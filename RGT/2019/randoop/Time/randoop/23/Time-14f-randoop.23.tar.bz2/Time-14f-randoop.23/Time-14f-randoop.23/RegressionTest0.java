import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) '#', (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3500 + "'", int2 == 3500);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology2 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, dateTimeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long3 = durationField0.subtract(10L, (int) (short) 0);
        org.junit.Assert.assertNotNull(durationField0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        java.lang.String str4 = property3.getAsShortText();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "19" + "'", str4.equals("19"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField2 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        org.joda.time.ReadablePartial readablePartial6 = null;
        try {
            int int7 = property3.compareTo(readablePartial6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 100.0d, (java.lang.Number) (-1), (java.lang.Number) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) 100, 0, (int) (short) 1, (-1), (int) '#', (int) (short) 100, 100, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 1, (long) (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test015");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560632798326L + "'", long0 == 1560632798326L);
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = null;
        try {
            org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        java.lang.Appendable appendable2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(dateTimeZone3);
        int int5 = monthDay4.getMonthOfYear();
        try {
            dateTimeFormatter1.printTo(appendable2, (org.joda.time.ReadablePartial) monthDay4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) (byte) 10);
        java.lang.Appendable appendable3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone4);
        try {
            dateTimeFormatter2.printTo(appendable3, (org.joda.time.ReadablePartial) monthDay5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(10, (int) (short) 10, (int) (short) 0, (int) '#', 6, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(dateTimeZone0);
        int int2 = monthDay1.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.MonthDay monthDay5 = monthDay1.withChronologyRetainFields((org.joda.time.Chronology) buddhistChronology4);
        try {
            org.joda.time.MonthDay monthDay7 = monthDay1.withDayOfMonth((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(monthDay5);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long3 = durationField0.subtract((long) 10, (-1L));
        org.junit.Assert.assertNotNull(durationField0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 11L + "'", long3 == 11L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(dateTimeZone2);
        int int4 = monthDay3.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.MonthDay monthDay7 = monthDay3.withChronologyRetainFields((org.joda.time.Chronology) buddhistChronology6);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) monthDay3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(monthDay7);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        try {
            int[] intArray4 = copticChronology0.get(readablePeriod1, (long) (byte) 1, (long) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, 3500, (int) (short) 0, 1, (int) (short) 100, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
        try {
            org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, 10L, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneOffset("", "", false, (int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
        try {
            org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for weekOfWeekyear must be in the range [1,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime2.plusSeconds((-1));
        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
        org.joda.time.LocalDateTime localDateTime7 = dateTime2.toLocalDateTime();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.DateTime dateTime10 = dateTime2.withFieldAdded(durationFieldType8, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDateTime7);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        java.lang.Appendable appendable2 = null;
        try {
            dateTimeFormatter0.printTo(appendable2, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        org.joda.time.DateTime dateTime8 = dateTime7.toDateTimeISO();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test038");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
//        boolean boolean3 = dateTimeFormatter0.isOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone4);
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
//        org.joda.time.DurationFieldType durationFieldType7 = null;
//        try {
//            org.joda.time.MonthDay monthDay9 = monthDay5.withFieldAdded(durationFieldType7, (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Jun 15, ���� �:��:�� �" + "'", str6.equals("Jun 15, ���� �:��:�� �"));
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        try {
            int[] intArray4 = copticChronology0.get(readablePeriod1, (long) 57599999, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (byte) 1, (int) (byte) 0, (int) (byte) 10, (int) (byte) -1, (int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeParser[] dateTimeParserArray4 = new org.joda.time.format.DateTimeParser[] {};
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.append(dateTimePrinter3, dateTimeParserArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeParserArray4);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        try {
            long long5 = copticChronology0.getDateTimeMillis((int) (short) 0, 0, (int) ' ', 6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = buddhistChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField5 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("19");
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFixedDecimal(dateTimeFieldType3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.Instant instant4 = new org.joda.time.Instant((java.lang.Object) dateTime2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.withZoneRetainFields(dateTimeZone5);
        try {
            org.joda.time.DateTime dateTime8 = dateTime6.withMonthOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        try {
            org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (byte) 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.util.Calendar calendar0 = null;
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.fromCalendarFields(calendar0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The calendar must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test054");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
//        boolean boolean3 = dateTimeFormatter0.isOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone4);
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
//        try {
//            org.joda.time.DateTimeFieldType dateTimeFieldType8 = monthDay5.getFieldType(3500);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3500");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Jun 15, ���� �:��:�� �" + "'", str6.equals("Jun 15, ���� �:��:�� �"));
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendTimeZoneOffset("--06-15", "15", true, (int) (byte) -1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        java.io.Writer writer2 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime5.centuryOfEra();
        org.joda.time.DateTime.Property property7 = dateTime5.weekyear();
        try {
            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadableInstant) dateTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = buddhistChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType4, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Chronology must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("19");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"19\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(dateTimeZone2);
        int int4 = monthDay3.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.MonthDay monthDay7 = monthDay3.withChronologyRetainFields((org.joda.time.Chronology) buddhistChronology6);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) monthDay7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(monthDay7);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        int int4 = dateTime2.getYearOfCentury();
        org.joda.time.DateTime dateTime6 = dateTime2.plusSeconds(15);
        org.joda.time.DateTime.Property property7 = dateTime2.weekyear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 69 + "'", int4 == 69);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        try {
            long long10 = buddhistChronology1.getDateTimeMillis(0, 59, 0, (int) 'a', 3500, (int) (byte) 10, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        int int6 = dateTime5.getMillisOfDay();
        java.util.Locale locale8 = null;
        java.lang.String str9 = dateTime5.toString("15", locale8);
        int int10 = dateTime5.getDayOfWeek();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57599999 + "'", int6 == 57599999);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "15" + "'", str9.equals("15"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = buddhistChronology1.withUTC();
        org.joda.time.DurationField durationField3 = buddhistChronology1.days();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
        org.joda.time.Chronology chronology6 = buddhistChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology5.secondOfDay();
        org.joda.time.DurationField durationField8 = buddhistChronology5.millis();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone11);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime.Property property14 = dateTime12.hourOfDay();
        org.joda.time.DateTime.Property property15 = dateTime12.hourOfDay();
        try {
            org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) 59);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType3 = monthDay1.getFieldType(3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        try {
            org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((int) 'a', 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.lang.Appendable appendable3 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
        org.joda.time.DateTime.Property property8 = dateTime6.hourOfDay();
        org.joda.time.DateTime.Property property9 = dateTime6.hourOfDay();
        try {
            dateTimeFormatter0.printTo(appendable3, (org.joda.time.ReadableInstant) dateTime6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test072");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
//        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
//        org.joda.time.DateTime dateTime5 = dateTime2.plusSeconds((-1));
//        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
//        org.joda.time.LocalDateTime localDateTime7 = dateTime2.toLocalDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withPivotYear((java.lang.Integer) 10);
//        boolean boolean11 = dateTimeFormatter8.isOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(dateTimeZone12);
//        java.lang.String str14 = dateTimeFormatter8.print((org.joda.time.ReadablePartial) monthDay13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(dateTimeZone15);
//        int int17 = monthDay16.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone18);
//        org.joda.time.MonthDay monthDay20 = monthDay16.withChronologyRetainFields((org.joda.time.Chronology) buddhistChronology19);
//        int int21 = monthDay13.compareTo((org.joda.time.ReadablePartial) monthDay20);
//        try {
//            boolean boolean22 = localDateTime7.isBefore((org.joda.time.ReadablePartial) monthDay20);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(localDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Jun 15, ���� �:��:�� �" + "'", str14.equals("Jun 15, ���� �:��:�� �"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNotNull(buddhistChronology19);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 3500);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology3 = buddhistChronology2.withUTC();
        org.joda.time.DurationField durationField4 = buddhistChronology2.days();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField5 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(10);
        java.lang.String str5 = dateTimeZone3.getShortName(3599999L);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone7);
        org.joda.time.DateTime dateTime9 = dateTime8.toDateTime();
        org.joda.time.DateTime dateTime11 = dateTime8.plusSeconds((-1));
        org.joda.time.DateTime.Property property12 = dateTime8.monthOfYear();
        org.joda.time.LocalDateTime localDateTime13 = dateTime8.toLocalDateTime();
        boolean boolean14 = dateTimeZone3.isLocalDateTimeGap(localDateTime13);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDateTime13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+10:00" + "'", str5.equals("+10:00"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = buddhistChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone9);
        org.joda.time.DateTime.Property property11 = dateTime10.centuryOfEra();
        org.joda.time.Instant instant12 = new org.joda.time.Instant((java.lang.Object) dateTime10);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = dateTime10.withZoneRetainFields(dateTimeZone13);
        try {
            org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.ReadableDateTime) dateTime6, (org.joda.time.ReadableDateTime) dateTime14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeParser dateTimeParser4 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParser4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
        boolean boolean3 = dateTimeFormatter0.isOffsetParsed();
        java.lang.StringBuffer stringBuffer4 = null;
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((long) 59);
        try {
            dateTimeFormatter0.printTo(stringBuffer4, (org.joda.time.ReadablePartial) monthDay6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        org.joda.time.DateTime.Property property5 = dateTime3.weekyear();
        boolean boolean6 = iSOChronology0.equals((java.lang.Object) property5);
        java.lang.String str7 = property5.getAsString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970" + "'", str7.equals("1970"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime5.centuryOfEra();
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime5.toMutableDateTime();
        int int10 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime7, "1970", (int) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 23);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfDay();
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        int int6 = dateTime5.getMillisOfDay();
        boolean boolean7 = dateTime5.isBeforeNow();
        org.joda.time.DateTime.Property property8 = dateTime5.dayOfMonth();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57599999 + "'", int6 == 57599999);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readableDuration4);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.centuryOfEra();
        org.joda.time.DateTime dateTime11 = property9.addToCopy(0);
        int int12 = dateTime11.getMillisOfDay();
        boolean boolean13 = dateTime11.isBeforeNow();
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime3, (org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime.Property property15 = dateTime3.dayOfWeek();
        org.joda.time.DateTime dateTime17 = dateTime3.minus((long) (short) 1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 57599999 + "'", int12 == 57599999);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(dateTimeZone14);
        int int16 = monthDay15.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone17);
        org.joda.time.MonthDay monthDay19 = monthDay15.withChronologyRetainFields((org.joda.time.Chronology) buddhistChronology18);
        int[] intArray23 = new int[] { 23, (byte) -1 };
        try {
            int[] intArray25 = delegatedDateTimeField13.add((org.joda.time.ReadablePartial) monthDay19, (int) '4', intArray23, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendDayOfWeekText();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendFixedSignedDecimal(dateTimeFieldType7, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.DurationField durationField2 = org.joda.time.field.MillisDurationField.INSTANCE;
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField3 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField1, durationField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        java.lang.String str3 = dateTimeZone1.getShortName(3599999L);
        long long5 = dateTimeZone1.convertUTCToLocal(0L);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 15");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+10:00" + "'", str3.equals("+10:00"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 36000000L + "'", long5 == 36000000L);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test092");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
//        boolean boolean3 = dateTimeFormatter0.isOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone4);
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
//        org.joda.time.MonthDay.Property property7 = monthDay5.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
//        try {
//            org.joda.time.MonthDay.Property property9 = monthDay5.property(dateTimeFieldType8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Jun 15, ���� �:��:�� �" + "'", str6.equals("Jun 15, ���� �:��:�� �"));
//        org.junit.Assert.assertNotNull(property7);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("19");
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, (int) (short) 10);
        org.joda.time.DateTime dateTime5 = instant4.toDateTime();
        org.joda.time.DateTimeZone dateTimeZone6 = dateTime5.getZone();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone8);
        org.joda.time.DateTime dateTime10 = dateTime9.toDateTime();
        org.joda.time.DateTime dateTime12 = dateTime9.plusSeconds((-1));
        org.joda.time.DateTime.Property property13 = dateTime9.monthOfYear();
        org.joda.time.LocalDateTime localDateTime14 = dateTime9.toLocalDateTime();
        int int15 = dateTime9.getMinuteOfDay();
        try {
            org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (org.joda.time.ReadableInstant) dateTime9, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 32");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(localDateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 959 + "'", int15 == 959);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneOffset("Jun 15, ���� �:��:�� �", "hi!", false, 6, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendDayOfWeek(1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        try {
            org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((int) (short) 100, 0, (org.joda.time.Chronology) julianChronology2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        int int0 = org.joda.time.MonthDay.DAY_OF_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test098");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        org.joda.time.DateTime.Property property5 = dateTime3.weekyear();
        boolean boolean6 = iSOChronology0.equals((java.lang.Object) property5);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField10 = new org.joda.time.field.DividedDateTimeField(dateTimeField7, dateTimeFieldType8, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.centuryOfEra();
        org.joda.time.DateTime dateTime10 = property8.addToCopy(0);
        org.joda.time.DateMidnight dateMidnight11 = dateTime10.toDateMidnight();
        int int12 = property4.getDifference((org.joda.time.ReadableInstant) dateMidnight11);
        long long13 = property4.remainder();
        try {
            org.joda.time.DateTime dateTime15 = property4.setCopy("");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for hourOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateMidnight11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3599999L + "'", long13 == 3599999L);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.hourOfDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(chronology5);
        org.joda.time.DateTime dateTime8 = dateTime6.minusYears(30);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.hourOfDay();
        org.joda.time.DateTime.Property property5 = dateTime2.hourOfDay();
        int int6 = property5.getLeapAmount();
        java.lang.String str7 = property5.getName();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hourOfDay" + "'", str7.equals("hourOfDay"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("19");
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, (int) (short) 10);
        org.joda.time.DateTime dateTime5 = instant4.toDateTime();
        int int6 = dateTime5.getYearOfEra();
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 19 + "'", int6 == 19);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneOffset("Jun 15, ���� �:��:�� �", "hi!", false, 6, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral('a');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap9 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendTimeZoneName(strMap9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendFixedDecimal(dateTimeFieldType11, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneOffset("Jun 15, ���� �:��:�� �", "hi!", false, 6, (int) 'a');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendMinuteOfDay((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("T16:00:00.100-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: T16:00:00.100-08:00");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = buddhistChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.secondOfDay();
        org.joda.time.DurationField durationField4 = buddhistChronology1.millis();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology1);
        java.lang.Object obj6 = null;
        boolean boolean7 = buddhistChronology1.equals(obj6);
        org.joda.time.DurationField durationField8 = buddhistChronology1.hours();
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology1, dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone13);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
        org.joda.time.DateTime dateTime17 = dateTime14.plusSeconds((-1));
        org.joda.time.DateTime.Property property18 = dateTime14.monthOfYear();
        org.joda.time.LocalDateTime localDateTime19 = dateTime14.toLocalDateTime();
        int int20 = dateTime14.getMinuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone22);
        org.joda.time.DateTime.Property property24 = dateTime23.centuryOfEra();
        org.joda.time.DateTime.Property property25 = dateTime23.hourOfDay();
        org.joda.time.DateTime.Property property26 = dateTime23.millisOfSecond();
        try {
            org.joda.time.chrono.LimitChronology limitChronology27 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.ReadableDateTime) dateTime14, (org.joda.time.ReadableDateTime) dateTime23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(localDateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 959 + "'", int20 == 959);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property26);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = buddhistChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.secondOfDay();
        org.joda.time.DurationField durationField4 = buddhistChronology1.millis();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology1);
        java.lang.Object obj6 = null;
        boolean boolean7 = buddhistChronology1.equals(obj6);
        org.joda.time.DurationField durationField8 = buddhistChronology1.hours();
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology1, dateTimeZone10);
        org.joda.time.DurationField durationField12 = zonedChronology11.years();
        try {
            long long18 = zonedChronology11.getDateTimeMillis((long) 959, 3, (-1), 959, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (byte) 10, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.minus(readableDuration3);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMonths((int) (short) -1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology3 = copticChronology0.withZone(dateTimeZone2);
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay((long) 59);
        org.joda.time.MonthDay monthDay7 = monthDay5.minusDays(1);
        int[] intArray8 = monthDay5.getValues();
        try {
            long long10 = copticChronology0.set((org.joda.time.ReadablePartial) monthDay5, (long) 30);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(intArray8);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.util.Collection<org.joda.time.DateTimeFieldType> dateTimeFieldTypeCollection0 = null;
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.forFields(dateTimeFieldTypeCollection0, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("19");
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        org.joda.time.DateMidnight dateMidnight6 = dateTime5.toDateMidnight();
        try {
            org.joda.time.DateTime dateTime8 = dateTime5.withMonthOfYear(19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateMidnight6);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("--06-15", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"--06-15\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(100, (-1), 7, (int) (byte) 1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneOffset("Jun 15, ���� �:��:�� �", "hi!", false, 6, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendMillisOfDay(10);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder10.appendTimeZoneOffset("+10:00", "dayOfMonth", false, 10, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = buddhistChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.secondOfDay();
        org.joda.time.DurationField durationField4 = buddhistChronology1.millis();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology1, dateTimeZone8);
        try {
            long long14 = zonedChronology9.getDateTimeMillis(10, 100, (int) (byte) 10, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(zonedChronology9);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        int int8 = dateTime5.getSecondOfMinute();
        org.joda.time.Instant instant9 = new org.joda.time.Instant((java.lang.Object) dateTime5);
        org.joda.time.MutableDateTime mutableDateTime10 = instant9.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        java.lang.String str6 = property3.getAsString();
        org.joda.time.DurationField durationField7 = property3.getDurationField();
        org.joda.time.DurationField durationField8 = property3.getRangeDurationField();
        org.joda.time.Interval interval9 = property3.toInterval();
        java.lang.String str10 = property3.getAsShortText();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "19" + "'", str6.equals("19"));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "19" + "'", str10.equals("19"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(30, 23, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "+10:59");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test132");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
//        boolean boolean3 = dateTimeFormatter0.isOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone4);
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
//        try {
//            org.joda.time.LocalDate localDate8 = dateTimeFormatter0.parseLocalDate("");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Jun 15, ���� �:��:�� �" + "'", str6.equals("Jun 15, ���� �:��:�� �"));
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        org.joda.time.DateTime.Property property5 = dateTime3.weekyear();
        boolean boolean6 = iSOChronology0.equals((java.lang.Object) property5);
        try {
            long long11 = iSOChronology0.getDateTimeMillis((int) (byte) -1, (int) '#', 7, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(31, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 131 + "'", int2 == 131);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        try {
            org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) dateTimeFormatter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
        org.joda.time.DateTime dateTime10 = dateTime7.plusYears(59);
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        int int6 = dateTime5.getMillisOfDay();
        int int7 = dateTime5.getMinuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.DateTime dateTime10 = dateTime5.toDateTime(dateTimeZone9);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57599999 + "'", int6 == 57599999);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 959 + "'", int7 == 959);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
        try {
            long long14 = gJChronology9.getDateTimeMillis((int) (byte) 10, (int) (byte) 10, (int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gJChronology9);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) ' ', 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 132 + "'", int2 == 132);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = buddhistChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.secondOfDay();
        org.joda.time.Chronology chronology4 = buddhistChronology1.withUTC();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test141");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.monthOfYear();
//        org.joda.time.DurationField durationField2 = copticChronology0.minutes();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withPivotYear((java.lang.Integer) 10);
//        boolean boolean6 = dateTimeFormatter3.isOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(dateTimeZone7);
//        java.lang.String str9 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) monthDay8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay(dateTimeZone10);
//        int int12 = monthDay11.getMonthOfYear();
//        java.lang.String str13 = monthDay11.toString();
//        int[] intArray14 = monthDay11.getValues();
//        copticChronology0.validate((org.joda.time.ReadablePartial) monthDay8, intArray14);
//        org.joda.time.DateTimeField dateTimeField16 = null;
//        try {
//            org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField16);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Jun 15, ���� �:��:�� �" + "'", str9.equals("Jun 15, ���� �:��:�� �"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "--06-15" + "'", str13.equals("--06-15"));
//        org.junit.Assert.assertNotNull(intArray14);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = copticChronology0.months();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField5 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType3, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = buddhistChronology1.withUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime5.centuryOfEra();
        org.joda.time.DateTime dateTime8 = property6.addToCopy(0);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.minus(readableDuration9);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTime10.getZone();
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11);
        boolean boolean13 = buddhistChronology1.equals((java.lang.Object) gJChronology12);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime2.plusSeconds((-1));
        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
        long long7 = property6.remainder();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2649599999L + "'", long7 == 2649599999L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType3, 959, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        org.joda.time.DateTime.Property property5 = dateTime3.weekyear();
        boolean boolean6 = iSOChronology0.equals((java.lang.Object) property5);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.hourOfDay();
        org.joda.time.DateTime.Property property5 = dateTime2.hourOfDay();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) 15);
        org.joda.time.DateTime dateTime9 = dateTime7.plusSeconds(69);
        org.joda.time.DateTime dateTime11 = dateTime7.withMonthOfYear((int) (short) 10);
        int int12 = dateTime11.getSecondOfMinute();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 59 + "'", int12 == 59);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        java.lang.StringBuffer stringBuffer2 = null;
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer2, readablePartial3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("Property[dayOfMonth]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[dayOfMonth]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 0, (int) (byte) -1, 1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        int int0 = org.joda.time.MonthDay.MONTH_OF_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.centuryOfEra();
        org.joda.time.DateTime.Property property6 = dateTime4.hourOfDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DateTime dateTime9 = property7.addToCopy((long) 15);
        boolean boolean10 = dateTime9.isEqualNow();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime9);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        try {
            long long9 = gregorianChronology1.getDateTimeMillis(23, (int) 'a', (-1), (int) (byte) 1, (int) ' ', 100, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.hourOfDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(chronology5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        boolean boolean8 = dateTime2.isSupported(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
//        boolean boolean3 = dateTimeFormatter0.isOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone4);
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
//        org.joda.time.MonthDay.Property property7 = monthDay5.monthOfYear();
//        try {
//            org.joda.time.DateTimeFieldType dateTimeFieldType9 = monthDay5.getFieldType(187200000);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 187200000");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Jun 15, ���� �:��:�� �" + "'", str6.equals("Jun 15, ���� �:��:�� �"));
//        org.junit.Assert.assertNotNull(property7);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str2 = dateTimeFormatter0.print((long) (short) 100);
        java.lang.StringBuffer stringBuffer3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer3, readableInstant4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "T16:00:00.100-08:00" + "'", str2.equals("T16:00:00.100-08:00"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        int int6 = dateTime5.getMillisOfDay();
        java.util.Locale locale8 = null;
        java.lang.String str9 = dateTime5.toString("15", locale8);
        org.joda.time.DateTime dateTime11 = dateTime5.minus((long) 3500);
        org.joda.time.DateTime dateTime13 = dateTime11.plusHours(10);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.withDurationAdded(readableDuration14, 131);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57599999 + "'", int6 == 57599999);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "15" + "'", str9.equals("15"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
        org.joda.time.Instant instant10 = gJChronology9.getGregorianCutover();
        java.lang.String str11 = gJChronology9.toString();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str11.equals("GJChronology[America/Los_Angeles]"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.hourOfDay();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        org.joda.time.Interval interval6 = property4.toInterval();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(interval6);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        java.util.Locale locale2 = dateTimeFormatter0.getLocale();
        try {
            long long4 = dateTimeFormatter0.parseMillis("T16:00:00.100-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"T16:00:00.100-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.hourOfDay();
        org.joda.time.DateTime.Property property5 = dateTime2.hourOfDay();
        try {
            org.joda.time.DateTime dateTime7 = dateTime2.withYearOfEra((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField12.getMaximumShortTextLength(locale13);
        java.lang.String str15 = skipDateTimeField12.getName();
        boolean boolean17 = skipDateTimeField12.isLeap((long) 10);
        int int20 = skipDateTimeField12.getDifference((long) 959, (long) 7);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField23 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField12, dateTimeFieldType21, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 7 + "'", int14 == 7);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "centuryOfEra" + "'", str15.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(1, 6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendTwoDigitWeekyear((int) (byte) 100);
        org.joda.time.format.DateTimeParser dateTimeParser11 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendOptional(dateTimeParser11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readableDuration4);
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfMinute();
        org.joda.time.DateTime.Property property7 = dateTime5.year();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 23);
        boolean boolean10 = property7.equals((java.lang.Object) dateTime9);
        int int11 = dateTime9.getYearOfCentury();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 69 + "'", int11 == 69);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = buddhistChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.secondOfDay();
        org.joda.time.DurationField durationField4 = buddhistChronology1.millis();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology1);
        java.lang.Object obj6 = null;
        boolean boolean7 = buddhistChronology1.equals(obj6);
        org.joda.time.DurationField durationField8 = buddhistChronology1.hours();
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology1, dateTimeZone10);
        org.joda.time.DurationField durationField12 = zonedChronology11.years();
        try {
            long long18 = zonedChronology11.getDateTimeMillis((long) 23, 3500, (int) 'a', 7, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3500 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.util.Locale locale3 = dateTimeFormatter2.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(locale3);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        int int8 = dateTime5.getSecondOfMinute();
        org.joda.time.DateTimeField dateTimeField9 = null;
        try {
            int int10 = dateTime5.get(dateTimeField9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeField must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField13.getLeapDurationField();
        long long17 = delegatedDateTimeField13.addWrapField((long) '#', (int) (short) 1);
        long long19 = delegatedDateTimeField13.roundHalfCeiling((long) 7);
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField13.getAsText(36000000L, locale21);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 3155760000035L + "'", long17 == 3155760000035L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-378662400000L) + "'", long19 == (-378662400000L));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "26" + "'", str22.equals("26"));
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test173");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
//        java.io.Writer writer1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(dateTimeZone2);
//        int int4 = monthDay3.getMonthOfYear();
//        java.lang.String str5 = monthDay3.toString();
//        int[] intArray6 = monthDay3.getValues();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        boolean boolean8 = monthDay3.isSupported(dateTimeFieldType7);
//        org.joda.time.MonthDay monthDay10 = monthDay3.plusMonths((-1));
//        try {
//            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) monthDay10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "--06-15" + "'", str5.equals("--06-15"));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(monthDay10);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readableDuration4);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.centuryOfEra();
        org.joda.time.DateTime dateTime11 = property9.addToCopy(0);
        int int12 = dateTime11.getMillisOfDay();
        boolean boolean13 = dateTime11.isBeforeNow();
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime3, (org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime16 = dateTime3.plusWeeks(0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 57599999 + "'", int12 == 57599999);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
        long long15 = delegatedDateTimeField13.roundFloor((long) 30);
        java.util.Locale locale18 = null;
        try {
            long long19 = delegatedDateTimeField13.set((long) (byte) 100, "Jun", locale18);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Jun\" for centuryOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-378662400000L) + "'", long15 == (-378662400000L));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology3 = buddhistChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.secondOfDay();
        org.joda.time.DurationField durationField5 = buddhistChronology2.millis();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology2);
        java.lang.Object obj7 = null;
        boolean boolean8 = buddhistChronology2.equals(obj7);
        org.joda.time.DurationField durationField9 = buddhistChronology2.hours();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone10);
        org.joda.time.Chronology chronology12 = buddhistChronology11.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology11.secondOfDay();
        org.joda.time.DurationField durationField14 = buddhistChronology11.millis();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology11);
        java.lang.Object obj16 = null;
        boolean boolean17 = buddhistChronology11.equals(obj16);
        org.joda.time.DurationField durationField18 = buddhistChronology11.hours();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField19 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField9, durationField18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(durationField18);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 59");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        int int8 = dateTime5.getSecondOfMinute();
        org.joda.time.DateTime.Property property9 = dateTime5.monthOfYear();
        java.lang.String str10 = property9.getAsText();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "December" + "'", str10.equals("December"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        java.lang.String str1 = copticChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str1.equals("CopticChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test180");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
//        java.io.Writer writer1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(dateTimeZone2);
//        int int4 = monthDay3.getMonthOfYear();
//        java.lang.String str5 = monthDay3.toString();
//        int[] intArray6 = monthDay3.getValues();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        boolean boolean8 = monthDay3.isSupported(dateTimeFieldType7);
//        try {
//            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) monthDay3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "--06-15" + "'", str5.equals("--06-15"));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(132, (int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("19");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str3 = jodaTimePermission1.getName();
        org.joda.time.JodaTimePermission jodaTimePermission5 = new org.joda.time.JodaTimePermission("19");
        boolean boolean6 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission5);
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "19" + "'", str3.equals("19"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 0, (int) ' ', 15, 959);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test185");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
//        boolean boolean3 = dateTimeFormatter0.isOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone4);
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(dateTimeZone7);
//        int int9 = monthDay8.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone10);
//        org.joda.time.MonthDay monthDay12 = monthDay8.withChronologyRetainFields((org.joda.time.Chronology) buddhistChronology11);
//        int int13 = monthDay5.compareTo((org.joda.time.ReadablePartial) monthDay12);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone14);
//        org.joda.time.Chronology chronology16 = buddhistChronology15.withUTC();
//        org.joda.time.MonthDay monthDay17 = monthDay12.withChronologyRetainFields((org.joda.time.Chronology) buddhistChronology15);
//        java.util.Locale locale19 = null;
//        try {
//            java.lang.String str20 = monthDay17.toString("America/Los_Angeles", locale19);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: A");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Jun 15, ���� �:��:�� �" + "'", str6.equals("Jun 15, ���� �:��:�� �"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertNotNull(buddhistChronology11);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(buddhistChronology15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(monthDay17);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 10, 59);
        java.lang.String str11 = dateTimeZone9.getName(0L);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone13);
        org.joda.time.DateTime.Property property15 = dateTime14.centuryOfEra();
        org.joda.time.Instant instant16 = new org.joda.time.Instant((java.lang.Object) dateTime14);
        int int17 = dateTimeZone9.getOffset((org.joda.time.ReadableInstant) instant16);
        try {
            org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) 'a', 2, 59, 132, 100, (int) '4', 2, dateTimeZone9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 132 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+10:59" + "'", str11.equals("+10:59"));
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 39540000 + "'", int17 == 39540000);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        int int0 = org.joda.time.chrono.CopticChronology.AM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime2.plusSeconds((-1));
        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
        org.joda.time.DateTime dateTime7 = property6.roundHalfFloorCopy();
        org.joda.time.DurationField durationField8 = property6.getLeapDurationField();
        long long11 = durationField8.subtract((long) 15, (long) 31);
        org.joda.time.DurationFieldType durationFieldType12 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField14 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType12, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-2678399985L) + "'", long11 == (-2678399985L));
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(dateTimeZone0);
//        int int2 = monthDay1.getMonthOfYear();
//        java.lang.String str3 = monthDay1.toString();
//        int[] intArray4 = monthDay1.getValues();
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        try {
//            org.joda.time.MonthDay.Property property6 = monthDay1.property(dateTimeFieldType5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "--06-15" + "'", str3.equals("--06-15"));
//        org.junit.Assert.assertNotNull(intArray4);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        java.lang.String str3 = dateTimeFormatter1.print((-15L));
        try {
            org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("dayOfMonth", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"dayOfMonth\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T15:59:59-08:00" + "'", str3.equals("T15:59:59-08:00"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        try {
            org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((java.lang.Object) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: java.lang.Character");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readableDuration4);
        try {
            org.joda.time.DateTime dateTime7 = dateTime5.withMonthOfYear(187200000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 187200000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        try {
            org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(959, 3500);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 959 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test197");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
//        boolean boolean3 = dateTimeFormatter0.isOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone4);
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
//        org.joda.time.MonthDay.Property property7 = monthDay5.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay(dateTimeZone8);
//        int int10 = monthDay9.getMonthOfYear();
//        boolean boolean11 = monthDay5.isBefore((org.joda.time.ReadablePartial) monthDay9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Jun 15, ���� �:��:�� �" + "'", str6.equals("Jun 15, ���� �:��:�� �"));
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
        long long15 = delegatedDateTimeField13.roundFloor((long) 30);
        java.util.Locale locale18 = null;
        try {
            long long19 = delegatedDateTimeField13.set((long) 69, "", locale18);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for centuryOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-378662400000L) + "'", long15 == (-378662400000L));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField13.getLeapDurationField();
        long long17 = delegatedDateTimeField13.addWrapField((long) '#', (int) (short) 1);
        long long19 = delegatedDateTimeField13.roundHalfCeiling((long) 7);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay(dateTimeZone20);
        org.joda.time.MonthDay monthDay23 = monthDay21.minusDays((int) (byte) 1);
        java.util.Locale locale24 = null;
        try {
            java.lang.String str25 = delegatedDateTimeField13.getAsText((org.joda.time.ReadablePartial) monthDay23, locale24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'centuryOfEra' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 3155760000035L + "'", long17 == 3155760000035L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-378662400000L) + "'", long19 == (-378662400000L));
        org.junit.Assert.assertNotNull(monthDay23);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.Instant instant4 = new org.joda.time.Instant((java.lang.Object) dateTime2);
        org.joda.time.ReadableInstant readableInstant5 = null;
        boolean boolean6 = dateTime2.isBefore(readableInstant5);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime2.plus(readableDuration7);
        java.util.Locale locale10 = null;
        try {
            java.lang.String str11 = dateTime8.toString("Jun", locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: J");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.hourOfDay();
        org.joda.time.DurationField durationField5 = property4.getLeapDurationField();
        int int6 = property4.getMaximumValueOverall();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone8);
        org.joda.time.DateTime dateTime10 = dateTime9.toDateTime();
        org.joda.time.DateTime dateTime12 = dateTime9.plusSeconds((-1));
        boolean boolean13 = property4.equals((java.lang.Object) dateTime12);
        boolean boolean15 = org.joda.time.field.FieldUtils.equals((java.lang.Object) boolean13, (java.lang.Object) 32);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 23 + "'", int6 == 23);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        try {
            long long3 = dateTimeFormatter1.parseMillis("Property[dayOfMonth]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[dayOfMonth]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 959);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 959 + "'", int1 == 959);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readableDuration4);
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfMinute();
        org.joda.time.DateTime.Property property7 = dateTime5.year();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 23);
        boolean boolean10 = property7.equals((java.lang.Object) dateTime9);
        org.joda.time.DateTime dateTime12 = dateTime9.minusMonths((int) 'a');
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        java.lang.String str6 = property3.getAsString();
        org.joda.time.DateTime dateTime8 = property3.setCopy(959);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.centuryOfEra();
        org.joda.time.DateTime.Property property13 = dateTime11.hourOfDay();
        org.joda.time.DateTime.Property property14 = dateTime11.hourOfDay();
        org.joda.time.DateTime dateTime16 = property14.addToCopy((long) 15);
        org.joda.time.DateTime dateTime18 = dateTime16.plusSeconds(69);
        org.joda.time.DateTime dateTime20 = dateTime16.withMonthOfYear((int) (short) 10);
        java.util.Date date21 = dateTime16.toDate();
        long long22 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
        boolean boolean24 = dateTime16.isSupported(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "19" + "'", str6.equals("19"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test207");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(dateTimeZone0);
//        int int2 = monthDay1.getMonthOfYear();
//        java.lang.String str3 = monthDay1.toString();
//        int[] intArray4 = monthDay1.getValues();
//        org.joda.time.MonthDay.Property property5 = monthDay1.dayOfMonth();
//        try {
//            org.joda.time.DateTimeField dateTimeField7 = monthDay1.getField((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: -1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "--06-15" + "'", str3.equals("--06-15"));
//        org.junit.Assert.assertNotNull(intArray4);
//        org.junit.Assert.assertNotNull(property5);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("+10:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+10:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2, 15);
        long long6 = skipDateTimeField4.roundHalfEven((long) 2922796);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2923000L + "'", long6 == 2923000L);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
        java.lang.String str6 = copticChronology5.toString();
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, (int) ' ', (int) (short) 10, (int) (short) -1, (int) 'a', (org.joda.time.Chronology) copticChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str6.equals("CopticChronology[America/Los_Angeles]"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime2.withMillisOfDay(23);
        org.joda.time.DateTime.Property property6 = dateTime2.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(959, 100, 0, 187200000, 39540000, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 187200000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(1, 6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendMonthOfYearText();
        org.joda.time.format.DateTimeParser dateTimeParser10 = dateTimeFormatterBuilder9.toParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeParser10);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(dateTimeZone0);
        org.joda.time.MonthDay monthDay3 = monthDay1.minusDays((int) (byte) 1);
        org.joda.time.DateTimeField[] dateTimeFieldArray4 = monthDay1.getFields();
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(dateTimeFieldArray4);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.lang.Number number2 = null;
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Jun", (java.lang.Number) 19, number2, number3);
        java.lang.Number number5 = illegalFieldValueException4.getIllegalNumberValue();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 19 + "'", number5.equals(19));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
        org.joda.time.DateTime.Property property9 = dateTime7.yearOfEra();
        boolean boolean11 = dateTime7.isEqual(2649599999L);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendCenturyOfEra(0, 59);
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withLocale(locale8);
        org.joda.time.format.DateTimeParser dateTimeParser10 = dateTimeFormatter7.getParser();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder5.append(dateTimePrinter6, dateTimeParser10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeParser10);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneOffset("Jun 15, ���� �:��:�� �", "hi!", false, 6, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMinuteOfDay(10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
        boolean boolean3 = dateTimeFormatter0.isOffsetParsed();
        boolean boolean4 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        org.joda.time.DateTime.Property property5 = dateTime3.hourOfDay();
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime(chronology6);
        boolean boolean8 = julianChronology0.equals((java.lang.Object) dateTime3);
        java.lang.String str9 = julianChronology0.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "JulianChronology[UTC]" + "'", str9.equals("JulianChronology[UTC]"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology0.secondOfDay();
        try {
            org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay((java.lang.Object) dateTimeField13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str10 = dateTimeFormatter8.print((long) (short) 100);
        boolean boolean11 = iSOChronology7.equals((java.lang.Object) dateTimeFormatter8);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
        org.joda.time.Chronology chronology14 = buddhistChronology13.withUTC();
        org.joda.time.DateTimeField dateTimeField15 = buddhistChronology13.secondOfDay();
        org.joda.time.DurationField durationField16 = buddhistChronology13.millis();
        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology13.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology7, dateTimeField17, (int) (short) 100);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology7.secondOfDay();
        try {
            org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(69, 0, 1, 1, 25, (-11), (int) '4', (org.joda.time.Chronology) iSOChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -11 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "T16:00:00.100-08:00" + "'", str10.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField20);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        int int6 = dateTime5.getMillisOfDay();
        java.util.Locale locale8 = null;
        java.lang.String str9 = dateTime5.toString("15", locale8);
        org.joda.time.DateTime dateTime11 = dateTime5.minus((long) 3500);
        org.joda.time.DateTime dateTime13 = dateTime11.plusHours(10);
        java.util.GregorianCalendar gregorianCalendar14 = dateTime13.toGregorianCalendar();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57599999 + "'", int6 == 57599999);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "15" + "'", str9.equals("15"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.hourOfDay();
        org.joda.time.DateTime.Property property5 = dateTime2.hourOfDay();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) 15);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone9);
        org.joda.time.DateTime.Property property11 = dateTime10.centuryOfEra();
        org.joda.time.DateTime.Property property12 = dateTime10.hourOfDay();
        org.joda.time.DateTime.Property property13 = dateTime10.hourOfDay();
        org.joda.time.DateTime dateTime15 = property13.addToCopy((long) 15);
        org.joda.time.DateTime dateTime17 = dateTime15.plusSeconds(69);
        long long18 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTime dateTime20 = property5.addWrapFieldToCopy((int) 'a');
        org.joda.time.DateTime dateTime21 = property5.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        try {
            org.joda.time.DateTime.Property property23 = dateTime21.property(dateTimeFieldType22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-15L) + "'", long18 == (-15L));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField12.getMaximumShortTextLength(locale13);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField12, dateTimeFieldType15, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 7 + "'", int14 == 7);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime3.toMutableDateTime();
        int int8 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "centuryOfEra", 10);
        boolean boolean9 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-11) + "'", int8 == (-11));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField12.getMaximumShortTextLength(locale13);
        java.lang.String str15 = skipDateTimeField12.getName();
        long long17 = skipDateTimeField12.roundHalfEven(0L);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField19 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipDateTimeField12, dateTimeFieldType18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 7 + "'", int14 == 7);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "centuryOfEra" + "'", str15.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-378662400000L) + "'", long17 == (-378662400000L));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.hourOfDay();
        org.joda.time.DurationField durationField5 = property4.getLeapDurationField();
        int int6 = property4.getMaximumValueOverall();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone8);
        org.joda.time.DateTime dateTime10 = dateTime9.toDateTime();
        org.joda.time.DateTime dateTime12 = dateTime9.plusSeconds((-1));
        boolean boolean13 = property4.equals((java.lang.Object) dateTime12);
        int int14 = dateTime12.getSecondOfDay();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 23 + "'", int6 == 23);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 57598 + "'", int14 == 57598);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology3 = copticChronology0.withZone(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str7 = dateTimeFormatter5.print((long) (short) 100);
        boolean boolean8 = iSOChronology4.equals((java.lang.Object) dateTimeFormatter5);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
        org.joda.time.Chronology chronology11 = buddhistChronology10.withUTC();
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology10.secondOfDay();
        org.joda.time.DurationField durationField13 = buddhistChronology10.millis();
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology10.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology4, dateTimeField14, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField17 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        org.joda.time.DurationField durationField18 = delegatedDateTimeField17.getLeapDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField19 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField17);
        try {
            long long22 = skipUndoDateTimeField19.set((long) 132, "");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for centuryOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "T16:00:00.100-08:00" + "'", str7.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNull(durationField18);
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology3 = copticChronology0.withZone(dateTimeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.lang.String str7 = dateTimeFormatter5.print((long) (short) 100);
//        boolean boolean8 = iSOChronology4.equals((java.lang.Object) dateTimeFormatter5);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
//        org.joda.time.Chronology chronology11 = buddhistChronology10.withUTC();
//        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology10.secondOfDay();
//        org.joda.time.DurationField durationField13 = buddhistChronology10.millis();
//        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology10.centuryOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology4, dateTimeField14, (int) (short) 100);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField17 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
//        org.joda.time.DurationField durationField18 = delegatedDateTimeField17.getLeapDurationField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField19 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField17);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay(dateTimeZone20);
//        int int22 = monthDay21.getMonthOfYear();
//        java.lang.String str23 = monthDay21.toString();
//        int[] intArray24 = monthDay21.getValues();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = null;
//        boolean boolean26 = monthDay21.isSupported(dateTimeFieldType25);
//        org.joda.time.MonthDay monthDay28 = monthDay21.withDayOfMonth((int) (byte) 10);
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.MonthDay monthDay31 = monthDay21.withPeriodAdded(readablePeriod29, 69);
//        int[] intArray34 = new int[] { 132 };
//        try {
//            int[] intArray36 = delegatedDateTimeField17.set((org.joda.time.ReadablePartial) monthDay21, (int) (byte) 0, intArray34, 6);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "T16:00:00.100-08:00" + "'", str7.equals("T16:00:00.100-08:00"));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNull(durationField18);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "--06-15" + "'", str23.equals("--06-15"));
//        org.junit.Assert.assertNotNull(intArray24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(monthDay28);
//        org.junit.Assert.assertNotNull(monthDay31);
//        org.junit.Assert.assertNotNull(intArray34);
//    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
//        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
//        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
//        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
//        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
//        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
//        long long15 = delegatedDateTimeField13.roundFloor((long) 30);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withPivotYear((java.lang.Integer) 10);
//        boolean boolean19 = dateTimeFormatter16.isOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay(dateTimeZone20);
//        java.lang.String str22 = dateTimeFormatter16.print((org.joda.time.ReadablePartial) monthDay21);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay(dateTimeZone24);
//        int int26 = monthDay25.getMonthOfYear();
//        java.lang.String str27 = monthDay25.toString();
//        int[] intArray28 = monthDay25.getValues();
//        int[] intArray30 = delegatedDateTimeField13.addWrapField((org.joda.time.ReadablePartial) monthDay21, (int) (byte) 1, intArray28, (int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.MonthDay monthDay32 = new org.joda.time.MonthDay(dateTimeZone31);
//        int int33 = monthDay32.getMonthOfYear();
//        java.lang.String str34 = monthDay32.toString();
//        int[] intArray35 = monthDay32.getValues();
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = null;
//        boolean boolean37 = monthDay32.isSupported(dateTimeFieldType36);
//        org.joda.time.MonthDay monthDay39 = monthDay32.withDayOfMonth((int) (byte) 10);
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.MonthDay monthDay42 = new org.joda.time.MonthDay(dateTimeZone41);
//        int int43 = monthDay42.getMonthOfYear();
//        java.lang.String str44 = monthDay42.toString();
//        int[] intArray45 = monthDay42.getValues();
//        try {
//            int[] intArray47 = delegatedDateTimeField13.addWrapField((org.joda.time.ReadablePartial) monthDay39, (-2922685), intArray45, 23);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -2922685");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-378662400000L) + "'", long15 == (-378662400000L));
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Jun 15, ���� �:��:�� �" + "'", str22.equals("Jun 15, ���� �:��:�� �"));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "--06-15" + "'", str27.equals("--06-15"));
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertNotNull(intArray30);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "--06-15" + "'", str34.equals("--06-15"));
//        org.junit.Assert.assertNotNull(intArray35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(monthDay39);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "--06-15" + "'", str44.equals("--06-15"));
//        org.junit.Assert.assertNotNull(intArray45);
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = buddhistChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.secondOfDay();
        org.joda.time.DurationField durationField4 = buddhistChronology1.millis();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology1);
        java.lang.Object obj6 = null;
        boolean boolean7 = buddhistChronology1.equals(obj6);
        org.joda.time.DurationField durationField8 = buddhistChronology1.hours();
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology1, dateTimeZone10);
        org.joda.time.DurationField durationField12 = zonedChronology11.years();
        try {
            long long18 = zonedChronology11.getDateTimeMillis((long) 132, (int) '#', 4, (int) (byte) 100, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField12.getMaximumShortTextLength(locale13);
        java.lang.String str15 = skipDateTimeField12.getName();
        boolean boolean17 = skipDateTimeField12.isLeap((long) 10);
        int int20 = skipDateTimeField12.getDifference((long) 959, (long) 7);
        int int22 = skipDateTimeField12.get(0L);
        try {
            long long25 = skipDateTimeField12.set((long) (short) 0, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 7 + "'", int14 == 7);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "centuryOfEra" + "'", str15.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 25 + "'", int22 == 25);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        org.joda.time.LocalTime localTime8 = dateTime7.toLocalTime();
        org.joda.time.DateTime dateTime10 = dateTime7.minusDays((int) '4');
        boolean boolean12 = dateTime7.isAfter((long) '4');
        long long13 = dateTime7.getMillis();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
//        boolean boolean3 = dateTimeFormatter0.isOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone4);
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
//        org.joda.time.MonthDay.Property property7 = monthDay5.monthOfYear();
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        try {
//            boolean boolean9 = monthDay5.isEqual(readablePartial8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial cannot be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Jun 15, ���� �:��:�� �" + "'", str6.equals("Jun 15, ���� �:��:�� �"));
//        org.junit.Assert.assertNotNull(property7);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        java.io.Writer writer1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.centuryOfEra();
        org.joda.time.DateTime dateTime7 = property5.addToCopy(0);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.minus(readableDuration8);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime12 = dateTime9.minusDays((int) '4');
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.weekyear();
        org.joda.time.DurationField durationField5 = property4.getDurationField();
        int int6 = property4.getMinimumValue();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-292275054) + "'", int6 == (-292275054));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        try {
            long long6 = gregorianChronology1.getDateTimeMillis(69, (int) (short) -1, 2, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = gregorianChronology1.withZone(dateTimeZone2);
        java.lang.String str4 = gregorianChronology1.toString();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[UTC]" + "'", str4.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("America/Los_Angeles", (java.lang.Number) 0L, number2, (java.lang.Number) (byte) 10);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology3 = copticChronology0.withZone(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str7 = dateTimeFormatter5.print((long) (short) 100);
        boolean boolean8 = iSOChronology4.equals((java.lang.Object) dateTimeFormatter5);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
        org.joda.time.Chronology chronology11 = buddhistChronology10.withUTC();
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology10.secondOfDay();
        org.joda.time.DurationField durationField13 = buddhistChronology10.millis();
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology10.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology4, dateTimeField14, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField17 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        org.joda.time.DurationField durationField18 = delegatedDateTimeField17.getLeapDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField19 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField17);
        int int20 = skipUndoDateTimeField19.getMaximumValue();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "T16:00:00.100-08:00" + "'", str7.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2922796 + "'", int20 == 2922796);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) (-2922685));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        int int6 = dateTime5.getMillisOfDay();
        boolean boolean7 = dateTime5.isBeforeNow();
        org.joda.time.DateTime dateTime9 = dateTime5.withDayOfMonth(19);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMinutes(10);
        boolean boolean13 = dateTime9.isAfter(22089888000007L);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57599999 + "'", int6 == 57599999);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        java.lang.String str3 = dateTimeZone1.getShortName(3599999L);
        long long5 = dateTimeZone1.convertUTCToLocal(0L);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        java.lang.String str7 = dateTimeZone1.toString();
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.centuryOfEra();
        org.joda.time.DateTime dateTime14 = property12.addToCopy(0);
        java.lang.String str15 = property12.getAsString();
        org.joda.time.DateTime dateTime17 = property12.setCopy(959);
        int int18 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+10:00" + "'", str3.equals("+10:00"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 36000000L + "'", long5 == 36000000L);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+10:00" + "'", str7.equals("+10:00"));
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "19" + "'", str15.equals("19"));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 36000000 + "'", int18 == 36000000);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.hourOfDay();
        org.joda.time.DurationField durationField5 = property4.getLeapDurationField();
        java.lang.String str6 = property4.getAsString();
        int int7 = property4.getMaximumValue();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 23 + "'", int7 == 23);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        org.joda.time.LocalTime localTime8 = dateTime7.toLocalTime();
        org.joda.time.DateTime dateTime10 = dateTime7.minusDays((int) '4');
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.minus(readablePeriod11);
        int int13 = dateTime10.getYearOfEra();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1969 + "'", int13 == 1969);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneOffset("Jun 15, ���� �:��:�� �", "hi!", false, 6, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendMonthOfYearShortText();
        boolean boolean10 = dateTimeFormatterBuilder9.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.hourOfDay();
        org.joda.time.DateTime.Property property5 = dateTime2.hourOfDay();
        long long6 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField12.getMaximumShortTextLength(locale13);
        java.lang.String str15 = skipDateTimeField12.getName();
        boolean boolean17 = skipDateTimeField12.isLeap((long) 10);
        int int18 = skipDateTimeField12.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 7 + "'", int14 == 7);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "centuryOfEra" + "'", str15.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-2922686) + "'", int18 == (-2922686));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField12.getMaximumShortTextLength(locale13);
        java.lang.String str15 = skipDateTimeField12.getName();
        long long17 = skipDateTimeField12.roundHalfEven(0L);
        java.lang.String str18 = skipDateTimeField12.getName();
        long long21 = skipDateTimeField12.set((long) 3500, 7);
        long long23 = skipDateTimeField12.roundHalfFloor((long) 32);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 7 + "'", int14 == 7);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "centuryOfEra" + "'", str15.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-378662400000L) + "'", long17 == (-378662400000L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "centuryOfEra" + "'", str18.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-56802557218500L) + "'", long21 == (-56802557218500L));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-378662400000L) + "'", long23 == (-378662400000L));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.hourOfDay();
        org.joda.time.DateTime.Property property5 = dateTime2.hourOfDay();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) 15);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone9);
        org.joda.time.DateTime.Property property11 = dateTime10.centuryOfEra();
        org.joda.time.DateTime.Property property12 = dateTime10.hourOfDay();
        org.joda.time.DateTime.Property property13 = dateTime10.hourOfDay();
        org.joda.time.DateTime dateTime15 = property13.addToCopy((long) 15);
        org.joda.time.DateTime dateTime17 = dateTime15.plusSeconds(69);
        long long18 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTime dateTime20 = property5.addWrapFieldToCopy((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone22);
        org.joda.time.DateTime.Property property24 = dateTime23.centuryOfEra();
        org.joda.time.DateTime.Property property25 = dateTime23.hourOfDay();
        org.joda.time.DateTime.Property property26 = dateTime23.hourOfDay();
        org.joda.time.DateTime dateTime28 = property26.addToCopy((long) 15);
        boolean boolean29 = dateTime20.isAfter((org.joda.time.ReadableInstant) dateTime28);
        org.joda.time.DateTime dateTime31 = dateTime28.minusHours(31);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-15L) + "'", long18 == (-15L));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTime31);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.hourOfDay();
        org.joda.time.DateTime.Property property5 = dateTime2.hourOfDay();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) 15);
        org.joda.time.DateTime dateTime9 = dateTime7.plusSeconds(69);
        org.joda.time.DateTime dateTime11 = dateTime7.withMonthOfYear((int) (short) 10);
        java.util.Date date12 = dateTime7.toDate();
        org.joda.time.Chronology chronology13 = dateTime7.getChronology();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "CopticChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(dateTimeZone0);
//        int int2 = monthDay1.getMonthOfYear();
//        java.lang.String str3 = monthDay1.toString();
//        int[] intArray4 = monthDay1.getValues();
//        org.joda.time.MonthDay.Property property5 = monthDay1.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = property5.getAsText(locale7);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone10);
//        org.joda.time.DateTime.Property property12 = dateTime11.centuryOfEra();
//        org.joda.time.DateTime dateTime14 = property12.addToCopy(0);
//        java.lang.String str15 = property12.getAsString();
//        org.joda.time.DateTime dateTime17 = property12.setCopy(959);
//        org.joda.time.DurationField durationField18 = property12.getDurationField();
//        boolean boolean19 = property5.equals((java.lang.Object) durationField18);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "--06-15" + "'", str3.equals("--06-15"));
//        org.junit.Assert.assertNotNull(intArray4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "15" + "'", str8.equals("15"));
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "19" + "'", str15.equals("19"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        org.joda.time.DateTime.Property property5 = dateTime3.hourOfDay();
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime(chronology6);
        boolean boolean8 = julianChronology0.equals((java.lang.Object) dateTime3);
        try {
            long long16 = julianChronology0.getDateTimeMillis(32, 7, 100, 10, 132, 2, (-2922685));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 132 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.util.Date date0 = null;
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.fromDateFields(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The date must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test267");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
//        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
//        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
//        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
//        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
//        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
//        java.util.Locale locale13 = null;
//        int int14 = skipDateTimeField12.getMaximumShortTextLength(locale13);
//        java.lang.String str15 = skipDateTimeField12.getName();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField12, 132);
//        long long19 = offsetDateTimeField17.roundCeiling((long) 7);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField17.getType();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(dateTimeZone21);
//        int int23 = monthDay22.getMonthOfYear();
//        java.lang.String str24 = monthDay22.toString();
//        int[] intArray25 = monthDay22.getValues();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
//        boolean boolean27 = monthDay22.isSupported(dateTimeFieldType26);
//        org.joda.time.MonthDay monthDay29 = monthDay22.plusMonths((-1));
//        org.joda.time.MonthDay monthDay32 = new org.joda.time.MonthDay((long) 59);
//        org.joda.time.MonthDay monthDay34 = monthDay32.minusDays(1);
//        int[] intArray35 = monthDay32.getValues();
//        try {
//            int[] intArray37 = offsetDateTimeField17.addWrapField((org.joda.time.ReadablePartial) monthDay22, (-11), intArray35, (-2922685));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -11");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 7 + "'", int14 == 7);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "centuryOfEra" + "'", str15.equals("centuryOfEra"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2777097600000L + "'", long19 == 2777097600000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "--06-15" + "'", str24.equals("--06-15"));
//        org.junit.Assert.assertNotNull(intArray25);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(monthDay29);
//        org.junit.Assert.assertNotNull(monthDay34);
//        org.junit.Assert.assertNotNull(intArray35);
//    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        int int6 = dateTime5.getMillisOfDay();
        java.util.Locale locale8 = null;
        java.lang.String str9 = dateTime5.toString("15", locale8);
        org.joda.time.DateTime dateTime11 = dateTime5.minus((long) 3500);
        org.joda.time.DateTime dateTime13 = dateTime11.withMillisOfDay(25);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.centuryOfEra();
        org.joda.time.DateTime.Property property19 = dateTime17.weekyear();
        boolean boolean20 = iSOChronology14.equals((java.lang.Object) property19);
        org.joda.time.Interval interval21 = property19.toInterval();
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval21);
        org.joda.time.DateTime dateTime23 = dateTime11.toDateTime(chronology22);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57599999 + "'", int6 == 57599999);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "15" + "'", str9.equals("15"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(interval21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 10, 59);
        java.lang.String str4 = dateTimeZone2.getName(0L);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.centuryOfEra();
        org.joda.time.Instant instant9 = new org.joda.time.Instant((java.lang.Object) dateTime7);
        int int10 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) instant9);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Instant instant12 = instant9.minus(readableDuration11);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+10:59" + "'", str4.equals("+10:59"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39540000 + "'", int10 == 39540000);
        org.junit.Assert.assertNotNull(instant12);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = gregorianChronology1.withUTC();
        try {
            long long10 = gregorianChronology1.getDateTimeMillis(69, 2922796, (-11), (-292275054), (int) (byte) 1, (int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275054 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        try {
            long long8 = gJChronology0.getDateTimeMillis((int) (byte) 1, (-11), 31, (-2922686), 0, (int) 'a', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2922686 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime2.plusSeconds((-1));
        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
        org.joda.time.LocalDateTime localDateTime7 = dateTime2.toLocalDateTime();
        org.joda.time.DateTime.Property property8 = dateTime2.secondOfMinute();
        org.joda.time.DateTime.Property property9 = dateTime2.minuteOfDay();
        java.lang.String str10 = property9.getAsText();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "959" + "'", str10.equals("959"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        org.joda.time.DateTime.Property property5 = dateTime3.weekyear();
        boolean boolean6 = iSOChronology0.equals((java.lang.Object) property5);
        org.joda.time.Interval interval7 = property5.toInterval();
        org.joda.time.ReadableInterval readableInterval8 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval7);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(interval7);
        org.junit.Assert.assertNotNull(readableInterval8);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-1));
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(dateTimeZone3);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Jun 15, ���� �:��:�� �", (java.lang.Number) (byte) 10, number2, (java.lang.Number) 23);
        java.lang.Number number7 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("Jun 15, ���� �:��:�� �", (java.lang.Number) (byte) 10, number7, (java.lang.Number) 23);
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException9);
        org.joda.time.DurationFieldType durationFieldType11 = illegalFieldValueException9.getDurationFieldType();
        org.junit.Assert.assertNull(durationFieldType11);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("T16:00:00.100-08:00", 3500, (-292275054), 187200000, 'a', (int) (short) 1, 1, 187200000, false, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        int int6 = dateTime5.getMillisOfDay();
        int int7 = dateTime5.getMinuteOfDay();
        org.joda.time.DateTime.Property property8 = dateTime5.dayOfWeek();
        org.joda.time.DurationField durationField9 = property8.getDurationField();
        org.joda.time.DurationField durationField10 = property8.getRangeDurationField();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57599999 + "'", int6 == 57599999);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 959 + "'", int7 == 959);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneOffset("Jun 15, ���� �:��:�� �", "hi!", false, 6, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendFractionOfHour(7, 59);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendDayOfYear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
//        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
//        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
//        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
//        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
//        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
//        long long15 = skipDateTimeField12.addWrapField((long) 7, 7);
//        long long18 = skipDateTimeField12.set((long) 'a', 23);
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay(dateTimeZone19);
//        int int21 = monthDay20.getMonthOfYear();
//        java.lang.String str22 = monthDay20.toString();
//        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((long) 59);
//        org.joda.time.MonthDay monthDay26 = monthDay24.minusDays(1);
//        int[] intArray27 = monthDay24.getValues();
//        int int28 = skipDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) monthDay20, intArray27);
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = skipDateTimeField12.getAsShortText((long) 6, locale30);
//        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.lang.String str35 = dateTimeFormatter33.print((long) (short) 100);
//        boolean boolean36 = iSOChronology32.equals((java.lang.Object) dateTimeFormatter33);
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology38 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone37);
//        org.joda.time.Chronology chronology39 = buddhistChronology38.withUTC();
//        org.joda.time.DateTimeField dateTimeField40 = buddhistChronology38.secondOfDay();
//        org.joda.time.DurationField durationField41 = buddhistChronology38.millis();
//        org.joda.time.DateTimeField dateTimeField42 = buddhistChronology38.centuryOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField44 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology32, dateTimeField42, (int) (short) 100);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField45 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField42);
//        long long47 = delegatedDateTimeField45.roundFloor((long) 30);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter48 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter50 = dateTimeFormatter48.withPivotYear((java.lang.Integer) 10);
//        boolean boolean51 = dateTimeFormatter48.isOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.MonthDay monthDay53 = new org.joda.time.MonthDay(dateTimeZone52);
//        java.lang.String str54 = dateTimeFormatter48.print((org.joda.time.ReadablePartial) monthDay53);
//        org.joda.time.DateTimeZone dateTimeZone56 = null;
//        org.joda.time.MonthDay monthDay57 = new org.joda.time.MonthDay(dateTimeZone56);
//        int int58 = monthDay57.getMonthOfYear();
//        java.lang.String str59 = monthDay57.toString();
//        int[] intArray60 = monthDay57.getValues();
//        int[] intArray62 = delegatedDateTimeField45.addWrapField((org.joda.time.ReadablePartial) monthDay53, (int) (byte) 1, intArray60, (int) (short) 10);
//        int int63 = monthDay53.getDayOfMonth();
//        java.util.Locale locale64 = null;
//        try {
//            java.lang.String str65 = skipDateTimeField12.getAsText((org.joda.time.ReadablePartial) monthDay53, locale64);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'centuryOfEra' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 22089888000007L + "'", long15 == 22089888000007L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-6311347621903L) + "'", long18 == (-6311347621903L));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "--06-15" + "'", str22.equals("--06-15"));
//        org.junit.Assert.assertNotNull(monthDay26);
//        org.junit.Assert.assertNotNull(intArray27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-2922685) + "'", int28 == (-2922685));
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "26" + "'", str31.equals("26"));
//        org.junit.Assert.assertNotNull(iSOChronology32);
//        org.junit.Assert.assertNotNull(dateTimeFormatter33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "T16:00:00.100-08:00" + "'", str35.equals("T16:00:00.100-08:00"));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology38);
//        org.junit.Assert.assertNotNull(chronology39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-378662400000L) + "'", long47 == (-378662400000L));
//        org.junit.Assert.assertNotNull(dateTimeFormatter48);
//        org.junit.Assert.assertNotNull(dateTimeFormatter50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Jun 15, ���� �:��:�� �" + "'", str54.equals("Jun 15, ���� �:��:�� �"));
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 6 + "'", int58 == 6);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "--06-15" + "'", str59.equals("--06-15"));
//        org.junit.Assert.assertNotNull(intArray60);
//        org.junit.Assert.assertNotNull(intArray62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 15 + "'", int63 == 15);
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("19");
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, (int) (short) 10);
        org.joda.time.Instant instant6 = instant1.plus(11L);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant9 = instant1.withDurationAdded(readableDuration7, 10);
        org.joda.time.DateTime dateTime10 = instant9.toDateTime();
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(59, (int) (byte) 100, 0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 58 + "'", int4 == 58);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Jun 15, ���� �:��:�� �", (java.lang.Number) (byte) 10, number2, (java.lang.Number) 23);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.lang.String str2 = dateTimeZone1.toString();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (byte) -1, 1);
        try {
            long long10 = gJChronology5.getDateTimeMillis((int) (short) 1, 0, (-1), 30);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(gJChronology5);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
        org.joda.time.DateTime dateTime10 = dateTime7.plusYears(59);
        org.joda.time.DateTime dateTime12 = dateTime7.plusDays((int) '#');
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str16 = dateTimeFormatter14.print((long) (short) 100);
        boolean boolean17 = iSOChronology13.equals((java.lang.Object) dateTimeFormatter14);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone18);
        org.joda.time.Chronology chronology20 = buddhistChronology19.withUTC();
        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology19.secondOfDay();
        org.joda.time.DurationField durationField22 = buddhistChronology19.millis();
        org.joda.time.DateTimeField dateTimeField23 = buddhistChronology19.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology13, dateTimeField23, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField23);
        int int27 = dateTime12.get(dateTimeField23);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "T16:00:00.100-08:00" + "'", str16.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 26 + "'", int27 == 26);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("Property[dayOfMonth]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[dayOfMonth]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTwoDigitYear((-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendDayOfYear(6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.tz.DefaultNameProvider defaultNameProvider5 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale6 = null;
        java.lang.String str9 = defaultNameProvider5.getShortName(locale6, "15", "19");
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) defaultNameProvider5);
        java.util.Locale locale11 = null;
        java.lang.String str14 = defaultNameProvider5.getShortName(locale11, "+100:00", "monthOfYear");
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(str14);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(dateTimeZone0);
//        int int2 = monthDay1.getMonthOfYear();
//        java.lang.String str3 = monthDay1.toString();
//        int[] intArray4 = monthDay1.getValues();
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        boolean boolean6 = monthDay1.isSupported(dateTimeFieldType5);
//        org.joda.time.MonthDay monthDay8 = monthDay1.plusMonths((-1));
//        try {
//            org.joda.time.DateTimeFieldType dateTimeFieldType10 = monthDay8.getFieldType(12);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 12");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "--06-15" + "'", str3.equals("--06-15"));
//        org.junit.Assert.assertNotNull(intArray4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(monthDay8);
//    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test294");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(dateTimeZone0);
//        int int2 = monthDay1.getMonthOfYear();
//        java.lang.String str3 = monthDay1.toString();
//        int[] intArray4 = monthDay1.getValues();
//        org.joda.time.MonthDay.Property property5 = monthDay1.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
//        int int7 = property5.getMaximumValue();
//        java.lang.String str8 = property5.getName();
//        int int9 = property5.getMaximumValueOverall();
//        try {
//            org.joda.time.MonthDay monthDay11 = property5.setCopy(131);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 131 for dayOfMonth must be in the range [1,30]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "--06-15" + "'", str3.equals("--06-15"));
//        org.junit.Assert.assertNotNull(intArray4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 30 + "'", int7 == 30);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "dayOfMonth" + "'", str8.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 31 + "'", int9 == 31);
//    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("T16:00:00.100-08:00", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"T16:00:00.100-08:00/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(dateTimeZone0);
//        int int2 = monthDay1.getMonthOfYear();
//        java.lang.String str3 = monthDay1.toString();
//        int[] intArray4 = monthDay1.getValues();
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        boolean boolean6 = monthDay1.isSupported(dateTimeFieldType5);
//        org.joda.time.MonthDay monthDay8 = monthDay1.plusMonths((-1));
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone10);
//        org.joda.time.DateTime.Property property12 = dateTime11.centuryOfEra();
//        org.joda.time.DateTime dateTime14 = property12.addToCopy(0);
//        org.joda.time.ReadableDuration readableDuration15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime14.minus(readableDuration15);
//        int int17 = dateTime14.getSecondOfMinute();
//        org.joda.time.DateTime.Property property18 = dateTime14.monthOfYear();
//        org.joda.time.DateTime dateTime19 = monthDay1.toDateTime((org.joda.time.ReadableInstant) dateTime14);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "--06-15" + "'", str3.equals("--06-15"));
//        org.junit.Assert.assertNotNull(intArray4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 59 + "'", int17 == 59);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        org.joda.time.LocalTime localTime8 = dateTime7.toLocalTime();
        org.joda.time.DateTime dateTime10 = dateTime7.minusDays((int) '4');
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.minus(readablePeriod11);
        int int13 = dateTime10.getSecondOfDay();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 57599 + "'", int13 == 57599);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (-2922685));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -2922685");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
        org.joda.time.DateTime dateTime10 = dateTime7.plusYears(59);
        org.joda.time.DateTime dateTime12 = dateTime7.plusDays((int) '#');
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone14);
        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
        org.joda.time.DateTime dateTime18 = property16.addToCopy(0);
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.minus(readableDuration19);
        org.joda.time.LocalTime localTime21 = dateTime20.toLocalTime();
        org.joda.time.DateTime dateTime23 = dateTime20.minusDays((int) '4');
        boolean boolean24 = dateTime12.isEqual((org.joda.time.ReadableInstant) dateTime23);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology3 = copticChronology0.withZone(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str7 = dateTimeFormatter5.print((long) (short) 100);
        boolean boolean8 = iSOChronology4.equals((java.lang.Object) dateTimeFormatter5);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
        org.joda.time.Chronology chronology11 = buddhistChronology10.withUTC();
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology10.secondOfDay();
        org.joda.time.DurationField durationField13 = buddhistChronology10.millis();
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology10.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology4, dateTimeField14, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField17 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        org.joda.time.DurationField durationField18 = delegatedDateTimeField17.getLeapDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField19 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField17);
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str23 = dateTimeFormatter21.print((long) (short) 100);
        boolean boolean24 = iSOChronology20.equals((java.lang.Object) dateTimeFormatter21);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone25);
        org.joda.time.Chronology chronology27 = buddhistChronology26.withUTC();
        org.joda.time.DateTimeField dateTimeField28 = buddhistChronology26.secondOfDay();
        org.joda.time.DurationField durationField29 = buddhistChronology26.millis();
        org.joda.time.DateTimeField dateTimeField30 = buddhistChronology26.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology20, dateTimeField30, (int) (short) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField17, dateTimeFieldType33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "T16:00:00.100-08:00" + "'", str7.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "T16:00:00.100-08:00" + "'", str23.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(buddhistChronology26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        try {
            int[] intArray4 = gregorianChronology0.get(readablePeriod1, (long) (-11), (long) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
        org.joda.time.DateTime.Property property8 = dateTime6.weekyear();
        boolean boolean9 = iSOChronology3.equals((java.lang.Object) property8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.weekOfWeekyear();
        int int11 = dateTime2.get(dateTimeField10);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str15 = dateTimeFormatter13.print((long) (short) 100);
        boolean boolean16 = iSOChronology12.equals((java.lang.Object) dateTimeFormatter13);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone17);
        org.joda.time.Chronology chronology19 = buddhistChronology18.withUTC();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology18.secondOfDay();
        org.joda.time.DurationField durationField21 = buddhistChronology18.millis();
        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology18.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology12, dateTimeField22, (int) (short) 100);
        java.util.Locale locale25 = null;
        int int26 = skipDateTimeField24.getMaximumShortTextLength(locale25);
        java.lang.String str27 = skipDateTimeField24.getName();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField24, 132);
        long long31 = offsetDateTimeField29.roundCeiling((long) 7);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField29.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType32, 4);
        long long36 = offsetDateTimeField34.roundHalfEven((long) 10);
        java.lang.String str37 = offsetDateTimeField34.getName();
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "T16:00:00.100-08:00" + "'", str15.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "centuryOfEra" + "'", str27.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2777097600000L + "'", long31 == 2777097600000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-230400000L) + "'", long36 == (-230400000L));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "centuryOfEra" + "'", str37.equals("centuryOfEra"));
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test303");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(dateTimeZone0);
//        int int2 = monthDay1.getMonthOfYear();
//        java.lang.String str3 = monthDay1.toString();
//        int[] intArray4 = monthDay1.getValues();
//        org.joda.time.MonthDay.Property property5 = monthDay1.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
//        int int7 = property5.getMaximumValue();
//        java.lang.String str8 = property5.getName();
//        int int9 = property5.getMaximumValueOverall();
//        org.joda.time.DurationField durationField10 = property5.getDurationField();
//        org.joda.time.MonthDay monthDay12 = property5.addWrapFieldToCopy((int) (short) 1);
//        try {
//            org.joda.time.MonthDay monthDay14 = monthDay12.withMonthOfYear(0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "--06-15" + "'", str3.equals("--06-15"));
//        org.junit.Assert.assertNotNull(intArray4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 30 + "'", int7 == 30);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "dayOfMonth" + "'", str8.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 31 + "'", int9 == 31);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(monthDay12);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipDateTimeField12.getAsText((-230400000L), locale14);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "26" + "'", str15.equals("26"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        org.joda.time.DateMidnight dateMidnight6 = dateTime5.toDateMidnight();
        org.joda.time.DateTime dateTime8 = dateTime5.withDayOfYear((int) 'a');
        org.joda.time.DateTime dateTime10 = dateTime5.withCenturyOfEra(0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test306");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
//        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
//        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
//        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
//        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
//        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
//        long long15 = skipDateTimeField12.addWrapField((long) 7, 7);
//        long long18 = skipDateTimeField12.set((long) 'a', 23);
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay(dateTimeZone19);
//        int int21 = monthDay20.getMonthOfYear();
//        java.lang.String str22 = monthDay20.toString();
//        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((long) 59);
//        org.joda.time.MonthDay monthDay26 = monthDay24.minusDays(1);
//        int[] intArray27 = monthDay24.getValues();
//        int int28 = skipDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) monthDay20, intArray27);
//        int int29 = skipDateTimeField12.getMinimumValue();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 22089888000007L + "'", long15 == 22089888000007L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-6311347621903L) + "'", long18 == (-6311347621903L));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "--06-15" + "'", str22.equals("--06-15"));
//        org.junit.Assert.assertNotNull(monthDay26);
//        org.junit.Assert.assertNotNull(intArray27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-2922685) + "'", int28 == (-2922685));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-2922686) + "'", int29 == (-2922686));
//    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("Property[dayOfMonth]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Property[dayOfMonth]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("00", (java.lang.Number) 57599999, (java.lang.Number) 23, number3);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
//        boolean boolean3 = dateTimeFormatter0.isOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone4);
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
//        org.joda.time.MonthDay.Property property7 = monthDay5.monthOfYear();
//        java.lang.String str8 = property7.getAsShortText();
//        java.lang.String str9 = property7.getName();
//        java.util.Locale locale11 = null;
//        try {
//            org.joda.time.MonthDay monthDay12 = property7.setCopy("GJChronology[America/Los_Angeles]", locale11);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GJChronology[America/Los_Angeles]\" for monthOfYear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Jun 15, ���� �:��:�� �" + "'", str6.equals("Jun 15, ���� �:��:�� �"));
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Jun" + "'", str8.equals("Jun"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "monthOfYear" + "'", str9.equals("monthOfYear"));
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2, 15);
        org.joda.time.DurationField durationField5 = iSOChronology0.hours();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Property[dayOfMonth]", "org.joda.time.IllegalFieldValueException: Value 10 for Jun 15, ���� �:��:�� � must not be larger than 23");
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.minus(readableDuration3);
        org.joda.time.DateTime.Property property5 = dateTime4.weekOfWeekyear();
        boolean boolean6 = dateTime4.isEqualNow();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(1, 6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendMonthOfYearText();
        boolean boolean10 = dateTimeFormatterBuilder9.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((-1), 7, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 23, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) 59);
        org.joda.time.MonthDay monthDay3 = monthDay1.minusMonths(1);
        org.junit.Assert.assertNotNull(monthDay3);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusMinutes(132);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime0.toYearMonthDay();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField13.getLeapDurationField();
        long long17 = delegatedDateTimeField13.addWrapField((long) '#', (int) (short) 1);
        int int18 = delegatedDateTimeField13.getMaximumValue();
        java.lang.String str20 = delegatedDateTimeField13.getAsText((long) ' ');
        try {
            long long23 = delegatedDateTimeField13.add(0L, 1209596400019L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 120959640001900");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 3155760000035L + "'", long17 == 3155760000035L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2922796 + "'", int18 == 2922796);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "26" + "'", str20.equals("26"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "org.joda.time.IllegalFieldValueException: Value 10 for Jun 15, ���� �:��:�� � must not be larger than 23");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTwoDigitYear((-1));
        boolean boolean5 = dateTimeFormatterBuilder2.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test322");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(dateTimeZone0);
//        int int2 = monthDay1.getMonthOfYear();
//        java.lang.String str3 = monthDay1.toString();
//        int[] intArray4 = monthDay1.getValues();
//        org.joda.time.MonthDay.Property property5 = monthDay1.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
//        int int7 = property5.getMaximumValue();
//        java.lang.String str8 = property5.getName();
//        int int9 = property5.getMaximumValueOverall();
//        org.joda.time.DurationField durationField10 = property5.getDurationField();
//        org.joda.time.MonthDay monthDay12 = property5.addWrapFieldToCopy((int) (short) 1);
//        int int13 = property5.get();
//        org.joda.time.Instant instant15 = org.joda.time.Instant.parse("19");
//        org.joda.time.ReadableDuration readableDuration16 = null;
//        org.joda.time.Instant instant18 = instant15.withDurationAdded(readableDuration16, (int) (short) 10);
//        org.joda.time.DateTime dateTime19 = instant18.toDateTime();
//        org.joda.time.DateTimeZone dateTimeZone20 = dateTime19.getZone();
//        int int21 = property5.compareTo((org.joda.time.ReadableInstant) dateTime19);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "--06-15" + "'", str3.equals("--06-15"));
//        org.junit.Assert.assertNotNull(intArray4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 30 + "'", int7 == 30);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "dayOfMonth" + "'", str8.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 31 + "'", int9 == 31);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
//        org.junit.Assert.assertNotNull(instant15);
//        org.junit.Assert.assertNotNull(instant18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readableDuration4);
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfMinute();
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime5, readableInstant7);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone10);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone14);
        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
        org.joda.time.DateTime.Property property17 = dateTime15.weekyear();
        boolean boolean18 = iSOChronology12.equals((java.lang.Object) property17);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.weekOfWeekyear();
        int int20 = dateTime11.get(dateTimeField19);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str24 = dateTimeFormatter22.print((long) (short) 100);
        boolean boolean25 = iSOChronology21.equals((java.lang.Object) dateTimeFormatter22);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology27 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone26);
        org.joda.time.Chronology chronology28 = buddhistChronology27.withUTC();
        org.joda.time.DateTimeField dateTimeField29 = buddhistChronology27.secondOfDay();
        org.joda.time.DurationField durationField30 = buddhistChronology27.millis();
        org.joda.time.DateTimeField dateTimeField31 = buddhistChronology27.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField33 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology21, dateTimeField31, (int) (short) 100);
        java.util.Locale locale34 = null;
        int int35 = skipDateTimeField33.getMaximumShortTextLength(locale34);
        java.lang.String str36 = skipDateTimeField33.getName();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField33, 132);
        long long40 = offsetDateTimeField38.roundCeiling((long) 7);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField38.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, dateTimeFieldType41, 4);
        int int44 = dateTime5.get(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "T16:00:00.100-08:00" + "'", str24.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(buddhistChronology27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 7 + "'", int35 == 7);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "centuryOfEra" + "'", str36.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 2777097600000L + "'", long40 == 2777097600000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 19 + "'", int44 == 19);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        int int10 = cachedDateTimeZone8.getOffset(0L);
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(23, (int) 'a', (int) (byte) 1, 59, 0, 0, (org.joda.time.DateTimeZone) cachedDateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 187200000 + "'", int10 == 187200000);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset(31L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField12.getMaximumShortTextLength(locale13);
        java.lang.String str15 = skipDateTimeField12.getName();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField12, 132);
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField17.getWrappedField();
        try {
            long long21 = offsetDateTimeField17.set((long) 3500, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The resulting instant is below the supported minimum of 0001-01-01T00:00:00.000-07:52:58 (BuddhistChronology[America/Los_Angeles])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 7 + "'", int14 == 7);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "centuryOfEra" + "'", str15.equals("centuryOfEra"));
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        try {
            org.joda.time.LocalDate localDate3 = dateTimeFormatter0.parseLocalDate("America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"America/Los_Angeles\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
        long long15 = skipDateTimeField12.addWrapField((long) 7, 7);
        org.joda.time.DurationField durationField16 = skipDateTimeField12.getLeapDurationField();
        java.util.Locale locale17 = null;
        int int18 = skipDateTimeField12.getMaximumShortTextLength(locale17);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 22089888000007L + "'", long15 == 22089888000007L);
        org.junit.Assert.assertNull(durationField16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 7 + "'", int18 == 7);
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(dateTimeZone0);
//        int int2 = monthDay1.getMonthOfYear();
//        java.lang.String str3 = monthDay1.toString();
//        int[] intArray4 = monthDay1.getValues();
//        org.joda.time.MonthDay.Property property5 = monthDay1.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
//        java.lang.String str7 = property5.getAsText();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "--06-15" + "'", str3.equals("--06-15"));
//        org.junit.Assert.assertNotNull(intArray4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "15" + "'", str7.equals("15"));
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField13.getLeapDurationField();
        long long17 = delegatedDateTimeField13.addWrapField((long) '#', (int) (short) 1);
        org.joda.time.ReadablePartial readablePartial18 = null;
        int int19 = delegatedDateTimeField13.getMaximumValue(readablePartial18);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 3155760000035L + "'", long17 == 3155760000035L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2922796 + "'", int19 == 2922796);
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone5);
//        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
//        org.joda.time.DateTime.Property property8 = dateTime6.weekyear();
//        boolean boolean9 = iSOChronology3.equals((java.lang.Object) property8);
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.weekOfWeekyear();
//        int int11 = dateTime2.get(dateTimeField10);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.lang.String str15 = dateTimeFormatter13.print((long) (short) 100);
//        boolean boolean16 = iSOChronology12.equals((java.lang.Object) dateTimeFormatter13);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone17);
//        org.joda.time.Chronology chronology19 = buddhistChronology18.withUTC();
//        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology18.secondOfDay();
//        org.joda.time.DurationField durationField21 = buddhistChronology18.millis();
//        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology18.centuryOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology12, dateTimeField22, (int) (short) 100);
//        java.util.Locale locale25 = null;
//        int int26 = skipDateTimeField24.getMaximumShortTextLength(locale25);
//        java.lang.String str27 = skipDateTimeField24.getName();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField24, 132);
//        long long31 = offsetDateTimeField29.roundCeiling((long) 7);
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField29.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType32, 4);
//        long long36 = offsetDateTimeField34.roundHalfEven((long) 10);
//        org.joda.time.DurationField durationField37 = offsetDateTimeField34.getLeapDurationField();
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay(dateTimeZone38);
//        int int40 = monthDay39.getMonthOfYear();
//        java.lang.String str41 = monthDay39.toString();
//        int[] intArray42 = monthDay39.getValues();
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = null;
//        boolean boolean44 = monthDay39.isSupported(dateTimeFieldType43);
//        org.joda.time.MonthDay monthDay46 = monthDay39.plusMonths((-1));
//        java.util.Locale locale47 = null;
//        try {
//            java.lang.String str48 = offsetDateTimeField34.getAsText((org.joda.time.ReadablePartial) monthDay39, locale47);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'centuryOfEra' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "T16:00:00.100-08:00" + "'", str15.equals("T16:00:00.100-08:00"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology18);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "centuryOfEra" + "'", str27.equals("centuryOfEra"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2777097600000L + "'", long31 == 2777097600000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-230400000L) + "'", long36 == (-230400000L));
//        org.junit.Assert.assertNull(durationField37);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "--06-15" + "'", str41.equals("--06-15"));
//        org.junit.Assert.assertNotNull(intArray42);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(monthDay46);
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology4 = copticChronology1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone3);
        try {
            long long12 = zonedChronology6.getDateTimeMillis((long) ' ', 2000, 23, 25, 12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(zonedChronology6);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Jun 15, ���� �:��:�� �", (java.lang.Number) (byte) 10, number2, (java.lang.Number) 23);
        java.lang.Number number7 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("Jun 15, ���� �:��:�� �", (java.lang.Number) (byte) 10, number7, (java.lang.Number) 23);
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException9);
        java.lang.String str11 = illegalFieldValueException4.toString();
        java.lang.Number number12 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.Number number15 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException("Jun 15, ���� �:��:�� �", (java.lang.Number) (byte) 10, number15, (java.lang.Number) 23);
        java.lang.Number number20 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException("Jun 15, ���� �:��:�� �", (java.lang.Number) (byte) 10, number20, (java.lang.Number) 23);
        illegalFieldValueException17.addSuppressed((java.lang.Throwable) illegalFieldValueException22);
        java.lang.String str24 = illegalFieldValueException17.toString();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException17);
        java.lang.Number number26 = illegalFieldValueException17.getIllegalNumberValue();
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 10 for Jun 15, ���� �:��:�� � must not be larger than 23" + "'", str11.equals("org.joda.time.IllegalFieldValueException: Value 10 for Jun 15, ���� �:��:�� � must not be larger than 23"));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (byte) 10 + "'", number12.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 10 for Jun 15, ���� �:��:�� � must not be larger than 23" + "'", str24.equals("org.joda.time.IllegalFieldValueException: Value 10 for Jun 15, ���� �:��:�� � must not be larger than 23"));
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + (byte) 10 + "'", number26.equals((byte) 10));
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
//        boolean boolean3 = dateTimeFormatter0.isOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone4);
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
//        try {
//            org.joda.time.MonthDay monthDay8 = monthDay5.withMonthOfYear((-2922686));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2922686 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Jun 15, ���� �:��:�� �" + "'", str6.equals("Jun 15, ���� �:��:�� �"));
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2, 15);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(10);
        java.lang.String str8 = dateTimeZone6.getShortName(3599999L);
        long long10 = dateTimeZone6.convertUTCToLocal(0L);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        java.lang.String str12 = dateTimeZone6.toString();
        org.joda.time.Chronology chronology13 = iSOChronology0.withZone(dateTimeZone6);
        java.lang.String str14 = dateTimeZone6.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+10:00" + "'", str8.equals("+10:00"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 36000000L + "'", long10 == 36000000L);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+10:00" + "'", str12.equals("+10:00"));
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+10:00" + "'", str14.equals("+10:00"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.hourOfDay();
        org.joda.time.DateTime.Property property5 = dateTime2.hourOfDay();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) 15);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone9);
        org.joda.time.DateTime.Property property11 = dateTime10.centuryOfEra();
        org.joda.time.DateTime.Property property12 = dateTime10.hourOfDay();
        org.joda.time.DateTime.Property property13 = dateTime10.hourOfDay();
        org.joda.time.DateTime dateTime15 = property13.addToCopy((long) 15);
        org.joda.time.DateTime dateTime17 = dateTime15.plusSeconds(69);
        long long18 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DurationField durationField19 = property5.getLeapDurationField();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-15L) + "'", long18 == (-15L));
        org.junit.Assert.assertNull(durationField19);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-1));
        try {
            long long4 = dateTimeFormatter0.parseMillis("00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"00\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2, 15);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(10);
        java.lang.String str8 = dateTimeZone6.getShortName(3599999L);
        long long10 = dateTimeZone6.convertUTCToLocal(0L);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        java.lang.String str12 = dateTimeZone6.toString();
        org.joda.time.Chronology chronology13 = iSOChronology0.withZone(dateTimeZone6);
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+10:00" + "'", str8.equals("+10:00"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 36000000L + "'", long10 == 36000000L);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+10:00" + "'", str12.equals("+10:00"));
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(julianChronology14);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 59);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 59 + "'", int1 == 59);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
        long long15 = skipDateTimeField12.addWrapField((long) 7, 7);
        org.joda.time.DurationField durationField16 = skipDateTimeField12.getLeapDurationField();
        int int17 = skipDateTimeField12.getMinimumValue();
        long long19 = skipDateTimeField12.remainder((long) 12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder20.appendTimeZoneOffset("Jun 15, ���� �:��:�� �", "hi!", false, 6, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder28.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder28.appendYear(100, (int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str37 = dateTimeFormatter35.print((long) (short) 100);
        boolean boolean38 = iSOChronology34.equals((java.lang.Object) dateTimeFormatter35);
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone39);
        org.joda.time.Chronology chronology41 = buddhistChronology40.withUTC();
        org.joda.time.DateTimeField dateTimeField42 = buddhistChronology40.secondOfDay();
        org.joda.time.DurationField durationField43 = buddhistChronology40.millis();
        org.joda.time.DateTimeField dateTimeField44 = buddhistChronology40.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField46 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology34, dateTimeField44, (int) (short) 100);
        java.util.Locale locale47 = null;
        int int48 = skipDateTimeField46.getMaximumShortTextLength(locale47);
        java.lang.String str49 = skipDateTimeField46.getName();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField46, 132);
        long long53 = offsetDateTimeField51.roundCeiling((long) 7);
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = offsetDateTimeField51.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder33.appendText(dateTimeFieldType54);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField12, dateTimeFieldType54, 59);
        java.util.Locale locale59 = null;
        java.lang.String str60 = skipDateTimeField12.getAsShortText((long) 4, locale59);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 22089888000007L + "'", long15 == 22089888000007L);
        org.junit.Assert.assertNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-2922686) + "'", int17 == (-2922686));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 12L + "'", long19 == 12L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "T16:00:00.100-08:00" + "'", str37.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(buddhistChronology40);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 7 + "'", int48 == 7);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "centuryOfEra" + "'", str49.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 2777097600000L + "'", long53 == 2777097600000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "26" + "'", str60.equals("26"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("-2922686", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime2.plusSeconds((-1));
        int int6 = dateTime5.getMillisOfSecond();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 999 + "'", int6 == 999);
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
//        boolean boolean3 = dateTimeFormatter0.isOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone4);
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
//        org.joda.time.MonthDay.Property property7 = monthDay5.monthOfYear();
//        int int8 = monthDay5.getDayOfMonth();
//        try {
//            org.joda.time.MonthDay monthDay10 = monthDay5.withDayOfMonth(32);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for dayOfMonth must be in the range [1,30]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Jun 15, ���� �:��:�� �" + "'", str6.equals("Jun 15, ���� �:��:�� �"));
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.minutes();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
//        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        java.util.TimeZone timeZone9 = dateTimeZone8.toTimeZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
//        java.lang.String str12 = dateTimeZone8.getName((long) (short) -1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Pacific Standard Time" + "'", str12.equals("Pacific Standard Time"));
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneOffset("Jun 15, ���� �:��:�� �", "hi!", false, 6, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral('a');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap9 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendTimeZoneName(strMap9);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendMillisOfDay((-11));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
        long long15 = skipDateTimeField12.addWrapField((long) 7, 7);
        org.joda.time.DurationField durationField16 = skipDateTimeField12.getLeapDurationField();
        int int17 = skipDateTimeField12.getMinimumValue();
        java.util.Locale locale18 = null;
        int int19 = skipDateTimeField12.getMaximumTextLength(locale18);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 22089888000007L + "'", long15 == 22089888000007L);
        org.junit.Assert.assertNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-2922686) + "'", int17 == (-2922686));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 7 + "'", int19 == 7);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(10);
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, dateTimeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("00");
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        boolean boolean3 = dateTimeFormatter2.isOffsetParsed();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readableDuration4);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.centuryOfEra();
        org.joda.time.DateTime dateTime11 = property9.addToCopy(0);
        int int12 = dateTime11.getMillisOfDay();
        boolean boolean13 = dateTime11.isBeforeNow();
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime3, (org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime.Property property15 = dateTime3.dayOfWeek();
        org.joda.time.DateTime dateTime16 = property15.roundFloorCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 57599999 + "'", int12 == 57599999);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneOffset("Jun 15, ���� �:��:�� �", "hi!", false, 6, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendMillisOfSecond(0);
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatterBuilder11.toParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusMinutes(132);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str6 = dateTimeFormatter4.print((long) (short) 100);
        boolean boolean7 = iSOChronology3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
        org.joda.time.Chronology chronology10 = buddhistChronology9.withUTC();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology9.secondOfDay();
        org.joda.time.DurationField durationField12 = buddhistChronology9.millis();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology9.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField13, (int) (short) 100);
        java.util.Locale locale16 = null;
        int int17 = skipDateTimeField15.getMaximumShortTextLength(locale16);
        java.lang.String str18 = skipDateTimeField15.getName();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField15, 132);
        long long22 = offsetDateTimeField20.roundCeiling((long) 7);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField20.getType();
        boolean boolean24 = dateTime0.isSupported(dateTimeFieldType23);
        try {
            org.joda.time.DateTime dateTime26 = dateTime0.withDayOfYear((-292275054));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275054 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "T16:00:00.100-08:00" + "'", str6.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 7 + "'", int17 == 7);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "centuryOfEra" + "'", str18.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2777097600000L + "'", long22 == 2777097600000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
//        boolean boolean3 = dateTimeFormatter0.isOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone4);
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
//        org.joda.time.MonthDay.Property property7 = monthDay5.monthOfYear();
//        java.lang.String str8 = property7.getAsShortText();
//        java.lang.String str9 = property7.getName();
//        java.lang.String str10 = property7.getAsString();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Jun 15, ���� �:��:�� �" + "'", str6.equals("Jun 15, ���� �:��:�� �"));
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Jun" + "'", str8.equals("Jun"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "monthOfYear" + "'", str9.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6" + "'", str10.equals("6"));
//    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneOffset("Jun 15, ���� �:��:�� �", "hi!", false, 6, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendYear(100, (int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str17 = dateTimeFormatter15.print((long) (short) 100);
        boolean boolean18 = iSOChronology14.equals((java.lang.Object) dateTimeFormatter15);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone19);
        org.joda.time.Chronology chronology21 = buddhistChronology20.withUTC();
        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology20.secondOfDay();
        org.joda.time.DurationField durationField23 = buddhistChronology20.millis();
        org.joda.time.DateTimeField dateTimeField24 = buddhistChronology20.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology14, dateTimeField24, (int) (short) 100);
        java.util.Locale locale27 = null;
        int int28 = skipDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str29 = skipDateTimeField26.getName();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField26, 132);
        long long33 = offsetDateTimeField31.roundCeiling((long) 7);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = offsetDateTimeField31.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType34);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder13.appendSecondOfDay((-2922554));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "T16:00:00.100-08:00" + "'", str17.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 7 + "'", int28 == 7);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "centuryOfEra" + "'", str29.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2777097600000L + "'", long33 == 2777097600000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneOffset("Jun 15, ���� �:��:�� �", "hi!", false, 6, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendClockhourOfDay(187200000);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 132, 3);
        int int6 = fixedDateTimeZone4.getStandardOffset((long) '4');
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("15", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"15\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
        org.joda.time.DateTime dateTime10 = dateTime7.plusYears(59);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendClockhourOfHalfday((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendFractionOfDay(57599999, 59);
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime23 = dateTime21.minusMinutes(132);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str27 = dateTimeFormatter25.print((long) (short) 100);
        boolean boolean28 = iSOChronology24.equals((java.lang.Object) dateTimeFormatter25);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone29);
        org.joda.time.Chronology chronology31 = buddhistChronology30.withUTC();
        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology30.secondOfDay();
        org.joda.time.DurationField durationField33 = buddhistChronology30.millis();
        org.joda.time.DateTimeField dateTimeField34 = buddhistChronology30.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology24, dateTimeField34, (int) (short) 100);
        java.util.Locale locale37 = null;
        int int38 = skipDateTimeField36.getMaximumShortTextLength(locale37);
        java.lang.String str39 = skipDateTimeField36.getName();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField36, 132);
        long long43 = offsetDateTimeField41.roundCeiling((long) 7);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = offsetDateTimeField41.getType();
        boolean boolean45 = dateTime21.isSupported(dateTimeFieldType44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder20.appendShortText(dateTimeFieldType44);
        try {
            org.joda.time.DateTime dateTime48 = dateTime10.withField(dateTimeFieldType44, (-2922686));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2922686 for centuryOfEra must be in the range [0,2922789]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "T16:00:00.100-08:00" + "'", str27.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(buddhistChronology30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 7 + "'", int38 == 7);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "centuryOfEra" + "'", str39.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 2777097600000L + "'", long43 == 2777097600000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        boolean boolean2 = dateTimeFormatter0.isPrinter();
        try {
            org.joda.time.LocalTime localTime4 = dateTimeFormatter0.parseLocalTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField3, 15);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(10);
        java.lang.String str9 = dateTimeZone7.getShortName(3599999L);
        long long11 = dateTimeZone7.convertUTCToLocal(0L);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        java.lang.String str13 = dateTimeZone7.toString();
        org.joda.time.Chronology chronology14 = iSOChronology1.withZone(dateTimeZone7);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 2922928, (org.joda.time.Chronology) iSOChronology1);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+10:00" + "'", str9.equals("+10:00"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 36000000L + "'", long11 == 36000000L);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+10:00" + "'", str13.equals("+10:00"));
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 36000000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 36000000 + "'", int1 == 36000000);
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(dateTimeZone0);
//        int int2 = monthDay1.getMonthOfYear();
//        java.lang.String str3 = monthDay1.toString();
//        int[] intArray4 = monthDay1.getValues();
//        org.joda.time.MonthDay.Property property5 = monthDay1.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = property5.getAsText(locale7);
//        java.lang.String str9 = property5.getAsString();
//        try {
//            org.joda.time.MonthDay monthDay11 = property5.setCopy(187200000);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 187200000 for dayOfMonth must be in the range [1,30]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "--06-15" + "'", str3.equals("--06-15"));
//        org.junit.Assert.assertNotNull(intArray4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "15" + "'", str8.equals("15"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "15" + "'", str9.equals("15"));
//    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.hourOfDay();
        org.joda.time.DateTime.Property property5 = dateTime2.hourOfDay();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) 15);
        org.joda.time.DateTime dateTime9 = dateTime7.plusSeconds(69);
        org.joda.time.DateTime dateTime11 = dateTime7.withMinuteOfHour((int) (byte) 1);
        try {
            org.joda.time.DateTime dateTime13 = dateTime11.withDayOfYear(3500);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3500 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone9);
        org.joda.time.DateTime.Property property11 = dateTime10.centuryOfEra();
        org.joda.time.DateTime dateTime13 = property11.addToCopy(0);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.minus(readableDuration14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.Chronology chronology18 = gregorianChronology7.withZone(dateTimeZone16);
        try {
            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(187200000, 57599999, 0, 999, 0, 2000, dateTimeZone16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 999 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(chronology18);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(1, 6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendTwoDigitWeekyear((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendTwoDigitWeekyear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder8.appendLiteral("ZonedChronology[BuddhistChronology[UTC], -01:00]");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.centuryOfEra();
        org.joda.time.DateTime.Property property9 = dateTime7.weekyear();
        boolean boolean10 = iSOChronology4.equals((java.lang.Object) property9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology4.weekOfWeekyear();
        int int12 = dateTime3.get(dateTimeField11);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str16 = dateTimeFormatter14.print((long) (short) 100);
        boolean boolean17 = iSOChronology13.equals((java.lang.Object) dateTimeFormatter14);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone18);
        org.joda.time.Chronology chronology20 = buddhistChronology19.withUTC();
        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology19.secondOfDay();
        org.joda.time.DurationField durationField22 = buddhistChronology19.millis();
        org.joda.time.DateTimeField dateTimeField23 = buddhistChronology19.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology13, dateTimeField23, (int) (short) 100);
        java.util.Locale locale26 = null;
        int int27 = skipDateTimeField25.getMaximumShortTextLength(locale26);
        java.lang.String str28 = skipDateTimeField25.getName();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField25, 132);
        long long32 = offsetDateTimeField30.roundCeiling((long) 7);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField30.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType33, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField37 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "T16:00:00.100-08:00" + "'", str16.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 7 + "'", int27 == 7);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "centuryOfEra" + "'", str28.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2777097600000L + "'", long32 == 2777097600000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneOffset("Jun 15, ���� �:��:�� �", "hi!", false, 6, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendMillisOfSecond(1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        java.lang.String str1 = copticChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.Chronology chronology5 = copticChronology0.withZone(dateTimeZone4);
        org.joda.time.DurationField durationField6 = copticChronology0.eras();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        boolean boolean10 = copticChronology0.equals((java.lang.Object) cachedDateTimeZone9);
        long long12 = cachedDateTimeZone9.nextTransition((long) (-2922686));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str1.equals("CopticChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2922686L) + "'", long12 == (-2922686L));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology3 = copticChronology0.withZone(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str7 = dateTimeFormatter5.print((long) (short) 100);
        boolean boolean8 = iSOChronology4.equals((java.lang.Object) dateTimeFormatter5);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
        org.joda.time.Chronology chronology11 = buddhistChronology10.withUTC();
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology10.secondOfDay();
        org.joda.time.DurationField durationField13 = buddhistChronology10.millis();
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology10.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology4, dateTimeField14, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField17 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        org.joda.time.DurationField durationField18 = delegatedDateTimeField17.getLeapDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField19 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField17);
        org.joda.time.Chronology chronology20 = copticChronology0.withUTC();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "T16:00:00.100-08:00" + "'", str7.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(chronology20);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        java.lang.String str1 = copticChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.Chronology chronology5 = copticChronology0.withZone(dateTimeZone4);
        org.joda.time.DurationField durationField6 = copticChronology0.eras();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        boolean boolean10 = copticChronology0.equals((java.lang.Object) cachedDateTimeZone9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        try {
            int[] intArray14 = copticChronology0.get(readablePeriod11, (long) 36000000, 2923000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str1.equals("CopticChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneOffset("Jun 15, ���� �:��:�� �", "hi!", false, 6, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendHourOfDay(15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendYear(1, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendFractionOfDay(0, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder16.appendTwoDigitYear(39540000, true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendDayOfWeek(19);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendTimeZoneOffset("T16:00:00.100-08:00", true, 3500, (-2922685));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology3 = copticChronology0.withZone(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str7 = dateTimeFormatter5.print((long) (short) 100);
        boolean boolean8 = iSOChronology4.equals((java.lang.Object) dateTimeFormatter5);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
        org.joda.time.Chronology chronology11 = buddhistChronology10.withUTC();
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology10.secondOfDay();
        org.joda.time.DurationField durationField13 = buddhistChronology10.millis();
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology10.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology4, dateTimeField14, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField17 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        org.joda.time.DurationField durationField18 = delegatedDateTimeField17.getLeapDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField19 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField17);
        org.joda.time.DurationField durationField20 = copticChronology0.hours();
        org.joda.time.DateTimeField dateTimeField21 = copticChronology0.monthOfYear();
        org.joda.time.Chronology chronology22 = copticChronology0.withUTC();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "T16:00:00.100-08:00" + "'", str7.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology22);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("--06-15");
        int int2 = dateTimeFormatter1.getDefaultYear();
        org.joda.time.Chronology chronology3 = dateTimeFormatter1.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000 + "'", int2 == 2000);
        org.junit.Assert.assertNull(chronology3);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        org.joda.time.LocalTime localTime8 = dateTime7.toLocalTime();
        org.joda.time.DateTime dateTime10 = dateTime7.minusDays((int) '4');
        boolean boolean12 = dateTime7.isAfter((long) '4');
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
        org.joda.time.Chronology chronology15 = gregorianChronology14.withUTC();
        org.joda.time.DateTime dateTime16 = dateTime7.toDateTime((org.joda.time.Chronology) gregorianChronology14);
        try {
            long long24 = gregorianChronology14.getDateTimeMillis(12, (-292275054), (int) ' ', 132, 59, 12, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 132 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
//        boolean boolean3 = dateTimeFormatter0.isOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone4);
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
//        org.joda.time.MonthDay.Property property7 = monthDay5.monthOfYear();
//        int int8 = property7.getMinimumValue();
//        org.joda.time.MonthDay monthDay10 = property7.setCopy("Jun");
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Jun 15, ���� �:��:�� �" + "'", str6.equals("Jun 15, ���� �:��:�� �"));
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(monthDay10);
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        java.lang.String str1 = copticChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.Chronology chronology5 = copticChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology5);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str1.equals("CopticChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime5.centuryOfEra();
        org.joda.time.DateTime dateTime8 = property6.addToCopy(0);
        org.joda.time.DateMidnight dateMidnight9 = dateTime8.toDateMidnight();
        java.lang.Class<?> wildcardClass10 = dateTime8.getClass();
        org.joda.time.DateTime dateTime12 = dateTime8.plusMillis(25);
        try {
            java.lang.String str13 = dateTimeFormatter2.print((org.joda.time.ReadableInstant) dateTime8);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.tz.DefaultNameProvider defaultNameProvider5 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale6 = null;
        java.lang.String str9 = defaultNameProvider5.getShortName(locale6, "15", "19");
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) defaultNameProvider5);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((long) 59);
        org.joda.time.MonthDay monthDay14 = monthDay12.minusDays(1);
        boolean boolean15 = iSOChronology0.equals((java.lang.Object) monthDay12);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.lang.String str4 = dateTimeFormatter0.print((long) 19);
        java.lang.Integer int5 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "00" + "'", str4.equals("00"));
        org.junit.Assert.assertNull(int5);
    }

//    @Test
//    public void test389() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test389");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
//        java.lang.String str3 = dateTimeZone1.getShortName(3599999L);
//        long long5 = dateTimeZone1.convertUTCToLocal(0L);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        java.lang.String str7 = dateTimeZone1.toString();
//        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.lang.String str12 = dateTimeFormatter10.print((long) (short) 100);
//        boolean boolean13 = iSOChronology9.equals((java.lang.Object) dateTimeFormatter10);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone14);
//        org.joda.time.Chronology chronology16 = buddhistChronology15.withUTC();
//        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology15.secondOfDay();
//        org.joda.time.DurationField durationField18 = buddhistChronology15.millis();
//        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology15.centuryOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField21 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology9, dateTimeField19, (int) (short) 100);
//        boolean boolean22 = skipDateTimeField21.isSupported();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology8, (org.joda.time.DateTimeField) skipDateTimeField21, 31);
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone28);
//        org.joda.time.Chronology chronology30 = buddhistChronology29.withUTC();
//        org.joda.time.DateTimeField dateTimeField31 = buddhistChronology29.secondOfDay();
//        org.joda.time.DurationField durationField32 = buddhistChronology29.millis();
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology29);
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((-1L), (org.joda.time.Chronology) buddhistChronology29);
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone37 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone36);
//        int int39 = cachedDateTimeZone37.getOffset(0L);
//        org.joda.time.Chronology chronology40 = buddhistChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone37);
//        org.joda.time.MonthDay monthDay41 = new org.joda.time.MonthDay(2777097600000L, (org.joda.time.Chronology) buddhistChronology29);
//        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.lang.String str45 = dateTimeFormatter43.print((long) (short) 100);
//        boolean boolean46 = iSOChronology42.equals((java.lang.Object) dateTimeFormatter43);
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology48 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone47);
//        org.joda.time.Chronology chronology49 = buddhistChronology48.withUTC();
//        org.joda.time.DateTimeField dateTimeField50 = buddhistChronology48.secondOfDay();
//        org.joda.time.DurationField durationField51 = buddhistChronology48.millis();
//        org.joda.time.DateTimeField dateTimeField52 = buddhistChronology48.centuryOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField54 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology42, dateTimeField52, (int) (short) 100);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField55 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField52);
//        long long57 = delegatedDateTimeField55.roundFloor((long) 30);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter58 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter60 = dateTimeFormatter58.withPivotYear((java.lang.Integer) 10);
//        boolean boolean61 = dateTimeFormatter58.isOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone62 = null;
//        org.joda.time.MonthDay monthDay63 = new org.joda.time.MonthDay(dateTimeZone62);
//        java.lang.String str64 = dateTimeFormatter58.print((org.joda.time.ReadablePartial) monthDay63);
//        org.joda.time.DateTimeZone dateTimeZone66 = null;
//        org.joda.time.MonthDay monthDay67 = new org.joda.time.MonthDay(dateTimeZone66);
//        int int68 = monthDay67.getMonthOfYear();
//        java.lang.String str69 = monthDay67.toString();
//        int[] intArray70 = monthDay67.getValues();
//        int[] intArray72 = delegatedDateTimeField55.addWrapField((org.joda.time.ReadablePartial) monthDay63, (int) (byte) 1, intArray70, (int) (short) 10);
//        iSOChronology25.validate((org.joda.time.ReadablePartial) monthDay41, intArray72);
//        java.util.Locale locale75 = null;
//        java.lang.String str76 = skipDateTimeField24.getAsText((org.joda.time.ReadablePartial) monthDay41, (-1), locale75);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+10:00" + "'", str3.equals("+10:00"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 36000000L + "'", long5 == 36000000L);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+10:00" + "'", str7.equals("+10:00"));
//        org.junit.Assert.assertNotNull(copticChronology8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "T16:00:00.100-08:00" + "'", str12.equals("T16:00:00.100-08:00"));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(buddhistChronology29);
//        org.junit.Assert.assertNotNull(chronology30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone37);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 187200000 + "'", int39 == 187200000);
//        org.junit.Assert.assertNotNull(chronology40);
//        org.junit.Assert.assertNotNull(iSOChronology42);
//        org.junit.Assert.assertNotNull(dateTimeFormatter43);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "T16:00:00.100-08:00" + "'", str45.equals("T16:00:00.100-08:00"));
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology48);
//        org.junit.Assert.assertNotNull(chronology49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertNotNull(durationField51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-378662400000L) + "'", long57 == (-378662400000L));
//        org.junit.Assert.assertNotNull(dateTimeFormatter58);
//        org.junit.Assert.assertNotNull(dateTimeFormatter60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "Jun 15, ���� �:��:�� �" + "'", str64.equals("Jun 15, ���� �:��:�� �"));
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 6 + "'", int68 == 6);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "--06-15" + "'", str69.equals("--06-15"));
//        org.junit.Assert.assertNotNull(intArray70);
//        org.junit.Assert.assertNotNull(intArray72);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "-1" + "'", str76.equals("-1"));
//    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.OutputStream outputStream2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("America/Los_Angeles", outputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("6");
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendDayOfWeek(19);
        dateTimeFormatterBuilder4.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendMinuteOfDay((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendClockhourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder10.appendTimeZoneOffset("Jun 15, ���� �:��:�� �", "hi!", false, 6, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder18.appendYear(100, (int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str27 = dateTimeFormatter25.print((long) (short) 100);
        boolean boolean28 = iSOChronology24.equals((java.lang.Object) dateTimeFormatter25);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone29);
        org.joda.time.Chronology chronology31 = buddhistChronology30.withUTC();
        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology30.secondOfDay();
        org.joda.time.DurationField durationField33 = buddhistChronology30.millis();
        org.joda.time.DateTimeField dateTimeField34 = buddhistChronology30.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology24, dateTimeField34, (int) (short) 100);
        java.util.Locale locale37 = null;
        int int38 = skipDateTimeField36.getMaximumShortTextLength(locale37);
        java.lang.String str39 = skipDateTimeField36.getName();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField36, 132);
        long long43 = offsetDateTimeField41.roundCeiling((long) 7);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = offsetDateTimeField41.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder23.appendText(dateTimeFieldType44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder9.appendSignedDecimal(dateTimeFieldType44, 26, (int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "T16:00:00.100-08:00" + "'", str27.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(buddhistChronology30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 7 + "'", int38 == 7);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "centuryOfEra" + "'", str39.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 2777097600000L + "'", long43 == 2777097600000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.hourOfDay();
        org.joda.time.DateTime.Property property5 = dateTime2.hourOfDay();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) 15);
        org.joda.time.DateTime dateTime9 = dateTime7.plusSeconds(69);
        org.joda.time.DateTime dateTime11 = dateTime7.withMonthOfYear((int) (short) 10);
        try {
            org.joda.time.DateTime dateTime13 = dateTime7.withSecondOfMinute(187200000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 187200000 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (short) 0, (long) 59);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 59L + "'", long2 == 59L);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.hourOfDay();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.withPeriodAdded(readablePeriod5, 3);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        java.lang.String str9 = dateTime7.toString();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969-12-31T15:59:59.999-08:00" + "'", str9.equals("1969-12-31T15:59:59.999-08:00"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.hourOfDay();
        org.joda.time.DurationField durationField5 = property4.getLeapDurationField();
        java.lang.String str6 = property4.getAsString();
        org.joda.time.DateTimeField dateTimeField7 = property4.getField();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.tz.DefaultNameProvider defaultNameProvider5 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale6 = null;
        java.lang.String str9 = defaultNameProvider5.getShortName(locale6, "15", "19");
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) defaultNameProvider5);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.era();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("Property[year]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[year]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.hourOfDay();
        org.joda.time.DateTime.Property property5 = dateTime2.hourOfDay();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) 15);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone9);
        org.joda.time.DateTime.Property property11 = dateTime10.centuryOfEra();
        org.joda.time.DateTime.Property property12 = dateTime10.hourOfDay();
        org.joda.time.DateTime.Property property13 = dateTime10.hourOfDay();
        org.joda.time.DateTime dateTime15 = property13.addToCopy((long) 15);
        org.joda.time.DateTime dateTime17 = dateTime15.plusSeconds(69);
        long long18 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTime dateTime20 = property5.addWrapFieldToCopy((int) 'a');
        org.joda.time.DateTime dateTime21 = property5.roundHalfEvenCopy();
        boolean boolean23 = dateTime21.isEqual((long) 'a');
        long long24 = dateTime21.getMillis();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-15L) + "'", long18 == (-15L));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withOffsetParsed();
        boolean boolean3 = gJChronology0.equals((java.lang.Object) dateTimeFormatter2);
        org.joda.time.Chronology chronology4 = gJChronology0.withUTC();
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(chronology4);
        org.joda.time.MonthDay monthDay7 = monthDay5.minusMonths(6);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(monthDay7);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
        org.joda.time.DateTime.Property property8 = dateTime6.weekyear();
        boolean boolean9 = iSOChronology3.equals((java.lang.Object) property8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.weekOfWeekyear();
        int int11 = dateTime2.get(dateTimeField10);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str15 = dateTimeFormatter13.print((long) (short) 100);
        boolean boolean16 = iSOChronology12.equals((java.lang.Object) dateTimeFormatter13);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone17);
        org.joda.time.Chronology chronology19 = buddhistChronology18.withUTC();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology18.secondOfDay();
        org.joda.time.DurationField durationField21 = buddhistChronology18.millis();
        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology18.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology12, dateTimeField22, (int) (short) 100);
        java.util.Locale locale25 = null;
        int int26 = skipDateTimeField24.getMaximumShortTextLength(locale25);
        java.lang.String str27 = skipDateTimeField24.getName();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField24, 132);
        long long31 = offsetDateTimeField29.roundCeiling((long) 7);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField29.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType32, 4);
        long long37 = offsetDateTimeField34.add((long) 19, 2000);
        java.util.Locale locale38 = null;
        int int39 = offsetDateTimeField34.getMaximumTextLength(locale38);
        long long41 = offsetDateTimeField34.roundHalfCeiling(0L);
        java.util.Locale locale43 = null;
        java.lang.String str44 = offsetDateTimeField34.getAsShortText(57598, locale43);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "T16:00:00.100-08:00" + "'", str15.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "centuryOfEra" + "'", str27.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2777097600000L + "'", long31 == 2777097600000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1209596400019L + "'", long37 == 1209596400019L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-230400000L) + "'", long41 == (-230400000L));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "57598" + "'", str44.equals("57598"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        int int6 = dateTime5.getMillisOfDay();
        boolean boolean7 = dateTime5.isBeforeNow();
        org.joda.time.DateTime dateTime9 = dateTime5.withDayOfMonth(19);
        org.joda.time.DateTime.Property property10 = dateTime9.monthOfYear();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57599999 + "'", int6 == 57599999);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "GJChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.hourOfDay();
        org.joda.time.DurationField durationField5 = property4.getLeapDurationField();
        int int6 = property4.getMaximumValueOverall();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone8);
        org.joda.time.DateTime dateTime10 = dateTime9.toDateTime();
        org.joda.time.DateTime dateTime12 = dateTime9.plusSeconds((-1));
        boolean boolean13 = property4.equals((java.lang.Object) dateTime12);
        org.joda.time.DateTimeField dateTimeField14 = property4.getField();
        org.joda.time.DateTime dateTime15 = property4.withMinimumValue();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 23 + "'", int6 == 23);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.tz.DefaultNameProvider defaultNameProvider5 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale6 = null;
        java.lang.String str9 = defaultNameProvider5.getShortName(locale6, "15", "19");
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) defaultNameProvider5);
        java.util.Locale locale11 = null;
        java.lang.String str14 = defaultNameProvider5.getShortName(locale11, "00", "Jun");
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("Property[year]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: Property[year]");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = buddhistChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.secondOfDay();
        org.joda.time.DurationField durationField4 = buddhistChronology1.millis();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.era();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str10 = dateTimeFormatter8.print((long) (short) 100);
        boolean boolean11 = iSOChronology7.equals((java.lang.Object) dateTimeFormatter8);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
        org.joda.time.Chronology chronology14 = buddhistChronology13.withUTC();
        org.joda.time.DateTimeField dateTimeField15 = buddhistChronology13.secondOfDay();
        org.joda.time.DurationField durationField16 = buddhistChronology13.millis();
        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology13.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology7, dateTimeField17, (int) (short) 100);
        java.util.Locale locale20 = null;
        int int21 = skipDateTimeField19.getMaximumShortTextLength(locale20);
        java.lang.String str22 = skipDateTimeField19.getName();
        long long24 = skipDateTimeField19.roundHalfEven(0L);
        org.joda.time.DateTimeField dateTimeField25 = skipDateTimeField19.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) skipDateTimeField19, 4);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone28);
        org.joda.time.Chronology chronology30 = buddhistChronology29.withUTC();
        org.joda.time.DateTimeField dateTimeField31 = buddhistChronology29.secondOfDay();
        org.joda.time.DurationField durationField32 = buddhistChronology29.millis();
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology29);
        java.lang.Object obj34 = null;
        boolean boolean35 = buddhistChronology29.equals(obj34);
        org.joda.time.DurationField durationField36 = buddhistChronology29.hours();
        java.util.TimeZone timeZone37 = null;
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forTimeZone(timeZone37);
        org.joda.time.chrono.ZonedChronology zonedChronology39 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology29, dateTimeZone38);
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology41 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone40);
        org.joda.time.Chronology chronology42 = buddhistChronology41.withUTC();
        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology41.secondOfDay();
        org.joda.time.DurationField durationField44 = buddhistChronology41.millis();
        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology41);
        org.joda.time.DateTime dateTime47 = dateTime45.withMillis(2777097600000L);
        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) dateTime45);
        org.joda.time.Chronology chronology49 = buddhistChronology1.withZone(dateTimeZone38);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "T16:00:00.100-08:00" + "'", str10.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 7 + "'", int21 == 7);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "centuryOfEra" + "'", str22.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-378662400000L) + "'", long24 == (-378662400000L));
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(zonedChronology39);
        org.junit.Assert.assertNotNull(buddhistChronology41);
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(gJChronology48);
        org.junit.Assert.assertNotNull(chronology49);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = buddhistChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.secondOfDay();
        org.joda.time.DurationField durationField4 = buddhistChronology1.millis();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology1);
        java.lang.Object obj6 = null;
        boolean boolean7 = buddhistChronology1.equals(obj6);
        org.joda.time.DurationField durationField8 = buddhistChronology1.hours();
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology1, dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
        org.joda.time.Chronology chronology14 = buddhistChronology13.withUTC();
        org.joda.time.DateTimeField dateTimeField15 = buddhistChronology13.secondOfDay();
        org.joda.time.DurationField durationField16 = buddhistChronology13.millis();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology13);
        org.joda.time.DateTime dateTime19 = dateTime17.withMillis(2777097600000L);
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone22);
        org.joda.time.DateTime dateTime24 = dateTime23.toDateTime();
        int int25 = dateTime23.getYearOfCentury();
        org.joda.time.DateTime dateTime27 = dateTime23.plusDays(25);
        boolean boolean28 = gJChronology20.equals((java.lang.Object) dateTime23);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 69 + "'", int25 == 69);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField13.getLeapDurationField();
        long long17 = delegatedDateTimeField13.addWrapField((long) '#', (int) (short) 1);
        int int18 = delegatedDateTimeField13.getMaximumValue();
        java.lang.String str20 = delegatedDateTimeField13.getAsText((long) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str24 = dateTimeFormatter22.print((long) (short) 100);
        boolean boolean25 = iSOChronology21.equals((java.lang.Object) dateTimeFormatter22);
        org.joda.time.tz.DefaultNameProvider defaultNameProvider26 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale27 = null;
        java.lang.String str30 = defaultNameProvider26.getShortName(locale27, "15", "19");
        boolean boolean31 = iSOChronology21.equals((java.lang.Object) defaultNameProvider26);
        org.joda.time.MonthDay monthDay33 = new org.joda.time.MonthDay((long) 59);
        org.joda.time.MonthDay monthDay35 = monthDay33.minusDays(1);
        boolean boolean36 = iSOChronology21.equals((java.lang.Object) monthDay33);
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay((long) 59);
        org.joda.time.MonthDay monthDay41 = monthDay39.minusDays(1);
        int[] intArray42 = monthDay39.getValues();
        try {
            int[] intArray44 = delegatedDateTimeField13.addWrapPartial((org.joda.time.ReadablePartial) monthDay33, 12, intArray42, (-2922685));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 12");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 3155760000035L + "'", long17 == 3155760000035L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2922796 + "'", int18 == 2922796);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "26" + "'", str20.equals("26"));
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "T16:00:00.100-08:00" + "'", str24.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(monthDay41);
        org.junit.Assert.assertNotNull(intArray42);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.hourOfDay();
        org.joda.time.DateTime.Property property5 = dateTime2.hourOfDay();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) 15);
        org.joda.time.DateTime dateTime9 = dateTime7.plusSeconds(69);
        org.joda.time.DateTime dateTime11 = dateTime7.withMonthOfYear((int) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusWeeks(36000000);
        int int14 = dateTime11.getWeekyear();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1970 + "'", int14 == 1970);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendDayOfWeek(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendFractionOfDay(6, (int) (short) 100);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendCenturyOfEra(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) -1, dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = gregorianChronology0.withZone(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.parse("GregorianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[America/Los_...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(dateTimeZone0);
//        int int2 = monthDay1.getMonthOfYear();
//        java.lang.String str3 = monthDay1.toString();
//        int[] intArray4 = monthDay1.getValues();
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        boolean boolean6 = monthDay1.isSupported(dateTimeFieldType5);
//        org.joda.time.MonthDay.Property property7 = monthDay1.dayOfMonth();
//        org.joda.time.MonthDay monthDay9 = property7.addWrapFieldToCopy(39540000);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray10 = monthDay9.getFieldTypes();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
//        try {
//            org.joda.time.MonthDay monthDay13 = monthDay9.withField(dateTimeFieldType11, (int) '#');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "--06-15" + "'", str3.equals("--06-15"));
//        org.junit.Assert.assertNotNull(intArray4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray10);
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 10, 59);
        java.lang.String str4 = dateTimeZone2.getName(0L);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.centuryOfEra();
        org.joda.time.Instant instant9 = new org.joda.time.Instant((java.lang.Object) dateTime7);
        int int10 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) instant9);
        org.joda.time.Instant instant12 = instant9.plus((long) 2);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
        org.joda.time.Chronology chronology15 = buddhistChronology14.withUTC();
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.secondOfDay();
        org.joda.time.DurationField durationField17 = buddhistChronology14.millis();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology14.weekyearOfCentury();
        int int20 = instant9.get(dateTimeField19);
        long long21 = instant9.getMillis();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+10:59" + "'", str4.equals("+10:59"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39540000 + "'", int10 == 39540000);
        org.junit.Assert.assertNotNull(instant12);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 14 + "'", int20 == 14);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        org.joda.time.DateTime dateTime7 = dateTime5.minusDays((int) (short) -1);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        java.lang.String str9 = copticChronology8.toString();
        org.joda.time.DateTimeField dateTimeField10 = copticChronology8.year();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) dateTime5, (org.joda.time.Chronology) copticChronology8);
        try {
            org.joda.time.DateTime dateTime16 = dateTime11.withTime(2922928, (int) (byte) 1, 69, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2922928 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str9.equals("CopticChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField12.getMaximumShortTextLength(locale13);
        java.lang.String str15 = skipDateTimeField12.getName();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField12, 132);
        long long19 = offsetDateTimeField17.roundCeiling((long) 7);
        org.joda.time.DurationField durationField20 = offsetDateTimeField17.getDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 7 + "'", int14 == 7);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "centuryOfEra" + "'", str15.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2777097600000L + "'", long19 == 2777097600000L);
        org.junit.Assert.assertNotNull(durationField20);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("1969-365T15:59:59.999-08:00", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"1969-365T15:59:59.999-08:00/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField12.getMaximumShortTextLength(locale13);
        java.lang.String str15 = skipDateTimeField12.getName();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField12, 132);
        long long19 = offsetDateTimeField17.roundCeiling((long) 7);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField17.getType();
        long long22 = offsetDateTimeField17.roundHalfFloor((-187200000L));
        long long24 = offsetDateTimeField17.roundHalfFloor((long) (short) 10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 7 + "'", int14 == 7);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "centuryOfEra" + "'", str15.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2777097600000L + "'", long19 == 2777097600000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-378662400000L) + "'", long22 == (-378662400000L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-378662400000L) + "'", long24 == (-378662400000L));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.hourOfDay();
        org.joda.time.DateTime.Property property5 = dateTime2.hourOfDay();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) 15);
        org.joda.time.DateTime dateTime9 = dateTime7.plusSeconds(69);
        org.joda.time.DateTime dateTime11 = dateTime7.withMonthOfYear((int) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusWeeks(36000000);
        try {
            org.joda.time.DateTime dateTime15 = dateTime11.withDayOfMonth(36000000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 36000000 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
//        boolean boolean3 = dateTimeFormatter0.isOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone4);
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeFormatter0.getZone();
//        java.io.Writer writer8 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone10);
//        org.joda.time.DateTime.Property property12 = dateTime11.centuryOfEra();
//        org.joda.time.DateTime.Property property13 = dateTime11.hourOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime11.minusYears(57599999);
//        try {
//            dateTimeFormatter0.printTo(writer8, (org.joda.time.ReadableInstant) dateTime11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Jun 15, ���� �:��:�� �" + "'", str6.equals("Jun 15, ���� �:��:�� �"));
//        org.junit.Assert.assertNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "Jun 15, ���� �:��:�� �", "+10:00");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "minuteOfDay", "ZonedChronology[BuddhistChronology[UTC], -01:00]");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField13.getLeapDurationField();
        int int16 = delegatedDateTimeField13.get(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 26 + "'", int16 == 26);
    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
//        boolean boolean3 = dateTimeFormatter0.isOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone4);
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.MonthDay monthDay8 = monthDay5.plus(readablePeriod7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Jun 15, ���� �:��:�� �" + "'", str6.equals("Jun 15, ���� �:��:�� �"));
//        org.junit.Assert.assertNotNull(monthDay8);
//    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone14);
        org.joda.time.Chronology chronology16 = buddhistChronology15.withUTC();
        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology15.secondOfDay();
        org.joda.time.DurationField durationField18 = buddhistChronology15.millis();
        org.joda.time.DurationField durationField19 = buddhistChronology15.centuries();
        long long27 = buddhistChronology15.getDateTimeMillis(4, (int) (byte) 10, 1, 3, 23, 0, 10);
        boolean boolean28 = iSOChronology0.equals((java.lang.Object) buddhistChronology15);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-79153245841990L) + "'", long27 == (-79153245841990L));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 2922796);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
        org.joda.time.DateTime dateTime10 = dateTime7.plusYears(59);
        org.joda.time.DateTime dateTime12 = dateTime7.plusDays((int) '#');
        org.joda.time.DateTime dateTime14 = dateTime12.withYear((-2922554));
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int4 = cachedDateTimeZone2.getOffset(0L);
        boolean boolean5 = cachedDateTimeZone2.isFixed();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 187200000 + "'", int4 == 187200000);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = gregorianChronology1.withZone(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str7 = dateTimeFormatter5.print((long) (short) 100);
        boolean boolean8 = iSOChronology4.equals((java.lang.Object) dateTimeFormatter5);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
        org.joda.time.Chronology chronology11 = buddhistChronology10.withUTC();
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology10.secondOfDay();
        org.joda.time.DurationField durationField13 = buddhistChronology10.millis();
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology10.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology4, dateTimeField14, (int) (short) 100);
        java.util.Locale locale17 = null;
        int int18 = skipDateTimeField16.getMaximumShortTextLength(locale17);
        java.lang.String str19 = skipDateTimeField16.getName();
        boolean boolean21 = skipDateTimeField16.isLeap((long) 10);
        int int24 = skipDateTimeField16.getDifference((long) 959, (long) 7);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField(chronology3, (org.joda.time.DateTimeField) skipDateTimeField16, 57598);
        long long29 = skipUndoDateTimeField26.set(0L, 132);
        long long32 = skipUndoDateTimeField26.set((long) (-2922686), 25);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "T16:00:00.100-08:00" + "'", str7.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 7 + "'", int18 == 7);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "centuryOfEra" + "'", str19.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 331348060800000L + "'", long29 == 331348060800000L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-3155676944686L) + "'", long32 == (-3155676944686L));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("19");
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, (int) (short) 10);
        org.joda.time.DateTime dateTime5 = instant4.toDateTime();
        org.joda.time.DateTime.Property property6 = dateTime5.centuryOfEra();
        org.joda.time.DateTime dateTime8 = dateTime5.minusMillis(25);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("19");
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, (int) (short) 10);
        org.joda.time.Instant instant6 = instant1.plus(11L);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant9 = instant1.withDurationAdded(readableDuration7, 10);
        org.joda.time.Instant instant12 = instant9.withDurationAdded((long) (short) 10, (int) (byte) -1);
        java.util.Date date13 = instant9.toDate();
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(instant12);
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        org.joda.time.DateMidnight dateMidnight6 = dateTime5.toDateMidnight();
        java.lang.Class<?> wildcardClass7 = dateTime5.getClass();
        org.joda.time.DateTime dateTime8 = dateTime5.toDateTimeISO();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = buddhistChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.secondOfDay();
        org.joda.time.DurationField durationField4 = buddhistChronology1.millis();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.era();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology1.weekOfWeekyear();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology9.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology8, dateTimeField10, 15);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours(10);
        java.lang.String str16 = dateTimeZone14.getShortName(3599999L);
        long long18 = dateTimeZone14.convertUTCToLocal(0L);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
        java.lang.String str20 = dateTimeZone14.toString();
        org.joda.time.Chronology chronology21 = iSOChronology8.withZone(dateTimeZone14);
        org.joda.time.Chronology chronology22 = buddhistChronology1.withZone(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField23 = buddhistChronology1.weekyear();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+10:00" + "'", str16.equals("+10:00"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 36000000L + "'", long18 == 36000000L);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+10:00" + "'", str20.equals("+10:00"));
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test441");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.secondOfMinute();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2, 15);
//        int int5 = skipDateTimeField4.getMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((java.lang.Integer) 10);
//        boolean boolean9 = dateTimeFormatter6.isOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay(dateTimeZone10);
//        java.lang.String str12 = dateTimeFormatter6.print((org.joda.time.ReadablePartial) monthDay11);
//        org.joda.time.MonthDay.Property property13 = monthDay11.monthOfYear();
//        int int14 = monthDay11.getDayOfMonth();
//        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = copticChronology15.monthOfYear();
//        org.joda.time.DurationField durationField17 = copticChronology15.minutes();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter18.withPivotYear((java.lang.Integer) 10);
//        boolean boolean21 = dateTimeFormatter18.isOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay(dateTimeZone22);
//        java.lang.String str24 = dateTimeFormatter18.print((org.joda.time.ReadablePartial) monthDay23);
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay(dateTimeZone25);
//        int int27 = monthDay26.getMonthOfYear();
//        java.lang.String str28 = monthDay26.toString();
//        int[] intArray29 = monthDay26.getValues();
//        copticChronology15.validate((org.joda.time.ReadablePartial) monthDay23, intArray29);
//        int int31 = skipDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay11, intArray29);
//        int int32 = skipDateTimeField4.getMinimumValue();
//        long long34 = skipDateTimeField4.roundFloor((-378662400000L));
//        org.joda.time.MonthDay monthDay35 = new org.joda.time.MonthDay();
//        org.joda.time.MonthDay monthDay38 = new org.joda.time.MonthDay((long) 59);
//        org.joda.time.MonthDay monthDay40 = monthDay38.minusDays(1);
//        int[] intArray41 = monthDay38.getValues();
//        try {
//            int[] intArray43 = skipDateTimeField4.add((org.joda.time.ReadablePartial) monthDay35, 3, intArray41, 12);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Jun 15, ���� �:��:�� �" + "'", str12.equals("Jun 15, ���� �:��:�� �"));
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
//        org.junit.Assert.assertNotNull(copticChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Jun 15, ���� �:��:�� �" + "'", str24.equals("Jun 15, ���� �:��:�� �"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "--06-15" + "'", str28.equals("--06-15"));
//        org.junit.Assert.assertNotNull(intArray29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-378662400000L) + "'", long34 == (-378662400000L));
//        org.junit.Assert.assertNotNull(monthDay40);
//        org.junit.Assert.assertNotNull(intArray41);
//    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        long long13 = dateTimeZone8.convertLocalToUTC((long) 19, false, (long) ' ');
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology14.getZone();
        try {
            long long21 = julianChronology14.getDateTimeMillis((long) 4, (-1), 187200000, 0, 3500);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28800019L + "'", long13 == 28800019L);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime2.withMillisOfDay(23);
        try {
            org.joda.time.DateTime dateTime10 = dateTime2.withTime(1969, 23, 3500, (-2922554));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        int int4 = dateTime2.getYearOfCentury();
        org.joda.time.DateTime dateTime6 = dateTime2.plusSeconds(15);
        int int7 = dateTime6.getCenturyOfEra();
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.plus(readableDuration8);
        org.joda.time.DateTime dateTime11 = dateTime6.minusMinutes(19);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 69 + "'", int4 == 69);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = buddhistChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.secondOfDay();
        org.joda.time.DurationField durationField4 = buddhistChronology1.millis();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology1);
        java.lang.Object obj6 = null;
        boolean boolean7 = buddhistChronology1.equals(obj6);
        org.joda.time.DurationField durationField8 = buddhistChronology1.hours();
        org.joda.time.Chronology chronology9 = buddhistChronology1.withUTC();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone8);
        org.joda.time.DateTime.Property property10 = dateTime9.centuryOfEra();
        org.joda.time.DateTime dateTime12 = property10.addToCopy(0);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime12.minus(readableDuration13);
        org.joda.time.DateTimeZone dateTimeZone15 = dateTime14.getZone();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
        org.joda.time.Instant instant17 = gJChronology16.getGregorianCutover();
        org.joda.time.DurationField durationField18 = gJChronology16.hours();
        try {
            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((-2922554), 57, 100, 57598, (-11), 15, 131, (org.joda.time.Chronology) gJChronology16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57598 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(instant17);
        org.junit.Assert.assertNotNull(durationField18);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = buddhistChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.secondOfDay();
        org.joda.time.DurationField durationField4 = buddhistChronology1.millis();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.era();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str10 = dateTimeFormatter8.print((long) (short) 100);
        boolean boolean11 = iSOChronology7.equals((java.lang.Object) dateTimeFormatter8);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
        org.joda.time.Chronology chronology14 = buddhistChronology13.withUTC();
        org.joda.time.DateTimeField dateTimeField15 = buddhistChronology13.secondOfDay();
        org.joda.time.DurationField durationField16 = buddhistChronology13.millis();
        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology13.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology7, dateTimeField17, (int) (short) 100);
        java.util.Locale locale20 = null;
        int int21 = skipDateTimeField19.getMaximumShortTextLength(locale20);
        java.lang.String str22 = skipDateTimeField19.getName();
        long long24 = skipDateTimeField19.roundHalfEven(0L);
        org.joda.time.DateTimeField dateTimeField25 = skipDateTimeField19.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) skipDateTimeField19, 4);
        long long30 = skipDateTimeField19.addWrapField((long) 4, (int) (short) 10);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "T16:00:00.100-08:00" + "'", str10.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 7 + "'", int21 == 7);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "centuryOfEra" + "'", str22.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-378662400000L) + "'", long24 == (-378662400000L));
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31556995200004L + "'", long30 == 31556995200004L);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = buddhistChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.secondOfDay();
        org.joda.time.DurationField durationField4 = buddhistChronology1.millis();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology1, dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
        int int14 = cachedDateTimeZone12.getOffset(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        boolean boolean16 = cachedDateTimeZone12.equals((java.lang.Object) dateTimeFormatter15);
        int int18 = cachedDateTimeZone12.getOffset((long) 15);
        org.joda.time.Chronology chronology19 = buddhistChronology1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone12);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 187200000 + "'", int14 == 187200000);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 187200000 + "'", int18 == 187200000);
        org.junit.Assert.assertNotNull(chronology19);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(dateTimeZone0);
        org.joda.time.MonthDay monthDay3 = monthDay1.minusDays((int) (byte) 1);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime6 = dateTime4.minusMinutes(132);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str10 = dateTimeFormatter8.print((long) (short) 100);
        boolean boolean11 = iSOChronology7.equals((java.lang.Object) dateTimeFormatter8);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
        org.joda.time.Chronology chronology14 = buddhistChronology13.withUTC();
        org.joda.time.DateTimeField dateTimeField15 = buddhistChronology13.secondOfDay();
        org.joda.time.DurationField durationField16 = buddhistChronology13.millis();
        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology13.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology7, dateTimeField17, (int) (short) 100);
        java.util.Locale locale20 = null;
        int int21 = skipDateTimeField19.getMaximumShortTextLength(locale20);
        java.lang.String str22 = skipDateTimeField19.getName();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField19, 132);
        long long26 = offsetDateTimeField24.roundCeiling((long) 7);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField24.getType();
        boolean boolean28 = dateTime4.isSupported(dateTimeFieldType27);
        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType27, "");
        try {
            int int31 = monthDay3.get(dateTimeFieldType27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'centuryOfEra' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "T16:00:00.100-08:00" + "'", str10.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 7 + "'", int21 == 7);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "centuryOfEra" + "'", str22.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2777097600000L + "'", long26 == 2777097600000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        java.lang.String str1 = copticChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.Chronology chronology5 = copticChronology0.withZone(dateTimeZone4);
        org.joda.time.DurationField durationField6 = copticChronology0.eras();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        boolean boolean10 = copticChronology0.equals((java.lang.Object) cachedDateTimeZone9);
        java.lang.Class<?> wildcardClass11 = cachedDateTimeZone9.getClass();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str1.equals("CopticChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        java.lang.String str3 = dateTimeZone1.getShortName(3599999L);
        long long5 = dateTimeZone1.convertUTCToLocal(0L);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        java.lang.String str7 = dateTimeZone1.toString();
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone10);
        org.joda.time.DateTime dateTime12 = dateTime11.toDateTime();
        int int13 = dateTime11.getYearOfCentury();
        org.joda.time.DateTime dateTime15 = dateTime11.plusDays(25);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone17);
        org.joda.time.DateTime.Property property19 = dateTime18.centuryOfEra();
        org.joda.time.DateTime dateTime21 = property19.addToCopy(0);
        org.joda.time.DateMidnight dateMidnight22 = dateTime21.toDateMidnight();
        org.joda.time.DateTime dateTime24 = dateTime21.withDayOfYear((int) 'a');
        boolean boolean25 = dateTime15.isEqual((org.joda.time.ReadableInstant) dateTime24);
        try {
            org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime24, 36000000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 36000000");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+10:00" + "'", str3.equals("+10:00"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 36000000L + "'", long5 == 36000000L);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+10:00" + "'", str7.equals("+10:00"));
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateMidnight22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime2.plusSeconds((-1));
        org.joda.time.DateTime.Property property6 = dateTime2.dayOfYear();
        org.joda.time.DurationField durationField7 = property6.getDurationField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField12.getMaximumShortTextLength(locale13);
        java.lang.String str15 = skipDateTimeField12.getName();
        boolean boolean17 = skipDateTimeField12.isLeap((long) 10);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone19);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone23);
        org.joda.time.DateTime.Property property25 = dateTime24.centuryOfEra();
        org.joda.time.DateTime.Property property26 = dateTime24.weekyear();
        boolean boolean27 = iSOChronology21.equals((java.lang.Object) property26);
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology21.weekOfWeekyear();
        int int29 = dateTime20.get(dateTimeField28);
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str33 = dateTimeFormatter31.print((long) (short) 100);
        boolean boolean34 = iSOChronology30.equals((java.lang.Object) dateTimeFormatter31);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone35);
        org.joda.time.Chronology chronology37 = buddhistChronology36.withUTC();
        org.joda.time.DateTimeField dateTimeField38 = buddhistChronology36.secondOfDay();
        org.joda.time.DurationField durationField39 = buddhistChronology36.millis();
        org.joda.time.DateTimeField dateTimeField40 = buddhistChronology36.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField42 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology30, dateTimeField40, (int) (short) 100);
        java.util.Locale locale43 = null;
        int int44 = skipDateTimeField42.getMaximumShortTextLength(locale43);
        java.lang.String str45 = skipDateTimeField42.getName();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField42, 132);
        long long49 = offsetDateTimeField47.roundCeiling((long) 7);
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = offsetDateTimeField47.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType50, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = offsetDateTimeField52.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField54 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField12, dateTimeFieldType53);
        java.lang.Number number55 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException58 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, number55, (java.lang.Number) (-1), (java.lang.Number) (short) 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 7 + "'", int14 == 7);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "centuryOfEra" + "'", str15.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "T16:00:00.100-08:00" + "'", str33.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(buddhistChronology36);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 7 + "'", int44 == 7);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "centuryOfEra" + "'", str45.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 2777097600000L + "'", long49 == 2777097600000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType50);
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField12.getMaximumShortTextLength(locale13);
        java.lang.String str15 = skipDateTimeField12.getName();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField12, 132);
        long long19 = offsetDateTimeField17.roundCeiling((long) 7);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField17.getType();
        long long23 = offsetDateTimeField17.add(28800019L, (long) 10);
        try {
            long long26 = offsetDateTimeField17.set((long) (byte) 10, "hourOfDay");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hourOfDay\" for centuryOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 7 + "'", int14 == 7);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "centuryOfEra" + "'", str15.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2777097600000L + "'", long19 == 2777097600000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 31557024000019L + "'", long23 == 31557024000019L);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime2.plusSeconds((-1));
        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
        org.joda.time.LocalDateTime localDateTime7 = dateTime2.toLocalDateTime();
        org.joda.time.DateTime.Property property8 = dateTime2.secondOfMinute();
        org.joda.time.DateTime.Property property9 = dateTime2.minuteOfDay();
        boolean boolean10 = property9.isLeap();
        java.lang.String str11 = property9.getName();
        org.joda.time.DateTime dateTime13 = property9.addWrapFieldToCopy(32);
        boolean boolean14 = dateTime13.isAfterNow();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "minuteOfDay" + "'", str11.equals("minuteOfDay"));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        try {
            int int1 = org.joda.time.field.FieldUtils.safeToInt((-56802557218500L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -56802557218500");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneOffset("Jun 15, ���� �:��:�� �", "hi!", false, 6, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendClockhourOfHalfday(959);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendTwoDigitWeekyear((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendFractionOfDay(2922928, 999);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = buddhistChronology1.withUTC();
        org.joda.time.DurationField durationField3 = buddhistChronology1.minutes();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
        org.joda.time.DateTime dateTime9 = property7.addToCopy(0);
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.minus(readableDuration10);
        org.joda.time.DateTimeZone dateTimeZone12 = dateTime11.getZone();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        org.joda.time.Chronology chronology14 = gregorianChronology3.withZone(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, dateTimeZone15);
        org.joda.time.MutableDateTime mutableDateTime17 = dateTime1.toMutableDateTime(dateTimeZone15);
        try {
            org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 2000");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test461");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone5);
//        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
//        org.joda.time.DateTime.Property property8 = dateTime6.weekyear();
//        boolean boolean9 = iSOChronology3.equals((java.lang.Object) property8);
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.weekOfWeekyear();
//        int int11 = dateTime2.get(dateTimeField10);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.lang.String str15 = dateTimeFormatter13.print((long) (short) 100);
//        boolean boolean16 = iSOChronology12.equals((java.lang.Object) dateTimeFormatter13);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone17);
//        org.joda.time.Chronology chronology19 = buddhistChronology18.withUTC();
//        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology18.secondOfDay();
//        org.joda.time.DurationField durationField21 = buddhistChronology18.millis();
//        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology18.centuryOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology12, dateTimeField22, (int) (short) 100);
//        java.util.Locale locale25 = null;
//        int int26 = skipDateTimeField24.getMaximumShortTextLength(locale25);
//        java.lang.String str27 = skipDateTimeField24.getName();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField24, 132);
//        long long31 = offsetDateTimeField29.roundCeiling((long) 7);
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField29.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType32, 4);
//        long long36 = offsetDateTimeField34.roundHalfEven((long) 10);
//        org.joda.time.DurationField durationField37 = offsetDateTimeField34.getLeapDurationField();
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay(dateTimeZone38);
//        int int40 = monthDay39.getMonthOfYear();
//        java.lang.String str41 = monthDay39.toString();
//        int[] intArray42 = monthDay39.getValues();
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = null;
//        boolean boolean44 = monthDay39.isSupported(dateTimeFieldType43);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.lang.String str48 = dateTimeFormatter46.print((long) (short) 100);
//        boolean boolean49 = iSOChronology45.equals((java.lang.Object) dateTimeFormatter46);
//        org.joda.time.DateTimeZone dateTimeZone50 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology51 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone50);
//        org.joda.time.Chronology chronology52 = buddhistChronology51.withUTC();
//        org.joda.time.DateTimeField dateTimeField53 = buddhistChronology51.secondOfDay();
//        org.joda.time.DurationField durationField54 = buddhistChronology51.millis();
//        org.joda.time.DateTimeField dateTimeField55 = buddhistChronology51.centuryOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField57 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology45, dateTimeField55, (int) (short) 100);
//        java.util.Locale locale58 = null;
//        int int59 = skipDateTimeField57.getMaximumShortTextLength(locale58);
//        java.lang.String str60 = skipDateTimeField57.getName();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField57, 132);
//        long long64 = offsetDateTimeField62.roundCeiling((long) 7);
//        org.joda.time.DateTimeFieldType dateTimeFieldType65 = offsetDateTimeField62.getType();
//        long long68 = offsetDateTimeField62.add(28800019L, (long) 10);
//        java.lang.String str70 = offsetDateTimeField62.getAsText((-187200000L));
//        org.joda.time.DateTimeZone dateTimeZone71 = null;
//        org.joda.time.MonthDay monthDay72 = new org.joda.time.MonthDay(dateTimeZone71);
//        org.joda.time.DateTimeFieldType dateTimeFieldType73 = null;
//        int int74 = monthDay72.indexOf(dateTimeFieldType73);
//        org.joda.time.chrono.CopticChronology copticChronology75 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField76 = copticChronology75.monthOfYear();
//        org.joda.time.DurationField durationField77 = copticChronology75.minutes();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter78 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter80 = dateTimeFormatter78.withPivotYear((java.lang.Integer) 10);
//        boolean boolean81 = dateTimeFormatter78.isOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone82 = null;
//        org.joda.time.MonthDay monthDay83 = new org.joda.time.MonthDay(dateTimeZone82);
//        java.lang.String str84 = dateTimeFormatter78.print((org.joda.time.ReadablePartial) monthDay83);
//        org.joda.time.DateTimeZone dateTimeZone85 = null;
//        org.joda.time.MonthDay monthDay86 = new org.joda.time.MonthDay(dateTimeZone85);
//        int int87 = monthDay86.getMonthOfYear();
//        java.lang.String str88 = monthDay86.toString();
//        int[] intArray89 = monthDay86.getValues();
//        copticChronology75.validate((org.joda.time.ReadablePartial) monthDay83, intArray89);
//        int int91 = offsetDateTimeField62.getMinimumValue((org.joda.time.ReadablePartial) monthDay72, intArray89);
//        int int92 = offsetDateTimeField34.getMinimumValue((org.joda.time.ReadablePartial) monthDay39, intArray89);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "T16:00:00.100-08:00" + "'", str15.equals("T16:00:00.100-08:00"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology18);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "centuryOfEra" + "'", str27.equals("centuryOfEra"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2777097600000L + "'", long31 == 2777097600000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-230400000L) + "'", long36 == (-230400000L));
//        org.junit.Assert.assertNull(durationField37);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "--06-15" + "'", str41.equals("--06-15"));
//        org.junit.Assert.assertNotNull(intArray42);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(dateTimeFormatter46);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "T16:00:00.100-08:00" + "'", str48.equals("T16:00:00.100-08:00"));
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology51);
//        org.junit.Assert.assertNotNull(chronology52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(durationField54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 7 + "'", int59 == 7);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "centuryOfEra" + "'", str60.equals("centuryOfEra"));
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 2777097600000L + "'", long64 == 2777097600000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType65);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 31557024000019L + "'", long68 == 31557024000019L);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "157" + "'", str70.equals("157"));
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
//        org.junit.Assert.assertNotNull(copticChronology75);
//        org.junit.Assert.assertNotNull(dateTimeField76);
//        org.junit.Assert.assertNotNull(durationField77);
//        org.junit.Assert.assertNotNull(dateTimeFormatter78);
//        org.junit.Assert.assertNotNull(dateTimeFormatter80);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "Jun 15, ���� �:��:�� �" + "'", str84.equals("Jun 15, ���� �:��:�� �"));
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 6 + "'", int87 == 6);
//        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "--06-15" + "'", str88.equals("--06-15"));
//        org.junit.Assert.assertNotNull(intArray89);
//        org.junit.Assert.assertTrue("'" + int91 + "' != '" + (-2922554) + "'", int91 == (-2922554));
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 5 + "'", int92 == 5);
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
        boolean boolean13 = skipDateTimeField12.isSupported();
        int int14 = skipDateTimeField12.getMaximumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2922796 + "'", int14 == 2922796);
    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone5);
//        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
//        org.joda.time.DateTime.Property property8 = dateTime6.weekyear();
//        boolean boolean9 = iSOChronology3.equals((java.lang.Object) property8);
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.weekOfWeekyear();
//        int int11 = dateTime2.get(dateTimeField10);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.lang.String str15 = dateTimeFormatter13.print((long) (short) 100);
//        boolean boolean16 = iSOChronology12.equals((java.lang.Object) dateTimeFormatter13);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone17);
//        org.joda.time.Chronology chronology19 = buddhistChronology18.withUTC();
//        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology18.secondOfDay();
//        org.joda.time.DurationField durationField21 = buddhistChronology18.millis();
//        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology18.centuryOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology12, dateTimeField22, (int) (short) 100);
//        java.util.Locale locale25 = null;
//        int int26 = skipDateTimeField24.getMaximumShortTextLength(locale25);
//        java.lang.String str27 = skipDateTimeField24.getName();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField24, 132);
//        long long31 = offsetDateTimeField29.roundCeiling((long) 7);
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField29.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType32, 4);
//        long long37 = offsetDateTimeField34.add((long) 19, 2000);
//        java.util.Locale locale38 = null;
//        int int39 = offsetDateTimeField34.getMaximumTextLength(locale38);
//        long long41 = offsetDateTimeField34.roundHalfCeiling(0L);
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.MonthDay monthDay43 = new org.joda.time.MonthDay(dateTimeZone42);
//        int int44 = monthDay43.getMonthOfYear();
//        java.lang.String str45 = monthDay43.toString();
//        int[] intArray46 = monthDay43.getValues();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = null;
//        boolean boolean48 = monthDay43.isSupported(dateTimeFieldType47);
//        org.joda.time.MonthDay.Property property49 = monthDay43.dayOfMonth();
//        org.joda.time.ReadablePeriod readablePeriod50 = null;
//        org.joda.time.MonthDay monthDay52 = monthDay43.withPeriodAdded(readablePeriod50, 187200000);
//        java.util.Locale locale54 = null;
//        java.lang.String str55 = offsetDateTimeField34.getAsShortText((org.joda.time.ReadablePartial) monthDay52, 10, locale54);
//        long long58 = offsetDateTimeField34.add((-260368619990L), (int) (byte) 100);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "T16:00:00.100-08:00" + "'", str15.equals("T16:00:00.100-08:00"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology18);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "centuryOfEra" + "'", str27.equals("centuryOfEra"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2777097600000L + "'", long31 == 2777097600000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1209596400019L + "'", long37 == 1209596400019L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-230400000L) + "'", long41 == (-230400000L));
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 6 + "'", int44 == 6);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "--06-15" + "'", str45.equals("--06-15"));
//        org.junit.Assert.assertNotNull(intArray46);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(monthDay52);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "10" + "'", str55.equals("10"));
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-199892219990L) + "'", long58 == (-199892219990L));
//    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gregorianCalendar2);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
        long long15 = skipDateTimeField12.addWrapField((long) 7, 7);
        org.joda.time.DurationField durationField16 = skipDateTimeField12.getLeapDurationField();
        int int17 = skipDateTimeField12.getMinimumValue();
        long long19 = skipDateTimeField12.remainder((long) 12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder20.appendTimeZoneOffset("Jun 15, ���� �:��:�� �", "hi!", false, 6, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder28.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder28.appendYear(100, (int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str37 = dateTimeFormatter35.print((long) (short) 100);
        boolean boolean38 = iSOChronology34.equals((java.lang.Object) dateTimeFormatter35);
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone39);
        org.joda.time.Chronology chronology41 = buddhistChronology40.withUTC();
        org.joda.time.DateTimeField dateTimeField42 = buddhistChronology40.secondOfDay();
        org.joda.time.DurationField durationField43 = buddhistChronology40.millis();
        org.joda.time.DateTimeField dateTimeField44 = buddhistChronology40.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField46 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology34, dateTimeField44, (int) (short) 100);
        java.util.Locale locale47 = null;
        int int48 = skipDateTimeField46.getMaximumShortTextLength(locale47);
        java.lang.String str49 = skipDateTimeField46.getName();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField46, 132);
        long long53 = offsetDateTimeField51.roundCeiling((long) 7);
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = offsetDateTimeField51.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder33.appendText(dateTimeFieldType54);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField12, dateTimeFieldType54, 59);
        long long59 = remainderDateTimeField57.remainder((long) (byte) -1);
        long long61 = remainderDateTimeField57.roundHalfEven(0L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder62.appendTimeZoneOffset("Jun 15, ���� �:��:�� �", "hi!", false, 6, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder70 = dateTimeFormatterBuilder68.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder72 = dateTimeFormatterBuilder70.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder75 = dateTimeFormatterBuilder70.appendYear(100, (int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology76 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter77 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str79 = dateTimeFormatter77.print((long) (short) 100);
        boolean boolean80 = iSOChronology76.equals((java.lang.Object) dateTimeFormatter77);
        org.joda.time.DateTimeZone dateTimeZone81 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology82 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone81);
        org.joda.time.Chronology chronology83 = buddhistChronology82.withUTC();
        org.joda.time.DateTimeField dateTimeField84 = buddhistChronology82.secondOfDay();
        org.joda.time.DurationField durationField85 = buddhistChronology82.millis();
        org.joda.time.DateTimeField dateTimeField86 = buddhistChronology82.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField88 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology76, dateTimeField86, (int) (short) 100);
        java.util.Locale locale89 = null;
        int int90 = skipDateTimeField88.getMaximumShortTextLength(locale89);
        java.lang.String str91 = skipDateTimeField88.getName();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField93 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField88, 132);
        long long95 = offsetDateTimeField93.roundCeiling((long) 7);
        org.joda.time.DateTimeFieldType dateTimeFieldType96 = offsetDateTimeField93.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder97 = dateTimeFormatterBuilder75.appendText(dateTimeFieldType96);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField98 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField57, dateTimeFieldType96);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 22089888000007L + "'", long15 == 22089888000007L);
        org.junit.Assert.assertNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-2922686) + "'", int17 == (-2922686));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 12L + "'", long19 == 12L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "T16:00:00.100-08:00" + "'", str37.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(buddhistChronology40);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 7 + "'", int48 == 7);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "centuryOfEra" + "'", str49.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 2777097600000L + "'", long53 == 2777097600000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-1L) + "'", long59 == (-1L));
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-378662400000L) + "'", long61 == (-378662400000L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder70);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder72);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder75);
        org.junit.Assert.assertNotNull(iSOChronology76);
        org.junit.Assert.assertNotNull(dateTimeFormatter77);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "T16:00:00.100-08:00" + "'", str79.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(buddhistChronology82);
        org.junit.Assert.assertNotNull(chronology83);
        org.junit.Assert.assertNotNull(dateTimeField84);
        org.junit.Assert.assertNotNull(durationField85);
        org.junit.Assert.assertNotNull(dateTimeField86);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 7 + "'", int90 == 7);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "centuryOfEra" + "'", str91.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + long95 + "' != '" + 2777097600000L + "'", long95 == 2777097600000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType96);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder97);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        java.lang.String str1 = copticChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.Chronology chronology5 = copticChronology0.withZone(dateTimeZone4);
        org.joda.time.DurationField durationField6 = copticChronology0.eras();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        boolean boolean10 = copticChronology0.equals((java.lang.Object) cachedDateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime13.toDateTime();
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.plus(readableDuration15);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime19.toDateTime();
        org.joda.time.DateTime dateTime22 = dateTime19.plusSeconds((-1));
        org.joda.time.DateTime.Property property23 = dateTime19.monthOfYear();
        org.joda.time.LocalDateTime localDateTime24 = dateTime19.toLocalDateTime();
        org.joda.time.DateTime.Property property25 = dateTime19.secondOfMinute();
        int int26 = dateTime19.getMinuteOfDay();
        try {
            org.joda.time.chrono.LimitChronology limitChronology27 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, (org.joda.time.ReadableDateTime) dateTime14, (org.joda.time.ReadableDateTime) dateTime19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str1.equals("CopticChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 959 + "'", int26 == 959);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = buddhistChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.secondOfDay();
        org.joda.time.DurationField durationField4 = buddhistChronology1.millis();
        org.joda.time.DurationField durationField5 = buddhistChronology1.centuries();
        long long13 = buddhistChronology1.getDateTimeMillis(4, (int) (byte) 10, 1, 3, 23, 0, 10);
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology1.secondOfMinute();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-79153245841990L) + "'", long13 == (-79153245841990L));
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone12);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.centuryOfEra();
        org.joda.time.DateTime.Property property19 = dateTime17.weekyear();
        boolean boolean20 = iSOChronology14.equals((java.lang.Object) property19);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology14.weekOfWeekyear();
        int int22 = dateTime13.get(dateTimeField21);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str26 = dateTimeFormatter24.print((long) (short) 100);
        boolean boolean27 = iSOChronology23.equals((java.lang.Object) dateTimeFormatter24);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone28);
        org.joda.time.Chronology chronology30 = buddhistChronology29.withUTC();
        org.joda.time.DateTimeField dateTimeField31 = buddhistChronology29.secondOfDay();
        org.joda.time.DurationField durationField32 = buddhistChronology29.millis();
        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology29.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField35 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology23, dateTimeField33, (int) (short) 100);
        java.util.Locale locale36 = null;
        int int37 = skipDateTimeField35.getMaximumShortTextLength(locale36);
        java.lang.String str38 = skipDateTimeField35.getName();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField35, 132);
        long long42 = offsetDateTimeField40.roundCeiling((long) 7);
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = offsetDateTimeField40.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, dateTimeFieldType43, 4);
        long long47 = offsetDateTimeField45.roundHalfEven((long) 10);
        boolean boolean48 = gJChronology9.equals((java.lang.Object) 10);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "T16:00:00.100-08:00" + "'", str26.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 7 + "'", int37 == 7);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "centuryOfEra" + "'", str38.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 2777097600000L + "'", long42 == 2777097600000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-230400000L) + "'", long47 == (-230400000L));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withOffsetParsed();
        boolean boolean3 = gJChronology0.equals((java.lang.Object) dateTimeFormatter2);
        org.joda.time.Chronology chronology4 = gJChronology0.withUTC();
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(chronology4);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray6 = monthDay5.getFieldTypes();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray6);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(1, 6);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap9 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendTimeZoneName(strMap9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(1L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("19");
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, (int) (short) 10);
        boolean boolean5 = instant4.isEqualNow();
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        boolean boolean2 = dateTimeFormatter1.isParser();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime5.centuryOfEra();
        org.joda.time.DateTime dateTime8 = property6.addToCopy(0);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.minus(readableDuration9);
        org.joda.time.LocalTime localTime11 = dateTime10.toLocalTime();
        org.joda.time.DateTime dateTime13 = dateTime10.minusDays((int) '4');
        java.lang.String str14 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime10);
        try {
            org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1969-365T15:59:59.999-08:00" + "'", str14.equals("1969-365T15:59:59.999-08:00"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.hourOfDay();
        org.joda.time.DateTime.Property property5 = dateTime2.hourOfDay();
        org.joda.time.DurationField durationField6 = property5.getRangeDurationField();
        long long9 = durationField6.subtract((long) (byte) 0, 14);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1209600000L) + "'", long9 == (-1209600000L));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("+10:59", 131);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder0.addRecurringSavings("Jun", 26, 2000, 31, '#', 0, 2922796, 959, true, (-11));
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

//    @Test
//    public void test476() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test476");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(dateTimeZone0);
//        org.joda.time.MonthDay monthDay3 = monthDay1.minusDays((int) (byte) 1);
//        int int4 = monthDay3.getDayOfMonth();
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.lang.String str8 = dateTimeFormatter6.print((long) (short) 100);
//        boolean boolean9 = iSOChronology5.equals((java.lang.Object) dateTimeFormatter6);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone10);
//        org.joda.time.Chronology chronology12 = buddhistChronology11.withUTC();
//        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology11.secondOfDay();
//        org.joda.time.DurationField durationField14 = buddhistChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField15 = buddhistChronology11.centuryOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology5, dateTimeField15, (int) (short) 100);
//        long long20 = skipDateTimeField17.addWrapField((long) 7, 7);
//        org.joda.time.DurationField durationField21 = skipDateTimeField17.getLeapDurationField();
//        int int22 = skipDateTimeField17.getMinimumValue();
//        long long24 = skipDateTimeField17.remainder((long) 12);
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = skipDateTimeField17.getType();
//        try {
//            org.joda.time.MonthDay.Property property26 = monthDay3.property(dateTimeFieldType25);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'centuryOfEra' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 14 + "'", int4 == 14);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "T16:00:00.100-08:00" + "'", str8.equals("T16:00:00.100-08:00"));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 22089888000007L + "'", long20 == 22089888000007L);
//        org.junit.Assert.assertNull(durationField21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-2922686) + "'", int22 == (-2922686));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 12L + "'", long24 == 12L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test477");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.Chronology chronology3 = buddhistChronology2.withUTC();
//        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.secondOfDay();
//        org.joda.time.DurationField durationField5 = buddhistChronology2.millis();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology2);
//        java.lang.Object obj7 = null;
//        boolean boolean8 = buddhistChronology2.equals(obj7);
//        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology2);
//        java.lang.String str10 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6 15, ���� �:��:�� �" + "'", str10.equals("6 15, ���� �:��:�� �"));
//    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.centuryOfEra();
        org.joda.time.DateTime dateTime10 = property8.addToCopy(0);
        org.joda.time.DateMidnight dateMidnight11 = dateTime10.toDateMidnight();
        int int12 = property4.getDifference((org.joda.time.ReadableInstant) dateMidnight11);
        long long13 = property4.remainder();
        org.joda.time.DurationField durationField14 = property4.getRangeDurationField();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateMidnight11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3599999L + "'", long13 == 3599999L);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
        org.joda.time.Instant instant10 = gJChronology9.getGregorianCutover();
        try {
            long long15 = gJChronology9.getDateTimeMillis(14, (-2922554), 999, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2922554 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(instant10);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
        org.joda.time.DateTime.Property property8 = dateTime6.weekyear();
        boolean boolean9 = iSOChronology3.equals((java.lang.Object) property8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.weekOfWeekyear();
        int int11 = dateTime2.get(dateTimeField10);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str15 = dateTimeFormatter13.print((long) (short) 100);
        boolean boolean16 = iSOChronology12.equals((java.lang.Object) dateTimeFormatter13);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone17);
        org.joda.time.Chronology chronology19 = buddhistChronology18.withUTC();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology18.secondOfDay();
        org.joda.time.DurationField durationField21 = buddhistChronology18.millis();
        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology18.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology12, dateTimeField22, (int) (short) 100);
        java.util.Locale locale25 = null;
        int int26 = skipDateTimeField24.getMaximumShortTextLength(locale25);
        java.lang.String str27 = skipDateTimeField24.getName();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField24, 132);
        long long31 = offsetDateTimeField29.roundCeiling((long) 7);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField29.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType32, 4);
        long long36 = offsetDateTimeField34.roundHalfCeiling((long) 3);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "T16:00:00.100-08:00" + "'", str15.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "centuryOfEra" + "'", str27.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2777097600000L + "'", long31 == 2777097600000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-230400000L) + "'", long36 == (-230400000L));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        int int4 = dateTime2.getYearOfCentury();
        org.joda.time.DateTime dateTime6 = dateTime2.plusSeconds(15);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime7.minusMinutes(132);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str13 = dateTimeFormatter11.print((long) (short) 100);
        boolean boolean14 = iSOChronology10.equals((java.lang.Object) dateTimeFormatter11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone15);
        org.joda.time.Chronology chronology17 = buddhistChronology16.withUTC();
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology16.secondOfDay();
        org.joda.time.DurationField durationField19 = buddhistChronology16.millis();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology16.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology10, dateTimeField20, (int) (short) 100);
        java.util.Locale locale23 = null;
        int int24 = skipDateTimeField22.getMaximumShortTextLength(locale23);
        java.lang.String str25 = skipDateTimeField22.getName();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField22, 132);
        long long29 = offsetDateTimeField27.roundCeiling((long) 7);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = offsetDateTimeField27.getType();
        boolean boolean31 = dateTime7.isSupported(dateTimeFieldType30);
        boolean boolean32 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime7);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 69 + "'", int4 == 69);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "T16:00:00.100-08:00" + "'", str13.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 7 + "'", int24 == 7);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "centuryOfEra" + "'", str25.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2777097600000L + "'", long29 == 2777097600000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.dayOfYear();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.millisOfDay();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = buddhistChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.secondOfDay();
        org.joda.time.DurationField durationField4 = buddhistChronology1.millis();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology1);
        java.lang.Object obj6 = null;
        boolean boolean7 = buddhistChronology1.equals(obj6);
        org.joda.time.DurationField durationField8 = buddhistChronology1.hours();
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology1, dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
        org.joda.time.Chronology chronology14 = buddhistChronology13.withUTC();
        org.joda.time.DateTimeField dateTimeField15 = buddhistChronology13.secondOfDay();
        org.joda.time.DurationField durationField16 = buddhistChronology13.millis();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology13);
        org.joda.time.DateTime dateTime19 = dateTime17.withMillis(2777097600000L);
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (org.joda.time.ReadableInstant) dateTime17);
        long long22 = dateTimeZone10.convertUTCToLocal((long) 59);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-28799941L) + "'", long22 == (-28799941L));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
        org.joda.time.TimeOfDay timeOfDay9 = dateTime7.toTimeOfDay();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(timeOfDay9);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime2.plusSeconds((-1));
        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
        org.joda.time.LocalDateTime localDateTime7 = dateTime2.toLocalDateTime();
        org.joda.time.DateTime.Property property8 = dateTime2.secondOfMinute();
        org.joda.time.DateTime.Property property9 = dateTime2.minuteOfDay();
        boolean boolean10 = property9.isLeap();
        java.util.Locale locale12 = null;
        try {
            org.joda.time.DateTime dateTime13 = property9.setCopy("ZonedChronology[BuddhistChronology[UTC], -01:00]", locale12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"ZonedChronology[BuddhistChronology[UTC], -01:00]\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        org.joda.time.DateMidnight dateMidnight6 = dateTime5.toDateMidnight();
        org.joda.time.DateTime dateTime8 = dateTime5.withDayOfYear((int) 'a');
        org.joda.time.DateTime dateTime10 = dateTime5.withMillis((long) (-11));
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = gregorianChronology1.withZone(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str7 = dateTimeFormatter5.print((long) (short) 100);
        boolean boolean8 = iSOChronology4.equals((java.lang.Object) dateTimeFormatter5);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
        org.joda.time.Chronology chronology11 = buddhistChronology10.withUTC();
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology10.secondOfDay();
        org.joda.time.DurationField durationField13 = buddhistChronology10.millis();
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology10.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology4, dateTimeField14, (int) (short) 100);
        java.util.Locale locale17 = null;
        int int18 = skipDateTimeField16.getMaximumShortTextLength(locale17);
        java.lang.String str19 = skipDateTimeField16.getName();
        boolean boolean21 = skipDateTimeField16.isLeap((long) 10);
        int int24 = skipDateTimeField16.getDifference((long) 959, (long) 7);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField(chronology3, (org.joda.time.DateTimeField) skipDateTimeField16, 57598);
        int int27 = skipUndoDateTimeField26.getMaximumValue();
        try {
            long long30 = skipUndoDateTimeField26.set((long) (-292275054), 36000000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 36000000 for centuryOfEra must be in the range [-2922685,2922796]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "T16:00:00.100-08:00" + "'", str7.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 7 + "'", int18 == 7);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "centuryOfEra" + "'", str19.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2922796 + "'", int27 == 2922796);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 100);
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology6.millis();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10, (int) (short) 100);
        long long15 = skipDateTimeField12.addWrapField((long) 7, 7);
        org.joda.time.DurationField durationField16 = skipDateTimeField12.getLeapDurationField();
        int int17 = skipDateTimeField12.getMinimumValue();
        long long19 = skipDateTimeField12.remainder((long) 12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder20.appendTimeZoneOffset("Jun 15, ���� �:��:�� �", "hi!", false, 6, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder28.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder28.appendYear(100, (int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str37 = dateTimeFormatter35.print((long) (short) 100);
        boolean boolean38 = iSOChronology34.equals((java.lang.Object) dateTimeFormatter35);
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone39);
        org.joda.time.Chronology chronology41 = buddhistChronology40.withUTC();
        org.joda.time.DateTimeField dateTimeField42 = buddhistChronology40.secondOfDay();
        org.joda.time.DurationField durationField43 = buddhistChronology40.millis();
        org.joda.time.DateTimeField dateTimeField44 = buddhistChronology40.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField46 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology34, dateTimeField44, (int) (short) 100);
        java.util.Locale locale47 = null;
        int int48 = skipDateTimeField46.getMaximumShortTextLength(locale47);
        java.lang.String str49 = skipDateTimeField46.getName();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField46, 132);
        long long53 = offsetDateTimeField51.roundCeiling((long) 7);
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = offsetDateTimeField51.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder33.appendText(dateTimeFieldType54);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField12, dateTimeFieldType54, 59);
        int int58 = skipDateTimeField12.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.100-08:00" + "'", str3.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 22089888000007L + "'", long15 == 22089888000007L);
        org.junit.Assert.assertNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-2922686) + "'", int17 == (-2922686));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 12L + "'", long19 == 12L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "T16:00:00.100-08:00" + "'", str37.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(buddhistChronology40);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 7 + "'", int48 == 7);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "centuryOfEra" + "'", str49.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 2777097600000L + "'", long53 == 2777097600000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-2922686) + "'", int58 == (-2922686));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
        org.joda.time.DateTime.Property property8 = dateTime6.weekyear();
        boolean boolean9 = iSOChronology3.equals((java.lang.Object) property8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.weekOfWeekyear();
        int int11 = dateTime2.get(dateTimeField10);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str15 = dateTimeFormatter13.print((long) (short) 100);
        boolean boolean16 = iSOChronology12.equals((java.lang.Object) dateTimeFormatter13);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone17);
        org.joda.time.Chronology chronology19 = buddhistChronology18.withUTC();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology18.secondOfDay();
        org.joda.time.DurationField durationField21 = buddhistChronology18.millis();
        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology18.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology12, dateTimeField22, (int) (short) 100);
        java.util.Locale locale25 = null;
        int int26 = skipDateTimeField24.getMaximumShortTextLength(locale25);
        java.lang.String str27 = skipDateTimeField24.getName();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField24, 132);
        long long31 = offsetDateTimeField29.roundCeiling((long) 7);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField29.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType32, 4);
        long long36 = offsetDateTimeField34.roundHalfEven((long) 10);
        java.util.Locale locale37 = null;
        int int38 = offsetDateTimeField34.getMaximumTextLength(locale37);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "T16:00:00.100-08:00" + "'", str15.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "centuryOfEra" + "'", str27.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2777097600000L + "'", long31 == 2777097600000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-230400000L) + "'", long36 == (-230400000L));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2 + "'", int38 == 2);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        int int8 = dateTime5.getSecondOfMinute();
        org.joda.time.Instant instant9 = new org.joda.time.Instant((java.lang.Object) dateTime5);
        org.joda.time.Chronology chronology10 = instant9.getChronology();
        org.joda.time.DateTime dateTime11 = instant9.toDateTimeISO();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Jun 15, ���� �:��:�� �", (java.lang.Number) (byte) 10, number2, (java.lang.Number) 23);
        java.lang.Number number7 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("Jun 15, ���� �:��:�� �", (java.lang.Number) (byte) 10, number7, (java.lang.Number) 23);
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException9);
        java.lang.String str11 = illegalFieldValueException4.toString();
        java.lang.Number number12 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.Number number15 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException("Jun 15, ���� �:��:�� �", (java.lang.Number) (byte) 10, number15, (java.lang.Number) 23);
        java.lang.Number number20 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException("Jun 15, ���� �:��:�� �", (java.lang.Number) (byte) 10, number20, (java.lang.Number) 23);
        illegalFieldValueException17.addSuppressed((java.lang.Throwable) illegalFieldValueException22);
        java.lang.String str24 = illegalFieldValueException17.toString();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException17);
        java.lang.Throwable[] throwableArray26 = illegalFieldValueException4.getSuppressed();
        java.lang.Number number27 = illegalFieldValueException4.getIllegalNumberValue();
        org.joda.time.DurationFieldType durationFieldType28 = illegalFieldValueException4.getDurationFieldType();
        java.lang.String str29 = illegalFieldValueException4.getFieldName();
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 10 for Jun 15, ���� �:��:�� � must not be larger than 23" + "'", str11.equals("org.joda.time.IllegalFieldValueException: Value 10 for Jun 15, ���� �:��:�� � must not be larger than 23"));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (byte) 10 + "'", number12.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 10 for Jun 15, ���� �:��:�� � must not be larger than 23" + "'", str24.equals("org.joda.time.IllegalFieldValueException: Value 10 for Jun 15, ���� �:��:�� � must not be larger than 23"));
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + (byte) 10 + "'", number27.equals((byte) 10));
        org.junit.Assert.assertNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Jun 15, ���� �:��:�� �" + "'", str29.equals("Jun 15, ���� �:��:�� �"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
        org.joda.time.DurationField durationField10 = gJChronology9.eras();
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology9.getZone();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test493");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(dateTimeZone0);
//        int int2 = monthDay1.getMonthOfYear();
//        java.lang.String str3 = monthDay1.toString();
//        int[] intArray4 = monthDay1.getValues();
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        boolean boolean6 = monthDay1.isSupported(dateTimeFieldType5);
//        org.joda.time.MonthDay.Property property7 = monthDay1.dayOfMonth();
//        org.joda.time.MonthDay monthDay9 = property7.addWrapFieldToCopy(39540000);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray10 = monthDay9.getFieldTypes();
//        org.joda.time.MonthDay.Property property11 = monthDay9.monthOfYear();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "--06-15" + "'", str3.equals("--06-15"));
//        org.junit.Assert.assertNotNull(intArray4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray10);
//        org.junit.Assert.assertNotNull(property11);
//    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(2922928, (int) (short) -1, 3500, (int) (byte) 0, 365, 2922928, (org.joda.time.Chronology) buddhistChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology7);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.hourOfDay();
        try {
            org.joda.time.DateTime dateTime6 = dateTime2.withDayOfYear((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0);
        int int6 = dateTime5.getMillisOfDay();
        java.util.Locale locale8 = null;
        java.lang.String str9 = dateTime5.toString("15", locale8);
        org.joda.time.DateTime dateTime11 = dateTime5.minus((long) 3500);
        org.joda.time.DateTime dateTime13 = dateTime11.withMillisOfDay(25);
        try {
            org.joda.time.DateTime dateTime15 = dateTime13.withCenturyOfEra((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for centuryOfEra must be in the range [0,2922789]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57599999 + "'", int6 == 57599999);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "15" + "'", str9.equals("15"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 15, (java.lang.Number) (-2922685), (java.lang.Number) 31556995200004L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(132, 57599);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57731 + "'", int2 == 57731);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) -1, dateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
        org.joda.time.DateTime.Property property8 = dateTime6.weekyear();
        boolean boolean9 = iSOChronology3.equals((java.lang.Object) property8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.weekOfWeekyear();
        int int11 = dateTime2.get(dateTimeField10);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str15 = dateTimeFormatter13.print((long) (short) 100);
        boolean boolean16 = iSOChronology12.equals((java.lang.Object) dateTimeFormatter13);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone17);
        org.joda.time.Chronology chronology19 = buddhistChronology18.withUTC();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology18.secondOfDay();
        org.joda.time.DurationField durationField21 = buddhistChronology18.millis();
        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology18.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology12, dateTimeField22, (int) (short) 100);
        java.util.Locale locale25 = null;
        int int26 = skipDateTimeField24.getMaximumShortTextLength(locale25);
        java.lang.String str27 = skipDateTimeField24.getName();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField24, 132);
        long long31 = offsetDateTimeField29.roundCeiling((long) 7);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField29.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType32, 4);
        long long36 = offsetDateTimeField34.roundHalfEven((long) 10);
        org.joda.time.DurationField durationField37 = offsetDateTimeField34.getLeapDurationField();
        java.util.Locale locale38 = null;
        int int39 = offsetDateTimeField34.getMaximumTextLength(locale38);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "T16:00:00.100-08:00" + "'", str15.equals("T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "centuryOfEra" + "'", str27.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2777097600000L + "'", long31 == 2777097600000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-230400000L) + "'", long36 == (-230400000L));
        org.junit.Assert.assertNull(durationField37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long5 = cachedDateTimeZone2.convertLocalToUTC((long) (byte) 0, true);
        int int7 = cachedDateTimeZone2.getStandardOffset((long) 57598);
        org.joda.time.DateTimeZone dateTimeZone8 = cachedDateTimeZone2.getUncachedZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-187200000L) + "'", long5 == (-187200000L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 187200000 + "'", int7 == 187200000);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }
}

