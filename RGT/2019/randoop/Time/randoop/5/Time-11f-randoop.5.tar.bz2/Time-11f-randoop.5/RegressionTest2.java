import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        long long7 = dateTimeZone5.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        long long11 = dateTimeZone9.convertUTCToLocal((-1L));
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        boolean boolean13 = zonedChronology8.equals((java.lang.Object) dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology8.dayOfWeek();
        org.joda.time.Chronology chronology15 = zonedChronology8.withUTC();
        org.joda.time.Period period16 = new org.joda.time.Period((long) 7, (-210866673600000L), (org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTimeField dateTimeField17 = zonedChronology8.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField18 = zonedChronology8.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (-25200000));
        int int23 = offsetDateTimeField20.getDifference((long) (-1), 0L);
        org.joda.time.ReadablePartial readablePartial24 = null;
        java.util.Locale locale26 = null;
        java.lang.String str27 = offsetDateTimeField20.getAsText(readablePartial24, 0, locale26);
        int int29 = offsetDateTimeField20.getLeapAmount((long) (-1));
        int int30 = offsetDateTimeField20.getMinimumValue();
        long long33 = offsetDateTimeField20.getDifferenceAsLong(0L, (-28800001L));
        org.joda.time.DurationField durationField34 = offsetDateTimeField20.getRangeDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-28800001L) + "'", long7 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-28800001L) + "'", long11 == (-28800001L));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-25199999) + "'", int30 == (-25199999));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(durationField34);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.standard();
        org.joda.time.DurationFieldType durationFieldType2 = periodType0.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField4 = new org.joda.time.field.PreciseDurationField(durationFieldType2, (long) (short) -1);
        long long7 = preciseDurationField4.add(107L, (int) (byte) 100);
        boolean boolean8 = preciseDurationField4.isSupported();
        long long11 = preciseDurationField4.getDifferenceAsLong((-27295726L), (-28799999L));
        java.lang.String str12 = preciseDurationField4.toString();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(durationFieldType2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 7L + "'", long7 == 7L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1504273L) + "'", long11 == (-1504273L));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DurationField[years]" + "'", str12.equals("DurationField[years]"));
    }

//    @Test
//    public void test03() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test03");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        org.joda.time.Period period5 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period7 = period5.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        org.joda.time.PeriodType periodType10 = null;
//        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
//        int int12 = period11.size();
//        org.joda.time.Period period14 = period11.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        long long17 = dateTimeZone15.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone18.getName((long) ' ', locale20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone18.getName((long) (byte) 0, locale23);
//        boolean boolean25 = period11.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period27 = period11.withYears((int) (byte) 100);
//        org.joda.time.Period period29 = new org.joda.time.Period(100L);
//        org.joda.time.Period period30 = period29.toPeriod();
//        int int31 = period29.getYears();
//        org.joda.time.Period period33 = period29.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType36 = periodType34.getFieldType(0);
//        int int37 = period33.get(durationFieldType36);
//        org.joda.time.Period period39 = period27.withFieldAdded(durationFieldType36, 2);
//        boolean boolean40 = period5.isSupported(durationFieldType36);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(durationFieldType36, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        boolean boolean45 = periodType2.isSupported(durationFieldType36);
//        org.joda.time.field.UnsupportedDurationField unsupportedDurationField46 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType36);
//        org.joda.time.DurationFieldType durationFieldType47 = unsupportedDurationField46.getType();
//        try {
//            long long50 = unsupportedDurationField46.getDifferenceAsLong((-1560626972550L), (long) '4');
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(period7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28800001L) + "'", long17 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Pacific Standard Time" + "'", str24.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(periodType34);
//        org.junit.Assert.assertNotNull(durationFieldType36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(period39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(unsupportedDurationField46);
//        org.junit.Assert.assertNotNull(durationFieldType47);
//    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType4 = periodType3.withSecondsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period(107L, (long) (-97), periodType4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        long long11 = dateTimeZone9.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology7, dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology12.halfdayOfDay();
        org.joda.time.DurationField durationField14 = zonedChronology12.minutes();
        org.joda.time.Period period15 = new org.joda.time.Period((-210866673600000L), periodType4, (org.joda.time.Chronology) zonedChronology12);
        org.joda.time.DateTimeField dateTimeField16 = zonedChronology12.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField17 = zonedChronology12.millisOfSecond();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-28800001L) + "'", long11 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.standard();
        org.joda.time.DurationFieldType durationFieldType2 = periodType0.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField4 = new org.joda.time.field.PreciseDurationField(durationFieldType2, (long) (short) -1);
        long long7 = preciseDurationField4.add(107L, (int) (byte) 100);
        long long10 = preciseDurationField4.add((long) (-28378000), 10);
        int int13 = preciseDurationField4.getDifference((long) (byte) 10, (long) (byte) 10);
        long long16 = preciseDurationField4.add((long) (-970), (-107));
        long long19 = preciseDurationField4.getMillis((-210782951940000L), (-174182393952000000L));
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(durationFieldType2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 7L + "'", long7 == 7L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-28378010L) + "'", long10 == (-28378010L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-863L) + "'", long16 == (-863L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 210782951940000L + "'", long19 == 210782951940000L);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", "");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str5 = illegalFieldValueException2.getFieldName();
        illegalFieldValueException2.prependMessage("Pacific Standard Time");
        org.joda.time.IllegalInstantException illegalInstantException10 = new org.joda.time.IllegalInstantException(28800000L, "PeriodType[Millis]");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalInstantException10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pacific Standard Time" + "'", str3.equals("Pacific Standard Time"));
        org.junit.Assert.assertNull(durationFieldType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pacific Standard Time" + "'", str5.equals("Pacific Standard Time"));
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.Period period8 = period6.withMonths((int) '4');
        org.joda.time.Period period10 = period8.minusSeconds((int) (short) 10);
        org.joda.time.PeriodType periodType11 = null;
        org.joda.time.Period period12 = period10.withPeriodType(periodType11);
        org.joda.time.MutablePeriod mutablePeriod13 = period10.toMutablePeriod();
        org.joda.time.Period period15 = period10.withMillis((int) (byte) 100);
        org.joda.time.DurationFieldType[] durationFieldTypeArray16 = period15.getFieldTypes();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(mutablePeriod13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(durationFieldTypeArray16);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 52, (java.lang.Number) (-1.0f), (java.lang.Number) (-863L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology1.dayOfMonth();
        try {
            long long16 = gregorianChronology1.getDateTimeMillis((int) '#', 385200000, (int) (byte) 100, 6, (-28800000), 1, 52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.joda.time.Period period2 = new org.joda.time.Period(100L);
        org.joda.time.Period period3 = period2.toPeriod();
        int int4 = period2.getYears();
        org.joda.time.Period period6 = period2.withMinutes((int) (byte) -1);
        org.joda.time.Duration duration7 = period6.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType10 = periodType9.withDaysRemoved();
        org.joda.time.Period period11 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration7, readableInstant8, periodType9);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        long long17 = dateTimeZone15.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology13, dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone19 = zonedChronology18.getZone();
        org.joda.time.DateTimeZone dateTimeZone20 = zonedChronology18.getZone();
        org.joda.time.Chronology chronology21 = zonedChronology18.withUTC();
        org.joda.time.Period period22 = new org.joda.time.Period(3745L, periodType9, chronology21);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28800001L) + "'", long17 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(chronology21);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType4 = periodType3.withSecondsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period(107L, (long) (-97), periodType4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        long long11 = dateTimeZone9.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology7, dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology12.halfdayOfDay();
        org.joda.time.DurationField durationField14 = zonedChronology12.minutes();
        org.joda.time.Period period15 = new org.joda.time.Period((-210866673600000L), periodType4, (org.joda.time.Chronology) zonedChronology12);
        org.joda.time.DateTimeField dateTimeField16 = zonedChronology12.secondOfMinute();
        org.joda.time.DurationField durationField17 = zonedChronology12.months();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology19.secondOfDay();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (-1));
        long long27 = gregorianChronology19.add((org.joda.time.ReadablePeriod) period24, 1560652172544L, 1);
        org.joda.time.Period period28 = period24.toPeriod();
        long long31 = zonedChronology12.add((org.joda.time.ReadablePeriod) period24, 31536000000L, 9);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-28800001L) + "'", long11 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560652172543L + "'", long27 == 1560652172543L);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31535999991L + "'", long31 == 31535999991L);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        java.lang.String str7 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology1.yearOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str7.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

//    @Test
//    public void test13() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test13");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        long long2 = dateTimeZone0.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName((long) ' ', locale5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        long long9 = dateTimeZone7.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
//        long long12 = dateTimeZone3.getMillisKeepLocal(dateTimeZone10, (long) (short) 10);
//        org.joda.time.LocalDateTime localDateTime13 = null;
//        try {
//            boolean boolean14 = dateTimeZone10.isLocalDateTimeGap(localDateTime13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-28800001L) + "'", long2 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Pacific Standard Time" + "'", str6.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-28800001L) + "'", long9 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
//    }

//    @Test
//    public void test14() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test14");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = cachedDateTimeZone4.getName(1L, locale6);
//        long long9 = cachedDateTimeZone4.nextTransition(0L);
//        long long11 = cachedDateTimeZone4.nextTransition(1L);
//        long long14 = cachedDateTimeZone4.adjustOffset((long) 0, false);
//        long long18 = cachedDateTimeZone4.convertLocalToUTC(0L, false, (long) (byte) 10);
//        boolean boolean19 = cachedDateTimeZone4.isFixed();
//        long long21 = cachedDateTimeZone4.nextTransition((long) ' ');
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
//        long long24 = dateTimeZone22.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeUtils.getZone(dateTimeZone22);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = dateTimeZone25.getName((long) ' ', locale27);
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
//        long long31 = dateTimeZone29.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone29);
//        long long34 = dateTimeZone25.getMillisKeepLocal(dateTimeZone32, (long) (short) 10);
//        long long38 = dateTimeZone32.convertLocalToUTC(0L, false, (-210858120000000L));
//        boolean boolean39 = cachedDateTimeZone4.equals((java.lang.Object) long38);
//        org.joda.time.ReadableInstant readableInstant40 = null;
//        int int41 = cachedDateTimeZone4.getOffset(readableInstant40);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9972000000L + "'", long9 == 9972000000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9972000000L + "'", long11 == 9972000000L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800000L + "'", long18 == 28800000L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9972000000L + "'", long21 == 9972000000L);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-28800001L) + "'", long24 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Pacific Standard Time" + "'", str28.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-28800001L) + "'", long31 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 28800000L + "'", long38 == 28800000L);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-28378000) + "'", int41 == (-28378000));
//    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("PST");
        java.lang.String str2 = jodaTimePermission1.toString();
        java.lang.String str3 = jodaTimePermission1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"PST\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"PST\")"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"PST\")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"PST\")"));
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalInstantException: Pacific Standard Time", (java.lang.Number) (-28378000), (java.lang.Number) 2, (java.lang.Number) (byte) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        org.junit.Assert.assertNull(dateTimeFieldType5);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "PeriodType[Weeks]", (int) 'a', (-970));
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        int int7 = fixedDateTimeZone4.getOffsetFromLocal(315532800107L);
        long long9 = fixedDateTimeZone4.previousTransition((-171630144000000000L));
        long long11 = fixedDateTimeZone4.nextTransition(1560652172543L);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-171630144000000000L) + "'", long9 == (-171630144000000000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560652172543L + "'", long11 == 1560652172543L);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType2 = periodType1.withMinutesRemoved();
        org.joda.time.Period period3 = new org.joda.time.Period(1560626963539L, periodType2);
        org.joda.time.PeriodType periodType4 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType5 = periodType2.withHoursRemoved();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
    }

//    @Test
//    public void test19() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test19");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone7 = zonedChronology6.getZone();
//        org.joda.time.DateTimeZone dateTimeZone8 = zonedChronology6.getZone();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        long long14 = dateTimeZone12.convertUTCToLocal((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology10, dateTimeZone12);
//        java.lang.String str17 = dateTimeZone12.getShortName(0L);
//        org.joda.time.Chronology chronology18 = zonedChronology6.withZone(dateTimeZone12);
//        try {
//            long long24 = zonedChronology6.getDateTimeMillis((long) 374, (-3745), 0, 107, (-4));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -3745 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-28800001L) + "'", long14 == (-28800001L));
//        org.junit.Assert.assertNotNull(zonedChronology15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PST" + "'", str17.equals("PST"));
//        org.junit.Assert.assertNotNull(chronology18);
//    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) (short) 100);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.joda.time.Period period1 = org.joda.time.Period.months((-97));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.joda.time.Period period4 = new org.joda.time.Period((int) '#', (int) (byte) 10, (int) '#', (int) '#');
        org.joda.time.Period period6 = period4.plusMinutes(7);
        org.junit.Assert.assertNotNull(period6);
    }

//    @Test
//    public void test23() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test23");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = cachedDateTimeZone4.getName(1L, locale6);
//        long long9 = cachedDateTimeZone4.nextTransition(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone11 = cachedDateTimeZone4.getUncachedZone();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9972000000L + "'", long9 == 9972000000L);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Chronology chronology6 = gregorianChronology1.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.millisOfSecond();
        org.joda.time.DurationField durationField8 = gregorianChronology1.centuries();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withYearsRemoved();
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        int int3 = periodType0.size();
        org.joda.time.PeriodType periodType4 = periodType0.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType4.withMinutesRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
    }

//    @Test
//    public void test26() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test26");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone7 = zonedChronology6.getZone();
//        org.joda.time.DateTimeZone dateTimeZone8 = zonedChronology6.getZone();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        long long14 = dateTimeZone12.convertUTCToLocal((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology10, dateTimeZone12);
//        java.lang.String str17 = dateTimeZone12.getShortName(0L);
//        org.joda.time.Chronology chronology18 = zonedChronology6.withZone(dateTimeZone12);
//        org.joda.time.DurationField durationField19 = zonedChronology6.centuries();
//        try {
//            long long22 = durationField19.subtract(6682L, (-230400000L));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 23040000000");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-28800001L) + "'", long14 == (-28800001L));
//        org.junit.Assert.assertNotNull(zonedChronology15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PST" + "'", str17.equals("PST"));
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(5);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.dayOfMonth();
        int int4 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant5, readableInstant6, periodType7);
        org.joda.time.Period period9 = period8.negated();
        org.joda.time.Period period11 = period9.minusYears((int) (byte) 0);
        int[] intArray13 = gregorianChronology1.get((org.joda.time.ReadablePeriod) period11, (-210782951940000L));
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology1.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology1.weekyear();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((-50612));
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(6682L, (-210866645222000L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -1409010923373404000");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology6.halfdayOfDay();
        org.joda.time.DurationField durationField8 = zonedChronology6.weeks();
        org.joda.time.DateTimeZone dateTimeZone9 = zonedChronology6.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.Period period5 = period3.plusMonths((int) '#');
        org.joda.time.Period period7 = period3.plusHours((int) (byte) 10);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
        int int12 = period11.size();
        org.joda.time.Period period14 = period11.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Duration duration16 = period11.toDurationFrom(readableInstant15);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType19 = periodType18.withSecondsRemoved();
        org.joda.time.Period period20 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration16, readableInstant17, periodType19);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        org.joda.time.DurationField durationField23 = gregorianChronology22.weekyears();
        org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) period7, periodType19, (org.joda.time.Chronology) gregorianChronology22);
        int int25 = periodType19.size();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(duration16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.Period period8 = period6.withMonths((int) '4');
        int int9 = period8.getWeeks();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

//    @Test
//    public void test34() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test34");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone7 = zonedChronology6.getZone();
//        org.joda.time.DateTimeZone dateTimeZone8 = zonedChronology6.getZone();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        long long14 = dateTimeZone12.convertUTCToLocal((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology10, dateTimeZone12);
//        java.lang.String str17 = dateTimeZone12.getShortName(0L);
//        org.joda.time.Chronology chronology18 = zonedChronology6.withZone(dateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone19 = zonedChronology6.getZone();
//        org.joda.time.DurationField durationField20 = zonedChronology6.eras();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-28800001L) + "'", long14 == (-28800001L));
//        org.junit.Assert.assertNotNull(zonedChronology15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PST" + "'", str17.equals("PST"));
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(durationField20);
//    }

//    @Test
//    public void test35() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test35");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("LMT");
//        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("PeriodType[Millis]");
//        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        long long10 = dateTimeZone8.convertUTCToLocal((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology6, dateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology11.getZone();
//        org.joda.time.DateTimeZone dateTimeZone13 = zonedChronology11.getZone();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        long long19 = dateTimeZone17.convertUTCToLocal((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology15, dateTimeZone17);
//        java.lang.String str22 = dateTimeZone17.getShortName(0L);
//        org.joda.time.Chronology chronology23 = zonedChronology11.withZone(dateTimeZone17);
//        org.joda.time.DurationField durationField24 = zonedChronology11.weeks();
//        boolean boolean25 = jodaTimePermission1.equals((java.lang.Object) durationField24);
//        org.joda.time.ReadableInstant readableInstant26 = null;
//        org.joda.time.ReadableInstant readableInstant27 = null;
//        org.joda.time.PeriodType periodType28 = null;
//        org.joda.time.Period period29 = new org.joda.time.Period(readableInstant26, readableInstant27, periodType28);
//        int int30 = period29.size();
//        org.joda.time.Period period32 = period29.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.getDefault();
//        long long35 = dateTimeZone33.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeUtils.getZone(dateTimeZone33);
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = dateTimeZone36.getName((long) ' ', locale38);
//        java.util.Locale locale41 = null;
//        java.lang.String str42 = dateTimeZone36.getName((long) (byte) 0, locale41);
//        boolean boolean43 = period29.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period45 = period29.withYears((int) (byte) 100);
//        org.joda.time.Period period47 = period29.plusDays((int) (short) -1);
//        org.joda.time.Days days48 = period29.toStandardDays();
//        jodaTimePermission1.checkGuard((java.lang.Object) period29);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-28800001L) + "'", long10 == (-28800001L));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-28800001L) + "'", long19 == (-28800001L));
//        org.junit.Assert.assertNotNull(zonedChronology20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "PST" + "'", str22.equals("PST"));
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 8 + "'", int30 == 8);
//        org.junit.Assert.assertNotNull(period32);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-28800001L) + "'", long35 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Pacific Standard Time" + "'", str39.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Pacific Standard Time" + "'", str42.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(period45);
//        org.junit.Assert.assertNotNull(period47);
//        org.junit.Assert.assertNotNull(days48);
//    }

//    @Test
//    public void test36() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test36");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        long long3 = dateTimeZone1.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName((long) ' ', locale6);
//        org.joda.time.Chronology chronology8 = iSOChronology0.withZone(dateTimeZone4);
//        org.joda.time.Period period10 = org.joda.time.Period.seconds(100);
//        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.weeks();
//        org.joda.time.PeriodType periodType12 = periodType11.withYearsRemoved();
//        org.joda.time.Period period13 = period10.normalizedStandard(periodType12);
//        boolean boolean14 = iSOChronology0.equals((java.lang.Object) period10);
//        org.joda.time.Period period16 = period10.minusMonths((int) (short) 10);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-28800001L) + "'", long3 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(period10);
//        org.junit.Assert.assertNotNull(periodType11);
//        org.junit.Assert.assertNotNull(periodType12);
//        org.junit.Assert.assertNotNull(period13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(period16);
//    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.dayOfMonth();
        int int4 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(chronology5);
    }

//    @Test
//    public void test38() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test38");
//        org.joda.time.Period period1 = org.joda.time.Period.seconds(100);
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.weeks();
//        org.joda.time.PeriodType periodType3 = periodType2.withYearsRemoved();
//        org.joda.time.Period period4 = period1.normalizedStandard(periodType3);
//        org.joda.time.Period period6 = period1.withWeeks((int) (short) -1);
//        org.joda.time.ReadableInstant readableInstant7 = null;
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.PeriodType periodType9 = null;
//        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant7, readableInstant8, periodType9);
//        int int11 = period10.size();
//        org.joda.time.Period period13 = period10.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        long long16 = dateTimeZone14.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) ' ', locale19);
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = dateTimeZone17.getName((long) (byte) 0, locale22);
//        boolean boolean24 = period10.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period26 = period10.withYears((int) (byte) 100);
//        org.joda.time.Period period28 = new org.joda.time.Period(100L);
//        org.joda.time.Period period29 = period28.toPeriod();
//        int int30 = period28.getYears();
//        org.joda.time.Period period32 = period28.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType33 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType35 = periodType33.getFieldType(0);
//        int int36 = period32.get(durationFieldType35);
//        org.joda.time.Period period38 = period26.withFieldAdded(durationFieldType35, 2);
//        boolean boolean39 = period6.isSupported(durationFieldType35);
//        org.joda.time.Period period41 = period6.plusYears(97);
//        org.junit.Assert.assertNotNull(period1);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(periodType3);
//        org.junit.Assert.assertNotNull(period4);
//        org.junit.Assert.assertNotNull(period6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
//        org.junit.Assert.assertNotNull(period13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-28800001L) + "'", long16 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Pacific Standard Time" + "'", str20.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Pacific Standard Time" + "'", str23.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertNotNull(period29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(period32);
//        org.junit.Assert.assertNotNull(periodType33);
//        org.junit.Assert.assertNotNull(durationFieldType35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(period38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertNotNull(period41);
//    }

//    @Test
//    public void test39() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test39");
//        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) 10);
//        org.joda.time.Period period3 = period1.multipliedBy((int) 'a');
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.Duration duration5 = period3.toDurationTo(readableInstant4);
//        long long6 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration5);
//        org.junit.Assert.assertNotNull(period1);
//        org.junit.Assert.assertNotNull(period3);
//        org.junit.Assert.assertNotNull(duration5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 586656000000L + "'", long6 == 586656000000L);
//    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType4);
        int int6 = period5.size();
        org.joda.time.Period period8 = period5.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Duration duration10 = period5.toDurationFrom(readableInstant9);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.PeriodType periodType12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration10, readableInstant11, periodType12);
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration10);
        long long15 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration10);
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration10);
        java.lang.String str17 = period16.toString();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.standard();
        org.joda.time.DurationFieldType durationFieldType20 = periodType18.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField22 = new org.joda.time.field.PreciseDurationField(durationFieldType20, (long) (short) -1);
        org.joda.time.Period period24 = period16.withFieldAdded(durationFieldType20, (-25199999));
        org.joda.time.Days days25 = period16.toStandardDays();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(duration10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PT0S" + "'", str17.equals("PT0S"));
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(days25);
    }

//    @Test
//    public void test41() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test41");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField7 = zonedChronology6.halfdayOfDay();
//        org.joda.time.DurationField durationField8 = zonedChronology6.weeks();
//        org.joda.time.Period period10 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period12 = period10.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.ReadableInstant readableInstant14 = null;
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant13, readableInstant14, periodType15);
//        int int17 = period16.size();
//        org.joda.time.Period period19 = period16.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        long long22 = dateTimeZone20.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = dateTimeZone23.getName((long) ' ', locale25);
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = dateTimeZone23.getName((long) (byte) 0, locale28);
//        boolean boolean30 = period16.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period32 = period16.withYears((int) (byte) 100);
//        org.joda.time.Period period34 = new org.joda.time.Period(100L);
//        org.joda.time.Period period35 = period34.toPeriod();
//        int int36 = period34.getYears();
//        org.joda.time.Period period38 = period34.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType41 = periodType39.getFieldType(0);
//        int int42 = period38.get(durationFieldType41);
//        org.joda.time.Period period44 = period32.withFieldAdded(durationFieldType41, 2);
//        boolean boolean45 = period10.isSupported(durationFieldType41);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException49 = new org.joda.time.IllegalFieldValueException(durationFieldType41, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        org.joda.time.field.ScaledDurationField scaledDurationField51 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType41, (int) (short) 10);
//        long long54 = scaledDurationField51.getDifferenceAsLong((-53509900L), 0L);
//        long long57 = scaledDurationField51.getValueAsLong((long) 6, (long) 970);
//        int int59 = scaledDurationField51.getValue(6682L);
//        long long62 = scaledDurationField51.getMillis(10, (long) '#');
//        boolean boolean63 = scaledDurationField51.isSupported();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(period10);
//        org.junit.Assert.assertNotNull(period12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-28800001L) + "'", long22 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Pacific Standard Time" + "'", str26.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Pacific Standard Time" + "'", str29.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(period32);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(period38);
//        org.junit.Assert.assertNotNull(periodType39);
//        org.junit.Assert.assertNotNull(durationFieldType41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(period44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 60480000000L + "'", long62 == 60480000000L);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
//    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.PeriodType periodType5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant3, readableInstant4, periodType5);
        int int7 = period6.size();
        org.joda.time.Period period9 = period6.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period6.toDurationFrom(readableInstant10);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.PeriodType periodType13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration11, readableInstant12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant2, (org.joda.time.ReadableDuration) duration11);
        long long16 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration11);
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration11);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType20 = periodType19.withYearsRemoved();
        org.joda.time.PeriodType periodType21 = org.joda.time.DateTimeUtils.getPeriodType(periodType19);
        int int22 = periodType19.size();
        org.joda.time.Period period23 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration11, readableInstant18, periodType19);
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration11);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 5 + "'", int22 == 5);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test43");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.dayOfMonth();
        int int4 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField5 = gregorianChronology1.eras();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(durationField5);
    }

//    @Test
//    public void test44() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test44");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = cachedDateTimeZone4.getName(1L, locale6);
//        long long9 = cachedDateTimeZone4.nextTransition(0L);
//        long long11 = cachedDateTimeZone4.nextTransition(1L);
//        long long14 = cachedDateTimeZone4.adjustOffset((long) 0, false);
//        long long18 = cachedDateTimeZone4.convertLocalToUTC(0L, false, (long) (byte) 10);
//        boolean boolean19 = cachedDateTimeZone4.isFixed();
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9972000000L + "'", long9 == 9972000000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9972000000L + "'", long11 == 9972000000L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800000L + "'", long18 == 28800000L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test45");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-28800001L), 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

//    @Test
//    public void test46() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test46");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        long long2 = dateTimeZone0.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        int int5 = dateTimeZone0.getOffsetFromLocal((long) (byte) 0);
//        java.lang.String str7 = dateTimeZone0.getShortName((long) (byte) -1);
//        long long11 = dateTimeZone0.convertLocalToUTC((long) (byte) 10, true, (long) (byte) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.centuryOfEra();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-28800001L) + "'", long2 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800010L + "'", long11 == 28800010L);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//    }

//    @Test
//    public void test47() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test47");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        org.joda.time.Period period5 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period7 = period5.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        org.joda.time.PeriodType periodType10 = null;
//        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
//        int int12 = period11.size();
//        org.joda.time.Period period14 = period11.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        long long17 = dateTimeZone15.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone18.getName((long) ' ', locale20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone18.getName((long) (byte) 0, locale23);
//        boolean boolean25 = period11.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period27 = period11.withYears((int) (byte) 100);
//        org.joda.time.Period period29 = new org.joda.time.Period(100L);
//        org.joda.time.Period period30 = period29.toPeriod();
//        int int31 = period29.getYears();
//        org.joda.time.Period period33 = period29.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType36 = periodType34.getFieldType(0);
//        int int37 = period33.get(durationFieldType36);
//        org.joda.time.Period period39 = period27.withFieldAdded(durationFieldType36, 2);
//        boolean boolean40 = period5.isSupported(durationFieldType36);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(durationFieldType36, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        boolean boolean45 = periodType2.isSupported(durationFieldType36);
//        org.joda.time.field.UnsupportedDurationField unsupportedDurationField46 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType36);
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone47);
//        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology48.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.getDefault();
//        long long52 = dateTimeZone50.convertUTCToLocal((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology53 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology48, dateTimeZone50);
//        org.joda.time.DateTimeField dateTimeField54 = zonedChronology53.halfdayOfDay();
//        java.util.TimeZone timeZone55 = null;
//        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeZone.forTimeZone(timeZone55);
//        int int58 = dateTimeZone56.getOffsetFromLocal(0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone59 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone56);
//        int int61 = cachedDateTimeZone59.getOffsetFromLocal((long) (-28800000));
//        int int63 = cachedDateTimeZone59.getOffset((long) (byte) 0);
//        org.joda.time.Chronology chronology64 = zonedChronology53.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone59);
//        boolean boolean65 = unsupportedDurationField46.equals((java.lang.Object) cachedDateTimeZone59);
//        boolean boolean66 = unsupportedDurationField46.isPrecise();
//        try {
//            long long69 = unsupportedDurationField46.getMillis(0L, 28800107L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(period7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28800001L) + "'", long17 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Pacific Standard Time" + "'", str24.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(periodType34);
//        org.junit.Assert.assertNotNull(durationFieldType36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(period39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(unsupportedDurationField46);
//        org.junit.Assert.assertNotNull(gregorianChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-28800001L) + "'", long52 == (-28800001L));
//        org.junit.Assert.assertNotNull(zonedChronology53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertNotNull(dateTimeZone56);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-28800000) + "'", int58 == (-28800000));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone59);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-28800000) + "'", int61 == (-28800000));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-28800000) + "'", int63 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology64);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
//    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test48");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant1, readableInstant2, periodType3);
        int int5 = period4.size();
        org.joda.time.Period period7 = period4.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Duration duration9 = period4.toDurationFrom(readableInstant8);
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration9);
        org.joda.time.MutablePeriod mutablePeriod11 = period10.toMutablePeriod();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Duration duration13 = period10.toDurationFrom(readableInstant12);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertNotNull(mutablePeriod11);
        org.junit.Assert.assertNotNull(duration13);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test49");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period3.toDurationFrom(readableInstant7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant9, periodType10);
        org.joda.time.Period period13 = period11.plusMinutes((int) '4');
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.PeriodType periodType16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant14, readableInstant15, periodType16);
        int int18 = period17.size();
        org.joda.time.Period period20 = period17.plusMonths((int) '#');
        org.joda.time.Period period22 = period20.withMonths((int) '4');
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.PeriodType periodType25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant23, readableInstant24, periodType25);
        int int27 = period26.size();
        org.joda.time.Period period29 = period26.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.Duration duration31 = period26.toDurationFrom(readableInstant30);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.PeriodType periodType33 = null;
        org.joda.time.Period period34 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration31, readableInstant32, periodType33);
        org.joda.time.Period period36 = period34.plusMinutes((int) '4');
        org.joda.time.Period period37 = period20.plus((org.joda.time.ReadablePeriod) period36);
        org.joda.time.Period period39 = period37.withYears(100);
        org.joda.time.Period period41 = period39.plusMonths(1);
        org.joda.time.Period period42 = period11.withFields((org.joda.time.ReadablePeriod) period39);
        try {
            org.joda.time.Seconds seconds43 = period39.toStandardSeconds();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Seconds as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 8 + "'", int27 == 8);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(duration31);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(period42);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test50");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        long long7 = dateTimeZone5.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        long long11 = dateTimeZone9.convertUTCToLocal((-1L));
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        boolean boolean13 = zonedChronology8.equals((java.lang.Object) dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology8.dayOfWeek();
        org.joda.time.Chronology chronology15 = zonedChronology8.withUTC();
        org.joda.time.Period period16 = new org.joda.time.Period((long) 7, (-210866673600000L), (org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTimeField dateTimeField17 = zonedChronology8.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField18 = zonedChronology8.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (-25200000));
        boolean boolean21 = offsetDateTimeField20.isSupported();
        java.lang.String str22 = offsetDateTimeField20.getName();
        long long24 = offsetDateTimeField20.roundCeiling((long) 7);
        long long27 = offsetDateTimeField20.getDifferenceAsLong((-776L), (-4L));
        org.joda.time.ReadablePartial readablePartial28 = null;
        int int29 = offsetDateTimeField20.getMaximumValue(readablePartial28);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-28800001L) + "'", long7 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-28800001L) + "'", long11 == (-28800001L));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "weekyearOfCentury" + "'", str22.equals("weekyearOfCentury"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 31824000000L + "'", long24 == 31824000000L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-25199900) + "'", int29 == (-25199900));
    }

//    @Test
//    public void test51() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test51");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField7 = zonedChronology6.halfdayOfDay();
//        org.joda.time.DurationField durationField8 = zonedChronology6.weeks();
//        org.joda.time.Period period10 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period12 = period10.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.ReadableInstant readableInstant14 = null;
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant13, readableInstant14, periodType15);
//        int int17 = period16.size();
//        org.joda.time.Period period19 = period16.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        long long22 = dateTimeZone20.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = dateTimeZone23.getName((long) ' ', locale25);
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = dateTimeZone23.getName((long) (byte) 0, locale28);
//        boolean boolean30 = period16.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period32 = period16.withYears((int) (byte) 100);
//        org.joda.time.Period period34 = new org.joda.time.Period(100L);
//        org.joda.time.Period period35 = period34.toPeriod();
//        int int36 = period34.getYears();
//        org.joda.time.Period period38 = period34.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType41 = periodType39.getFieldType(0);
//        int int42 = period38.get(durationFieldType41);
//        org.joda.time.Period period44 = period32.withFieldAdded(durationFieldType41, 2);
//        boolean boolean45 = period10.isSupported(durationFieldType41);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException49 = new org.joda.time.IllegalFieldValueException(durationFieldType41, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        org.joda.time.field.ScaledDurationField scaledDurationField51 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType41, (int) (short) 10);
//        org.joda.time.DurationField durationField52 = scaledDurationField51.getWrappedField();
//        long long54 = scaledDurationField51.getValueAsLong((-53509900L));
//        long long56 = scaledDurationField51.getMillis((long) (-28378000));
//        long long57 = scaledDurationField51.getUnitMillis();
//        long long58 = scaledDurationField51.getUnitMillis();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(period10);
//        org.junit.Assert.assertNotNull(period12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-28800001L) + "'", long22 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Pacific Standard Time" + "'", str26.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Pacific Standard Time" + "'", str29.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(period32);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(period38);
//        org.junit.Assert.assertNotNull(periodType39);
//        org.junit.Assert.assertNotNull(durationFieldType41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(period44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-171630144000000000L) + "'", long56 == (-171630144000000000L));
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 6048000000L + "'", long57 == 6048000000L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 6048000000L + "'", long58 == 6048000000L);
//    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test52");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("-25199929", "Seconds", (-25199999), 0);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test53");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "PeriodType[Weeks]", (int) 'a', (-970));
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        long long7 = fixedDateTimeZone4.nextTransition((long) (-107));
        long long9 = fixedDateTimeZone4.previousTransition(2440588L);
        int int11 = fixedDateTimeZone4.getOffset(315532800107L);
        long long13 = fixedDateTimeZone4.convertUTCToLocal((long) 4);
        boolean boolean14 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-107L) + "'", long7 == (-107L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2440588L + "'", long9 == 2440588L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 97 + "'", int11 == 97);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 101L + "'", long13 == 101L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test54");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        org.joda.time.Chronology chronology8 = gregorianChronology3.withZone(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology3.dayOfWeek();
        org.joda.time.Period period10 = new org.joda.time.Period((long) (-25199999), 28800000L, (org.joda.time.Chronology) gregorianChronology3);
        java.lang.String str11 = gregorianChronology3.toString();
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str11.equals("GregorianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test55");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        long long7 = dateTimeZone5.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        long long11 = dateTimeZone9.convertUTCToLocal((-1L));
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        boolean boolean13 = zonedChronology8.equals((java.lang.Object) dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology8.dayOfWeek();
        org.joda.time.Chronology chronology15 = zonedChronology8.withUTC();
        org.joda.time.Period period16 = new org.joda.time.Period((long) 7, (-210866673600000L), (org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTimeField dateTimeField17 = zonedChronology8.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField18 = zonedChronology8.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (-25200000));
        boolean boolean21 = offsetDateTimeField20.isSupported();
        java.lang.String str22 = offsetDateTimeField20.getName();
        int int23 = offsetDateTimeField20.getMaximumValue();
        org.joda.time.DurationField durationField24 = offsetDateTimeField20.getRangeDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-28800001L) + "'", long7 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-28800001L) + "'", long11 == (-28800001L));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "weekyearOfCentury" + "'", str22.equals("weekyearOfCentury"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-25199900) + "'", int23 == (-25199900));
        org.junit.Assert.assertNotNull(durationField24);
    }

//    @Test
//    public void test56() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test56");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        int int6 = cachedDateTimeZone4.getOffsetFromLocal((long) (-28800000));
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone4, 1);
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.yearOfCentury();
//        long long13 = gregorianChronology8.add((long) 1, 0L, (int) (byte) 1);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology8.dayOfYear();
//        org.joda.time.DurationField durationField15 = gregorianChronology8.hours();
//        java.util.TimeZone timeZone16 = null;
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forTimeZone(timeZone16);
//        int int19 = dateTimeZone17.getOffsetFromLocal(0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone20 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone17);
//        int int22 = cachedDateTimeZone20.getOffsetFromLocal((long) (-28800000));
//        boolean boolean23 = cachedDateTimeZone20.isFixed();
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = cachedDateTimeZone20.getShortName((long) 107, locale25);
//        java.lang.String str28 = cachedDateTimeZone20.getNameKey(7L);
//        org.joda.time.Chronology chronology29 = gregorianChronology8.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-28800000) + "'", int6 == (-28800000));
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-28800000) + "'", int19 == (-28800000));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-28800000) + "'", int22 == (-28800000));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "PST" + "'", str26.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "PST" + "'", str28.equals("PST"));
//        org.junit.Assert.assertNotNull(chronology29);
//    }

//    @Test
//    public void test57() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test57");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        long long9 = dateTimeZone7.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
//        boolean boolean11 = zonedChronology6.equals((java.lang.Object) dateTimeZone7);
//        org.joda.time.DateTimeField dateTimeField12 = zonedChronology6.dayOfWeek();
//        java.util.TimeZone timeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
//        int int16 = dateTimeZone14.getOffsetFromLocal(0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = cachedDateTimeZone17.getName(1L, locale19);
//        long long22 = cachedDateTimeZone17.nextTransition(0L);
//        long long24 = cachedDateTimeZone17.nextTransition(1L);
//        long long27 = cachedDateTimeZone17.adjustOffset((long) 0, false);
//        long long31 = cachedDateTimeZone17.convertLocalToUTC(0L, false, (long) (byte) 10);
//        boolean boolean32 = cachedDateTimeZone17.isFixed();
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone17);
//        org.joda.time.chrono.ZonedChronology zonedChronology34 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) zonedChronology6, (org.joda.time.DateTimeZone) cachedDateTimeZone17);
//        boolean boolean35 = cachedDateTimeZone17.isFixed();
//        int int37 = cachedDateTimeZone17.getOffset((long) (-107));
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-28800001L) + "'", long9 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-28800000) + "'", int16 == (-28800000));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Pacific Standard Time" + "'", str20.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 9972000000L + "'", long22 == 9972000000L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9972000000L + "'", long24 == 9972000000L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 28800000L + "'", long31 == 28800000L);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(zonedChronology34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-28800000) + "'", int37 == (-28800000));
//    }

//    @Test
//    public void test58() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test58");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField7 = zonedChronology6.halfdayOfDay();
//        org.joda.time.DurationField durationField8 = zonedChronology6.weeks();
//        org.joda.time.Period period10 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period12 = period10.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.ReadableInstant readableInstant14 = null;
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant13, readableInstant14, periodType15);
//        int int17 = period16.size();
//        org.joda.time.Period period19 = period16.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        long long22 = dateTimeZone20.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = dateTimeZone23.getName((long) ' ', locale25);
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = dateTimeZone23.getName((long) (byte) 0, locale28);
//        boolean boolean30 = period16.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period32 = period16.withYears((int) (byte) 100);
//        org.joda.time.Period period34 = new org.joda.time.Period(100L);
//        org.joda.time.Period period35 = period34.toPeriod();
//        int int36 = period34.getYears();
//        org.joda.time.Period period38 = period34.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType41 = periodType39.getFieldType(0);
//        int int42 = period38.get(durationFieldType41);
//        org.joda.time.Period period44 = period32.withFieldAdded(durationFieldType41, 2);
//        boolean boolean45 = period10.isSupported(durationFieldType41);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException49 = new org.joda.time.IllegalFieldValueException(durationFieldType41, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        org.joda.time.field.ScaledDurationField scaledDurationField51 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType41, (int) (short) 10);
//        org.joda.time.DurationField durationField52 = scaledDurationField51.getWrappedField();
//        int int54 = scaledDurationField51.getValue((long) 5);
//        org.joda.time.DateTimeZone dateTimeZone55 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone55);
//        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology56.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.getDefault();
//        long long60 = dateTimeZone58.convertUTCToLocal((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology61 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology56, dateTimeZone58);
//        org.joda.time.DateTimeField dateTimeField62 = zonedChronology61.halfdayOfDay();
//        java.util.TimeZone timeZone63 = null;
//        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.forTimeZone(timeZone63);
//        int int66 = dateTimeZone64.getOffsetFromLocal(0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone67 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone64);
//        int int69 = cachedDateTimeZone67.getOffsetFromLocal((long) (-28800000));
//        int int71 = cachedDateTimeZone67.getOffset((long) (byte) 0);
//        org.joda.time.Chronology chronology72 = zonedChronology61.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone67);
//        org.joda.time.DateTimeField dateTimeField73 = zonedChronology61.clockhourOfDay();
//        boolean boolean74 = scaledDurationField51.equals((java.lang.Object) zonedChronology61);
//        java.util.TimeZone timeZone75 = null;
//        org.joda.time.DateTimeZone dateTimeZone76 = org.joda.time.DateTimeZone.forTimeZone(timeZone75);
//        int int78 = dateTimeZone76.getOffsetFromLocal(0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone79 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone76);
//        int int81 = cachedDateTimeZone79.getOffsetFromLocal((long) (-28800000));
//        org.joda.time.chrono.GregorianChronology gregorianChronology83 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone79, 1);
//        org.joda.time.DateTimeField dateTimeField84 = gregorianChronology83.yearOfCentury();
//        long long88 = gregorianChronology83.add((long) 1, 0L, (int) (byte) 1);
//        org.joda.time.DateTimeField dateTimeField89 = gregorianChronology83.minuteOfHour();
//        boolean boolean90 = scaledDurationField51.equals((java.lang.Object) dateTimeField89);
//        try {
//            long long93 = scaledDurationField51.getMillis((-171630144000000000L), 28800374L);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -1716301440000000000 * 604800000");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(period10);
//        org.junit.Assert.assertNotNull(period12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-28800001L) + "'", long22 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Pacific Standard Time" + "'", str26.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Pacific Standard Time" + "'", str29.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(period32);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(period38);
//        org.junit.Assert.assertNotNull(periodType39);
//        org.junit.Assert.assertNotNull(durationFieldType41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(period44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology56);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-28800001L) + "'", long60 == (-28800001L));
//        org.junit.Assert.assertNotNull(zonedChronology61);
//        org.junit.Assert.assertNotNull(dateTimeField62);
//        org.junit.Assert.assertNotNull(dateTimeZone64);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-28800000) + "'", int66 == (-28800000));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone67);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-28800000) + "'", int69 == (-28800000));
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-28800000) + "'", int71 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology72);
//        org.junit.Assert.assertNotNull(dateTimeField73);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone76);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-28800000) + "'", int78 == (-28800000));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone79);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + (-28800000) + "'", int81 == (-28800000));
//        org.junit.Assert.assertNotNull(gregorianChronology83);
//        org.junit.Assert.assertNotNull(dateTimeField84);
//        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 1L + "'", long88 == 1L);
//        org.junit.Assert.assertNotNull(dateTimeField89);
//        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
//    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test59");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        long long9 = dateTimeZone7.convertUTCToLocal((-1L));
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        boolean boolean11 = zonedChronology6.equals((java.lang.Object) dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField12 = zonedChronology6.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone13 = zonedChronology6.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        boolean boolean16 = dateTimeZone13.isStandardOffset(0L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-28800001L) + "'", long9 == (-28800001L));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

//    @Test
//    public void test60() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test60");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField7 = zonedChronology6.halfdayOfDay();
//        org.joda.time.DurationField durationField8 = zonedChronology6.weeks();
//        org.joda.time.Period period10 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period12 = period10.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.ReadableInstant readableInstant14 = null;
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant13, readableInstant14, periodType15);
//        int int17 = period16.size();
//        org.joda.time.Period period19 = period16.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        long long22 = dateTimeZone20.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = dateTimeZone23.getName((long) ' ', locale25);
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = dateTimeZone23.getName((long) (byte) 0, locale28);
//        boolean boolean30 = period16.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period32 = period16.withYears((int) (byte) 100);
//        org.joda.time.Period period34 = new org.joda.time.Period(100L);
//        org.joda.time.Period period35 = period34.toPeriod();
//        int int36 = period34.getYears();
//        org.joda.time.Period period38 = period34.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType41 = periodType39.getFieldType(0);
//        int int42 = period38.get(durationFieldType41);
//        org.joda.time.Period period44 = period32.withFieldAdded(durationFieldType41, 2);
//        boolean boolean45 = period10.isSupported(durationFieldType41);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException49 = new org.joda.time.IllegalFieldValueException(durationFieldType41, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        org.joda.time.field.ScaledDurationField scaledDurationField51 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType41, (int) (short) 10);
//        long long54 = scaledDurationField51.getDifferenceAsLong((-53509900L), 0L);
//        long long57 = scaledDurationField51.add((-4L), (int) (byte) 100);
//        long long59 = scaledDurationField51.getValueAsLong((long) 5);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(period10);
//        org.junit.Assert.assertNotNull(period12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-28800001L) + "'", long22 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Pacific Standard Time" + "'", str26.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Pacific Standard Time" + "'", str29.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(period32);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(period38);
//        org.junit.Assert.assertNotNull(periodType39);
//        org.junit.Assert.assertNotNull(durationFieldType41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(period44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 604799999996L + "'", long57 == 604799999996L);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 0L + "'", long59 == 0L);
//    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test61");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        long long11 = zonedChronology6.getDateTimeMillis((-97), 5, 1, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField12 = zonedChronology6.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-65217888421990L) + "'", long11 == (-65217888421990L));
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test62");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Hours hours3 = period2.toStandardHours();
        org.joda.time.Duration duration4 = period2.toStandardDuration();
        org.joda.time.Period period6 = period2.plusMinutes((-25199999));
        org.junit.Assert.assertNotNull(hours3);
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(period6);
    }

//    @Test
//    public void test63() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test63");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField7 = zonedChronology6.halfdayOfDay();
//        org.joda.time.DurationField durationField8 = zonedChronology6.weeks();
//        org.joda.time.Period period10 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period12 = period10.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.ReadableInstant readableInstant14 = null;
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant13, readableInstant14, periodType15);
//        int int17 = period16.size();
//        org.joda.time.Period period19 = period16.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        long long22 = dateTimeZone20.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = dateTimeZone23.getName((long) ' ', locale25);
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = dateTimeZone23.getName((long) (byte) 0, locale28);
//        boolean boolean30 = period16.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period32 = period16.withYears((int) (byte) 100);
//        org.joda.time.Period period34 = new org.joda.time.Period(100L);
//        org.joda.time.Period period35 = period34.toPeriod();
//        int int36 = period34.getYears();
//        org.joda.time.Period period38 = period34.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType41 = periodType39.getFieldType(0);
//        int int42 = period38.get(durationFieldType41);
//        org.joda.time.Period period44 = period32.withFieldAdded(durationFieldType41, 2);
//        boolean boolean45 = period10.isSupported(durationFieldType41);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException49 = new org.joda.time.IllegalFieldValueException(durationFieldType41, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        org.joda.time.field.ScaledDurationField scaledDurationField51 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType41, (int) (short) 10);
//        org.joda.time.DurationField durationField52 = scaledDurationField51.getWrappedField();
//        int int54 = scaledDurationField51.getValue((long) 5);
//        org.joda.time.DateTimeZone dateTimeZone55 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone55);
//        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology56.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.getDefault();
//        long long60 = dateTimeZone58.convertUTCToLocal((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology61 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology56, dateTimeZone58);
//        org.joda.time.DateTimeField dateTimeField62 = zonedChronology61.halfdayOfDay();
//        java.util.TimeZone timeZone63 = null;
//        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.forTimeZone(timeZone63);
//        int int66 = dateTimeZone64.getOffsetFromLocal(0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone67 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone64);
//        int int69 = cachedDateTimeZone67.getOffsetFromLocal((long) (-28800000));
//        int int71 = cachedDateTimeZone67.getOffset((long) (byte) 0);
//        org.joda.time.Chronology chronology72 = zonedChronology61.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone67);
//        org.joda.time.DateTimeField dateTimeField73 = zonedChronology61.clockhourOfDay();
//        boolean boolean74 = scaledDurationField51.equals((java.lang.Object) zonedChronology61);
//        int int77 = scaledDurationField51.getDifference(28800001L, (-30610166822000L));
//        long long78 = scaledDurationField51.getUnitMillis();
//        long long81 = scaledDurationField51.getValueAsLong((-25199900L), 3067541999996L);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(period10);
//        org.junit.Assert.assertNotNull(period12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-28800001L) + "'", long22 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Pacific Standard Time" + "'", str26.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Pacific Standard Time" + "'", str29.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(period32);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(period38);
//        org.junit.Assert.assertNotNull(periodType39);
//        org.junit.Assert.assertNotNull(durationFieldType41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(period44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology56);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-28800001L) + "'", long60 == (-28800001L));
//        org.junit.Assert.assertNotNull(zonedChronology61);
//        org.junit.Assert.assertNotNull(dateTimeField62);
//        org.junit.Assert.assertNotNull(dateTimeZone64);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-28800000) + "'", int66 == (-28800000));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone67);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-28800000) + "'", int69 == (-28800000));
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-28800000) + "'", int71 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology72);
//        org.junit.Assert.assertNotNull(dateTimeField73);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 5061 + "'", int77 == 5061);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 6048000000L + "'", long78 == 6048000000L);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 0L + "'", long81 == 0L);
//    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test64");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "DurationField[years]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test65");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        int int3 = periodType2.size();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.Period period6 = period4.plusWeeks(2);
        org.joda.time.Period period7 = period4.normalizedStandard();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test66");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        long long7 = dateTimeZone5.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        long long11 = dateTimeZone9.convertUTCToLocal((-1L));
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        boolean boolean13 = zonedChronology8.equals((java.lang.Object) dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology8.dayOfWeek();
        org.joda.time.Chronology chronology15 = zonedChronology8.withUTC();
        org.joda.time.Period period16 = new org.joda.time.Period((long) 7, (-210866673600000L), (org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTimeField dateTimeField17 = zonedChronology8.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField18 = zonedChronology8.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (-25200000));
        long long22 = offsetDateTimeField20.roundHalfFloor((long) (short) -1);
        int int25 = offsetDateTimeField20.getDifference(0L, (-1L));
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField20.getAsShortText((int) '#', locale27);
        java.lang.String str29 = offsetDateTimeField20.toString();
        int int31 = offsetDateTimeField20.getMinimumValue((-604799999996L));
        org.joda.time.DurationField durationField32 = offsetDateTimeField20.getLeapDurationField();
        long long34 = offsetDateTimeField20.remainder((long) (-25199999));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-28800001L) + "'", long7 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-28800001L) + "'", long11 == (-28800001L));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-230400000L) + "'", long22 == (-230400000L));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "35" + "'", str28.equals("35"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "DateTimeField[weekyearOfCentury]" + "'", str29.equals("DateTimeField[weekyearOfCentury]"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-25199999) + "'", int31 == (-25199999));
        org.junit.Assert.assertNull(durationField32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 205200001L + "'", long34 == 205200001L);
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test67");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.Period period8 = period6.withMonths((int) '4');
        org.joda.time.Period period10 = period6.plusMinutes((int) (short) 10);
        org.joda.time.Period period12 = period10.minusYears(0);
        org.joda.time.Period period14 = new org.joda.time.Period(100L);
        org.joda.time.Period period15 = period12.plus((org.joda.time.ReadablePeriod) period14);
        org.joda.time.Period period17 = period14.plusWeeks(5);
        org.joda.time.Minutes minutes18 = period17.toStandardMinutes();
        org.joda.time.Period period20 = period17.minusMinutes(6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(minutes18);
        org.junit.Assert.assertNotNull(period20);
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test68");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        long long7 = dateTimeZone5.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        long long11 = dateTimeZone9.convertUTCToLocal((-1L));
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        boolean boolean13 = zonedChronology8.equals((java.lang.Object) dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology8.dayOfWeek();
        org.joda.time.Chronology chronology15 = zonedChronology8.withUTC();
        org.joda.time.Period period16 = new org.joda.time.Period((long) 7, (-210866673600000L), (org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTimeField dateTimeField17 = zonedChronology8.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField18 = zonedChronology8.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (-25200000));
        long long22 = offsetDateTimeField20.roundHalfCeiling((long) '#');
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-28800001L) + "'", long7 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-28800001L) + "'", long11 == (-28800001L));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-230400000L) + "'", long22 == (-230400000L));
    }

//    @Test
//    public void test69() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test69");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField7 = zonedChronology6.halfdayOfDay();
//        org.joda.time.DurationField durationField8 = zonedChronology6.weeks();
//        org.joda.time.Period period10 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period12 = period10.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.ReadableInstant readableInstant14 = null;
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant13, readableInstant14, periodType15);
//        int int17 = period16.size();
//        org.joda.time.Period period19 = period16.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        long long22 = dateTimeZone20.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = dateTimeZone23.getName((long) ' ', locale25);
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = dateTimeZone23.getName((long) (byte) 0, locale28);
//        boolean boolean30 = period16.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period32 = period16.withYears((int) (byte) 100);
//        org.joda.time.Period period34 = new org.joda.time.Period(100L);
//        org.joda.time.Period period35 = period34.toPeriod();
//        int int36 = period34.getYears();
//        org.joda.time.Period period38 = period34.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType41 = periodType39.getFieldType(0);
//        int int42 = period38.get(durationFieldType41);
//        org.joda.time.Period period44 = period32.withFieldAdded(durationFieldType41, 2);
//        boolean boolean45 = period10.isSupported(durationFieldType41);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException49 = new org.joda.time.IllegalFieldValueException(durationFieldType41, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        org.joda.time.field.ScaledDurationField scaledDurationField51 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType41, (int) (short) 10);
//        org.joda.time.DurationField durationField52 = scaledDurationField51.getWrappedField();
//        long long54 = scaledDurationField51.getValueAsLong((-53509900L));
//        long long56 = scaledDurationField51.getMillis((long) (-28378000));
//        long long57 = scaledDurationField51.getUnitMillis();
//        long long59 = scaledDurationField51.getMillis(385200000);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(period10);
//        org.junit.Assert.assertNotNull(period12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-28800001L) + "'", long22 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Pacific Standard Time" + "'", str26.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Pacific Standard Time" + "'", str29.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(period32);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(period38);
//        org.junit.Assert.assertNotNull(periodType39);
//        org.junit.Assert.assertNotNull(durationFieldType41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(period44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-171630144000000000L) + "'", long56 == (-171630144000000000L));
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 6048000000L + "'", long57 == 6048000000L);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 2329689600000000000L + "'", long59 == 2329689600000000000L);
//    }

//    @Test
//    public void test70() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test70");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone7 = zonedChronology6.getZone();
//        org.joda.time.DateTimeZone dateTimeZone8 = zonedChronology6.getZone();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        long long14 = dateTimeZone12.convertUTCToLocal((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology10, dateTimeZone12);
//        java.lang.String str17 = dateTimeZone12.getShortName(0L);
//        org.joda.time.Chronology chronology18 = zonedChronology6.withZone(dateTimeZone12);
//        org.joda.time.DurationField durationField19 = zonedChronology6.centuries();
//        org.joda.time.DateTimeZone dateTimeZone20 = zonedChronology6.getZone();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-28800001L) + "'", long14 == (-28800001L));
//        org.junit.Assert.assertNotNull(zonedChronology15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PST" + "'", str17.equals("PST"));
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//    }

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test71");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "PeriodType[Weeks]", (int) 'a', (-970));
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        long long7 = fixedDateTimeZone4.nextTransition((long) (-107));
        long long9 = fixedDateTimeZone4.previousTransition(2440588L);
        int int11 = fixedDateTimeZone4.getOffset(315532800107L);
        long long14 = fixedDateTimeZone4.adjustOffset((-30610166822000L), false);
        java.util.TimeZone timeZone15 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-107L) + "'", long7 == (-107L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2440588L + "'", long9 == 2440588L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 97 + "'", int11 == 97);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-30610166822000L) + "'", long14 == (-30610166822000L));
        org.junit.Assert.assertNotNull(timeZone15);
    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test72");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType2 = periodType1.withMinutesRemoved();
        org.joda.time.Period period3 = new org.joda.time.Period(1560626963539L, periodType2);
        org.joda.time.Period period5 = period3.withYears(1);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test73");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        long long7 = dateTimeZone5.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        long long11 = dateTimeZone9.convertUTCToLocal((-1L));
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        boolean boolean13 = zonedChronology8.equals((java.lang.Object) dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology8.dayOfWeek();
        org.joda.time.Chronology chronology15 = zonedChronology8.withUTC();
        org.joda.time.Period period16 = new org.joda.time.Period((long) 7, (-210866673600000L), (org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTimeField dateTimeField17 = zonedChronology8.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField18 = zonedChronology8.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (-25200000));
        int int23 = offsetDateTimeField20.getDifference((long) (-1), 0L);
        org.joda.time.ReadablePartial readablePartial24 = null;
        java.util.Locale locale26 = null;
        java.lang.String str27 = offsetDateTimeField20.getAsText(readablePartial24, 0, locale26);
        org.joda.time.ReadablePartial readablePartial28 = null;
        int int29 = offsetDateTimeField20.getMinimumValue(readablePartial28);
        int int32 = offsetDateTimeField20.getDifference(2447587L, 28799996L);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-28800001L) + "'", long7 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-28800001L) + "'", long11 == (-28800001L));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-25199999) + "'", int29 == (-25199999));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test74");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("P35MT52M", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test75() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test75");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant3 = null;
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.PeriodType periodType5 = null;
//        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant3, readableInstant4, periodType5);
//        int int7 = period6.size();
//        org.joda.time.Period period9 = period6.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        long long12 = dateTimeZone10.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getName((long) ' ', locale15);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = dateTimeZone13.getName((long) (byte) 0, locale18);
//        boolean boolean20 = period6.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period22 = period6.withYears((int) (byte) 100);
//        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.yearWeekDayTime();
//        int int24 = periodType23.size();
//        org.joda.time.Period period25 = period6.withPeriodType(periodType23);
//        org.joda.time.PeriodType periodType26 = periodType23.withYearsRemoved();
//        org.joda.time.Period period27 = new org.joda.time.Period(33L, periodType23);
//        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType23);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
//        org.junit.Assert.assertNotNull(period9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-28800001L) + "'", long12 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Pacific Standard Time" + "'", str16.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Pacific Standard Time" + "'", str19.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(period22);
//        org.junit.Assert.assertNotNull(periodType23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 7 + "'", int24 == 7);
//        org.junit.Assert.assertNotNull(period25);
//        org.junit.Assert.assertNotNull(periodType26);
//    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test76");
        org.joda.time.Period period8 = new org.joda.time.Period(100, (int) (byte) 10, 52, (int) (short) 1, 0, 0, (int) (short) 10, (int) (short) -1);
        org.joda.time.Period period10 = period8.minusDays((int) (byte) 10);
        org.joda.time.Period period12 = period8.minusHours(0);
        java.lang.String str13 = period8.toString();
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "P100Y10M52W1DT9.999S" + "'", str13.equals("P100Y10M52W1DT9.999S"));
    }

//    @Test
//    public void test77() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test77");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField7 = zonedChronology6.halfdayOfDay();
//        org.joda.time.DurationField durationField8 = zonedChronology6.weeks();
//        org.joda.time.Period period10 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period12 = period10.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.ReadableInstant readableInstant14 = null;
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant13, readableInstant14, periodType15);
//        int int17 = period16.size();
//        org.joda.time.Period period19 = period16.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        long long22 = dateTimeZone20.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = dateTimeZone23.getName((long) ' ', locale25);
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = dateTimeZone23.getName((long) (byte) 0, locale28);
//        boolean boolean30 = period16.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period32 = period16.withYears((int) (byte) 100);
//        org.joda.time.Period period34 = new org.joda.time.Period(100L);
//        org.joda.time.Period period35 = period34.toPeriod();
//        int int36 = period34.getYears();
//        org.joda.time.Period period38 = period34.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType41 = periodType39.getFieldType(0);
//        int int42 = period38.get(durationFieldType41);
//        org.joda.time.Period period44 = period32.withFieldAdded(durationFieldType41, 2);
//        boolean boolean45 = period10.isSupported(durationFieldType41);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException49 = new org.joda.time.IllegalFieldValueException(durationFieldType41, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        org.joda.time.field.ScaledDurationField scaledDurationField51 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType41, (int) (short) 10);
//        org.joda.time.DurationField durationField52 = scaledDurationField51.getWrappedField();
//        org.joda.time.DurationField durationField53 = scaledDurationField51.getWrappedField();
//        long long56 = scaledDurationField51.getValueAsLong((long) (short) 1, (long) (-50612));
//        long long58 = scaledDurationField51.getMillis(100);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(period10);
//        org.junit.Assert.assertNotNull(period12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-28800001L) + "'", long22 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Pacific Standard Time" + "'", str26.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Pacific Standard Time" + "'", str29.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(period32);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(period38);
//        org.junit.Assert.assertNotNull(periodType39);
//        org.junit.Assert.assertNotNull(durationFieldType41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(period44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(durationField53);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 604800000000L + "'", long58 == 604800000000L);
//    }

//    @Test
//    public void test78() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test78");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField7 = zonedChronology6.halfdayOfDay();
//        org.joda.time.DurationField durationField8 = zonedChronology6.weeks();
//        org.joda.time.Period period10 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period12 = period10.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.ReadableInstant readableInstant14 = null;
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant13, readableInstant14, periodType15);
//        int int17 = period16.size();
//        org.joda.time.Period period19 = period16.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        long long22 = dateTimeZone20.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = dateTimeZone23.getName((long) ' ', locale25);
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = dateTimeZone23.getName((long) (byte) 0, locale28);
//        boolean boolean30 = period16.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period32 = period16.withYears((int) (byte) 100);
//        org.joda.time.Period period34 = new org.joda.time.Period(100L);
//        org.joda.time.Period period35 = period34.toPeriod();
//        int int36 = period34.getYears();
//        org.joda.time.Period period38 = period34.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType41 = periodType39.getFieldType(0);
//        int int42 = period38.get(durationFieldType41);
//        org.joda.time.Period period44 = period32.withFieldAdded(durationFieldType41, 2);
//        boolean boolean45 = period10.isSupported(durationFieldType41);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException49 = new org.joda.time.IllegalFieldValueException(durationFieldType41, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        org.joda.time.field.ScaledDurationField scaledDurationField51 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType41, (int) (short) 10);
//        org.joda.time.DurationField durationField52 = scaledDurationField51.getWrappedField();
//        long long54 = scaledDurationField51.getValueAsLong((-53509900L));
//        long long56 = scaledDurationField51.getMillis((long) (-28378000));
//        long long59 = scaledDurationField51.getDifferenceAsLong(34L, 0L);
//        long long62 = scaledDurationField51.subtract(28200100L, 1504273L);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(period10);
//        org.junit.Assert.assertNotNull(period12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-28800001L) + "'", long22 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Pacific Standard Time" + "'", str26.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Pacific Standard Time" + "'", str29.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(period32);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(period38);
//        org.junit.Assert.assertNotNull(periodType39);
//        org.junit.Assert.assertNotNull(durationFieldType41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(period44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-171630144000000000L) + "'", long56 == (-171630144000000000L));
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 0L + "'", long59 == 0L);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-9097843076221900L) + "'", long62 == (-9097843076221900L));
//    }

    @Test
    public void test79() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test79");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int6 = cachedDateTimeZone4.getOffsetFromLocal((long) (-28800000));
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone4, 1);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.weekyear();
        org.joda.time.DurationField durationField11 = gregorianChronology8.days();
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology8.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-28800000) + "'", int6 == (-28800000));
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
    }

    @Test
    public void test80() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test80");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType4 = periodType3.withSecondsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period(107L, (long) (-97), periodType4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        long long11 = dateTimeZone9.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology7, dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology12.halfdayOfDay();
        org.joda.time.DurationField durationField14 = zonedChronology12.minutes();
        org.joda.time.Period period15 = new org.joda.time.Period((-210866673600000L), periodType4, (org.joda.time.Chronology) zonedChronology12);
        org.joda.time.DateTimeField dateTimeField16 = zonedChronology12.weekOfWeekyear();
        org.joda.time.DurationField durationField17 = zonedChronology12.hours();
        org.joda.time.DateTimeField dateTimeField18 = zonedChronology12.dayOfYear();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-28800001L) + "'", long11 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

//    @Test
//    public void test81() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test81");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = cachedDateTimeZone4.getName(1L, locale6);
//        long long9 = cachedDateTimeZone4.nextTransition(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone4);
//        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9972000000L + "'", long9 == 9972000000L);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(lenientChronology11);
//    }

    @Test
    public void test82() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test82");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        long long7 = dateTimeZone5.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        long long11 = dateTimeZone9.convertUTCToLocal((-1L));
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        boolean boolean13 = zonedChronology8.equals((java.lang.Object) dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology8.dayOfWeek();
        org.joda.time.Chronology chronology15 = zonedChronology8.withUTC();
        org.joda.time.Period period16 = new org.joda.time.Period((long) 7, (-210866673600000L), (org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTimeField dateTimeField17 = zonedChronology8.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField18 = zonedChronology8.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (-25200000));
        int int23 = offsetDateTimeField20.getDifference((long) (-1), 0L);
        org.joda.time.ReadablePartial readablePartial24 = null;
        java.util.Locale locale26 = null;
        java.lang.String str27 = offsetDateTimeField20.getAsText(readablePartial24, 0, locale26);
        int int29 = offsetDateTimeField20.getLeapAmount((long) (-1));
        int int30 = offsetDateTimeField20.getMinimumValue();
        long long32 = offsetDateTimeField20.roundHalfEven(0L);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-28800001L) + "'", long7 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-28800001L) + "'", long11 == (-28800001L));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-25199999) + "'", int30 == (-25199999));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-230400000L) + "'", long32 == (-230400000L));
    }
}

