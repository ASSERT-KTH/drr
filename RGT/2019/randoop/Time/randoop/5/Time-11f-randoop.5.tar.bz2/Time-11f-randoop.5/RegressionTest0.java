import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(10, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 970 + "'", int2 == 970);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.lang.String str1 = dateTimeZone0.getID();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "America/Los_Angeles" + "'", str1.equals("America/Los_Angeles"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 100, (java.lang.Object) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) ' ', (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 33L + "'", long2 == 33L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, 0, 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.Period period5 = period3.plusMonths((int) '#');
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.Period period8 = period5.withFieldAdded(durationFieldType6, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.Period period5 = period3.plusMonths((int) '#');
        try {
            org.joda.time.Minutes minutes6 = period5.toStandardMinutes();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Minutes as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (-28800000), (long) 970);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -27936000000");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(10, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1L, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 10, (int) (byte) 10, (int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("Pacific Standard Time", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Pacific Standard Time/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'hi!' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test023");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        long long2 = dateTimeZone0.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.lang.String str5 = dateTimeZone0.getName((long) '#');
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-28800001L) + "'", long2 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pacific Standard Time" + "'", str5.equals("Pacific Standard Time"));
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.Period period8 = period6.withMonths((int) '4');
        org.joda.time.Period period10 = period6.plusMinutes((int) (short) 10);
        org.joda.time.Period period12 = period10.minusYears(0);
        try {
            org.joda.time.Minutes minutes13 = period12.toStandardMinutes();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Minutes as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int6 = cachedDateTimeZone4.getOffsetFromLocal((long) (-28800000));
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone4, 1);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        try {
            int[] intArray13 = gregorianChronology8.get(readablePeriod10, 0L, (long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-28800000) + "'", int6 == (-28800000));
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        int int3 = periodType2.size();
        try {
            org.joda.time.Period period4 = new org.joda.time.Period((java.lang.Object) chronology1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.weekyears();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField6 = gregorianChronology5.weekyears();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField7 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField3, durationField6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        long long2 = dateTimeZone0.convertUTCToLocal((-1L));
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.yearWeekDayTime();
        int int6 = periodType5.size();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant3, readableInstant4, periodType5);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.hourOfDay();
        try {
            org.joda.time.Period period11 = new org.joda.time.Period((java.lang.Object) dateTimeZone0, periodType5, (org.joda.time.Chronology) gregorianChronology9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.tz.CachedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-28800001L) + "'", long2 == (-28800001L));
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 7 + "'", int6 == 7);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("hi!", (int) 'a', (int) (short) 1, 970, 'a', (int) (byte) -1, 970, 970, false, (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.Period period8 = period6.withMonths((int) '4');
        org.joda.time.Period period10 = period6.withMillis((int) '#');
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType12 = periodType11.withYearsRemoved();
        org.joda.time.PeriodType periodType13 = org.joda.time.DateTimeUtils.getPeriodType(periodType11);
        try {
            org.joda.time.Period period14 = period10.normalizedStandard(periodType11);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("America/Los_Angeles", (int) (short) 100, (int) (short) 100, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for America/Los_Angeles must be in the range [100,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test034");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560626963539L + "'", long1 == 1560626963539L);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (byte) 10, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 100, (int) (short) 1, (int) 'a', 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology6.halfdayOfDay();
        org.joda.time.DurationField durationField8 = zonedChronology6.minutes();
        long long11 = durationField8.subtract((long) (short) 10, (int) (byte) -1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 60010L + "'", long11 == 60010L);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) 100);
        java.io.DataOutput dataOutput4 = null;
        try {
            dateTimeZoneBuilder2.writeTo("", dataOutput4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType9 = periodType8.withYearsRemoved();
        try {
            org.joda.time.Period period10 = new org.joda.time.Period((int) (byte) 10, (int) (byte) 100, 0, (int) (byte) 100, (int) ' ', (int) (short) -1, (int) (byte) 100, (int) '4', periodType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.time();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "GregorianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) '4');
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology6.halfdayOfDay();
        org.joda.time.DurationField durationField8 = zonedChronology6.weeks();
        try {
            long long14 = zonedChronology6.getDateTimeMillis((-28800001L), (int) 'a', 7, (int) (short) 100, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.Period period4 = period3.negated();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.Period period7 = period3.withField(durationFieldType5, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.dayOfMonth();
        try {
            long long12 = gregorianChronology1.getDateTimeMillis((int) (short) 100, 970, (int) (byte) 100, (-28800000), 0, (int) ' ', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-97) + "'", int1 == (-97));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
        java.lang.String str4 = dateTimeZone1.getID();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "America/Los_Angeles" + "'", str4.equals("America/Los_Angeles"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.Period period8 = period6.withMonths((int) '4');
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant9, readableInstant10, periodType11);
        int int13 = period12.size();
        org.joda.time.Period period15 = period12.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Duration duration17 = period12.toDurationFrom(readableInstant16);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.PeriodType periodType19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration17, readableInstant18, periodType19);
        org.joda.time.Period period22 = period20.plusMinutes((int) '4');
        org.joda.time.Period period23 = period6.plus((org.joda.time.ReadablePeriod) period22);
        org.joda.time.PeriodType periodType24 = org.joda.time.PeriodType.dayTime();
        try {
            org.joda.time.Period period25 = period23.withPeriodType(periodType24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'months'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(periodType24);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-1L), (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-35L) + "'", long2 == (-35L));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.Period period8 = period6.withMonths((int) '4');
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant9, readableInstant10, periodType11);
        int int13 = period12.size();
        org.joda.time.Period period15 = period12.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Duration duration17 = period12.toDurationFrom(readableInstant16);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.PeriodType periodType19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration17, readableInstant18, periodType19);
        org.joda.time.Period period22 = period20.plusMinutes((int) '4');
        org.joda.time.Period period23 = period6.plus((org.joda.time.ReadablePeriod) period22);
        org.joda.time.Period period25 = period23.withYears(100);
        org.joda.time.format.PeriodFormatter periodFormatter26 = null;
        java.lang.String str27 = period23.toString(periodFormatter26);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "P35MT52M" + "'", str27.equals("P35MT52M"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        long long9 = dateTimeZone7.convertUTCToLocal((-1L));
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        boolean boolean11 = zonedChronology6.equals((java.lang.Object) dateTimeZone7);
        try {
            long long19 = zonedChronology6.getDateTimeMillis((int) (short) 0, (int) (short) 0, 100, 10, (int) '#', 1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-28800001L) + "'", long9 == (-28800001L));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 970, "Pacific Standard Time");
        boolean boolean3 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalInstantException2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology6.halfdayOfDay();
        org.joda.time.DurationField durationField8 = zonedChronology6.minutes();
        long long11 = durationField8.subtract((long) (short) -1, 0);
        org.joda.time.DurationFieldType durationFieldType12 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField13 = new org.joda.time.field.DecoratedDurationField(durationField8, durationFieldType12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.fieldDifference(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) 100);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder0.addCutover(100, ' ', 0, 0, 8, true, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 1.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866673600000L) + "'", long1 == (-210866673600000L));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (byte) 0, (java.lang.Number) (short) 1, (java.lang.Number) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int6 = cachedDateTimeZone4.getOffsetFromLocal((long) (-28800000));
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone4);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-28800000) + "'", int6 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        java.lang.String str3 = period2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PT0S" + "'", str3.equals("PT0S"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.Period period8 = period3.plusWeeks((int) (byte) 0);
        org.joda.time.Period period10 = period8.minusYears(0);
        org.joda.time.Period period11 = period10.normalizedStandard();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("P35MT52M", (int) (byte) -1, (int) (short) 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for P35MT52M must be in the range [0,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.Period period8 = period6.withMonths((int) '4');
        try {
            org.joda.time.Hours hours9 = period6.toStandardHours();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Hours as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 9972000000L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 861369933240000000L + "'", long1 == 861369933240000000L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.DurationFieldType[] durationFieldTypeArray0 = new org.joda.time.DurationFieldType[] {};
        try {
            org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.forFields(durationFieldTypeArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationFieldTypeArray0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("Pacific Standard Time");
        java.lang.Throwable[] throwableArray2 = illegalInstantException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int6 = cachedDateTimeZone4.getOffsetFromLocal((long) (-28800000));
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone4, 1);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.weekyear();
        try {
            long long18 = gregorianChronology8.getDateTimeMillis((int) (byte) 10, (-28800000), (int) (short) 100, (int) (short) 0, (int) (short) 100, 100, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-28800000) + "'", int6 == (-28800000));
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDay();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", "");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        org.junit.Assert.assertNull(number3);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis(10);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(970);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 0, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) -1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period3.toDurationFrom(readableInstant7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant9, periodType10);
        org.joda.time.Period period13 = period11.plusMinutes((int) '4');
        org.joda.time.Duration duration14 = period11.toStandardDuration();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(duration14);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]", "PST");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.months();
        int int1 = periodType0.size();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology6.halfdayOfDay();
        org.joda.time.DurationField durationField8 = zonedChronology6.minutes();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        try {
            int[] intArray11 = zonedChronology6.get(readablePeriod9, (long) (-97));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.weekyears();
        org.joda.time.DurationField durationField3 = gregorianChronology1.weeks();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 970, (java.lang.Number) 1560626963539L, (java.lang.Number) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        try {
            long long12 = zonedChronology6.getDateTimeMillis((long) (short) 100, 7, (int) (byte) 100, 1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.Period period8 = period6.withMonths((int) '4');
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant9, readableInstant10, periodType11);
        int int13 = period12.size();
        org.joda.time.Period period15 = period12.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Duration duration17 = period12.toDurationFrom(readableInstant16);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.PeriodType periodType19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration17, readableInstant18, periodType19);
        org.joda.time.Period period22 = period20.plusMinutes((int) '4');
        org.joda.time.Period period23 = period6.plus((org.joda.time.ReadablePeriod) period22);
        org.joda.time.Period period25 = period23.withYears(100);
        org.joda.time.Period period27 = period25.plusWeeks((int) (short) 100);
        org.joda.time.DurationFieldType durationFieldType28 = null;
        try {
            org.joda.time.Period period30 = period27.withFieldAdded(durationFieldType28, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("GregorianChronology[America/Los_Angeles]", (java.lang.Number) 0L, (java.lang.Number) 0.0d, (java.lang.Number) 10L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", "");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str5 = illegalFieldValueException2.getFieldName();
        illegalFieldValueException2.prependMessage("Pacific Standard Time");
        java.lang.Number number8 = illegalFieldValueException2.getUpperBound();
        java.lang.Number number9 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pacific Standard Time" + "'", str3.equals("Pacific Standard Time"));
        org.junit.Assert.assertNull(durationFieldType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pacific Standard Time" + "'", str5.equals("Pacific Standard Time"));
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 100.0f, (java.lang.Number) 0.0d, (java.lang.Number) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone7 = zonedChronology6.getZone();
        org.joda.time.DateTimeZone dateTimeZone8 = zonedChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology6.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField11 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(970);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-970) + "'", int1 == (-970));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.500000046d + "'", double1 == 2440587.500000046d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        try {
            org.joda.time.Period period3 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology6.halfdayOfDay();
        org.joda.time.DurationField durationField8 = zonedChronology6.minutes();
        org.joda.time.DurationField durationField9 = zonedChronology6.hours();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField11 = new org.joda.time.field.DecoratedDurationField(durationField9, durationFieldType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.Period period5 = period3.plusMonths((int) '#');
        org.joda.time.Hours hours6 = period3.toStandardHours();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(hours6);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 1L, (java.lang.Number) 8, (java.lang.Number) 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        boolean boolean0 = org.joda.time.tz.ZoneInfoCompiler.verbose();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.DurationFieldType durationFieldType1 = null;
        int int2 = periodType0.indexOf(durationFieldType1);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((-97));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.dayOfMonth();
        java.lang.String str4 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.era();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.year();
        org.joda.time.ReadablePartial readablePartial7 = null;
        int[] intArray8 = null;
        try {
            gregorianChronology1.validate(readablePartial7, intArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str4.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = new org.joda.time.Period(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology6.halfdayOfDay();
        org.joda.time.DurationField durationField8 = zonedChronology6.weeks();
        try {
            long long13 = zonedChronology6.getDateTimeMillis((int) '#', (int) 'a', (int) '#', 52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.Period period8 = period6.withMonths((int) '4');
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant9, readableInstant10, periodType11);
        int int13 = period12.size();
        org.joda.time.Period period15 = period12.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Duration duration17 = period12.toDurationFrom(readableInstant16);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.PeriodType periodType19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration17, readableInstant18, periodType19);
        org.joda.time.Period period22 = period20.plusMinutes((int) '4');
        org.joda.time.Period period23 = period6.plus((org.joda.time.ReadablePeriod) period22);
        org.joda.time.Period period25 = period23.withYears(100);
        org.joda.time.Period period27 = period25.plusWeeks((int) (short) 100);
        org.joda.time.format.PeriodFormatter periodFormatter28 = null;
        java.lang.String str29 = period27.toString(periodFormatter28);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "P100Y35M100WT52M" + "'", str29.equals("P100Y35M100WT52M"));
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test110");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = cachedDateTimeZone4.getName(1L, locale6);
//        long long9 = cachedDateTimeZone4.nextTransition(0L);
//        long long11 = cachedDateTimeZone4.nextTransition(1L);
//        long long14 = cachedDateTimeZone4.adjustOffset((long) 0, false);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
//        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.dayOfMonth();
//        boolean boolean19 = cachedDateTimeZone4.equals((java.lang.Object) gregorianChronology16);
//        boolean boolean20 = cachedDateTimeZone4.isFixed();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9972000000L + "'", long9 == 9972000000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9972000000L + "'", long11 == 9972000000L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        long long6 = dateTimeZone4.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.halfdayOfDay();
        org.joda.time.DurationField durationField9 = zonedChronology7.weeks();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField10 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-28800001L) + "'", long6 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 1, 52, 1, 10);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        try {
            org.joda.time.Period period3 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 0, (-97), (int) (short) 0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 10, (int) (byte) -1, 970);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((-210866673600000L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test117");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560626972544L + "'", long0 == 1560626972544L);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(0, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.dayOfMonth();
        java.lang.String str4 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.era();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.year();
        try {
            long long14 = gregorianChronology1.getDateTimeMillis(7, 97, 100, (int) (short) 10, (int) (short) 0, (int) '#', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str4.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.Period period1 = org.joda.time.Period.hours((-1));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (byte) 10, 1560626963539L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1560626963529L) + "'", long2 == (-1560626963529L));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.hourOfHalfday();
        org.joda.time.DurationField durationField3 = gregorianChronology1.eras();
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            int[] intArray6 = gregorianChronology1.get(readablePartial4, (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("PT0S", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"PT0S/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
        try {
            org.joda.time.Period period12 = new org.joda.time.Period((-97), 0, 52, (int) (byte) 10, (int) (byte) 1, 2, 52, (int) (short) 10, periodType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'weeks'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType10);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 970);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210782952000000L) + "'", long1 == (-210782952000000L));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.Period period4 = new org.joda.time.Period(0, (-97), 1, 52);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField5 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType3, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.Period period8 = period6.withMonths((int) '4');
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant9, readableInstant10, periodType11);
        int int13 = period12.size();
        org.joda.time.Period period15 = period12.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Duration duration17 = period12.toDurationFrom(readableInstant16);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.PeriodType periodType19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration17, readableInstant18, periodType19);
        org.joda.time.Period period22 = period20.plusMinutes((int) '4');
        org.joda.time.Period period23 = period6.plus((org.joda.time.ReadablePeriod) period22);
        org.joda.time.Period period25 = period23.withYears(100);
        org.joda.time.Period period27 = period23.withMinutes((-28800000));
        int int28 = period23.getYears();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(60010L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (short) 0, 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) 100);
        java.io.DataOutput dataOutput4 = null;
        try {
            dateTimeZoneBuilder0.writeTo("", dataOutput4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.dayTime();
        try {
            org.joda.time.DurationFieldType durationFieldType2 = periodType0.getFieldType(97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(107L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 107 + "'", int1 == 107);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Chronology chronology6 = gregorianChronology1.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.millisOfSecond();
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant9, readableInstant10, periodType11);
        org.joda.time.Period period14 = period12.plusMonths((int) '#');
        org.joda.time.Period period16 = period12.plusHours((int) (byte) 10);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.PeriodType periodType19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant17, readableInstant18, periodType19);
        int int21 = period20.size();
        org.joda.time.Period period23 = period20.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.Duration duration25 = period20.toDurationFrom(readableInstant24);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.PeriodType periodType27 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType28 = periodType27.withSecondsRemoved();
        org.joda.time.Period period29 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration25, readableInstant26, periodType28);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone30);
        org.joda.time.DurationField durationField32 = gregorianChronology31.weekyears();
        org.joda.time.Period period33 = new org.joda.time.Period((java.lang.Object) period16, periodType28, (org.joda.time.Chronology) gregorianChronology31);
        try {
            org.joda.time.Period period34 = new org.joda.time.Period((java.lang.Object) dateTimeField7, periodType8, (org.joda.time.Chronology) gregorianChronology31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 8 + "'", int21 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(duration25);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(durationField32);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        int int2 = period0.indexOf(durationFieldType1);
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withYearsRemoved();
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.PeriodType periodType5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant3, readableInstant4, periodType5);
        int int7 = period6.size();
        org.joda.time.Period period9 = period6.plusMonths((int) '#');
        org.joda.time.Period period11 = period9.withMonths((int) '4');
        org.joda.time.Period period13 = period9.withMillis((int) '#');
        int int14 = period9.getMillis();
        boolean boolean15 = periodType2.equals((java.lang.Object) int14);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) ' ');
        int int2 = period1.getDays();
        int int3 = period1.getDays();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.Period period8 = period6.withMonths((int) '4');
        org.joda.time.Period period10 = period6.withMillis((int) '#');
        try {
            org.joda.time.Minutes minutes11 = period10.toStandardMinutes();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Minutes as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "Pacific Standard Time", "America/Los_Angeles");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale6 = null;
        java.lang.String str9 = defaultNameProvider0.getShortName(locale6, "America/Los_Angeles", "P35MT52M");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", "");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        java.lang.Number number5 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pacific Standard Time" + "'", str3.equals("Pacific Standard Time"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-28799999L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210858120000000L) + "'", long1 == (-210858120000000L));
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test146");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) 100);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder0.addCutover((int) (byte) 0, '#', (int) (short) 0, 8, (int) '4', true, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) '#');
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "Months");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(0L, (long) (-97));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-97L) + "'", long2 == (-97L));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number2 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-1), number2, number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", "");
        illegalFieldValueException2.prependMessage("");
        try {
            org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) illegalFieldValueException2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.IllegalFieldValueException");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(1560626963539L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560626963539L + "'", long2 == 1560626963539L);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period10 = new org.joda.time.Period((-35L), (long) ' ', periodType9);
        int[] intArray13 = gregorianChronology1.get((org.joda.time.ReadablePeriod) period10, (long) 4, (long) 'a');
        org.joda.time.Period period14 = period10.negated();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Chronology chronology6 = gregorianChronology1.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType8, (int) (short) 1, 52, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = null;
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        int int4 = period3.size();
//        org.joda.time.Period period6 = period3.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        long long9 = dateTimeZone7.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone10.getName((long) ' ', locale12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone10.getName((long) (byte) 0, locale15);
//        boolean boolean17 = period3.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period19 = period3.withYears((int) (byte) 100);
//        org.joda.time.Period period21 = period3.plusDays((int) (short) -1);
//        org.joda.time.Period period23 = period21.plusSeconds((int) (byte) 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
//        org.junit.Assert.assertNotNull(period6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-28800001L) + "'", long9 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Pacific Standard Time" + "'", str16.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertNotNull(period21);
//        org.junit.Assert.assertNotNull(period23);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", "");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str5 = illegalFieldValueException2.getFieldName();
        java.lang.String str6 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.String str7 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pacific Standard Time" + "'", str3.equals("Pacific Standard Time"));
        org.junit.Assert.assertNull(durationFieldType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pacific Standard Time" + "'", str5.equals("Pacific Standard Time"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.Period period1 = new org.joda.time.Period(0L);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone7 = zonedChronology6.getZone();
        org.joda.time.DateTimeZone dateTimeZone8 = zonedChronology6.getZone();
        org.joda.time.DurationField durationField9 = zonedChronology6.weeks();
        try {
            long long17 = zonedChronology6.getDateTimeMillis((-970), (int) (byte) 1, 970, 10, 97, (int) (short) 10, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (-970));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.4999887734d + "'", double1 == 2440587.4999887734d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period10 = new org.joda.time.Period((-35L), (long) ' ', periodType9);
        int[] intArray13 = gregorianChronology1.get((org.joda.time.ReadablePeriod) period10, (long) 4, (long) 'a');
        org.joda.time.Period period15 = period10.withHours(4);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(period15);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test166");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = cachedDateTimeZone4.getName(1L, locale6);
//        org.joda.time.LocalDateTime localDateTime8 = null;
//        try {
//            boolean boolean9 = cachedDateTimeZone4.isLocalDateTimeGap(localDateTime8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.weeks();
        org.joda.time.PeriodType periodType1 = periodType0.withYearsRemoved();
        int int2 = periodType0.size();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "P100Y35M100WT52M");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekyear();
        try {
            org.joda.time.Period period7 = new org.joda.time.Period((-210858120000000L), 60010L, periodType2, (org.joda.time.Chronology) gregorianChronology4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 210858120060010");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.Period period8 = period6.withMonths((int) '4');
        org.joda.time.Period period10 = period6.withMillis((int) '#');
        org.joda.time.DurationFieldType durationFieldType11 = null;
        boolean boolean12 = period6.isSupported(durationFieldType11);
        org.joda.time.Period period14 = period6.minusSeconds((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.dayOfMonth();
        java.lang.String str4 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.era();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.year();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField9 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType7, 107);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str4.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = null;
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        int int4 = period3.size();
//        org.joda.time.Period period6 = period3.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        long long9 = dateTimeZone7.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone10.getName((long) ' ', locale12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone10.getName((long) (byte) 0, locale15);
//        boolean boolean17 = period3.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period19 = period3.withYears((int) (byte) 100);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearWeekDayTime();
//        int int21 = periodType20.size();
//        org.joda.time.Period period22 = period3.withPeriodType(periodType20);
//        org.joda.time.PeriodType periodType23 = periodType20.withMinutesRemoved();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
//        org.junit.Assert.assertNotNull(period6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-28800001L) + "'", long9 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Pacific Standard Time" + "'", str16.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 7 + "'", int21 == 7);
//        org.junit.Assert.assertNotNull(period22);
//        org.junit.Assert.assertNotNull(periodType23);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.millis();
        java.lang.String str1 = periodType0.toString();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PeriodType[Millis]" + "'", str1.equals("PeriodType[Millis]"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology6.halfdayOfDay();
        org.joda.time.DurationField durationField8 = zonedChronology6.minutes();
        long long11 = durationField8.subtract((long) (short) -1, 0);
        long long14 = durationField8.subtract((long) (byte) 100, 10);
        long long17 = durationField8.subtract((-210782952000000L), (long) (short) -1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-599900L) + "'", long14 == (-599900L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-210782951940000L) + "'", long17 == (-210782951940000L));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.dayOfMonth();
        long long8 = gregorianChronology1.add(0L, (long) (short) 10, (int) 'a');
        long long12 = gregorianChronology1.add((-30610138022000L), 28800000L, (-1));
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 970L + "'", long8 == 970L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-30610166822000L) + "'", long12 == (-30610166822000L));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.weekyears();
        long long5 = durationField2.subtract(0L, 970);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.standard();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType(0);
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField10 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType8, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The scalar must not be 0 or 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-30610138022000L) + "'", long5 == (-30610138022000L));
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (byte) 0, (-970));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-970) + "'", int2 == (-970));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period2 = new org.joda.time.Period(0L, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DurationField durationField3 = gregorianChronology1.centuries();
        org.joda.time.DurationField durationField4 = gregorianChronology1.years();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.Period period0 = new org.joda.time.Period();
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant1, readableInstant2, periodType3);
        int int5 = period4.size();
        org.joda.time.Period period7 = period4.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Duration duration9 = period4.toDurationFrom(readableInstant8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration9, readableInstant10, periodType11);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType14 = periodType13.withYearsRemoved();
        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
        int int16 = periodType13.size();
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration9, periodType13);
        try {
            org.joda.time.Period period19 = period17.plusWeeks((-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 5 + "'", int16 == 5);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        boolean boolean8 = dateTimeZone3.isStandardOffset((long) (byte) -1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "org.joda.time.IllegalInstantException: Pacific Standard Time");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        int int3 = periodType2.size();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.Period period6 = period4.plusWeeks(2);
        try {
            org.joda.time.DurationFieldType durationFieldType8 = period6.getFieldType(52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        int int3 = periodType2.size();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.Period period6 = period4.plusWeeks(2);
        org.joda.time.Period period8 = period6.minusSeconds((-28800000));
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.dayOfMonth();
        long long8 = gregorianChronology1.add(0L, (long) (short) 10, (int) 'a');
        org.joda.time.DurationField durationField9 = gregorianChronology1.eras();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 970L + "'", long8 == 970L);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((-1), (int) (short) -1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        org.joda.time.ReadablePartial readablePartial0 = null;
//        org.joda.time.ReadablePartial readablePartial1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.ReadableInstant readableInstant3 = null;
//        org.joda.time.PeriodType periodType4 = null;
//        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType4);
//        int int6 = period5.size();
//        org.joda.time.Period period8 = period5.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
//        long long11 = dateTimeZone9.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = dateTimeZone12.getName((long) ' ', locale14);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone12.getName((long) (byte) 0, locale17);
//        boolean boolean19 = period5.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period21 = period5.withYears((int) (byte) 100);
//        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.yearWeekDayTime();
//        int int23 = periodType22.size();
//        org.joda.time.Period period24 = period5.withPeriodType(periodType22);
//        org.joda.time.PeriodType periodType25 = periodType22.withYearsRemoved();
//        try {
//            org.joda.time.Period period26 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType22);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
//        org.junit.Assert.assertNotNull(period8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-28800001L) + "'", long11 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Pacific Standard Time" + "'", str15.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pacific Standard Time" + "'", str18.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(period21);
//        org.junit.Assert.assertNotNull(periodType22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 7 + "'", int23 == 7);
//        org.junit.Assert.assertNotNull(period24);
//        org.junit.Assert.assertNotNull(periodType25);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.Chronology chronology3 = gregorianChronology1.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.dayOfMonth();
        org.joda.time.DurationField durationField5 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.monthOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(0L, 970L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(7, 'a', (int) (byte) 10, (int) (byte) 100, 0, true, (int) ' ');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder8.addRecurringSavings("hi!", 4, (int) 'a', (int) (short) 0, ' ', 10, (int) (byte) 0, 100, false, 0);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder27 = dateTimeZoneBuilder8.addCutover((int) (byte) -1, '#', 8, 107, 7, true, 107);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder19);
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test194");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = cachedDateTimeZone4.getName(1L, locale6);
//        long long9 = cachedDateTimeZone4.nextTransition(0L);
//        long long11 = cachedDateTimeZone4.nextTransition(1L);
//        long long14 = cachedDateTimeZone4.adjustOffset((long) 0, false);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
//        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.dayOfMonth();
//        boolean boolean19 = cachedDateTimeZone4.equals((java.lang.Object) gregorianChronology16);
//        org.joda.time.DurationField durationField20 = gregorianChronology16.eras();
//        try {
//            long long28 = gregorianChronology16.getDateTimeMillis(1, 100, (int) (byte) 10, 970, (int) (byte) 1, (int) (short) 10, 2);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 970 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9972000000L + "'", long9 == 9972000000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9972000000L + "'", long11 == 9972000000L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(durationField20);
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withYearsRemoved();
        org.joda.time.PeriodType periodType2 = periodType0.withSecondsRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = cachedDateTimeZone4.getName(1L, locale6);
//        long long9 = cachedDateTimeZone4.nextTransition(0L);
//        long long11 = cachedDateTimeZone4.nextTransition(1L);
//        long long14 = cachedDateTimeZone4.adjustOffset((long) 0, false);
//        java.lang.String str16 = cachedDateTimeZone4.getNameKey((-210866673600000L));
//        org.joda.time.LocalDateTime localDateTime17 = null;
//        try {
//            boolean boolean18 = cachedDateTimeZone4.isLocalDateTimeGap(localDateTime17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9972000000L + "'", long9 == 9972000000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9972000000L + "'", long11 == 9972000000L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "LMT" + "'", str16.equals("LMT"));
//    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test197");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = null;
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        int int4 = period3.size();
//        org.joda.time.Period period6 = period3.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        long long9 = dateTimeZone7.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone10.getName((long) ' ', locale12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone10.getName((long) (byte) 0, locale15);
//        boolean boolean17 = period3.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period19 = period3.withYears((int) (byte) 100);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearWeekDayTime();
//        int int21 = periodType20.size();
//        org.joda.time.Period period22 = period3.withPeriodType(periodType20);
//        int int23 = period22.getDays();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
//        org.junit.Assert.assertNotNull(period6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-28800001L) + "'", long9 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Pacific Standard Time" + "'", str16.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 7 + "'", int21 == 7);
//        org.junit.Assert.assertNotNull(period22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", "");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str5 = illegalFieldValueException2.getFieldName();
        java.lang.String str6 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.Number number7 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pacific Standard Time" + "'", str3.equals("Pacific Standard Time"));
        org.junit.Assert.assertNull(durationFieldType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pacific Standard Time" + "'", str5.equals("Pacific Standard Time"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearWeekDayTime();
        int int5 = periodType4.size();
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType4);
        try {
            org.joda.time.Period period7 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType4);
        int int6 = period5.size();
        org.joda.time.Period period8 = period5.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Duration duration10 = period5.toDurationFrom(readableInstant9);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.PeriodType periodType12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration10, readableInstant11, periodType12);
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration10);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.PeriodType periodType19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant17, readableInstant18, periodType19);
        int int21 = period20.size();
        org.joda.time.Period period23 = period20.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.Duration duration25 = period20.toDurationFrom(readableInstant24);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.PeriodType periodType27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration25, readableInstant26, periodType27);
        org.joda.time.Period period29 = new org.joda.time.Period(readableInstant16, (org.joda.time.ReadableDuration) duration25);
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.PeriodType periodType32 = org.joda.time.PeriodType.yearWeekDayTime();
        int int33 = periodType32.size();
        org.joda.time.Period period34 = new org.joda.time.Period(readableInstant30, readableInstant31, periodType32);
        org.joda.time.Period period35 = new org.joda.time.Period(readableInstant15, (org.joda.time.ReadableDuration) duration25, periodType32);
        org.joda.time.Period period36 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration10, periodType32);
        int int37 = period36.getDays();
        org.joda.time.Period period39 = period36.withYears(5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(duration10);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 8 + "'", int21 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(duration25);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 7 + "'", int33 == 7);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(period39);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        int int5 = period3.size();
        org.joda.time.Duration duration6 = period3.toStandardDuration();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(duration6);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period2 = new org.joda.time.Period(0L, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DurationField durationField3 = gregorianChronology1.centuries();
        try {
            long long8 = gregorianChronology1.getDateTimeMillis(0, 100, (int) '4', (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField3);
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        long long3 = dateTimeZone1.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName((long) ' ', locale6);
//        org.joda.time.Chronology chronology8 = iSOChronology0.withZone(dateTimeZone4);
//        org.joda.time.Period period10 = org.joda.time.Period.seconds(100);
//        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.weeks();
//        org.joda.time.PeriodType periodType12 = periodType11.withYearsRemoved();
//        org.joda.time.Period period13 = period10.normalizedStandard(periodType12);
//        boolean boolean14 = iSOChronology0.equals((java.lang.Object) period10);
//        int int15 = period10.getHours();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-28800001L) + "'", long3 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(period10);
//        org.junit.Assert.assertNotNull(periodType11);
//        org.junit.Assert.assertNotNull(periodType12);
//        org.junit.Assert.assertNotNull(period13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test204");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        long long2 = dateTimeZone0.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        int int5 = dateTimeZone0.getOffsetFromLocal((long) (byte) 0);
//        java.lang.String str7 = dateTimeZone0.getShortName((long) (byte) -1);
//        long long11 = dateTimeZone0.convertLocalToUTC((long) (byte) 10, true, (long) (byte) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        try {
//            org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (-970));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -970");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-28800001L) + "'", long2 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800010L + "'", long11 == 28800010L);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(28800010L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period3.toDurationFrom(readableInstant7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant9, periodType10);
        org.joda.time.Period period13 = period11.plusMinutes((int) '4');
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.PeriodType periodType16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant14, readableInstant15, periodType16);
        int int18 = period17.size();
        org.joda.time.Period period20 = period17.plusMonths((int) '#');
        org.joda.time.Period period22 = period20.withMonths((int) '4');
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.PeriodType periodType25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant23, readableInstant24, periodType25);
        int int27 = period26.size();
        org.joda.time.Period period29 = period26.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.Duration duration31 = period26.toDurationFrom(readableInstant30);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.PeriodType periodType33 = null;
        org.joda.time.Period period34 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration31, readableInstant32, periodType33);
        org.joda.time.Period period36 = period34.plusMinutes((int) '4');
        org.joda.time.Period period37 = period20.plus((org.joda.time.ReadablePeriod) period36);
        org.joda.time.Period period39 = period37.withYears(100);
        org.joda.time.Period period41 = period39.plusMonths(1);
        org.joda.time.Period period42 = period11.withFields((org.joda.time.ReadablePeriod) period39);
        int int43 = period11.getMinutes();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 8 + "'", int27 == 8);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(duration31);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.withSeconds(7);
        org.joda.time.Period period8 = period3.minusWeeks(107);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.Period period4 = new org.joda.time.Period((int) '#', (int) (byte) 10, (int) '#', (int) '#');
        org.joda.time.Period period6 = period4.minusSeconds(2);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period2 = new org.joda.time.Period(0L, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.PeriodType periodType4 = null;
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        int int8 = dateTimeZone6.getOffsetFromLocal(0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        int int11 = cachedDateTimeZone9.getOffsetFromLocal((long) (-28800000));
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone9, 1);
        try {
            org.joda.time.Period period14 = new org.joda.time.Period((java.lang.Object) gregorianChronology1, periodType4, (org.joda.time.Chronology) gregorianChronology13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.GregorianChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
        org.junit.Assert.assertNotNull(gregorianChronology13);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.weekyearOfCentury();
        org.joda.time.Chronology chronology4 = null;
        try {
            org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) dateTimeField3, chronology4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.hourOfHalfday();
        org.joda.time.DurationField durationField3 = gregorianChronology1.years();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.secondOfMinute();
        org.joda.time.Chronology chronology5 = gregorianChronology1.withUTC();
        java.lang.Class<?> wildcardClass6 = chronology5.getClass();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.Period period1 = org.joda.time.Period.months(52);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) ' ');
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period3.toDurationFrom(readableInstant7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.PeriodType periodType13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableInstant12, periodType13);
        int int15 = period14.size();
        org.joda.time.Period period17 = period14.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = period14.toDurationFrom(readableInstant18);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.PeriodType periodType21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration19, readableInstant20, periodType21);
        org.joda.time.Period period23 = new org.joda.time.Period(readableInstant10, (org.joda.time.ReadableDuration) duration19);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.PeriodType periodType28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period(readableInstant26, readableInstant27, periodType28);
        int int30 = period29.size();
        org.joda.time.Period period32 = period29.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Duration duration34 = period29.toDurationFrom(readableInstant33);
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.PeriodType periodType36 = null;
        org.joda.time.Period period37 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration34, readableInstant35, periodType36);
        org.joda.time.Period period38 = new org.joda.time.Period(readableInstant25, (org.joda.time.ReadableDuration) duration34);
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.ReadableInstant readableInstant40 = null;
        org.joda.time.PeriodType periodType41 = org.joda.time.PeriodType.yearWeekDayTime();
        int int42 = periodType41.size();
        org.joda.time.Period period43 = new org.joda.time.Period(readableInstant39, readableInstant40, periodType41);
        org.joda.time.Period period44 = new org.joda.time.Period(readableInstant24, (org.joda.time.ReadableDuration) duration34, periodType41);
        org.joda.time.Period period45 = new org.joda.time.Period(readableInstant9, (org.joda.time.ReadableDuration) duration19, periodType41);
        int int46 = period45.getDays();
        org.joda.time.Period period47 = period3.plus((org.joda.time.ReadablePeriod) period45);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 8 + "'", int15 == 8);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 8 + "'", int30 == 8);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(duration34);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 7 + "'", int42 == 7);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(period47);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-97L), 8);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-776L) + "'", long2 == (-776L));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType5, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(60010L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5006945604d + "'", double1 == 2440587.5006945604d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("P100Y35M100WT52M");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"P100Y35M100WT52M/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 1.0d, (java.lang.Number) 5, (java.lang.Number) (short) -1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.weeks();
        org.joda.time.PeriodType periodType3 = periodType2.withYearsRemoved();
        try {
            org.joda.time.Period period4 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.DurationFieldType[] durationFieldTypeArray0 = null;
        try {
            org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.forFields(durationFieldTypeArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", "");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str5 = illegalFieldValueException2.getFieldName();
        java.lang.String str6 = illegalFieldValueException2.getIllegalStringValue();
        org.joda.time.DurationFieldType durationFieldType7 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pacific Standard Time" + "'", str3.equals("Pacific Standard Time"));
        org.junit.Assert.assertNull(durationFieldType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pacific Standard Time" + "'", str5.equals("Pacific Standard Time"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(durationFieldType7);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType4);
        int int6 = period5.size();
        org.joda.time.Period period8 = period5.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Duration duration10 = period5.toDurationFrom(readableInstant9);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.PeriodType periodType12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration10, readableInstant11, periodType12);
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration10);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant15, readableInstant16, periodType17);
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration10, periodType17);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration10, readableInstant20);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(duration10);
        org.junit.Assert.assertNotNull(periodType17);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.Period period1 = org.joda.time.Period.months((int) ' ');
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(107, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-107) + "'", int2 == (-107));
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test227");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        long long2 = dateTimeZone0.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        int int5 = dateTimeZone0.getOffsetFromLocal((long) (byte) 0);
//        java.lang.String str7 = dateTimeZone0.getShortName((long) (byte) -1);
//        long long11 = dateTimeZone0.convertLocalToUTC((long) (byte) 10, true, (long) (byte) 1);
//        java.util.TimeZone timeZone12 = dateTimeZone0.toTimeZone();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-28800001L) + "'", long2 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800010L + "'", long11 == 28800010L);
//        org.junit.Assert.assertNotNull(timeZone12);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        int int3 = periodType2.size();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.Period period6 = period4.plusDays(970);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int6 = cachedDateTimeZone4.getOffsetFromLocal((long) (-28800000));
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone4, 1);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, dateTimeFieldType10, 107, 970, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-28800000) + "'", int6 == (-28800000));
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant1, readableInstant2, periodType3);
        int int5 = period4.size();
        org.joda.time.Period period7 = period4.plusMonths((int) '#');
        org.joda.time.Period period9 = period7.withMonths((int) '4');
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.PeriodType periodType12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(readableInstant10, readableInstant11, periodType12);
        int int14 = period13.size();
        org.joda.time.Period period16 = period13.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Duration duration18 = period13.toDurationFrom(readableInstant17);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.PeriodType periodType20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration18, readableInstant19, periodType20);
        org.joda.time.Period period23 = period21.plusMinutes((int) '4');
        org.joda.time.Period period24 = period7.plus((org.joda.time.ReadablePeriod) period23);
        org.joda.time.Period period26 = period24.withYears(100);
        org.joda.time.Period period28 = period26.plusMonths(1);
        long long31 = iSOChronology0.add((org.joda.time.ReadablePeriod) period28, (long) 52, (int) (byte) 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(duration18);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 52L + "'", long31 == 52L);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.Days days7 = period3.toStandardDays();
        org.joda.time.Period period9 = period3.withWeeks((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(days7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Chronology chronology6 = gregorianChronology1.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.millisOfSecond();
        try {
            long long15 = gregorianChronology1.getDateTimeMillis(8, 2, 8, (-97), 52, (-107), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        boolean boolean2 = dateTimeZone0.isStandardOffset((long) 107);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        long long9 = dateTimeZone7.convertUTCToLocal((-1L));
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        boolean boolean11 = zonedChronology6.equals((java.lang.Object) dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField12 = zonedChronology6.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone13 = zonedChronology6.getZone();
        java.lang.String str14 = zonedChronology6.toString();
        org.joda.time.DateTimeField dateTimeField15 = zonedChronology6.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-28800001L) + "'", long9 == (-28800001L));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]" + "'", str14.equals("ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology6.halfdayOfDay();
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        int int11 = dateTimeZone9.getOffsetFromLocal(0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        int int14 = cachedDateTimeZone12.getOffsetFromLocal((long) (-28800000));
        int int16 = cachedDateTimeZone12.getOffset((long) (byte) 0);
        org.joda.time.Chronology chronology17 = zonedChronology6.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone18 = zonedChronology6.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-28800000) + "'", int14 == (-28800000));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-28800000) + "'", int16 == (-28800000));
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, number1, (java.lang.Number) (-599900L), (java.lang.Number) (-97L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.Period period8 = new org.joda.time.Period((int) (byte) 1, 0, (int) (byte) 100, (int) (byte) 0, 7, 7, (int) (byte) 10, 100);
        org.joda.time.Period period9 = period8.negated();
        org.joda.time.Period period11 = period8.minusWeeks(1);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.BufferedReader bufferedReader1 = null;
        try {
            zoneInfoCompiler0.parseDataFile(bufferedReader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField6 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType4, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test242");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = null;
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        int int4 = period3.size();
//        org.joda.time.Period period6 = period3.plusMonths((int) '#');
//        org.joda.time.Period period8 = period6.withMonths((int) '4');
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        org.joda.time.ReadableInstant readableInstant10 = null;
//        org.joda.time.PeriodType periodType11 = null;
//        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant9, readableInstant10, periodType11);
//        int int13 = period12.size();
//        org.joda.time.Period period15 = period12.plusMonths((int) '#');
//        org.joda.time.ReadableInstant readableInstant16 = null;
//        org.joda.time.Duration duration17 = period12.toDurationFrom(readableInstant16);
//        org.joda.time.ReadableInstant readableInstant18 = null;
//        org.joda.time.PeriodType periodType19 = null;
//        org.joda.time.Period period20 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration17, readableInstant18, periodType19);
//        org.joda.time.Period period22 = period20.plusMinutes((int) '4');
//        org.joda.time.Period period23 = period6.plus((org.joda.time.ReadablePeriod) period22);
//        org.joda.time.ReadableInstant readableInstant24 = null;
//        org.joda.time.ReadableInstant readableInstant25 = null;
//        org.joda.time.PeriodType periodType26 = null;
//        org.joda.time.Period period27 = new org.joda.time.Period(readableInstant24, readableInstant25, periodType26);
//        int int28 = period27.size();
//        org.joda.time.Period period30 = period27.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.getDefault();
//        long long33 = dateTimeZone31.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
//        java.util.Locale locale36 = null;
//        java.lang.String str37 = dateTimeZone34.getName((long) ' ', locale36);
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = dateTimeZone34.getName((long) (byte) 0, locale39);
//        boolean boolean41 = period27.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period43 = period27.withYears((int) (byte) 100);
//        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.yearWeekDayTime();
//        int int45 = periodType44.size();
//        org.joda.time.Period period46 = period27.withPeriodType(periodType44);
//        org.joda.time.Period period47 = new org.joda.time.Period((java.lang.Object) period22, periodType44);
//        org.joda.time.Period period49 = period47.plusMillis(2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
//        org.junit.Assert.assertNotNull(period6);
//        org.junit.Assert.assertNotNull(period8);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
//        org.junit.Assert.assertNotNull(period15);
//        org.junit.Assert.assertNotNull(duration17);
//        org.junit.Assert.assertNotNull(period22);
//        org.junit.Assert.assertNotNull(period23);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 8 + "'", int28 == 8);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-28800001L) + "'", long33 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Pacific Standard Time" + "'", str37.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Pacific Standard Time" + "'", str40.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(period43);
//        org.junit.Assert.assertNotNull(periodType44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 7 + "'", int45 == 7);
//        org.junit.Assert.assertNotNull(period46);
//        org.junit.Assert.assertNotNull(period49);
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int6 = cachedDateTimeZone4.getOffsetFromLocal((long) (-28800000));
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone4, 1);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.millisOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType11, 970, (int) (short) 0, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-28800000) + "'", int6 == (-28800000));
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) 0);
        org.joda.time.Period period3 = period1.plusMillis((int) (byte) 0);
        org.joda.time.Period period5 = period3.plusHours(0);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period5.toDurationTo(readableInstant6);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration7);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType6, 0, 7, (-107));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test246");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        boolean boolean6 = dateTimeZone1.isStandardOffset((-30610138022000L));
//        java.lang.String str8 = dateTimeZone1.getShortName((long) (short) -1);
//        long long10 = dateTimeZone1.convertUTCToLocal(0L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PST" + "'", str8.equals("PST"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-28800000L) + "'", long10 == (-28800000L));
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(0, 0, 2, (int) '#');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 34 + "'", int4 == 34);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-1560626963529L), "GregorianChronology[America/Los_Angeles,mdfw=1]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "Pacific Standard Time", "America/Los_Angeles");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale6 = null;
        java.lang.String str9 = defaultNameProvider0.getShortName(locale6, "P-1Y-100WT-7H-7M-10.100S", "Pacific Standard Time");
        java.util.Locale locale10 = null;
        java.lang.String str13 = defaultNameProvider0.getName(locale10, "PeriodType[Millis]", "GregorianChronology[America/Los_Angeles,mdfw=1]");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.Period period8 = new org.joda.time.Period(100, (int) (byte) 10, 52, (int) (short) 1, 0, 0, (int) (short) 10, (int) (short) -1);
        org.joda.time.Period period9 = period8.negated();
        org.joda.time.Period period11 = period9.minusSeconds((int) (short) -1);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withSecondsRemoved();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (-776L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210933806400000L) + "'", long1 == (-210933806400000L));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        java.lang.String str7 = zonedChronology6.toString();
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.months();
        java.lang.String str9 = periodType8.getName();
        try {
            org.joda.time.Period period10 = new org.joda.time.Period((java.lang.Object) str7, periodType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ZonedChronology[GregorianChronol...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]" + "'", str7.equals("ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Months" + "'", str9.equals("Months"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.dayOfMonth();
        org.joda.time.ReadablePartial readablePartial8 = null;
        try {
            int[] intArray10 = gregorianChronology1.get(readablePartial8, (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = cachedDateTimeZone4.getName(1L, locale6);
//        long long9 = cachedDateTimeZone4.nextTransition(0L);
//        long long11 = cachedDateTimeZone4.nextTransition(1L);
//        long long14 = cachedDateTimeZone4.adjustOffset((long) 0, false);
//        long long18 = cachedDateTimeZone4.convertLocalToUTC(0L, false, (long) (byte) 10);
//        int int20 = cachedDateTimeZone4.getOffset(0L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9972000000L + "'", long9 == 9972000000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9972000000L + "'", long11 == 9972000000L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800000L + "'", long18 == 28800000L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-28800000) + "'", int20 == (-28800000));
//    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test256");
//        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
//        long long3 = durationField0.subtract((long) 1, (-28800000));
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.ReadableInstant readableInstant5 = null;
//        org.joda.time.PeriodType periodType6 = null;
//        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant4, readableInstant5, periodType6);
//        int int8 = period7.size();
//        org.joda.time.Period period10 = period7.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        long long13 = dateTimeZone11.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = dateTimeZone14.getName((long) ' ', locale16);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone14.getName((long) (byte) 0, locale19);
//        boolean boolean21 = period7.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period23 = period7.withYears((int) (byte) 100);
//        org.joda.time.Period period25 = new org.joda.time.Period(100L);
//        org.joda.time.Period period26 = period25.toPeriod();
//        int int27 = period25.getYears();
//        org.joda.time.Period period29 = period25.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType(0);
//        int int33 = period29.get(durationFieldType32);
//        org.joda.time.Period period35 = period23.withFieldAdded(durationFieldType32, 2);
//        org.joda.time.field.DecoratedDurationField decoratedDurationField36 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType32);
//        try {
//            int int39 = decoratedDurationField36.getDifference((long) (-107), 1560626963636L);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -1560626963743");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(durationField0);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 28800001L + "'", long3 == 28800001L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
//        org.junit.Assert.assertNotNull(period10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-28800001L) + "'", long13 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Pacific Standard Time" + "'", str17.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Pacific Standard Time" + "'", str20.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(period23);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(period29);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertNotNull(durationFieldType32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(period35);
//    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "PeriodType[Years]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.Period period8 = period6.withMonths((int) '4');
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant9, readableInstant10, periodType11);
        int int13 = period12.size();
        org.joda.time.Period period15 = period12.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Duration duration17 = period12.toDurationFrom(readableInstant16);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.PeriodType periodType19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration17, readableInstant18, periodType19);
        org.joda.time.Period period22 = period20.plusMinutes((int) '4');
        org.joda.time.Period period23 = period6.plus((org.joda.time.ReadablePeriod) period22);
        org.joda.time.Period period25 = period23.minusDays(5);
        try {
            org.joda.time.Hours hours26 = period23.toStandardHours();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Hours as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.weekyears();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField4 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-4) + "'", int1 == (-4));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (-97), (-35L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3395L + "'", long2 == 3395L);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.OutputStream outputStream2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("P35MT52M", outputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = null;
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        int int4 = period3.size();
//        org.joda.time.Period period6 = period3.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        long long9 = dateTimeZone7.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone10.getName((long) ' ', locale12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone10.getName((long) (byte) 0, locale15);
//        boolean boolean17 = period3.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period19 = period3.withYears((int) (byte) 100);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearWeekDayTime();
//        int int21 = periodType20.size();
//        org.joda.time.Period period22 = period3.withPeriodType(periodType20);
//        org.joda.time.Weeks weeks23 = period22.toStandardWeeks();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
//        org.junit.Assert.assertNotNull(period6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-28800001L) + "'", long9 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Pacific Standard Time" + "'", str16.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 7 + "'", int21 == 7);
//        org.junit.Assert.assertNotNull(period22);
//        org.junit.Assert.assertNotNull(weeks23);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType4);
        int int6 = period5.size();
        org.joda.time.Period period8 = period5.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Duration duration10 = period5.toDurationFrom(readableInstant9);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.PeriodType periodType12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration10, readableInstant11, periodType12);
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration10);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.PeriodType periodType19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant17, readableInstant18, periodType19);
        int int21 = period20.size();
        org.joda.time.Period period23 = period20.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.Duration duration25 = period20.toDurationFrom(readableInstant24);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.PeriodType periodType27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration25, readableInstant26, periodType27);
        org.joda.time.Period period29 = new org.joda.time.Period(readableInstant16, (org.joda.time.ReadableDuration) duration25);
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.PeriodType periodType32 = org.joda.time.PeriodType.yearWeekDayTime();
        int int33 = periodType32.size();
        org.joda.time.Period period34 = new org.joda.time.Period(readableInstant30, readableInstant31, periodType32);
        org.joda.time.Period period35 = new org.joda.time.Period(readableInstant15, (org.joda.time.ReadableDuration) duration25, periodType32);
        org.joda.time.Period period36 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration10, periodType32);
        int int37 = period36.getDays();
        try {
            org.joda.time.Period period39 = period36.withMonths(97);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(duration10);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 8 + "'", int21 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(duration25);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 7 + "'", int33 == 7);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType2 = null;
        boolean boolean3 = period1.isSupported(durationFieldType2);
        org.joda.time.Period period5 = period1.withWeeks(5);
        org.joda.time.Period period7 = period1.plusMillis(8);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period3.toDurationFrom(readableInstant7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant9, readableInstant10, periodType11);
        int int13 = period12.size();
        org.joda.time.Period period15 = period12.plusMonths((int) '#');
        org.joda.time.Period period17 = period15.withMonths((int) '4');
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.PeriodType periodType20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period(readableInstant18, readableInstant19, periodType20);
        int int22 = period21.size();
        org.joda.time.Period period24 = period21.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.Duration duration26 = period21.toDurationFrom(readableInstant25);
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.PeriodType periodType28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration26, readableInstant27, periodType28);
        org.joda.time.Period period31 = period29.plusMinutes((int) '4');
        org.joda.time.Period period32 = period15.plus((org.joda.time.ReadablePeriod) period31);
        boolean boolean33 = period3.equals((java.lang.Object) period15);
        try {
            org.joda.time.Period period34 = new org.joda.time.Period((java.lang.Object) boolean33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Boolean");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(duration26);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType9 = periodType8.withYearsRemoved();
        org.joda.time.PeriodType periodType10 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
        int int11 = periodType8.size();
        try {
            org.joda.time.Period period12 = new org.joda.time.Period(0, (int) '4', (-970), (int) '4', (int) (short) 10, 97, 107, (-1), periodType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'months'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) 0);
        int int2 = period1.getSeconds();
        int int3 = period1.getWeeks();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.year();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.millisOfSecond();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 100, periodType1);
        org.joda.time.Period period4 = period2.minusWeeks(8);
        org.joda.time.Period period6 = period4.withYears((int) (short) 10);
        org.joda.time.format.PeriodFormatter periodFormatter7 = null;
        java.lang.String str8 = period6.toString(periodFormatter7);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "P10Y-8WT0.100S" + "'", str8.equals("P10Y-8WT0.100S"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str1.equals("GregorianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period((-35L), (long) ' ', periodType2);
        java.lang.String str4 = periodType2.getName();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Standard" + "'", str4.equals("Standard"));
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = cachedDateTimeZone4.getName(1L, locale6);
//        long long9 = cachedDateTimeZone4.nextTransition(0L);
//        long long11 = cachedDateTimeZone4.nextTransition(1L);
//        org.joda.time.LocalDateTime localDateTime12 = null;
//        try {
//            boolean boolean13 = cachedDateTimeZone4.isLocalDateTimeGap(localDateTime12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9972000000L + "'", long9 == 9972000000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9972000000L + "'", long11 == 9972000000L);
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.Period period1 = new org.joda.time.Period((long) (-97));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "Pacific Standard Time", "America/Los_Angeles");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale6 = null;
        java.lang.String str9 = defaultNameProvider0.getShortName(locale6, "America/Los_Angeles", "P35MT52M");
        java.util.Locale locale10 = null;
        java.lang.String str13 = defaultNameProvider0.getShortName(locale10, "", "PeriodType[Weeks]");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(107, (-1), 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int6 = cachedDateTimeZone4.getOffsetFromLocal((long) (-28800000));
        int int8 = cachedDateTimeZone4.getOffset((long) (byte) 0);
        int int10 = cachedDateTimeZone4.getStandardOffset((-30610138022000L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-28800000) + "'", int6 == (-28800000));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28378000) + "'", int10 == (-28378000));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology6.halfdayOfDay();
        org.joda.time.DurationField durationField8 = zonedChronology6.minutes();
        long long11 = durationField8.subtract(28800001L, (int) (byte) 10);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28200001L + "'", long11 == 28200001L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology6.halfdayOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField9 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        long long7 = dateTimeZone5.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        long long11 = dateTimeZone9.convertUTCToLocal((-1L));
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        boolean boolean13 = zonedChronology8.equals((java.lang.Object) dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology8.dayOfWeek();
        org.joda.time.Chronology chronology15 = zonedChronology8.withUTC();
        org.joda.time.Period period16 = new org.joda.time.Period((long) 7, (-210866673600000L), (org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTimeField dateTimeField17 = zonedChronology8.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone18 = zonedChronology8.getZone();
        org.joda.time.DurationField durationField19 = zonedChronology8.weeks();
        try {
            long long27 = zonedChronology8.getDateTimeMillis((-28800000), (int) (short) 100, (-28800000), 0, (int) (byte) -1, (int) (short) 10, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-28800001L) + "'", long7 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-28800001L) + "'", long11 == (-28800001L));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(durationField19);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(1560626963539L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(107);
        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 385200000 + "'", int3 == 385200000);
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        org.joda.time.Period period5 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period7 = period5.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        org.joda.time.PeriodType periodType10 = null;
//        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
//        int int12 = period11.size();
//        org.joda.time.Period period14 = period11.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        long long17 = dateTimeZone15.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone18.getName((long) ' ', locale20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone18.getName((long) (byte) 0, locale23);
//        boolean boolean25 = period11.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period27 = period11.withYears((int) (byte) 100);
//        org.joda.time.Period period29 = new org.joda.time.Period(100L);
//        org.joda.time.Period period30 = period29.toPeriod();
//        int int31 = period29.getYears();
//        org.joda.time.Period period33 = period29.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType36 = periodType34.getFieldType(0);
//        int int37 = period33.get(durationFieldType36);
//        org.joda.time.Period period39 = period27.withFieldAdded(durationFieldType36, 2);
//        boolean boolean40 = period5.isSupported(durationFieldType36);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(durationFieldType36, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        boolean boolean45 = periodType2.isSupported(durationFieldType36);
//        org.joda.time.field.UnsupportedDurationField unsupportedDurationField46 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType36);
//        try {
//            int int48 = unsupportedDurationField46.getValue((long) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(period7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28800001L) + "'", long17 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Pacific Standard Time" + "'", str24.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(periodType34);
//        org.junit.Assert.assertNotNull(durationFieldType36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(period39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(unsupportedDurationField46);
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone7 = zonedChronology6.getZone();
        org.joda.time.DateTimeZone dateTimeZone8 = zonedChronology6.getZone();
        java.lang.Object obj9 = null;
        boolean boolean10 = zonedChronology6.equals(obj9);
        org.joda.time.DurationField durationField11 = zonedChronology6.eras();
        try {
            long long19 = zonedChronology6.getDateTimeMillis((-1), (-28800000), (int) (short) 100, (int) (short) 0, (-97), 100, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(97, 7);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.Period period1 = org.joda.time.Period.months((-28378000));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period10 = new org.joda.time.Period((-35L), (long) ' ', periodType9);
        int[] intArray13 = gregorianChronology1.get((org.joda.time.ReadablePeriod) period10, (long) 4, (long) 'a');
        int int14 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.Period period8 = period6.withMonths((int) '4');
        org.joda.time.Period period10 = period8.minusSeconds((int) (short) 10);
        org.joda.time.Period period12 = period8.withWeeks((int) (short) 0);
        org.joda.time.Period period14 = period8.plusHours((int) ' ');
        org.joda.time.Period period16 = period14.minusDays(52);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test289");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        org.joda.time.Period period5 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period7 = period5.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        org.joda.time.PeriodType periodType10 = null;
//        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
//        int int12 = period11.size();
//        org.joda.time.Period period14 = period11.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        long long17 = dateTimeZone15.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone18.getName((long) ' ', locale20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone18.getName((long) (byte) 0, locale23);
//        boolean boolean25 = period11.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period27 = period11.withYears((int) (byte) 100);
//        org.joda.time.Period period29 = new org.joda.time.Period(100L);
//        org.joda.time.Period period30 = period29.toPeriod();
//        int int31 = period29.getYears();
//        org.joda.time.Period period33 = period29.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType36 = periodType34.getFieldType(0);
//        int int37 = period33.get(durationFieldType36);
//        org.joda.time.Period period39 = period27.withFieldAdded(durationFieldType36, 2);
//        boolean boolean40 = period5.isSupported(durationFieldType36);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(durationFieldType36, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        boolean boolean45 = periodType2.isSupported(durationFieldType36);
//        org.joda.time.field.UnsupportedDurationField unsupportedDurationField46 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType36);
//        try {
//            int int49 = unsupportedDurationField46.getDifference((long) (-970), (long) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(period7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28800001L) + "'", long17 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Pacific Standard Time" + "'", str24.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(periodType34);
//        org.junit.Assert.assertNotNull(durationFieldType36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(period39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(unsupportedDurationField46);
//    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.Period period5 = period3.plusMonths((int) '#');
        org.joda.time.Period period7 = period3.plusHours((int) (byte) 10);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
        int int12 = period11.size();
        org.joda.time.Period period14 = period11.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Duration duration16 = period11.toDurationFrom(readableInstant15);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType19 = periodType18.withSecondsRemoved();
        org.joda.time.Period period20 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration16, readableInstant17, periodType19);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        org.joda.time.DurationField durationField23 = gregorianChronology22.weekyears();
        org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) period7, periodType19, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.Period period26 = period24.plusYears(2);
        org.joda.time.Period period28 = period24.plusMillis(100);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(duration16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period28);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("LMT");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("PeriodType[Millis]");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        java.security.PermissionCollection permissionCollection5 = jodaTimePermission3.newPermissionCollection();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(permissionCollection5);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.Period period5 = period2.withFieldAdded(durationFieldType3, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.hourOfHalfday();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField5 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType3, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withYearsRemoved();
        org.joda.time.PeriodType periodType2 = periodType1.withDaysRemoved();
        java.lang.String str3 = periodType2.getName();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "YearDayTimeNoYearsNoDays" + "'", str3.equals("YearDayTimeNoYearsNoDays"));
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test295");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        long long2 = dateTimeZone0.convertUTCToLocal((-1L));
//        java.lang.String str4 = dateTimeZone0.getName(0L);
//        long long6 = dateTimeZone0.convertUTCToLocal(60010L);
//        org.joda.time.LocalDateTime localDateTime7 = null;
//        try {
//            boolean boolean8 = dateTimeZone0.isLocalDateTimeGap(localDateTime7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-28800001L) + "'", long2 == (-28800001L));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-28739990L) + "'", long6 == (-28739990L));
//    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = null;
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        int int4 = period3.size();
//        org.joda.time.Period period6 = period3.plusMonths((int) '#');
//        org.joda.time.Period period8 = period6.withMonths((int) '4');
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        org.joda.time.ReadableInstant readableInstant10 = null;
//        org.joda.time.PeriodType periodType11 = null;
//        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant9, readableInstant10, periodType11);
//        int int13 = period12.size();
//        org.joda.time.Period period15 = period12.plusMonths((int) '#');
//        org.joda.time.ReadableInstant readableInstant16 = null;
//        org.joda.time.Duration duration17 = period12.toDurationFrom(readableInstant16);
//        org.joda.time.ReadableInstant readableInstant18 = null;
//        org.joda.time.PeriodType periodType19 = null;
//        org.joda.time.Period period20 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration17, readableInstant18, periodType19);
//        org.joda.time.Period period22 = period20.plusMinutes((int) '4');
//        org.joda.time.Period period23 = period6.plus((org.joda.time.ReadablePeriod) period22);
//        org.joda.time.ReadableInstant readableInstant24 = null;
//        org.joda.time.ReadableInstant readableInstant25 = null;
//        org.joda.time.PeriodType periodType26 = null;
//        org.joda.time.Period period27 = new org.joda.time.Period(readableInstant24, readableInstant25, periodType26);
//        int int28 = period27.size();
//        org.joda.time.Period period30 = period27.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.getDefault();
//        long long33 = dateTimeZone31.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
//        java.util.Locale locale36 = null;
//        java.lang.String str37 = dateTimeZone34.getName((long) ' ', locale36);
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = dateTimeZone34.getName((long) (byte) 0, locale39);
//        boolean boolean41 = period27.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period43 = period27.withYears((int) (byte) 100);
//        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.yearWeekDayTime();
//        int int45 = periodType44.size();
//        org.joda.time.Period period46 = period27.withPeriodType(periodType44);
//        org.joda.time.Period period47 = new org.joda.time.Period((java.lang.Object) period22, periodType44);
//        org.joda.time.Period period49 = period47.minusSeconds(0);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
//        org.junit.Assert.assertNotNull(period6);
//        org.junit.Assert.assertNotNull(period8);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
//        org.junit.Assert.assertNotNull(period15);
//        org.junit.Assert.assertNotNull(duration17);
//        org.junit.Assert.assertNotNull(period22);
//        org.junit.Assert.assertNotNull(period23);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 8 + "'", int28 == 8);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-28800001L) + "'", long33 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Pacific Standard Time" + "'", str37.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Pacific Standard Time" + "'", str40.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(period43);
//        org.junit.Assert.assertNotNull(periodType44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 7 + "'", int45 == 7);
//        org.junit.Assert.assertNotNull(period46);
//        org.junit.Assert.assertNotNull(period49);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.PeriodType periodType5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant3, readableInstant4, periodType5);
        int int7 = period6.size();
        org.joda.time.Period period9 = period6.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period6.toDurationFrom(readableInstant10);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.PeriodType periodType13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration11, readableInstant12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant2, (org.joda.time.ReadableDuration) duration11);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.PeriodType periodType20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period(readableInstant18, readableInstant19, periodType20);
        int int22 = period21.size();
        org.joda.time.Period period24 = period21.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.Duration duration26 = period21.toDurationFrom(readableInstant25);
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.PeriodType periodType28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration26, readableInstant27, periodType28);
        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant17, (org.joda.time.ReadableDuration) duration26);
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.PeriodType periodType33 = org.joda.time.PeriodType.yearWeekDayTime();
        int int34 = periodType33.size();
        org.joda.time.Period period35 = new org.joda.time.Period(readableInstant31, readableInstant32, periodType33);
        org.joda.time.Period period36 = new org.joda.time.Period(readableInstant16, (org.joda.time.ReadableDuration) duration26, periodType33);
        org.joda.time.Period period37 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration11, periodType33);
        org.joda.time.Period period38 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration11);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(duration26);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 7 + "'", int34 == 7);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant1, readableInstant2, periodType3);
        int int5 = period4.size();
        org.joda.time.Period period7 = period4.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Duration duration9 = period4.toDurationFrom(readableInstant8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration9, readableInstant10, periodType11);
        org.joda.time.Period period13 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration9);
        long long14 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration9);
        long long15 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration9);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType19 = periodType18.withMinutesRemoved();
        org.joda.time.Period period20 = new org.joda.time.Period(1560626963539L, periodType19);
        org.joda.time.Period period21 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration9, readableInstant16, periodType19);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        int int4 = dateTimeZone2.getOffsetFromLocal(0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone5);
        long long8 = dateTimeZone0.getMillisKeepLocal(dateTimeZone6, 0L);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone4);
        long long7 = cachedDateTimeZone4.convertUTCToLocal(60010L);
        long long9 = cachedDateTimeZone4.nextTransition((long) '#');
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-28739990L) + "'", long7 == (-28739990L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9972000000L + "'", long9 == 9972000000L);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int6 = cachedDateTimeZone4.getOffsetFromLocal((long) (-28800000));
        long long8 = cachedDateTimeZone4.nextTransition((long) (-970));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-28800000) + "'", int6 == (-28800000));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9972000000L + "'", long8 == 9972000000L);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.junit.Assert.assertNotNull(strMap0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType4);
        int int6 = period5.size();
        org.joda.time.Period period8 = period5.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Duration duration10 = period5.toDurationFrom(readableInstant9);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.PeriodType periodType12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration10, readableInstant11, periodType12);
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration10);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.PeriodType periodType19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant17, readableInstant18, periodType19);
        int int21 = period20.size();
        org.joda.time.Period period23 = period20.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.Duration duration25 = period20.toDurationFrom(readableInstant24);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.PeriodType periodType27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration25, readableInstant26, periodType27);
        org.joda.time.Period period29 = new org.joda.time.Period(readableInstant16, (org.joda.time.ReadableDuration) duration25);
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.PeriodType periodType32 = org.joda.time.PeriodType.yearWeekDayTime();
        int int33 = periodType32.size();
        org.joda.time.Period period34 = new org.joda.time.Period(readableInstant30, readableInstant31, periodType32);
        org.joda.time.Period period35 = new org.joda.time.Period(readableInstant15, (org.joda.time.ReadableDuration) duration25, periodType32);
        org.joda.time.Period period36 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration10, periodType32);
        org.joda.time.ReadableInstant readableInstant37 = null;
        org.joda.time.Period period38 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration10, readableInstant37);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(duration10);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 8 + "'", int21 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(duration25);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 7 + "'", int33 == 7);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        long long9 = dateTimeZone7.convertUTCToLocal((-1L));
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        boolean boolean11 = zonedChronology6.equals((java.lang.Object) dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField12 = zonedChronology6.dayOfWeek();
        try {
            long long20 = zonedChronology6.getDateTimeMillis(0, (-97), (int) (short) 100, (int) (byte) 10, 100, 107, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-28800001L) + "'", long9 == (-28800001L));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-210782952000000L), 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test306");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        org.joda.time.Period period5 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period7 = period5.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        org.joda.time.PeriodType periodType10 = null;
//        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
//        int int12 = period11.size();
//        org.joda.time.Period period14 = period11.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        long long17 = dateTimeZone15.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone18.getName((long) ' ', locale20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone18.getName((long) (byte) 0, locale23);
//        boolean boolean25 = period11.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period27 = period11.withYears((int) (byte) 100);
//        org.joda.time.Period period29 = new org.joda.time.Period(100L);
//        org.joda.time.Period period30 = period29.toPeriod();
//        int int31 = period29.getYears();
//        org.joda.time.Period period33 = period29.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType36 = periodType34.getFieldType(0);
//        int int37 = period33.get(durationFieldType36);
//        org.joda.time.Period period39 = period27.withFieldAdded(durationFieldType36, 2);
//        boolean boolean40 = period5.isSupported(durationFieldType36);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(durationFieldType36, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        boolean boolean45 = periodType2.isSupported(durationFieldType36);
//        org.joda.time.field.UnsupportedDurationField unsupportedDurationField46 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType36);
//        try {
//            long long49 = unsupportedDurationField46.add(970L, 4);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(period7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28800001L) + "'", long17 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Pacific Standard Time" + "'", str24.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(periodType34);
//        org.junit.Assert.assertNotNull(durationFieldType36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(period39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(unsupportedDurationField46);
//    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        org.joda.time.Period period5 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period7 = period5.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        org.joda.time.PeriodType periodType10 = null;
//        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
//        int int12 = period11.size();
//        org.joda.time.Period period14 = period11.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        long long17 = dateTimeZone15.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone18.getName((long) ' ', locale20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone18.getName((long) (byte) 0, locale23);
//        boolean boolean25 = period11.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period27 = period11.withYears((int) (byte) 100);
//        org.joda.time.Period period29 = new org.joda.time.Period(100L);
//        org.joda.time.Period period30 = period29.toPeriod();
//        int int31 = period29.getYears();
//        org.joda.time.Period period33 = period29.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType36 = periodType34.getFieldType(0);
//        int int37 = period33.get(durationFieldType36);
//        org.joda.time.Period period39 = period27.withFieldAdded(durationFieldType36, 2);
//        boolean boolean40 = period5.isSupported(durationFieldType36);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(durationFieldType36, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        boolean boolean45 = periodType2.isSupported(durationFieldType36);
//        org.joda.time.field.UnsupportedDurationField unsupportedDurationField46 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType36);
//        try {
//            int int49 = unsupportedDurationField46.getDifference((-28739990L), (long) 34);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(period7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28800001L) + "'", long17 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Pacific Standard Time" + "'", str24.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(periodType34);
//        org.junit.Assert.assertNotNull(durationFieldType36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(period39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(unsupportedDurationField46);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant1, readableInstant2, periodType3);
        int int5 = period4.size();
        org.joda.time.Period period7 = period4.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Duration duration9 = period4.toDurationFrom(readableInstant8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration9, readableInstant10, periodType11);
        org.joda.time.Period period13 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration9);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.PeriodType periodType16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant14, readableInstant15, periodType16);
        int int18 = period17.size();
        org.joda.time.Period period20 = period17.plusMonths((int) '#');
        org.joda.time.Period period22 = period17.plusWeeks((int) (byte) 0);
        org.joda.time.Period period24 = period22.minusYears(0);
        org.joda.time.Period period25 = period13.withFields((org.joda.time.ReadablePeriod) period22);
        int int26 = period25.getDays();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.millis();
        java.lang.String str1 = periodType0.getName();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Millis" + "'", str1.equals("Millis"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfEra();
        try {
            long long8 = gregorianChronology1.getDateTimeMillis(100, (int) '4', (int) '4', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "Pacific Standard Time", "America/Los_Angeles");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale6 = null;
        java.lang.String str9 = defaultNameProvider0.getShortName(locale6, "America/Los_Angeles", "P35MT52M");
        java.util.Locale locale10 = null;
        java.lang.String str13 = defaultNameProvider0.getShortName(locale10, "PST", "org.joda.time.IllegalInstantException: Pacific Standard Time");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(str13);
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
//        long long3 = durationField0.subtract((long) 1, (-28800000));
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.ReadableInstant readableInstant5 = null;
//        org.joda.time.PeriodType periodType6 = null;
//        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant4, readableInstant5, periodType6);
//        int int8 = period7.size();
//        org.joda.time.Period period10 = period7.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        long long13 = dateTimeZone11.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = dateTimeZone14.getName((long) ' ', locale16);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone14.getName((long) (byte) 0, locale19);
//        boolean boolean21 = period7.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period23 = period7.withYears((int) (byte) 100);
//        org.joda.time.Period period25 = new org.joda.time.Period(100L);
//        org.joda.time.Period period26 = period25.toPeriod();
//        int int27 = period25.getYears();
//        org.joda.time.Period period29 = period25.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType(0);
//        int int33 = period29.get(durationFieldType32);
//        org.joda.time.Period period35 = period23.withFieldAdded(durationFieldType32, 2);
//        org.joda.time.field.DecoratedDurationField decoratedDurationField36 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType32);
//        org.joda.time.DurationFieldType durationFieldType37 = decoratedDurationField36.getType();
//        boolean boolean38 = decoratedDurationField36.isPrecise();
//        org.junit.Assert.assertNotNull(durationField0);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 28800001L + "'", long3 == 28800001L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
//        org.junit.Assert.assertNotNull(period10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-28800001L) + "'", long13 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Pacific Standard Time" + "'", str17.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Pacific Standard Time" + "'", str20.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(period23);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(period29);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertNotNull(durationFieldType32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertNotNull(durationFieldType37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant1, readableInstant2, periodType3);
        int int5 = period4.size();
        org.joda.time.Period period7 = period4.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Duration duration9 = period4.toDurationFrom(readableInstant8);
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration9);
        org.joda.time.MutablePeriod mutablePeriod11 = period10.toMutablePeriod();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.PeriodType periodType14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant12, readableInstant13, periodType14);
        org.joda.time.Period period16 = period15.negated();
        boolean boolean17 = period10.equals((java.lang.Object) period16);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertNotNull(mutablePeriod11);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.days();
//        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType3 = periodType1.getFieldType(0);
//        int int4 = periodType0.indexOf(durationFieldType3);
//        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType7 = periodType5.getFieldType(0);
//        org.joda.time.DurationField durationField8 = org.joda.time.field.MillisDurationField.INSTANCE;
//        long long11 = durationField8.subtract((long) 1, (-28800000));
//        org.joda.time.ReadableInstant readableInstant12 = null;
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.PeriodType periodType14 = null;
//        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant12, readableInstant13, periodType14);
//        int int16 = period15.size();
//        org.joda.time.Period period18 = period15.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        long long21 = dateTimeZone19.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = dateTimeZone22.getName((long) ' ', locale24);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = dateTimeZone22.getName((long) (byte) 0, locale27);
//        boolean boolean29 = period15.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period31 = period15.withYears((int) (byte) 100);
//        org.joda.time.Period period33 = new org.joda.time.Period(100L);
//        org.joda.time.Period period34 = period33.toPeriod();
//        int int35 = period33.getYears();
//        org.joda.time.Period period37 = period33.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType38 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType40 = periodType38.getFieldType(0);
//        int int41 = period37.get(durationFieldType40);
//        org.joda.time.Period period43 = period31.withFieldAdded(durationFieldType40, 2);
//        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField(durationField8, durationFieldType40);
//        org.joda.time.DurationFieldType[] durationFieldTypeArray45 = new org.joda.time.DurationFieldType[] { durationFieldType3, durationFieldType7, durationFieldType40 };
//        try {
//            org.joda.time.PeriodType periodType46 = org.joda.time.PeriodType.forFields(durationFieldTypeArray45);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: PeriodType does not support fields: [years, years]");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType0);
//        org.junit.Assert.assertNotNull(periodType1);
//        org.junit.Assert.assertNotNull(durationFieldType3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(periodType5);
//        org.junit.Assert.assertNotNull(durationFieldType7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800001L + "'", long11 == 28800001L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 8 + "'", int16 == 8);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-28800001L) + "'", long21 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Pacific Standard Time" + "'", str25.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Pacific Standard Time" + "'", str28.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(period31);
//        org.junit.Assert.assertNotNull(period34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//        org.junit.Assert.assertNotNull(period37);
//        org.junit.Assert.assertNotNull(periodType38);
//        org.junit.Assert.assertNotNull(durationFieldType40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertNotNull(period43);
//        org.junit.Assert.assertNotNull(durationFieldTypeArray45);
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(0, '4', (int) (short) 1, 0, (-107), true, (-28378000));
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeZoneBuilder0.toDateTimeZone("YearWeekDayTime", false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.joda.time.ReadablePartial readablePartial0 = null;
//        org.joda.time.ReadablePartial readablePartial1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.ReadableInstant readableInstant3 = null;
//        org.joda.time.PeriodType periodType4 = null;
//        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType4);
//        int int6 = period5.size();
//        org.joda.time.Period period8 = period5.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
//        long long11 = dateTimeZone9.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = dateTimeZone12.getName((long) ' ', locale14);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone12.getName((long) (byte) 0, locale17);
//        boolean boolean19 = period5.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period21 = period5.withYears((int) (byte) 100);
//        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.yearWeekDayTime();
//        int int23 = periodType22.size();
//        org.joda.time.Period period24 = period5.withPeriodType(periodType22);
//        org.joda.time.PeriodType periodType25 = periodType22.withYearsRemoved();
//        org.joda.time.PeriodType periodType26 = periodType25.withMonthsRemoved();
//        try {
//            org.joda.time.Period period27 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType25);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
//        org.junit.Assert.assertNotNull(period8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-28800001L) + "'", long11 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Pacific Standard Time" + "'", str15.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pacific Standard Time" + "'", str18.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(period21);
//        org.junit.Assert.assertNotNull(periodType22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 7 + "'", int23 == 7);
//        org.junit.Assert.assertNotNull(period24);
//        org.junit.Assert.assertNotNull(periodType25);
//        org.junit.Assert.assertNotNull(periodType26);
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        long long9 = dateTimeZone7.convertUTCToLocal((-1L));
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        boolean boolean11 = zonedChronology6.equals((java.lang.Object) dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField12 = zonedChronology6.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone13 = zonedChronology6.getZone();
        java.lang.String str14 = zonedChronology6.toString();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        long long17 = dateTimeZone15.convertUTCToLocal((-1L));
        java.util.TimeZone timeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
        int int21 = dateTimeZone19.getOffsetFromLocal(0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone19);
        int int24 = cachedDateTimeZone22.getOffsetFromLocal((long) (-28800000));
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone22);
        long long27 = dateTimeZone15.getMillisKeepLocal(dateTimeZone25, 0L);
        org.joda.time.Chronology chronology28 = zonedChronology6.withZone(dateTimeZone15);
        org.joda.time.ReadableInstant readableInstant29 = null;
        int int30 = dateTimeZone15.getOffset(readableInstant29);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-28800001L) + "'", long9 == (-28800001L));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]" + "'", str14.equals("ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28800001L) + "'", long17 == (-28800001L));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-28800000) + "'", int21 == (-28800000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-25200000) + "'", int30 == (-25200000));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.Period period8 = new org.joda.time.Period((int) (byte) 1, 0, (int) (byte) 100, (int) (byte) 0, 7, 7, (int) (byte) 10, 100);
        try {
            org.joda.time.Seconds seconds9 = period8.toStandardSeconds();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Seconds as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        long long3 = dateTimeZone1.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName((long) ' ', locale6);
//        org.joda.time.Chronology chronology8 = iSOChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        long long14 = dateTimeZone12.convertUTCToLocal((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology10, dateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone16 = zonedChronology15.getZone();
//        org.joda.time.DateTimeZone dateTimeZone17 = zonedChronology15.getZone();
//        java.lang.Object obj18 = null;
//        boolean boolean19 = zonedChronology15.equals(obj18);
//        boolean boolean20 = iSOChronology0.equals((java.lang.Object) zonedChronology15);
//        org.joda.time.DateTimeZone dateTimeZone21 = zonedChronology15.getZone();
//        long long24 = dateTimeZone21.convertLocalToUTC((long) (byte) 1, true);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-28800001L) + "'", long3 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-28800001L) + "'", long14 == (-28800001L));
//        org.junit.Assert.assertNotNull(zonedChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28800001L + "'", long24 == 28800001L);
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.Period period1 = org.joda.time.Period.hours(107);
        org.junit.Assert.assertNotNull(period1);
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone7 = zonedChronology6.getZone();
//        org.joda.time.DateTimeZone dateTimeZone8 = zonedChronology6.getZone();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
//        java.lang.Class<?> wildcardClass11 = dateTimeZone10.getClass();
//        org.joda.time.Chronology chronology12 = zonedChronology6.withZone(dateTimeZone10);
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.ReadableInstant readableInstant14 = null;
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant13, readableInstant14, periodType15);
//        int int17 = period16.size();
//        org.joda.time.Period period19 = period16.plusMonths((int) '#');
//        org.joda.time.Period period21 = period19.withMonths((int) '4');
//        org.joda.time.ReadableInstant readableInstant22 = null;
//        org.joda.time.ReadableInstant readableInstant23 = null;
//        org.joda.time.PeriodType periodType24 = null;
//        org.joda.time.Period period25 = new org.joda.time.Period(readableInstant22, readableInstant23, periodType24);
//        int int26 = period25.size();
//        org.joda.time.Period period28 = period25.plusMonths((int) '#');
//        org.joda.time.ReadableInstant readableInstant29 = null;
//        org.joda.time.Duration duration30 = period25.toDurationFrom(readableInstant29);
//        org.joda.time.ReadableInstant readableInstant31 = null;
//        org.joda.time.PeriodType periodType32 = null;
//        org.joda.time.Period period33 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration30, readableInstant31, periodType32);
//        org.joda.time.Period period35 = period33.plusMinutes((int) '4');
//        org.joda.time.Period period36 = period19.plus((org.joda.time.ReadablePeriod) period35);
//        org.joda.time.ReadableInstant readableInstant37 = null;
//        org.joda.time.ReadableInstant readableInstant38 = null;
//        org.joda.time.PeriodType periodType39 = null;
//        org.joda.time.Period period40 = new org.joda.time.Period(readableInstant37, readableInstant38, periodType39);
//        int int41 = period40.size();
//        org.joda.time.Period period43 = period40.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.getDefault();
//        long long46 = dateTimeZone44.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeUtils.getZone(dateTimeZone44);
//        java.util.Locale locale49 = null;
//        java.lang.String str50 = dateTimeZone47.getName((long) ' ', locale49);
//        java.util.Locale locale52 = null;
//        java.lang.String str53 = dateTimeZone47.getName((long) (byte) 0, locale52);
//        boolean boolean54 = period40.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period56 = period40.withYears((int) (byte) 100);
//        org.joda.time.PeriodType periodType57 = org.joda.time.PeriodType.yearWeekDayTime();
//        int int58 = periodType57.size();
//        org.joda.time.Period period59 = period40.withPeriodType(periodType57);
//        org.joda.time.Period period60 = new org.joda.time.Period((java.lang.Object) period35, periodType57);
//        boolean boolean61 = zonedChronology6.equals((java.lang.Object) periodType57);
//        org.joda.time.DateTimeField dateTimeField62 = zonedChronology6.centuryOfEra();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertNotNull(period21);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 8 + "'", int26 == 8);
//        org.junit.Assert.assertNotNull(period28);
//        org.junit.Assert.assertNotNull(duration30);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertNotNull(period36);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 8 + "'", int41 == 8);
//        org.junit.Assert.assertNotNull(period43);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-28800001L) + "'", long46 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Pacific Standard Time" + "'", str50.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "Pacific Standard Time" + "'", str53.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(period56);
//        org.junit.Assert.assertNotNull(periodType57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 7 + "'", int58 == 7);
//        org.junit.Assert.assertNotNull(period59);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertNotNull(dateTimeField62);
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.Period period8 = new org.joda.time.Period((int) (byte) 0, (int) (byte) -1, (int) (short) 10, 7, 97, (int) (short) 100, 8, 107);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("PeriodType[Years]");
        boolean boolean2 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalInstantException1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("Pacific Standard Time");
        org.joda.time.IllegalInstantException illegalInstantException3 = new org.joda.time.IllegalInstantException("Pacific Standard Time");
        illegalInstantException1.addSuppressed((java.lang.Throwable) illegalInstantException3);
        org.joda.time.IllegalFieldValueException illegalFieldValueException7 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", "");
        java.lang.String str8 = illegalFieldValueException7.getFieldName();
        illegalInstantException3.addSuppressed((java.lang.Throwable) illegalFieldValueException7);
        java.lang.String str10 = illegalFieldValueException7.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant1, readableInstant2, periodType3);
        int int5 = period4.size();
        org.joda.time.Period period7 = period4.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Duration duration9 = period4.toDurationFrom(readableInstant8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration9, readableInstant10, periodType11);
        org.joda.time.Period period13 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration9);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.PeriodType periodType16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant14, readableInstant15, periodType16);
        int int18 = period17.size();
        org.joda.time.Period period20 = period17.plusMonths((int) '#');
        org.joda.time.Period period22 = period17.plusWeeks((int) (byte) 0);
        org.joda.time.Period period24 = period22.minusYears(0);
        org.joda.time.Period period25 = period13.withFields((org.joda.time.ReadablePeriod) period22);
        org.joda.time.Period period26 = new org.joda.time.Period((java.lang.Object) period13);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period25);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant1, readableInstant2, periodType3);
        int int5 = period4.size();
        org.joda.time.Period period7 = period4.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Duration duration9 = period4.toDurationFrom(readableInstant8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration9, readableInstant10, periodType11);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType14 = periodType13.withYearsRemoved();
        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
        int int16 = periodType13.size();
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration9, periodType13);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType20 = periodType19.withMinutesRemoved();
        org.joda.time.Period period21 = new org.joda.time.Period(1560626963539L, periodType20);
        boolean boolean22 = org.joda.time.field.FieldUtils.equals((java.lang.Object) readableInstant0, (java.lang.Object) periodType20);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 5 + "'", int16 == 5);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.Period period1 = org.joda.time.Period.years(0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", "");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        java.lang.Number number4 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pacific Standard Time" + "'", str3.equals("Pacific Standard Time"));
        org.junit.Assert.assertNull(number4);
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        long long3 = dateTimeZone1.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName((long) ' ', locale6);
//        org.joda.time.Chronology chronology8 = iSOChronology0.withZone(dateTimeZone4);
//        org.joda.time.Period period10 = org.joda.time.Period.seconds(100);
//        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.weeks();
//        org.joda.time.PeriodType periodType12 = periodType11.withYearsRemoved();
//        org.joda.time.Period period13 = period10.normalizedStandard(periodType12);
//        boolean boolean14 = iSOChronology0.equals((java.lang.Object) period10);
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology0.minuteOfDay();
//        try {
//            long long21 = iSOChronology0.getDateTimeMillis((-28739990L), (-4), (-97), (int) '4', 1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -4 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-28800001L) + "'", long3 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(period10);
//        org.junit.Assert.assertNotNull(periodType11);
//        org.junit.Assert.assertNotNull(periodType12);
//        org.junit.Assert.assertNotNull(period13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        long long6 = dateTimeZone4.convertUTCToLocal((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.halfdayOfDay();
//        org.joda.time.DurationField durationField9 = zonedChronology7.weeks();
//        org.joda.time.Period period11 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period13 = period11.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant14 = null;
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        org.joda.time.PeriodType periodType16 = null;
//        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant14, readableInstant15, periodType16);
//        int int18 = period17.size();
//        org.joda.time.Period period20 = period17.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
//        long long23 = dateTimeZone21.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = dateTimeZone24.getName((long) ' ', locale26);
//        java.util.Locale locale29 = null;
//        java.lang.String str30 = dateTimeZone24.getName((long) (byte) 0, locale29);
//        boolean boolean31 = period17.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period33 = period17.withYears((int) (byte) 100);
//        org.joda.time.Period period35 = new org.joda.time.Period(100L);
//        org.joda.time.Period period36 = period35.toPeriod();
//        int int37 = period35.getYears();
//        org.joda.time.Period period39 = period35.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType40 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType42 = periodType40.getFieldType(0);
//        int int43 = period39.get(durationFieldType42);
//        org.joda.time.Period period45 = period33.withFieldAdded(durationFieldType42, 2);
//        boolean boolean46 = period11.isSupported(durationFieldType42);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException50 = new org.joda.time.IllegalFieldValueException(durationFieldType42, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        org.joda.time.field.ScaledDurationField scaledDurationField52 = new org.joda.time.field.ScaledDurationField(durationField9, durationFieldType42, (int) (short) 10);
//        try {
//            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField53 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, (org.joda.time.DurationField) scaledDurationField52);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-28800001L) + "'", long6 == (-28800001L));
//        org.junit.Assert.assertNotNull(zonedChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(period11);
//        org.junit.Assert.assertNotNull(period13);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
//        org.junit.Assert.assertNotNull(period20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-28800001L) + "'", long23 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Pacific Standard Time" + "'", str27.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Pacific Standard Time" + "'", str30.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(period36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(period39);
//        org.junit.Assert.assertNotNull(periodType40);
//        org.junit.Assert.assertNotNull(durationFieldType42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(period45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((-97));
        long long4 = dateTimeZone1.convertLocalToUTC(10L, true);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone1.getName((long) 52, locale6);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107L + "'", long4 == 107L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-00:00:00.097" + "'", str7.equals("-00:00:00.097"));
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.hourOfHalfday();
//        org.joda.time.DurationField durationField3 = gregorianChronology1.years();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.ReadableInstant readableInstant5 = null;
//        org.joda.time.PeriodType periodType6 = null;
//        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant4, readableInstant5, periodType6);
//        int int8 = period7.size();
//        org.joda.time.Period period10 = period7.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        long long13 = dateTimeZone11.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = dateTimeZone14.getName((long) ' ', locale16);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone14.getName((long) (byte) 0, locale19);
//        boolean boolean21 = period7.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period23 = period7.withYears((int) (byte) 100);
//        org.joda.time.Period period25 = new org.joda.time.Period(100L);
//        org.joda.time.Period period26 = period25.toPeriod();
//        int int27 = period25.getYears();
//        org.joda.time.Period period29 = period25.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType(0);
//        int int33 = period29.get(durationFieldType32);
//        org.joda.time.Period period35 = period23.withFieldAdded(durationFieldType32, 2);
//        org.joda.time.field.DecoratedDurationField decoratedDurationField36 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType32);
//        int int39 = decoratedDurationField36.getDifference((long) 7, (-776L));
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
//        org.junit.Assert.assertNotNull(period10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-28800001L) + "'", long13 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Pacific Standard Time" + "'", str17.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Pacific Standard Time" + "'", str20.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(period23);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(period29);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertNotNull(durationFieldType32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.year();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField5 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType3, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone7 = zonedChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology6.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone9 = zonedChronology6.getZone();
        try {
            long long14 = zonedChronology6.getDateTimeMillis(385200000, (int) (short) 100, (int) (short) 10, 970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 385200000 for year must be in the range [-292275054,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(7, 'a', (int) (byte) 10, (int) (byte) 100, 0, true, (int) ' ');
        try {
            org.joda.time.Period period9 = new org.joda.time.Period((java.lang.Object) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 0, 0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField6 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType4, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 385200000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440591.9583333335d + "'", double1 == 2440591.9583333335d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period3.toDurationFrom(readableInstant7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant9, periodType10);
        org.joda.time.Period period13 = period11.plusMinutes((int) '4');
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.PeriodType periodType16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant14, readableInstant15, periodType16);
        int int18 = period17.size();
        org.joda.time.Period period20 = period17.plusMonths((int) '#');
        org.joda.time.Period period22 = period20.withMonths((int) '4');
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.PeriodType periodType25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant23, readableInstant24, periodType25);
        int int27 = period26.size();
        org.joda.time.Period period29 = period26.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.Duration duration31 = period26.toDurationFrom(readableInstant30);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.PeriodType periodType33 = null;
        org.joda.time.Period period34 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration31, readableInstant32, periodType33);
        org.joda.time.Period period36 = period34.plusMinutes((int) '4');
        org.joda.time.Period period37 = period20.plus((org.joda.time.ReadablePeriod) period36);
        org.joda.time.Period period39 = period37.withYears(100);
        org.joda.time.Period period41 = period39.plusMonths(1);
        org.joda.time.Period period42 = period11.withFields((org.joda.time.ReadablePeriod) period39);
        int int43 = period42.getMinutes();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 8 + "'", int27 == 8);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(duration31);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 52 + "'", int43 == 52);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.dayOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.millisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.Period period8 = period6.withMonths((int) '4');
        org.joda.time.Period period10 = period6.plusMinutes((int) (short) 10);
        org.joda.time.Period period12 = period10.minusYears(0);
        org.joda.time.Period period14 = period10.minusSeconds((-97));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        long long2 = dateTimeZone0.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        int int5 = dateTimeZone0.getOffsetFromLocal((long) (byte) 0);
//        java.lang.String str7 = dateTimeZone0.getShortName((long) (byte) -1);
//        long long11 = dateTimeZone0.convertLocalToUTC((long) (byte) 10, true, (long) (byte) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        long long18 = gregorianChronology12.getDateTimeMillis((long) 1, 1, (int) ' ', 0, 0);
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology12.millisOfSecond();
//        org.joda.time.DurationField durationField20 = gregorianChronology12.hours();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-28800001L) + "'", long2 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800010L + "'", long11 == 28800010L);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-52080000L) + "'", long18 == (-52080000L));
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(durationField20);
//    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", "");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str5 = illegalFieldValueException2.getFieldName();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.Number number7 = illegalFieldValueException2.getUpperBound();
        org.joda.time.IllegalInstantException illegalInstantException9 = new org.joda.time.IllegalInstantException("YearWeekDayTime");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalInstantException9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pacific Standard Time" + "'", str3.equals("Pacific Standard Time"));
        org.junit.Assert.assertNull(durationFieldType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pacific Standard Time" + "'", str5.equals("Pacific Standard Time"));
        org.junit.Assert.assertNull(dateTimeFieldType6);
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("PT0.100S", "hi!");
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.Period period5 = period3.plusMonths((int) '#');
        org.joda.time.Period period7 = period3.plusHours((int) (byte) 10);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
        int int12 = period11.size();
        org.joda.time.Period period14 = period11.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Duration duration16 = period11.toDurationFrom(readableInstant15);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType19 = periodType18.withSecondsRemoved();
        org.joda.time.Period period20 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration16, readableInstant17, periodType19);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        org.joda.time.DurationField durationField23 = gregorianChronology22.weekyears();
        org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) period7, periodType19, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.Period period26 = period7.withMillis((int) (byte) 1);
        org.joda.time.Period period28 = period26.minusMillis(0);
        int int29 = period28.getYears();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(duration16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "PeriodType[Weeks]", (int) 'a', (-970));
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        int int7 = fixedDateTimeZone4.getOffsetFromLocal(315532800107L);
        int int9 = fixedDateTimeZone4.getStandardOffset((long) (-1));
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-970) + "'", int9 == (-970));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("P-1Y52MT-10S", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"P-1Y52MT-10S/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test353");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.hourOfHalfday();
//        org.joda.time.DurationField durationField3 = gregorianChronology1.years();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.ReadableInstant readableInstant5 = null;
//        org.joda.time.PeriodType periodType6 = null;
//        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant4, readableInstant5, periodType6);
//        int int8 = period7.size();
//        org.joda.time.Period period10 = period7.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        long long13 = dateTimeZone11.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = dateTimeZone14.getName((long) ' ', locale16);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone14.getName((long) (byte) 0, locale19);
//        boolean boolean21 = period7.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period23 = period7.withYears((int) (byte) 100);
//        org.joda.time.Period period25 = new org.joda.time.Period(100L);
//        org.joda.time.Period period26 = period25.toPeriod();
//        int int27 = period25.getYears();
//        org.joda.time.Period period29 = period25.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType(0);
//        int int33 = period29.get(durationFieldType32);
//        org.joda.time.Period period35 = period23.withFieldAdded(durationFieldType32, 2);
//        org.joda.time.field.DecoratedDurationField decoratedDurationField36 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType32);
//        long long38 = decoratedDurationField36.getMillis((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone39 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone39);
//        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology40.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
//        long long44 = dateTimeZone42.convertUTCToLocal((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology45 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology40, dateTimeZone42);
//        org.joda.time.DateTimeField dateTimeField46 = zonedChronology45.halfdayOfDay();
//        org.joda.time.DurationField durationField47 = zonedChronology45.weeks();
//        int int48 = decoratedDurationField36.compareTo(durationField47);
//        boolean boolean49 = decoratedDurationField36.isSupported();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
//        org.junit.Assert.assertNotNull(period10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-28800001L) + "'", long13 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Pacific Standard Time" + "'", str17.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Pacific Standard Time" + "'", str20.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(period23);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(period29);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertNotNull(durationFieldType32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 3155695200000L + "'", long38 == 3155695200000L);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-28800001L) + "'", long44 == (-28800001L));
//        org.junit.Assert.assertNotNull(zonedChronology45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(97L, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9700L + "'", long2 == 9700L);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (byte) 100, (int) 'a', 970);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.weekyears();
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.PeriodType periodType5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant3, readableInstant4, periodType5);
        int int7 = period6.size();
        org.joda.time.Period period9 = period6.plusMonths((int) '#');
        org.joda.time.Days days10 = period6.toStandardDays();
        int[] intArray13 = gregorianChronology1.get((org.joda.time.ReadablePeriod) days10, (long) (short) 100, 0L);
        org.joda.time.DurationField durationField14 = gregorianChronology1.halfdays();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(days10);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(durationField14);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        org.joda.time.Period period5 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period7 = period5.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        org.joda.time.PeriodType periodType10 = null;
//        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
//        int int12 = period11.size();
//        org.joda.time.Period period14 = period11.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        long long17 = dateTimeZone15.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone18.getName((long) ' ', locale20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone18.getName((long) (byte) 0, locale23);
//        boolean boolean25 = period11.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period27 = period11.withYears((int) (byte) 100);
//        org.joda.time.Period period29 = new org.joda.time.Period(100L);
//        org.joda.time.Period period30 = period29.toPeriod();
//        int int31 = period29.getYears();
//        org.joda.time.Period period33 = period29.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType36 = periodType34.getFieldType(0);
//        int int37 = period33.get(durationFieldType36);
//        org.joda.time.Period period39 = period27.withFieldAdded(durationFieldType36, 2);
//        boolean boolean40 = period5.isSupported(durationFieldType36);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(durationFieldType36, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        boolean boolean45 = periodType2.isSupported(durationFieldType36);
//        org.joda.time.field.UnsupportedDurationField unsupportedDurationField46 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType36);
//        boolean boolean47 = unsupportedDurationField46.isSupported();
//        try {
//            long long49 = unsupportedDurationField46.getValueAsLong(970L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(period7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28800001L) + "'", long17 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Pacific Standard Time" + "'", str24.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(periodType34);
//        org.junit.Assert.assertNotNull(durationFieldType36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(period39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(unsupportedDurationField46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        long long9 = dateTimeZone7.convertUTCToLocal((-1L));
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        boolean boolean11 = zonedChronology6.equals((java.lang.Object) dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField12 = zonedChronology6.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone13 = zonedChronology6.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
        java.lang.Class<?> wildcardClass16 = dateTimeZone15.getClass();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-28800001L) + "'", long9 == (-28800001L));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.Period period1 = new org.joda.time.Period(100L);
        org.joda.time.Period period2 = period1.toPeriod();
        org.joda.time.format.PeriodFormatter periodFormatter3 = null;
        java.lang.String str4 = period2.toString(periodFormatter3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((java.lang.Object) period2, chronology5);
        org.joda.time.Period period8 = period6.withSeconds((int) (byte) 0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PT0.100S" + "'", str4.equals("PT0.100S"));
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.Period period1 = new org.joda.time.Period(60010L);
        java.lang.Class<?> wildcardClass2 = period1.getClass();
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.hourOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.dayOfMonth();
        org.joda.time.Period period8 = new org.joda.time.Period(obj0, periodType2, (org.joda.time.Chronology) gregorianChronology4);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int6 = cachedDateTimeZone4.getOffsetFromLocal((long) (-28800000));
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone4);
        boolean boolean8 = cachedDateTimeZone4.isFixed();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-28800000) + "'", int6 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-25200000), (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: -28800000");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test364");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        org.joda.time.Period period5 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period7 = period5.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        org.joda.time.PeriodType periodType10 = null;
//        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
//        int int12 = period11.size();
//        org.joda.time.Period period14 = period11.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        long long17 = dateTimeZone15.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone18.getName((long) ' ', locale20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone18.getName((long) (byte) 0, locale23);
//        boolean boolean25 = period11.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period27 = period11.withYears((int) (byte) 100);
//        org.joda.time.Period period29 = new org.joda.time.Period(100L);
//        org.joda.time.Period period30 = period29.toPeriod();
//        int int31 = period29.getYears();
//        org.joda.time.Period period33 = period29.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType36 = periodType34.getFieldType(0);
//        int int37 = period33.get(durationFieldType36);
//        org.joda.time.Period period39 = period27.withFieldAdded(durationFieldType36, 2);
//        boolean boolean40 = period5.isSupported(durationFieldType36);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(durationFieldType36, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        boolean boolean45 = periodType2.isSupported(durationFieldType36);
//        org.joda.time.field.UnsupportedDurationField unsupportedDurationField46 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType36);
//        java.lang.String str47 = unsupportedDurationField46.getName();
//        try {
//            long long50 = unsupportedDurationField46.getMillis(0, 0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(period7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28800001L) + "'", long17 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Pacific Standard Time" + "'", str24.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(periodType34);
//        org.junit.Assert.assertNotNull(durationFieldType36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(period39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(unsupportedDurationField46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "years" + "'", str47.equals("years"));
//    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "PeriodType[Weeks]", (int) 'a', (-970));
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        long long7 = fixedDateTimeZone4.nextTransition((long) (-107));
        long long9 = fixedDateTimeZone4.previousTransition(2440588L);
        boolean boolean10 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-107L) + "'", long7 == (-107L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2440588L + "'", long9 == 2440588L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.PeriodType periodType5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant3, readableInstant4, periodType5);
        int int7 = period6.size();
        org.joda.time.Period period9 = period6.plusMonths((int) '#');
        org.joda.time.Period period11 = period9.withMonths((int) '4');
        org.joda.time.Period period13 = period11.minusSeconds((int) (short) 10);
        org.joda.time.Period period15 = period13.minusDays(7);
        org.joda.time.Period period16 = period2.plus((org.joda.time.ReadablePeriod) period15);
        try {
            org.joda.time.Hours hours17 = period15.toStandardHours();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Hours as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period16);
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = cachedDateTimeZone4.getName(1L, locale6);
//        long long9 = cachedDateTimeZone4.nextTransition(0L);
//        long long11 = cachedDateTimeZone4.nextTransition(1L);
//        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) cachedDateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9972000000L + "'", long9 == 9972000000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9972000000L + "'", long11 == 9972000000L);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.Period period8 = new org.joda.time.Period(100, (int) (byte) 10, 52, (int) (short) 1, 0, 0, (int) (short) 10, (int) (short) -1);
        org.joda.time.Period period10 = period8.minusYears(7);
        int int11 = period10.getWeeks();
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 52 + "'", int11 == 52);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("");
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = cachedDateTimeZone4.getName(1L, locale6);
//        long long9 = cachedDateTimeZone4.nextTransition(0L);
//        long long11 = cachedDateTimeZone4.nextTransition(1L);
//        long long14 = cachedDateTimeZone4.adjustOffset((long) 0, false);
//        long long18 = cachedDateTimeZone4.convertLocalToUTC(0L, false, (long) (byte) 10);
//        boolean boolean19 = cachedDateTimeZone4.isFixed();
//        java.lang.String str20 = cachedDateTimeZone4.toString();
//        java.lang.String str21 = cachedDateTimeZone4.getID();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9972000000L + "'", long9 == 9972000000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9972000000L + "'", long11 == 9972000000L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800000L + "'", long18 == 28800000L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "America/Los_Angeles" + "'", str20.equals("America/Los_Angeles"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "America/Los_Angeles" + "'", str21.equals("America/Los_Angeles"));
//    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test371");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = null;
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        int int4 = period3.size();
//        org.joda.time.Period period6 = period3.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        long long9 = dateTimeZone7.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone10.getName((long) ' ', locale12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone10.getName((long) (byte) 0, locale15);
//        boolean boolean17 = period3.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period19 = period3.withYears((int) (byte) 100);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearWeekDayTime();
//        int int21 = periodType20.size();
//        org.joda.time.Period period22 = period3.withPeriodType(periodType20);
//        org.joda.time.PeriodType periodType23 = periodType20.withYearsRemoved();
//        int int24 = periodType23.size();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
//        org.junit.Assert.assertNotNull(period6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-28800001L) + "'", long9 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Pacific Standard Time" + "'", str16.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 7 + "'", int21 == 7);
//        org.junit.Assert.assertNotNull(period22);
//        org.junit.Assert.assertNotNull(periodType23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
//    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.hourOfHalfday();
//        org.joda.time.DurationField durationField3 = gregorianChronology1.years();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.ReadableInstant readableInstant5 = null;
//        org.joda.time.PeriodType periodType6 = null;
//        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant4, readableInstant5, periodType6);
//        int int8 = period7.size();
//        org.joda.time.Period period10 = period7.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        long long13 = dateTimeZone11.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = dateTimeZone14.getName((long) ' ', locale16);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone14.getName((long) (byte) 0, locale19);
//        boolean boolean21 = period7.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period23 = period7.withYears((int) (byte) 100);
//        org.joda.time.Period period25 = new org.joda.time.Period(100L);
//        org.joda.time.Period period26 = period25.toPeriod();
//        int int27 = period25.getYears();
//        org.joda.time.Period period29 = period25.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType(0);
//        int int33 = period29.get(durationFieldType32);
//        org.joda.time.Period period35 = period23.withFieldAdded(durationFieldType32, 2);
//        org.joda.time.field.DecoratedDurationField decoratedDurationField36 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType32);
//        long long39 = decoratedDurationField36.add(0L, (int) (byte) 10);
//        boolean boolean40 = decoratedDurationField36.isPrecise();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
//        org.junit.Assert.assertNotNull(period10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-28800001L) + "'", long13 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Pacific Standard Time" + "'", str17.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Pacific Standard Time" + "'", str20.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(period23);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(period29);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertNotNull(durationFieldType32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 315532800000L + "'", long39 == 315532800000L);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        long long7 = dateTimeZone5.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        long long11 = dateTimeZone9.convertUTCToLocal((-1L));
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        boolean boolean13 = zonedChronology8.equals((java.lang.Object) dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology8.dayOfWeek();
        org.joda.time.Chronology chronology15 = zonedChronology8.withUTC();
        org.joda.time.Period period16 = new org.joda.time.Period((long) 7, (-210866673600000L), (org.joda.time.Chronology) zonedChronology8);
        try {
            long long21 = zonedChronology8.getDateTimeMillis(6, (int) (short) -1, (-28378000), (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-28800001L) + "'", long7 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-28800001L) + "'", long11 == (-28800001L));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology15);
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        org.joda.time.Period period5 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period7 = period5.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        org.joda.time.PeriodType periodType10 = null;
//        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
//        int int12 = period11.size();
//        org.joda.time.Period period14 = period11.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        long long17 = dateTimeZone15.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone18.getName((long) ' ', locale20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone18.getName((long) (byte) 0, locale23);
//        boolean boolean25 = period11.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period27 = period11.withYears((int) (byte) 100);
//        org.joda.time.Period period29 = new org.joda.time.Period(100L);
//        org.joda.time.Period period30 = period29.toPeriod();
//        int int31 = period29.getYears();
//        org.joda.time.Period period33 = period29.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType36 = periodType34.getFieldType(0);
//        int int37 = period33.get(durationFieldType36);
//        org.joda.time.Period period39 = period27.withFieldAdded(durationFieldType36, 2);
//        boolean boolean40 = period5.isSupported(durationFieldType36);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(durationFieldType36, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        boolean boolean45 = periodType2.isSupported(durationFieldType36);
//        org.joda.time.field.UnsupportedDurationField unsupportedDurationField46 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType36);
//        try {
//            long long48 = unsupportedDurationField46.getMillis(861369933240000000L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(period7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28800001L) + "'", long17 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Pacific Standard Time" + "'", str24.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(periodType34);
//        org.junit.Assert.assertNotNull(durationFieldType36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(period39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(unsupportedDurationField46);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period3.toDurationFrom(readableInstant7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant9, readableInstant10, periodType11);
        int int13 = period12.size();
        org.joda.time.Period period15 = period12.plusMonths((int) '#');
        org.joda.time.Period period17 = period15.withMonths((int) '4');
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.PeriodType periodType20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period(readableInstant18, readableInstant19, periodType20);
        int int22 = period21.size();
        org.joda.time.Period period24 = period21.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.Duration duration26 = period21.toDurationFrom(readableInstant25);
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.PeriodType periodType28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration26, readableInstant27, periodType28);
        org.joda.time.Period period31 = period29.plusMinutes((int) '4');
        org.joda.time.Period period32 = period15.plus((org.joda.time.ReadablePeriod) period31);
        boolean boolean33 = period3.equals((java.lang.Object) period15);
        org.joda.time.Duration duration34 = period3.toStandardDuration();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(duration26);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(duration34);
    }

//    @Test
//    public void test376() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test376");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = cachedDateTimeZone4.getName(1L, locale6);
//        long long9 = cachedDateTimeZone4.nextTransition(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone4);
//        org.joda.time.DurationField durationField11 = gregorianChronology10.months();
//        org.joda.time.DurationField durationField12 = gregorianChronology10.seconds();
//        long long15 = durationField12.subtract((long) (-25200000), (int) '#');
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9972000000L + "'", long9 == 9972000000L);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-25235000L) + "'", long15 == (-25235000L));
//    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test377");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        org.joda.time.Period period5 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period7 = period5.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        org.joda.time.PeriodType periodType10 = null;
//        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
//        int int12 = period11.size();
//        org.joda.time.Period period14 = period11.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        long long17 = dateTimeZone15.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone18.getName((long) ' ', locale20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone18.getName((long) (byte) 0, locale23);
//        boolean boolean25 = period11.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period27 = period11.withYears((int) (byte) 100);
//        org.joda.time.Period period29 = new org.joda.time.Period(100L);
//        org.joda.time.Period period30 = period29.toPeriod();
//        int int31 = period29.getYears();
//        org.joda.time.Period period33 = period29.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType36 = periodType34.getFieldType(0);
//        int int37 = period33.get(durationFieldType36);
//        org.joda.time.Period period39 = period27.withFieldAdded(durationFieldType36, 2);
//        boolean boolean40 = period5.isSupported(durationFieldType36);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(durationFieldType36, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        boolean boolean45 = periodType2.isSupported(durationFieldType36);
//        org.joda.time.field.UnsupportedDurationField unsupportedDurationField46 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType36);
//        java.lang.String str47 = unsupportedDurationField46.toString();
//        java.lang.String str48 = unsupportedDurationField46.toString();
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(period7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28800001L) + "'", long17 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Pacific Standard Time" + "'", str24.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(periodType34);
//        org.junit.Assert.assertNotNull(durationFieldType36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(period39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(unsupportedDurationField46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UnsupportedDurationField[years]" + "'", str47.equals("UnsupportedDurationField[years]"));
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "UnsupportedDurationField[years]" + "'", str48.equals("UnsupportedDurationField[years]"));
//    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Chronology chronology6 = gregorianChronology1.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField10 = new org.joda.time.field.DividedDateTimeField(dateTimeField7, dateTimeFieldType8, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType4 = periodType3.withSecondsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period(107L, (long) (-97), periodType4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        long long11 = dateTimeZone9.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology7, dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology12.halfdayOfDay();
        org.joda.time.DurationField durationField14 = zonedChronology12.minutes();
        org.joda.time.Period period15 = new org.joda.time.Period((-210866673600000L), periodType4, (org.joda.time.Chronology) zonedChronology12);
        org.joda.time.ReadablePartial readablePartial16 = null;
        try {
            int[] intArray18 = zonedChronology12.get(readablePartial16, (long) (-4));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-28800001L) + "'", long11 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.Period period2 = new org.joda.time.Period(315532800000L, (long) (byte) 0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period3.toDurationFrom(readableInstant7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant9, periodType10);
        org.joda.time.Period period13 = period11.plusMinutes((int) '4');
        org.joda.time.Period period15 = period13.minusMonths(970);
        org.joda.time.Period period17 = period13.plusDays(34);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.PeriodType periodType21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period(readableInstant19, readableInstant20, periodType21);
        int int23 = period22.size();
        org.joda.time.Period period25 = period22.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.Duration duration27 = period22.toDurationFrom(readableInstant26);
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.PeriodType periodType29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration27, readableInstant28, periodType29);
        org.joda.time.Period period31 = new org.joda.time.Period(readableInstant18, (org.joda.time.ReadableDuration) duration27);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.PeriodType periodType34 = null;
        org.joda.time.Period period35 = new org.joda.time.Period(readableInstant32, readableInstant33, periodType34);
        int int36 = period35.size();
        org.joda.time.Period period38 = period35.plusMonths((int) '#');
        org.joda.time.Period period40 = period35.plusWeeks((int) (byte) 0);
        org.joda.time.Period period42 = period40.minusYears(0);
        org.joda.time.Period period43 = period31.withFields((org.joda.time.ReadablePeriod) period40);
        org.joda.time.Period period44 = period13.withFields((org.joda.time.ReadablePeriod) period43);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 8 + "'", int23 == 8);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(duration27);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 8 + "'", int36 == 8);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertNotNull(period44);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period3.toDurationFrom(readableInstant7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant9, readableInstant10, periodType11);
        int int13 = period12.size();
        org.joda.time.Period period15 = period12.plusMonths((int) '#');
        org.joda.time.Period period17 = period15.withMonths((int) '4');
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.PeriodType periodType20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period(readableInstant18, readableInstant19, periodType20);
        int int22 = period21.size();
        org.joda.time.Period period24 = period21.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.Duration duration26 = period21.toDurationFrom(readableInstant25);
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.PeriodType periodType28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration26, readableInstant27, periodType28);
        org.joda.time.Period period31 = period29.plusMinutes((int) '4');
        org.joda.time.Period period32 = period15.plus((org.joda.time.ReadablePeriod) period31);
        boolean boolean33 = period3.equals((java.lang.Object) period15);
        int int34 = period15.size();
        org.joda.time.Period period36 = period15.plusMillis((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(duration26);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 8 + "'", int34 == 8);
        org.junit.Assert.assertNotNull(period36);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "Pacific Standard Time", "America/Los_Angeles");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "P-1Y-100WT-7H-7M-10.100S", "org.joda.time.IllegalInstantException: Pacific Standard Time");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        long long7 = dateTimeZone5.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        long long11 = dateTimeZone9.convertUTCToLocal((-1L));
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        boolean boolean13 = zonedChronology8.equals((java.lang.Object) dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology8.dayOfWeek();
        org.joda.time.Chronology chronology15 = zonedChronology8.withUTC();
        org.joda.time.Period period16 = new org.joda.time.Period((long) 7, (-210866673600000L), (org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTimeField dateTimeField17 = zonedChronology8.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone18 = zonedChronology8.getZone();
        try {
            long long26 = zonedChronology8.getDateTimeMillis(97, 34, (int) (byte) 0, (int) (short) -1, (-25200000), 2, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-28800001L) + "'", long7 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-28800001L) + "'", long11 == (-28800001L));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        org.joda.time.Period period5 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period7 = period5.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        org.joda.time.PeriodType periodType10 = null;
//        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
//        int int12 = period11.size();
//        org.joda.time.Period period14 = period11.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        long long17 = dateTimeZone15.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone18.getName((long) ' ', locale20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone18.getName((long) (byte) 0, locale23);
//        boolean boolean25 = period11.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period27 = period11.withYears((int) (byte) 100);
//        org.joda.time.Period period29 = new org.joda.time.Period(100L);
//        org.joda.time.Period period30 = period29.toPeriod();
//        int int31 = period29.getYears();
//        org.joda.time.Period period33 = period29.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType36 = periodType34.getFieldType(0);
//        int int37 = period33.get(durationFieldType36);
//        org.joda.time.Period period39 = period27.withFieldAdded(durationFieldType36, 2);
//        boolean boolean40 = period5.isSupported(durationFieldType36);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(durationFieldType36, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        boolean boolean45 = periodType2.isSupported(durationFieldType36);
//        org.joda.time.field.UnsupportedDurationField unsupportedDurationField46 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType36);
//        java.lang.String str47 = unsupportedDurationField46.toString();
//        try {
//            long long49 = unsupportedDurationField46.getValueAsLong((-28739990L));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(period7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28800001L) + "'", long17 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Pacific Standard Time" + "'", str24.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(periodType34);
//        org.junit.Assert.assertNotNull(durationFieldType36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(period39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(unsupportedDurationField46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UnsupportedDurationField[years]" + "'", str47.equals("UnsupportedDurationField[years]"));
//    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.Period period8 = period6.withMonths((int) '4');
        org.joda.time.Period period10 = period8.minusSeconds((int) (short) 10);
        org.joda.time.PeriodType periodType11 = null;
        org.joda.time.Period period12 = period10.withPeriodType(periodType11);
        org.joda.time.MutablePeriod mutablePeriod13 = period10.toMutablePeriod();
        try {
            org.joda.time.Weeks weeks14 = period10.toStandardWeeks();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Weeks as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(mutablePeriod13);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant1, readableInstant2, periodType3);
        int int5 = period4.size();
        org.joda.time.Period period7 = period4.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Duration duration9 = period4.toDurationFrom(readableInstant8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration9, readableInstant10, periodType11);
        org.joda.time.Period period13 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration9);
        org.joda.time.Period period15 = period13.plusMillis((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.hourOfHalfday();
        org.joda.time.DurationField durationField3 = gregorianChronology1.eras();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology1.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        long long8 = dateTimeZone4.adjustOffset(0L, true);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

//    @Test
//    public void test389() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test389");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        org.joda.time.Period period5 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period7 = period5.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        org.joda.time.PeriodType periodType10 = null;
//        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
//        int int12 = period11.size();
//        org.joda.time.Period period14 = period11.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        long long17 = dateTimeZone15.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone18.getName((long) ' ', locale20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone18.getName((long) (byte) 0, locale23);
//        boolean boolean25 = period11.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period27 = period11.withYears((int) (byte) 100);
//        org.joda.time.Period period29 = new org.joda.time.Period(100L);
//        org.joda.time.Period period30 = period29.toPeriod();
//        int int31 = period29.getYears();
//        org.joda.time.Period period33 = period29.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType36 = periodType34.getFieldType(0);
//        int int37 = period33.get(durationFieldType36);
//        org.joda.time.Period period39 = period27.withFieldAdded(durationFieldType36, 2);
//        boolean boolean40 = period5.isSupported(durationFieldType36);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(durationFieldType36, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        boolean boolean45 = periodType2.isSupported(durationFieldType36);
//        org.joda.time.field.UnsupportedDurationField unsupportedDurationField46 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType36);
//        java.lang.String str47 = unsupportedDurationField46.toString();
//        try {
//            long long50 = unsupportedDurationField46.getDifferenceAsLong(0L, (long) 4);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(period7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28800001L) + "'", long17 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Pacific Standard Time" + "'", str24.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(periodType34);
//        org.junit.Assert.assertNotNull(durationFieldType36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(period39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(unsupportedDurationField46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UnsupportedDurationField[years]" + "'", str47.equals("UnsupportedDurationField[years]"));
//    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology6.halfdayOfDay();
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        int int11 = dateTimeZone9.getOffsetFromLocal(0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        int int14 = cachedDateTimeZone12.getOffsetFromLocal((long) (-28800000));
        int int16 = cachedDateTimeZone12.getOffset((long) (byte) 0);
        org.joda.time.Chronology chronology17 = zonedChronology6.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone12);
        org.joda.time.DateTimeField dateTimeField18 = zonedChronology6.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField19 = zonedChronology6.yearOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-28800000) + "'", int14 == (-28800000));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-28800000) + "'", int16 == (-28800000));
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.dayOfMonth();
        org.joda.time.DurationField durationField5 = gregorianChronology1.eras();
        org.joda.time.Chronology chronology6 = gregorianChronology1.withUTC();
        int int7 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.Period period1 = org.joda.time.Period.hours(0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology6.halfdayOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField10 = new org.joda.time.field.DividedDateTimeField(dateTimeField7, dateTimeFieldType8, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.ReadablePartial readablePartial7 = null;
        try {
            long long9 = gregorianChronology1.set(readablePartial7, (long) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology6.halfdayOfDay();
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        int int11 = dateTimeZone9.getOffsetFromLocal(0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        int int14 = cachedDateTimeZone12.getOffsetFromLocal((long) (-28800000));
        int int16 = cachedDateTimeZone12.getOffset((long) (byte) 0);
        org.joda.time.Chronology chronology17 = zonedChronology6.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone12);
        org.joda.time.DateTimeField dateTimeField18 = zonedChronology6.clockhourOfDay();
        org.joda.time.ReadablePartial readablePartial19 = null;
        try {
            int[] intArray21 = zonedChronology6.get(readablePartial19, (-210858120000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-28800000) + "'", int14 == (-28800000));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-28800000) + "'", int16 == (-28800000));
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int6 = cachedDateTimeZone4.getOffsetFromLocal((long) (-28800000));
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone4, 1);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.era();
        org.joda.time.DurationField durationField10 = gregorianChronology8.months();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-28800000) + "'", int6 == (-28800000));
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(7, 'a', (int) (byte) 10, (int) (byte) 100, 0, true, (int) ' ');
        java.io.DataOutput dataOutput10 = null;
        try {
            dateTimeZoneBuilder0.writeTo("-00:00:00.097", dataOutput10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test398");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        org.joda.time.Period period5 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period7 = period5.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        org.joda.time.PeriodType periodType10 = null;
//        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
//        int int12 = period11.size();
//        org.joda.time.Period period14 = period11.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        long long17 = dateTimeZone15.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone18.getName((long) ' ', locale20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone18.getName((long) (byte) 0, locale23);
//        boolean boolean25 = period11.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period27 = period11.withYears((int) (byte) 100);
//        org.joda.time.Period period29 = new org.joda.time.Period(100L);
//        org.joda.time.Period period30 = period29.toPeriod();
//        int int31 = period29.getYears();
//        org.joda.time.Period period33 = period29.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType36 = periodType34.getFieldType(0);
//        int int37 = period33.get(durationFieldType36);
//        org.joda.time.Period period39 = period27.withFieldAdded(durationFieldType36, 2);
//        boolean boolean40 = period5.isSupported(durationFieldType36);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(durationFieldType36, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        boolean boolean45 = periodType2.isSupported(durationFieldType36);
//        org.joda.time.field.UnsupportedDurationField unsupportedDurationField46 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType36);
//        org.joda.time.DurationFieldType durationFieldType47 = unsupportedDurationField46.getType();
//        try {
//            long long50 = unsupportedDurationField46.getMillis(0L, (long) 385200000);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(period7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28800001L) + "'", long17 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Pacific Standard Time" + "'", str24.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(periodType34);
//        org.junit.Assert.assertNotNull(durationFieldType36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(period39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(unsupportedDurationField46);
//        org.junit.Assert.assertNotNull(durationFieldType47);
//    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        org.joda.time.Period period5 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period7 = period5.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        org.joda.time.PeriodType periodType10 = null;
//        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
//        int int12 = period11.size();
//        org.joda.time.Period period14 = period11.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        long long17 = dateTimeZone15.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone18.getName((long) ' ', locale20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone18.getName((long) (byte) 0, locale23);
//        boolean boolean25 = period11.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period27 = period11.withYears((int) (byte) 100);
//        org.joda.time.Period period29 = new org.joda.time.Period(100L);
//        org.joda.time.Period period30 = period29.toPeriod();
//        int int31 = period29.getYears();
//        org.joda.time.Period period33 = period29.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType36 = periodType34.getFieldType(0);
//        int int37 = period33.get(durationFieldType36);
//        org.joda.time.Period period39 = period27.withFieldAdded(durationFieldType36, 2);
//        boolean boolean40 = period5.isSupported(durationFieldType36);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(durationFieldType36, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        boolean boolean45 = periodType2.isSupported(durationFieldType36);
//        org.joda.time.field.UnsupportedDurationField unsupportedDurationField46 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType36);
//        boolean boolean47 = unsupportedDurationField46.isSupported();
//        try {
//            long long49 = unsupportedDurationField46.getMillis(7);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(period7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28800001L) + "'", long17 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Pacific Standard Time" + "'", str24.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(periodType34);
//        org.junit.Assert.assertNotNull(durationFieldType36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(period39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(unsupportedDurationField46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", "");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        java.lang.Number number5 = illegalFieldValueException2.getLowerBound();
        java.lang.String str6 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str7 = illegalFieldValueException2.getIllegalStringValue();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pacific Standard Time" + "'", str3.equals("Pacific Standard Time"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test401");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        org.joda.time.Period period5 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period7 = period5.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        org.joda.time.PeriodType periodType10 = null;
//        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
//        int int12 = period11.size();
//        org.joda.time.Period period14 = period11.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        long long17 = dateTimeZone15.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone18.getName((long) ' ', locale20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone18.getName((long) (byte) 0, locale23);
//        boolean boolean25 = period11.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period27 = period11.withYears((int) (byte) 100);
//        org.joda.time.Period period29 = new org.joda.time.Period(100L);
//        org.joda.time.Period period30 = period29.toPeriod();
//        int int31 = period29.getYears();
//        org.joda.time.Period period33 = period29.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType36 = periodType34.getFieldType(0);
//        int int37 = period33.get(durationFieldType36);
//        org.joda.time.Period period39 = period27.withFieldAdded(durationFieldType36, 2);
//        boolean boolean40 = period5.isSupported(durationFieldType36);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(durationFieldType36, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        boolean boolean45 = periodType2.isSupported(durationFieldType36);
//        org.joda.time.field.UnsupportedDurationField unsupportedDurationField46 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType36);
//        java.lang.String str47 = unsupportedDurationField46.toString();
//        try {
//            long long49 = unsupportedDurationField46.getValueAsLong(0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(period7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28800001L) + "'", long17 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Pacific Standard Time" + "'", str24.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(periodType34);
//        org.junit.Assert.assertNotNull(durationFieldType36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(period39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(unsupportedDurationField46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UnsupportedDurationField[years]" + "'", str47.equals("UnsupportedDurationField[years]"));
//    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(0, '4', (int) (short) 1, 0, (-107), true, (-28378000));
        java.io.DataOutput dataOutput10 = null;
        try {
            dateTimeZoneBuilder8.writeTo("PST", dataOutput10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.Period period8 = period3.plusWeeks((int) (byte) 0);
        org.joda.time.Period period10 = period3.withMonths((int) (byte) 1);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period12 = period3.normalizedStandard(periodType11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType4);
        org.joda.time.Period period6 = new org.joda.time.Period((-30610166822000L), (-35L), periodType4);
        org.joda.time.Period period8 = period6.minusMinutes((int) '#');
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period8);
    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test405");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        org.joda.time.Period period5 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period7 = period5.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        org.joda.time.PeriodType periodType10 = null;
//        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
//        int int12 = period11.size();
//        org.joda.time.Period period14 = period11.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        long long17 = dateTimeZone15.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone18.getName((long) ' ', locale20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone18.getName((long) (byte) 0, locale23);
//        boolean boolean25 = period11.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period27 = period11.withYears((int) (byte) 100);
//        org.joda.time.Period period29 = new org.joda.time.Period(100L);
//        org.joda.time.Period period30 = period29.toPeriod();
//        int int31 = period29.getYears();
//        org.joda.time.Period period33 = period29.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType36 = periodType34.getFieldType(0);
//        int int37 = period33.get(durationFieldType36);
//        org.joda.time.Period period39 = period27.withFieldAdded(durationFieldType36, 2);
//        boolean boolean40 = period5.isSupported(durationFieldType36);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(durationFieldType36, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        boolean boolean45 = periodType2.isSupported(durationFieldType36);
//        org.joda.time.field.UnsupportedDurationField unsupportedDurationField46 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType36);
//        boolean boolean47 = unsupportedDurationField46.isSupported();
//        try {
//            int int50 = unsupportedDurationField46.getDifference((long) 970, (-599900L));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(period7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28800001L) + "'", long17 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Pacific Standard Time" + "'", str24.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(periodType34);
//        org.junit.Assert.assertNotNull(durationFieldType36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(period39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(unsupportedDurationField46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology6.halfdayOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, 7, (int) (short) 1, 107);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType1 = periodType0.withDaysRemoved();
        org.joda.time.PeriodType periodType2 = periodType1.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        boolean boolean5 = periodType2.equals((java.lang.Object) (short) 100);
        java.lang.String str6 = periodType2.getName();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Seconds" + "'", str6.equals("Seconds"));
    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test408");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        org.joda.time.Period period5 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period7 = period5.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        org.joda.time.PeriodType periodType10 = null;
//        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
//        int int12 = period11.size();
//        org.joda.time.Period period14 = period11.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        long long17 = dateTimeZone15.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone18.getName((long) ' ', locale20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone18.getName((long) (byte) 0, locale23);
//        boolean boolean25 = period11.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period27 = period11.withYears((int) (byte) 100);
//        org.joda.time.Period period29 = new org.joda.time.Period(100L);
//        org.joda.time.Period period30 = period29.toPeriod();
//        int int31 = period29.getYears();
//        org.joda.time.Period period33 = period29.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType36 = periodType34.getFieldType(0);
//        int int37 = period33.get(durationFieldType36);
//        org.joda.time.Period period39 = period27.withFieldAdded(durationFieldType36, 2);
//        boolean boolean40 = period5.isSupported(durationFieldType36);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(durationFieldType36, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        boolean boolean45 = periodType2.isSupported(durationFieldType36);
//        org.joda.time.field.UnsupportedDurationField unsupportedDurationField46 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType36);
//        org.joda.time.DurationFieldType durationFieldType47 = unsupportedDurationField46.getType();
//        java.lang.String str48 = unsupportedDurationField46.getName();
//        java.lang.String str49 = unsupportedDurationField46.toString();
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(period7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28800001L) + "'", long17 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Pacific Standard Time" + "'", str24.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(periodType34);
//        org.junit.Assert.assertNotNull(durationFieldType36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(period39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(unsupportedDurationField46);
//        org.junit.Assert.assertNotNull(durationFieldType47);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "years" + "'", str48.equals("years"));
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "UnsupportedDurationField[years]" + "'", str49.equals("UnsupportedDurationField[years]"));
//    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.PeriodType periodType5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant3, readableInstant4, periodType5);
        int int7 = period6.size();
        org.joda.time.Period period9 = period6.plusMonths((int) '#');
        org.joda.time.Period period11 = period9.withMonths((int) '4');
        org.joda.time.Period period13 = period11.minusSeconds((int) (short) 10);
        org.joda.time.PeriodType periodType14 = null;
        org.joda.time.Period period15 = period13.withPeriodType(periodType14);
        org.joda.time.Period period16 = period2.plus((org.joda.time.ReadablePeriod) period13);
        int int17 = period13.getMonths();
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.PeriodType periodType24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period(readableInstant22, readableInstant23, periodType24);
        int int26 = period25.size();
        org.joda.time.Period period28 = period25.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.Duration duration30 = period25.toDurationFrom(readableInstant29);
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.PeriodType periodType32 = null;
        org.joda.time.Period period33 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration30, readableInstant31, periodType32);
        org.joda.time.Period period34 = new org.joda.time.Period(readableInstant21, (org.joda.time.ReadableDuration) duration30);
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.ReadableInstant readableInstant36 = null;
        org.joda.time.PeriodType periodType37 = org.joda.time.PeriodType.yearWeekDayTime();
        int int38 = periodType37.size();
        org.joda.time.Period period39 = new org.joda.time.Period(readableInstant35, readableInstant36, periodType37);
        org.joda.time.Period period40 = new org.joda.time.Period(readableInstant20, (org.joda.time.ReadableDuration) duration30, periodType37);
        org.joda.time.Period period41 = new org.joda.time.Period(readableInstant18, readableDuration19, periodType37);
        org.joda.time.PeriodType periodType42 = periodType37.withHoursRemoved();
        try {
            org.joda.time.Period period43 = new org.joda.time.Period((java.lang.Object) int17, periodType42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 8 + "'", int26 == 8);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(duration30);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 7 + "'", int38 == 7);
        org.junit.Assert.assertNotNull(periodType42);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.weekyears();
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.PeriodType periodType5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant3, readableInstant4, periodType5);
        int int7 = period6.size();
        org.joda.time.Period period9 = period6.plusMonths((int) '#');
        org.joda.time.Days days10 = period6.toStandardDays();
        int[] intArray13 = gregorianChronology1.get((org.joda.time.ReadablePeriod) days10, (long) (short) 100, 0L);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.PeriodType periodType16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant14, readableInstant15, periodType16);
        int int18 = period17.size();
        org.joda.time.Period period20 = period17.withSeconds(7);
        int[] intArray23 = gregorianChronology1.get((org.joda.time.ReadablePeriod) period20, (long) 'a', (long) 107);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(days10);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.Days days7 = period3.toStandardDays();
        org.joda.time.Period period9 = period3.withDays((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(days7);
        org.junit.Assert.assertNotNull(period9);
    }

//    @Test
//    public void test413() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test413");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        org.joda.time.Period period5 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period7 = period5.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        org.joda.time.PeriodType periodType10 = null;
//        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
//        int int12 = period11.size();
//        org.joda.time.Period period14 = period11.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        long long17 = dateTimeZone15.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone18.getName((long) ' ', locale20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone18.getName((long) (byte) 0, locale23);
//        boolean boolean25 = period11.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period27 = period11.withYears((int) (byte) 100);
//        org.joda.time.Period period29 = new org.joda.time.Period(100L);
//        org.joda.time.Period period30 = period29.toPeriod();
//        int int31 = period29.getYears();
//        org.joda.time.Period period33 = period29.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType36 = periodType34.getFieldType(0);
//        int int37 = period33.get(durationFieldType36);
//        org.joda.time.Period period39 = period27.withFieldAdded(durationFieldType36, 2);
//        boolean boolean40 = period5.isSupported(durationFieldType36);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(durationFieldType36, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        boolean boolean45 = periodType2.isSupported(durationFieldType36);
//        org.joda.time.field.UnsupportedDurationField unsupportedDurationField46 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType36);
//        org.joda.time.DurationFieldType durationFieldType47 = unsupportedDurationField46.getType();
//        java.lang.String str48 = unsupportedDurationField46.toString();
//        boolean boolean49 = unsupportedDurationField46.isSupported();
//        try {
//            long long51 = unsupportedDurationField46.getValueAsLong(315532800000L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(period7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28800001L) + "'", long17 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Pacific Standard Time" + "'", str24.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(periodType34);
//        org.junit.Assert.assertNotNull(durationFieldType36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(period39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(unsupportedDurationField46);
//        org.junit.Assert.assertNotNull(durationFieldType47);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "UnsupportedDurationField[years]" + "'", str48.equals("UnsupportedDurationField[years]"));
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", "");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str5 = illegalFieldValueException2.getFieldName();
        java.lang.String str6 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.String str7 = illegalFieldValueException2.toString();
        java.lang.String str8 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.Number number9 = illegalFieldValueException2.getLowerBound();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pacific Standard Time" + "'", str3.equals("Pacific Standard Time"));
        org.junit.Assert.assertNull(durationFieldType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pacific Standard Time" + "'", str5.equals("Pacific Standard Time"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for Pacific Standard Time is not supported" + "'", str7.equals("org.joda.time.IllegalFieldValueException: Value \"\" for Pacific Standard Time is not supported"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.Period period1 = org.joda.time.Period.years((-1));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 1, (long) (-4));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("P35MT52M");
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", "");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str5 = illegalFieldValueException2.getFieldName();
        java.lang.String str6 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.Number number7 = illegalFieldValueException2.getLowerBound();
        boolean boolean8 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pacific Standard Time" + "'", str3.equals("Pacific Standard Time"));
        org.junit.Assert.assertNull(durationFieldType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pacific Standard Time" + "'", str5.equals("Pacific Standard Time"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("LMT", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]", (java.lang.Number) 10.0f, (java.lang.Number) (byte) 100, (java.lang.Number) (short) 10);
        org.joda.time.IllegalInstantException illegalInstantException6 = new org.joda.time.IllegalInstantException("hi!");
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalInstantException6);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType4 = periodType3.withSecondsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period(107L, (long) (-97), periodType4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        long long11 = dateTimeZone9.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology7, dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology12.halfdayOfDay();
        org.joda.time.DurationField durationField14 = zonedChronology12.minutes();
        org.joda.time.Period period15 = new org.joda.time.Period((-210866673600000L), periodType4, (org.joda.time.Chronology) zonedChronology12);
        org.joda.time.DateTimeField dateTimeField16 = zonedChronology12.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField17 = zonedChronology12.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField18 = zonedChronology12.dayOfWeek();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-28800001L) + "'", long11 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int6 = cachedDateTimeZone4.getOffsetFromLocal((long) (-28800000));
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone4, 1);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.weekyear();
        java.lang.String str11 = gregorianChronology8.toString();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology8.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-28800000) + "'", int6 == (-28800000));
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "GregorianChronology[America/Los_Angeles,mdfw=1]" + "'", str11.equals("GregorianChronology[America/Los_Angeles,mdfw=1]"));
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test423");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        org.joda.time.Period period5 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period7 = period5.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        org.joda.time.PeriodType periodType10 = null;
//        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
//        int int12 = period11.size();
//        org.joda.time.Period period14 = period11.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        long long17 = dateTimeZone15.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone18.getName((long) ' ', locale20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone18.getName((long) (byte) 0, locale23);
//        boolean boolean25 = period11.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period27 = period11.withYears((int) (byte) 100);
//        org.joda.time.Period period29 = new org.joda.time.Period(100L);
//        org.joda.time.Period period30 = period29.toPeriod();
//        int int31 = period29.getYears();
//        org.joda.time.Period period33 = period29.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType36 = periodType34.getFieldType(0);
//        int int37 = period33.get(durationFieldType36);
//        org.joda.time.Period period39 = period27.withFieldAdded(durationFieldType36, 2);
//        boolean boolean40 = period5.isSupported(durationFieldType36);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(durationFieldType36, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        boolean boolean45 = periodType2.isSupported(durationFieldType36);
//        org.joda.time.field.UnsupportedDurationField unsupportedDurationField46 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType36);
//        java.lang.String str47 = unsupportedDurationField46.toString();
//        long long48 = unsupportedDurationField46.getUnitMillis();
//        try {
//            long long50 = unsupportedDurationField46.getValueAsLong((long) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(period7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28800001L) + "'", long17 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Pacific Standard Time" + "'", str24.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(periodType34);
//        org.junit.Assert.assertNotNull(durationFieldType36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(period39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(unsupportedDurationField46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UnsupportedDurationField[years]" + "'", str47.equals("UnsupportedDurationField[years]"));
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
//    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((-97));
        long long4 = dateTimeZone1.convertLocalToUTC(1560626963539L, true);
        java.lang.String str5 = dateTimeZone1.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560626963636L + "'", long4 == 1560626963636L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-00:00:00.097" + "'", str5.equals("-00:00:00.097"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, (-4));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(2);
        org.joda.time.Period period3 = period1.minusMonths((-28800000));
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("GregorianChronology[America/Los_Angeles,mdfw=1]", number1, (java.lang.Number) (short) 0, (java.lang.Number) (-35L));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("P100Y35M100WT52M", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"P100Y35M100WT52M/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        org.joda.time.Period period5 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period7 = period5.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        org.joda.time.PeriodType periodType10 = null;
//        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
//        int int12 = period11.size();
//        org.joda.time.Period period14 = period11.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        long long17 = dateTimeZone15.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone18.getName((long) ' ', locale20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone18.getName((long) (byte) 0, locale23);
//        boolean boolean25 = period11.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period27 = period11.withYears((int) (byte) 100);
//        org.joda.time.Period period29 = new org.joda.time.Period(100L);
//        org.joda.time.Period period30 = period29.toPeriod();
//        int int31 = period29.getYears();
//        org.joda.time.Period period33 = period29.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType36 = periodType34.getFieldType(0);
//        int int37 = period33.get(durationFieldType36);
//        org.joda.time.Period period39 = period27.withFieldAdded(durationFieldType36, 2);
//        boolean boolean40 = period5.isSupported(durationFieldType36);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(durationFieldType36, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        boolean boolean45 = periodType2.isSupported(durationFieldType36);
//        org.joda.time.field.UnsupportedDurationField unsupportedDurationField46 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType36);
//        boolean boolean47 = unsupportedDurationField46.isSupported();
//        try {
//            long long50 = unsupportedDurationField46.getDifferenceAsLong((long) (short) 0, (long) 34);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(period7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28800001L) + "'", long17 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Pacific Standard Time" + "'", str24.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(periodType34);
//        org.junit.Assert.assertNotNull(durationFieldType36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(period39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(unsupportedDurationField46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        org.joda.time.Period period5 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period7 = period5.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        org.joda.time.PeriodType periodType10 = null;
//        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
//        int int12 = period11.size();
//        org.joda.time.Period period14 = period11.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        long long17 = dateTimeZone15.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone18.getName((long) ' ', locale20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone18.getName((long) (byte) 0, locale23);
//        boolean boolean25 = period11.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period27 = period11.withYears((int) (byte) 100);
//        org.joda.time.Period period29 = new org.joda.time.Period(100L);
//        org.joda.time.Period period30 = period29.toPeriod();
//        int int31 = period29.getYears();
//        org.joda.time.Period period33 = period29.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType36 = periodType34.getFieldType(0);
//        int int37 = period33.get(durationFieldType36);
//        org.joda.time.Period period39 = period27.withFieldAdded(durationFieldType36, 2);
//        boolean boolean40 = period5.isSupported(durationFieldType36);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(durationFieldType36, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        boolean boolean45 = periodType2.isSupported(durationFieldType36);
//        org.joda.time.field.UnsupportedDurationField unsupportedDurationField46 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType36);
//        java.lang.String str47 = unsupportedDurationField46.toString();
//        try {
//            long long49 = unsupportedDurationField46.getMillis((long) 52);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(period7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28800001L) + "'", long17 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Pacific Standard Time" + "'", str24.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(periodType34);
//        org.junit.Assert.assertNotNull(durationFieldType36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(period39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(unsupportedDurationField46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UnsupportedDurationField[years]" + "'", str47.equals("UnsupportedDurationField[years]"));
//    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int6 = cachedDateTimeZone4.getOffsetFromLocal((long) (-28800000));
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone4, 1);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.weekyear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-28800000) + "'", int6 == (-28800000));
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfMonth();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant7, readableInstant8, periodType9);
        org.joda.time.Period period11 = period10.negated();
        org.joda.time.Period period13 = period11.minusYears((int) (byte) 0);
        int[] intArray15 = gregorianChronology3.get((org.joda.time.ReadablePeriod) period13, (-210782951940000L));
        org.joda.time.Period period16 = new org.joda.time.Period(10L, (-28799999L), (org.joda.time.Chronology) gregorianChronology3);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone4);
        long long7 = cachedDateTimeZone4.convertUTCToLocal(60010L);
        long long9 = cachedDateTimeZone4.nextTransition((long) (short) 1);
        java.lang.Class<?> wildcardClass10 = cachedDateTimeZone4.getClass();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-28739990L) + "'", long7 == (-28739990L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9972000000L + "'", long9 == 9972000000L);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test434");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.hourOfHalfday();
//        org.joda.time.DurationField durationField3 = gregorianChronology1.years();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.ReadableInstant readableInstant5 = null;
//        org.joda.time.PeriodType periodType6 = null;
//        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant4, readableInstant5, periodType6);
//        int int8 = period7.size();
//        org.joda.time.Period period10 = period7.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        long long13 = dateTimeZone11.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = dateTimeZone14.getName((long) ' ', locale16);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone14.getName((long) (byte) 0, locale19);
//        boolean boolean21 = period7.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period23 = period7.withYears((int) (byte) 100);
//        org.joda.time.Period period25 = new org.joda.time.Period(100L);
//        org.joda.time.Period period26 = period25.toPeriod();
//        int int27 = period25.getYears();
//        org.joda.time.Period period29 = period25.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType(0);
//        int int33 = period29.get(durationFieldType32);
//        org.joda.time.Period period35 = period23.withFieldAdded(durationFieldType32, 2);
//        org.joda.time.field.DecoratedDurationField decoratedDurationField36 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType32);
//        long long38 = decoratedDurationField36.getMillis((int) (short) 100);
//        org.joda.time.DurationField durationField39 = decoratedDurationField36.getWrappedField();
//        boolean boolean40 = decoratedDurationField36.isPrecise();
//        org.joda.time.PeriodType periodType41 = org.joda.time.PeriodType.yearWeekDayTime();
//        org.joda.time.PeriodType periodType42 = periodType41.withSecondsRemoved();
//        try {
//            org.joda.time.Period period43 = new org.joda.time.Period((java.lang.Object) decoratedDurationField36, periodType41);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.field.DecoratedDurationField");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
//        org.junit.Assert.assertNotNull(period10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-28800001L) + "'", long13 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Pacific Standard Time" + "'", str17.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Pacific Standard Time" + "'", str20.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(period23);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(period29);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertNotNull(durationFieldType32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 3155695200000L + "'", long38 == 3155695200000L);
//        org.junit.Assert.assertNotNull(durationField39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(periodType41);
//        org.junit.Assert.assertNotNull(periodType42);
//    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]", (java.lang.Number) 10.0f, (java.lang.Number) (byte) 100, (java.lang.Number) (short) 10);
        java.lang.Number number5 = illegalFieldValueException4.getIllegalNumberValue();
        boolean boolean6 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("P-1Y-100WT-7H-7M-10.100S", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        org.joda.time.Period period5 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period7 = period5.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        org.joda.time.PeriodType periodType10 = null;
//        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
//        int int12 = period11.size();
//        org.joda.time.Period period14 = period11.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        long long17 = dateTimeZone15.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone18.getName((long) ' ', locale20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone18.getName((long) (byte) 0, locale23);
//        boolean boolean25 = period11.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period27 = period11.withYears((int) (byte) 100);
//        org.joda.time.Period period29 = new org.joda.time.Period(100L);
//        org.joda.time.Period period30 = period29.toPeriod();
//        int int31 = period29.getYears();
//        org.joda.time.Period period33 = period29.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType36 = periodType34.getFieldType(0);
//        int int37 = period33.get(durationFieldType36);
//        org.joda.time.Period period39 = period27.withFieldAdded(durationFieldType36, 2);
//        boolean boolean40 = period5.isSupported(durationFieldType36);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(durationFieldType36, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        boolean boolean45 = periodType2.isSupported(durationFieldType36);
//        org.joda.time.field.UnsupportedDurationField unsupportedDurationField46 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType36);
//        org.joda.time.DurationFieldType durationFieldType47 = unsupportedDurationField46.getType();
//        java.lang.String str48 = unsupportedDurationField46.toString();
//        boolean boolean49 = unsupportedDurationField46.isSupported();
//        try {
//            long long52 = unsupportedDurationField46.add((long) 385200000, 1560652172544L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(period7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28800001L) + "'", long17 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Pacific Standard Time" + "'", str24.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(periodType34);
//        org.junit.Assert.assertNotNull(durationFieldType36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(period39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(unsupportedDurationField46);
//        org.junit.Assert.assertNotNull(durationFieldType47);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "UnsupportedDurationField[years]" + "'", str48.equals("UnsupportedDurationField[years]"));
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test438");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = null;
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        int int4 = period3.size();
//        org.joda.time.Period period6 = period3.plusMonths((int) '#');
//        org.joda.time.Period period8 = period3.plusWeeks((int) (byte) 0);
//        org.joda.time.Weeks weeks9 = period8.toStandardWeeks();
//        org.joda.time.ReadableInstant readableInstant10 = null;
//        org.joda.time.ReadableInstant readableInstant11 = null;
//        org.joda.time.PeriodType periodType12 = null;
//        org.joda.time.Period period13 = new org.joda.time.Period(readableInstant10, readableInstant11, periodType12);
//        int int14 = period13.size();
//        org.joda.time.Period period16 = period13.plusMonths((int) '#');
//        org.joda.time.ReadableInstant readableInstant17 = null;
//        org.joda.time.Duration duration18 = period13.toDurationFrom(readableInstant17);
//        org.joda.time.ReadableInstant readableInstant19 = null;
//        org.joda.time.PeriodType periodType20 = null;
//        org.joda.time.Period period21 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration18, readableInstant19, periodType20);
//        org.joda.time.Period period23 = period21.plusMinutes((int) '4');
//        org.joda.time.Period period24 = period8.plus((org.joda.time.ReadablePeriod) period23);
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone25);
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.getDefault();
//        long long30 = dateTimeZone28.convertUTCToLocal((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology31 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology26, dateTimeZone28);
//        org.joda.time.DateTimeField dateTimeField32 = zonedChronology31.halfdayOfDay();
//        org.joda.time.DurationField durationField33 = zonedChronology31.weeks();
//        org.joda.time.Period period35 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period37 = period35.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant38 = null;
//        org.joda.time.ReadableInstant readableInstant39 = null;
//        org.joda.time.PeriodType periodType40 = null;
//        org.joda.time.Period period41 = new org.joda.time.Period(readableInstant38, readableInstant39, periodType40);
//        int int42 = period41.size();
//        org.joda.time.Period period44 = period41.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
//        long long47 = dateTimeZone45.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeUtils.getZone(dateTimeZone45);
//        java.util.Locale locale50 = null;
//        java.lang.String str51 = dateTimeZone48.getName((long) ' ', locale50);
//        java.util.Locale locale53 = null;
//        java.lang.String str54 = dateTimeZone48.getName((long) (byte) 0, locale53);
//        boolean boolean55 = period41.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period57 = period41.withYears((int) (byte) 100);
//        org.joda.time.Period period59 = new org.joda.time.Period(100L);
//        org.joda.time.Period period60 = period59.toPeriod();
//        int int61 = period59.getYears();
//        org.joda.time.Period period63 = period59.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType64 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType66 = periodType64.getFieldType(0);
//        int int67 = period63.get(durationFieldType66);
//        org.joda.time.Period period69 = period57.withFieldAdded(durationFieldType66, 2);
//        boolean boolean70 = period35.isSupported(durationFieldType66);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException74 = new org.joda.time.IllegalFieldValueException(durationFieldType66, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        org.joda.time.field.ScaledDurationField scaledDurationField76 = new org.joda.time.field.ScaledDurationField(durationField33, durationFieldType66, (int) (short) 10);
//        int int77 = period23.get(durationFieldType66);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
//        org.junit.Assert.assertNotNull(period6);
//        org.junit.Assert.assertNotNull(period8);
//        org.junit.Assert.assertNotNull(weeks9);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(duration18);
//        org.junit.Assert.assertNotNull(period23);
//        org.junit.Assert.assertNotNull(period24);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-28800001L) + "'", long30 == (-28800001L));
//        org.junit.Assert.assertNotNull(zonedChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertNotNull(period37);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 8 + "'", int42 == 8);
//        org.junit.Assert.assertNotNull(period44);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-28800001L) + "'", long47 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone48);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Pacific Standard Time" + "'", str51.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Pacific Standard Time" + "'", str54.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(period57);
//        org.junit.Assert.assertNotNull(period60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
//        org.junit.Assert.assertNotNull(period63);
//        org.junit.Assert.assertNotNull(periodType64);
//        org.junit.Assert.assertNotNull(durationFieldType66);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
//        org.junit.Assert.assertNotNull(period69);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
//    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period10 = new org.joda.time.Period((-35L), (long) ' ', periodType9);
        int[] intArray13 = gregorianChronology1.get((org.joda.time.ReadablePeriod) period10, (long) 4, (long) 'a');
        org.joda.time.ReadablePartial readablePartial14 = null;
        try {
            int[] intArray16 = gregorianChronology1.get(readablePartial14, (long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.Period period4 = period2.plusMillis((int) (byte) 1);
        org.joda.time.Period period6 = period2.plusMillis(10);
        org.joda.time.Period period8 = period2.plusYears(2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int6 = cachedDateTimeZone4.getOffsetFromLocal((long) (-28800000));
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone4, 1);
        java.util.Locale locale10 = null;
        java.lang.String str11 = cachedDateTimeZone4.getShortName((-210933806400000L), locale10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-28800000) + "'", int6 == (-28800000));
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-07:52:58" + "'", str11.equals("-07:52:58"));
    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test442");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField7 = zonedChronology6.halfdayOfDay();
//        org.joda.time.DurationField durationField8 = zonedChronology6.weeks();
//        org.joda.time.Period period10 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period12 = period10.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.ReadableInstant readableInstant14 = null;
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant13, readableInstant14, periodType15);
//        int int17 = period16.size();
//        org.joda.time.Period period19 = period16.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        long long22 = dateTimeZone20.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = dateTimeZone23.getName((long) ' ', locale25);
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = dateTimeZone23.getName((long) (byte) 0, locale28);
//        boolean boolean30 = period16.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period32 = period16.withYears((int) (byte) 100);
//        org.joda.time.Period period34 = new org.joda.time.Period(100L);
//        org.joda.time.Period period35 = period34.toPeriod();
//        int int36 = period34.getYears();
//        org.joda.time.Period period38 = period34.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType41 = periodType39.getFieldType(0);
//        int int42 = period38.get(durationFieldType41);
//        org.joda.time.Period period44 = period32.withFieldAdded(durationFieldType41, 2);
//        boolean boolean45 = period10.isSupported(durationFieldType41);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException49 = new org.joda.time.IllegalFieldValueException(durationFieldType41, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        org.joda.time.field.ScaledDurationField scaledDurationField51 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType41, (int) (short) 10);
//        long long54 = scaledDurationField51.getDifferenceAsLong((-53509900L), 0L);
//        int int57 = scaledDurationField51.getValue((long) 100, (long) 10);
//        long long60 = scaledDurationField51.getDifferenceAsLong((long) (short) 0, (long) (byte) 10);
//        long long63 = scaledDurationField51.getMillis((long) (-4), 5L);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(period10);
//        org.junit.Assert.assertNotNull(period12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-28800001L) + "'", long22 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Pacific Standard Time" + "'", str26.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Pacific Standard Time" + "'", str29.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(period32);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(period38);
//        org.junit.Assert.assertNotNull(periodType39);
//        org.junit.Assert.assertNotNull(durationFieldType41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(period44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + (-24192000000L) + "'", long63 == (-24192000000L));
//    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.Period period1 = org.joda.time.Period.days(52);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.hourOfHalfday();
        org.joda.time.DurationField durationField3 = gregorianChronology1.eras();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology1.getZone();
        try {
            long long10 = gregorianChronology1.getDateTimeMillis(0L, (-970), (int) (short) 100, 100, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.Period period1 = org.joda.time.Period.months((-28800000));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 1, 9972000000L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 9972000000");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(7, 'a', (int) (byte) 10, (int) (byte) 100, 0, true, (int) ' ');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder8.addRecurringSavings("hi!", 4, (int) 'a', (int) (short) 0, ' ', 10, (int) (byte) 0, 100, false, 0);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder27 = dateTimeZoneBuilder8.addCutover(100, '4', (-25200000), (int) (short) 0, 4, true, (-28378000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder19);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.standard();
        org.joda.time.DurationFieldType durationFieldType2 = periodType0.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField4 = new org.joda.time.field.PreciseDurationField(durationFieldType2, (long) (short) -1);
        long long7 = preciseDurationField4.add(7L, 0);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(durationFieldType2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 7L + "'", long7 == 7L);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology1.getZone();
        long long9 = dateTimeZone5.convertLocalToUTC((-210866673600000L), true, 7L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-210866645222000L) + "'", long9 == (-210866645222000L));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = null;
        try {
            org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.Period period1 = org.joda.time.Period.months(34);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.Period period8 = period6.withMonths((int) '4');
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant9, readableInstant10, periodType11);
        int int13 = period12.size();
        org.joda.time.Period period15 = period12.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Duration duration17 = period12.toDurationFrom(readableInstant16);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.PeriodType periodType19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration17, readableInstant18, periodType19);
        org.joda.time.Period period22 = period20.plusMinutes((int) '4');
        org.joda.time.Period period23 = period6.plus((org.joda.time.ReadablePeriod) period22);
        org.joda.time.Period period25 = period23.withYears(100);
        org.joda.time.Period period27 = period23.withMinutes((-28800000));
        org.joda.time.Period period28 = period27.negated();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period28);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone7 = zonedChronology6.getZone();
        org.joda.time.DateTimeZone dateTimeZone8 = zonedChronology6.getZone();
        java.lang.Object obj9 = null;
        boolean boolean10 = zonedChronology6.equals(obj9);
        org.joda.time.DurationField durationField11 = zonedChronology6.weeks();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        long long7 = dateTimeZone5.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        long long11 = dateTimeZone9.convertUTCToLocal((-1L));
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        boolean boolean13 = zonedChronology8.equals((java.lang.Object) dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology8.dayOfWeek();
        org.joda.time.Chronology chronology15 = zonedChronology8.withUTC();
        org.joda.time.Period period16 = new org.joda.time.Period((long) 7, (-210866673600000L), (org.joda.time.Chronology) zonedChronology8);
        try {
            org.joda.time.Minutes minutes17 = period16.toStandardMinutes();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Minutes as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-28800001L) + "'", long7 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-28800001L) + "'", long11 == (-28800001L));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology15);
    }

//    @Test
//    public void test455() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test455");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        org.joda.time.Period period5 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period7 = period5.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        org.joda.time.PeriodType periodType10 = null;
//        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
//        int int12 = period11.size();
//        org.joda.time.Period period14 = period11.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        long long17 = dateTimeZone15.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone18.getName((long) ' ', locale20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone18.getName((long) (byte) 0, locale23);
//        boolean boolean25 = period11.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period27 = period11.withYears((int) (byte) 100);
//        org.joda.time.Period period29 = new org.joda.time.Period(100L);
//        org.joda.time.Period period30 = period29.toPeriod();
//        int int31 = period29.getYears();
//        org.joda.time.Period period33 = period29.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType36 = periodType34.getFieldType(0);
//        int int37 = period33.get(durationFieldType36);
//        org.joda.time.Period period39 = period27.withFieldAdded(durationFieldType36, 2);
//        boolean boolean40 = period5.isSupported(durationFieldType36);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(durationFieldType36, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        boolean boolean45 = periodType2.isSupported(durationFieldType36);
//        org.joda.time.field.UnsupportedDurationField unsupportedDurationField46 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType36);
//        boolean boolean47 = unsupportedDurationField46.isSupported();
//        try {
//            int int49 = unsupportedDurationField46.getValue((-24192000000L));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(period7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28800001L) + "'", long17 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Pacific Standard Time" + "'", str24.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(periodType34);
//        org.junit.Assert.assertNotNull(durationFieldType36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(period39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(unsupportedDurationField46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.hourOfHalfday();
        org.joda.time.DurationField durationField3 = gregorianChronology1.years();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.secondOfMinute();
        org.joda.time.Chronology chronology5 = gregorianChronology1.withUTC();
        org.joda.time.ReadablePartial readablePartial6 = null;
        try {
            int[] intArray8 = gregorianChronology1.get(readablePartial6, (long) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant4, readableInstant5, periodType6);
        int int8 = period7.size();
        org.joda.time.Period period10 = period7.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period7.toDurationFrom(readableInstant11);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.PeriodType periodType14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration12, readableInstant13, periodType14);
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant3, (org.joda.time.ReadableDuration) duration12);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.yearWeekDayTime();
        int int20 = periodType19.size();
        org.joda.time.Period period21 = new org.joda.time.Period(readableInstant17, readableInstant18, periodType19);
        org.joda.time.Period period22 = new org.joda.time.Period(readableInstant2, (org.joda.time.ReadableDuration) duration12, periodType19);
        org.joda.time.Period period23 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType19);
        try {
            org.joda.time.Period period25 = period23.withMonths((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 7 + "'", int20 == 7);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.Period period8 = period6.withMonths((int) '4');
        org.joda.time.Period period10 = period8.minusSeconds((int) (short) 10);
        org.joda.time.Period period12 = period10.minusDays(7);
        java.lang.String str13 = period12.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "P52M-7DT-10S" + "'", str13.equals("P52M-7DT-10S"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("org.joda.time.IllegalInstantException: Pacific Standard Time");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"org.joda.time.IllegalInstantException: Pacific Standard Time/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.dayOfMonth();
        java.lang.String str4 = gregorianChronology1.toString();
        org.joda.time.DurationField durationField5 = gregorianChronology1.years();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.centuryOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str4.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.dayOfMonth();
        int int4 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant5, readableInstant6, periodType7);
        org.joda.time.Period period9 = period8.negated();
        org.joda.time.Period period11 = period9.minusYears((int) (byte) 0);
        int[] intArray13 = gregorianChronology1.get((org.joda.time.ReadablePeriod) period11, (-210782951940000L));
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology1.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology1.yearOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test462");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.ReadableInstant readableInstant3 = null;
//        org.joda.time.PeriodType periodType4 = null;
//        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType4);
//        int int6 = period5.size();
//        org.joda.time.Period period8 = period5.plusMonths((int) '#');
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        org.joda.time.Duration duration10 = period5.toDurationFrom(readableInstant9);
//        org.joda.time.ReadableInstant readableInstant11 = null;
//        org.joda.time.PeriodType periodType12 = null;
//        org.joda.time.Period period13 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration10, readableInstant11, periodType12);
//        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration10);
//        long long15 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration10);
//        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration10);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.millisOfSecond();
//        boolean boolean21 = org.joda.time.field.FieldUtils.equals((java.lang.Object) duration10, (java.lang.Object) gregorianChronology18);
//        org.joda.time.ReadableInstant readableInstant22 = null;
//        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.months();
//        org.joda.time.Period period24 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration10, readableInstant22, periodType23);
//        org.joda.time.ReadableInstant readableInstant25 = null;
//        org.joda.time.ReadableInstant readableInstant27 = null;
//        org.joda.time.ReadableInstant readableInstant28 = null;
//        org.joda.time.PeriodType periodType29 = null;
//        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant27, readableInstant28, periodType29);
//        int int31 = period30.size();
//        org.joda.time.Period period33 = period30.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.getDefault();
//        long long36 = dateTimeZone34.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeUtils.getZone(dateTimeZone34);
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = dateTimeZone37.getName((long) ' ', locale39);
//        java.util.Locale locale42 = null;
//        java.lang.String str43 = dateTimeZone37.getName((long) (byte) 0, locale42);
//        boolean boolean44 = period30.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period46 = period30.withYears((int) (byte) 100);
//        org.joda.time.PeriodType periodType47 = org.joda.time.PeriodType.yearWeekDayTime();
//        int int48 = periodType47.size();
//        org.joda.time.Period period49 = period30.withPeriodType(periodType47);
//        org.joda.time.PeriodType periodType50 = periodType47.withYearsRemoved();
//        org.joda.time.Period period51 = new org.joda.time.Period(33L, periodType47);
//        org.joda.time.Period period52 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration10, readableInstant25, periodType47);
//        long long53 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration10);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
//        org.junit.Assert.assertNotNull(period8);
//        org.junit.Assert.assertNotNull(duration10);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(periodType23);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 8 + "'", int31 == 8);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-28800001L) + "'", long36 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Pacific Standard Time" + "'", str40.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Pacific Standard Time" + "'", str43.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(period46);
//        org.junit.Assert.assertNotNull(periodType47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 7 + "'", int48 == 7);
//        org.junit.Assert.assertNotNull(period49);
//        org.junit.Assert.assertNotNull(periodType50);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
//    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("Standard", (-25200000), (int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25200000 for Standard must be in the range [-1,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType2 = null;
        boolean boolean3 = period1.isSupported(durationFieldType2);
        try {
            int int5 = period1.getValue((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.Chronology chronology6 = gregorianChronology1.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.millisOfSecond();
        org.joda.time.Chronology chronology8 = gregorianChronology1.withUTC();
        org.joda.time.DurationField durationField9 = gregorianChronology1.seconds();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(107);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType4);
        int int6 = period5.size();
        org.joda.time.Period period8 = period5.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Duration duration10 = period5.toDurationFrom(readableInstant9);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.PeriodType periodType12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration10, readableInstant11, periodType12);
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration10);
        long long15 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration10);
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration10);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.millisOfSecond();
        boolean boolean21 = org.joda.time.field.FieldUtils.equals((java.lang.Object) duration10, (java.lang.Object) gregorianChronology18);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.months();
        org.joda.time.Period period24 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration10, readableInstant22, periodType23);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration10, readableInstant25);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(duration10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(periodType23);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.weekyears();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField5 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType3, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File[] fileArray2 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = zoneInfoCompiler0.compile(file1, fileArray2);
        java.io.BufferedReader bufferedReader4 = null;
        try {
            zoneInfoCompiler0.parseDataFile(bufferedReader4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fileArray2);
        org.junit.Assert.assertNotNull(strMap3);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.Period period8 = period6.withMonths((int) '4');
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant9, readableInstant10, periodType11);
        int int13 = period12.size();
        org.joda.time.Period period15 = period12.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Duration duration17 = period12.toDurationFrom(readableInstant16);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.PeriodType periodType19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration17, readableInstant18, periodType19);
        org.joda.time.Period period22 = period20.plusMinutes((int) '4');
        org.joda.time.Period period23 = period6.plus((org.joda.time.ReadablePeriod) period22);
        org.joda.time.Period period25 = period23.withYears(100);
        org.joda.time.Period period27 = period25.plusWeeks((int) (short) 100);
        org.joda.time.Period period29 = period27.minusMonths((-1));
        org.joda.time.Period period31 = period27.minusYears(107);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period31);
    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = null;
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        int int4 = period3.size();
//        org.joda.time.Period period6 = period3.plusMonths((int) '#');
//        org.joda.time.Period period8 = period6.withMonths((int) '4');
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        org.joda.time.ReadableInstant readableInstant10 = null;
//        org.joda.time.PeriodType periodType11 = null;
//        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant9, readableInstant10, periodType11);
//        int int13 = period12.size();
//        org.joda.time.Period period15 = period12.plusMonths((int) '#');
//        org.joda.time.ReadableInstant readableInstant16 = null;
//        org.joda.time.Duration duration17 = period12.toDurationFrom(readableInstant16);
//        org.joda.time.ReadableInstant readableInstant18 = null;
//        org.joda.time.PeriodType periodType19 = null;
//        org.joda.time.Period period20 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration17, readableInstant18, periodType19);
//        org.joda.time.Period period22 = period20.plusMinutes((int) '4');
//        org.joda.time.Period period23 = period6.plus((org.joda.time.ReadablePeriod) period22);
//        org.joda.time.ReadableInstant readableInstant24 = null;
//        org.joda.time.ReadableInstant readableInstant25 = null;
//        org.joda.time.PeriodType periodType26 = null;
//        org.joda.time.Period period27 = new org.joda.time.Period(readableInstant24, readableInstant25, periodType26);
//        int int28 = period27.size();
//        org.joda.time.Period period30 = period27.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.getDefault();
//        long long33 = dateTimeZone31.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
//        java.util.Locale locale36 = null;
//        java.lang.String str37 = dateTimeZone34.getName((long) ' ', locale36);
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = dateTimeZone34.getName((long) (byte) 0, locale39);
//        boolean boolean41 = period27.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period43 = period27.withYears((int) (byte) 100);
//        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.yearWeekDayTime();
//        int int45 = periodType44.size();
//        org.joda.time.Period period46 = period27.withPeriodType(periodType44);
//        org.joda.time.Period period47 = new org.joda.time.Period((java.lang.Object) period22, periodType44);
//        org.joda.time.DurationFieldType durationFieldType48 = null;
//        boolean boolean49 = periodType44.isSupported(durationFieldType48);
//        int int50 = periodType44.size();
//        java.lang.String str51 = periodType44.getName();
//        org.joda.time.PeriodType periodType52 = periodType44.withDaysRemoved();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
//        org.junit.Assert.assertNotNull(period6);
//        org.junit.Assert.assertNotNull(period8);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
//        org.junit.Assert.assertNotNull(period15);
//        org.junit.Assert.assertNotNull(duration17);
//        org.junit.Assert.assertNotNull(period22);
//        org.junit.Assert.assertNotNull(period23);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 8 + "'", int28 == 8);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-28800001L) + "'", long33 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Pacific Standard Time" + "'", str37.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Pacific Standard Time" + "'", str40.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(period43);
//        org.junit.Assert.assertNotNull(periodType44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 7 + "'", int45 == 7);
//        org.junit.Assert.assertNotNull(period46);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 7 + "'", int50 == 7);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "YearWeekDayTime" + "'", str51.equals("YearWeekDayTime"));
//        org.junit.Assert.assertNotNull(periodType52);
//    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField7 = zonedChronology6.halfdayOfDay();
//        org.joda.time.DurationField durationField8 = zonedChronology6.weeks();
//        org.joda.time.Period period10 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period12 = period10.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.ReadableInstant readableInstant14 = null;
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant13, readableInstant14, periodType15);
//        int int17 = period16.size();
//        org.joda.time.Period period19 = period16.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        long long22 = dateTimeZone20.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = dateTimeZone23.getName((long) ' ', locale25);
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = dateTimeZone23.getName((long) (byte) 0, locale28);
//        boolean boolean30 = period16.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period32 = period16.withYears((int) (byte) 100);
//        org.joda.time.Period period34 = new org.joda.time.Period(100L);
//        org.joda.time.Period period35 = period34.toPeriod();
//        int int36 = period34.getYears();
//        org.joda.time.Period period38 = period34.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType41 = periodType39.getFieldType(0);
//        int int42 = period38.get(durationFieldType41);
//        org.joda.time.Period period44 = period32.withFieldAdded(durationFieldType41, 2);
//        boolean boolean45 = period10.isSupported(durationFieldType41);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException49 = new org.joda.time.IllegalFieldValueException(durationFieldType41, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        org.joda.time.field.ScaledDurationField scaledDurationField51 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType41, (int) (short) 10);
//        int int54 = scaledDurationField51.getValue((-52080000L), (long) (-28378000));
//        org.joda.time.DurationField durationField55 = scaledDurationField51.getWrappedField();
//        long long58 = scaledDurationField51.getValueAsLong((-28378010L), (long) 34);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(period10);
//        org.junit.Assert.assertNotNull(period12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-28800001L) + "'", long22 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Pacific Standard Time" + "'", str26.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Pacific Standard Time" + "'", str29.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(period32);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(period38);
//        org.junit.Assert.assertNotNull(periodType39);
//        org.junit.Assert.assertNotNull(durationFieldType41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(period44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertNotNull(durationField55);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 0L + "'", long58 == 0L);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(33L);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (-53509900L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(107);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-107) + "'", int1 == (-107));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.Period period1 = new org.joda.time.Period((long) 10);
        int int2 = period1.getDays();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 52, (long) (short) 0, periodType2);
        org.joda.time.Duration duration4 = period3.toStandardDuration();
        org.junit.Assert.assertNotNull(duration4);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.Period period5 = period3.plusMonths((int) '#');
        org.joda.time.Period period7 = period3.plusHours((int) (byte) 10);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
        int int12 = period11.size();
        org.joda.time.Period period14 = period11.plusMonths((int) '#');
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Duration duration16 = period11.toDurationFrom(readableInstant15);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType19 = periodType18.withSecondsRemoved();
        org.joda.time.Period period20 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration16, readableInstant17, periodType19);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        org.joda.time.DurationField durationField23 = gregorianChronology22.weekyears();
        org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) period7, periodType19, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.Period period26 = period7.withMillis((int) (byte) 1);
        org.joda.time.Period period28 = period7.plusSeconds(0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(duration16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period28);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("Pacific Standard Time");
        org.joda.time.IllegalInstantException illegalInstantException3 = new org.joda.time.IllegalInstantException("Pacific Standard Time");
        illegalInstantException1.addSuppressed((java.lang.Throwable) illegalInstantException3);
        java.lang.Throwable[] throwableArray5 = illegalInstantException1.getSuppressed();
        java.lang.String str6 = illegalInstantException1.toString();
        java.lang.Throwable[] throwableArray7 = illegalInstantException1.getSuppressed();
        java.lang.Throwable[] throwableArray8 = illegalInstantException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalInstantException: Pacific Standard Time" + "'", str6.equals("org.joda.time.IllegalInstantException: Pacific Standard Time"));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.size();
        org.joda.time.Period period6 = period3.plusMonths((int) '#');
        org.joda.time.Period period8 = period3.plusWeeks((int) (byte) 0);
        org.joda.time.Period period10 = period8.minusYears(0);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        int int12 = period10.indexOf(durationFieldType11);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period10.toDurationFrom(readableInstant13);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(duration14);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "PeriodType[Weeks]", (int) 'a', (-970));
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.LocalDateTime localDateTime7 = null;
        try {
            boolean boolean8 = dateTimeZone6.isLocalDateTimeGap(localDateTime7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        long long7 = dateTimeZone5.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        long long11 = dateTimeZone9.convertUTCToLocal((-1L));
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        boolean boolean13 = zonedChronology8.equals((java.lang.Object) dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology8.dayOfWeek();
        org.joda.time.Chronology chronology15 = zonedChronology8.withUTC();
        org.joda.time.Period period16 = new org.joda.time.Period((long) 7, (-210866673600000L), (org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTimeField dateTimeField17 = zonedChronology8.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone18 = zonedChronology8.getZone();
        org.joda.time.DurationField durationField19 = zonedChronology8.millis();
        org.joda.time.DurationFieldType durationFieldType20 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField21 = new org.joda.time.field.DecoratedDurationField(durationField19, durationFieldType20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-28800001L) + "'", long7 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-28800001L) + "'", long11 == (-28800001L));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(durationField19);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "PeriodType[Weeks]", (int) 'a', (-970));
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        int int7 = fixedDateTimeZone4.getOffset(3155695200000L);
        int int9 = fixedDateTimeZone4.getStandardOffset((long) (short) 100);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-970) + "'", int9 == (-970));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        long long9 = dateTimeZone7.convertUTCToLocal((-1L));
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        boolean boolean11 = zonedChronology6.equals((java.lang.Object) dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField12 = zonedChronology6.dayOfWeek();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField14 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField12, dateTimeFieldType13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-28800001L) + "'", long9 == (-28800001L));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        long long9 = dateTimeZone7.convertUTCToLocal((-1L));
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        boolean boolean11 = zonedChronology6.equals((java.lang.Object) dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField12 = zonedChronology6.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone13 = zonedChronology6.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        java.lang.String str15 = iSOChronology14.toString();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800001L) + "'", long5 == (-28800001L));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-28800001L) + "'", long9 == (-28800001L));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str15.equals("ISOChronology[America/Los_Angeles]"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.millisOfSecond();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 1, 1560626963636L, periodType3, (org.joda.time.Chronology) gregorianChronology5);
        java.lang.String str9 = gregorianChronology5.toString();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str9.equals("GregorianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 34, 0, 34);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone5 = dateTimeZoneBuilder0.toDateTimeZone("org.joda.time.IllegalFieldValueException: Value \"\" for Pacific Standard Time is not supported", true);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder0.addRecurringSavings("org.joda.time.IllegalInstantException: Pacific Standard Time", (-28800000), 1, 5061, ' ', (-97), (int) (short) 100, (-970), true, 107);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test493");
//        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
//        long long3 = durationField0.subtract((long) 1, (-28800000));
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.ReadableInstant readableInstant5 = null;
//        org.joda.time.PeriodType periodType6 = null;
//        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant4, readableInstant5, periodType6);
//        int int8 = period7.size();
//        org.joda.time.Period period10 = period7.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        long long13 = dateTimeZone11.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = dateTimeZone14.getName((long) ' ', locale16);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone14.getName((long) (byte) 0, locale19);
//        boolean boolean21 = period7.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period23 = period7.withYears((int) (byte) 100);
//        org.joda.time.Period period25 = new org.joda.time.Period(100L);
//        org.joda.time.Period period26 = period25.toPeriod();
//        int int27 = period25.getYears();
//        org.joda.time.Period period29 = period25.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType(0);
//        int int33 = period29.get(durationFieldType32);
//        org.joda.time.Period period35 = period23.withFieldAdded(durationFieldType32, 2);
//        org.joda.time.field.DecoratedDurationField decoratedDurationField36 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType32);
//        org.joda.time.DurationFieldType durationFieldType37 = decoratedDurationField36.getType();
//        long long39 = decoratedDurationField36.getValueAsLong((long) 1);
//        org.joda.time.DurationField durationField40 = decoratedDurationField36.getWrappedField();
//        org.junit.Assert.assertNotNull(durationField0);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 28800001L + "'", long3 == 28800001L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
//        org.junit.Assert.assertNotNull(period10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-28800001L) + "'", long13 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Pacific Standard Time" + "'", str17.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Pacific Standard Time" + "'", str20.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(period23);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(period29);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertNotNull(durationFieldType32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertNotNull(durationFieldType37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1L + "'", long39 == 1L);
//        org.junit.Assert.assertNotNull(durationField40);
//    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ZonedChronology[GregorianChronol...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.hourOfHalfday();
        org.joda.time.DurationField durationField3 = gregorianChronology1.eras();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology1.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone5);
        try {
            long long11 = gregorianChronology6.getDateTimeMillis((-4), (-970), (int) (short) 100, 970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -970 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 52, periodType1, chronology2);
    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
//        long long3 = durationField0.subtract((long) 1, (-28800000));
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.ReadableInstant readableInstant5 = null;
//        org.joda.time.PeriodType periodType6 = null;
//        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant4, readableInstant5, periodType6);
//        int int8 = period7.size();
//        org.joda.time.Period period10 = period7.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        long long13 = dateTimeZone11.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = dateTimeZone14.getName((long) ' ', locale16);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone14.getName((long) (byte) 0, locale19);
//        boolean boolean21 = period7.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period23 = period7.withYears((int) (byte) 100);
//        org.joda.time.Period period25 = new org.joda.time.Period(100L);
//        org.joda.time.Period period26 = period25.toPeriod();
//        int int27 = period25.getYears();
//        org.joda.time.Period period29 = period25.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType(0);
//        int int33 = period29.get(durationFieldType32);
//        org.joda.time.Period period35 = period23.withFieldAdded(durationFieldType32, 2);
//        org.joda.time.field.DecoratedDurationField decoratedDurationField36 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType32);
//        org.joda.time.DurationFieldType durationFieldType37 = decoratedDurationField36.getType();
//        long long39 = decoratedDurationField36.getMillis((-4));
//        long long41 = decoratedDurationField36.getMillis(5L);
//        org.junit.Assert.assertNotNull(durationField0);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 28800001L + "'", long3 == 28800001L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
//        org.junit.Assert.assertNotNull(period10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-28800001L) + "'", long13 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Pacific Standard Time" + "'", str17.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Pacific Standard Time" + "'", str20.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(period23);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(period29);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertNotNull(durationFieldType32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertNotNull(durationFieldType37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-4L) + "'", long39 == (-4L));
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 5L + "'", long41 == 5L);
//    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("PeriodType[Millis]");
        java.lang.String str2 = jodaTimePermission1.toString();
        java.lang.String str3 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"PeriodType[Millis]\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"PeriodType[Millis]\")"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PeriodType[Millis]" + "'", str3.equals("PeriodType[Millis]"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "PeriodType[Weeks]", (int) 'a', (-970));
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        int int7 = fixedDateTimeZone4.getOffset(3155695200000L);
        int int9 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 10);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
    }

//    @Test
//    public void test500() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test500");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        org.joda.time.Period period5 = org.joda.time.Period.weeks((int) ' ');
//        org.joda.time.Period period7 = period5.minusYears(1);
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        org.joda.time.PeriodType periodType10 = null;
//        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
//        int int12 = period11.size();
//        org.joda.time.Period period14 = period11.plusMonths((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        long long17 = dateTimeZone15.convertUTCToLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone18.getName((long) ' ', locale20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone18.getName((long) (byte) 0, locale23);
//        boolean boolean25 = period11.equals((java.lang.Object) (byte) 0);
//        org.joda.time.Period period27 = period11.withYears((int) (byte) 100);
//        org.joda.time.Period period29 = new org.joda.time.Period(100L);
//        org.joda.time.Period period30 = period29.toPeriod();
//        int int31 = period29.getYears();
//        org.joda.time.Period period33 = period29.withMinutes((int) (byte) -1);
//        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
//        org.joda.time.DurationFieldType durationFieldType36 = periodType34.getFieldType(0);
//        int int37 = period33.get(durationFieldType36);
//        org.joda.time.Period period39 = period27.withFieldAdded(durationFieldType36, 2);
//        boolean boolean40 = period5.isSupported(durationFieldType36);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(durationFieldType36, (java.lang.Number) 1L, (java.lang.Number) 2440587.5006945604d, (java.lang.Number) (-97L));
//        boolean boolean45 = periodType2.isSupported(durationFieldType36);
//        org.joda.time.field.UnsupportedDurationField unsupportedDurationField46 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType36);
//        org.joda.time.DurationFieldType durationFieldType47 = unsupportedDurationField46.getType();
//        java.lang.String str48 = unsupportedDurationField46.toString();
//        try {
//            long long51 = unsupportedDurationField46.getValueAsLong((long) '4', (-35L));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(period7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28800001L) + "'", long17 == (-28800001L));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Pacific Standard Time" + "'", str24.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(periodType34);
//        org.junit.Assert.assertNotNull(durationFieldType36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(period39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(unsupportedDurationField46);
//        org.junit.Assert.assertNotNull(durationFieldType47);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "UnsupportedDurationField[years]" + "'", str48.equals("UnsupportedDurationField[years]"));
//    }
//}

