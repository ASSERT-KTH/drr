import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DurationField durationField3 = gregorianChronology1.months();
        org.joda.time.DurationField durationField4 = gregorianChronology1.minutes();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("2");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.hourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        java.lang.String str29 = unsupportedDateTimeField28.getName();
//        try {
//            int int31 = unsupportedDateTimeField28.getLeapAmount((long) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:56.960" + "'", str11.equals("����-��-��T14:31:56.960"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "weekyear" + "'", str29.equals("weekyear"));
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        org.joda.time.TimeOfDay timeOfDay6 = dateTime5.toTimeOfDay();
        org.joda.time.DateTime.Property property7 = dateTime5.era();
        int int8 = property7.getMaximumValue();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(timeOfDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        java.util.TimeZone timeZone7 = dateTimeZone3.toTimeZone();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfDay();
        boolean boolean6 = dateTime2.isEqual((long) (-870));
        org.joda.time.DateTime dateTime8 = dateTime2.minusHours(292278993);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(52263, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendYearOfEra(100, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMinuteOfHour(52263);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMillisOfSecond(6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTimeZoneName();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap14 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder10.appendTimeZoneName(strMap14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        java.lang.String str29 = unsupportedDateTimeField28.getName();
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter31.withOffsetParsed();
//        org.joda.time.ReadableInterval readableInterval33 = null;
//        org.joda.time.ReadableInterval readableInterval34 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval33);
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((java.lang.Object) readableInterval33);
//        org.joda.time.MutableDateTime mutableDateTime36 = dateTime35.toMutableDateTime();
//        org.joda.time.DateTime.Property property37 = dateTime35.secondOfMinute();
//        org.joda.time.DateTime dateTime39 = dateTime35.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime40 = dateTime35.toLocalDateTime();
//        java.lang.String str41 = dateTimeFormatter32.print((org.joda.time.ReadablePartial) localDateTime40);
//        long long43 = iSOChronology30.set((org.joda.time.ReadablePartial) localDateTime40, (long) 57600);
//        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology45);
//        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology45.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField47, 365);
//        org.joda.time.ReadableInterval readableInterval50 = null;
//        org.joda.time.ReadableInterval readableInterval51 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval50);
//        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((java.lang.Object) readableInterval50);
//        org.joda.time.YearMonthDay yearMonthDay53 = dateTime52.toYearMonthDay();
//        int[] intArray54 = new int[] {};
//        int int55 = offsetDateTimeField49.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay53, intArray54);
//        try {
//            int int56 = unsupportedDateTimeField28.getMaximumValue((org.joda.time.ReadablePartial) localDateTime40, intArray54);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:57.093" + "'", str11.equals("����-��-��T14:31:57.093"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "weekyear" + "'", str29.equals("weekyear"));
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter32);
//        org.junit.Assert.assertNotNull(readableInterval34);
//        org.junit.Assert.assertNotNull(mutableDateTime36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(localDateTime40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "2019-W24" + "'", str41.equals("2019-W24"));
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560609117103L + "'", long43 == 1560609117103L);
//        org.junit.Assert.assertNotNull(gregorianChronology45);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertNotNull(readableInterval51);
//        org.junit.Assert.assertNotNull(yearMonthDay53);
//        org.junit.Assert.assertNotNull(intArray54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 366 + "'", int55 == 366);
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("����-��-��T14:31:21.765");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"����-��-��T14:31:21.765\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTime dateTime17 = dateTime14.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime19 = dateTime17.plusWeeks(6);
//        org.joda.time.DateTime.Property property20 = dateTime19.year();
//        org.joda.time.DateTime.Property property21 = dateTime19.era();
//        org.joda.time.DateTime dateTime22 = property21.withMinimumValue();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:57.135" + "'", str11.equals("����-��-��T14:31:57.135"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime22);
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatterBuilder3.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatterBuilder8.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean11 = dateTimeFormatter10.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean14 = dateTimeFormatter13.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter13.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray18 = new org.joda.time.format.DateTimeParser[] { dateTimeParser12, dateTimeParser15, dateTimeParser17 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder3.append(dateTimePrinter9, dateTimeParserArray18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder3.appendLiteral("Pacific Standard Time");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder3.appendMinuteOfDay(9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder23.appendFractionOfMinute(52313, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeParserArray18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(57600, 'a', 8, 0, (int) (byte) 0, true, (int) (short) 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.setFixedSavings("����-��-��T14:31:03.496", 14);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder22 = dateTimeZoneBuilder0.addRecurringSavings("����-��-��T14:31:35.164", 0, 1970, 366, '4', 377, 52881764, 99, false, 6);
        java.io.DataOutput dataOutput24 = null;
        try {
            dateTimeZoneBuilder22.writeTo("����-��-��T14:31:43.049", dataOutput24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder22);
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
//        long long8 = offsetDateTimeField5.getDifferenceAsLong((long) (short) -1, (long) 1970);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = offsetDateTimeField5.getAsShortText(0L, locale10);
//        java.util.TimeZone timeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(dateTimeZone13);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval16 = null;
//        org.joda.time.ReadableInterval readableInterval17 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval16);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) readableInterval16);
//        org.joda.time.DateTime.Property property19 = dateTime18.weekOfWeekyear();
//        org.joda.time.DateTime dateTime21 = dateTime18.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay22 = dateTime21.toTimeOfDay();
//        java.lang.String str23 = dateTimeFormatter15.print((org.joda.time.ReadablePartial) timeOfDay22);
//        org.joda.time.DateTime dateTime24 = dateTime14.withFields((org.joda.time.ReadablePartial) timeOfDay22);
//        org.joda.time.DateTime dateTime26 = dateTime14.withEra(0);
//        org.joda.time.DateTime.Property property27 = dateTime26.weekyear();
//        org.joda.time.DateTime dateTime29 = dateTime26.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime31 = dateTime29.plusWeeks(6);
//        org.joda.time.DateTime dateTime33 = dateTime29.withWeekyear(6);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        boolean boolean35 = dateTimeFormatter34.isParser();
//        org.joda.time.format.DateTimeParser dateTimeParser36 = dateTimeFormatter34.getParser();
//        org.joda.time.ReadableInterval readableInterval37 = null;
//        org.joda.time.ReadableInterval readableInterval38 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval37);
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((java.lang.Object) readableInterval37);
//        org.joda.time.DateTime.Property property40 = dateTime39.weekOfWeekyear();
//        org.joda.time.DateTime dateTime42 = dateTime39.withWeekOfWeekyear((int) '4');
//        java.util.TimeZone timeZone43 = null;
//        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forTimeZone(timeZone43);
//        org.joda.time.DateTime dateTime45 = dateTime42.withZoneRetainFields(dateTimeZone44);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone46 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone44);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter47 = dateTimeFormatter34.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone46);
//        org.joda.time.DateTime dateTime48 = dateTime33.withZoneRetainFields((org.joda.time.DateTimeZone) cachedDateTimeZone46);
//        try {
//            org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((java.lang.Object) offsetDateTimeField5, (org.joda.time.DateTimeZone) cachedDateTimeZone46);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.field.OffsetDateTimeField");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "377" + "'", str11.equals("377"));
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(readableInterval17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(timeOfDay22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "����-��-��T14:31:57.458" + "'", str23.equals("����-��-��T14:31:57.458"));
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTimeFormatter34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNotNull(dateTimeParser36);
//        org.junit.Assert.assertNotNull(readableInterval38);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone46);
//        org.junit.Assert.assertNotNull(dateTimeFormatter47);
//        org.junit.Assert.assertNotNull(dateTime48);
//    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
//        int int6 = dateTime2.getMillisOfDay();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52317484 + "'", int6 == 52317484);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        long long8 = offsetDateTimeField5.getDifferenceAsLong((long) (short) -1, (long) 1970);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsShortText(0L, locale10);
        try {
            long long14 = offsetDateTimeField5.set((long) 52273, "����-��-��T14:31:47.975");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"����-��-��T14:31:47.975\" for clockhourOfHalfday is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "377" + "'", str11.equals("377"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("����-��-��T14:31:30.685");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"����-��-��T14:31:30.685/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField4 = gregorianChronology3.millis();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.weekOfWeekyear();
//        int int6 = dateTime2.get(dateTimeField5);
//        int int7 = dateTime2.getMillisOfDay();
//        java.util.Locale locale8 = null;
//        java.util.Calendar calendar9 = dateTime2.toCalendar(locale8);
//        org.joda.time.DateTime dateTime11 = dateTime2.minusMillis(52);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52317953 + "'", int7 == 52317953);
//        org.junit.Assert.assertNotNull(calendar9);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        java.lang.String str4 = property3.getName();
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval9 = null;
//        org.joda.time.ReadableInterval readableInterval10 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval9);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) readableInterval9);
//        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
//        org.joda.time.DateTime dateTime14 = dateTime11.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay15 = dateTime14.toTimeOfDay();
//        java.lang.String str16 = dateTimeFormatter8.print((org.joda.time.ReadablePartial) timeOfDay15);
//        org.joda.time.DateTime dateTime17 = dateTime7.withFields((org.joda.time.ReadablePartial) timeOfDay15);
//        org.joda.time.DateTime dateTime19 = dateTime7.withEra(0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
//        boolean boolean21 = dateTime7.isSupported(dateTimeFieldType20);
//        org.joda.time.DateTime.Property property22 = dateTime7.year();
//        int int23 = property3.compareTo((org.joda.time.ReadableInstant) dateTime7);
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "weekOfWeekyear" + "'", str4.equals("weekOfWeekyear"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(readableInterval10);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(timeOfDay15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "����-��-��T14:31:58.004" + "'", str16.equals("����-��-��T14:31:58.004"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendHourOfDay(52275274);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        try {
            long long3 = dateTimeFormatter0.parseMillis("����-��-��T14:31:55.073");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"����-��-��T14:31:55.073\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        java.lang.String str29 = unsupportedDateTimeField28.getName();
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology31);
//        org.joda.time.DateTimeZone dateTimeZone33 = gregorianChronology31.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone33);
//        org.joda.time.DurationField durationField35 = iSOChronology34.hours();
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.ReadableInterval readableInterval37 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((java.lang.Object) readableInterval36);
//        org.joda.time.DateTime.Property property39 = dateTime38.weekOfWeekyear();
//        org.joda.time.DateTime dateTime41 = dateTime38.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay42 = dateTime41.toTimeOfDay();
//        int[] intArray44 = iSOChronology34.get((org.joda.time.ReadablePartial) timeOfDay42, 3600000L);
//        int[] intArray52 = new int[] { 31, 3, 52297838, (byte) 100, (-100), 2019 };
//        try {
//            int[] intArray54 = unsupportedDateTimeField28.addWrapField((org.joda.time.ReadablePartial) timeOfDay42, 12775, intArray52, (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:58.214" + "'", str11.equals("����-��-��T14:31:58.214"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "weekyear" + "'", str29.equals("weekyear"));
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(readableInterval37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(timeOfDay42);
//        org.junit.Assert.assertNotNull(intArray44);
//        org.junit.Assert.assertNotNull(intArray52);
//    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTime dateTime17 = dateTime14.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime19 = dateTime17.plusWeeks(6);
//        org.joda.time.DateTime.Property property20 = dateTime19.year();
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime19.minus(readableDuration21);
//        try {
//            org.joda.time.DateTime dateTime24 = dateTime22.withEra(52258);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52258 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:58.255" + "'", str11.equals("����-��-��T14:31:58.255"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime22);
//    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
//        int int6 = dateTime2.getSecondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        boolean boolean8 = dateTime2.isSupported(dateTimeFieldType7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 365);
//        int int15 = dateTime2.get(dateTimeField12);
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
//        try {
//            int int17 = dateTime2.get(dateTimeFieldType16);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52318 + "'", int6 == 52318);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.halfdayOfDay();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) readableInterval3);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTime dateTime8 = dateTime5.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.DateTime dateTime11 = dateTime8.withZoneRetainFields(dateTimeZone10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
        long long14 = cachedDateTimeZone12.nextTransition((long) (short) 0);
        org.joda.time.Chronology chronology15 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone12);
        int int17 = cachedDateTimeZone12.getStandardOffset((long) (short) 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(readableInterval4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9972000000L + "'", long14 == 9972000000L);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-28800000) + "'", int17 == (-28800000));
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
//        org.joda.time.ReadableInterval readableInterval1 = null;
//        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) readableInterval1);
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTime.Property property5 = dateTime3.secondOfMinute();
//        org.joda.time.DateTime dateTime7 = dateTime3.plusMillis((int) (byte) 10);
//        int int8 = dateTime7.getDayOfYear();
//        org.joda.time.ReadableInterval readableInterval9 = null;
//        org.joda.time.ReadableInterval readableInterval10 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval9);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) readableInterval9);
//        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
//        org.joda.time.DateTime dateTime14 = dateTime11.withWeekOfWeekyear((int) '4');
//        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime7, (org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter0.withChronology(chronology15);
//        java.lang.StringBuffer stringBuffer17 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        org.joda.time.DateTime dateTime24 = dateTime21.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay25 = dateTime24.toTimeOfDay();
//        java.lang.String str26 = dateTimeFormatter18.print((org.joda.time.ReadablePartial) timeOfDay25);
//        try {
//            dateTimeFormatter16.printTo(stringBuffer17, (org.joda.time.ReadablePartial) timeOfDay25);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(readableInterval2);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 166 + "'", int8 == 166);
//        org.junit.Assert.assertNotNull(readableInterval10);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(timeOfDay25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "����-��-��T14:31:59.062" + "'", str26.equals("����-��-��T14:31:59.062"));
//    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
//        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
//        int int7 = dateTime6.getDayOfYear();
//        org.joda.time.ReadableInterval readableInterval8 = null;
//        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) readableInterval8);
//        org.joda.time.DateTime.Property property11 = dateTime10.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = dateTime10.withWeekOfWeekyear((int) '4');
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime6, (org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime.Property property15 = dateTime10.monthOfYear();
//        org.joda.time.DateTime.Property property16 = dateTime10.yearOfEra();
//        int int17 = dateTime10.getMillisOfSecond();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 166 + "'", int7 == 166);
//        org.junit.Assert.assertNotNull(readableInterval9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 79 + "'", int17 == 79);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 52257628, "����-��-��T14:31:39.457");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        long long31 = unsupportedDateTimeField28.add((long) 52274482, (long) 13);
//        org.joda.time.DurationField durationField32 = unsupportedDateTimeField28.getDurationField();
//        try {
//            int int34 = unsupportedDateTimeField28.getMinimumValue((-1L));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:59.196" + "'", str11.equals("����-��-��T14:31:59.196"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 7914674482L + "'", long31 == 7914674482L);
//        org.junit.Assert.assertNotNull(durationField32);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatterBuilder3.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatterBuilder8.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean11 = dateTimeFormatter10.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean14 = dateTimeFormatter13.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter13.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray18 = new org.joda.time.format.DateTimeParser[] { dateTimeParser12, dateTimeParser15, dateTimeParser17 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder3.append(dateTimePrinter9, dateTimeParserArray18);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser21 = dateTimeFormatter20.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter9, dateTimeParser21);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser24 = dateTimeFormatter23.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter9, dateTimeParser24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeParserArray18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimeParser21);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTimeParser24);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTime dateTime17 = dateTime14.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime.Property property18 = dateTime14.secondOfMinute();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:59.280" + "'", str11.equals("����-��-��T14:31:59.280"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test034");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        org.joda.time.DateTime dateTime8 = dateTime5.withZoneRetainFields(dateTimeZone7);
//        java.lang.String str9 = dateTimeZone7.getID();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone7);
//        long long11 = dateTime10.getMillis();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "America/Los_Angeles" + "'", str9.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560634319438L + "'", long11 == 1560634319438L);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
        long long10 = offsetDateTimeField5.getDifferenceAsLong((long) (byte) -1, (long) 100);
        org.joda.time.DurationField durationField11 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale12 = null;
        int int13 = offsetDateTimeField5.getMaximumShortTextLength(locale12);
        long long15 = offsetDateTimeField5.roundFloor((long) 86399999);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 82800000L + "'", long15 == 82800000L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("weekOfWeekyear", (java.lang.Number) 1L, (java.lang.Number) (byte) 10, number3);
        java.lang.Number number5 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.Number number9 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException("weekOfWeekyear", (java.lang.Number) 1L, (java.lang.Number) (byte) 10, number9);
        java.lang.Number number11 = illegalFieldValueException10.getIllegalNumberValue();
        java.lang.String str12 = illegalFieldValueException10.getIllegalStringValue();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException10);
        org.joda.time.DurationFieldType durationFieldType14 = illegalFieldValueException10.getDurationFieldType();
        java.lang.Number number15 = illegalFieldValueException10.getUpperBound();
        java.lang.Number number16 = illegalFieldValueException10.getUpperBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1L + "'", number5.equals(1L));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 1L + "'", number11.equals(1L));
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(durationFieldType14);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertNull(number16);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(52263, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendHourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.halfdays();
        org.joda.time.DurationField durationField6 = iSOChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.era();
        try {
            long long15 = iSOChronology4.getDateTimeMillis(21, 52258, 292278993, 52258, (int) (byte) 1, (int) ' ', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52258 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(52263, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendHourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendHourOfDay((int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "����-��-��T14:31:45.060");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
//        java.lang.String str6 = offsetDateTimeField5.toString();
//        java.util.TimeZone timeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval11 = null;
//        org.joda.time.ReadableInterval readableInterval12 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) readableInterval11);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        org.joda.time.DateTime dateTime16 = dateTime13.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay17 = dateTime16.toTimeOfDay();
//        java.lang.String str18 = dateTimeFormatter10.print((org.joda.time.ReadablePartial) timeOfDay17);
//        org.joda.time.DateTime dateTime19 = dateTime9.withFields((org.joda.time.ReadablePartial) timeOfDay17);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = offsetDateTimeField5.getAsText((org.joda.time.ReadablePartial) timeOfDay17, 52278114, locale21);
//        org.joda.time.DateTimeField dateTimeField23 = offsetDateTimeField5.getWrappedField();
//        long long26 = offsetDateTimeField5.addWrapField((-5756400001L), 52307);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[clockhourOfHalfday]" + "'", str6.equals("DateTimeField[clockhourOfHalfday]"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(readableInterval12);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(timeOfDay17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "����-��-��T14:31:59.718" + "'", str18.equals("����-��-��T14:31:59.718"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "52278114" + "'", str22.equals("52278114"));
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-5760000001L) + "'", long26 == (-5760000001L));
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "����-��-��T14:31:43.049", "����W���T143137");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        boolean boolean2 = dateTimeFormatterBuilder1.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendTwoDigitYear((int) (short) 0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendHalfdayOfDayText();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = null;
        org.joda.time.format.DateTimeParser[] dateTimeParserArray8 = new org.joda.time.format.DateTimeParser[] {};
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder1.append(dateTimePrinter7, dateTimeParserArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeParserArray8);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatterBuilder3.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatterBuilder8.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean11 = dateTimeFormatter10.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean14 = dateTimeFormatter13.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter13.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray18 = new org.joda.time.format.DateTimeParser[] { dateTimeParser12, dateTimeParser15, dateTimeParser17 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder3.append(dateTimePrinter9, dateTimeParserArray18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder3.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder22.appendYearOfEra(12, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeParserArray18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime.Property property8 = dateTime6.millisOfDay();
//        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
//        int int10 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property11 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = dateTime2.withMillis((long) (byte) 1);
//        org.joda.time.DateTime.Property property14 = dateTime2.centuryOfEra();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(522840, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 522850 + "'", int2 == 522850);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.DateTime dateTime13 = dateTime10.withZoneRetainFields(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        long long16 = cachedDateTimeZone14.nextTransition((long) (short) 0);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology18.getZone();
        java.lang.String str20 = dateTimeZone19.getID();
        boolean boolean21 = zonedChronology17.equals((java.lang.Object) dateTimeZone19);
        org.joda.time.DurationField durationField22 = zonedChronology17.halfdays();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(readableInterval6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9972000000L + "'", long16 == 9972000000L);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationField22);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gregorianChronology1.millis();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.weekOfWeekyear();
        org.joda.time.DurationField durationField4 = gregorianChronology1.hours();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology1.getZone();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.ReadableInterval readableInterval7 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) readableInterval6);
        org.joda.time.DateTime.Property property9 = dateTime8.weekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime8.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
        org.joda.time.DateTime dateTime14 = dateTime11.withZoneRetainFields(dateTimeZone13);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone13);
        long long17 = cachedDateTimeZone15.nextTransition((long) (short) 0);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeZone) cachedDateTimeZone15);
        try {
            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) "����-��-��T14:31:55.073", (org.joda.time.DateTimeZone) cachedDateTimeZone15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"����-��-��T14:31:55.073\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(readableInterval7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9972000000L + "'", long17 == 9972000000L);
        org.junit.Assert.assertNotNull(zonedChronology18);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.halfdays();
        org.joda.time.DurationField durationField6 = iSOChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology4.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology4.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
//        boolean boolean16 = dateTime2.isSupported(dateTimeFieldType15);
//        org.joda.time.DateTime.Property property17 = dateTime2.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:00.283" + "'", str11.equals("����-��-��T14:32:00.283"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.minuteOfHour();
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime5 = property4.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "weekOfWeekyear", 24, (-870));
        long long6 = fixedDateTimeZone4.nextTransition((long) 2019);
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.ReadableInterval readableInterval8 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) readableInterval7);
        org.joda.time.DateTime.Property property10 = dateTime9.weekOfWeekyear();
        org.joda.time.DateTime dateTime12 = dateTime9.withWeekOfWeekyear((int) '4');
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime9);
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) dateTime9);
        java.lang.String str15 = fixedDateTimeZone4.toString();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(readableInterval8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.minus(readableDuration4);
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.ReadableInterval readableInterval7 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) readableInterval6);
        org.joda.time.DateTime.Property property9 = dateTime8.weekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime8.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
        org.joda.time.DateTime dateTime14 = dateTime11.withZoneRetainFields(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = dateTime2.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime16 = dateTime2.toDateTime();
        org.joda.time.DateTime dateTime18 = dateTime16.minusYears(2019);
        org.joda.time.DateTime dateTime20 = dateTime18.withWeekyear(0);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(readableInterval7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
        long long10 = offsetDateTimeField5.getDifferenceAsLong((long) (byte) -1, (long) 100);
        long long12 = offsetDateTimeField5.remainder((long) 57600);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField5.getType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, 8, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 8 for clockhourOfHalfday must be in the range [0,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 57600L + "'", long12 == 57600L);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
        org.joda.time.DateTime dateTime8 = dateTime6.plusMonths((int) (short) -1);
        org.joda.time.DateTime dateTime10 = dateTime8.withWeekOfWeekyear(52);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime8.minus(readablePeriod11);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int6 = offsetDateTimeField5.getMaximumValue();
        java.lang.String str7 = offsetDateTimeField5.toString();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 377 + "'", int6 == 377);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DateTimeField[clockhourOfHalfday]" + "'", str7.equals("DateTimeField[clockhourOfHalfday]"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.halfdays();
        org.joda.time.DurationField durationField6 = iSOChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology4.minuteOfHour();
        java.lang.String str9 = iSOChronology4.toString();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology4.monthOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ISOChronology[UTC]" + "'", str9.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        long long31 = unsupportedDateTimeField28.add((long) 52274482, (long) 13);
//        org.joda.time.DurationField durationField32 = unsupportedDateTimeField28.getDurationField();
//        long long35 = durationField32.subtract((long) 166, (long) (byte) 100);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:00.756" + "'", str11.equals("����-��-��T14:32:00.756"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 7914674482L + "'", long31 == 7914674482L);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-60479999834L) + "'", long35 == (-60479999834L));
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 52284, 1277500);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 66792810000L + "'", long2 == 66792810000L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
        long long10 = offsetDateTimeField5.getDifferenceAsLong((long) (byte) -1, (long) 100);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField5.getMaximumTextLength(locale11);
        boolean boolean14 = offsetDateTimeField5.isLeap((-902L));
        java.util.Locale locale15 = null;
        int int16 = offsetDateTimeField5.getMaximumShortTextLength(locale15);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean1 = dateTimeFormatter0.isParser();
        boolean boolean2 = dateTimeFormatter0.isParser();
        java.lang.String str4 = dateTimeFormatter0.print((long) 365);
        java.util.Locale locale5 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969365T160000.365-0800" + "'", str4.equals("1969365T160000.365-0800"));
        org.junit.Assert.assertNull(locale5);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
//        org.joda.time.ReadableInterval readableInterval2 = null;
//        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) readableInterval2);
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime4.toMutableDateTime();
//        org.joda.time.DateTime.Property property6 = dateTime4.secondOfMinute();
//        org.joda.time.DateTime dateTime8 = dateTime4.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime9 = dateTime4.toLocalDateTime();
//        java.lang.String str10 = dateTimeFormatter1.print((org.joda.time.ReadablePartial) localDateTime9);
//        boolean boolean11 = dateTimeFormatter1.isOffsetParsed();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(readableInterval3);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(localDateTime9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-W24" + "'", str10.equals("2019-W24"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.DateTime dateTime13 = dateTime10.withZoneRetainFields(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        long long16 = cachedDateTimeZone14.nextTransition((long) (short) 0);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField19 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(readableInterval6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9972000000L + "'", long16 == 9972000000L);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
        long long10 = offsetDateTimeField5.getDifferenceAsLong((long) (byte) -1, (long) 100);
        org.joda.time.DurationField durationField11 = offsetDateTimeField5.getLeapDurationField();
        int int12 = offsetDateTimeField5.getOffset();
        long long15 = offsetDateTimeField5.add((long) 960, (long) 871);
        int int16 = offsetDateTimeField5.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 365 + "'", int12 == 365);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3135600960L + "'", long15 == 3135600960L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 366 + "'", int16 == 366);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.minuteOfHour();
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime5 = property4.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime6 = property4.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
        long long10 = offsetDateTimeField5.getDifferenceAsLong((long) (byte) -1, (long) 100);
        org.joda.time.DurationField durationField11 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale12 = null;
        int int13 = offsetDateTimeField5.getMaximumShortTextLength(locale12);
        long long15 = offsetDateTimeField5.roundHalfFloor((long) 2031);
        long long18 = offsetDateTimeField5.add((long) (byte) 100, (long) 52288104);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 188237174400100L + "'", long18 == 188237174400100L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
        org.joda.time.DateTime.Property property7 = dateTime2.yearOfCentury();
        org.joda.time.ReadableInstant readableInstant8 = null;
        long long9 = property7.getDifferenceAsLong(readableInstant8);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
//        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
//        long long9 = offsetDateTimeField5.roundHalfFloor(0L);
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval14 = null;
//        org.joda.time.ReadableInterval readableInterval15 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval14);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) readableInterval14);
//        org.joda.time.DateTime.Property property17 = dateTime16.weekOfWeekyear();
//        org.joda.time.DateTime dateTime19 = dateTime16.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay20 = dateTime19.toTimeOfDay();
//        java.lang.String str21 = dateTimeFormatter13.print((org.joda.time.ReadablePartial) timeOfDay20);
//        org.joda.time.DateTime dateTime22 = dateTime12.withFields((org.joda.time.ReadablePartial) timeOfDay20);
//        org.joda.time.DateTime dateTime24 = dateTime12.withEra(0);
//        org.joda.time.DateTime.Property property25 = dateTime24.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property25.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, "377");
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType26, 52303605, 52305, (int) (short) 10);
//        long long35 = offsetDateTimeField5.add((long) 10, (long) 52258);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(readableInterval15);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(timeOfDay20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "����-��-��T14:32:01.868" + "'", str21.equals("����-��-��T14:32:01.868"));
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 188128800010L + "'", long35 == 188128800010L);
//    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        java.util.Locale locale4 = null;
//        int int5 = property3.getMaximumTextLength(locale4);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = property3.getAsShortText(locale6);
//        int int8 = property3.getMinimumValueOverall();
//        java.lang.String str9 = property3.getAsString();
//        java.lang.String str10 = property3.getName();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "24" + "'", str7.equals("24"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "24" + "'", str9.equals("24"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "weekOfWeekyear" + "'", str10.equals("weekOfWeekyear"));
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 19);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
//        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '#');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withOffsetParsed();
//        org.joda.time.ReadableInterval readableInterval12 = null;
//        org.joda.time.ReadableInterval readableInterval13 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval12);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) readableInterval12);
//        org.joda.time.MutableDateTime mutableDateTime15 = dateTime14.toMutableDateTime();
//        org.joda.time.DateTime.Property property16 = dateTime14.secondOfMinute();
//        org.joda.time.DateTime dateTime18 = dateTime14.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime19 = dateTime14.toLocalDateTime();
//        java.lang.String str20 = dateTimeFormatter11.print((org.joda.time.ReadablePartial) localDateTime19);
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology21.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter23.withOffsetParsed();
//        org.joda.time.ReadableInterval readableInterval25 = null;
//        org.joda.time.ReadableInterval readableInterval26 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval25);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((java.lang.Object) readableInterval25);
//        org.joda.time.MutableDateTime mutableDateTime28 = dateTime27.toMutableDateTime();
//        org.joda.time.DateTime.Property property29 = dateTime27.secondOfMinute();
//        org.joda.time.DateTime dateTime31 = dateTime27.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime32 = dateTime27.toLocalDateTime();
//        java.lang.String str33 = dateTimeFormatter24.print((org.joda.time.ReadablePartial) localDateTime32);
//        int[] intArray35 = gregorianChronology21.get((org.joda.time.ReadablePartial) localDateTime32, (-1209599903L));
//        int int36 = offsetDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) localDateTime19, intArray35);
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = offsetDateTimeField5.getAsShortText((long) 0, locale38);
//        boolean boolean41 = offsetDateTimeField5.isLeap((long) 14);
//        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = dateTimeFormatter43.withOffsetParsed();
//        org.joda.time.ReadableInterval readableInterval45 = null;
//        org.joda.time.ReadableInterval readableInterval46 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval45);
//        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((java.lang.Object) readableInterval45);
//        org.joda.time.MutableDateTime mutableDateTime48 = dateTime47.toMutableDateTime();
//        org.joda.time.DateTime.Property property49 = dateTime47.secondOfMinute();
//        org.joda.time.DateTime dateTime51 = dateTime47.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime52 = dateTime47.toLocalDateTime();
//        java.lang.String str53 = dateTimeFormatter44.print((org.joda.time.ReadablePartial) localDateTime52);
//        long long55 = iSOChronology42.set((org.joda.time.ReadablePartial) localDateTime52, (long) 57600);
//        int[] intArray59 = new int[] { (byte) 0, 870 };
//        java.util.Locale locale61 = null;
//        try {
//            int[] intArray62 = offsetDateTimeField5.set((org.joda.time.ReadablePartial) localDateTime52, (int) (short) -1, intArray59, "����-��-��T14:31:47.126", locale61);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"����-��-��T14:31:47.126\" for clockhourOfHalfday is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(readableInterval13);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(localDateTime19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019-W24" + "'", str20.equals("2019-W24"));
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertNotNull(readableInterval26);
//        org.junit.Assert.assertNotNull(mutableDateTime28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(localDateTime32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2019-W24" + "'", str33.equals("2019-W24"));
//        org.junit.Assert.assertNotNull(intArray35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 366 + "'", int36 == 366);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "377" + "'", str39.equals("377"));
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(iSOChronology42);
//        org.junit.Assert.assertNotNull(dateTimeFormatter43);
//        org.junit.Assert.assertNotNull(dateTimeFormatter44);
//        org.junit.Assert.assertNotNull(readableInterval46);
//        org.junit.Assert.assertNotNull(mutableDateTime48);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(localDateTime52);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "2019-W24" + "'", str53.equals("2019-W24"));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560609122142L + "'", long55 == 1560609122142L);
//        org.junit.Assert.assertNotNull(intArray59);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.dayOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "weekOfWeekyear", 24, (-870));
        long long6 = fixedDateTimeZone4.nextTransition((long) 2019);
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        int int9 = fixedDateTimeZone4.getStandardOffset(0L);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.ReadableInterval readableInterval11 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval10);
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(chronology12);
        org.joda.time.YearMonthDay yearMonthDay14 = dateTime13.toYearMonthDay();
        int int15 = fixedDateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime13);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-870) + "'", int9 == (-870));
        org.junit.Assert.assertNotNull(readableInterval11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(yearMonthDay14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 24 + "'", int15 == 24);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
        org.joda.time.DateTime dateTime6 = property4.addToCopy((-870));
        int int7 = property4.get();
        java.util.Locale locale8 = null;
        java.lang.String str9 = property4.getAsShortText(locale8);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "19" + "'", str9.equals("19"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTime.Property property8 = dateTime6.millisOfDay();
        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
        int int10 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property11 = dateTime6.centuryOfEra();
        org.joda.time.DateTime dateTime13 = dateTime6.withMillisOfDay(1970);
        org.joda.time.DateTime.Property property14 = dateTime13.minuteOfHour();
        org.joda.time.DateTime dateTime15 = property14.roundCeilingCopy();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(readableInterval5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(57600, 'a', 8, 0, (int) (byte) 0, true, (int) (short) 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.setFixedSavings("����-��-��T14:31:03.496", 14);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder22 = dateTimeZoneBuilder0.addRecurringSavings("����-��-��T14:31:35.164", 0, 1970, 366, '4', 377, 52881764, 99, false, 6);
        java.io.OutputStream outputStream24 = null;
        try {
            dateTimeZoneBuilder0.writeTo("����W���T143118", outputStream24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder22);
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test079");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        java.lang.String str29 = unsupportedDateTimeField28.getName();
//        long long32 = unsupportedDateTimeField28.getDifferenceAsLong(3600000L, 0L);
//        try {
//            int int34 = unsupportedDateTimeField28.get((-28799980L));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:02.555" + "'", str11.equals("����-��-��T14:32:02.555"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "weekyear" + "'", str29.equals("weekyear"));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(1970, 21, 52288104, (int) '#', 52901);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField4 = gregorianChronology3.millis();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.weekOfWeekyear();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.DateTime.Property property7 = dateTime2.dayOfYear();
//        int int8 = dateTime2.getDayOfYear();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 166 + "'", int8 == 166);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        try {
//            int int29 = unsupportedDateTimeField28.getMaximumValue();
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:02.664" + "'", str11.equals("����-��-��T14:32:02.664"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        long long31 = unsupportedDateTimeField28.add((long) 52274482, (long) 13);
//        org.joda.time.DurationField durationField32 = unsupportedDateTimeField28.getDurationField();
//        try {
//            long long34 = unsupportedDateTimeField28.roundFloor((long) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:02.688" + "'", str11.equals("����-��-��T14:32:02.688"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 7914674482L + "'", long31 == 7914674482L);
//        org.junit.Assert.assertNotNull(durationField32);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField4 = gregorianChronology3.millis();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.weekOfWeekyear();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.DateTime.Property property7 = dateTime2.dayOfYear();
//        int int8 = property7.getMaximumValueOverall();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 366 + "'", int8 == 366);
//    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTime dateTime17 = dateTime14.plusYears((int) (byte) 0);
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime14.plus(readablePeriod18);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
//        int int21 = dateTimeFormatter20.getDefaultYear();
//        boolean boolean22 = dateTime14.equals((java.lang.Object) dateTimeFormatter20);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:02.747" + "'", str11.equals("����-��-��T14:32:02.747"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2000 + "'", int21 == 2000);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        org.joda.time.DurationField durationField29 = unsupportedDateTimeField28.getLeapDurationField();
//        java.util.Locale locale31 = null;
//        try {
//            java.lang.String str32 = unsupportedDateTimeField28.getAsText(8, locale31);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:02.915" + "'", str11.equals("����-��-��T14:32:02.915"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertNull(durationField29);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime2.toYearMonthDay();
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        org.joda.time.DateTime dateTime8 = dateTime5.withZoneRetainFields(dateTimeZone7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        long long11 = cachedDateTimeZone9.nextTransition((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone12 = cachedDateTimeZone9.getUncachedZone();
        long long14 = dateTimeZone12.convertUTCToLocal((long) 12775);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9972000000L + "'", long11 == 9972000000L);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-28787225L) + "'", long14 == (-28787225L));
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.DurationField durationField17 = null;
//        try {
//            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField17);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:03.080" + "'", str11.equals("����-��-��T14:32:03.080"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(52263, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendYearOfEra(100, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendMillisOfDay(52275313);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.halfdays();
        org.joda.time.DurationField durationField6 = iSOChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology4.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology10 = iSOChronology4.withZone(dateTimeZone9);
        long long14 = dateTimeZone9.convertLocalToUTC((long) 57600000, true, (long) (short) 100);
        long long17 = dateTimeZone9.convertLocalToUTC((long) 52297838, false);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 86400000L + "'", long14 == 86400000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 81097838L + "'", long17 == 81097838L);
        org.junit.Assert.assertNotNull(gregorianChronology18);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.DateTime dateTime13 = dateTime10.withZoneRetainFields(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        long long16 = cachedDateTimeZone14.nextTransition((long) (short) 0);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology18.getZone();
        java.lang.String str20 = dateTimeZone19.getID();
        boolean boolean21 = zonedChronology17.equals((java.lang.Object) dateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone22 = zonedChronology17.getZone();
        org.joda.time.DateTimeField dateTimeField23 = zonedChronology17.weekyearOfCentury();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone28 = new org.joda.time.tz.FixedDateTimeZone("", "weekOfWeekyear", 24, (-870));
        long long30 = fixedDateTimeZone28.nextTransition((long) 2019);
        boolean boolean31 = fixedDateTimeZone28.isFixed();
        org.joda.time.ReadableInstant readableInstant32 = null;
        int int33 = fixedDateTimeZone28.getOffset(readableInstant32);
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology35);
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology35.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, 365);
        int int41 = offsetDateTimeField39.getMinimumValue((long) 19);
        org.joda.time.DurationField durationField42 = offsetDateTimeField39.getDurationField();
        boolean boolean43 = fixedDateTimeZone28.equals((java.lang.Object) offsetDateTimeField39);
        java.util.TimeZone timeZone44 = fixedDateTimeZone28.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.forTimeZone(timeZone44);
        org.joda.time.Chronology chronology46 = zonedChronology17.withZone(dateTimeZone45);
        long long51 = zonedChronology17.getDateTimeMillis((int) (short) 100, 9, 10, 3);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(readableInterval6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9972000000L + "'", long16 == 9972000000L);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 2019L + "'", long30 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 24 + "'", int33 == 24);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 366 + "'", int41 == 366);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(chronology46);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-58989658021997L) + "'", long51 == (-58989658021997L));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((-1L), (-24L));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withPivotYear((int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.DateTime dateTime13 = dateTime10.withZoneRetainFields(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        long long16 = cachedDateTimeZone14.nextTransition((long) (short) 0);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology18.getZone();
        java.lang.String str20 = dateTimeZone19.getID();
        boolean boolean21 = zonedChronology17.equals((java.lang.Object) dateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone22 = zonedChronology17.getZone();
        org.joda.time.DateTimeField dateTimeField23 = zonedChronology17.weekyearOfCentury();
        org.joda.time.ReadableInterval readableInterval24 = null;
        org.joda.time.ReadableInterval readableInterval25 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval24);
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((java.lang.Object) readableInterval24);
        org.joda.time.DateTime.Property property27 = dateTime26.weekOfWeekyear();
        org.joda.time.DateTime dateTime29 = dateTime26.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTime dateTime31 = dateTime26.withMinuteOfHour((int) (short) 10);
        boolean boolean32 = zonedChronology17.equals((java.lang.Object) (short) 10);
        org.joda.time.DurationField durationField33 = zonedChronology17.weekyears();
        org.joda.time.DateTimeField dateTimeField34 = zonedChronology17.monthOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(readableInterval6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9972000000L + "'", long16 == 9972000000L);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(readableInterval25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.halfdays();
        org.joda.time.DurationField durationField6 = iSOChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology4.millisOfSecond();
        org.joda.time.DurationField durationField9 = iSOChronology4.weekyears();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField11 = new org.joda.time.field.DecoratedDurationField(durationField9, durationFieldType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(52263, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendYearOfEra(100, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendDayOfWeek((int) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
//        java.lang.Integer int2 = dateTimeFormatter0.getPivotYear();
//        java.io.Writer writer3 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateTime();
//        org.joda.time.ReadableInterval readableInterval5 = null;
//        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime7.toMutableDateTime();
//        org.joda.time.DateTime.Property property9 = dateTime7.secondOfMinute();
//        org.joda.time.DateTime dateTime11 = dateTime7.plusMillis((int) (byte) 10);
//        int int12 = dateTime11.getDayOfYear();
//        org.joda.time.ReadableInterval readableInterval13 = null;
//        org.joda.time.ReadableInterval readableInterval14 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval13);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) readableInterval13);
//        org.joda.time.DateTime.Property property16 = dateTime15.weekOfWeekyear();
//        org.joda.time.DateTime dateTime18 = dateTime15.withWeekOfWeekyear((int) '4');
//        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime11, (org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter4.withChronology(chronology19);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter4.withOffsetParsed();
//        java.util.TimeZone timeZone22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now(dateTimeZone23);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval26 = null;
//        org.joda.time.ReadableInterval readableInterval27 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval26);
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) readableInterval26);
//        org.joda.time.DateTime.Property property29 = dateTime28.weekOfWeekyear();
//        org.joda.time.DateTime dateTime31 = dateTime28.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay32 = dateTime31.toTimeOfDay();
//        java.lang.String str33 = dateTimeFormatter25.print((org.joda.time.ReadablePartial) timeOfDay32);
//        org.joda.time.DateTime dateTime34 = dateTime24.withFields((org.joda.time.ReadablePartial) timeOfDay32);
//        java.lang.String str35 = dateTimeFormatter4.print((org.joda.time.ReadablePartial) timeOfDay32);
//        try {
//            dateTimeFormatter0.printTo(writer3, (org.joda.time.ReadablePartial) timeOfDay32);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeParser1);
//        org.junit.Assert.assertNull(int2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(readableInterval6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 166 + "'", int12 == 166);
//        org.junit.Assert.assertNotNull(readableInterval14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(readableInterval27);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(timeOfDay32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "����-��-��T14:32:03.813" + "'", str33.equals("����-��-��T14:32:03.813"));
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "����-��-��T14:32:03.813" + "'", str35.equals("����-��-��T14:32:03.813"));
//    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime.Property property8 = dateTime6.millisOfDay();
//        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
//        int int10 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime12 = dateTime6.plusMinutes(377);
//        org.joda.time.DateTime.Property property13 = dateTime12.minuteOfHour();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime2.withMonthOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        org.joda.time.TimeOfDay timeOfDay8 = dateTime6.toTimeOfDay();
        org.joda.time.DateTime.Property property9 = dateTime6.era();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(timeOfDay8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.appendTimeZoneOffset("����-��-��T14:31:45.658", "����-��-��T14:31:33.500", true, (-870), 52307);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatterBuilder3.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatterBuilder8.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean11 = dateTimeFormatter10.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean14 = dateTimeFormatter13.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter13.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray18 = new org.joda.time.format.DateTimeParser[] { dateTimeParser12, dateTimeParser15, dateTimeParser17 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder3.append(dateTimePrinter9, dateTimeParserArray18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder3.appendClockhourOfHalfday(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendDayOfWeek(52278009);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeParserArray18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) readableInterval2);
        org.joda.time.DateTime.Property property5 = dateTime4.weekOfWeekyear();
        org.joda.time.DateTime.Property property6 = dateTime4.millisOfDay();
        boolean boolean8 = dateTime4.isEqual((long) (-870));
        org.joda.time.DateTime dateTime10 = dateTime4.plusMonths((int) 'a');
        org.joda.time.DateTime.Property property11 = dateTime4.millisOfDay();
        org.joda.time.DateTime.Property property12 = dateTime4.dayOfYear();
        int int13 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime4);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(readableInterval3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "weekOfWeekyear", 24, (-870));
        long long6 = fixedDateTimeZone4.nextTransition((long) 2019);
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.ReadableInterval readableInterval8 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) readableInterval7);
        org.joda.time.DateTime.Property property10 = dateTime9.weekOfWeekyear();
        org.joda.time.DateTime dateTime12 = dateTime9.withWeekOfWeekyear((int) '4');
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime9);
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) dateTime9);
        java.lang.String str16 = fixedDateTimeZone4.getName((long) 166);
        long long19 = fixedDateTimeZone4.adjustOffset(100L, false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(readableInterval8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00:00.024" + "'", str16.equals("+00:00:00.024"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        int int4 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField5 = gregorianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology0.getZone();
        try {
            long long12 = gregorianChronology0.getDateTimeMillis((long) 52307, 24, 377, 52303, 52317953);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 24 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime.Property property8 = dateTime6.millisOfDay();
//        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
//        int int10 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property11 = dateTime6.centuryOfEra();
//        org.joda.time.DateTime dateTime12 = property11.roundHalfFloorCopy();
//        org.joda.time.ReadableDuration readableDuration13 = null;
//        org.joda.time.DateTime dateTime15 = dateTime12.withDurationAdded(readableDuration13, 292278993);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hour();
//        java.util.Locale locale17 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withLocale(locale17);
//        org.joda.time.Chronology chronology19 = dateTimeFormatter16.getChronolgy();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter16.withPivotYear(52284);
//        java.lang.String str22 = dateTime12.toString(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNull(chronology19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "00" + "'", str22.equals("00"));
//    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTime dateTime17 = dateTime14.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime19 = dateTime17.plusWeeks(6);
//        org.joda.time.DateTime.Property property20 = dateTime19.year();
//        int int21 = dateTime19.getSecondOfDay();
//        try {
//            org.joda.time.DateTime dateTime23 = dateTime19.withMonthOfYear(52305);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52305 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:04.316" + "'", str11.equals("����-��-��T14:32:04.316"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 52924 + "'", int21 == 52924);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        org.joda.time.DateTime dateTime8 = dateTime5.withZoneRetainFields(dateTimeZone7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        long long11 = cachedDateTimeZone9.nextTransition((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone12 = cachedDateTimeZone9.getUncachedZone();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9972000000L + "'", long11 == 9972000000L);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        java.lang.String str29 = unsupportedDateTimeField28.getName();
//        long long32 = unsupportedDateTimeField28.getDifferenceAsLong(3600000L, 0L);
//        try {
//            long long35 = unsupportedDateTimeField28.set(3135600960L, "����-��-��T14:31:54.738");
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:04.387" + "'", str11.equals("����-��-��T14:32:04.387"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "weekyear" + "'", str29.equals("weekyear"));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(1560634263199L, (long) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 81152981686348");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "weekOfWeekyear", 24, (-870));
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        try {
            long long8 = dateTimeFormatter0.parseMillis("America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"America/Los_Angeles\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        java.util.TimeZone timeZone17 = null;
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forTimeZone(timeZone17);
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval21 = null;
//        org.joda.time.ReadableInterval readableInterval22 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval21);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((java.lang.Object) readableInterval21);
//        org.joda.time.DateTime.Property property24 = dateTime23.weekOfWeekyear();
//        org.joda.time.DateTime dateTime26 = dateTime23.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay27 = dateTime26.toTimeOfDay();
//        java.lang.String str28 = dateTimeFormatter20.print((org.joda.time.ReadablePartial) timeOfDay27);
//        org.joda.time.DateTime dateTime29 = dateTime19.withFields((org.joda.time.ReadablePartial) timeOfDay27);
//        org.joda.time.DateTime dateTime31 = dateTime19.withEra(0);
//        org.joda.time.DateTime.Property property32 = dateTime31.weekyear();
//        int int33 = property15.getDifference((org.joda.time.ReadableInstant) dateTime31);
//        org.joda.time.DateTime dateTime35 = dateTime31.minusMinutes(166);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:04.446" + "'", str11.equals("����-��-��T14:32:04.446"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertNotNull(readableInterval22);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(timeOfDay27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "����-��-��T14:32:04.452" + "'", str28.equals("����-��-��T14:32:04.452"));
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(dateTime35);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0, 0, (-2608), 292278993, 0, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTime dateTime17 = dateTime14.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime19 = dateTime17.plusWeeks(6);
//        org.joda.time.DateTime.Property property20 = dateTime19.year();
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime19.minus(readableDuration21);
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField24 = gregorianChronology23.millis();
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology23.weekOfWeekyear();
//        org.joda.time.DurationField durationField26 = gregorianChronology23.hours();
//        org.joda.time.DateTimeZone dateTimeZone27 = gregorianChronology23.getZone();
//        org.joda.time.ReadableInterval readableInterval28 = null;
//        org.joda.time.ReadableInterval readableInterval29 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval28);
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) readableInterval28);
//        org.joda.time.DateTime.Property property31 = dateTime30.weekOfWeekyear();
//        org.joda.time.DateTime dateTime33 = dateTime30.withWeekOfWeekyear((int) '4');
//        java.util.TimeZone timeZone34 = null;
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forTimeZone(timeZone34);
//        org.joda.time.DateTime dateTime36 = dateTime33.withZoneRetainFields(dateTimeZone35);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone37 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
//        long long39 = cachedDateTimeZone37.nextTransition((long) (short) 0);
//        org.joda.time.chrono.ZonedChronology zonedChronology40 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology23, (org.joda.time.DateTimeZone) cachedDateTimeZone37);
//        org.joda.time.DateTimeZone dateTimeZone41 = gregorianChronology23.getZone();
//        org.joda.time.DateTime dateTime42 = dateTime22.withZoneRetainFields(dateTimeZone41);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:05.045" + "'", str11.equals("����-��-��T14:32:05.045"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(readableInterval29);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 9972000000L + "'", long39 == 9972000000L);
//        org.junit.Assert.assertNotNull(zonedChronology40);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertNotNull(dateTime42);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.halfdayOfDay();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) readableInterval3);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTime dateTime8 = dateTime5.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.DateTime dateTime11 = dateTime8.withZoneRetainFields(dateTimeZone10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
        long long14 = cachedDateTimeZone12.nextTransition((long) (short) 0);
        org.joda.time.Chronology chronology15 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone12);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology17);
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology17.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone19);
        org.joda.time.Chronology chronology22 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone21);
        org.joda.time.DurationField durationField23 = gregorianChronology0.weekyears();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(readableInterval4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9972000000L + "'", long14 == 9972000000L);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(durationField23);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
        org.joda.time.DateTime dateTime8 = dateTime6.plusMonths((int) (short) -1);
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.ReadableInterval readableInterval10 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) readableInterval9);
        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
        org.joda.time.DateTime.Property property13 = dateTime11.millisOfDay();
        boolean boolean15 = dateTime11.isEqual((long) (-870));
        org.joda.time.DateTime dateTime17 = dateTime11.plusMonths((int) 'a');
        org.joda.time.DateTime.Property property18 = dateTime11.millisOfDay();
        org.joda.time.DateTime.Property property19 = dateTime11.dayOfYear();
        boolean boolean20 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime11);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(readableInterval10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.DateTime dateTime13 = dateTime10.withZoneRetainFields(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        long long16 = cachedDateTimeZone14.nextTransition((long) (short) 0);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
        org.joda.time.Chronology chronology18 = zonedChronology17.withUTC();
        org.joda.time.Chronology chronology19 = zonedChronology17.withUTC();
        org.joda.time.DurationField durationField20 = zonedChronology17.halfdays();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(readableInterval6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9972000000L + "'", long16 == 9972000000L);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(durationField20);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTime.Property property8 = dateTime6.millisOfDay();
        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
        int int10 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime13 = dateTime6.withDurationAdded((long) (short) 0, (int) (byte) 0);
        boolean boolean15 = dateTime6.isBefore((long) 10);
        org.joda.time.DateTime.Property property16 = dateTime6.secondOfDay();
        org.joda.time.DurationField durationField17 = property16.getRangeDurationField();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(readableInterval5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfDay();
        boolean boolean6 = dateTime2.isEqual((long) (-870));
        org.joda.time.DateTime.Property property7 = dateTime2.dayOfYear();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
        org.joda.time.LocalDateTime localDateTime7 = dateTime2.toLocalDateTime();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = dateTime2.toDateTime(dateTimeZone8);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.ReadableInterval readableInterval11 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) readableInterval10);
        org.joda.time.DateTime.Property property13 = dateTime12.weekOfWeekyear();
        org.joda.time.DateTime dateTime15 = dateTime12.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone16 = null;
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forTimeZone(timeZone16);
        org.joda.time.DateTime dateTime18 = dateTime15.withZoneRetainFields(dateTimeZone17);
        java.lang.String str19 = dateTimeZone17.getID();
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now(dateTimeZone17);
        org.joda.time.DateTime dateTime21 = dateTime2.toDateTime(dateTimeZone17);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(readableInterval11);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "America/Los_Angeles" + "'", str19.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "����-��-��T14:31:00.636", "����-��-��T14:30:58.818");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "", "GregorianChronology[UTC]");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getName(locale9, "America/Los_Angeles", "����-��-��T14:32:04.452");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getShortName((long) (short) 100, locale2);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        long long8 = offsetDateTimeField5.getDifferenceAsLong((long) (short) -1, (long) 1970);
        java.lang.String str10 = offsetDateTimeField5.getAsText((long) 6);
        long long12 = offsetDateTimeField5.remainder((long) 79);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "377" + "'", str10.equals("377"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 79L + "'", long12 == 79L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 12775L, 21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Coordinated Universal Time", "����-��-��T14:31:01.229");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����-��-��T14:31:01.229" + "'", str3.equals("����-��-��T14:31:01.229"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(52263, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneName();
        boolean boolean7 = dateTimeFormatterBuilder0.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.halfdays();
        org.joda.time.DurationField durationField6 = iSOChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology4.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology10 = iSOChronology4.withZone(dateTimeZone9);
        long long14 = dateTimeZone9.convertLocalToUTC((long) 57600000, true, (long) (short) 100);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 86400000L + "'", long14 == 86400000L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendTimeZoneOffset("24", "Property[weekOfWeekyear]", true, (int) 'a', 166);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.appendMillisOfSecond(871);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendFractionOfDay((int) '#', (int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime2.withMonthOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property7 = dateTime2.hourOfDay();
        org.joda.time.DateTime dateTime8 = dateTime2.toDateTime();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(52317953, 19, 19, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("weekOfWeekyear", (java.lang.Number) 1L, (java.lang.Number) (byte) 10, number3);
        java.lang.Number number5 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.Number number9 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException("weekOfWeekyear", (java.lang.Number) 1L, (java.lang.Number) (byte) 10, number9);
        java.lang.Number number11 = illegalFieldValueException10.getIllegalNumberValue();
        java.lang.String str12 = illegalFieldValueException10.getIllegalStringValue();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException10);
        org.joda.time.DurationFieldType durationFieldType14 = illegalFieldValueException10.getDurationFieldType();
        illegalFieldValueException10.prependMessage("");
        java.lang.Number number17 = illegalFieldValueException10.getUpperBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1L + "'", number5.equals(1L));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 1L + "'", number11.equals(1L));
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(durationFieldType14);
        org.junit.Assert.assertNull(number17);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.junit.Assert.assertNotNull(dateTime0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        org.joda.time.DateTime dateTime8 = dateTime5.withZoneRetainFields(dateTimeZone7);
        java.lang.String str9 = dateTimeZone7.getID();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.plus(readableDuration11);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "America/Los_Angeles" + "'", str9.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime2.withMonthOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = dateTime6.toDateTime(dateTimeZone9);
        org.joda.time.DateTime dateTime13 = dateTime11.plusDays(0);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury((int) (byte) 100, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatterBuilder0.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime2.withMonthOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        org.joda.time.TimeOfDay timeOfDay8 = dateTime6.toTimeOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology10.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DurationField durationField14 = iSOChronology13.halfdays();
        org.joda.time.DurationField durationField15 = iSOChronology13.weeks();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology13.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology13.minuteOfHour();
        org.joda.time.DateTime dateTime18 = dateTime6.withChronology((org.joda.time.Chronology) iSOChronology13);
        try {
            org.joda.time.DateTime dateTime20 = dateTime6.withMillisOfSecond(52263199);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52263199 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(timeOfDay8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(13);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        long long31 = unsupportedDateTimeField28.add((long) 52274482, (long) 13);
//        org.joda.time.DurationField durationField32 = unsupportedDateTimeField28.getDurationField();
//        int int35 = unsupportedDateTimeField28.getDifference(96L, 1577572260761L);
//        boolean boolean36 = unsupportedDateTimeField28.isLenient();
//        org.joda.time.ReadablePartial readablePartial37 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology40);
//        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, 365);
//        int int46 = offsetDateTimeField44.getMinimumValue((long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField44, (int) '#');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter50 = dateTimeFormatter49.withOffsetParsed();
//        org.joda.time.ReadableInterval readableInterval51 = null;
//        org.joda.time.ReadableInterval readableInterval52 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval51);
//        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((java.lang.Object) readableInterval51);
//        org.joda.time.MutableDateTime mutableDateTime54 = dateTime53.toMutableDateTime();
//        org.joda.time.DateTime.Property property55 = dateTime53.secondOfMinute();
//        org.joda.time.DateTime dateTime57 = dateTime53.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime58 = dateTime53.toLocalDateTime();
//        java.lang.String str59 = dateTimeFormatter50.print((org.joda.time.ReadablePartial) localDateTime58);
//        org.joda.time.chrono.GregorianChronology gregorianChronology60 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone61 = gregorianChronology60.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter62 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter63 = dateTimeFormatter62.withOffsetParsed();
//        org.joda.time.ReadableInterval readableInterval64 = null;
//        org.joda.time.ReadableInterval readableInterval65 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval64);
//        org.joda.time.DateTime dateTime66 = new org.joda.time.DateTime((java.lang.Object) readableInterval64);
//        org.joda.time.MutableDateTime mutableDateTime67 = dateTime66.toMutableDateTime();
//        org.joda.time.DateTime.Property property68 = dateTime66.secondOfMinute();
//        org.joda.time.DateTime dateTime70 = dateTime66.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime71 = dateTime66.toLocalDateTime();
//        java.lang.String str72 = dateTimeFormatter63.print((org.joda.time.ReadablePartial) localDateTime71);
//        int[] intArray74 = gregorianChronology60.get((org.joda.time.ReadablePartial) localDateTime71, (-1209599903L));
//        int int75 = offsetDateTimeField44.getMinimumValue((org.joda.time.ReadablePartial) localDateTime58, intArray74);
//        try {
//            int[] intArray77 = unsupportedDateTimeField28.addWrapPartial(readablePartial37, 0, intArray74, 2031);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:08.041" + "'", str11.equals("����-��-��T14:32:08.041"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 7914674482L + "'", long31 == 7914674482L);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-2608) + "'", int35 == (-2608));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 366 + "'", int46 == 366);
//        org.junit.Assert.assertNotNull(dateTimeFormatter49);
//        org.junit.Assert.assertNotNull(dateTimeFormatter50);
//        org.junit.Assert.assertNotNull(readableInterval52);
//        org.junit.Assert.assertNotNull(mutableDateTime54);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(localDateTime58);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "2019-W24" + "'", str59.equals("2019-W24"));
//        org.junit.Assert.assertNotNull(gregorianChronology60);
//        org.junit.Assert.assertNotNull(dateTimeZone61);
//        org.junit.Assert.assertNotNull(dateTimeFormatter62);
//        org.junit.Assert.assertNotNull(dateTimeFormatter63);
//        org.junit.Assert.assertNotNull(readableInterval65);
//        org.junit.Assert.assertNotNull(mutableDateTime67);
//        org.junit.Assert.assertNotNull(property68);
//        org.junit.Assert.assertNotNull(dateTime70);
//        org.junit.Assert.assertNotNull(localDateTime71);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "2019-W24" + "'", str72.equals("2019-W24"));
//        org.junit.Assert.assertNotNull(intArray74);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 366 + "'", int75 == 366);
//    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
//        java.util.Locale locale1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
//        org.joda.time.Chronology chronology3 = dateTimeFormatter2.getChronology();
//        java.lang.Appendable appendable4 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withOffsetParsed();
//        org.joda.time.ReadableInterval readableInterval9 = null;
//        org.joda.time.ReadableInterval readableInterval10 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval9);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) readableInterval9);
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime11.toMutableDateTime();
//        org.joda.time.DateTime.Property property13 = dateTime11.secondOfMinute();
//        org.joda.time.DateTime dateTime15 = dateTime11.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime16 = dateTime11.toLocalDateTime();
//        java.lang.String str17 = dateTimeFormatter8.print((org.joda.time.ReadablePartial) localDateTime16);
//        int[] intArray19 = gregorianChronology5.get((org.joda.time.ReadablePartial) localDateTime16, (-1209599903L));
//        try {
//            dateTimeFormatter2.printTo(appendable4, (org.joda.time.ReadablePartial) localDateTime16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNull(chronology3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(readableInterval10);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(localDateTime16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019-W24" + "'", str17.equals("2019-W24"));
//        org.junit.Assert.assertNotNull(intArray19);
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getDurationField();
        long long10 = offsetDateTimeField5.roundHalfCeiling(28800365L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28800000L + "'", long10 == 28800000L);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(52263, (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfHour(166, (int) (byte) 10);
//        org.joda.time.format.DateTimePrinter dateTimePrinter10 = dateTimeFormatterBuilder9.toPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendFractionOfHour(166, (int) (byte) 10);
//        org.joda.time.format.DateTimePrinter dateTimePrinter15 = dateTimeFormatterBuilder14.toPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder16.appendFractionOfHour(166, (int) (byte) 10);
//        org.joda.time.format.DateTimePrinter dateTimePrinter20 = dateTimeFormatterBuilder19.toPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        boolean boolean22 = dateTimeFormatter21.isParser();
//        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter21.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        boolean boolean25 = dateTimeFormatter24.isParser();
//        org.joda.time.format.DateTimeParser dateTimeParser26 = dateTimeFormatter24.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        org.joda.time.format.DateTimeParser dateTimeParser28 = dateTimeFormatter27.getParser();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray29 = new org.joda.time.format.DateTimeParser[] { dateTimeParser23, dateTimeParser26, dateTimeParser28 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder14.append(dateTimePrinter20, dateTimeParserArray29);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        org.joda.time.format.DateTimeParser dateTimeParser32 = dateTimeFormatter31.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter20, dateTimeParser32);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder5.append(dateTimePrinter10, dateTimeParser32);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder34.appendWeekyear(0, 57600000);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder34.appendMonthOfYear(57600000);
//        java.util.TimeZone timeZone40 = null;
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forTimeZone(timeZone40);
//        org.joda.time.DateTime dateTime42 = org.joda.time.DateTime.now(dateTimeZone41);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval44 = null;
//        org.joda.time.ReadableInterval readableInterval45 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval44);
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((java.lang.Object) readableInterval44);
//        org.joda.time.DateTime.Property property47 = dateTime46.weekOfWeekyear();
//        org.joda.time.DateTime dateTime49 = dateTime46.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay50 = dateTime49.toTimeOfDay();
//        java.lang.String str51 = dateTimeFormatter43.print((org.joda.time.ReadablePartial) timeOfDay50);
//        org.joda.time.DateTime dateTime52 = dateTime42.withFields((org.joda.time.ReadablePartial) timeOfDay50);
//        org.joda.time.DateTime dateTime54 = dateTime42.withEra(0);
//        org.joda.time.DateTime.Property property55 = dateTime54.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = property55.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException58 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType56, "Coordinated Universal Time");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder34.appendText(dateTimeFieldType56);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTimePrinter10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimePrinter15);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
//        org.junit.Assert.assertNotNull(dateTimePrinter20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(dateTimeParser23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTimeParser26);
//        org.junit.Assert.assertNotNull(dateTimeFormatter27);
//        org.junit.Assert.assertNotNull(dateTimeParser28);
//        org.junit.Assert.assertNotNull(dateTimeParserArray29);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(dateTimeParser32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTimeFormatter43);
//        org.junit.Assert.assertNotNull(readableInterval45);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(timeOfDay50);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "����-��-��T14:32:08.312" + "'", str51.equals("����-��-��T14:32:08.312"));
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertNotNull(dateTimeFieldType56);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("weekOfWeekyear", (java.lang.Number) 1L, (java.lang.Number) (byte) 10, number3);
        java.lang.Number number5 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.String str6 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Number number7 = illegalFieldValueException4.getUpperBound();
        java.lang.String str8 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1L + "'", number5.equals(1L));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        java.lang.String str4 = gregorianChronology1.toString();
        org.joda.time.DurationField durationField5 = gregorianChronology1.seconds();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[UTC]" + "'", str4.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField5);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(52263, (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendYearOfEra(100, (int) ' ');
//        java.util.TimeZone timeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval13 = null;
//        org.joda.time.ReadableInterval readableInterval14 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval13);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) readableInterval13);
//        org.joda.time.DateTime.Property property16 = dateTime15.weekOfWeekyear();
//        org.joda.time.DateTime dateTime18 = dateTime15.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay19 = dateTime18.toTimeOfDay();
//        java.lang.String str20 = dateTimeFormatter12.print((org.joda.time.ReadablePartial) timeOfDay19);
//        org.joda.time.DateTime dateTime21 = dateTime11.withFields((org.joda.time.ReadablePartial) timeOfDay19);
//        org.joda.time.DateTime dateTime23 = dateTime11.withEra(0);
//        org.joda.time.DateTime.Property property24 = dateTime23.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder0.appendFixedSignedDecimal(dateTimeFieldType25, 1970);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "PST");
//        illegalFieldValueException29.prependMessage("����-��-��T14:32:05.045");
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(readableInterval14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(timeOfDay19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "����-��-��T14:32:08.911" + "'", str20.equals("����-��-��T14:32:08.911"));
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter0.getParser();
        java.lang.Integer int3 = dateTimeFormatter0.getPivotYear();
        try {
            long long5 = dateTimeFormatter0.parseMillis("����-��-��T14:31:00.636");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"����-��-��T14:31:00.636\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNull(int3);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        int int4 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField5 = gregorianChronology0.seconds();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
        long long10 = offsetDateTimeField5.getDifferenceAsLong((long) (byte) -1, (long) 100);
        long long12 = offsetDateTimeField5.remainder((long) 57600);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField5.getType();
        org.joda.time.ReadableInterval readableInterval14 = null;
        org.joda.time.ReadableInterval readableInterval15 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) readableInterval14);
        org.joda.time.MutableDateTime mutableDateTime17 = dateTime16.toMutableDateTime();
        org.joda.time.DateTime.Property property18 = dateTime16.secondOfMinute();
        org.joda.time.DateTime dateTime20 = dateTime16.plusMillis((int) (byte) 10);
        org.joda.time.LocalDateTime localDateTime21 = dateTime16.toLocalDateTime();
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDateTime21, 52286, locale23);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 57600L + "'", long12 == 57600L);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(readableInterval15);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "52286" + "'", str24.equals("52286"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int6 = offsetDateTimeField5.getMaximumValue();
        long long8 = offsetDateTimeField5.roundHalfFloor((long) (byte) 10);
        long long11 = offsetDateTimeField5.getDifferenceAsLong((long) 52284, 0L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 377 + "'", int6 == 377);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        java.lang.String str4 = property3.getName();
        java.lang.String str5 = property3.getName();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "weekOfWeekyear" + "'", str4.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "weekOfWeekyear" + "'", str5.equals("weekOfWeekyear"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.halfdayOfDay();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) readableInterval3);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTime dateTime8 = dateTime5.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.DateTime dateTime11 = dateTime8.withZoneRetainFields(dateTimeZone10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
        long long14 = cachedDateTimeZone12.nextTransition((long) (short) 0);
        org.joda.time.Chronology chronology15 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone12);
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology0.dayOfWeek();
        java.lang.String str17 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(readableInterval4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9972000000L + "'", long14 == 9972000000L);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "GregorianChronology[UTC]" + "'", str17.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
        long long10 = offsetDateTimeField5.getDifferenceAsLong((long) (byte) -1, (long) 100);
        long long12 = offsetDateTimeField5.remainder((long) 466);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology14);
        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology14.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
        org.joda.time.DurationField durationField18 = iSOChronology17.hours();
        org.joda.time.ReadableInterval readableInterval19 = null;
        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
        org.joda.time.DateTime dateTime24 = dateTime21.withWeekOfWeekyear((int) '4');
        org.joda.time.TimeOfDay timeOfDay25 = dateTime24.toTimeOfDay();
        int[] intArray27 = iSOChronology17.get((org.joda.time.ReadablePartial) timeOfDay25, 3600000L);
        int[] intArray29 = null;
        int[] intArray31 = offsetDateTimeField5.add((org.joda.time.ReadablePartial) timeOfDay25, (int) 'a', intArray29, 0);
        java.lang.String str32 = offsetDateTimeField5.toString();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 466L + "'", long12 == 466L);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(readableInterval20);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(timeOfDay25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNull(intArray31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "DateTimeField[clockhourOfHalfday]" + "'", str32.equals("DateTimeField[clockhourOfHalfday]"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.lang.Number number4 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("weekOfWeekyear", (java.lang.Number) 1L, (java.lang.Number) (byte) 10, number4);
        java.lang.Number number6 = illegalFieldValueException5.getIllegalNumberValue();
        java.lang.Number number10 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException("weekOfWeekyear", (java.lang.Number) 1L, (java.lang.Number) (byte) 10, number10);
        java.lang.Number number12 = illegalFieldValueException11.getIllegalNumberValue();
        java.lang.String str13 = illegalFieldValueException11.getIllegalStringValue();
        illegalFieldValueException5.addSuppressed((java.lang.Throwable) illegalFieldValueException11);
        org.joda.time.DurationFieldType durationFieldType15 = illegalFieldValueException11.getDurationFieldType();
        org.joda.time.DurationFieldType durationFieldType16 = illegalFieldValueException11.getDurationFieldType();
        java.lang.Throwable[] throwableArray17 = illegalFieldValueException11.getSuppressed();
        boolean boolean18 = org.joda.time.field.FieldUtils.equals((java.lang.Object) "����-��-��T14:31:35.344", (java.lang.Object) illegalFieldValueException11);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1L + "'", number6.equals(1L));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 1L + "'", number12.equals(1L));
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNull(durationFieldType15);
        org.junit.Assert.assertNull(durationFieldType16);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatterBuilder3.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatterBuilder8.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean11 = dateTimeFormatter10.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean14 = dateTimeFormatter13.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter13.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray18 = new org.joda.time.format.DateTimeParser[] { dateTimeParser12, dateTimeParser15, dateTimeParser17 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder3.append(dateTimePrinter9, dateTimeParserArray18);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder3.appendTimeZoneOffset("����-��-��T14:31:03.016", "", false, 1970, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeParserArray18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        int int4 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField5 = gregorianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField7 = gregorianChronology0.minutes();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int6 = offsetDateTimeField5.getMaximumValue();
        long long8 = offsetDateTimeField5.roundHalfFloor((long) (byte) 10);
        long long10 = offsetDateTimeField5.roundFloor((long) 365);
        long long12 = offsetDateTimeField5.roundCeiling(0L);
        try {
            long long15 = offsetDateTimeField5.set((long) (byte) 100, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for clockhourOfHalfday must be in the range [366,377]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 377 + "'", int6 == 377);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) readableInterval2);
        org.joda.time.DateTime.Property property5 = dateTime4.weekOfWeekyear();
        org.joda.time.DateTime dateTime7 = dateTime4.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        org.joda.time.DateTime dateTime10 = dateTime7.withZoneRetainFields(dateTimeZone9);
        org.joda.time.DateTime dateTime13 = dateTime7.withDurationAdded((long) 100, 0);
        org.joda.time.DateTime dateTime15 = dateTime7.minusMinutes(4);
        int int16 = dateTime7.getCenturyOfEra();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime7);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(readableInterval3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 20 + "'", int16 == 20);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        org.joda.time.DurationField durationField29 = unsupportedDateTimeField28.getLeapDurationField();
//        org.joda.time.ReadableInterval readableInterval30 = null;
//        org.joda.time.ReadableInterval readableInterval31 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval30);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((java.lang.Object) readableInterval30);
//        org.joda.time.DateTime.Property property33 = dateTime32.weekOfWeekyear();
//        org.joda.time.DateTime dateTime35 = dateTime32.withWeekOfWeekyear((int) '4');
//        java.util.TimeZone timeZone36 = null;
//        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.forTimeZone(timeZone36);
//        org.joda.time.DateTime dateTime38 = dateTime35.withZoneRetainFields(dateTimeZone37);
//        org.joda.time.DateTime dateTime41 = dateTime35.withDurationAdded((long) 100, 0);
//        org.joda.time.DateTime dateTime43 = dateTime35.minusYears(1970);
//        org.joda.time.ReadableInterval readableInterval44 = null;
//        org.joda.time.ReadableInterval readableInterval45 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval44);
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((java.lang.Object) readableInterval44);
//        org.joda.time.MutableDateTime mutableDateTime47 = dateTime46.toMutableDateTime();
//        org.joda.time.DateTime.Property property48 = dateTime46.secondOfMinute();
//        org.joda.time.DateTime dateTime50 = dateTime46.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime51 = dateTime46.toLocalDateTime();
//        org.joda.time.DateTime dateTime52 = dateTime43.withFields((org.joda.time.ReadablePartial) localDateTime51);
//        org.joda.time.chrono.GregorianChronology gregorianChronology54 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology54);
//        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology54.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField56, 365);
//        org.joda.time.ReadableInterval readableInterval59 = null;
//        org.joda.time.ReadableInterval readableInterval60 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval59);
//        org.joda.time.DateTime dateTime61 = new org.joda.time.DateTime((java.lang.Object) readableInterval59);
//        org.joda.time.YearMonthDay yearMonthDay62 = dateTime61.toYearMonthDay();
//        int[] intArray63 = new int[] {};
//        int int64 = offsetDateTimeField58.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay62, intArray63);
//        try {
//            int int65 = unsupportedDateTimeField28.getMaximumValue((org.joda.time.ReadablePartial) localDateTime51, intArray63);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:09.779" + "'", str11.equals("����-��-��T14:32:09.779"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertNull(durationField29);
//        org.junit.Assert.assertNotNull(readableInterval31);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(readableInterval45);
//        org.junit.Assert.assertNotNull(mutableDateTime47);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(localDateTime51);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(gregorianChronology54);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(readableInterval60);
//        org.junit.Assert.assertNotNull(yearMonthDay62);
//        org.junit.Assert.assertNotNull(intArray63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 366 + "'", int64 == 366);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        org.joda.time.DateTime dateTime8 = dateTime5.withZoneRetainFields(dateTimeZone7);
        org.joda.time.DateTime dateTime11 = dateTime5.withDurationAdded((long) 100, 0);
        org.joda.time.DateTime dateTime13 = dateTime5.minusYears(1970);
        org.joda.time.DateTime dateTime15 = dateTime13.plusMonths(960);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test165");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
//        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
//        org.joda.time.ReadableInterval readableInterval8 = null;
//        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) readableInterval8);
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
//        org.joda.time.DateTime.Property property12 = dateTime10.secondOfMinute();
//        org.joda.time.DateTime dateTime14 = dateTime10.withMonthOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekOfWeekyear();
//        org.joda.time.TimeOfDay timeOfDay16 = dateTime14.toTimeOfDay();
//        int int17 = offsetDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay16);
//        long long20 = offsetDateTimeField5.getDifferenceAsLong((-137478161260800870L), 52275313L);
//        java.util.TimeZone timeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now(dateTimeZone22);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval25 = null;
//        org.joda.time.ReadableInterval readableInterval26 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval25);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((java.lang.Object) readableInterval25);
//        org.joda.time.DateTime.Property property28 = dateTime27.weekOfWeekyear();
//        org.joda.time.DateTime dateTime30 = dateTime27.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay31 = dateTime30.toTimeOfDay();
//        java.lang.String str32 = dateTimeFormatter24.print((org.joda.time.ReadablePartial) timeOfDay31);
//        org.joda.time.DateTime dateTime33 = dateTime23.withFields((org.joda.time.ReadablePartial) timeOfDay31);
//        boolean boolean34 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) timeOfDay31);
//        java.util.Locale locale36 = null;
//        java.lang.String str37 = offsetDateTimeField5.getAsText((org.joda.time.ReadablePartial) timeOfDay31, 4, locale36);
//        boolean boolean38 = offsetDateTimeField5.isLenient();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
//        org.junit.Assert.assertNotNull(readableInterval9);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(timeOfDay16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 366 + "'", int17 == 366);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-38188378142L) + "'", long20 == (-38188378142L));
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertNotNull(readableInterval26);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(timeOfDay31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "����-��-��T14:32:09.870" + "'", str32.equals("����-��-��T14:32:09.870"));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "4" + "'", str37.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(57600, 'a', 8, 0, (int) (byte) 0, true, (int) (short) 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder8.setFixedSavings("", 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder8.setStandardOffset(1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder15 = dateTimeZoneBuilder13.setStandardOffset(292278993);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder17 = dateTimeZoneBuilder13.setStandardOffset(52305);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder28 = dateTimeZoneBuilder17.addRecurringSavings("����-��-��T14:31:12.892", 14, 2031, 871, 'a', 365, 12, 52305, false, (int) '4');
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder15);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder17);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder28);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("Property[millisOfDay]");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Property[millisOfDay]/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
        org.joda.time.ReadableInterval readableInterval8 = null;
        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) readableInterval8);
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
        org.joda.time.DateTime.Property property12 = dateTime10.secondOfMinute();
        org.joda.time.DateTime dateTime14 = dateTime10.withMonthOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property15 = dateTime14.weekOfWeekyear();
        org.joda.time.TimeOfDay timeOfDay16 = dateTime14.toTimeOfDay();
        int int17 = offsetDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay16);
        long long20 = offsetDateTimeField5.getDifferenceAsLong((-137478161260800870L), 52275313L);
        int int21 = offsetDateTimeField5.getMinimumValue();
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField5.getAsShortText(2019, locale23);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
        org.junit.Assert.assertNotNull(readableInterval9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(timeOfDay16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 366 + "'", int17 == 366);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-38188378142L) + "'", long20 == (-38188378142L));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 366 + "'", int21 == 366);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019" + "'", str24.equals("2019"));
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        java.lang.String str29 = unsupportedDateTimeField28.getName();
//        org.joda.time.DurationField durationField30 = unsupportedDateTimeField28.getDurationField();
//        try {
//            long long32 = unsupportedDateTimeField28.remainder((long) 2000);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:10.282" + "'", str11.equals("����-��-��T14:32:10.282"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "weekyear" + "'", str29.equals("weekyear"));
//        org.junit.Assert.assertNotNull(durationField30);
//    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfMonth((int) '4');
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField6 = gregorianChronology5.millis();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
//        org.joda.time.ReadableInterval readableInterval8 = null;
//        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) readableInterval8);
//        org.joda.time.DateTime.Property property11 = dateTime10.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = dateTime10.withWeekOfWeekyear((int) '4');
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        org.joda.time.DateTime dateTime16 = dateTime13.withZoneRetainFields(dateTimeZone15);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
//        long long19 = cachedDateTimeZone17.nextTransition((long) (short) 0);
//        org.joda.time.Chronology chronology20 = gregorianChronology5.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology5.dayOfWeek();
//        java.util.TimeZone timeZone22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now(dateTimeZone23);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval26 = null;
//        org.joda.time.ReadableInterval readableInterval27 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval26);
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) readableInterval26);
//        org.joda.time.DateTime.Property property29 = dateTime28.weekOfWeekyear();
//        org.joda.time.DateTime dateTime31 = dateTime28.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay32 = dateTime31.toTimeOfDay();
//        java.lang.String str33 = dateTimeFormatter25.print((org.joda.time.ReadablePartial) timeOfDay32);
//        org.joda.time.DateTime dateTime34 = dateTime24.withFields((org.joda.time.ReadablePartial) timeOfDay32);
//        org.joda.time.DateTime dateTime36 = dateTime24.withEra(0);
//        org.joda.time.DateTime.Property property37 = dateTime36.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property37.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, dateTimeFieldType38, 377);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder2.appendFraction(dateTimeFieldType38, 1, 14);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder44.appendTwoDigitWeekyear((int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder44.appendWeekyear(52263, (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder44.appendYearOfEra(100, (int) ' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder52.appendMinuteOfHour(52263);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder54.appendMillisOfSecond(6);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder54.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter58 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        org.joda.time.format.DateTimeParser dateTimeParser59 = dateTimeFormatter58.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder54.appendOptional(dateTimeParser59);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder2.append(dateTimeParser59);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(readableInterval9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9972000000L + "'", long19 == 9972000000L);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(readableInterval27);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(timeOfDay32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "����-��-��T14:32:10.309" + "'", str33.equals("����-��-��T14:32:10.309"));
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder57);
//        org.junit.Assert.assertNotNull(dateTimeFormatter58);
//        org.junit.Assert.assertNotNull(dateTimeParser59);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test172");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
//        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
//        int int7 = dateTime6.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
//        org.joda.time.DateTime dateTime10 = dateTime6.minusMillis(31);
//        org.joda.time.DateTime dateTime12 = dateTime6.withYearOfEra(21);
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 166 + "'", int7 == 166);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("weekOfWeekyear", (java.lang.Number) 1L, (java.lang.Number) (byte) 10, number3);
        java.lang.Number number5 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.String str6 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Number number7 = illegalFieldValueException4.getUpperBound();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = illegalFieldValueException4.getDateTimeFieldType();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1L + "'", number5.equals(1L));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNull(dateTimeFieldType8);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
        org.joda.time.DateTime dateTime8 = dateTime6.plusMonths((int) (short) -1);
        org.joda.time.DateTime dateTime10 = dateTime8.withWeekOfWeekyear(52);
        boolean boolean12 = dateTime8.isEqual((long) (short) 100);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.joda.time.DateTimeField dateTimeField0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 365);
//        int int8 = offsetDateTimeField6.getMinimumValue((long) 19);
//        long long10 = offsetDateTimeField6.roundHalfFloor(0L);
//        java.util.TimeZone timeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone12);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.ReadableInterval readableInterval16 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((java.lang.Object) readableInterval15);
//        org.joda.time.DateTime.Property property18 = dateTime17.weekOfWeekyear();
//        org.joda.time.DateTime dateTime20 = dateTime17.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay21 = dateTime20.toTimeOfDay();
//        java.lang.String str22 = dateTimeFormatter14.print((org.joda.time.ReadablePartial) timeOfDay21);
//        org.joda.time.DateTime dateTime23 = dateTime13.withFields((org.joda.time.ReadablePartial) timeOfDay21);
//        org.joda.time.DateTime dateTime25 = dateTime13.withEra(0);
//        org.joda.time.DateTime.Property property26 = dateTime25.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType27, "377");
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, dateTimeFieldType27, 52303605, 52305, (int) (short) 10);
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, dateTimeFieldType27, (-2608));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 366 + "'", int8 == 366);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(readableInterval16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(timeOfDay21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "����-��-��T14:32:11.048" + "'", str22.equals("����-��-��T14:32:11.048"));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        org.joda.time.DateTimeField dateTimeField0 = null;
//        java.util.TimeZone timeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval5 = null;
//        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
//        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
//        org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay11 = dateTime10.toTimeOfDay();
//        java.lang.String str12 = dateTimeFormatter4.print((org.joda.time.ReadablePartial) timeOfDay11);
//        org.joda.time.DateTime dateTime13 = dateTime3.withFields((org.joda.time.ReadablePartial) timeOfDay11);
//        org.joda.time.DateTime dateTime15 = dateTime3.withEra(0);
//        org.joda.time.DateTime.Property property16 = dateTime15.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property16.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType17, "Coordinated Universal Time");
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, dateTimeFieldType17, 8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(readableInterval6);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(timeOfDay11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "����-��-��T14:32:11.069" + "'", str12.equals("����-��-��T14:32:11.069"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
        org.joda.time.DateTime.Property property7 = dateTime2.yearOfCentury();
        org.joda.time.DateTime dateTime9 = dateTime2.minus((long) ' ');
        org.joda.time.DateTime.Property property10 = dateTime9.weekyear();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test178");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTime dateTime17 = dateTime14.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime19 = dateTime17.plusWeeks(6);
//        org.joda.time.DateTime dateTime21 = dateTime17.withWeekyear(6);
//        org.joda.time.MutableDateTime mutableDateTime22 = dateTime17.toMutableDateTime();
//        java.util.TimeZone timeZone23 = null;
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forTimeZone(timeZone23);
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now(dateTimeZone24);
//        org.joda.time.DateTime.Property property26 = dateTime25.minuteOfHour();
//        org.joda.time.DateTime.Property property27 = dateTime25.year();
//        boolean boolean29 = dateTime25.isAfter(28800365L);
//        int int30 = dateTime17.compareTo((org.joda.time.ReadableInstant) dateTime25);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:11.147" + "'", str11.equals("����-��-��T14:32:11.147"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(mutableDateTime22);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.minuteOfHour();
//        org.joda.time.DateTime.Property property4 = dateTime2.year();
//        int int5 = dateTime2.getWeekOfWeekyear();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2019);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "weekOfWeekyear", 24, (-870));
        long long9 = fixedDateTimeZone7.nextTransition((long) 2019);
        boolean boolean10 = fixedDateTimeZone7.isFixed();
        org.joda.time.DateTime dateTime11 = dateTime1.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test181");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTime dateTime17 = dateTime14.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime19 = dateTime17.plusWeeks(6);
//        org.joda.time.DateTime.Property property20 = dateTime19.year();
//        org.joda.time.DateTime.Property property21 = dateTime19.era();
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = property21.getAsShortText(locale22);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:11.579" + "'", str11.equals("����-��-��T14:32:11.579"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "BC" + "'", str23.equals("BC"));
//    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        org.joda.time.DateTime dateTime8 = dateTime5.withZoneRetainFields(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.year();
//        int int10 = property9.getMaximumValueOverall();
//        java.util.TimeZone timeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone12);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.ReadableInterval readableInterval16 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((java.lang.Object) readableInterval15);
//        org.joda.time.DateTime.Property property18 = dateTime17.weekOfWeekyear();
//        org.joda.time.DateTime dateTime20 = dateTime17.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay21 = dateTime20.toTimeOfDay();
//        java.lang.String str22 = dateTimeFormatter14.print((org.joda.time.ReadablePartial) timeOfDay21);
//        org.joda.time.DateTime dateTime23 = dateTime13.withFields((org.joda.time.ReadablePartial) timeOfDay21);
//        org.joda.time.DateTime dateTime25 = dateTime13.withEra(0);
//        org.joda.time.DateTime.Property property26 = dateTime25.monthOfYear();
//        boolean boolean28 = dateTime25.isEqual((-28799980L));
//        boolean boolean29 = property9.equals((java.lang.Object) boolean28);
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292278993 + "'", int10 == 292278993);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(readableInterval16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(timeOfDay21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "����-��-��T14:32:11.724" + "'", str22.equals("����-��-��T14:32:11.724"));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.DateTime dateTime13 = dateTime10.withZoneRetainFields(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        long long16 = cachedDateTimeZone14.nextTransition((long) (short) 0);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
        java.lang.String str18 = zonedChronology17.toString();
        java.lang.String str19 = zonedChronology17.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        java.util.TimeZone timeZone22 = dateTimeZone21.toTimeZone();
        org.joda.time.Chronology chronology23 = zonedChronology17.withZone(dateTimeZone21);
        java.lang.String str24 = dateTimeZone21.getID();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(readableInterval6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9972000000L + "'", long16 == 9972000000L);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]" + "'", str18.equals("ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]" + "'", str19.equals("ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "UTC" + "'", str24.equals("UTC"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(3600000L);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.junit.Assert.assertNotNull(gregorianCalendar2);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test185");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        long long31 = unsupportedDateTimeField28.add((long) 52274482, (long) 13);
//        org.joda.time.DurationField durationField32 = unsupportedDateTimeField28.getDurationField();
//        org.joda.time.ReadablePartial readablePartial33 = null;
//        java.util.Locale locale34 = null;
//        try {
//            java.lang.String str35 = unsupportedDateTimeField28.getAsText(readablePartial33, locale34);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:12.348" + "'", str11.equals("����-��-��T14:32:12.348"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 7914674482L + "'", long31 == 7914674482L);
//        org.junit.Assert.assertNotNull(durationField32);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.halfdays();
        org.joda.time.DurationField durationField6 = iSOChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology4.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology10 = iSOChronology4.withZone(dateTimeZone9);
        org.joda.time.ReadablePartial readablePartial11 = null;
        try {
            int[] intArray13 = iSOChronology4.get(readablePartial11, 79L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        java.util.Locale locale2 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "����-��-��T14:31:00.636", "����-��-��T14:30:58.818");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str4);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "weekOfWeekyear", 24, (-870));
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.ReadableInterval readableInterval8 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) readableInterval7);
//        org.joda.time.DateTime.Property property10 = dateTime9.weekOfWeekyear();
//        org.joda.time.DateTime dateTime12 = dateTime9.withWeekOfWeekyear((int) '4');
//        int int13 = dateTime12.getWeekyear();
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.ReadableInterval readableInterval16 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((java.lang.Object) readableInterval15);
//        org.joda.time.DateTime.Property property18 = dateTime17.weekOfWeekyear();
//        org.joda.time.DateTime dateTime20 = dateTime17.withWeekOfWeekyear((int) '4');
//        org.joda.time.MutableDateTime mutableDateTime21 = dateTime17.toMutableDateTimeISO();
//        java.util.Locale locale22 = null;
//        java.util.Calendar calendar23 = dateTime17.toCalendar(locale22);
//        int int24 = dateTime17.getMinuteOfDay();
//        boolean boolean25 = dateTime12.isAfter((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime dateTime28 = dateTime17.plusYears(52278009);
//        java.lang.String str29 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(readableInterval8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577572332412L + "'", long14 == 1577572332412L);
//        org.junit.Assert.assertNotNull(readableInterval16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(mutableDateTime21);
//        org.junit.Assert.assertNotNull(calendar23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 872 + "'", int24 == 872);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "T143212-0700" + "'", str29.equals("T143212-0700"));
//    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        java.lang.String str29 = unsupportedDateTimeField28.getName();
//        try {
//            long long31 = unsupportedDateTimeField28.remainder((-137478161260800870L));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:12.629" + "'", str11.equals("����-��-��T14:32:12.629"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "weekyear" + "'", str29.equals("weekyear"));
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int6 = offsetDateTimeField5.getMaximumValue();
        long long9 = offsetDateTimeField5.add(9L, 292278993);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField5.getAsText((int) (short) 1, locale11);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 377 + "'", int6 == 377);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1052204374800009L + "'", long9 == 1052204374800009L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test193");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval1 = null;
//        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) readableInterval1);
//        org.joda.time.DateTime.Property property4 = dateTime3.weekOfWeekyear();
//        org.joda.time.DateTime dateTime6 = dateTime3.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay7 = dateTime6.toTimeOfDay();
//        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) timeOfDay7);
//        java.lang.StringBuffer stringBuffer9 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology11);
//        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology11.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.DurationField durationField15 = iSOChronology14.halfdays();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology14);
//        try {
//            dateTimeFormatter0.printTo(stringBuffer9, (org.joda.time.ReadableInstant) dateTime16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(readableInterval2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(timeOfDay7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����-��-��T14:32:12.667" + "'", str8.equals("����-��-��T14:32:12.667"));
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "weekOfWeekyear", 24, (-870));
        long long6 = fixedDateTimeZone4.previousTransition((long) 12775);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) 'a', true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 12775L + "'", long6 == 12775L);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 73L + "'", long10 == 73L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.halfdays();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.weekyear();
        try {
            long long11 = iSOChronology4.getDateTimeMillis((int) (byte) 10, 52257628, 960, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52257628 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(52263, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendYearOfEra(100, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMinuteOfHour(52263);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap11 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendTimeZoneShortName(strMap11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test197");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        try {
//            java.lang.String str30 = unsupportedDateTimeField28.getAsText((long) 19);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:13.001" + "'", str11.equals("����-��-��T14:32:13.001"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
        org.joda.time.DateTime.Property property5 = dateTime2.centuryOfEra();
        java.util.Locale locale6 = null;
        java.lang.String str7 = property5.getAsText(locale6);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "20" + "'", str7.equals("20"));
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test199");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
//        int int5 = dateTime2.getMillisOfDay();
//        int int6 = dateTime2.getMinuteOfHour();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime2.minus(readablePeriod7);
//        org.joda.time.DateTime dateTime10 = dateTime2.plusMillis(52901);
//        org.joda.time.DateTime.Property property11 = dateTime2.minuteOfDay();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52333813 + "'", int5 == 52333813);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test200");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
//        int int6 = offsetDateTimeField5.getMaximumValue();
//        int int8 = offsetDateTimeField5.getMaximumValue(96L);
//        java.util.TimeZone timeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval13 = null;
//        org.joda.time.ReadableInterval readableInterval14 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval13);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) readableInterval13);
//        org.joda.time.DateTime.Property property16 = dateTime15.weekOfWeekyear();
//        org.joda.time.DateTime dateTime18 = dateTime15.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay19 = dateTime18.toTimeOfDay();
//        java.lang.String str20 = dateTimeFormatter12.print((org.joda.time.ReadablePartial) timeOfDay19);
//        org.joda.time.DateTime dateTime21 = dateTime11.withFields((org.joda.time.ReadablePartial) timeOfDay19);
//        org.joda.time.DateTime dateTime23 = dateTime11.withEra(0);
//        org.joda.time.DateTime.Property property24 = dateTime23.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "377");
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType25, (-100), 52263, 57600);
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology33);
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology33.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField35, 365);
//        int int39 = offsetDateTimeField37.getMinimumValue((long) 19);
//        org.joda.time.ReadableInterval readableInterval40 = null;
//        org.joda.time.ReadableInterval readableInterval41 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval40);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((java.lang.Object) readableInterval40);
//        org.joda.time.MutableDateTime mutableDateTime43 = dateTime42.toMutableDateTime();
//        org.joda.time.DateTime.Property property44 = dateTime42.secondOfMinute();
//        org.joda.time.DateTime dateTime46 = dateTime42.withMonthOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property47 = dateTime46.weekOfWeekyear();
//        org.joda.time.TimeOfDay timeOfDay48 = dateTime46.toTimeOfDay();
//        int int49 = offsetDateTimeField37.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay48);
//        int[] intArray53 = new int[] { 9, 1970 };
//        try {
//            int[] intArray55 = offsetDateTimeField31.set((org.joda.time.ReadablePartial) timeOfDay48, 1, intArray53, 52303605);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52303605 for weekyear must be in the range [52263,277]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 377 + "'", int6 == 377);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 377 + "'", int8 == 377);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(readableInterval14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(timeOfDay19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "����-��-��T14:32:14.368" + "'", str20.equals("����-��-��T14:32:14.368"));
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 366 + "'", int39 == 366);
//        org.junit.Assert.assertNotNull(readableInterval41);
//        org.junit.Assert.assertNotNull(mutableDateTime43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertNotNull(timeOfDay48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 366 + "'", int49 == 366);
//        org.junit.Assert.assertNotNull(intArray53);
//    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test201");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
//        org.joda.time.DateTime dateTime6 = dateTime2.withMonthOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
//        org.joda.time.DateTime dateTime11 = dateTime6.toDateTime(dateTimeZone9);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology13);
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 365);
//        int int19 = offsetDateTimeField17.getMinimumValue((long) 19);
//        org.joda.time.ReadableInterval readableInterval20 = null;
//        org.joda.time.ReadableInterval readableInterval21 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval20);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((java.lang.Object) readableInterval20);
//        org.joda.time.MutableDateTime mutableDateTime23 = dateTime22.toMutableDateTime();
//        org.joda.time.DateTime.Property property24 = dateTime22.secondOfMinute();
//        org.joda.time.DateTime dateTime26 = dateTime22.withMonthOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property27 = dateTime26.weekOfWeekyear();
//        org.joda.time.TimeOfDay timeOfDay28 = dateTime26.toTimeOfDay();
//        int int29 = offsetDateTimeField17.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay28);
//        long long32 = offsetDateTimeField17.getDifferenceAsLong((-137478161260800870L), 52275313L);
//        java.util.TimeZone timeZone33 = null;
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forTimeZone(timeZone33);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone34);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval37 = null;
//        org.joda.time.ReadableInterval readableInterval38 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval37);
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((java.lang.Object) readableInterval37);
//        org.joda.time.DateTime.Property property40 = dateTime39.weekOfWeekyear();
//        org.joda.time.DateTime dateTime42 = dateTime39.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay43 = dateTime42.toTimeOfDay();
//        java.lang.String str44 = dateTimeFormatter36.print((org.joda.time.ReadablePartial) timeOfDay43);
//        org.joda.time.DateTime dateTime45 = dateTime35.withFields((org.joda.time.ReadablePartial) timeOfDay43);
//        boolean boolean46 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) timeOfDay43);
//        java.util.Locale locale48 = null;
//        java.lang.String str49 = offsetDateTimeField17.getAsText((org.joda.time.ReadablePartial) timeOfDay43, 4, locale48);
//        org.joda.time.DateTime dateTime50 = dateTime6.withFields((org.joda.time.ReadablePartial) timeOfDay43);
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 366 + "'", int19 == 366);
//        org.junit.Assert.assertNotNull(readableInterval21);
//        org.junit.Assert.assertNotNull(mutableDateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(timeOfDay28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 366 + "'", int29 == 366);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-38188378142L) + "'", long32 == (-38188378142L));
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTimeFormatter36);
//        org.junit.Assert.assertNotNull(readableInterval38);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(timeOfDay43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "����-��-��T14:32:14.396" + "'", str44.equals("����-��-��T14:32:14.396"));
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "4" + "'", str49.equals("4"));
//        org.junit.Assert.assertNotNull(dateTime50);
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(52263, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendYearOfEra(100, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMinuteOfHour(52263);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMillisOfSecond(6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder10.appendOptional(dateTimeParser15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendMonthOfYearText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test203");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime.Property property8 = dateTime6.millisOfDay();
//        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
//        int int10 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime12 = dateTime6.plusMinutes(377);
//        org.joda.time.DateTime dateTime13 = dateTime6.toDateTimeISO();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime.Property property8 = dateTime6.millisOfDay();
//        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
//        int int10 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime13 = dateTime6.withDurationAdded((long) (short) 0, (int) (byte) 0);
//        org.joda.time.ReadableDuration readableDuration14 = null;
//        org.joda.time.DateTime dateTime16 = dateTime13.withDurationAdded(readableDuration14, 12);
//        org.joda.time.DateTime.Property property17 = dateTime16.year();
//        org.joda.time.DateTime dateTime19 = property17.addWrapFieldToCopy((int) (short) 1);
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test205");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime.Property property4 = dateTime2.millisOfDay();
//        java.lang.String str5 = property4.getAsString();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "52336618" + "'", str5.equals("52336618"));
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(32, 870);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 902 + "'", int2 == 902);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test207");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        long long31 = unsupportedDateTimeField28.add((long) 52274482, (long) 13);
//        org.joda.time.DurationField durationField32 = unsupportedDateTimeField28.getDurationField();
//        int int35 = unsupportedDateTimeField28.getDifference(96L, 1577572260761L);
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.ReadableInterval readableInterval37 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((java.lang.Object) readableInterval36);
//        org.joda.time.MutableDateTime mutableDateTime39 = dateTime38.toMutableDateTime();
//        org.joda.time.DateTime.Property property40 = dateTime38.secondOfMinute();
//        org.joda.time.DateTime dateTime42 = dateTime38.withMonthOfYear((int) (byte) 1);
//        org.joda.time.LocalDateTime localDateTime43 = dateTime38.toLocalDateTime();
//        try {
//            int int44 = unsupportedDateTimeField28.getMinimumValue((org.joda.time.ReadablePartial) localDateTime43);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:16.643" + "'", str11.equals("����-��-��T14:32:16.643"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 7914674482L + "'", long31 == 7914674482L);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-2608) + "'", int35 == (-2608));
//        org.junit.Assert.assertNotNull(readableInterval37);
//        org.junit.Assert.assertNotNull(mutableDateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(localDateTime43);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.hours();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.ReadableInterval readableInterval7 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) readableInterval6);
        org.joda.time.DateTime.Property property9 = dateTime8.weekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime8.withWeekOfWeekyear((int) '4');
        org.joda.time.TimeOfDay timeOfDay12 = dateTime11.toTimeOfDay();
        int[] intArray14 = iSOChronology4.get((org.joda.time.ReadablePartial) timeOfDay12, 3600000L);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology4.millisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(readableInterval7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(timeOfDay12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.halfdays();
        org.joda.time.DurationField durationField6 = iSOChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.era();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology4.year();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.era();
        java.lang.String str6 = iSOChronology4.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology7.days();
        boolean boolean9 = iSOChronology4.equals((java.lang.Object) durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ISOChronology[UTC]" + "'", str6.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test211");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfHour(166, (int) (byte) 10);
//        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatterBuilder3.toPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(166, (int) (byte) 10);
//        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatterBuilder8.toPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        boolean boolean11 = dateTimeFormatter10.isParser();
//        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter10.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        boolean boolean14 = dateTimeFormatter13.isParser();
//        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter13.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray18 = new org.joda.time.format.DateTimeParser[] { dateTimeParser12, dateTimeParser15, dateTimeParser17 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder3.append(dateTimePrinter9, dateTimeParserArray18);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendMillisOfSecond(24);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendDayOfMonth((int) '4');
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField26 = gregorianChronology25.millis();
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology25.halfdayOfDay();
//        org.joda.time.ReadableInterval readableInterval28 = null;
//        org.joda.time.ReadableInterval readableInterval29 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval28);
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) readableInterval28);
//        org.joda.time.DateTime.Property property31 = dateTime30.weekOfWeekyear();
//        org.joda.time.DateTime dateTime33 = dateTime30.withWeekOfWeekyear((int) '4');
//        java.util.TimeZone timeZone34 = null;
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forTimeZone(timeZone34);
//        org.joda.time.DateTime dateTime36 = dateTime33.withZoneRetainFields(dateTimeZone35);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone37 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
//        long long39 = cachedDateTimeZone37.nextTransition((long) (short) 0);
//        org.joda.time.Chronology chronology40 = gregorianChronology25.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone37);
//        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology25.dayOfWeek();
//        java.util.TimeZone timeZone42 = null;
//        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.forTimeZone(timeZone42);
//        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now(dateTimeZone43);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval46 = null;
//        org.joda.time.ReadableInterval readableInterval47 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval46);
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((java.lang.Object) readableInterval46);
//        org.joda.time.DateTime.Property property49 = dateTime48.weekOfWeekyear();
//        org.joda.time.DateTime dateTime51 = dateTime48.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay52 = dateTime51.toTimeOfDay();
//        java.lang.String str53 = dateTimeFormatter45.print((org.joda.time.ReadablePartial) timeOfDay52);
//        org.joda.time.DateTime dateTime54 = dateTime44.withFields((org.joda.time.ReadablePartial) timeOfDay52);
//        org.joda.time.DateTime dateTime56 = dateTime44.withEra(0);
//        org.joda.time.DateTime.Property property57 = dateTime56.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType58 = property57.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField60 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, dateTimeFieldType58, 377);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder22.appendFraction(dateTimeFieldType58, 1, 14);
//        try {
//            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder3.appendSignedDecimal(dateTimeFieldType58, (-100), 52);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimePrinter4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimePrinter9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(dateTimeParser12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTimeParser15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTimeParser17);
//        org.junit.Assert.assertNotNull(dateTimeParserArray18);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(readableInterval29);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 9972000000L + "'", long39 == 9972000000L);
//        org.junit.Assert.assertNotNull(chronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTimeFormatter45);
//        org.junit.Assert.assertNotNull(readableInterval47);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(timeOfDay52);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "����-��-��T14:32:16.960" + "'", str53.equals("����-��-��T14:32:16.960"));
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(dateTimeFieldType58);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
//    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test212");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        java.lang.String str29 = unsupportedDateTimeField28.getName();
//        org.joda.time.DurationField durationField30 = unsupportedDateTimeField28.getDurationField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology32);
//        org.joda.time.DateTimeZone dateTimeZone34 = gregorianChronology32.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone34);
//        org.joda.time.DurationField durationField36 = iSOChronology35.hours();
//        org.joda.time.ReadableInterval readableInterval37 = null;
//        org.joda.time.ReadableInterval readableInterval38 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval37);
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((java.lang.Object) readableInterval37);
//        org.joda.time.DateTime.Property property40 = dateTime39.weekOfWeekyear();
//        org.joda.time.DateTime dateTime42 = dateTime39.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay43 = dateTime42.toTimeOfDay();
//        int[] intArray45 = iSOChronology35.get((org.joda.time.ReadablePartial) timeOfDay43, 3600000L);
//        java.util.Locale locale47 = null;
//        try {
//            java.lang.String str48 = unsupportedDateTimeField28.getAsShortText((org.joda.time.ReadablePartial) timeOfDay43, 52333813, locale47);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:17.019" + "'", str11.equals("����-��-��T14:32:17.019"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "weekyear" + "'", str29.equals("weekyear"));
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(gregorianChronology32);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertNotNull(durationField36);
//        org.junit.Assert.assertNotNull(readableInterval38);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(timeOfDay43);
//        org.junit.Assert.assertNotNull(intArray45);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2019);
        long long2 = dateTime1.getMillis();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(52263, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendYearOfEra(100, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMinuteOfHour(52263);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMillisOfSecond(6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendTwoDigitWeekyear((-100), false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.minus(readableDuration4);
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.ReadableInterval readableInterval7 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) readableInterval6);
        org.joda.time.DateTime.Property property9 = dateTime8.weekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime8.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
        org.joda.time.DateTime dateTime14 = dateTime11.withZoneRetainFields(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = dateTime2.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime17 = dateTime2.plusHours((int) '4');
        java.util.Locale locale19 = null;
        try {
            java.lang.String str20 = dateTime17.toString("����-��-��T14:31:02.082", locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(readableInterval7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("weekOfWeekyear", (java.lang.Number) 1L, (java.lang.Number) (byte) 10, number3);
        java.lang.Number number5 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.Number number9 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException("weekOfWeekyear", (java.lang.Number) 1L, (java.lang.Number) (byte) 10, number9);
        java.lang.Number number11 = illegalFieldValueException10.getIllegalNumberValue();
        java.lang.String str12 = illegalFieldValueException10.getIllegalStringValue();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException10);
        org.joda.time.DurationFieldType durationFieldType14 = illegalFieldValueException10.getDurationFieldType();
        org.joda.time.DurationFieldType durationFieldType15 = illegalFieldValueException10.getDurationFieldType();
        java.lang.Number number19 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException("weekOfWeekyear", (java.lang.Number) 1L, (java.lang.Number) (byte) 10, number19);
        java.lang.Number number21 = illegalFieldValueException20.getIllegalNumberValue();
        java.lang.String str22 = illegalFieldValueException20.getIllegalStringValue();
        illegalFieldValueException10.addSuppressed((java.lang.Throwable) illegalFieldValueException20);
        java.lang.String str24 = illegalFieldValueException10.toString();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1L + "'", number5.equals(1L));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 1L + "'", number11.equals(1L));
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(durationFieldType14);
        org.junit.Assert.assertNull(durationFieldType15);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1L + "'", number21.equals(1L));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 1 for weekOfWeekyear must not be smaller than 10" + "'", str24.equals("org.joda.time.IllegalFieldValueException: Value 1 for weekOfWeekyear must not be smaller than 10"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTime.Property property8 = dateTime6.millisOfDay();
        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
        int int10 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property11 = dateTime6.centuryOfEra();
        org.joda.time.DateTime dateTime12 = property11.roundHalfFloorCopy();
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.withDurationAdded(readableDuration13, 292278993);
        boolean boolean17 = dateTime15.isEqual(52275313L);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(readableInterval5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfDay();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.plus(readableDuration5);
        org.joda.time.LocalDate localDate7 = dateTime2.toLocalDate();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test220");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withOffsetParsed();
//        org.joda.time.ReadableInterval readableInterval3 = null;
//        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) readableInterval3);
//        org.joda.time.MutableDateTime mutableDateTime6 = dateTime5.toMutableDateTime();
//        org.joda.time.DateTime.Property property7 = dateTime5.secondOfMinute();
//        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime10 = dateTime5.toLocalDateTime();
//        java.lang.String str11 = dateTimeFormatter2.print((org.joda.time.ReadablePartial) localDateTime10);
//        long long13 = iSOChronology0.set((org.joda.time.ReadablePartial) localDateTime10, (long) 57600);
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology0.dayOfWeek();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(readableInterval4);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(localDateTime10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019-W24" + "'", str11.equals("2019-W24"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560609137276L + "'", long13 == 1560609137276L);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 1560609095972L, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test222");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
//        org.joda.time.MutableDateTime mutableDateTime6 = dateTime2.toMutableDateTimeISO();
//        java.util.Locale locale7 = null;
//        java.util.Calendar calendar8 = dateTime2.toCalendar(locale7);
//        int int9 = dateTime2.getMinuteOfDay();
//        org.joda.time.DateTime dateTime11 = dateTime2.plusHours(0);
//        org.joda.time.DateTime dateTime13 = dateTime11.withMillisOfDay(52303);
//        org.joda.time.DateTime.Property property14 = dateTime11.dayOfMonth();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(calendar8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 872 + "'", int9 == 872);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(337452L);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '#');
        long long12 = offsetDateTimeField5.add((long) 365, (long) (short) 10);
        int int13 = offsetDateTimeField5.getMaximumValue();
        long long16 = offsetDateTimeField5.addWrapField(0L, 52313);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 36000365L + "'", long12 == 36000365L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 377 + "'", int13 == 377);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 18000000L + "'", long16 == 18000000L);
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test226");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        long long31 = unsupportedDateTimeField28.add((long) 52274482, (long) 13);
//        org.joda.time.DurationField durationField32 = unsupportedDateTimeField28.getDurationField();
//        int int35 = unsupportedDateTimeField28.getDifference(96L, 1577572260761L);
//        boolean boolean36 = unsupportedDateTimeField28.isLenient();
//        try {
//            long long39 = unsupportedDateTimeField28.addWrapField(28800365L, 52273);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:17.483" + "'", str11.equals("����-��-��T14:32:17.483"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 7914674482L + "'", long31 == 7914674482L);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-2608) + "'", int35 == (-2608));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        java.lang.String str5 = iSOChronology4.toString();
        org.joda.time.Chronology chronology6 = iSOChronology4.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[UTC]" + "'", str5.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(1);
        java.lang.String str2 = dateTimeZone1.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+01:00" + "'", str2.equals("+01:00"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMinuteOfDay(57600);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.append(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(52263, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendYearOfEra(100, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMinuteOfHour(52263);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMillisOfSecond(6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendTwoDigitWeekyear(52258, true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test231");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        java.lang.String str29 = unsupportedDateTimeField28.getName();
//        long long32 = unsupportedDateTimeField28.getDifferenceAsLong(3600000L, 0L);
//        org.joda.time.ReadablePartial readablePartial33 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology36);
//        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology36.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField(dateTimeField38, 365);
//        org.joda.time.ReadableInterval readableInterval41 = null;
//        org.joda.time.ReadableInterval readableInterval42 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval41);
//        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((java.lang.Object) readableInterval41);
//        org.joda.time.YearMonthDay yearMonthDay44 = dateTime43.toYearMonthDay();
//        int[] intArray45 = new int[] {};
//        int int46 = offsetDateTimeField40.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay44, intArray45);
//        try {
//            int[] intArray48 = unsupportedDateTimeField28.add(readablePartial33, 52, intArray45, 365);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:17.587" + "'", str11.equals("����-��-��T14:32:17.587"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "weekyear" + "'", str29.equals("weekyear"));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(readableInterval42);
//        org.junit.Assert.assertNotNull(yearMonthDay44);
//        org.junit.Assert.assertNotNull(intArray45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 366 + "'", int46 == 366);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter0.getParser();
        java.lang.Integer int3 = dateTimeFormatter0.getPivotYear();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTime();
        org.joda.time.DateTime.Property property8 = dateTime6.secondOfMinute();
        org.joda.time.DateTime dateTime10 = dateTime6.plusMillis((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime10.minusMonths(52274482);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime14 = dateTime10.toMutableDateTime(dateTimeZone13);
        int int17 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime14, "", 292278993);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNull(int3);
        org.junit.Assert.assertNotNull(readableInterval5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-292278994) + "'", int17 == (-292278994));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(99);
        java.io.Writer writer3 = null;
        try {
            dateTimeFormatter0.printTo(writer3, (-58989658021997L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatterBuilder3.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatterBuilder8.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean11 = dateTimeFormatter10.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean14 = dateTimeFormatter13.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter13.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray18 = new org.joda.time.format.DateTimeParser[] { dateTimeParser12, dateTimeParser15, dateTimeParser17 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder3.append(dateTimePrinter9, dateTimeParserArray18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder3.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendClockhourOfDay(52275274);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder20.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder24.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter28 = dateTimeFormatterBuilder27.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser30 = dateTimeFormatter29.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser32 = dateTimeFormatter31.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder33.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter37 = dateTimeFormatterBuilder36.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder38.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter42 = dateTimeFormatterBuilder41.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean44 = dateTimeFormatter43.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser45 = dateTimeFormatter43.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean47 = dateTimeFormatter46.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser48 = dateTimeFormatter46.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser50 = dateTimeFormatter49.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray51 = new org.joda.time.format.DateTimeParser[] { dateTimeParser45, dateTimeParser48, dateTimeParser50 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder36.append(dateTimePrinter42, dateTimeParserArray51);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser54 = dateTimeFormatter53.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter55 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter42, dateTimeParser54);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder56.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter60 = dateTimeFormatterBuilder59.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder61.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter65 = dateTimeFormatterBuilder64.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter66 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean67 = dateTimeFormatter66.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser68 = dateTimeFormatter66.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter69 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean70 = dateTimeFormatter69.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser71 = dateTimeFormatter69.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter72 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser73 = dateTimeFormatter72.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray74 = new org.joda.time.format.DateTimeParser[] { dateTimeParser68, dateTimeParser71, dateTimeParser73 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder75 = dateTimeFormatterBuilder59.append(dateTimePrinter65, dateTimeParserArray74);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter76 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser77 = dateTimeFormatter76.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter78 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter65, dateTimeParser77);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter79 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser80 = dateTimeFormatter79.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray81 = new org.joda.time.format.DateTimeParser[] { dateTimeParser30, dateTimeParser32, dateTimeParser54, dateTimeParser77, dateTimeParser80 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder82 = dateTimeFormatterBuilder23.append(dateTimePrinter28, dateTimeParserArray81);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeParserArray18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimePrinter28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTimeParser30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeParser32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimePrinter37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimePrinter42);
        org.junit.Assert.assertNotNull(dateTimeFormatter43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(dateTimeParser45);
        org.junit.Assert.assertNotNull(dateTimeFormatter46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(dateTimeParser48);
        org.junit.Assert.assertNotNull(dateTimeFormatter49);
        org.junit.Assert.assertNotNull(dateTimeParser50);
        org.junit.Assert.assertNotNull(dateTimeParserArray51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertNotNull(dateTimeFormatter53);
        org.junit.Assert.assertNotNull(dateTimeParser54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
        org.junit.Assert.assertNotNull(dateTimePrinter60);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertNotNull(dateTimePrinter65);
        org.junit.Assert.assertNotNull(dateTimeFormatter66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(dateTimeParser68);
        org.junit.Assert.assertNotNull(dateTimeFormatter69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNotNull(dateTimeParser71);
        org.junit.Assert.assertNotNull(dateTimeFormatter72);
        org.junit.Assert.assertNotNull(dateTimeParser73);
        org.junit.Assert.assertNotNull(dateTimeParserArray74);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder75);
        org.junit.Assert.assertNotNull(dateTimeFormatter76);
        org.junit.Assert.assertNotNull(dateTimeParser77);
        org.junit.Assert.assertNotNull(dateTimeFormatter79);
        org.junit.Assert.assertNotNull(dateTimeParser80);
        org.junit.Assert.assertNotNull(dateTimeParserArray81);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder82);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test235");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        org.joda.time.DateTime dateTime8 = dateTime5.withZoneRetainFields(dateTimeZone7);
//        org.joda.time.DateTime dateTime11 = dateTime5.withDurationAdded((long) 100, 0);
//        org.joda.time.DateTime dateTime13 = dateTime5.minusMinutes(4);
//        int int14 = dateTime5.getCenturyOfEra();
//        int int15 = dateTime5.getMillisOfDay();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 20 + "'", int14 == 20);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 52338238 + "'", int15 == 52338238);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(57600, 'a', 8, 0, (int) (byte) 0, true, (int) (short) 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder8.setFixedSavings("", 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder8.setStandardOffset(1);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTimeZoneBuilder8.toDateTimeZone("����-��-��T14:31:23.185", false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
        org.junit.Assert.assertNotNull(dateTimeZone16);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.DateTime dateTime13 = dateTime10.withZoneRetainFields(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        long long16 = cachedDateTimeZone14.nextTransition((long) (short) 0);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
        java.lang.String str18 = zonedChronology17.toString();
        org.joda.time.DurationField durationField19 = zonedChronology17.hours();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(readableInterval6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9972000000L + "'", long16 == 9972000000L);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]" + "'", str18.equals("ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(durationField19);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test238");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
//        int int6 = offsetDateTimeField5.getMaximumValue();
//        long long8 = offsetDateTimeField5.roundHalfFloor((long) (byte) 10);
//        long long10 = offsetDateTimeField5.roundFloor((long) 365);
//        long long12 = offsetDateTimeField5.roundCeiling(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField14 = gregorianChronology13.millis();
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.halfdayOfDay();
//        org.joda.time.ReadableInterval readableInterval16 = null;
//        org.joda.time.ReadableInterval readableInterval17 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval16);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) readableInterval16);
//        org.joda.time.DateTime.Property property19 = dateTime18.weekOfWeekyear();
//        org.joda.time.DateTime dateTime21 = dateTime18.withWeekOfWeekyear((int) '4');
//        java.util.TimeZone timeZone22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
//        org.joda.time.DateTime dateTime24 = dateTime21.withZoneRetainFields(dateTimeZone23);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone25 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone23);
//        long long27 = cachedDateTimeZone25.nextTransition((long) (short) 0);
//        org.joda.time.Chronology chronology28 = gregorianChronology13.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone25);
//        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology13.dayOfWeek();
//        java.util.TimeZone timeZone30 = null;
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forTimeZone(timeZone30);
//        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now(dateTimeZone31);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval34 = null;
//        org.joda.time.ReadableInterval readableInterval35 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval34);
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((java.lang.Object) readableInterval34);
//        org.joda.time.DateTime.Property property37 = dateTime36.weekOfWeekyear();
//        org.joda.time.DateTime dateTime39 = dateTime36.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay40 = dateTime39.toTimeOfDay();
//        java.lang.String str41 = dateTimeFormatter33.print((org.joda.time.ReadablePartial) timeOfDay40);
//        org.joda.time.DateTime dateTime42 = dateTime32.withFields((org.joda.time.ReadablePartial) timeOfDay40);
//        org.joda.time.DateTime dateTime44 = dateTime32.withEra(0);
//        org.joda.time.DateTime.Property property45 = dateTime44.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property45.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, dateTimeFieldType46, 377);
//        try {
//            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField49 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType46);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 377 + "'", int6 == 377);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(readableInterval17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 9972000000L + "'", long27 == 9972000000L);
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTimeFormatter33);
//        org.junit.Assert.assertNotNull(readableInterval35);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(timeOfDay40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "����-��-��T14:32:18.457" + "'", str41.equals("����-��-��T14:32:18.457"));
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTimeFieldType46);
//    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test239");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        long long31 = unsupportedDateTimeField28.add((long) 52274482, (long) 13);
//        org.joda.time.DurationField durationField32 = unsupportedDateTimeField28.getDurationField();
//        int int35 = unsupportedDateTimeField28.getDifference(96L, 1577572260761L);
//        boolean boolean36 = unsupportedDateTimeField28.isSupported();
//        boolean boolean37 = unsupportedDateTimeField28.isSupported();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:18.507" + "'", str11.equals("����-��-��T14:32:18.507"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 7914674482L + "'", long31 == 7914674482L);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-2608) + "'", int35 == (-2608));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "weekOfWeekyear", 24, (-870));
        long long6 = fixedDateTimeZone4.nextTransition((long) 2019);
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        org.joda.time.ReadableInstant readableInstant8 = null;
        int int9 = fixedDateTimeZone4.getOffset(readableInstant8);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 365);
        int int17 = offsetDateTimeField15.getMinimumValue((long) 19);
        org.joda.time.DurationField durationField18 = offsetDateTimeField15.getDurationField();
        boolean boolean19 = fixedDateTimeZone4.equals((java.lang.Object) offsetDateTimeField15);
        int int21 = offsetDateTimeField15.getLeapAmount((long) (short) 0);
        long long23 = offsetDateTimeField15.roundHalfEven(0L);
        java.lang.String str25 = offsetDateTimeField15.getAsText(2019L);
        java.util.Locale locale26 = null;
        int int27 = offsetDateTimeField15.getMaximumShortTextLength(locale26);
        int int29 = offsetDateTimeField15.getLeapAmount(1560634263199L);
        long long32 = offsetDateTimeField15.add((long) 12, (long) 52314);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 366 + "'", int17 == 366);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "377" + "'", str25.equals("377"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 188330400012L + "'", long32 == 188330400012L);
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test241");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        java.lang.String str29 = unsupportedDateTimeField28.getName();
//        org.joda.time.DurationField durationField30 = unsupportedDateTimeField28.getDurationField();
//        org.joda.time.ReadableInterval readableInterval31 = null;
//        org.joda.time.ReadableInterval readableInterval32 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval31);
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((java.lang.Object) readableInterval31);
//        org.joda.time.MutableDateTime mutableDateTime34 = dateTime33.toMutableDateTime();
//        org.joda.time.DateTime.Property property35 = dateTime33.secondOfMinute();
//        org.joda.time.DateTime dateTime37 = dateTime33.withMonthOfYear((int) (byte) 1);
//        org.joda.time.LocalDateTime localDateTime38 = dateTime33.toLocalDateTime();
//        int[] intArray39 = null;
//        try {
//            int int40 = unsupportedDateTimeField28.getMaximumValue((org.joda.time.ReadablePartial) localDateTime38, intArray39);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:18.759" + "'", str11.equals("����-��-��T14:32:18.759"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "weekyear" + "'", str29.equals("weekyear"));
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(readableInterval32);
//        org.junit.Assert.assertNotNull(mutableDateTime34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(localDateTime38);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.DateTime dateTime13 = dateTime10.withZoneRetainFields(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        long long16 = cachedDateTimeZone14.nextTransition((long) (short) 0);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
        org.joda.time.Chronology chronology18 = zonedChronology17.withUTC();
        org.joda.time.Chronology chronology19 = zonedChronology17.withUTC();
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology17);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(readableInterval6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9972000000L + "'", long16 == 9972000000L);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.joda.time.DurationField durationField4 = gregorianChronology0.millis();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
        boolean boolean8 = offsetDateTimeField5.isLenient();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
        long long10 = offsetDateTimeField5.getDifferenceAsLong((long) (byte) -1, (long) 100);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField5.getMaximumTextLength(locale11);
        boolean boolean14 = offsetDateTimeField5.isLeap((-902L));
        java.lang.String str15 = offsetDateTimeField5.toString();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DateTimeField[clockhourOfHalfday]" + "'", str15.equals("DateTimeField[clockhourOfHalfday]"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int6 = offsetDateTimeField5.getMaximumValue();
        long long8 = offsetDateTimeField5.roundHalfFloor((long) (byte) 10);
        long long10 = offsetDateTimeField5.roundFloor((long) 365);
        org.joda.time.DurationField durationField11 = offsetDateTimeField5.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 377 + "'", int6 == 377);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNull(durationField11);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.ReadableInterval readableInterval7 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) readableInterval6);
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime8.toYearMonthDay();
        int[] intArray10 = new int[] {};
        int int11 = offsetDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay9, intArray10);
        long long13 = offsetDateTimeField5.roundHalfFloor(0L);
        long long16 = offsetDateTimeField5.add(0L, (-1L));
        long long19 = offsetDateTimeField5.getDifferenceAsLong((long) (byte) -1, (long) 57600000);
        int int21 = offsetDateTimeField5.get((long) 100);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(readableInterval7);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 366 + "'", int11 == 366);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-3600000L) + "'", long16 == (-3600000L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-16L) + "'", long19 == (-16L));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 377 + "'", int21 == 377);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test248");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime.Property property8 = dateTime6.millisOfDay();
//        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
//        int int10 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property11 = dateTime2.weekOfWeekyear();
//        boolean boolean12 = dateTime2.isAfterNow();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.ReadableInterval readableInterval7 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) readableInterval6);
        org.joda.time.DateTime.Property property9 = dateTime8.weekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime8.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
        org.joda.time.DateTime dateTime14 = dateTime11.withZoneRetainFields(dateTimeZone13);
        org.joda.time.DateTime dateTime17 = dateTime11.withDurationAdded((long) 100, 0);
        org.joda.time.DateTime dateTime19 = dateTime11.minusYears(1970);
        org.joda.time.ReadableInterval readableInterval20 = null;
        org.joda.time.ReadableInterval readableInterval21 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval20);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((java.lang.Object) readableInterval20);
        org.joda.time.MutableDateTime mutableDateTime23 = dateTime22.toMutableDateTime();
        org.joda.time.DateTime.Property property24 = dateTime22.secondOfMinute();
        org.joda.time.DateTime dateTime26 = dateTime22.plusMillis((int) (byte) 10);
        org.joda.time.LocalDateTime localDateTime27 = dateTime22.toLocalDateTime();
        org.joda.time.DateTime dateTime28 = dateTime19.withFields((org.joda.time.ReadablePartial) localDateTime27);
        int int29 = offsetDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) localDateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(readableInterval7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(readableInterval21);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(localDateTime27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 366 + "'", int29 == 366);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        try {
            int[] intArray7 = gregorianChronology1.get(readablePeriod4, (long) 52288104, (long) 12775);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        org.joda.time.DateTime dateTime8 = dateTime5.withZoneRetainFields(dateTimeZone7);
        org.joda.time.DateTime dateTime11 = dateTime5.withDurationAdded((long) 100, 0);
        org.joda.time.DateTime dateTime13 = dateTime5.minusMinutes(4);
        int int14 = dateTime5.getCenturyOfEra();
        org.joda.time.DateTime dateTime17 = dateTime5.withDurationAdded((long) 52305574, 52303);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 20 + "'", int14 == 20);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
        org.joda.time.YearMonthDay yearMonthDay4 = dateTime3.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.toDateTime(chronology5);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(yearMonthDay4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test254");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTime dateTime17 = dateTime14.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime19 = dateTime17.plusWeeks(6);
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology21);
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.minuteOfHour();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendTwoDigitWeekyear((int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder24.appendWeekyear(52263, (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder24.appendYearOfEra(100, (int) ' ');
//        java.util.TimeZone timeZone33 = null;
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forTimeZone(timeZone33);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone34);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval37 = null;
//        org.joda.time.ReadableInterval readableInterval38 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval37);
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((java.lang.Object) readableInterval37);
//        org.joda.time.DateTime.Property property40 = dateTime39.weekOfWeekyear();
//        org.joda.time.DateTime dateTime42 = dateTime39.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay43 = dateTime42.toTimeOfDay();
//        java.lang.String str44 = dateTimeFormatter36.print((org.joda.time.ReadablePartial) timeOfDay43);
//        org.joda.time.DateTime dateTime45 = dateTime35.withFields((org.joda.time.ReadablePartial) timeOfDay43);
//        org.joda.time.DateTime dateTime47 = dateTime35.withEra(0);
//        org.joda.time.DateTime.Property property48 = dateTime47.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = property48.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder24.appendFixedSignedDecimal(dateTimeFieldType49, 1970);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException53 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType49, "PST");
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, dateTimeFieldType49, 366, (int) (short) 10, 12775);
//        boolean boolean58 = dateTime17.isSupported(dateTimeFieldType49);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:20.962" + "'", str11.equals("����-��-��T14:32:20.962"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTimeFormatter36);
//        org.junit.Assert.assertNotNull(readableInterval38);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(timeOfDay43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "����-��-��T14:32:21.002" + "'", str44.equals("����-��-��T14:32:21.002"));
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertNotNull(dateTimeFieldType49);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.DateTime dateTime13 = dateTime10.withZoneRetainFields(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        long long16 = cachedDateTimeZone14.nextTransition((long) (short) 0);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology18.getZone();
        java.lang.String str20 = dateTimeZone19.getID();
        boolean boolean21 = zonedChronology17.equals((java.lang.Object) dateTimeZone19);
        org.joda.time.ReadableInterval readableInterval22 = null;
        org.joda.time.ReadableInterval readableInterval23 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval22);
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((java.lang.Object) readableInterval22);
        org.joda.time.DateTime.Property property25 = dateTime24.weekOfWeekyear();
        org.joda.time.DateTime dateTime27 = dateTime24.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forTimeZone(timeZone28);
        org.joda.time.DateTime dateTime30 = dateTime27.withZoneRetainFields(dateTimeZone29);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone31 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone29);
        long long33 = cachedDateTimeZone31.nextTransition((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone34 = cachedDateTimeZone31.getUncachedZone();
        boolean boolean35 = cachedDateTimeZone31.isFixed();
        org.joda.time.Chronology chronology36 = zonedChronology17.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone31);
        java.lang.String str37 = cachedDateTimeZone31.getID();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(readableInterval6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9972000000L + "'", long16 == 9972000000L);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(readableInterval23);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(cachedDateTimeZone31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9972000000L + "'", long33 == 9972000000L);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "America/Los_Angeles" + "'", str37.equals("America/Los_Angeles"));
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test256");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
//        int int6 = dateTime5.getWeekyear();
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.ReadableInterval readableInterval8 = null;
//        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) readableInterval8);
//        org.joda.time.DateTime.Property property11 = dateTime10.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = dateTime10.withWeekOfWeekyear((int) '4');
//        org.joda.time.MutableDateTime mutableDateTime14 = dateTime10.toMutableDateTimeISO();
//        java.util.Locale locale15 = null;
//        java.util.Calendar calendar16 = dateTime10.toCalendar(locale15);
//        int int17 = dateTime10.getMinuteOfDay();
//        boolean boolean18 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime19 = dateTime10.withTimeAtStartOfDay();
//        org.joda.time.DateTime.Property property20 = dateTime10.millisOfSecond();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577572341983L + "'", long7 == 1577572341983L);
//        org.junit.Assert.assertNotNull(readableInterval9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertNotNull(calendar16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 872 + "'", int17 == 872);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test257");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTime dateTime17 = dateTime14.plusMinutes((int) (byte) 10);
//        try {
//            org.joda.time.DateTime dateTime19 = dateTime17.withMinuteOfHour(292278993);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:22.133" + "'", str11.equals("����-��-��T14:32:22.133"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.minus(readableDuration4);
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.ReadableInterval readableInterval7 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) readableInterval6);
        org.joda.time.DateTime.Property property9 = dateTime8.weekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime8.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
        org.joda.time.DateTime dateTime14 = dateTime11.withZoneRetainFields(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = dateTime2.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime16 = dateTime2.toDateTime();
        java.lang.Class<?> wildcardClass17 = dateTime16.getClass();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(readableInterval7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendTimeZoneOffset("24", "Property[weekOfWeekyear]", true, (int) 'a', 166);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendSecondOfMinute(57600);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendSecondOfMinute(2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime2.withMonthOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTime dateTime8 = property7.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.DateTime dateTime13 = dateTime10.withZoneRetainFields(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        long long16 = cachedDateTimeZone14.nextTransition((long) (short) 0);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology18.getZone();
        java.lang.String str20 = dateTimeZone19.getID();
        boolean boolean21 = zonedChronology17.equals((java.lang.Object) dateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone22 = zonedChronology17.getZone();
        org.joda.time.DateTimeField dateTimeField23 = zonedChronology17.weekyearOfCentury();
        org.joda.time.ReadableInterval readableInterval24 = null;
        org.joda.time.ReadableInterval readableInterval25 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval24);
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((java.lang.Object) readableInterval24);
        org.joda.time.DateTime.Property property27 = dateTime26.weekOfWeekyear();
        org.joda.time.DateTime dateTime29 = dateTime26.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTime dateTime31 = dateTime26.withMinuteOfHour((int) (short) 10);
        boolean boolean32 = zonedChronology17.equals((java.lang.Object) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone33 = zonedChronology17.getZone();
        org.joda.time.DateTimeField dateTimeField34 = zonedChronology17.millisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(readableInterval6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9972000000L + "'", long16 == 9972000000L);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(readableInterval25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTimeField34);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test263");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime15 = dateTime2.withPeriodAdded(readablePeriod13, 292278993);
//        org.joda.time.DateTime dateTime17 = dateTime2.minusYears((int) '#');
//        java.util.TimeZone timeZone18 = null;
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now(dateTimeZone19);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval22 = null;
//        org.joda.time.ReadableInterval readableInterval23 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval22);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((java.lang.Object) readableInterval22);
//        org.joda.time.DateTime.Property property25 = dateTime24.weekOfWeekyear();
//        org.joda.time.DateTime dateTime27 = dateTime24.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay28 = dateTime27.toTimeOfDay();
//        java.lang.String str29 = dateTimeFormatter21.print((org.joda.time.ReadablePartial) timeOfDay28);
//        org.joda.time.DateTime dateTime30 = dateTime20.withFields((org.joda.time.ReadablePartial) timeOfDay28);
//        org.joda.time.DateTime dateTime32 = dateTime20.withEra(0);
//        org.joda.time.DateTime.Property property33 = dateTime32.weekyear();
//        org.joda.time.DateTime dateTime35 = dateTime32.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime37 = dateTime35.plusWeeks(6);
//        org.joda.time.DateTime.Property property38 = dateTime37.year();
//        org.joda.time.DateTime.Property property39 = dateTime37.millisOfDay();
//        org.joda.time.DateMidnight dateMidnight40 = dateTime37.toDateMidnight();
//        int int41 = dateTime17.compareTo((org.joda.time.ReadableInstant) dateTime37);
//        org.joda.time.DateTime dateTime43 = dateTime17.minusMinutes(52305574);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:22.681" + "'", str11.equals("����-��-��T14:32:22.681"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(readableInterval23);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(timeOfDay28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "����-��-��T14:32:22.712" + "'", str29.equals("����-��-��T14:32:22.712"));
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(dateMidnight40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertNotNull(dateTime43);
//    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test264");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
//        boolean boolean2 = dateTimeFormatter1.isPrinter();
//        boolean boolean3 = dateTimeFormatter1.isPrinter();
//        java.lang.Appendable appendable4 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateTime();
//        org.joda.time.ReadableInterval readableInterval6 = null;
//        org.joda.time.ReadableInterval readableInterval7 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval6);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) readableInterval6);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTime();
//        org.joda.time.DateTime.Property property10 = dateTime8.secondOfMinute();
//        org.joda.time.DateTime dateTime12 = dateTime8.plusMillis((int) (byte) 10);
//        int int13 = dateTime12.getDayOfYear();
//        org.joda.time.ReadableInterval readableInterval14 = null;
//        org.joda.time.ReadableInterval readableInterval15 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval14);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) readableInterval14);
//        org.joda.time.DateTime.Property property17 = dateTime16.weekOfWeekyear();
//        org.joda.time.DateTime dateTime19 = dateTime16.withWeekOfWeekyear((int) '4');
//        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime12, (org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter5.withChronology(chronology20);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter5.withOffsetParsed();
//        java.util.TimeZone timeZone23 = null;
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forTimeZone(timeZone23);
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now(dateTimeZone24);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval27 = null;
//        org.joda.time.ReadableInterval readableInterval28 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval27);
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((java.lang.Object) readableInterval27);
//        org.joda.time.DateTime.Property property30 = dateTime29.weekOfWeekyear();
//        org.joda.time.DateTime dateTime32 = dateTime29.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay33 = dateTime32.toTimeOfDay();
//        java.lang.String str34 = dateTimeFormatter26.print((org.joda.time.ReadablePartial) timeOfDay33);
//        org.joda.time.DateTime dateTime35 = dateTime25.withFields((org.joda.time.ReadablePartial) timeOfDay33);
//        java.lang.String str36 = dateTimeFormatter5.print((org.joda.time.ReadablePartial) timeOfDay33);
//        try {
//            dateTimeFormatter1.printTo(appendable4, (org.joda.time.ReadablePartial) timeOfDay33);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(readableInterval7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 166 + "'", int13 == 166);
//        org.junit.Assert.assertNotNull(readableInterval15);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(readableInterval28);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(timeOfDay33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "����-��-��T14:32:23.456" + "'", str34.equals("����-��-��T14:32:23.456"));
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "����-��-��T14:32:23.456" + "'", str36.equals("����-��-��T14:32:23.456"));
//    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test265");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime.Property property8 = dateTime6.millisOfDay();
//        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
//        int int10 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime6);
//        int int11 = dateTime2.getCenturyOfEra();
//        org.joda.time.DateTime dateTime13 = dateTime2.plusYears(57600);
//        int int14 = dateTime13.getMinuteOfHour();
//        org.joda.time.DateTime.Property property15 = dateTime13.weekyear();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 32 + "'", int14 == 32);
//        org.junit.Assert.assertNotNull(property15);
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
        org.joda.time.LocalDateTime localDateTime7 = dateTime2.toLocalDateTime();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = dateTime2.toDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMillis(166);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("yearOfCentury");
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendCenturyOfEra(10, 0);
        boolean boolean6 = dateTimeFormatterBuilder2.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.DateTime dateTime13 = dateTime10.withZoneRetainFields(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        long long16 = cachedDateTimeZone14.nextTransition((long) (short) 0);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
        org.joda.time.Chronology chronology18 = zonedChronology17.withUTC();
        org.joda.time.Chronology chronology19 = zonedChronology17.withUTC();
        java.lang.String str20 = zonedChronology17.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(readableInterval6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9972000000L + "'", long16 == 9972000000L);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]" + "'", str20.equals("ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]"));
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test270");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear((int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendWeekyear(52263, (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.appendYearOfEra(100, (int) ' ');
//        java.util.TimeZone timeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval17 = null;
//        org.joda.time.ReadableInterval readableInterval18 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval17);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) readableInterval17);
//        org.joda.time.DateTime.Property property20 = dateTime19.weekOfWeekyear();
//        org.joda.time.DateTime dateTime22 = dateTime19.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay23 = dateTime22.toTimeOfDay();
//        java.lang.String str24 = dateTimeFormatter16.print((org.joda.time.ReadablePartial) timeOfDay23);
//        org.joda.time.DateTime dateTime25 = dateTime15.withFields((org.joda.time.ReadablePartial) timeOfDay23);
//        org.joda.time.DateTime dateTime27 = dateTime15.withEra(0);
//        org.joda.time.DateTime.Property property28 = dateTime27.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType29, 1970);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, "PST");
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType29, 366, (int) (short) 10, 12775);
//        long long40 = offsetDateTimeField37.addWrapField((-1209599903L), 14);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(readableInterval18);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(timeOfDay23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "����-��-��T14:32:23.820" + "'", str24.equals("����-��-��T14:32:23.820"));
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-1208759903L) + "'", long40 == (-1208759903L));
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField6 = iSOChronology5.halfdays();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField7 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test272");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfHour(166, (int) (byte) 10);
//        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatterBuilder3.toPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(166, (int) (byte) 10);
//        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatterBuilder8.toPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        boolean boolean11 = dateTimeFormatter10.isParser();
//        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter10.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        boolean boolean14 = dateTimeFormatter13.isParser();
//        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter13.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray18 = new org.joda.time.format.DateTimeParser[] { dateTimeParser12, dateTimeParser15, dateTimeParser17 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder3.append(dateTimePrinter9, dateTimeParserArray18);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder3.appendLiteral("Pacific Standard Time");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder3.appendMinuteOfDay(9);
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology25);
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology25.minuteOfHour();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder28.appendTwoDigitWeekyear((int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder28.appendWeekyear(52263, (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder28.appendYearOfEra(100, (int) ' ');
//        java.util.TimeZone timeZone37 = null;
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forTimeZone(timeZone37);
//        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now(dateTimeZone38);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval41 = null;
//        org.joda.time.ReadableInterval readableInterval42 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval41);
//        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((java.lang.Object) readableInterval41);
//        org.joda.time.DateTime.Property property44 = dateTime43.weekOfWeekyear();
//        org.joda.time.DateTime dateTime46 = dateTime43.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay47 = dateTime46.toTimeOfDay();
//        java.lang.String str48 = dateTimeFormatter40.print((org.joda.time.ReadablePartial) timeOfDay47);
//        org.joda.time.DateTime dateTime49 = dateTime39.withFields((org.joda.time.ReadablePartial) timeOfDay47);
//        org.joda.time.DateTime dateTime51 = dateTime39.withEra(0);
//        org.joda.time.DateTime.Property property52 = dateTime51.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property52.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder28.appendFixedSignedDecimal(dateTimeFieldType53, 1970);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException57 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, "PST");
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField61 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, dateTimeFieldType53, 366, (int) (short) 10, 12775);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder23.appendSignedDecimal(dateTimeFieldType53, 52275274, 366);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter65 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
//        org.joda.time.format.DateTimeParser dateTimeParser66 = dateTimeFormatter65.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder23.appendOptional(dateTimeParser66);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimePrinter4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimePrinter9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(dateTimeParser12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTimeParser15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTimeParser17);
//        org.junit.Assert.assertNotNull(dateTimeParserArray18);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTimeFormatter40);
//        org.junit.Assert.assertNotNull(readableInterval42);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(timeOfDay47);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "����-��-��T14:32:24.019" + "'", str48.equals("����-��-��T14:32:24.019"));
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
//        org.junit.Assert.assertNotNull(dateTimeFormatter65);
//        org.junit.Assert.assertNotNull(dateTimeParser66);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(0, 20, 52327, 2031, 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2031 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
        long long10 = offsetDateTimeField5.getDifferenceAsLong((long) (byte) -1, (long) 100);
        org.joda.time.DurationField durationField11 = offsetDateTimeField5.getLeapDurationField();
        long long13 = offsetDateTimeField5.roundHalfEven(1577572278239L);
        long long15 = offsetDateTimeField5.roundCeiling(0L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577574000000L + "'", long13 == 1577574000000L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test275");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        long long31 = unsupportedDateTimeField28.add((long) 52274482, (long) 13);
//        org.joda.time.DurationField durationField32 = unsupportedDateTimeField28.getDurationField();
//        int int35 = unsupportedDateTimeField28.getDifference(96L, 1577572260761L);
//        boolean boolean36 = unsupportedDateTimeField28.isLenient();
//        try {
//            boolean boolean38 = unsupportedDateTimeField28.isLeap((long) 52);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:24.622" + "'", str11.equals("����-��-��T14:32:24.622"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 7914674482L + "'", long31 == 7914674482L);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-2608) + "'", int35 == (-2608));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        long long8 = offsetDateTimeField5.getDifferenceAsLong((long) (short) -1, (long) 1970);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsShortText(0L, locale10);
        java.util.Locale locale12 = null;
        int int13 = offsetDateTimeField5.getMaximumTextLength(locale12);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "377" + "'", str11.equals("377"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test277");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        long long31 = unsupportedDateTimeField28.add((long) 52274482, (long) 13);
//        java.util.TimeZone timeZone32 = null;
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forTimeZone(timeZone32);
//        java.lang.String str35 = dateTimeZone33.getName((long) '4');
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.ReadableInterval readableInterval37 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((java.lang.Object) readableInterval36);
//        org.joda.time.MutableDateTime mutableDateTime39 = dateTime38.toMutableDateTime();
//        org.joda.time.DateTime.Property property40 = dateTime38.secondOfMinute();
//        org.joda.time.DateTime dateTime42 = dateTime38.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime43 = dateTime38.toLocalDateTime();
//        boolean boolean44 = dateTimeZone33.isLocalDateTimeGap(localDateTime43);
//        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology47);
//        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology47.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField(dateTimeField49, 365);
//        int int53 = offsetDateTimeField51.getMinimumValue((long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField51, (int) '#');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter56 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter57 = dateTimeFormatter56.withOffsetParsed();
//        org.joda.time.ReadableInterval readableInterval58 = null;
//        org.joda.time.ReadableInterval readableInterval59 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval58);
//        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((java.lang.Object) readableInterval58);
//        org.joda.time.MutableDateTime mutableDateTime61 = dateTime60.toMutableDateTime();
//        org.joda.time.DateTime.Property property62 = dateTime60.secondOfMinute();
//        org.joda.time.DateTime dateTime64 = dateTime60.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime65 = dateTime60.toLocalDateTime();
//        java.lang.String str66 = dateTimeFormatter57.print((org.joda.time.ReadablePartial) localDateTime65);
//        org.joda.time.chrono.GregorianChronology gregorianChronology67 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone68 = gregorianChronology67.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter69 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter70 = dateTimeFormatter69.withOffsetParsed();
//        org.joda.time.ReadableInterval readableInterval71 = null;
//        org.joda.time.ReadableInterval readableInterval72 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval71);
//        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime((java.lang.Object) readableInterval71);
//        org.joda.time.MutableDateTime mutableDateTime74 = dateTime73.toMutableDateTime();
//        org.joda.time.DateTime.Property property75 = dateTime73.secondOfMinute();
//        org.joda.time.DateTime dateTime77 = dateTime73.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime78 = dateTime73.toLocalDateTime();
//        java.lang.String str79 = dateTimeFormatter70.print((org.joda.time.ReadablePartial) localDateTime78);
//        int[] intArray81 = gregorianChronology67.get((org.joda.time.ReadablePartial) localDateTime78, (-1209599903L));
//        int int82 = offsetDateTimeField51.getMinimumValue((org.joda.time.ReadablePartial) localDateTime65, intArray81);
//        try {
//            int[] intArray84 = unsupportedDateTimeField28.add((org.joda.time.ReadablePartial) localDateTime43, 52258, intArray81, (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:24.695" + "'", str11.equals("����-��-��T14:32:24.695"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 7914674482L + "'", long31 == 7914674482L);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Pacific Standard Time" + "'", str35.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(readableInterval37);
//        org.junit.Assert.assertNotNull(mutableDateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(localDateTime43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology47);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 366 + "'", int53 == 366);
//        org.junit.Assert.assertNotNull(dateTimeFormatter56);
//        org.junit.Assert.assertNotNull(dateTimeFormatter57);
//        org.junit.Assert.assertNotNull(readableInterval59);
//        org.junit.Assert.assertNotNull(mutableDateTime61);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(localDateTime65);
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "2019-W24" + "'", str66.equals("2019-W24"));
//        org.junit.Assert.assertNotNull(gregorianChronology67);
//        org.junit.Assert.assertNotNull(dateTimeZone68);
//        org.junit.Assert.assertNotNull(dateTimeFormatter69);
//        org.junit.Assert.assertNotNull(dateTimeFormatter70);
//        org.junit.Assert.assertNotNull(readableInterval72);
//        org.junit.Assert.assertNotNull(mutableDateTime74);
//        org.junit.Assert.assertNotNull(property75);
//        org.junit.Assert.assertNotNull(dateTime77);
//        org.junit.Assert.assertNotNull(localDateTime78);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "2019-W24" + "'", str79.equals("2019-W24"));
//        org.junit.Assert.assertNotNull(intArray81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 366 + "'", int82 == 366);
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(0L, dateTimeZone1);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test279");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        long long31 = unsupportedDateTimeField28.add((long) 52274482, (long) 13);
//        org.joda.time.DurationField durationField32 = unsupportedDateTimeField28.getDurationField();
//        try {
//            long long34 = unsupportedDateTimeField28.roundHalfFloor(0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:24.774" + "'", str11.equals("����-��-��T14:32:24.774"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 7914674482L + "'", long31 == 7914674482L);
//        org.junit.Assert.assertNotNull(durationField32);
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test281");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        org.joda.time.DateTime dateTime8 = dateTime5.withZoneRetainFields(dateTimeZone7);
//        org.joda.time.DateTime dateTime10 = dateTime8.plusSeconds(0);
//        long long11 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577572344810L + "'", long11 == 1577572344810L);
//    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test282");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.dayOfWeek();
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval12 = null;
//        org.joda.time.ReadableInterval readableInterval13 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval12);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) readableInterval12);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekOfWeekyear();
//        org.joda.time.DateTime dateTime17 = dateTime14.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay18 = dateTime17.toTimeOfDay();
//        java.lang.String str19 = dateTimeFormatter11.print((org.joda.time.ReadablePartial) timeOfDay18);
//        org.joda.time.DateTime dateTime20 = dateTime10.withFields((org.joda.time.ReadablePartial) timeOfDay18);
//        org.joda.time.DateTime dateTime22 = dateTime10.withEra(0);
//        org.joda.time.DateTime.Property property23 = dateTime22.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType24, 2000, 52258, 52258);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, "Property[weekOfWeekyear]");
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(readableInterval13);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(timeOfDay18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "����-��-��T14:32:24.854" + "'", str19.equals("����-��-��T14:32:24.854"));
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.year();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.millisOfDay();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.DateTimeField dateTimeField8 = property6.getField();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(52288104, 870, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        java.util.Locale locale6 = null;
        java.util.Calendar calendar7 = dateTime5.toCalendar(locale6);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) ' ');
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(calendar7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMinuteOfDay(57600);
        boolean boolean6 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime2.withMonthOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTime dateTime8 = property7.getDateTime();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test290");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        org.joda.time.DurationField durationField29 = unsupportedDateTimeField28.getLeapDurationField();
//        try {
//            long long31 = unsupportedDateTimeField28.remainder(10L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:25.421" + "'", str11.equals("����-��-��T14:32:25.421"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertNull(durationField29);
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatterBuilder3.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatterBuilder8.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean11 = dateTimeFormatter10.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean14 = dateTimeFormatter13.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter13.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray18 = new org.joda.time.format.DateTimeParser[] { dateTimeParser12, dateTimeParser15, dateTimeParser17 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder3.append(dateTimePrinter9, dateTimeParserArray18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder3.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendClockhourOfDay(52275274);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder20.appendDayOfWeekText();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder20.appendFixedSignedDecimal(dateTimeFieldType24, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeParserArray18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((-902L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-902L) + "'", long2 == (-902L));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendFractionOfHour(24, 52257628);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatterBuilder11.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter17 = dateTimeFormatterBuilder16.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean19 = dateTimeFormatter18.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean22 = dateTimeFormatter21.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter21.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser25 = dateTimeFormatter24.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray26 = new org.joda.time.format.DateTimeParser[] { dateTimeParser20, dateTimeParser23, dateTimeParser25 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder11.append(dateTimePrinter17, dateTimeParserArray26);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser29 = dateTimeFormatter28.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter17, dateTimeParser29);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder7.append(dateTimePrinter17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimePrinter12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimePrinter17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTimeParser20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(dateTimeParser23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTimeParser25);
        org.junit.Assert.assertNotNull(dateTimeParserArray26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTimeParser29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hour();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withLocale(locale2);
        try {
            org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("1969365T160000.365-0800", dateTimeFormatter3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969365T160000.365-0800\" is malformed at \"69365T160000.365-0800\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        int int4 = gregorianChronology0.getMinimumDaysInFirstWeek();
        long long8 = gregorianChronology0.add(9972000000L, 0L, 870);
        int int9 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9972000000L + "'", long8 == 9972000000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test297");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        long long31 = unsupportedDateTimeField28.add((long) 52274482, (long) 13);
//        org.joda.time.DurationField durationField32 = unsupportedDateTimeField28.getDurationField();
//        int int35 = unsupportedDateTimeField28.getDifference(96L, 1577572260761L);
//        int int38 = unsupportedDateTimeField28.getDifference((long) 57600, (long) 52305574);
//        try {
//            long long41 = unsupportedDateTimeField28.set((long) (byte) -1, 52257628);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:25.643" + "'", str11.equals("����-��-��T14:32:25.643"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 7914674482L + "'", long31 == 7914674482L);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-2608) + "'", int35 == (-2608));
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test298");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
//        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
//        int int7 = dateTime6.getDayOfYear();
//        org.joda.time.DateTime dateTime9 = dateTime6.minusSeconds(166);
//        org.joda.time.DateTime.Property property10 = dateTime6.secondOfMinute();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 166 + "'", int7 == 166);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test299");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfMonth((int) '4');
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField6 = gregorianChronology5.millis();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
//        org.joda.time.ReadableInterval readableInterval8 = null;
//        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) readableInterval8);
//        org.joda.time.DateTime.Property property11 = dateTime10.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = dateTime10.withWeekOfWeekyear((int) '4');
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        org.joda.time.DateTime dateTime16 = dateTime13.withZoneRetainFields(dateTimeZone15);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
//        long long19 = cachedDateTimeZone17.nextTransition((long) (short) 0);
//        org.joda.time.Chronology chronology20 = gregorianChronology5.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology5.dayOfWeek();
//        java.util.TimeZone timeZone22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now(dateTimeZone23);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval26 = null;
//        org.joda.time.ReadableInterval readableInterval27 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval26);
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) readableInterval26);
//        org.joda.time.DateTime.Property property29 = dateTime28.weekOfWeekyear();
//        org.joda.time.DateTime dateTime31 = dateTime28.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay32 = dateTime31.toTimeOfDay();
//        java.lang.String str33 = dateTimeFormatter25.print((org.joda.time.ReadablePartial) timeOfDay32);
//        org.joda.time.DateTime dateTime34 = dateTime24.withFields((org.joda.time.ReadablePartial) timeOfDay32);
//        org.joda.time.DateTime dateTime36 = dateTime24.withEra(0);
//        org.joda.time.DateTime.Property property37 = dateTime36.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property37.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, dateTimeFieldType38, 377);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder2.appendFraction(dateTimeFieldType38, 1, 14);
//        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField45 = gregorianChronology44.millis();
//        org.joda.time.Chronology chronology46 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology44);
//        org.joda.time.DurationField durationField47 = gregorianChronology44.months();
//        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology44.dayOfMonth();
//        org.joda.time.DurationField durationField49 = gregorianChronology44.seconds();
//        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField51 = gregorianChronology50.millis();
//        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology50.weekOfWeekyear();
//        org.joda.time.DurationField durationField53 = gregorianChronology50.hours();
//        int int54 = gregorianChronology50.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField55 = gregorianChronology50.days();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField56 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType38, durationField49, durationField55);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(readableInterval9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9972000000L + "'", long19 == 9972000000L);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(readableInterval27);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(timeOfDay32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "����-��-��T14:32:25.744" + "'", str33.equals("����-��-��T14:32:25.744"));
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(gregorianChronology44);
//        org.junit.Assert.assertNotNull(durationField45);
//        org.junit.Assert.assertNotNull(chronology46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(durationField49);
//        org.junit.Assert.assertNotNull(gregorianChronology50);
//        org.junit.Assert.assertNotNull(durationField51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(durationField53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 4 + "'", int54 == 4);
//        org.junit.Assert.assertNotNull(durationField55);
//    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test300");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
//        int int6 = offsetDateTimeField5.getMaximumValue();
//        int int8 = offsetDateTimeField5.getMaximumValue(96L);
//        java.util.TimeZone timeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval13 = null;
//        org.joda.time.ReadableInterval readableInterval14 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval13);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) readableInterval13);
//        org.joda.time.DateTime.Property property16 = dateTime15.weekOfWeekyear();
//        org.joda.time.DateTime dateTime18 = dateTime15.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay19 = dateTime18.toTimeOfDay();
//        java.lang.String str20 = dateTimeFormatter12.print((org.joda.time.ReadablePartial) timeOfDay19);
//        org.joda.time.DateTime dateTime21 = dateTime11.withFields((org.joda.time.ReadablePartial) timeOfDay19);
//        org.joda.time.DateTime dateTime23 = dateTime11.withEra(0);
//        org.joda.time.DateTime.Property property24 = dateTime23.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "377");
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType25, (-100), 52263, 57600);
//        int int32 = offsetDateTimeField5.getMinimumValue();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 377 + "'", int6 == 377);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 377 + "'", int8 == 377);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(readableInterval14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(timeOfDay19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "����-��-��T14:32:27.061" + "'", str20.equals("����-��-��T14:32:27.061"));
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 366 + "'", int32 == 366);
//    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test301");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
//        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
//        int int7 = dateTime6.getDayOfYear();
//        int int8 = dateTime6.getWeekOfWeekyear();
//        java.util.Date date9 = dateTime6.toDate();
//        org.joda.time.DateTime dateTime11 = dateTime6.plusHours(100);
//        org.joda.time.DateTime dateTime13 = dateTime11.plusHours(0);
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 166 + "'", int7 == 166);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = gregorianChronology0.equals((java.lang.Object) "Property[millisOfDay]");
        java.lang.Object obj3 = null;
        boolean boolean4 = gregorianChronology0.equals(obj3);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology5);
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test303");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
//        int int6 = dateTime2.getSecondOfDay();
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime2.minus(readableDuration7);
//        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
//        int int10 = dateTime2.getWeekyear();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52347 + "'", int6 == 52347);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560634347393L + "'", long9 == 1560634347393L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
        long long10 = offsetDateTimeField5.getDifferenceAsLong((long) (byte) -1, (long) 100);
        long long12 = offsetDateTimeField5.remainder((long) 466);
        int int14 = offsetDateTimeField5.getMinimumValue(0L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 466L + "'", long12 == 466L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 366 + "'", int14 == 366);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.halfdays();
        org.joda.time.DurationField durationField6 = iSOChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology4.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology10 = iSOChronology4.withZone(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(chronology10);
        org.joda.time.DateTime dateTime12 = dateTime11.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(292278993);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-292278993) + "'", int1 == (-292278993));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMonthOfYear(12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder5.appendTimeZoneOffset("", "����-��-��T14:32:08.911", false, (int) (short) 1, 52275274);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        org.joda.time.DateTime dateTime8 = dateTime5.withZoneRetainFields(dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        org.joda.time.DateTime.Property property10 = dateTime8.monthOfYear();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        org.joda.time.Instant instant6 = dateTime5.toInstant();
        int int7 = dateTime5.getSecondOfDay();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 86399 + "'", int7 == 86399);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "weekOfWeekyear", 24, (-870));
        java.lang.String str6 = fixedDateTimeZone4.getName((long) 52303);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.024" + "'", str6.equals("+00:00:00.024"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime2.minus(readablePeriod7);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test312");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
//        int int6 = offsetDateTimeField5.getMaximumValue();
//        int int8 = offsetDateTimeField5.getMaximumValue(96L);
//        int int11 = offsetDateTimeField5.getDifference((long) (short) 100, (-28799980L));
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology13);
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.minuteOfHour();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendTwoDigitWeekyear((int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder16.appendWeekyear(52263, (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder16.appendYearOfEra(100, (int) ' ');
//        java.util.TimeZone timeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forTimeZone(timeZone25);
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now(dateTimeZone26);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval29 = null;
//        org.joda.time.ReadableInterval readableInterval30 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval29);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((java.lang.Object) readableInterval29);
//        org.joda.time.DateTime.Property property32 = dateTime31.weekOfWeekyear();
//        org.joda.time.DateTime dateTime34 = dateTime31.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay35 = dateTime34.toTimeOfDay();
//        java.lang.String str36 = dateTimeFormatter28.print((org.joda.time.ReadablePartial) timeOfDay35);
//        org.joda.time.DateTime dateTime37 = dateTime27.withFields((org.joda.time.ReadablePartial) timeOfDay35);
//        org.joda.time.DateTime dateTime39 = dateTime27.withEra(0);
//        org.joda.time.DateTime.Property property40 = dateTime39.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = property40.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder16.appendFixedSignedDecimal(dateTimeFieldType41, 1970);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException45 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType41, "PST");
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, dateTimeFieldType41, 366, (int) (short) 10, 12775);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType41, (int) (byte) 1, 366, 52316909);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 377 + "'", int6 == 377);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 377 + "'", int8 == 377);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTimeFormatter28);
//        org.junit.Assert.assertNotNull(readableInterval30);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(timeOfDay35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "����-��-��T14:32:27.731" + "'", str36.equals("����-��-��T14:32:27.731"));
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test313");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
//        org.joda.time.ReadableInterval readableInterval2 = null;
//        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) readableInterval2);
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime4.toMutableDateTime();
//        org.joda.time.DateTime.Property property6 = dateTime4.secondOfMinute();
//        org.joda.time.DateTime dateTime8 = dateTime4.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime9 = dateTime4.toLocalDateTime();
//        java.lang.String str10 = dateTimeFormatter1.print((org.joda.time.ReadablePartial) localDateTime9);
//        java.lang.Appendable appendable11 = null;
//        try {
//            dateTimeFormatter1.printTo(appendable11, (long) 57600000);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(readableInterval3);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(localDateTime9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-W24" + "'", str10.equals("2019-W24"));
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
        org.joda.time.DateTime dateTime8 = dateTime6.plusMonths((int) (short) -1);
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.ReadableInterval readableInterval10 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) readableInterval9);
        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
        org.joda.time.DateTime dateTime14 = dateTime11.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone15);
        org.joda.time.DateTime dateTime17 = dateTime14.withZoneRetainFields(dateTimeZone16);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
        long long20 = cachedDateTimeZone18.nextTransition((long) (short) 0);
        long long22 = cachedDateTimeZone18.nextTransition((long) 10);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) cachedDateTimeZone18);
        long long25 = cachedDateTimeZone18.convertUTCToLocal((long) 20);
        org.joda.time.DateTime dateTime26 = dateTime8.withZoneRetainFields((org.joda.time.DateTimeZone) cachedDateTimeZone18);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(readableInterval10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9972000000L + "'", long20 == 9972000000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 9972000000L + "'", long22 == 9972000000L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-28799980L) + "'", long25 == (-28799980L));
        org.junit.Assert.assertNotNull(dateTime26);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        try {
            org.joda.time.DateTime dateTime4 = dateTime2.withHourOfDay(99);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 99 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        java.lang.String str6 = property4.toString();
        java.util.Locale locale7 = null;
        int int8 = property4.getMaximumTextLength(locale7);
        org.joda.time.DurationField durationField9 = property4.getRangeDurationField();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[millisOfDay]" + "'", str6.equals("Property[millisOfDay]"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 52297838);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(57600000, 0, 79, 466);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 236 + "'", int4 == 236);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(52263, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("����-��-��T14:31:50.782");
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test322");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime.Property property8 = dateTime6.millisOfDay();
//        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
//        int int10 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property11 = dateTime6.centuryOfEra();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime14 = dateTime6.withPeriodAdded(readablePeriod12, 366);
//        java.util.Locale locale15 = null;
//        java.util.Calendar calendar16 = dateTime6.toCalendar(locale15);
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(calendar16);
//    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test323");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval10 = null;
//        org.joda.time.ReadableInterval readableInterval11 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval10);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) readableInterval10);
//        org.joda.time.DateTime.Property property13 = dateTime12.weekOfWeekyear();
//        org.joda.time.DateTime dateTime15 = dateTime12.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay16 = dateTime15.toTimeOfDay();
//        java.lang.String str17 = dateTimeFormatter9.print((org.joda.time.ReadablePartial) timeOfDay16);
//        org.joda.time.DateTime dateTime18 = dateTime8.withFields((org.joda.time.ReadablePartial) timeOfDay16);
//        boolean boolean19 = cachedDateTimeZone5.equals((java.lang.Object) dateTime18);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 2019);
//        int int22 = cachedDateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime21);
//        long long25 = cachedDateTimeZone5.adjustOffset((long) 9, false);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(readableInterval11);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(timeOfDay16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "����-��-��T14:32:28.657" + "'", str17.equals("����-��-��T14:32:28.657"));
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9L + "'", long25 == 9L);
//    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test324");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
//        org.joda.time.DateTime dateTime6 = property4.addToCopy((-870));
//        int int7 = dateTime6.getSecondOfMinute();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 28 + "'", int7 == 28);
//    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.halfdays();
        org.joda.time.DurationField durationField6 = iSOChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.era();
        org.joda.time.DurationField durationField8 = iSOChronology4.minutes();
        org.joda.time.DurationField durationField9 = iSOChronology4.months();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("weekOfWeekyear", (java.lang.Number) 1L, (java.lang.Number) (byte) 10, number3);
        java.lang.Number number5 = illegalFieldValueException4.getIllegalNumberValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException4.getDateTimeFieldType();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1L + "'", number5.equals(1L));
        org.junit.Assert.assertNull(dateTimeFieldType6);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(0, 13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "weekOfWeekyear", 24, (-870));
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        long long9 = fixedDateTimeZone5.convertLocalToUTC(3135600960L, false);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3135600936L + "'", long9 == 3135600936L);
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test330");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
//        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
//        int int7 = dateTime6.getDayOfYear();
//        org.joda.time.ReadableInterval readableInterval8 = null;
//        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) readableInterval8);
//        org.joda.time.DateTime.Property property11 = dateTime10.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = dateTime10.withWeekOfWeekyear((int) '4');
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime6, (org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime16 = dateTime6.minusMinutes(365);
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 166 + "'", int7 == 166);
//        org.junit.Assert.assertNotNull(readableInterval9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test331");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        java.lang.Appendable appendable1 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withOffsetParsed();
//        org.joda.time.ReadableInterval readableInterval6 = null;
//        org.joda.time.ReadableInterval readableInterval7 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval6);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) readableInterval6);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTime();
//        org.joda.time.DateTime.Property property10 = dateTime8.secondOfMinute();
//        org.joda.time.DateTime dateTime12 = dateTime8.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime13 = dateTime8.toLocalDateTime();
//        java.lang.String str14 = dateTimeFormatter5.print((org.joda.time.ReadablePartial) localDateTime13);
//        int[] intArray16 = gregorianChronology2.get((org.joda.time.ReadablePartial) localDateTime13, (-1209599903L));
//        try {
//            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localDateTime13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(readableInterval7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(localDateTime13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019-W24" + "'", str14.equals("2019-W24"));
//        org.junit.Assert.assertNotNull(intArray16);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 14);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(52263, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendYearOfEra(100, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendLiteral("����-��-��T14:31:41.749");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test334");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        long long31 = unsupportedDateTimeField28.add((long) 52274482, (long) 13);
//        org.joda.time.DurationField durationField32 = unsupportedDateTimeField28.getDurationField();
//        int int35 = unsupportedDateTimeField28.getDifference(96L, 1577572260761L);
//        java.lang.String str36 = unsupportedDateTimeField28.getName();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:29.559" + "'", str11.equals("����-��-��T14:32:29.559"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 7914674482L + "'", long31 == 7914674482L);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-2608) + "'", int35 == (-2608));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "weekyear" + "'", str36.equals("weekyear"));
//    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test335");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        long long31 = unsupportedDateTimeField28.add((long) 52274482, (long) 13);
//        org.joda.time.DurationField durationField32 = unsupportedDateTimeField28.getDurationField();
//        try {
//            boolean boolean34 = unsupportedDateTimeField28.isLeap((long) 52275313);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:29.737" + "'", str11.equals("����-��-��T14:32:29.737"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 7914674482L + "'", long31 == 7914674482L);
//        org.junit.Assert.assertNotNull(durationField32);
//    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test336");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        long long31 = unsupportedDateTimeField28.add((long) 52274482, (long) 13);
//        org.joda.time.DurationField durationField32 = unsupportedDateTimeField28.getDurationField();
//        int int35 = unsupportedDateTimeField28.getDifference(96L, 1577572260761L);
//        int int38 = unsupportedDateTimeField28.getDifference((long) 57600, (long) 52305574);
//        try {
//            long long41 = unsupportedDateTimeField28.set((long) 10, "57");
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:29.783" + "'", str11.equals("����-��-��T14:32:29.783"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 7914674482L + "'", long31 == 7914674482L);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-2608) + "'", int35 == (-2608));
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
        org.joda.time.DurationField durationField5 = property4.getRangeDurationField();
        boolean boolean6 = property4.isLeap();
        org.joda.time.DateTime dateTime7 = property4.roundHalfCeilingCopy();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology9.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.DurationField durationField13 = iSOChronology12.halfdays();
        org.joda.time.DurationField durationField14 = iSOChronology12.weeks();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology12.yearOfCentury();
        org.joda.time.MutableDateTime mutableDateTime16 = dateTime7.toMutableDateTime((org.joda.time.Chronology) iSOChronology12);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.DateTime dateTime13 = dateTime10.withZoneRetainFields(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        long long16 = cachedDateTimeZone14.nextTransition((long) (short) 0);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
        java.lang.String str18 = zonedChronology17.toString();
        java.lang.String str19 = zonedChronology17.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        java.util.TimeZone timeZone22 = dateTimeZone21.toTimeZone();
        org.joda.time.Chronology chronology23 = zonedChronology17.withZone(dateTimeZone21);
        try {
            long long28 = zonedChronology17.getDateTimeMillis(52297838, 28, 872, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 28 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(readableInterval6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9972000000L + "'", long16 == 9972000000L);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]" + "'", str18.equals("ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]" + "'", str19.equals("ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(chronology23);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.halfdayOfDay();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) readableInterval3);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTime dateTime8 = dateTime5.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.DateTime dateTime11 = dateTime8.withZoneRetainFields(dateTimeZone10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
        long long14 = cachedDateTimeZone12.nextTransition((long) (short) 0);
        org.joda.time.Chronology chronology15 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone12);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology17);
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology17.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone19);
        org.joda.time.Chronology chronology22 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone21);
        java.lang.String str23 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone25 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField26 = gregorianChronology0.eras();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(readableInterval4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9972000000L + "'", long14 == 9972000000L);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "GregorianChronology[UTC]" + "'", str23.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(durationField26);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("weekOfWeekyear", (java.lang.Number) 1L, (java.lang.Number) (byte) 10, number3);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        java.lang.Number number6 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.DateTime dateTime13 = dateTime10.withZoneRetainFields(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        long long16 = cachedDateTimeZone14.nextTransition((long) (short) 0);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone18 = zonedChronology17.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(readableInterval6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9972000000L + "'", long16 == 9972000000L);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) -1, 0, (int) (byte) 0, 52901);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52901 + "'", int4 == 52901);
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test344");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType16, 1277500, 52347, (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1277500 for weekyear must be in the range [52347,100]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:30.486" + "'", str11.equals("����-��-��T14:32:30.486"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
        org.joda.time.DateTime dateTime5 = property4.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        int int4 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField5 = gregorianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.minuteOfDay();
        java.lang.String str8 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GregorianChronology[UTC]" + "'", str8.equals("GregorianChronology[UTC]"));
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test347");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
//        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '#');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withOffsetParsed();
//        org.joda.time.ReadableInterval readableInterval12 = null;
//        org.joda.time.ReadableInterval readableInterval13 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval12);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) readableInterval12);
//        org.joda.time.MutableDateTime mutableDateTime15 = dateTime14.toMutableDateTime();
//        org.joda.time.DateTime.Property property16 = dateTime14.secondOfMinute();
//        org.joda.time.DateTime dateTime18 = dateTime14.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime19 = dateTime14.toLocalDateTime();
//        java.lang.String str20 = dateTimeFormatter11.print((org.joda.time.ReadablePartial) localDateTime19);
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology21.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter23.withOffsetParsed();
//        org.joda.time.ReadableInterval readableInterval25 = null;
//        org.joda.time.ReadableInterval readableInterval26 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval25);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((java.lang.Object) readableInterval25);
//        org.joda.time.MutableDateTime mutableDateTime28 = dateTime27.toMutableDateTime();
//        org.joda.time.DateTime.Property property29 = dateTime27.secondOfMinute();
//        org.joda.time.DateTime dateTime31 = dateTime27.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime32 = dateTime27.toLocalDateTime();
//        java.lang.String str33 = dateTimeFormatter24.print((org.joda.time.ReadablePartial) localDateTime32);
//        int[] intArray35 = gregorianChronology21.get((org.joda.time.ReadablePartial) localDateTime32, (-1209599903L));
//        int int36 = offsetDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) localDateTime19, intArray35);
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = offsetDateTimeField5.getAsShortText((long) 0, locale38);
//        long long41 = offsetDateTimeField5.remainder((long) (byte) 100);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(readableInterval13);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(localDateTime19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019-W24" + "'", str20.equals("2019-W24"));
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertNotNull(readableInterval26);
//        org.junit.Assert.assertNotNull(mutableDateTime28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(localDateTime32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2019-W24" + "'", str33.equals("2019-W24"));
//        org.junit.Assert.assertNotNull(intArray35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 366 + "'", int36 == 366);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "377" + "'", str39.equals("377"));
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 100L + "'", long41 == 100L);
//    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test348");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        long long31 = unsupportedDateTimeField28.add((long) 52274482, (long) 13);
//        org.joda.time.DurationField durationField32 = unsupportedDateTimeField28.getDurationField();
//        int int35 = unsupportedDateTimeField28.getDifference(96L, 1577572260761L);
//        boolean boolean36 = unsupportedDateTimeField28.isSupported();
//        java.util.TimeZone timeZone37 = null;
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forTimeZone(timeZone37);
//        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now(dateTimeZone38);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval41 = null;
//        org.joda.time.ReadableInterval readableInterval42 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval41);
//        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((java.lang.Object) readableInterval41);
//        org.joda.time.DateTime.Property property44 = dateTime43.weekOfWeekyear();
//        org.joda.time.DateTime dateTime46 = dateTime43.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay47 = dateTime46.toTimeOfDay();
//        java.lang.String str48 = dateTimeFormatter40.print((org.joda.time.ReadablePartial) timeOfDay47);
//        org.joda.time.DateTime dateTime49 = dateTime39.withFields((org.joda.time.ReadablePartial) timeOfDay47);
//        org.joda.time.chrono.GregorianChronology gregorianChronology52 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology52);
//        org.joda.time.DateTimeZone dateTimeZone54 = gregorianChronology52.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology55 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone54);
//        org.joda.time.DurationField durationField56 = iSOChronology55.hours();
//        org.joda.time.ReadableInterval readableInterval57 = null;
//        org.joda.time.ReadableInterval readableInterval58 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval57);
//        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((java.lang.Object) readableInterval57);
//        org.joda.time.DateTime.Property property60 = dateTime59.weekOfWeekyear();
//        org.joda.time.DateTime dateTime62 = dateTime59.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay63 = dateTime62.toTimeOfDay();
//        int[] intArray65 = iSOChronology55.get((org.joda.time.ReadablePartial) timeOfDay63, 3600000L);
//        java.util.Locale locale67 = null;
//        try {
//            int[] intArray68 = unsupportedDateTimeField28.set((org.joda.time.ReadablePartial) timeOfDay47, 52275313, intArray65, "20", locale67);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:30.879" + "'", str11.equals("����-��-��T14:32:30.879"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 7914674482L + "'", long31 == 7914674482L);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-2608) + "'", int35 == (-2608));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTimeFormatter40);
//        org.junit.Assert.assertNotNull(readableInterval42);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(timeOfDay47);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "����-��-��T14:32:30.886" + "'", str48.equals("����-��-��T14:32:30.886"));
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(gregorianChronology52);
//        org.junit.Assert.assertNotNull(dateTimeZone54);
//        org.junit.Assert.assertNotNull(iSOChronology55);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(readableInterval58);
//        org.junit.Assert.assertNotNull(property60);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertNotNull(timeOfDay63);
//        org.junit.Assert.assertNotNull(intArray65);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test350");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTime dateTime17 = dateTime14.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime19 = dateTime17.plusWeeks(6);
//        org.joda.time.DateTime dateTime21 = dateTime17.withWeekyear(6);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        boolean boolean23 = dateTimeFormatter22.isParser();
//        org.joda.time.format.DateTimeParser dateTimeParser24 = dateTimeFormatter22.getParser();
//        org.joda.time.ReadableInterval readableInterval25 = null;
//        org.joda.time.ReadableInterval readableInterval26 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval25);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((java.lang.Object) readableInterval25);
//        org.joda.time.DateTime.Property property28 = dateTime27.weekOfWeekyear();
//        org.joda.time.DateTime dateTime30 = dateTime27.withWeekOfWeekyear((int) '4');
//        java.util.TimeZone timeZone31 = null;
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forTimeZone(timeZone31);
//        org.joda.time.DateTime dateTime33 = dateTime30.withZoneRetainFields(dateTimeZone32);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone34 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone32);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter22.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone34);
//        org.joda.time.DateTime dateTime36 = dateTime21.withZoneRetainFields((org.joda.time.DateTimeZone) cachedDateTimeZone34);
//        int int38 = cachedDateTimeZone34.getOffset((long) 32);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:30.957" + "'", str11.equals("����-��-��T14:32:30.957"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNotNull(dateTimeParser24);
//        org.junit.Assert.assertNotNull(readableInterval26);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone34);
//        org.junit.Assert.assertNotNull(dateTimeFormatter35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-28800000) + "'", int38 == (-28800000));
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((java.lang.Object) 364L);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks(52881764);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.DurationField durationField4 = gregorianChronology1.millis();
        org.joda.time.DurationField durationField5 = gregorianChronology1.minutes();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test353");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
//        org.joda.time.ReadableInterval readableInterval2 = null;
//        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) readableInterval2);
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime4.toMutableDateTime();
//        org.joda.time.DateTime.Property property6 = dateTime4.secondOfMinute();
//        org.joda.time.DateTime dateTime8 = dateTime4.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime9 = dateTime4.toLocalDateTime();
//        java.lang.String str10 = dateTimeFormatter1.print((org.joda.time.ReadablePartial) localDateTime9);
//        org.joda.time.format.DateTimePrinter dateTimePrinter11 = dateTimeFormatter1.getPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendTwoDigitWeekyear((int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder12.appendWeekyear(52263, (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendFractionOfHour(166, (int) (byte) 10);
//        org.joda.time.format.DateTimePrinter dateTimePrinter22 = dateTimeFormatterBuilder21.toPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder23.appendFractionOfHour(166, (int) (byte) 10);
//        org.joda.time.format.DateTimePrinter dateTimePrinter27 = dateTimeFormatterBuilder26.toPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder28.appendFractionOfHour(166, (int) (byte) 10);
//        org.joda.time.format.DateTimePrinter dateTimePrinter32 = dateTimeFormatterBuilder31.toPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        boolean boolean34 = dateTimeFormatter33.isParser();
//        org.joda.time.format.DateTimeParser dateTimeParser35 = dateTimeFormatter33.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        boolean boolean37 = dateTimeFormatter36.isParser();
//        org.joda.time.format.DateTimeParser dateTimeParser38 = dateTimeFormatter36.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        org.joda.time.format.DateTimeParser dateTimeParser40 = dateTimeFormatter39.getParser();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray41 = new org.joda.time.format.DateTimeParser[] { dateTimeParser35, dateTimeParser38, dateTimeParser40 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder26.append(dateTimePrinter32, dateTimeParserArray41);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        org.joda.time.format.DateTimeParser dateTimeParser44 = dateTimeFormatter43.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter32, dateTimeParser44);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder17.append(dateTimePrinter22, dateTimeParser44);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter47 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter11, dateTimeParser44);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(readableInterval3);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(localDateTime9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-W24" + "'", str10.equals("2019-W24"));
//        org.junit.Assert.assertNotNull(dateTimePrinter11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
//        org.junit.Assert.assertNotNull(dateTimePrinter22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(dateTimePrinter27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(dateTimePrinter32);
//        org.junit.Assert.assertNotNull(dateTimeFormatter33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertNotNull(dateTimeParser35);
//        org.junit.Assert.assertNotNull(dateTimeFormatter36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertNotNull(dateTimeParser38);
//        org.junit.Assert.assertNotNull(dateTimeFormatter39);
//        org.junit.Assert.assertNotNull(dateTimeParser40);
//        org.junit.Assert.assertNotNull(dateTimeParserArray41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(dateTimeFormatter43);
//        org.junit.Assert.assertNotNull(dateTimeParser44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
//    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter0.getParser();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) readableInterval3);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTime dateTime8 = dateTime5.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.DateTime dateTime11 = dateTime8.withZoneRetainFields(dateTimeZone10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone12);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) cachedDateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(readableInterval4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test355");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        java.lang.String str29 = unsupportedDateTimeField28.getName();
//        long long32 = unsupportedDateTimeField28.getDifferenceAsLong(3600000L, 0L);
//        org.joda.time.ReadableInterval readableInterval33 = null;
//        org.joda.time.ReadableInterval readableInterval34 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval33);
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((java.lang.Object) readableInterval33);
//        org.joda.time.DateTime.Property property36 = dateTime35.weekOfWeekyear();
//        java.util.Locale locale37 = null;
//        int int38 = property36.getMaximumTextLength(locale37);
//        int int39 = property36.get();
//        java.lang.String str40 = property36.toString();
//        java.util.Locale locale41 = null;
//        java.lang.String str42 = property36.getAsText(locale41);
//        org.joda.time.ReadableInterval readableInterval43 = null;
//        org.joda.time.ReadableInterval readableInterval44 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval43);
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((java.lang.Object) readableInterval43);
//        org.joda.time.DateTime.Property property46 = dateTime45.weekOfWeekyear();
//        java.lang.String str47 = property46.getName();
//        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone49 = gregorianChronology48.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter50 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = dateTimeFormatter50.withOffsetParsed();
//        org.joda.time.ReadableInterval readableInterval52 = null;
//        org.joda.time.ReadableInterval readableInterval53 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval52);
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((java.lang.Object) readableInterval52);
//        org.joda.time.MutableDateTime mutableDateTime55 = dateTime54.toMutableDateTime();
//        org.joda.time.DateTime.Property property56 = dateTime54.secondOfMinute();
//        org.joda.time.DateTime dateTime58 = dateTime54.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime59 = dateTime54.toLocalDateTime();
//        java.lang.String str60 = dateTimeFormatter51.print((org.joda.time.ReadablePartial) localDateTime59);
//        int[] intArray62 = gregorianChronology48.get((org.joda.time.ReadablePartial) localDateTime59, (-1209599903L));
//        int int63 = property46.compareTo((org.joda.time.ReadablePartial) localDateTime59);
//        int int64 = property36.compareTo((org.joda.time.ReadablePartial) localDateTime59);
//        java.util.Locale locale65 = null;
//        try {
//            java.lang.String str66 = unsupportedDateTimeField28.getAsShortText((org.joda.time.ReadablePartial) localDateTime59, locale65);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:32:31.760" + "'", str11.equals("����-��-��T14:32:31.760"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "weekyear" + "'", str29.equals("weekyear"));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//        org.junit.Assert.assertNotNull(readableInterval34);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2 + "'", int38 == 2);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 24 + "'", int39 == 24);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Property[weekOfWeekyear]" + "'", str40.equals("Property[weekOfWeekyear]"));
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "24" + "'", str42.equals("24"));
//        org.junit.Assert.assertNotNull(readableInterval44);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "weekOfWeekyear" + "'", str47.equals("weekOfWeekyear"));
//        org.junit.Assert.assertNotNull(gregorianChronology48);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertNotNull(dateTimeFormatter50);
//        org.junit.Assert.assertNotNull(dateTimeFormatter51);
//        org.junit.Assert.assertNotNull(readableInterval53);
//        org.junit.Assert.assertNotNull(mutableDateTime55);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(localDateTime59);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "2019-W24" + "'", str60.equals("2019-W24"));
//        org.junit.Assert.assertNotNull(intArray62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
//    }
//}

