import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.DurationField durationField2 = null;
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField3 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField1, durationField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean1 = dateTimeFormatter0.isParser();
        try {
            org.joda.time.MutableDateTime mutableDateTime3 = dateTimeFormatter0.parseMutableDateTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.io.Writer writer1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(writer1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        java.lang.Class<?> wildcardClass1 = dateTimeFormatter0.getClass();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-100) + "'", int1 == (-100));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        java.io.Writer writer1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(writer1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(10L, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9L + "'", long2 == 9L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant5);
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (byte) -1, (int) 'a', 0, (-100), (int) ' ', chronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        java.io.Writer writer1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(writer1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField2 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((-1L), 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9L + "'", long2 == 9L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        try {
            long long2 = dateTimeFormatter0.parseMillis("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime2.toMutableDateTimeISO();
        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime6.toMutableDateTime();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        org.joda.time.DateTime dateTime8 = dateTime5.withZoneRetainFields(dateTimeZone7);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, number1, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (short) -1, 870);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-870) + "'", int2 == (-870));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        java.lang.Appendable appendable1 = null;
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) readableInterval2);
        org.joda.time.DateTime.Property property5 = dateTime4.weekOfWeekyear();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(readableInterval3);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "weekOfWeekyear");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfDay();
        org.joda.time.DateTime.Property property5 = dateTime2.monthOfYear();
        try {
            org.joda.time.DateTime dateTime10 = dateTime2.withTime(0, 1, (-1), (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.io.Writer writer1 = null;
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) readableInterval2);
        org.joda.time.DateTime.Property property5 = dateTime4.weekOfWeekyear();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(readableInterval3);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.ReadableInterval readableInterval7 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) readableInterval6);
        org.joda.time.DateTime.Property property9 = dateTime8.weekOfWeekyear();
        org.joda.time.DateTime.Property property10 = dateTime8.millisOfDay();
        boolean boolean11 = dateTime2.isAfter((org.joda.time.ReadableInstant) dateTime8);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(readableInterval7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) -1, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        java.io.Writer writer1 = null;
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) readableInterval2);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime4.toMutableDateTime();
        org.joda.time.DateTime.Property property6 = dateTime4.secondOfMinute();
        org.joda.time.DateTime dateTime8 = dateTime4.plusMillis((int) (byte) 10);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(readableInterval3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        try {
            java.lang.String str2 = dateTimeFormatter0.print((long) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
        try {
            org.joda.time.DateTime dateTime6 = dateTime2.withDayOfMonth(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,28]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField2 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test047");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval1 = null;
//        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) readableInterval1);
//        org.joda.time.DateTime.Property property4 = dateTime3.weekOfWeekyear();
//        org.joda.time.DateTime dateTime6 = dateTime3.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay7 = dateTime6.toTimeOfDay();
//        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) timeOfDay7);
//        java.lang.StringBuffer stringBuffer9 = null;
//        org.joda.time.ReadableInterval readableInterval10 = null;
//        org.joda.time.ReadableInterval readableInterval11 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval10);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) readableInterval10);
//        org.joda.time.DateTime.Property property13 = dateTime12.weekOfWeekyear();
//        org.joda.time.DateTime dateTime15 = dateTime12.withWeekOfWeekyear((int) '4');
//        org.joda.time.MutableDateTime mutableDateTime16 = dateTime12.toMutableDateTimeISO();
//        try {
//            dateTimeFormatter0.printTo(stringBuffer9, (org.joda.time.ReadableInstant) dateTime12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(readableInterval2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(timeOfDay7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����-��-��T14:30:58.141" + "'", str8.equals("����-��-��T14:30:58.141"));
//        org.junit.Assert.assertNotNull(readableInterval11);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test048");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 9972000000L, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        org.joda.time.DateTime dateTime8 = dateTime5.withZoneRetainFields(dateTimeZone7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        long long11 = cachedDateTimeZone9.previousTransition((long) 52257628);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-5756400001L) + "'", long11 == (-5756400001L));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(10, (-100), (int) ' ', (int) ' ', (int) (short) 100, (int) (byte) 10, 1, dateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (short) 1, (java.lang.Number) 1.0f, (java.lang.Number) 9L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfDay();
        boolean boolean6 = dateTime2.isEqual((long) (-870));
        int int7 = dateTime2.getMonthOfYear();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        long long4 = durationField1.subtract(0L, (long) 24);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-24L) + "'", long4 == (-24L));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.hourOfDay();
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(100, 100, 0, 0, 0, (int) '#', (int) '#', (org.joda.time.Chronology) gregorianChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(100L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("Property[millisOfDay]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[millisOfDay]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 10, (java.lang.Number) (-1L), number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("weekOfWeekyear", (java.lang.Number) 1L, (java.lang.Number) (byte) 10, number3);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        org.junit.Assert.assertNull(dateTimeFieldType5);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        org.joda.time.DateTime dateTime8 = dateTime5.withZoneRetainFields(dateTimeZone7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        long long11 = cachedDateTimeZone9.nextTransition((long) (short) 0);
        long long13 = cachedDateTimeZone9.nextTransition((long) 10);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone9, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9972000000L + "'", long11 == 9972000000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9972000000L + "'", long13 == 9972000000L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        try {
            org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((java.lang.Object) 24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumShortTextLength(locale5);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test069");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval1 = null;
//        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) readableInterval1);
//        org.joda.time.DateTime.Property property4 = dateTime3.weekOfWeekyear();
//        org.joda.time.DateTime dateTime6 = dateTime3.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay7 = dateTime6.toTimeOfDay();
//        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) timeOfDay7);
//        java.util.Locale locale9 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withLocale(locale9);
//        java.lang.Appendable appendable11 = null;
//        org.joda.time.ReadableInterval readableInterval12 = null;
//        org.joda.time.ReadableInterval readableInterval13 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval12);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) readableInterval12);
//        org.joda.time.MutableDateTime mutableDateTime15 = dateTime14.toMutableDateTime();
//        org.joda.time.DateTime.Property property16 = dateTime14.secondOfMinute();
//        org.joda.time.DateTime dateTime18 = dateTime14.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime19 = dateTime14.toLocalDateTime();
//        try {
//            dateTimeFormatter10.printTo(appendable11, (org.joda.time.ReadablePartial) localDateTime19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(readableInterval2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(timeOfDay7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����-��-��T14:31:02.041" + "'", str8.equals("����-��-��T14:31:02.041"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(readableInterval13);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(localDateTime19);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "Pacific Standard Time");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("����-��-��T14:31:00.636", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"����-��-��T14:31:00.636/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test072");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
//        java.io.Writer writer1 = null;
//        org.joda.time.ReadableInterval readableInterval2 = null;
//        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) readableInterval2);
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime4.toMutableDateTime();
//        org.joda.time.DateTime.Property property6 = dateTime4.secondOfMinute();
//        org.joda.time.DateTime dateTime8 = dateTime4.plusMillis((int) (byte) 10);
//        int int9 = dateTime8.getDayOfYear();
//        try {
//            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime8);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(readableInterval3);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 166 + "'", int9 == 166);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, 1, (int) (byte) 1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) -1);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((-1), (int) (byte) 1, 0, 0, 31, (int) 'a', 10, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.ReadableInstant readableInstant3 = null;
        boolean boolean4 = dateTime2.isBefore(readableInstant3);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test079");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval1 = null;
//        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) readableInterval1);
//        org.joda.time.DateTime.Property property4 = dateTime3.weekOfWeekyear();
//        org.joda.time.DateTime dateTime6 = dateTime3.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay7 = dateTime6.toTimeOfDay();
//        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) timeOfDay7);
//        java.lang.Integer int9 = dateTimeFormatter0.getPivotYear();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(readableInterval2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(timeOfDay7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����-��-��T14:31:03.016" + "'", str8.equals("����-��-��T14:31:03.016"));
//        org.junit.Assert.assertNull(int9);
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField3, 2019, (int) (short) 100, (-100));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for hourOfDay must be in the range [100,-100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(166, (-870), 0, 31, (int) 'a', (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        try {
            org.joda.time.DateTime dateTime6 = dateTime2.withWeekOfWeekyear((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "����-��-��T14:31:00.636", "����-��-��T14:30:58.818");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "", "Property[millisOfDay]");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test085");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
//        int int5 = dateTime2.getMillisOfDay();
//        long long6 = dateTime2.getMillis();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52263199 + "'", int5 == 52263199);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560634263199L + "'", long6 == 1560634263199L);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.halfdayOfDay();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField2, (-1), (int) (short) 100, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for halfdayOfDay must be in the range [100,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.halfdays();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        try {
            int[] intArray8 = iSOChronology4.get(readablePeriod6, (long) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test089");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval2 = null;
//        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) readableInterval2);
//        org.joda.time.DateTime.Property property5 = dateTime4.weekOfWeekyear();
//        org.joda.time.DateTime dateTime7 = dateTime4.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay8 = dateTime7.toTimeOfDay();
//        java.lang.String str9 = dateTimeFormatter1.print((org.joda.time.ReadablePartial) timeOfDay8);
//        try {
//            org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.parse("����-��-��T14:31:02.082", dateTimeFormatter1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"����-��-��T14:31:02.082\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(readableInterval3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(timeOfDay8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "����-��-��T14:31:04.119" + "'", str9.equals("����-��-��T14:31:04.119"));
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFixedSignedDecimal(dateTimeFieldType4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(0L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime2.withMonthOfYear((int) (byte) 1);
        org.joda.time.DateTime dateTime8 = dateTime2.minusDays((int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            int int10 = dateTime8.get(dateTimeFieldType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        try {
            org.joda.time.DateTime dateTime4 = dateTime2.withYearOfEra(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        java.lang.String str2 = dateTimeZone1.getID();
        java.lang.String str3 = dateTimeZone1.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) 10);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTimeZoneOffset("", false, 10, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTime.Property property8 = dateTime6.millisOfDay();
        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
        int int10 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property11 = dateTime6.centuryOfEra();
        java.lang.Object obj12 = null;
        boolean boolean13 = dateTime6.equals(obj12);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(readableInterval5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
        int int7 = dateTime6.getDayOfYear();
        int int8 = dateTime6.getWeekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.DateTime.Property property10 = dateTime6.property(dateTimeFieldType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 365 + "'", int7 == 365);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (byte) 100, (-100), (int) (byte) 1, (int) ' ', 52263199);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology6.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((-870), 52257628, (int) (byte) -1, (int) ' ', (int) (short) 0, (org.joda.time.Chronology) iSOChronology9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(iSOChronology9);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury((int) (byte) 100, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFixedSignedDecimal(dateTimeFieldType4, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        java.lang.String str4 = property3.getName();
        org.joda.time.DateTime dateTime5 = property3.roundHalfEvenCopy();
        java.util.Locale locale7 = null;
        try {
            org.joda.time.DateTime dateTime8 = property3.setCopy("", locale7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for weekOfWeekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "weekOfWeekyear" + "'", str4.equals("weekOfWeekyear"));
        org.junit.Assert.assertNotNull(dateTime5);
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test103");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) (byte) 100, locale3);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime2.withMonthOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        org.joda.time.ReadableInterval readableInterval8 = null;
        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) readableInterval8);
        org.joda.time.DateTime.Property property11 = dateTime10.weekOfWeekyear();
        org.joda.time.DateTime dateTime13 = dateTime10.withWeekOfWeekyear((int) '4');
        org.joda.time.TimeOfDay timeOfDay14 = dateTime13.toTimeOfDay();
        try {
            int int15 = property7.compareTo((org.joda.time.ReadablePartial) timeOfDay14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekOfWeekyear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(readableInterval9);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(timeOfDay14);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField5 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType3, 52263);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
        org.joda.time.YearMonthDay yearMonthDay7 = dateTime6.toYearMonthDay();
        int[] intArray12 = new int[] { 52257628, 166, (-100), (byte) 10 };
        try {
            gregorianChronology1.validate((org.joda.time.ReadablePartial) yearMonthDay7, intArray12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 166 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(readableInterval5);
        org.junit.Assert.assertNotNull(yearMonthDay7);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.ReadableInterval readableInterval10 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) readableInterval9);
        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
        org.joda.time.DateTime dateTime14 = dateTime11.withWeekOfWeekyear((int) '4');
        org.joda.time.TimeOfDay timeOfDay15 = dateTime14.toTimeOfDay();
        java.lang.String str16 = dateTimeFormatter8.print((org.joda.time.ReadablePartial) timeOfDay15);
        org.joda.time.DateTime dateTime17 = dateTime7.withFields((org.joda.time.ReadablePartial) timeOfDay15);
        org.joda.time.DateTime dateTime19 = dateTime7.withEra(0);
        org.joda.time.DateTime.Property property20 = dateTime19.weekyear();
        java.util.TimeZone timeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now(dateTimeZone22);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.ReadableInterval readableInterval25 = null;
        org.joda.time.ReadableInterval readableInterval26 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval25);
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((java.lang.Object) readableInterval25);
        org.joda.time.DateTime.Property property28 = dateTime27.weekOfWeekyear();
        org.joda.time.DateTime dateTime30 = dateTime27.withWeekOfWeekyear((int) '4');
        org.joda.time.TimeOfDay timeOfDay31 = dateTime30.toTimeOfDay();
        java.lang.String str32 = dateTimeFormatter24.print((org.joda.time.ReadablePartial) timeOfDay31);
        org.joda.time.DateTime dateTime33 = dateTime23.withFields((org.joda.time.ReadablePartial) timeOfDay31);
        org.joda.time.DateTime dateTime34 = dateTime19.withFields((org.joda.time.ReadablePartial) timeOfDay31);
        int[] intArray39 = new int[] { 1, (byte) 100, (byte) 100, 2019 };
        try {
            gregorianChronology0.validate((org.joda.time.ReadablePartial) timeOfDay31, intArray39);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must not be larger than 59");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(readableInterval10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(timeOfDay15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "����-��-��T16:00:00.000" + "'", str16.equals("����-��-��T16:00:00.000"));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(readableInterval26);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(timeOfDay31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "����-��-��T16:00:00.000" + "'", str32.equals("����-��-��T16:00:00.000"));
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(intArray39);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime2.withMonthOfYear((int) (byte) 1);
        org.joda.time.DateTime dateTime8 = dateTime2.minusDays((int) (byte) 100);
        org.joda.time.DateTime dateTime10 = dateTime8.minusYears(1);
        try {
            org.joda.time.DateTime dateTime12 = dateTime8.withDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTime dateTime7 = dateTime2.withMinuteOfHour((int) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology9.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.DurationField durationField13 = iSOChronology12.halfdays();
        org.joda.time.DurationField durationField14 = iSOChronology12.weeks();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology12.secondOfMinute();
        int int16 = dateTime2.get(dateTimeField15);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.minuteOfHour();
        try {
            org.joda.time.DateTime dateTime7 = dateTime2.withDate((-1), 57600000, 6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) readableInterval1);
        org.joda.time.YearMonthDay yearMonthDay4 = dateTime3.toYearMonthDay();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.minus(readableDuration5);
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.ReadableInterval readableInterval8 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) readableInterval7);
        org.joda.time.DateTime.Property property10 = dateTime9.weekOfWeekyear();
        org.joda.time.DateTime dateTime12 = dateTime9.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
        org.joda.time.DateTime dateTime15 = dateTime12.withZoneRetainFields(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = dateTime3.withZone(dateTimeZone14);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter0.withZone(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(yearMonthDay4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(readableInterval8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gregorianChronology1.millis();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField3 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.DateTime dateTime13 = dateTime10.withZoneRetainFields(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        long long16 = cachedDateTimeZone14.nextTransition((long) (short) 0);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
        try {
            long long22 = zonedChronology17.getDateTimeMillis(52258, 10, 166, 57600000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 166 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(readableInterval6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9972000000L + "'", long16 == 9972000000L);
        org.junit.Assert.assertNotNull(zonedChronology17);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, 9972000000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-870), (java.lang.Number) 100L, (java.lang.Number) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("����-��-��T14:31:02.082");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"����-��-��T14:31:02.082\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendDecimal(dateTimeFieldType3, 166, 960);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime2.toMutableDateTimeISO();
        java.util.Locale locale7 = null;
        java.util.Calendar calendar8 = dateTime2.toCalendar(locale7);
        int int9 = dateTime2.getMinuteOfDay();
        org.joda.time.DateTime.Property property10 = dateTime2.weekOfWeekyear();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(calendar8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 960 + "'", int9 == 960);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((-870), 57600, 0, 0, (int) (short) -1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTime.Property property8 = dateTime6.millisOfDay();
        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
        int int10 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime6);
        int int11 = dateTime2.getCenturyOfEra();
        int int12 = dateTime2.getMonthOfYear();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(readableInterval5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField5 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 0L + "'", long0 == 0L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.DateTime dateTime13 = dateTime10.withZoneRetainFields(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        long long16 = cachedDateTimeZone14.nextTransition((long) (short) 0);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
        try {
            long long22 = zonedChronology17.getDateTimeMillis((int) (byte) 10, 960, (int) (byte) 100, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(readableInterval6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9972000000L + "'", long16 == 9972000000L);
        org.junit.Assert.assertNotNull(zonedChronology17);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "����-��-��T14:31:01.229");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        int int6 = dateTime2.getSecondOfDay();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime2.minus(readableDuration7);
        boolean boolean9 = dateTime8.isAfterNow();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57600 + "'", int6 == 57600);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.OutputStream outputStream2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("", outputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (-902L), (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 57600000, "Property[weekOfWeekyear]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(166, (int) 'a', 57600000);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 166 + "'", int3 == 166);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTime dateTime7 = dateTime2.minus((long) '#');
        try {
            org.joda.time.DateTime dateTime9 = dateTime7.withEra(1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 1577572260761L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfHour(166, (int) (byte) 10);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendCenturyOfEra((-100), 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (byte) 100, 0, 12, 52263, (-100), 0, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52263 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("����-��-��T14:30:57.838");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"����-��-��T14:30:57.838\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        try {
            long long2 = dateTimeFormatter0.parseMillis("Property[weekOfWeekyear]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[weekOfWeekyear]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        org.joda.time.DateTime dateTime7 = property4.setCopy(2);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatterBuilder3.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatterBuilder8.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean11 = dateTimeFormatter10.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean14 = dateTimeFormatter13.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter13.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray18 = new org.joda.time.format.DateTimeParser[] { dateTimeParser12, dateTimeParser15, dateTimeParser17 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder3.append(dateTimePrinter9, dateTimeParserArray18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder3.appendDayOfWeekShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder3.appendFixedSignedDecimal(dateTimeFieldType21, 52263);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeParserArray18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.DateTime dateTime5 = dateTime2.plusMinutes(366);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        int int6 = dateTime5.getWeekyear();
        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime5);
        int int8 = dateTime5.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1970 + "'", int6 == 1970);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 30844800000L + "'", long7 == 30844800000L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, number1, "����-��-��T14:31:02.082");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        java.io.Writer writer1 = null;
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) readableInterval2);
        org.joda.time.DateTime.Property property5 = dateTime4.weekOfWeekyear();
        org.joda.time.DateTime.Property property6 = dateTime4.millisOfDay();
        org.joda.time.DateTime dateTime7 = property6.withMaximumValue();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(readableInterval3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        int int6 = dateTime5.getWeekyear();
        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime5);
        java.util.Locale locale8 = null;
        java.util.Calendar calendar9 = dateTime5.toCalendar(locale8);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1970 + "'", int6 == 1970);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 30844800000L + "'", long7 == 30844800000L);
        org.junit.Assert.assertNotNull(calendar9);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DurationField durationField3 = gregorianChronology1.days();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 19, (java.lang.Number) 2019, (java.lang.Number) 52257628);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray8 = gregorianChronology0.get(readablePeriod5, (long) 19, (-902L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.ReadableInterval readableInterval10 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) readableInterval9);
        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
        org.joda.time.DateTime dateTime14 = dateTime11.withWeekOfWeekyear((int) '4');
        org.joda.time.TimeOfDay timeOfDay15 = dateTime14.toTimeOfDay();
        java.lang.String str16 = dateTimeFormatter8.print((org.joda.time.ReadablePartial) timeOfDay15);
        int[] intArray24 = new int[] { 52, 31, (byte) -1, (byte) 100, 19, 31 };
        try {
            int[] intArray26 = offsetDateTimeField5.addWrapPartial((org.joda.time.ReadablePartial) timeOfDay15, 4, intArray24, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 119 for clockhourOfHalfday must be in the range [366,377]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(readableInterval10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(timeOfDay15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "����-��-��T16:00:00.000" + "'", str16.equals("����-��-��T16:00:00.000"));
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
        int int7 = property6.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 99 + "'", int7 == 99);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        int int5 = dateTime2.getDayOfMonth();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-100) + "'", int1 == (-100));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) 166);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
        int int4 = dateTime3.getMillisOfSecond();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) '4', (long) (-870));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 922L + "'", long2 == 922L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.ReadableInterval readableInterval8 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) readableInterval7);
        org.joda.time.DateTime.Property property10 = dateTime9.weekOfWeekyear();
        org.joda.time.DateTime dateTime12 = dateTime9.withWeekOfWeekyear((int) '4');
        org.joda.time.TimeOfDay timeOfDay13 = dateTime12.toTimeOfDay();
        java.lang.String str14 = dateTimeFormatter6.print((org.joda.time.ReadablePartial) timeOfDay13);
        int[] intArray16 = null;
        java.util.Locale locale18 = null;
        try {
            int[] intArray19 = offsetDateTimeField5.set((org.joda.time.ReadablePartial) timeOfDay13, 0, intArray16, "����-��-��T14:30:57.838", locale18);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"����-��-��T14:30:57.838\" for clockhourOfHalfday is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(readableInterval8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(timeOfDay13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "����-��-��T16:00:00.000" + "'", str14.equals("����-��-��T16:00:00.000"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(922L, (long) 366);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 337452L + "'", long2 == 337452L);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        java.lang.String str4 = gregorianChronology1.toString();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[UTC]" + "'", str4.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
        java.lang.String str5 = property4.getName();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfCentury" + "'", str5.equals("yearOfCentury"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        org.joda.time.DateTime dateTime8 = dateTime5.withZoneRetainFields(dateTimeZone7);
        java.lang.String str9 = dateTimeZone7.getID();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.DateTime.Property property11 = dateTime10.millisOfSecond();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "America/Los_Angeles" + "'", str9.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(1970, 2, 0, (int) (byte) 1, 2019, 960, dateTimeZone9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis((int) '4', 6, 2, 0, 366, 52263199, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 366 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, 0, (int) 'a', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        int int6 = dateTime5.getWeekyear();
        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.ReadableInterval readableInterval8 = null;
        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) readableInterval8);
        org.joda.time.DateTime.Property property11 = dateTime10.weekOfWeekyear();
        org.joda.time.DateTime dateTime13 = dateTime10.withWeekOfWeekyear((int) '4');
        org.joda.time.MutableDateTime mutableDateTime14 = dateTime10.toMutableDateTimeISO();
        java.util.Locale locale15 = null;
        java.util.Calendar calendar16 = dateTime10.toCalendar(locale15);
        int int17 = dateTime10.getMinuteOfDay();
        boolean boolean18 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime.Property property19 = dateTime10.millisOfDay();
        java.util.TimeZone timeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.ReadableInterval readableInterval24 = null;
        org.joda.time.ReadableInterval readableInterval25 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval24);
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((java.lang.Object) readableInterval24);
        org.joda.time.DateTime.Property property27 = dateTime26.weekOfWeekyear();
        org.joda.time.DateTime dateTime29 = dateTime26.withWeekOfWeekyear((int) '4');
        org.joda.time.TimeOfDay timeOfDay30 = dateTime29.toTimeOfDay();
        java.lang.String str31 = dateTimeFormatter23.print((org.joda.time.ReadablePartial) timeOfDay30);
        org.joda.time.DateTime dateTime32 = dateTime22.withFields((org.joda.time.ReadablePartial) timeOfDay30);
        org.joda.time.DateTime dateTime34 = dateTime22.withEra(0);
        org.joda.time.DateTime.Property property35 = dateTime34.weekyear();
        org.joda.time.DateTime dateTime37 = dateTime34.plusMinutes((int) (byte) 10);
        int int38 = property19.compareTo((org.joda.time.ReadableInstant) dateTime34);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1970 + "'", int6 == 1970);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 30844800000L + "'", long7 == 30844800000L);
        org.junit.Assert.assertNotNull(readableInterval9);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(calendar16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 960 + "'", int17 == 960);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(readableInterval25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(timeOfDay30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "����-��-��T16:00:00.000" + "'", str31.equals("����-��-��T16:00:00.000"));
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) readableInterval1);
        org.joda.time.DateTime.Property property4 = dateTime3.weekOfWeekyear();
        org.joda.time.DateTime dateTime6 = dateTime3.withWeekOfWeekyear((int) '4');
        org.joda.time.TimeOfDay timeOfDay7 = dateTime6.toTimeOfDay();
        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) timeOfDay7);
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withLocale(locale9);
        org.joda.time.Chronology chronology11 = dateTimeFormatter10.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����-��-��T16:00:00.000" + "'", str8.equals("����-��-��T16:00:00.000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNull(chronology11);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        java.lang.String str4 = dateTime2.toString(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970-01-01T00:00:00.035" + "'", str4.equals("1970-01-01T00:00:00.035"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 6, 52257628);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField11 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType9, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (byte) 0, 10, 52, 52263, (int) (byte) 10, 8, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52263 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.days();
        try {
            long long6 = gregorianChronology0.getDateTimeMillis(0, (int) (byte) 0, (int) 'a', 166);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime2.withMonthOfYear((int) (byte) 1);
        try {
            org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(52263, (int) (byte) 10);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendDayOfMonth((-870));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.DateTime dateTime13 = dateTime10.withZoneRetainFields(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        long long16 = cachedDateTimeZone14.nextTransition((long) (short) 0);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
        try {
            long long25 = zonedChronology17.getDateTimeMillis(52258, 9, (int) '4', 57600, 0, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(readableInterval6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9972000000L + "'", long16 == 9972000000L);
        org.junit.Assert.assertNotNull(zonedChronology17);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "weekOfWeekyear", 24, (-870));
        long long6 = fixedDateTimeZone4.nextTransition((long) 2019);
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        org.joda.time.ReadableInstant readableInstant8 = null;
        int int9 = fixedDateTimeZone4.getOffset(readableInstant8);
        long long11 = fixedDateTimeZone4.nextTransition((long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test179");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
//        org.joda.time.DateTime dateTime6 = dateTime2.withMonthOfYear((int) (byte) 1);
//        org.joda.time.DateTime dateTime8 = dateTime2.minusDays((int) (byte) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology10.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
//        org.joda.time.DurationField durationField14 = iSOChronology13.halfdays();
//        org.joda.time.DurationField durationField15 = iSOChronology13.weeks();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology13.secondOfMinute();
//        int int17 = dateTime8.get(dateTimeField16);
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 13 + "'", int17 == 13);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) '#', 365);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12775 + "'", int2 == 12775);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test181");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay6 = dateTime5.toTimeOfDay();
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.ReadableInterval readableInterval8 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) readableInterval7);
//        org.joda.time.DateTime.Property property10 = dateTime9.weekOfWeekyear();
//        org.joda.time.DateTime dateTime12 = dateTime9.withWeekOfWeekyear((int) '4');
//        java.util.TimeZone timeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
//        org.joda.time.DateTime dateTime15 = dateTime12.withZoneRetainFields(dateTimeZone14);
//        org.joda.time.DateTime dateTime18 = dateTime12.withDurationAdded((long) 100, 0);
//        org.joda.time.DateTime dateTime20 = dateTime12.minusMinutes(4);
//        boolean boolean21 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime12);
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(timeOfDay6);
//        org.junit.Assert.assertNotNull(readableInterval8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.ReadableInterval readableInterval7 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) readableInterval6);
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime8.toYearMonthDay();
        int[] intArray10 = new int[] {};
        int int11 = offsetDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay9, intArray10);
        try {
            long long14 = offsetDateTimeField5.set((long) 52258, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for clockhourOfHalfday must be in the range [366,377]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(readableInterval7);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 366 + "'", int11 == 366);
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test183");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
//        int int6 = dateTime5.getWeekyear();
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.ReadableInterval readableInterval8 = null;
//        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) readableInterval8);
//        org.joda.time.DateTime.Property property11 = dateTime10.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = dateTime10.withWeekOfWeekyear((int) '4');
//        org.joda.time.MutableDateTime mutableDateTime14 = dateTime10.toMutableDateTimeISO();
//        java.util.Locale locale15 = null;
//        java.util.Calendar calendar16 = dateTime10.toCalendar(locale15);
//        int int17 = dateTime10.getMinuteOfDay();
//        boolean boolean18 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime.Property property19 = dateTime10.millisOfDay();
//        long long20 = property19.remainder();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577572274309L + "'", long7 == 1577572274309L);
//        org.junit.Assert.assertNotNull(readableInterval9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertNotNull(calendar16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 871 + "'", int17 == 871);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(52263, (int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendFixedSignedDecimal(dateTimeFieldType6, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        boolean boolean3 = dateTimeFormatter0.isPrinter();
        try {
            org.joda.time.LocalDateTime localDateTime5 = dateTimeFormatter0.parseLocalDateTime("ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ZonedChronology[GregorianChronol...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test186");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
//        org.joda.time.MutableDateTime mutableDateTime6 = dateTime2.toMutableDateTimeISO();
//        java.util.Locale locale7 = null;
//        java.util.Calendar calendar8 = dateTime2.toCalendar(locale7);
//        int int9 = dateTime2.getMinuteOfDay();
//        org.joda.time.DateTime dateTime11 = dateTime2.plusHours(0);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusWeeks(9);
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(calendar8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 871 + "'", int9 == 871);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        org.joda.time.TimeOfDay timeOfDay6 = dateTime5.toTimeOfDay();
        org.joda.time.DateTime dateTime7 = dateTime5.withEarlierOffsetAtOverlap();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.DateTime dateTime10 = dateTime5.withFieldAdded(durationFieldType8, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(timeOfDay6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test188");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
//        int int5 = dateTime2.getMillisOfDay();
//        org.joda.time.DateTime.Property property6 = dateTime2.secondOfDay();
//        org.joda.time.DateTime dateTime8 = dateTime2.withMillisOfSecond(0);
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52275274 + "'", int5 == 52275274);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatterBuilder3.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatterBuilder8.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean11 = dateTimeFormatter10.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean14 = dateTimeFormatter13.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter13.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray18 = new org.joda.time.format.DateTimeParser[] { dateTimeParser12, dateTimeParser15, dateTimeParser17 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder3.append(dateTimePrinter9, dateTimeParserArray18);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder19.appendFractionOfMinute((int) (byte) -1, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeParserArray18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology7.millis();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.weekOfWeekyear();
        org.joda.time.DurationField durationField10 = gregorianChronology7.hours();
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology7.getZone();
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.ReadableInterval readableInterval13 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) readableInterval12);
        org.joda.time.DateTime.Property property15 = dateTime14.weekOfWeekyear();
        org.joda.time.DateTime dateTime17 = dateTime14.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
        org.joda.time.DateTime dateTime20 = dateTime17.withZoneRetainFields(dateTimeZone19);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone19);
        long long23 = cachedDateTimeZone21.nextTransition((long) (short) 0);
        org.joda.time.chrono.ZonedChronology zonedChronology24 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology7, (org.joda.time.DateTimeZone) cachedDateTimeZone21);
        try {
            org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(52263, (int) 'a', (int) (byte) 10, 100, 960, 0, 0, (org.joda.time.Chronology) zonedChronology24);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(readableInterval13);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9972000000L + "'", long23 == 9972000000L);
        org.junit.Assert.assertNotNull(zonedChronology24);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField4 = gregorianChronology3.millis();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.weekOfWeekyear();
//        int int6 = dateTime2.get(dateTimeField5);
//        int int7 = dateTime2.getMillisOfDay();
//        java.util.Locale locale8 = null;
//        java.util.Calendar calendar9 = dateTime2.toCalendar(locale8);
//        try {
//            org.joda.time.DateTime dateTime11 = dateTime2.withHourOfDay(292278993);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52276276 + "'", int7 == 52276276);
//        org.junit.Assert.assertNotNull(calendar9);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        int int6 = property4.getLeapAmount();
        int int7 = property4.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 86399999 + "'", int7 == 86399999);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime2.withHourOfDay(2);
        java.lang.Object obj7 = null;
        boolean boolean8 = dateTime6.equals(obj7);
        org.joda.time.DateTime.Property property9 = dateTime6.dayOfMonth();
        int int10 = property9.getMinimumValue();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury((int) (byte) 100, (int) (byte) 100);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendPattern("2019-W24");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: W");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.halfdays();
        org.joda.time.DurationField durationField6 = iSOChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology4.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField11 = new org.joda.time.field.DividedDateTimeField(dateTimeField8, dateTimeFieldType9, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
        org.joda.time.DateTime dateTime8 = dateTime6.plusMonths((int) (short) -1);
        boolean boolean9 = dateTime8.isBeforeNow();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField4 = gregorianChronology3.millis();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.weekOfWeekyear();
//        int int6 = dateTime2.get(dateTimeField5);
//        int int7 = dateTime2.getMillisOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology9);
//        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology9.getZone();
//        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology9.getZone();
//        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology9.hourOfDay();
//        int int14 = dateTime2.get(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52278114 + "'", int7 == 52278114);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 21 + "'", int14 == 21);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((-100));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 1560634263199L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
        org.joda.time.ReadableInterval readableInterval8 = null;
        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) readableInterval8);
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
        org.joda.time.DateTime.Property property12 = dateTime10.secondOfMinute();
        org.joda.time.DateTime dateTime14 = dateTime10.withMonthOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property15 = dateTime14.weekOfWeekyear();
        org.joda.time.TimeOfDay timeOfDay16 = dateTime14.toTimeOfDay();
        int int17 = offsetDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay16);
        org.joda.time.ReadableInterval readableInterval18 = null;
        org.joda.time.ReadableInterval readableInterval19 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval18);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((java.lang.Object) readableInterval18);
        org.joda.time.DateTime.Property property21 = dateTime20.weekOfWeekyear();
        org.joda.time.DateTime dateTime23 = dateTime20.withWeekOfWeekyear((int) '4');
        org.joda.time.TimeOfDay timeOfDay24 = dateTime23.toTimeOfDay();
        int[] intArray32 = new int[] { (byte) 1, 6, 6, 24, (short) 10, 52274482 };
        try {
            int[] intArray34 = offsetDateTimeField5.add((org.joda.time.ReadablePartial) timeOfDay24, 24, intArray32, 377);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 24");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
        org.junit.Assert.assertNotNull(readableInterval9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(timeOfDay16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 366 + "'", int17 == 366);
        org.junit.Assert.assertNotNull(readableInterval19);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(timeOfDay24);
        org.junit.Assert.assertNotNull(intArray32);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean1 = dateTimeFormatter0.isParser();
        boolean boolean2 = dateTimeFormatter0.isParser();
        boolean boolean3 = dateTimeFormatter0.isOffsetParsed();
        try {
            org.joda.time.LocalTime localTime5 = dateTimeFormatter0.parseLocalTime("����-��-��T14:30:59.213");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"����-��-��T14:30:59.213\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
//        int int6 = dateTime2.getSecondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        boolean boolean8 = dateTime2.isSupported(dateTimeFieldType7);
//        java.util.Locale locale10 = null;
//        try {
//            java.lang.String str11 = dateTime2.toString("", locale10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52278 + "'", int6 == 52278);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test207");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime.Property property4 = dateTime2.millisOfDay();
//        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = property4.getAsShortText(locale6);
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "52278963" + "'", str7.equals("52278963"));
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime2.withMonthOfYear((int) (byte) 1);
        org.joda.time.DateTime dateTime8 = dateTime2.minusDays((int) (byte) 100);
        org.joda.time.DateTime dateTime10 = dateTime8.minusYears(1);
        org.joda.time.DateTime dateTime11 = dateTime8.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime13 = dateTime8.withSecondOfMinute(52);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) 2019, 52278009);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "����-��-��T14:31:16.336");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test211");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval1 = null;
//        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) readableInterval1);
//        org.joda.time.DateTime.Property property4 = dateTime3.weekOfWeekyear();
//        org.joda.time.DateTime dateTime6 = dateTime3.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay7 = dateTime6.toTimeOfDay();
//        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) timeOfDay7);
//        try {
//            org.joda.time.MutableDateTime mutableDateTime10 = dateTimeFormatter0.parseMutableDateTime("����-��-��T14:31:18.482");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"����-��-��T14:31:18.482\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(readableInterval2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(timeOfDay7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����-��-��T14:31:20.119" + "'", str8.equals("����-��-��T14:31:20.119"));
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
        org.joda.time.ReadableInterval readableInterval8 = null;
        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) readableInterval8);
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
        org.joda.time.DateTime.Property property12 = dateTime10.secondOfMinute();
        org.joda.time.DateTime dateTime14 = dateTime10.withMonthOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property15 = dateTime14.weekOfWeekyear();
        org.joda.time.TimeOfDay timeOfDay16 = dateTime14.toTimeOfDay();
        int int17 = offsetDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay16);
        org.joda.time.ReadableInterval readableInterval18 = null;
        org.joda.time.ReadableInterval readableInterval19 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval18);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((java.lang.Object) readableInterval18);
        org.joda.time.YearMonthDay yearMonthDay21 = dateTime20.toYearMonthDay();
        java.util.Locale locale22 = null;
        try {
            java.lang.String str23 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay21, locale22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'clockhourOfHalfday' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
        org.junit.Assert.assertNotNull(readableInterval9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(timeOfDay16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 366 + "'", int17 == 366);
        org.junit.Assert.assertNotNull(readableInterval19);
        org.junit.Assert.assertNotNull(yearMonthDay21);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.days();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
        org.joda.time.ReadableInterval readableInterval8 = null;
        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) readableInterval8);
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
        org.joda.time.DateTime.Property property12 = dateTime10.secondOfMinute();
        org.joda.time.DateTime dateTime14 = dateTime10.withMonthOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property15 = dateTime14.weekOfWeekyear();
        org.joda.time.TimeOfDay timeOfDay16 = dateTime14.toTimeOfDay();
        int int17 = offsetDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay16);
        long long20 = offsetDateTimeField5.add((long) (-870), 30844800000L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
        org.junit.Assert.assertNotNull(readableInterval9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(timeOfDay16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 366 + "'", int17 == 366);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 111041279999999130L + "'", long20 == 111041279999999130L);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 0L, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("52278963");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '52278963' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test217");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
//        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
//        org.joda.time.ReadableInterval readableInterval8 = null;
//        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) readableInterval8);
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
//        org.joda.time.DateTime.Property property12 = dateTime10.secondOfMinute();
//        org.joda.time.DateTime dateTime14 = dateTime10.withMonthOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekOfWeekyear();
//        org.joda.time.TimeOfDay timeOfDay16 = dateTime14.toTimeOfDay();
//        int int17 = offsetDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay16);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
//        java.util.TimeZone timeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now(dateTimeZone20);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval23 = null;
//        org.joda.time.ReadableInterval readableInterval24 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval23);
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) readableInterval23);
//        org.joda.time.DateTime.Property property26 = dateTime25.weekOfWeekyear();
//        org.joda.time.DateTime dateTime28 = dateTime25.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay29 = dateTime28.toTimeOfDay();
//        java.lang.String str30 = dateTimeFormatter22.print((org.joda.time.ReadablePartial) timeOfDay29);
//        org.joda.time.DateTime dateTime31 = dateTime21.withFields((org.joda.time.ReadablePartial) timeOfDay29);
//        boolean boolean32 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) timeOfDay29);
//        java.lang.String str33 = dateTimeFormatter18.print((org.joda.time.ReadablePartial) timeOfDay29);
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = offsetDateTimeField5.getAsText((org.joda.time.ReadablePartial) timeOfDay29, 100, locale35);
//        long long38 = offsetDateTimeField5.roundCeiling((long) 52258);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = null;
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField41 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType39, (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
//        org.junit.Assert.assertNotNull(readableInterval9);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(timeOfDay16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 366 + "'", int17 == 366);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertNotNull(readableInterval24);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(timeOfDay29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "����-��-��T14:31:20.581" + "'", str30.equals("����-��-��T14:31:20.581"));
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "����W���T143120" + "'", str33.equals("����W���T143120"));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "100" + "'", str36.equals("100"));
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 3600000L + "'", long38 == 3600000L);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(366, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 466 + "'", int2 == 466);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        java.lang.Appendable appendable2 = null;
        try {
            dateTimeFormatter0.printTo(appendable2, (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("����W���T160000");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"����W���T160000\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) readableInterval2);
        org.joda.time.DateTime.Property property5 = dateTime4.weekOfWeekyear();
        org.joda.time.DateTime dateTime7 = dateTime4.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        org.joda.time.DateTime dateTime10 = dateTime7.withZoneRetainFields(dateTimeZone9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        long long13 = cachedDateTimeZone11.nextTransition((long) (short) 0);
        long long15 = cachedDateTimeZone11.nextTransition((long) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter0.withDefaultYear(3);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(readableInterval3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9972000000L + "'", long13 == 9972000000L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9972000000L + "'", long15 == 9972000000L);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(24, 12, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTime dateTime17 = dateTime14.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime19 = dateTime17.plusWeeks(6);
//        org.joda.time.DateTime.Property property20 = dateTime19.year();
//        org.joda.time.DateTime.Property property21 = dateTime19.millisOfDay();
//        org.joda.time.DateMidnight dateMidnight22 = dateTime19.toDateMidnight();
//        int int23 = dateTime19.getMillisOfDay();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:21.765" + "'", str11.equals("����-��-��T14:31:21.765"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateMidnight22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 52881764 + "'", int23 == 52881764);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatterBuilder3.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.appendTimeZoneOffset("����-��-��T14:31:01.229", true, 365, 377);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DurationField durationField3 = gregorianChronology1.months();
        long long6 = durationField3.subtract((long) (-870), (long) 52278114);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-137478161260800870L) + "'", long6 == (-137478161260800870L));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatterBuilder3.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatterBuilder8.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean11 = dateTimeFormatter10.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean14 = dateTimeFormatter13.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter13.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray18 = new org.joda.time.format.DateTimeParser[] { dateTimeParser12, dateTimeParser15, dateTimeParser17 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder3.append(dateTimePrinter9, dateTimeParserArray18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder3.appendFractionOfMinute(31, 52263);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeParserArray18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(52263, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendYearOfEra(100, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendMonthOfYearShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendFraction(dateTimeFieldType10, 12775, 57600);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.DateTime dateTime13 = dateTime10.withZoneRetainFields(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        long long16 = cachedDateTimeZone14.nextTransition((long) (short) 0);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
        org.joda.time.Chronology chronology18 = zonedChronology17.withUTC();
        org.joda.time.Chronology chronology19 = zonedChronology17.withUTC();
        try {
            long long24 = zonedChronology17.getDateTimeMillis(24, 1970, 100, 19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(readableInterval6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9972000000L + "'", long16 == 9972000000L);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(chronology19);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.DateTime dateTime13 = dateTime10.withZoneRetainFields(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        long long16 = cachedDateTimeZone14.nextTransition((long) (short) 0);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
        org.joda.time.Chronology chronology18 = zonedChronology17.withUTC();
        try {
            long long26 = zonedChronology17.getDateTimeMillis(52278009, 365, (int) '#', 377, 12775, 292278993, (-870));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 377 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(readableInterval6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9972000000L + "'", long16 == 9972000000L);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(chronology18);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
//        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
//        int int7 = dateTime6.getDayOfYear();
//        org.joda.time.ReadableInterval readableInterval8 = null;
//        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) readableInterval8);
//        org.joda.time.DateTime.Property property11 = dateTime10.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = dateTime10.withWeekOfWeekyear((int) '4');
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime6, (org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime.Property property15 = dateTime10.monthOfYear();
//        org.joda.time.ReadableInterval readableInterval16 = null;
//        org.joda.time.ReadableInterval readableInterval17 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval16);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) readableInterval16);
//        org.joda.time.DateTime.Property property19 = dateTime18.weekOfWeekyear();
//        org.joda.time.DateTime.Property property20 = dateTime18.millisOfDay();
//        boolean boolean21 = property15.equals((java.lang.Object) property20);
//        org.joda.time.DurationField durationField22 = property15.getDurationField();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 166 + "'", int7 == 166);
//        org.junit.Assert.assertNotNull(readableInterval9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(readableInterval17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(durationField22);
//    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
//        int int6 = dateTime2.getSecondOfDay();
//        org.joda.time.DateTime.Property property7 = dateTime2.minuteOfHour();
//        java.util.Locale locale8 = null;
//        java.util.Calendar calendar9 = dateTime2.toCalendar(locale8);
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52284 + "'", int6 == 52284);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(calendar9);
//    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
//        org.joda.time.MutableDateTime mutableDateTime6 = dateTime2.toMutableDateTimeISO();
//        java.util.Locale locale7 = null;
//        java.util.Calendar calendar8 = dateTime2.toCalendar(locale7);
//        int int9 = dateTime2.getMinuteOfDay();
//        org.joda.time.DateTime dateTime11 = dateTime2.plusHours(0);
//        boolean boolean12 = dateTime2.isEqualNow();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(calendar8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 871 + "'", int9 == 871);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("Pacific Standard Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Pacific Standard Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test236");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        boolean boolean1 = dateTimeFormatter0.isParser();
//        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter0.getParser();
//        org.joda.time.ReadableInterval readableInterval3 = null;
//        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) readableInterval3);
//        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = dateTime5.withWeekOfWeekyear((int) '4');
//        java.util.TimeZone timeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
//        org.joda.time.DateTime dateTime11 = dateTime8.withZoneRetainFields(dateTimeZone10);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone12);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter0.withOffsetParsed();
//        java.lang.StringBuffer stringBuffer15 = null;
//        java.util.TimeZone timeZone16 = null;
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forTimeZone(timeZone16);
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval20 = null;
//        org.joda.time.ReadableInterval readableInterval21 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval20);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((java.lang.Object) readableInterval20);
//        org.joda.time.DateTime.Property property23 = dateTime22.weekOfWeekyear();
//        org.joda.time.DateTime dateTime25 = dateTime22.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay26 = dateTime25.toTimeOfDay();
//        java.lang.String str27 = dateTimeFormatter19.print((org.joda.time.ReadablePartial) timeOfDay26);
//        org.joda.time.DateTime dateTime28 = dateTime18.withFields((org.joda.time.ReadablePartial) timeOfDay26);
//        org.joda.time.DateTime dateTime30 = dateTime18.withEra(0);
//        org.joda.time.DateTime.Property property31 = dateTime30.weekyear();
//        java.util.TimeZone timeZone32 = null;
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forTimeZone(timeZone32);
//        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now(dateTimeZone33);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.ReadableInterval readableInterval37 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((java.lang.Object) readableInterval36);
//        org.joda.time.DateTime.Property property39 = dateTime38.weekOfWeekyear();
//        org.joda.time.DateTime dateTime41 = dateTime38.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay42 = dateTime41.toTimeOfDay();
//        java.lang.String str43 = dateTimeFormatter35.print((org.joda.time.ReadablePartial) timeOfDay42);
//        org.joda.time.DateTime dateTime44 = dateTime34.withFields((org.joda.time.ReadablePartial) timeOfDay42);
//        org.joda.time.DateTime dateTime45 = dateTime30.withFields((org.joda.time.ReadablePartial) timeOfDay42);
//        try {
//            dateTimeFormatter14.printTo(stringBuffer15, (org.joda.time.ReadablePartial) timeOfDay42);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertNotNull(dateTimeParser2);
//        org.junit.Assert.assertNotNull(readableInterval4);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertNotNull(readableInterval21);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(timeOfDay26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "����-��-��T14:31:24.812" + "'", str27.equals("����-��-��T14:31:24.812"));
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTimeFormatter35);
//        org.junit.Assert.assertNotNull(readableInterval37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(timeOfDay42);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "����-��-��T14:31:24.814" + "'", str43.equals("����-��-��T14:31:24.814"));
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTime45);
//    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test237");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName((long) '4');
//        long long7 = dateTimeZone1.convertLocalToUTC(57600L, true, (long) 31);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pacific Standard Time" + "'", str3.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28857600L + "'", long7 == 28857600L);
//    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime.Property property4 = dateTime2.millisOfDay();
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.plus(readableDuration5);
//        int int7 = dateTime2.getMinuteOfDay();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 871 + "'", int7 == 871);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendMonthOfYearText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology1.add(readablePeriod4, (long) 52275313, 2000);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52275313L + "'", long7 == 52275313L);
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
//        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
//        long long10 = offsetDateTimeField5.getDifferenceAsLong((long) (byte) -1, (long) 100);
//        java.util.TimeZone timeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone12);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.ReadableInterval readableInterval16 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((java.lang.Object) readableInterval15);
//        org.joda.time.DateTime.Property property18 = dateTime17.weekOfWeekyear();
//        org.joda.time.DateTime dateTime20 = dateTime17.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay21 = dateTime20.toTimeOfDay();
//        java.lang.String str22 = dateTimeFormatter14.print((org.joda.time.ReadablePartial) timeOfDay21);
//        org.joda.time.DateTime dateTime23 = dateTime13.withFields((org.joda.time.ReadablePartial) timeOfDay21);
//        org.joda.time.DateTime dateTime25 = dateTime13.withEra(0);
//        org.joda.time.DateTime.Property property26 = dateTime25.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField29 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType27, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(readableInterval16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(timeOfDay21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "����-��-��T14:31:25.835" + "'", str22.equals("����-��-��T14:31:25.835"));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        long long8 = offsetDateTimeField5.getDifferenceAsLong((long) (short) -1, (long) 1970);
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.ReadableInterval readableInterval10 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) readableInterval9);
        org.joda.time.MutableDateTime mutableDateTime12 = dateTime11.toMutableDateTime();
        org.joda.time.DateTime.Property property13 = dateTime11.secondOfMinute();
        org.joda.time.DateTime dateTime15 = dateTime11.plusMillis((int) (byte) 10);
        org.joda.time.LocalDateTime localDateTime16 = dateTime11.toLocalDateTime();
        int[] intArray20 = new int[] { 31, 6 };
        try {
            int[] intArray22 = offsetDateTimeField5.add((org.joda.time.ReadablePartial) localDateTime16, 52284, intArray20, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52284");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(readableInterval10);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(localDateTime16);
        org.junit.Assert.assertNotNull(intArray20);
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test244");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
//        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
//        long long10 = offsetDateTimeField5.getDifferenceAsLong((long) (byte) -1, (long) 100);
//        org.joda.time.DurationField durationField11 = offsetDateTimeField5.getLeapDurationField();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter12.withOffsetParsed();
//        org.joda.time.ReadableInterval readableInterval14 = null;
//        org.joda.time.ReadableInterval readableInterval15 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval14);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) readableInterval14);
//        org.joda.time.MutableDateTime mutableDateTime17 = dateTime16.toMutableDateTime();
//        org.joda.time.DateTime.Property property18 = dateTime16.secondOfMinute();
//        org.joda.time.DateTime dateTime20 = dateTime16.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime21 = dateTime16.toLocalDateTime();
//        java.lang.String str22 = dateTimeFormatter13.print((org.joda.time.ReadablePartial) localDateTime21);
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology25);
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology25.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, 365);
//        org.joda.time.ReadableInterval readableInterval30 = null;
//        org.joda.time.ReadableInterval readableInterval31 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval30);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((java.lang.Object) readableInterval30);
//        org.joda.time.YearMonthDay yearMonthDay33 = dateTime32.toYearMonthDay();
//        int[] intArray34 = new int[] {};
//        int int35 = offsetDateTimeField29.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay33, intArray34);
//        try {
//            int[] intArray37 = offsetDateTimeField5.addWrapField((org.joda.time.ReadablePartial) localDateTime21, 870, intArray34, 52275313);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 870");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(readableInterval15);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(localDateTime21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019-W24" + "'", str22.equals("2019-W24"));
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(readableInterval31);
//        org.junit.Assert.assertNotNull(yearMonthDay33);
//        org.junit.Assert.assertNotNull(intArray34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 366 + "'", int35 == 366);
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((-24L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-24L) + "'", long2 == (-24L));
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test246");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime.Property property8 = dateTime6.millisOfDay();
//        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
//        int int10 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime6);
//        int int11 = dateTime2.getCenturyOfEra();
//        int int12 = dateTime2.getHourOfDay();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 14 + "'", int12 == 14);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 'a', (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 96L + "'", long2 == 96L);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test248");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
//        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
//        int int7 = dateTime6.getDayOfYear();
//        int int8 = dateTime6.getWeekOfWeekyear();
//        org.joda.time.DateTime.Property property9 = dateTime6.dayOfMonth();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 166 + "'", int7 == 166);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(property9);
//    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
//        int int6 = dateTime2.getSecondOfDay();
//        int int7 = dateTime2.getEra();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52286 + "'", int6 == 52286);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiply(52273, 52274482);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The calculation caused an overflow: 52273 * 52274482");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMonthOfYear(12);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneShortName(strMap5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) 466);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test254");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
//        org.joda.time.MutableDateTime mutableDateTime6 = dateTime2.toMutableDateTimeISO();
//        java.util.Locale locale7 = null;
//        java.util.Calendar calendar8 = dateTime2.toCalendar(locale7);
//        int int9 = dateTime2.getMinuteOfDay();
//        org.joda.time.DateTime dateTime11 = dateTime2.plusHours(0);
//        try {
//            org.joda.time.DateTime dateTime13 = dateTime11.withEra(100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(calendar8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 871 + "'", int9 == 871);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfDay();
        org.joda.time.DateTime.Property property5 = dateTime2.monthOfYear();
        org.joda.time.DateTime dateTime6 = property5.roundCeilingCopy();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(0, 52274482);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "24");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test259");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime.Property property8 = dateTime6.millisOfDay();
//        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
//        int int10 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property11 = dateTime2.weekOfWeekyear();
//        java.util.Locale locale12 = null;
//        java.util.Calendar calendar13 = dateTime2.toCalendar(locale12);
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(calendar13);
//    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        org.joda.time.DateTime dateTime8 = dateTime5.withZoneRetainFields(dateTimeZone7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        long long11 = cachedDateTimeZone9.nextTransition((long) (short) 0);
        java.lang.String str12 = cachedDateTimeZone9.getID();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9972000000L + "'", long11 == 9972000000L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "America/Los_Angeles" + "'", str12.equals("America/Los_Angeles"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfDay();
        boolean boolean6 = dateTime2.isEqual((long) (-870));
        org.joda.time.DateTime dateTime8 = dateTime2.plusMonths((int) 'a');
        org.joda.time.DateTime.Property property9 = dateTime2.millisOfDay();
        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType3);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(57600, 'a', 8, 0, (int) (byte) 0, true, (int) (short) 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder0.setStandardOffset((int) '4');
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
//        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
//        int int7 = dateTime6.getDayOfYear();
//        int int8 = dateTime6.getWeekOfWeekyear();
//        java.util.Date date9 = dateTime6.toDate();
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime6.minus(readableDuration10);
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 166 + "'", int7 == 166);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        int int6 = dateTime5.getWeekyear();
        try {
            org.joda.time.DateTime dateTime8 = dateTime5.withHourOfDay(377);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 377 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("����-��-��T14:31:23.185");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '����-��-��T14:31:23.185' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        java.io.Writer writer2 = null;
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) readableInterval3);
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime5.toMutableDateTime();
        org.joda.time.DateTime.Property property7 = dateTime5.secondOfMinute();
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (byte) 10);
        org.joda.time.LocalDateTime localDateTime10 = dateTime5.toLocalDateTime();
        try {
            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadablePartial) localDateTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(readableInterval4);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDateTime10);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        org.joda.time.Interval interval6 = property4.toInterval();
        org.joda.time.DateTimeField dateTimeField7 = property4.getField();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(interval6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        long long4 = property3.remainder();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 484288086L + "'", long4 == 484288086L);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
        long long10 = offsetDateTimeField5.getDifferenceAsLong((long) (byte) -1, (long) 100);
        long long12 = offsetDateTimeField5.remainder((long) 57600);
        long long14 = offsetDateTimeField5.roundHalfCeiling((long) 52284);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 57600L + "'", long12 == 57600L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
//        java.lang.Appendable appendable1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval3 = null;
//        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) readableInterval3);
//        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = dateTime5.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay9 = dateTime8.toTimeOfDay();
//        java.lang.String str10 = dateTimeFormatter2.print((org.joda.time.ReadablePartial) timeOfDay9);
//        try {
//            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) timeOfDay9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(readableInterval4);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(timeOfDay9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "����-��-��T14:31:28.304" + "'", str10.equals("����-��-��T14:31:28.304"));
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMonthOfYear(12);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneShortName(strMap5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendTwoDigitYear(57600000);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Coordinated Universal Time", "����-��-��T14:31:01.229");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNull(durationFieldType3);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime.Property property8 = dateTime6.millisOfDay();
//        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
//        int int10 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property11 = dateTime6.centuryOfEra();
//        org.joda.time.DateTime dateTime13 = property11.addWrapFieldToCopy((int) (short) 100);
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("����-��-��T14:30:59.213", "weekOfWeekyear", 365, 52273);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        long long7 = fixedDateTimeZone4.convertUTCToLocal((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 364L + "'", long7 == 364L);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
//        org.joda.time.ReadableInterval readableInterval1 = null;
//        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) readableInterval1);
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTime.Property property5 = dateTime3.secondOfMinute();
//        org.joda.time.DateTime dateTime7 = dateTime3.plusMillis((int) (byte) 10);
//        int int8 = dateTime7.getDayOfYear();
//        org.joda.time.ReadableInterval readableInterval9 = null;
//        org.joda.time.ReadableInterval readableInterval10 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval9);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) readableInterval9);
//        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
//        org.joda.time.DateTime dateTime14 = dateTime11.withWeekOfWeekyear((int) '4');
//        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime7, (org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter0.withChronology(chronology15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter0.withOffsetParsed();
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean20 = gregorianChronology18.equals((java.lang.Object) "Property[millisOfDay]");
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField22 = gregorianChronology21.days();
//        boolean boolean23 = gregorianChronology18.equals((java.lang.Object) durationField22);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology18);
//        org.joda.time.DurationField durationField25 = gregorianChronology18.seconds();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(readableInterval2);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 166 + "'", int8 == 166);
//        org.junit.Assert.assertNotNull(readableInterval10);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertNotNull(durationField25);
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatterBuilder3.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatterBuilder8.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean11 = dateTimeFormatter10.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean14 = dateTimeFormatter13.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter13.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray18 = new org.joda.time.format.DateTimeParser[] { dateTimeParser12, dateTimeParser15, dateTimeParser17 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder3.append(dateTimePrinter9, dateTimeParserArray18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder3.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendTwoDigitYear((-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder20.appendLiteral('4');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeParserArray18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-100), 6);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNull(dateTimeZone2);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        org.joda.time.DateTime dateTime8 = dateTime5.withZoneRetainFields(dateTimeZone7);
        java.lang.String str9 = dateTimeZone7.getID();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone7);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "America/Los_Angeles" + "'", str9.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        boolean boolean1 = dateTimeFormatter0.isParser();
        java.lang.Appendable appendable2 = null;
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) readableInterval3);
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime5.toMutableDateTime();
        org.joda.time.DateTime.Property property7 = dateTime5.secondOfMinute();
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (byte) 10);
        org.joda.time.LocalDateTime localDateTime10 = dateTime5.toLocalDateTime();
        try {
            dateTimeFormatter0.printTo(appendable2, (org.joda.time.ReadablePartial) localDateTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(readableInterval4);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDateTime10);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatterBuilder3.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatterBuilder8.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean11 = dateTimeFormatter10.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean14 = dateTimeFormatter13.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter13.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray18 = new org.joda.time.format.DateTimeParser[] { dateTimeParser12, dateTimeParser15, dateTimeParser17 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder3.append(dateTimePrinter9, dateTimeParserArray18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder3.appendClockhourOfHalfday(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendMillisOfSecond(52);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder21.appendSecondOfMinute(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeParserArray18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        org.joda.time.Interval interval6 = property4.toInterval();
        org.joda.time.DateTime dateTime8 = property4.addToCopy((long) 31);
        org.joda.time.DateTime dateTime9 = dateTime8.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(interval6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime2.withMonthOfYear((int) (byte) 1);
        org.joda.time.DateTime dateTime8 = dateTime2.minusDays((int) (byte) 100);
        org.joda.time.DateTime dateTime10 = dateTime8.minusYears(1);
        int int11 = dateTime8.getMonthOfYear();
        try {
            org.joda.time.DateTime dateTime13 = dateTime8.withHourOfDay(960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        int int4 = gregorianChronology0.getMinimumDaysInFirstWeek();
        try {
            long long12 = gregorianChronology0.getDateTimeMillis(10, 2, (int) (short) 0, 366, 52286, (int) (short) 10, 1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 366 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime9 = dateTime5.withPeriodAdded(readablePeriod7, (int) (short) 0);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime9);
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test290");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
//        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
//        int int7 = dateTime6.getDayOfYear();
//        org.joda.time.ReadableInterval readableInterval8 = null;
//        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) readableInterval8);
//        org.joda.time.DateTime.Property property11 = dateTime10.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = dateTime10.withWeekOfWeekyear((int) '4');
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime6, (org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime.Property property15 = dateTime10.monthOfYear();
//        org.joda.time.ReadableInterval readableInterval16 = null;
//        org.joda.time.ReadableInterval readableInterval17 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval16);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) readableInterval16);
//        org.joda.time.DateTime.Property property19 = dateTime18.weekOfWeekyear();
//        org.joda.time.DateTime.Property property20 = dateTime18.millisOfDay();
//        boolean boolean21 = property15.equals((java.lang.Object) property20);
//        org.joda.time.DateTime dateTime22 = property15.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime23 = property15.withMinimumValue();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 166 + "'", int7 == 166);
//        org.junit.Assert.assertNotNull(readableInterval9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(readableInterval17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime23);
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField6 = gregorianChronology5.millis();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.weekOfWeekyear();
        org.joda.time.DurationField durationField8 = gregorianChronology5.hours();
        int int9 = gregorianChronology5.getMinimumDaysInFirstWeek();
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(1970, 21, (int) ' ', (int) (short) -1, 1, (org.joda.time.Chronology) gregorianChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test292");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
//        int int6 = dateTime5.getWeekyear();
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.ReadableInterval readableInterval8 = null;
//        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) readableInterval8);
//        org.joda.time.DateTime.Property property11 = dateTime10.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = dateTime10.withWeekOfWeekyear((int) '4');
//        org.joda.time.MutableDateTime mutableDateTime14 = dateTime10.toMutableDateTimeISO();
//        java.util.Locale locale15 = null;
//        java.util.Calendar calendar16 = dateTime10.toCalendar(locale15);
//        int int17 = dateTime10.getMinuteOfDay();
//        boolean boolean18 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime19 = dateTime10.withTimeAtStartOfDay();
//        org.joda.time.DateTime dateTime20 = dateTime19.toDateTime();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577572292541L + "'", long7 == 1577572292541L);
//        org.junit.Assert.assertNotNull(readableInterval9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertNotNull(calendar16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 871 + "'", int17 == 871);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test294");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.halfdayOfDay();
//        org.joda.time.ReadableInterval readableInterval3 = null;
//        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) readableInterval3);
//        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = dateTime5.withWeekOfWeekyear((int) '4');
//        java.util.TimeZone timeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
//        org.joda.time.DateTime dateTime11 = dateTime8.withZoneRetainFields(dateTimeZone10);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
//        long long14 = cachedDateTimeZone12.nextTransition((long) (short) 0);
//        org.joda.time.Chronology chronology15 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone12);
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone12);
//        java.lang.String str18 = cachedDateTimeZone12.getShortName((long) 366);
//        long long22 = cachedDateTimeZone12.convertLocalToUTC((long) 365, true, (long) 'a');
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(readableInterval4);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9972000000L + "'", long14 == 9972000000L);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PST" + "'", str18.equals("PST"));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 28800365L + "'", long22 == 28800365L);
//    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test295");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        org.joda.time.ReadableInterval readableInterval29 = null;
//        org.joda.time.ReadableInterval readableInterval30 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval29);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((java.lang.Object) readableInterval29);
//        org.joda.time.DateTime.Property property32 = dateTime31.weekOfWeekyear();
//        int int33 = property32.getMinimumValueOverall();
//        org.joda.time.DurationField durationField34 = property32.getDurationField();
//        long long37 = durationField34.subtract((long) 'a', 2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology39);
//        org.joda.time.DateTimeZone dateTimeZone41 = gregorianChronology39.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone41);
//        org.joda.time.DurationField durationField43 = iSOChronology42.hours();
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField44 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType16, durationField34, durationField43);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:33.102" + "'", str11.equals("����-��-��T14:31:33.102"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertNotNull(readableInterval30);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-1209599903L) + "'", long37 == (-1209599903L));
//        org.junit.Assert.assertNotNull(gregorianChronology39);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertNotNull(iSOChronology42);
//        org.junit.Assert.assertNotNull(durationField43);
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.days();
        org.joda.time.DurationField durationField2 = gregorianChronology0.minutes();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.centuryOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.halfdays();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 0, 12775);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        try {
//            long long30 = unsupportedDateTimeField28.roundFloor((-24L));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:33.232" + "'", str11.equals("����-��-��T14:31:33.232"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test301");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval10 = null;
//        org.joda.time.ReadableInterval readableInterval11 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval10);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) readableInterval10);
//        org.joda.time.DateTime.Property property13 = dateTime12.weekOfWeekyear();
//        org.joda.time.DateTime dateTime15 = dateTime12.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay16 = dateTime15.toTimeOfDay();
//        java.lang.String str17 = dateTimeFormatter9.print((org.joda.time.ReadablePartial) timeOfDay16);
//        org.joda.time.DateTime dateTime18 = dateTime8.withFields((org.joda.time.ReadablePartial) timeOfDay16);
//        boolean boolean19 = cachedDateTimeZone5.equals((java.lang.Object) dateTime18);
//        int int21 = cachedDateTimeZone5.getOffset((long) (-100));
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(readableInterval11);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(timeOfDay16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "����-��-��T14:31:33.500" + "'", str17.equals("����-��-��T14:31:33.500"));
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.DateTime dateTime13 = dateTime10.withZoneRetainFields(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        long long16 = cachedDateTimeZone14.nextTransition((long) (short) 0);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology18.getZone();
        java.lang.String str20 = dateTimeZone19.getID();
        boolean boolean21 = zonedChronology17.equals((java.lang.Object) dateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone22 = zonedChronology17.getZone();
        org.joda.time.DateTimeField dateTimeField23 = zonedChronology17.weekyearOfCentury();
        org.joda.time.ReadableInterval readableInterval24 = null;
        org.joda.time.ReadableInterval readableInterval25 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval24);
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((java.lang.Object) readableInterval24);
        org.joda.time.DateTime.Property property27 = dateTime26.weekOfWeekyear();
        org.joda.time.DateTime dateTime29 = dateTime26.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTime dateTime31 = dateTime26.withMinuteOfHour((int) (short) 10);
        boolean boolean32 = zonedChronology17.equals((java.lang.Object) (short) 10);
        org.joda.time.DurationField durationField33 = zonedChronology17.weekyears();
        org.joda.time.DurationFieldType durationFieldType34 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField36 = new org.joda.time.field.ScaledDurationField(durationField33, durationFieldType34, (-100));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(readableInterval6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9972000000L + "'", long16 == 9972000000L);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(readableInterval25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(durationField33);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) readableInterval2);
        org.joda.time.DateTime.Property property5 = dateTime4.weekOfWeekyear();
        org.joda.time.DateTime dateTime7 = dateTime4.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        org.joda.time.DateTime dateTime10 = dateTime7.withZoneRetainFields(dateTimeZone9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        long long13 = cachedDateTimeZone11.nextTransition((long) (short) 0);
        long long15 = cachedDateTimeZone11.nextTransition((long) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone11);
        boolean boolean17 = dateTimeFormatter0.isPrinter();
        boolean boolean18 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(readableInterval3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9972000000L + "'", long13 == 9972000000L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9972000000L + "'", long15 == 9972000000L);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis(52263199, 292278993, 1970, 57600000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("����-��-��T14:30:59.213", "weekOfWeekyear", 365, 52273);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        int int7 = fixedDateTimeZone4.getStandardOffset(2019L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52273 + "'", int7 == 52273);
    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test308");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
//        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime7 = dateTime2.toLocalDateTime();
//        org.joda.time.ReadableInterval readableInterval8 = null;
//        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) readableInterval8);
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
//        org.joda.time.DateTime.Property property12 = dateTime10.secondOfMinute();
//        org.joda.time.DateTime dateTime14 = dateTime10.plusMillis((int) (byte) 10);
//        int int15 = dateTime14.getDayOfYear();
//        org.joda.time.DateTime dateTime17 = dateTime14.minusSeconds(166);
//        boolean boolean18 = dateTime2.equals((java.lang.Object) dateTime17);
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(localDateTime7);
//        org.junit.Assert.assertNotNull(readableInterval9);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 166 + "'", int15 == 166);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(52263, (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendYearOfEra(100, (int) ' ');
//        java.util.TimeZone timeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval13 = null;
//        org.joda.time.ReadableInterval readableInterval14 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval13);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) readableInterval13);
//        org.joda.time.DateTime.Property property16 = dateTime15.weekOfWeekyear();
//        org.joda.time.DateTime dateTime18 = dateTime15.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay19 = dateTime18.toTimeOfDay();
//        java.lang.String str20 = dateTimeFormatter12.print((org.joda.time.ReadablePartial) timeOfDay19);
//        org.joda.time.DateTime dateTime21 = dateTime11.withFields((org.joda.time.ReadablePartial) timeOfDay19);
//        org.joda.time.DateTime dateTime23 = dateTime11.withEra(0);
//        org.joda.time.DateTime.Property property24 = dateTime23.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder0.appendFixedSignedDecimal(dateTimeFieldType25, 1970);
//        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField29 = gregorianChronology28.millis();
//        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology28.weekOfWeekyear();
//        org.joda.time.DurationField durationField31 = gregorianChronology28.hours();
//        org.joda.time.DateTimeZone dateTimeZone32 = gregorianChronology28.getZone();
//        org.joda.time.ReadableInterval readableInterval33 = null;
//        org.joda.time.ReadableInterval readableInterval34 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval33);
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((java.lang.Object) readableInterval33);
//        org.joda.time.DateTime.Property property36 = dateTime35.weekOfWeekyear();
//        org.joda.time.DateTime dateTime38 = dateTime35.withWeekOfWeekyear((int) '4');
//        java.util.TimeZone timeZone39 = null;
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forTimeZone(timeZone39);
//        org.joda.time.DateTime dateTime41 = dateTime38.withZoneRetainFields(dateTimeZone40);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone42 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone40);
//        long long44 = cachedDateTimeZone42.nextTransition((long) (short) 0);
//        org.joda.time.chrono.ZonedChronology zonedChronology45 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology28, (org.joda.time.DateTimeZone) cachedDateTimeZone42);
//        org.joda.time.DateTimeZone dateTimeZone46 = gregorianChronology28.getZone();
//        org.joda.time.DurationField durationField47 = gregorianChronology28.days();
//        org.joda.time.DurationField durationField48 = gregorianChronology28.months();
//        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField50 = gregorianChronology49.millis();
//        long long53 = durationField50.subtract((long) (-870), (int) ' ');
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField54 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType25, durationField48, durationField50);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(readableInterval14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(timeOfDay19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "����-��-��T14:31:35.914" + "'", str20.equals("����-��-��T14:31:35.914"));
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(gregorianChronology28);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(readableInterval34);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 9972000000L + "'", long44 == 9972000000L);
//        org.junit.Assert.assertNotNull(zonedChronology45);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(gregorianChronology49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-902L) + "'", long53 == (-902L));
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.DateTime dateTime13 = dateTime10.withZoneRetainFields(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        long long16 = cachedDateTimeZone14.nextTransition((long) (short) 0);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology18.getZone();
        java.lang.String str20 = dateTimeZone19.getID();
        boolean boolean21 = zonedChronology17.equals((java.lang.Object) dateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone22 = zonedChronology17.getZone();
        org.joda.time.DateTimeField dateTimeField23 = zonedChronology17.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField24 = zonedChronology17.weekOfWeekyear();
        org.joda.time.Chronology chronology25 = zonedChronology17.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(readableInterval6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9972000000L + "'", long16 == 9972000000L);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(chronology25);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property4.getAsShortText(locale5);
//        org.joda.time.DateTime dateTime7 = property4.withMinimumValue();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "36" + "'", str6.equals("36"));
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatterBuilder3.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatterBuilder8.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean11 = dateTimeFormatter10.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean14 = dateTimeFormatter13.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter13.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray18 = new org.joda.time.format.DateTimeParser[] { dateTimeParser12, dateTimeParser15, dateTimeParser17 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder3.append(dateTimePrinter9, dateTimeParserArray18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder3.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendLiteral(' ');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder20.appendMillisOfDay((-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeParserArray18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ZonedChronology[GregorianChronol...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval3);
        org.junit.Assert.assertNotNull(readableInterval4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(readableInterval6);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        try {
            org.joda.time.LocalDateTime localDateTime3 = dateTimeFormatter1.parseLocalDateTime("����-��-��T14:31:02.630");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"����-��-��T14:31:02.630\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology30);
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology30.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, 365);
//        int int36 = offsetDateTimeField34.getMinimumValue((long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField34, (int) '#');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = dateTimeFormatter39.withOffsetParsed();
//        org.joda.time.ReadableInterval readableInterval41 = null;
//        org.joda.time.ReadableInterval readableInterval42 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval41);
//        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((java.lang.Object) readableInterval41);
//        org.joda.time.MutableDateTime mutableDateTime44 = dateTime43.toMutableDateTime();
//        org.joda.time.DateTime.Property property45 = dateTime43.secondOfMinute();
//        org.joda.time.DateTime dateTime47 = dateTime43.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime48 = dateTime43.toLocalDateTime();
//        java.lang.String str49 = dateTimeFormatter40.print((org.joda.time.ReadablePartial) localDateTime48);
//        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone51 = gregorianChronology50.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = dateTimeFormatter52.withOffsetParsed();
//        org.joda.time.ReadableInterval readableInterval54 = null;
//        org.joda.time.ReadableInterval readableInterval55 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval54);
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime((java.lang.Object) readableInterval54);
//        org.joda.time.MutableDateTime mutableDateTime57 = dateTime56.toMutableDateTime();
//        org.joda.time.DateTime.Property property58 = dateTime56.secondOfMinute();
//        org.joda.time.DateTime dateTime60 = dateTime56.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime61 = dateTime56.toLocalDateTime();
//        java.lang.String str62 = dateTimeFormatter53.print((org.joda.time.ReadablePartial) localDateTime61);
//        int[] intArray64 = gregorianChronology50.get((org.joda.time.ReadablePartial) localDateTime61, (-1209599903L));
//        int int65 = offsetDateTimeField34.getMinimumValue((org.joda.time.ReadablePartial) localDateTime48, intArray64);
//        org.joda.time.chrono.GregorianChronology gregorianChronology68 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology68);
//        org.joda.time.DateTimeZone dateTimeZone70 = gregorianChronology68.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology71 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone70);
//        org.joda.time.DurationField durationField72 = iSOChronology71.hours();
//        org.joda.time.ReadableInterval readableInterval73 = null;
//        org.joda.time.ReadableInterval readableInterval74 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval73);
//        org.joda.time.DateTime dateTime75 = new org.joda.time.DateTime((java.lang.Object) readableInterval73);
//        org.joda.time.DateTime.Property property76 = dateTime75.weekOfWeekyear();
//        org.joda.time.DateTime dateTime78 = dateTime75.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay79 = dateTime78.toTimeOfDay();
//        int[] intArray81 = iSOChronology71.get((org.joda.time.ReadablePartial) timeOfDay79, 3600000L);
//        try {
//            int[] intArray83 = unsupportedDateTimeField28.set((org.joda.time.ReadablePartial) localDateTime48, 2000, intArray81, 19);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:37.157" + "'", str11.equals("����-��-��T14:31:37.157"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 366 + "'", int36 == 366);
//        org.junit.Assert.assertNotNull(dateTimeFormatter39);
//        org.junit.Assert.assertNotNull(dateTimeFormatter40);
//        org.junit.Assert.assertNotNull(readableInterval42);
//        org.junit.Assert.assertNotNull(mutableDateTime44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(localDateTime48);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "2019-W24" + "'", str49.equals("2019-W24"));
//        org.junit.Assert.assertNotNull(gregorianChronology50);
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertNotNull(dateTimeFormatter52);
//        org.junit.Assert.assertNotNull(dateTimeFormatter53);
//        org.junit.Assert.assertNotNull(readableInterval55);
//        org.junit.Assert.assertNotNull(mutableDateTime57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(localDateTime61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "2019-W24" + "'", str62.equals("2019-W24"));
//        org.junit.Assert.assertNotNull(intArray64);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 366 + "'", int65 == 366);
//        org.junit.Assert.assertNotNull(gregorianChronology68);
//        org.junit.Assert.assertNotNull(dateTimeZone70);
//        org.junit.Assert.assertNotNull(iSOChronology71);
//        org.junit.Assert.assertNotNull(durationField72);
//        org.junit.Assert.assertNotNull(readableInterval74);
//        org.junit.Assert.assertNotNull(property76);
//        org.junit.Assert.assertNotNull(dateTime78);
//        org.junit.Assert.assertNotNull(timeOfDay79);
//        org.junit.Assert.assertNotNull(intArray81);
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 52274482);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 52274482");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
//        java.util.TimeZone timeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval5 = null;
//        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
//        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
//        org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay11 = dateTime10.toTimeOfDay();
//        java.lang.String str12 = dateTimeFormatter4.print((org.joda.time.ReadablePartial) timeOfDay11);
//        org.joda.time.DateTime dateTime13 = dateTime3.withFields((org.joda.time.ReadablePartial) timeOfDay11);
//        org.joda.time.DateTime dateTime15 = dateTime3.withEra(0);
//        org.joda.time.DateTime.Property property16 = dateTime15.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property16.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType17, "377");
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField20 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(readableInterval6);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(timeOfDay11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "����-��-��T14:31:37.220" + "'", str12.equals("����-��-��T14:31:37.220"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        java.util.TimeZone timeZone29 = null;
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forTimeZone(timeZone29);
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone30);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval33 = null;
//        org.joda.time.ReadableInterval readableInterval34 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval33);
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((java.lang.Object) readableInterval33);
//        org.joda.time.DateTime.Property property36 = dateTime35.weekOfWeekyear();
//        org.joda.time.DateTime dateTime38 = dateTime35.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay39 = dateTime38.toTimeOfDay();
//        java.lang.String str40 = dateTimeFormatter32.print((org.joda.time.ReadablePartial) timeOfDay39);
//        org.joda.time.DateTime dateTime41 = dateTime31.withFields((org.joda.time.ReadablePartial) timeOfDay39);
//        boolean boolean42 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) timeOfDay39);
//        try {
//            int int43 = unsupportedDateTimeField28.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay39);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:37.264" + "'", str11.equals("����-��-��T14:31:37.264"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter32);
//        org.junit.Assert.assertNotNull(readableInterval34);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(timeOfDay39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "����-��-��T14:31:37.284" + "'", str40.equals("����-��-��T14:31:37.284"));
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) 'a', 52273, 0, (int) (byte) 0, 0, (int) (short) 100, 52275313, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        boolean boolean1 = dateTimeFormatter0.isParser();
        java.lang.Integer int2 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(int2);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(9L, (long) 24);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 216L + "'", long2 == 216L);
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        try {
//            java.lang.String str30 = unsupportedDateTimeField28.getAsShortText((long) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:37.333" + "'", str11.equals("����-��-��T14:31:37.333"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test326");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withOffsetParsed();
//        org.joda.time.ReadableInterval readableInterval3 = null;
//        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) readableInterval3);
//        org.joda.time.MutableDateTime mutableDateTime6 = dateTime5.toMutableDateTime();
//        org.joda.time.DateTime.Property property7 = dateTime5.secondOfMinute();
//        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime10 = dateTime5.toLocalDateTime();
//        java.lang.String str11 = dateTimeFormatter2.print((org.joda.time.ReadablePartial) localDateTime10);
//        long long13 = iSOChronology0.set((org.joda.time.ReadablePartial) localDateTime10, (long) 57600);
//        org.joda.time.DurationField durationField14 = iSOChronology0.minutes();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(readableInterval4);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(localDateTime10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019-W24" + "'", str11.equals("2019-W24"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560609097384L + "'", long13 == 1560609097384L);
//        org.junit.Assert.assertNotNull(durationField14);
//    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.halfdays();
        org.joda.time.DurationField durationField6 = iSOChronology4.weeks();
        java.lang.String str7 = iSOChronology4.toString();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        int int4 = property3.getMinimumValueOverall();
        org.joda.time.Interval interval5 = property3.toInterval();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(interval5);
    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test329");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
//        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
//        int int7 = dateTime6.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime6.plus(readablePeriod9);
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 166 + "'", int7 == 166);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
//        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
//        org.joda.time.ReadableInterval readableInterval8 = null;
//        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) readableInterval8);
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
//        org.joda.time.DateTime.Property property12 = dateTime10.secondOfMinute();
//        org.joda.time.DateTime dateTime14 = dateTime10.withMonthOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekOfWeekyear();
//        org.joda.time.TimeOfDay timeOfDay16 = dateTime14.toTimeOfDay();
//        int int17 = offsetDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay16);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
//        java.util.TimeZone timeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now(dateTimeZone20);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval23 = null;
//        org.joda.time.ReadableInterval readableInterval24 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval23);
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) readableInterval23);
//        org.joda.time.DateTime.Property property26 = dateTime25.weekOfWeekyear();
//        org.joda.time.DateTime dateTime28 = dateTime25.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay29 = dateTime28.toTimeOfDay();
//        java.lang.String str30 = dateTimeFormatter22.print((org.joda.time.ReadablePartial) timeOfDay29);
//        org.joda.time.DateTime dateTime31 = dateTime21.withFields((org.joda.time.ReadablePartial) timeOfDay29);
//        boolean boolean32 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) timeOfDay29);
//        java.lang.String str33 = dateTimeFormatter18.print((org.joda.time.ReadablePartial) timeOfDay29);
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = offsetDateTimeField5.getAsText((org.joda.time.ReadablePartial) timeOfDay29, 100, locale35);
//        java.lang.String str38 = offsetDateTimeField5.getAsShortText((long) 57600);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
//        org.junit.Assert.assertNotNull(readableInterval9);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(timeOfDay16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 366 + "'", int17 == 366);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertNotNull(readableInterval24);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(timeOfDay29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "����-��-��T14:31:37.601" + "'", str30.equals("����-��-��T14:31:37.601"));
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "����W���T143137" + "'", str33.equals("����W���T143137"));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "100" + "'", str36.equals("100"));
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "377" + "'", str38.equals("377"));
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        int int4 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField5 = gregorianChronology0.millis();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
        org.joda.time.DateTime.Property property7 = dateTime2.yearOfCentury();
        org.joda.time.DateTime dateTime8 = property7.roundCeilingCopy();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime.Property property4 = dateTime2.millisOfDay();
//        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
//        int int6 = property4.getLeapAmount();
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.ReadableInterval readableInterval8 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) readableInterval7);
//        org.joda.time.DateTime.Property property10 = dateTime9.weekOfWeekyear();
//        org.joda.time.DateTime dateTime12 = dateTime9.withWeekOfWeekyear((int) '4');
//        java.util.TimeZone timeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
//        org.joda.time.DateTime dateTime15 = dateTime12.withZoneRetainFields(dateTimeZone14);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) cachedDateTimeZone16);
//        int int18 = property4.getDifference((org.joda.time.ReadableInstant) dateTime17);
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(readableInterval8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-20) + "'", int18 == (-20));
//    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.halfdayOfDay();
//        org.joda.time.ReadableInterval readableInterval3 = null;
//        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) readableInterval3);
//        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = dateTime5.withWeekOfWeekyear((int) '4');
//        java.util.TimeZone timeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
//        org.joda.time.DateTime dateTime11 = dateTime8.withZoneRetainFields(dateTimeZone10);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
//        long long14 = cachedDateTimeZone12.nextTransition((long) (short) 0);
//        org.joda.time.Chronology chronology15 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone12);
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology0.dayOfWeek();
//        java.util.TimeZone timeZone17 = null;
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forTimeZone(timeZone17);
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval21 = null;
//        org.joda.time.ReadableInterval readableInterval22 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval21);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((java.lang.Object) readableInterval21);
//        org.joda.time.DateTime.Property property24 = dateTime23.weekOfWeekyear();
//        org.joda.time.DateTime dateTime26 = dateTime23.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay27 = dateTime26.toTimeOfDay();
//        java.lang.String str28 = dateTimeFormatter20.print((org.joda.time.ReadablePartial) timeOfDay27);
//        org.joda.time.DateTime dateTime29 = dateTime19.withFields((org.joda.time.ReadablePartial) timeOfDay27);
//        org.joda.time.DateTime dateTime31 = dateTime19.withEra(0);
//        org.joda.time.DateTime.Property property32 = dateTime31.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, dateTimeFieldType33, 377);
//        long long37 = offsetDateTimeField35.roundCeiling((long) 365);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(readableInterval4);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9972000000L + "'", long14 == 9972000000L);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertNotNull(readableInterval22);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(timeOfDay27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "����-��-��T14:31:38.209" + "'", str28.equals("����-��-��T14:31:38.209"));
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 86400000L + "'", long37 == 86400000L);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatterBuilder3.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.append(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test338");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter30.withOffsetParsed();
//        org.joda.time.ReadableInterval readableInterval32 = null;
//        org.joda.time.ReadableInterval readableInterval33 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval32);
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((java.lang.Object) readableInterval32);
//        org.joda.time.MutableDateTime mutableDateTime35 = dateTime34.toMutableDateTime();
//        org.joda.time.DateTime.Property property36 = dateTime34.secondOfMinute();
//        org.joda.time.DateTime dateTime38 = dateTime34.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime39 = dateTime34.toLocalDateTime();
//        java.lang.String str40 = dateTimeFormatter31.print((org.joda.time.ReadablePartial) localDateTime39);
//        long long42 = iSOChronology29.set((org.joda.time.ReadablePartial) localDateTime39, (long) 57600);
//        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology45);
//        org.joda.time.DateTimeZone dateTimeZone47 = gregorianChronology45.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone47);
//        org.joda.time.DurationField durationField49 = iSOChronology48.hours();
//        org.joda.time.ReadableInterval readableInterval50 = null;
//        org.joda.time.ReadableInterval readableInterval51 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval50);
//        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((java.lang.Object) readableInterval50);
//        org.joda.time.DateTime.Property property53 = dateTime52.weekOfWeekyear();
//        org.joda.time.DateTime dateTime55 = dateTime52.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay56 = dateTime55.toTimeOfDay();
//        int[] intArray58 = iSOChronology48.get((org.joda.time.ReadablePartial) timeOfDay56, 3600000L);
//        try {
//            int[] intArray60 = unsupportedDateTimeField28.set((org.joda.time.ReadablePartial) localDateTime39, 19, intArray58, 871);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:38.898" + "'", str11.equals("����-��-��T14:31:38.898"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertNotNull(dateTimeFormatter30);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(readableInterval33);
//        org.junit.Assert.assertNotNull(mutableDateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(localDateTime39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "2019-W24" + "'", str40.equals("2019-W24"));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560609098903L + "'", long42 == 1560609098903L);
//        org.junit.Assert.assertNotNull(gregorianChronology45);
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertNotNull(iSOChronology48);
//        org.junit.Assert.assertNotNull(durationField49);
//        org.junit.Assert.assertNotNull(readableInterval51);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(timeOfDay56);
//        org.junit.Assert.assertNotNull(intArray58);
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
//        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
//        int int7 = dateTime6.getDayOfYear();
//        org.joda.time.ReadableInterval readableInterval8 = null;
//        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) readableInterval8);
//        org.joda.time.DateTime.Property property11 = dateTime10.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = dateTime10.withWeekOfWeekyear((int) '4');
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime6, (org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime.Property property15 = dateTime10.monthOfYear();
//        org.joda.time.DateTime.Property property16 = dateTime10.yearOfEra();
//        int int17 = property16.getMinimumValueOverall();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 166 + "'", int7 == 166);
//        org.junit.Assert.assertNotNull(readableInterval9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
//        int int5 = dateTime2.getMillisOfDay();
//        int int6 = dateTime2.getMinuteOfHour();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime2.minus(readablePeriod7);
//        org.joda.time.DateTime dateTime10 = dateTime8.plusHours(166);
//        try {
//            org.joda.time.DateTime dateTime12 = dateTime10.withMillisOfSecond(52263);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52263 for millisOfSecond must be in the range [0,999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52299273 + "'", int5 == 52299273);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.hours();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.yearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.DateTime dateTime13 = dateTime10.withZoneRetainFields(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        long long16 = cachedDateTimeZone14.nextTransition((long) (short) 0);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology18.getZone();
        java.lang.String str20 = dateTimeZone19.getID();
        boolean boolean21 = zonedChronology17.equals((java.lang.Object) dateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone22 = zonedChronology17.getZone();
        org.joda.time.DateTimeField dateTimeField23 = zonedChronology17.weekyearOfCentury();
        try {
            long long28 = zonedChronology17.getDateTimeMillis(21, 0, 366, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86400000]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(readableInterval6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9972000000L + "'", long16 == 9972000000L);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeField23);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "����-��-��T14:31:01.229");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
//        org.joda.time.ReadableInterval readableInterval5 = null;
//        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
//        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
//        org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((int) '4');
//        java.util.TimeZone timeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
//        org.joda.time.DateTime dateTime13 = dateTime10.withZoneRetainFields(dateTimeZone12);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
//        long long16 = cachedDateTimeZone14.nextTransition((long) (short) 0);
//        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
//        org.joda.time.Chronology chronology18 = zonedChronology17.withUTC();
//        org.joda.time.Chronology chronology19 = zonedChronology17.withUTC();
//        java.util.TimeZone timeZone20 = null;
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval24 = null;
//        org.joda.time.ReadableInterval readableInterval25 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval24);
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((java.lang.Object) readableInterval24);
//        org.joda.time.DateTime.Property property27 = dateTime26.weekOfWeekyear();
//        org.joda.time.DateTime dateTime29 = dateTime26.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay30 = dateTime29.toTimeOfDay();
//        java.lang.String str31 = dateTimeFormatter23.print((org.joda.time.ReadablePartial) timeOfDay30);
//        org.joda.time.DateTime dateTime32 = dateTime22.withFields((org.joda.time.ReadablePartial) timeOfDay30);
//        org.joda.time.DateTime dateTime34 = dateTime22.withEra(0);
//        org.joda.time.DateTime.Property property35 = dateTime34.monthOfYear();
//        org.joda.time.DateTime dateTime37 = dateTime34.plusDays(0);
//        boolean boolean38 = zonedChronology17.equals((java.lang.Object) 0);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(readableInterval6);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9972000000L + "'", long16 == 9972000000L);
//        org.junit.Assert.assertNotNull(zonedChronology17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertNotNull(readableInterval25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(timeOfDay30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "����-��-��T14:31:39.672" + "'", str31.equals("����-��-��T14:31:39.672"));
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        long long31 = unsupportedDateTimeField28.add((long) 52274482, (long) 13);
//        java.util.TimeZone timeZone32 = null;
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forTimeZone(timeZone32);
//        java.lang.String str35 = dateTimeZone33.getName((long) '4');
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.ReadableInterval readableInterval37 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((java.lang.Object) readableInterval36);
//        org.joda.time.MutableDateTime mutableDateTime39 = dateTime38.toMutableDateTime();
//        org.joda.time.DateTime.Property property40 = dateTime38.secondOfMinute();
//        org.joda.time.DateTime dateTime42 = dateTime38.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime43 = dateTime38.toLocalDateTime();
//        boolean boolean44 = dateTimeZone33.isLocalDateTimeGap(localDateTime43);
//        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology47);
//        org.joda.time.DateTimeZone dateTimeZone49 = gregorianChronology47.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology50 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone49);
//        org.joda.time.DurationField durationField51 = iSOChronology50.hours();
//        org.joda.time.ReadableInterval readableInterval52 = null;
//        org.joda.time.ReadableInterval readableInterval53 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval52);
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((java.lang.Object) readableInterval52);
//        org.joda.time.DateTime.Property property55 = dateTime54.weekOfWeekyear();
//        org.joda.time.DateTime dateTime57 = dateTime54.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay58 = dateTime57.toTimeOfDay();
//        int[] intArray60 = iSOChronology50.get((org.joda.time.ReadablePartial) timeOfDay58, 3600000L);
//        java.util.Locale locale62 = null;
//        try {
//            int[] intArray63 = unsupportedDateTimeField28.set((org.joda.time.ReadablePartial) localDateTime43, (int) (short) 1, intArray60, "UTC", locale62);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:39.986" + "'", str11.equals("����-��-��T14:31:39.986"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 7914674482L + "'", long31 == 7914674482L);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Pacific Standard Time" + "'", str35.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(readableInterval37);
//        org.junit.Assert.assertNotNull(mutableDateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(localDateTime43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology47);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertNotNull(iSOChronology50);
//        org.junit.Assert.assertNotNull(durationField51);
//        org.junit.Assert.assertNotNull(readableInterval53);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(timeOfDay58);
//        org.junit.Assert.assertNotNull(intArray60);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.ReadableInterval readableInterval7 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) readableInterval6);
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime8.toYearMonthDay();
        int[] intArray10 = new int[] {};
        int int11 = offsetDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay9, intArray10);
        org.joda.time.DurationField durationField12 = offsetDateTimeField5.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(readableInterval7);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 366 + "'", int11 == 366);
        org.junit.Assert.assertNull(durationField12);
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        long long31 = unsupportedDateTimeField28.add((long) 52274482, (long) 13);
//        try {
//            long long33 = unsupportedDateTimeField28.roundHalfEven(0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:40.321" + "'", str11.equals("����-��-��T14:31:40.321"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 7914674482L + "'", long31 == 7914674482L);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
        org.joda.time.DateTime.Property property7 = dateTime2.yearOfCentury();
        int int8 = property7.getMaximumValueOverall();
        java.util.Locale locale9 = null;
        int int10 = property7.getMaximumShortTextLength(locale9);
        java.util.Locale locale11 = null;
        java.lang.String str12 = property7.getAsText(locale11);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 99 + "'", int8 == 99);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "19" + "'", str12.equals("19"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime2.withMonthOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        java.util.Locale locale9 = null;
        org.joda.time.DateTime dateTime10 = property7.setCopy("24", locale9);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        int int4 = property3.getMinimumValueOverall();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
        org.joda.time.YearMonthDay yearMonthDay8 = dateTime7.toYearMonthDay();
        long long9 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime11 = dateTime7.withYearOfCentury(31);
        int int12 = dateTime11.getYearOfEra();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(readableInterval6);
        org.junit.Assert.assertNotNull(yearMonthDay8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2031 + "'", int12 == 2031);
    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime.Property property8 = dateTime6.millisOfDay();
//        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
//        int int10 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime6);
//        int int11 = dateTime2.getCenturyOfEra();
//        org.joda.time.DateTime dateTime13 = dateTime2.plusYears(57600);
//        boolean boolean14 = dateTime13.isBeforeNow();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(99);
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter2.printTo(appendable3, (long) 20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        long long8 = offsetDateTimeField5.getDifferenceAsLong((long) (short) -1, (long) 1970);
        java.lang.String str10 = offsetDateTimeField5.getAsText((long) 6);
        long long13 = offsetDateTimeField5.add((long) 52274, (long) ' ');
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "377" + "'", str10.equals("377"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 115252274L + "'", long13 == 115252274L);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        java.util.Locale locale4 = null;
//        int int5 = property3.getMaximumTextLength(locale4);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = property3.getAsShortText(locale6);
//        int int8 = property3.get();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "24" + "'", str7.equals("24"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime2.withHourOfDay(2);
        java.lang.Object obj7 = null;
        boolean boolean8 = dateTime6.equals(obj7);
        org.joda.time.DateTime.Property property9 = dateTime6.dayOfMonth();
        try {
            org.joda.time.DateTime dateTime11 = property9.setCopy("100");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (-38188378142L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(870);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(870, 52, 52273, (int) '#', 365, 14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTime.Property property8 = dateTime6.millisOfDay();
        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
        int int10 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property11 = dateTime6.centuryOfEra();
        org.joda.time.DateTime dateTime13 = dateTime6.withMillisOfDay(1970);
        org.joda.time.DateTime.Property property14 = dateTime6.millisOfSecond();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(readableInterval5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField6 = gregorianChronology5.millis();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.weekOfWeekyear();
        org.joda.time.DurationField durationField8 = gregorianChronology5.hours();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology5.getZone();
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.ReadableInterval readableInterval11 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) readableInterval10);
        org.joda.time.DateTime.Property property13 = dateTime12.weekOfWeekyear();
        org.joda.time.DateTime dateTime15 = dateTime12.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone16 = null;
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forTimeZone(timeZone16);
        org.joda.time.DateTime dateTime18 = dateTime15.withZoneRetainFields(dateTimeZone17);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone19 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone17);
        long long21 = cachedDateTimeZone19.nextTransition((long) (short) 0);
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology5, (org.joda.time.DateTimeZone) cachedDateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone23 = gregorianChronology5.getZone();
        org.joda.time.DurationField durationField24 = gregorianChronology5.days();
        org.joda.time.DurationField durationField25 = gregorianChronology5.months();
        try {
            org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(6, 86399999, 6, 0, (int) (short) 0, (org.joda.time.Chronology) gregorianChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399999 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(readableInterval11);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(cachedDateTimeZone19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9972000000L + "'", long21 == 9972000000L);
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(durationField25);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(52263, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendYearOfEra(100, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendSecondOfDay(366);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test365");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        java.util.Locale locale4 = null;
//        int int5 = property3.getMaximumTextLength(locale4);
//        int int6 = property3.get();
//        org.joda.time.DateTime dateTime7 = property3.getDateTime();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(57600, 'a', 8, 0, (int) (byte) 0, true, (int) (short) 0);
        java.io.DataOutput dataOutput10 = null;
        try {
            dateTimeZoneBuilder0.writeTo("1", dataOutput10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(52, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        java.lang.String str2 = dateTimeFormatter0.print(9972000000L);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970" + "'", str2.equals("1970"));
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        java.lang.String str29 = unsupportedDateTimeField28.getName();
//        java.util.Locale locale30 = null;
//        try {
//            int int31 = unsupportedDateTimeField28.getMaximumShortTextLength(locale30);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:42.326" + "'", str11.equals("����-��-��T14:31:42.326"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "weekyear" + "'", str29.equals("weekyear"));
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int6 = offsetDateTimeField5.getMaximumValue();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField5, 52901, (int) (byte) 0, 20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52901 for clockhourOfHalfday must be in the range [0,20]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 377 + "'", int6 == 377);
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfHour(166, (int) (byte) 10);
//        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatterBuilder3.toPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(166, (int) (byte) 10);
//        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatterBuilder8.toPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        boolean boolean11 = dateTimeFormatter10.isParser();
//        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter10.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        boolean boolean14 = dateTimeFormatter13.isParser();
//        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter13.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray18 = new org.joda.time.format.DateTimeParser[] { dateTimeParser12, dateTimeParser15, dateTimeParser17 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder3.append(dateTimePrinter9, dateTimeParserArray18);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder3.appendDayOfWeekShortText();
//        java.util.TimeZone timeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now(dateTimeZone22);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval25 = null;
//        org.joda.time.ReadableInterval readableInterval26 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval25);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((java.lang.Object) readableInterval25);
//        org.joda.time.DateTime.Property property28 = dateTime27.weekOfWeekyear();
//        org.joda.time.DateTime dateTime30 = dateTime27.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay31 = dateTime30.toTimeOfDay();
//        java.lang.String str32 = dateTimeFormatter24.print((org.joda.time.ReadablePartial) timeOfDay31);
//        org.joda.time.DateTime dateTime33 = dateTime23.withFields((org.joda.time.ReadablePartial) timeOfDay31);
//        org.joda.time.DateTime dateTime35 = dateTime23.withEra(0);
//        org.joda.time.DateTime.Property property36 = dateTime35.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType37 = property36.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType37, "377");
//        org.joda.time.ReadableInterval readableInterval40 = null;
//        org.joda.time.ReadableInterval readableInterval41 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval40);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((java.lang.Object) readableInterval40);
//        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
//        int int44 = property43.getMinimumValueOverall();
//        org.joda.time.DurationField durationField45 = property43.getDurationField();
//        long long48 = durationField45.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField49 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField45);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder3.appendFixedSignedDecimal(dateTimeFieldType37, 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology52 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField53 = gregorianChronology52.millis();
//        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology52.weekOfWeekyear();
//        org.joda.time.DurationField durationField55 = gregorianChronology52.hours();
//        int int56 = gregorianChronology52.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField57 = gregorianChronology52.days();
//        org.joda.time.ReadableInterval readableInterval58 = null;
//        org.joda.time.ReadableInterval readableInterval59 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval58);
//        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((java.lang.Object) readableInterval58);
//        org.joda.time.YearMonthDay yearMonthDay61 = dateTime60.toYearMonthDay();
//        org.joda.time.DateTime.Property property62 = dateTime60.yearOfCentury();
//        org.joda.time.DateTime dateTime64 = property62.addToCopy((-870));
//        org.joda.time.DurationField durationField65 = property62.getDurationField();
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField66 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType37, durationField57, durationField65);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range duration field must be precise");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimePrinter4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimePrinter9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(dateTimeParser12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTimeParser15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTimeParser17);
//        org.junit.Assert.assertNotNull(dateTimeParserArray18);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertNotNull(readableInterval26);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(timeOfDay31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "����-��-��T14:31:42.376" + "'", str32.equals("����-��-��T14:31:42.376"));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFieldType37);
//        org.junit.Assert.assertNotNull(readableInterval41);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertNotNull(durationField45);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-1209599903L) + "'", long48 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
//        org.junit.Assert.assertNotNull(gregorianChronology52);
//        org.junit.Assert.assertNotNull(durationField53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertNotNull(durationField55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
//        org.junit.Assert.assertNotNull(durationField57);
//        org.junit.Assert.assertNotNull(readableInterval59);
//        org.junit.Assert.assertNotNull(yearMonthDay61);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(durationField65);
//    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test373");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        try {
//            long long30 = unsupportedDateTimeField28.roundHalfCeiling(364L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:42.425" + "'", str11.equals("����-��-��T14:31:42.425"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
//        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
//        org.joda.time.ReadableInterval readableInterval8 = null;
//        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) readableInterval8);
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
//        org.joda.time.DateTime.Property property12 = dateTime10.secondOfMinute();
//        org.joda.time.DateTime dateTime14 = dateTime10.withMonthOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekOfWeekyear();
//        org.joda.time.TimeOfDay timeOfDay16 = dateTime14.toTimeOfDay();
//        int int17 = offsetDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay16);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
//        java.util.TimeZone timeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now(dateTimeZone20);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval23 = null;
//        org.joda.time.ReadableInterval readableInterval24 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval23);
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) readableInterval23);
//        org.joda.time.DateTime.Property property26 = dateTime25.weekOfWeekyear();
//        org.joda.time.DateTime dateTime28 = dateTime25.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay29 = dateTime28.toTimeOfDay();
//        java.lang.String str30 = dateTimeFormatter22.print((org.joda.time.ReadablePartial) timeOfDay29);
//        org.joda.time.DateTime dateTime31 = dateTime21.withFields((org.joda.time.ReadablePartial) timeOfDay29);
//        boolean boolean32 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) timeOfDay29);
//        java.lang.String str33 = dateTimeFormatter18.print((org.joda.time.ReadablePartial) timeOfDay29);
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = offsetDateTimeField5.getAsText((org.joda.time.ReadablePartial) timeOfDay29, 100, locale35);
//        org.joda.time.ReadableInterval readableInterval37 = null;
//        org.joda.time.ReadableInterval readableInterval38 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval37);
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((java.lang.Object) readableInterval37);
//        org.joda.time.DateTime.Property property40 = dateTime39.weekOfWeekyear();
//        org.joda.time.DateTime dateTime42 = dateTime39.withWeekOfWeekyear((int) '4');
//        java.util.TimeZone timeZone43 = null;
//        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forTimeZone(timeZone43);
//        org.joda.time.DateTime dateTime45 = dateTime42.withZoneRetainFields(dateTimeZone44);
//        org.joda.time.DateTime dateTime48 = dateTime42.withDurationAdded((long) 100, 0);
//        org.joda.time.DateTime dateTime50 = dateTime42.minusYears(1970);
//        org.joda.time.ReadableInterval readableInterval51 = null;
//        org.joda.time.ReadableInterval readableInterval52 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval51);
//        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((java.lang.Object) readableInterval51);
//        org.joda.time.MutableDateTime mutableDateTime54 = dateTime53.toMutableDateTime();
//        org.joda.time.DateTime.Property property55 = dateTime53.secondOfMinute();
//        org.joda.time.DateTime dateTime57 = dateTime53.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime58 = dateTime53.toLocalDateTime();
//        org.joda.time.DateTime dateTime59 = dateTime50.withFields((org.joda.time.ReadablePartial) localDateTime58);
//        org.joda.time.chrono.GregorianChronology gregorianChronology61 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone62 = gregorianChronology61.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter63 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter64 = dateTimeFormatter63.withOffsetParsed();
//        org.joda.time.ReadableInterval readableInterval65 = null;
//        org.joda.time.ReadableInterval readableInterval66 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval65);
//        org.joda.time.DateTime dateTime67 = new org.joda.time.DateTime((java.lang.Object) readableInterval65);
//        org.joda.time.MutableDateTime mutableDateTime68 = dateTime67.toMutableDateTime();
//        org.joda.time.DateTime.Property property69 = dateTime67.secondOfMinute();
//        org.joda.time.DateTime dateTime71 = dateTime67.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime72 = dateTime67.toLocalDateTime();
//        java.lang.String str73 = dateTimeFormatter64.print((org.joda.time.ReadablePartial) localDateTime72);
//        int[] intArray75 = gregorianChronology61.get((org.joda.time.ReadablePartial) localDateTime72, (-1209599903L));
//        try {
//            int[] intArray77 = offsetDateTimeField5.set((org.joda.time.ReadablePartial) localDateTime58, 52286, intArray75, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for clockhourOfHalfday must be in the range [366,377]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
//        org.junit.Assert.assertNotNull(readableInterval9);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(timeOfDay16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 366 + "'", int17 == 366);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertNotNull(readableInterval24);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(timeOfDay29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "����-��-��T14:31:42.492" + "'", str30.equals("����-��-��T14:31:42.492"));
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "����W���T143142" + "'", str33.equals("����W���T143142"));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "100" + "'", str36.equals("100"));
//        org.junit.Assert.assertNotNull(readableInterval38);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(readableInterval52);
//        org.junit.Assert.assertNotNull(mutableDateTime54);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(localDateTime58);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(gregorianChronology61);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertNotNull(dateTimeFormatter63);
//        org.junit.Assert.assertNotNull(dateTimeFormatter64);
//        org.junit.Assert.assertNotNull(readableInterval66);
//        org.junit.Assert.assertNotNull(mutableDateTime68);
//        org.junit.Assert.assertNotNull(property69);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(localDateTime72);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "2019-W24" + "'", str73.equals("2019-W24"));
//        org.junit.Assert.assertNotNull(intArray75);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.DateTime dateTime13 = dateTime10.withZoneRetainFields(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        long long16 = cachedDateTimeZone14.nextTransition((long) (short) 0);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology18.getZone();
        java.lang.String str20 = dateTimeZone19.getID();
        boolean boolean21 = zonedChronology17.equals((java.lang.Object) dateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone22 = zonedChronology17.getZone();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        try {
            int[] intArray25 = zonedChronology17.get(readablePeriod23, (long) 99);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(readableInterval6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9972000000L + "'", long16 == 9972000000L);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeZone22);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.millisOfDay();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTime.Property property8 = dateTime6.millisOfDay();
        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
        int int10 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property11 = dateTime6.centuryOfEra();
        org.joda.time.DateTime dateTime12 = property11.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime13 = dateTime12.toDateTime();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(readableInterval5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatterBuilder3.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatterBuilder8.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean11 = dateTimeFormatter10.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean14 = dateTimeFormatter13.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter13.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray18 = new org.joda.time.format.DateTimeParser[] { dateTimeParser12, dateTimeParser15, dateTimeParser17 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder3.append(dateTimePrinter9, dateTimeParserArray18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder3.appendDayOfWeekShortText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder20.appendYear((-28800000), 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeParserArray18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(2000, 52, 52288104, 52286, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52286 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 52284, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 522840 + "'", int2 == 522840);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DurationField durationField12 = iSOChronology11.halfdays();
        org.joda.time.DurationField durationField13 = iSOChronology11.weeks();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology11.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology17 = iSOChronology11.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(chronology17);
        try {
            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(870, (int) (byte) -1, 52258, (-870), (int) 'a', 52, 0, chronology17);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -870 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(chronology17);
    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime.Property property8 = dateTime6.millisOfDay();
//        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
//        int int10 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime12 = dateTime6.plusMinutes(377);
//        int int13 = dateTime6.getDayOfYear();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 166 + "'", int13 == 166);
//    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
//        int int5 = dateTime2.getMillisOfDay();
//        org.joda.time.DateTime.Property property6 = dateTime2.secondOfDay();
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.ReadableInterval readableInterval8 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) readableInterval7);
//        org.joda.time.DateTime.Property property10 = dateTime9.weekOfWeekyear();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfDay();
//        org.joda.time.DateTime dateTime13 = dateTime9.withHourOfDay(2);
//        java.lang.Object obj14 = null;
//        boolean boolean15 = dateTime13.equals(obj14);
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime13.withChronology(chronology16);
//        boolean boolean18 = dateTime2.equals((java.lang.Object) chronology16);
//        int int19 = dateTime2.getSecondOfDay();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52303605 + "'", int5 == 52303605);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(readableInterval8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 52303 + "'", int19 == 52303);
//    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        java.lang.String str29 = unsupportedDateTimeField28.getName();
//        long long32 = unsupportedDateTimeField28.getDifferenceAsLong(3600000L, 0L);
//        try {
//            long long34 = unsupportedDateTimeField28.remainder((long) 960);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:44.069" + "'", str11.equals("����-��-��T14:31:44.069"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "weekyear" + "'", str29.equals("weekyear"));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
        java.lang.String str9 = offsetDateTimeField5.getAsText((long) 870);
        boolean boolean11 = offsetDateTimeField5.isLeap((long) (short) -1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "377" + "'", str9.equals("377"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(52263, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendYearOfEra(100, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendHalfdayOfDayText();
        boolean boolean11 = dateTimeFormatterBuilder9.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        long long31 = unsupportedDateTimeField28.add((long) 52274482, (long) 13);
//        java.util.TimeZone timeZone32 = null;
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forTimeZone(timeZone32);
//        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now(dateTimeZone33);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.ReadableInterval readableInterval37 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((java.lang.Object) readableInterval36);
//        org.joda.time.DateTime.Property property39 = dateTime38.weekOfWeekyear();
//        org.joda.time.DateTime dateTime41 = dateTime38.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay42 = dateTime41.toTimeOfDay();
//        java.lang.String str43 = dateTimeFormatter35.print((org.joda.time.ReadablePartial) timeOfDay42);
//        org.joda.time.DateTime dateTime44 = dateTime34.withFields((org.joda.time.ReadablePartial) timeOfDay42);
//        java.util.Locale locale46 = null;
//        try {
//            java.lang.String str47 = unsupportedDateTimeField28.getAsText((org.joda.time.ReadablePartial) timeOfDay42, (int) (byte) -1, locale46);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:44.133" + "'", str11.equals("����-��-��T14:31:44.133"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 7914674482L + "'", long31 == 7914674482L);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTimeFormatter35);
//        org.junit.Assert.assertNotNull(readableInterval37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(timeOfDay42);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "����-��-��T14:31:44.155" + "'", str43.equals("����-��-��T14:31:44.155"));
//        org.junit.Assert.assertNotNull(dateTime44);
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMinuteOfDay(57600);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap6 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
//        org.joda.time.DateTime.Property property6 = dateTime2.year();
//        int int7 = dateTime2.getWeekOfWeekyear();
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval12 = null;
//        org.joda.time.ReadableInterval readableInterval13 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval12);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) readableInterval12);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekOfWeekyear();
//        org.joda.time.DateTime dateTime17 = dateTime14.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay18 = dateTime17.toTimeOfDay();
//        java.lang.String str19 = dateTimeFormatter11.print((org.joda.time.ReadablePartial) timeOfDay18);
//        org.joda.time.DateTime dateTime20 = dateTime10.withFields((org.joda.time.ReadablePartial) timeOfDay18);
//        org.joda.time.DateTime dateTime22 = dateTime10.withEra(0);
//        org.joda.time.DateTime.Property property23 = dateTime22.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, "377");
//        org.joda.time.DateTime dateTime28 = dateTime2.withField(dateTimeFieldType24, 3);
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(readableInterval13);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(timeOfDay18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "����-��-��T14:31:44.190" + "'", str19.equals("����-��-��T14:31:44.190"));
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertNotNull(dateTime28);
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatterBuilder3.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatterBuilder8.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean11 = dateTimeFormatter10.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean14 = dateTimeFormatter13.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter13.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray18 = new org.joda.time.format.DateTimeParser[] { dateTimeParser12, dateTimeParser15, dateTimeParser17 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder3.append(dateTimePrinter9, dateTimeParserArray18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder3.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendClockhourOfDay(52275274);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder20.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeParserArray18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 365);
//        int int11 = offsetDateTimeField9.getMinimumValue((long) 19);
//        org.joda.time.ReadableInterval readableInterval12 = null;
//        org.joda.time.ReadableInterval readableInterval13 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval12);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) readableInterval12);
//        org.joda.time.MutableDateTime mutableDateTime15 = dateTime14.toMutableDateTime();
//        org.joda.time.DateTime.Property property16 = dateTime14.secondOfMinute();
//        org.joda.time.DateTime dateTime18 = dateTime14.withMonthOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property19 = dateTime18.weekOfWeekyear();
//        org.joda.time.TimeOfDay timeOfDay20 = dateTime18.toTimeOfDay();
//        int int21 = offsetDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay20);
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology23);
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology23.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, 365);
//        int int29 = offsetDateTimeField27.getMinimumValue((long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField27, (int) '#');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter32.withOffsetParsed();
//        org.joda.time.ReadableInterval readableInterval34 = null;
//        org.joda.time.ReadableInterval readableInterval35 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval34);
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((java.lang.Object) readableInterval34);
//        org.joda.time.MutableDateTime mutableDateTime37 = dateTime36.toMutableDateTime();
//        org.joda.time.DateTime.Property property38 = dateTime36.secondOfMinute();
//        org.joda.time.DateTime dateTime40 = dateTime36.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime41 = dateTime36.toLocalDateTime();
//        java.lang.String str42 = dateTimeFormatter33.print((org.joda.time.ReadablePartial) localDateTime41);
//        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone44 = gregorianChronology43.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = dateTimeFormatter45.withOffsetParsed();
//        org.joda.time.ReadableInterval readableInterval47 = null;
//        org.joda.time.ReadableInterval readableInterval48 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval47);
//        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((java.lang.Object) readableInterval47);
//        org.joda.time.MutableDateTime mutableDateTime50 = dateTime49.toMutableDateTime();
//        org.joda.time.DateTime.Property property51 = dateTime49.secondOfMinute();
//        org.joda.time.DateTime dateTime53 = dateTime49.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime54 = dateTime49.toLocalDateTime();
//        java.lang.String str55 = dateTimeFormatter46.print((org.joda.time.ReadablePartial) localDateTime54);
//        int[] intArray57 = gregorianChronology43.get((org.joda.time.ReadablePartial) localDateTime54, (-1209599903L));
//        int int58 = offsetDateTimeField27.getMinimumValue((org.joda.time.ReadablePartial) localDateTime41, intArray57);
//        try {
//            gregorianChronology1.validate((org.joda.time.ReadablePartial) timeOfDay20, intArray57);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must not be larger than 23");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 366 + "'", int11 == 366);
//        org.junit.Assert.assertNotNull(readableInterval13);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(timeOfDay20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 366 + "'", int21 == 366);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 366 + "'", int29 == 366);
//        org.junit.Assert.assertNotNull(dateTimeFormatter32);
//        org.junit.Assert.assertNotNull(dateTimeFormatter33);
//        org.junit.Assert.assertNotNull(readableInterval35);
//        org.junit.Assert.assertNotNull(mutableDateTime37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(localDateTime41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "2019-W24" + "'", str42.equals("2019-W24"));
//        org.junit.Assert.assertNotNull(gregorianChronology43);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(dateTimeFormatter45);
//        org.junit.Assert.assertNotNull(dateTimeFormatter46);
//        org.junit.Assert.assertNotNull(readableInterval48);
//        org.junit.Assert.assertNotNull(mutableDateTime50);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(localDateTime54);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "2019-W24" + "'", str55.equals("2019-W24"));
//        org.junit.Assert.assertNotNull(intArray57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 366 + "'", int58 == 366);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfDay();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.plus(readableDuration5);
        org.joda.time.DateTime dateTime8 = dateTime2.minusHours(377);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
        org.joda.time.DateTime dateTime6 = property4.addToCopy((-870));
        org.joda.time.ReadableInstant readableInstant7 = null;
        int int8 = property4.getDifference(readableInstant7);
        java.lang.String str9 = property4.getName();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "yearOfCentury" + "'", str9.equals("yearOfCentury"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0, 52297838, 52258, (int) (byte) 100, 8, 21);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (-5756400001L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test397");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        java.lang.String str29 = unsupportedDateTimeField28.getName();
//        try {
//            int int30 = unsupportedDateTimeField28.getMaximumValue();
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:44.848" + "'", str11.equals("����-��-��T14:31:44.848"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "weekyear" + "'", str29.equals("weekyear"));
//    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.DateTime dateTime13 = dateTime10.withZoneRetainFields(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        long long16 = cachedDateTimeZone14.nextTransition((long) (short) 0);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
        java.lang.String str18 = zonedChronology17.toString();
        java.lang.String str19 = zonedChronology17.toString();
        try {
            long long27 = zonedChronology17.getDateTimeMillis(6, 12, 292278993, 2031, 0, 31, 52881764);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2031 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(readableInterval6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9972000000L + "'", long16 == 9972000000L);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]" + "'", str18.equals("ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]" + "'", str19.equals("ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        try {
            org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(52263199);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52263199 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiply(52257628, 52257628);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The calculation caused an overflow: 52257628 * 52257628");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 13, 0, 52275274);
    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test403");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField4 = gregorianChronology3.millis();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.weekOfWeekyear();
//        int int6 = dateTime2.get(dateTimeField5);
//        int int7 = dateTime2.getMillisOfDay();
//        java.util.Locale locale8 = null;
//        java.util.Calendar calendar9 = dateTime2.toCalendar(locale8);
//        int int10 = dateTime2.getHourOfDay();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52305574 + "'", int7 == 52305574);
//        org.junit.Assert.assertNotNull(calendar9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 14 + "'", int10 == 14);
//    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        java.lang.Appendable appendable2 = null;
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) readableInterval3);
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime5.toYearMonthDay();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.minus(readableDuration7);
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.ReadableInterval readableInterval10 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) readableInterval9);
        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
        org.joda.time.DateTime dateTime14 = dateTime11.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone15);
        org.joda.time.DateTime dateTime17 = dateTime14.withZoneRetainFields(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = dateTime5.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime19 = dateTime5.toDateTime();
        org.joda.time.DateTime dateTime21 = dateTime19.minusYears(2019);
        try {
            dateTimeFormatter0.printTo(appendable2, (org.joda.time.ReadableInstant) dateTime19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(readableInterval4);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(readableInterval10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '#');
        int int10 = offsetDateTimeField5.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 366 + "'", int10 == 366);
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        try {
//            long long31 = unsupportedDateTimeField28.set(0L, "����-��-��T14:31:23.923");
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:45.805" + "'", str11.equals("����-��-��T14:31:45.805"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("weekOfWeekyear", (java.lang.Number) 1L, (java.lang.Number) (byte) 10, number3);
        java.lang.Number number5 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.Number number9 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException("weekOfWeekyear", (java.lang.Number) 1L, (java.lang.Number) (byte) 10, number9);
        java.lang.Number number11 = illegalFieldValueException10.getIllegalNumberValue();
        java.lang.String str12 = illegalFieldValueException10.getIllegalStringValue();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException10);
        org.joda.time.DurationFieldType durationFieldType14 = illegalFieldValueException10.getDurationFieldType();
        org.joda.time.DurationFieldType durationFieldType15 = illegalFieldValueException10.getDurationFieldType();
        java.lang.String str16 = illegalFieldValueException10.getFieldName();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1L + "'", number5.equals(1L));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 1L + "'", number11.equals(1L));
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(durationFieldType14);
        org.junit.Assert.assertNull(durationFieldType15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "weekOfWeekyear" + "'", str16.equals("weekOfWeekyear"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
//        int int6 = dateTime2.getSecondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        boolean boolean8 = dateTime2.isSupported(dateTimeFieldType7);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime2.toMutableDateTimeISO();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52305 + "'", int6 == 52305);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        long long31 = unsupportedDateTimeField28.add((long) 52274482, (long) 13);
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology33);
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology33.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField35, 365);
//        java.lang.String str38 = offsetDateTimeField37.toString();
//        java.util.TimeZone timeZone39 = null;
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forTimeZone(timeZone39);
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now(dateTimeZone40);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval43 = null;
//        org.joda.time.ReadableInterval readableInterval44 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval43);
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((java.lang.Object) readableInterval43);
//        org.joda.time.DateTime.Property property46 = dateTime45.weekOfWeekyear();
//        org.joda.time.DateTime dateTime48 = dateTime45.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay49 = dateTime48.toTimeOfDay();
//        java.lang.String str50 = dateTimeFormatter42.print((org.joda.time.ReadablePartial) timeOfDay49);
//        org.joda.time.DateTime dateTime51 = dateTime41.withFields((org.joda.time.ReadablePartial) timeOfDay49);
//        java.util.Locale locale53 = null;
//        java.lang.String str54 = offsetDateTimeField37.getAsText((org.joda.time.ReadablePartial) timeOfDay49, 52278114, locale53);
//        try {
//            int int55 = unsupportedDateTimeField28.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay49);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:46.026" + "'", str11.equals("����-��-��T14:31:46.026"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 7914674482L + "'", long31 == 7914674482L);
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "DateTimeField[clockhourOfHalfday]" + "'", str38.equals("DateTimeField[clockhourOfHalfday]"));
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTimeFormatter42);
//        org.junit.Assert.assertNotNull(readableInterval44);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(timeOfDay49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "����-��-��T14:31:46.032" + "'", str50.equals("����-��-��T14:31:46.032"));
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "52278114" + "'", str54.equals("52278114"));
//    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 52275313, 52881764);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2764410765092132L + "'", long2 == 2764410765092132L);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.DateTime dateTime13 = dateTime10.withZoneRetainFields(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        long long16 = cachedDateTimeZone14.nextTransition((long) (short) 0);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology18.getZone();
        java.lang.String str20 = dateTimeZone19.getID();
        boolean boolean21 = zonedChronology17.equals((java.lang.Object) dateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone22 = zonedChronology17.getZone();
        org.joda.time.DateTimeField dateTimeField23 = zonedChronology17.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField24 = zonedChronology17.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology26);
        org.joda.time.DateTimeZone dateTimeZone28 = gregorianChronology26.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone30 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone28);
        org.joda.time.Chronology chronology31 = zonedChronology17.withZone(dateTimeZone28);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(readableInterval6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9972000000L + "'", long16 == 9972000000L);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(cachedDateTimeZone30);
        org.junit.Assert.assertNotNull(chronology31);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "weekOfWeekyear", 24, (-870));
        long long6 = fixedDateTimeZone4.nextTransition((long) 2019);
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        int int9 = fixedDateTimeZone4.getStandardOffset(0L);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-870) + "'", int9 == (-870));
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test416");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        long long31 = unsupportedDateTimeField28.add((long) 52274482, (long) 13);
//        try {
//            int int33 = unsupportedDateTimeField28.getMaximumValue((long) 52286);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:47.085" + "'", str11.equals("����-��-��T14:31:47.085"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 7914674482L + "'", long31 == 7914674482L);
//    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        java.lang.String str29 = unsupportedDateTimeField28.getName();
//        long long32 = unsupportedDateTimeField28.getDifferenceAsLong(3600000L, 0L);
//        org.joda.time.ReadableInterval readableInterval33 = null;
//        org.joda.time.ReadableInterval readableInterval34 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval33);
//        org.joda.time.Chronology chronology35 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval34);
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime(chronology35);
//        org.joda.time.YearMonthDay yearMonthDay37 = dateTime36.toYearMonthDay();
//        java.util.Locale locale38 = null;
//        try {
//            java.lang.String str39 = unsupportedDateTimeField28.getAsText((org.joda.time.ReadablePartial) yearMonthDay37, locale38);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:47.530" + "'", str11.equals("����-��-��T14:31:47.530"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "weekyear" + "'", str29.equals("weekyear"));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//        org.junit.Assert.assertNotNull(readableInterval34);
//        org.junit.Assert.assertNotNull(chronology35);
//        org.junit.Assert.assertNotNull(yearMonthDay37);
//    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.ReadableInterval readableInterval7 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) readableInterval6);
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime8.toYearMonthDay();
        int[] intArray10 = new int[] {};
        int int11 = offsetDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay9, intArray10);
        long long13 = offsetDateTimeField5.roundHalfFloor(0L);
        java.util.Locale locale16 = null;
        try {
            long long17 = offsetDateTimeField5.set((long) 100, "����-��-��T14:31:43.675", locale16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"����-��-��T14:31:43.675\" for clockhourOfHalfday is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(readableInterval7);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 366 + "'", int11 == 366);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        org.joda.time.DateTime dateTime8 = dateTime5.withZoneRetainFields(dateTimeZone7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        long long11 = cachedDateTimeZone9.nextTransition((long) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        org.joda.time.DurationField durationField13 = gregorianChronology12.seconds();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9972000000L + "'", long11 == 9972000000L);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        org.joda.time.DateTime dateTime8 = dateTime5.withZoneRetainFields(dateTimeZone7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        long long11 = cachedDateTimeZone9.nextTransition((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone12 = cachedDateTimeZone9.getUncachedZone();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        long long17 = iSOChronology13.add(readablePeriod14, (long) 52275313, (int) '#');
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9972000000L + "'", long11 == 9972000000L);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52275313L + "'", long17 == 52275313L);
    }

//    @Test
//    public void test421() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test421");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        java.lang.Appendable appendable1 = null;
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval6 = null;
//        org.joda.time.ReadableInterval readableInterval7 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval6);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) readableInterval6);
//        org.joda.time.DateTime.Property property9 = dateTime8.weekOfWeekyear();
//        org.joda.time.DateTime dateTime11 = dateTime8.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay12 = dateTime11.toTimeOfDay();
//        java.lang.String str13 = dateTimeFormatter5.print((org.joda.time.ReadablePartial) timeOfDay12);
//        org.joda.time.DateTime dateTime14 = dateTime4.withFields((org.joda.time.ReadablePartial) timeOfDay12);
//        org.joda.time.DateTime dateTime16 = dateTime4.withEra(0);
//        org.joda.time.DateTime.Property property17 = dateTime16.weekyear();
//        java.util.TimeZone timeZone18 = null;
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now(dateTimeZone19);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval22 = null;
//        org.joda.time.ReadableInterval readableInterval23 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval22);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((java.lang.Object) readableInterval22);
//        org.joda.time.DateTime.Property property25 = dateTime24.weekOfWeekyear();
//        org.joda.time.DateTime dateTime27 = dateTime24.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay28 = dateTime27.toTimeOfDay();
//        java.lang.String str29 = dateTimeFormatter21.print((org.joda.time.ReadablePartial) timeOfDay28);
//        org.joda.time.DateTime dateTime30 = dateTime20.withFields((org.joda.time.ReadablePartial) timeOfDay28);
//        org.joda.time.DateTime dateTime31 = dateTime16.withFields((org.joda.time.ReadablePartial) timeOfDay28);
//        try {
//            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) timeOfDay28);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(readableInterval7);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(timeOfDay12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "����-��-��T14:31:47.710" + "'", str13.equals("����-��-��T14:31:47.710"));
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(readableInterval23);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(timeOfDay28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "����-��-��T14:31:47.712" + "'", str29.equals("����-��-��T14:31:47.712"));
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime31);
//    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
        long long9 = offsetDateTimeField5.roundHalfFloor(0L);
        org.joda.time.DurationField durationField10 = offsetDateTimeField5.getRangeDurationField();
        org.joda.time.DurationFieldType durationFieldType11 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField12 = new org.joda.time.field.DecoratedDurationField(durationField10, durationFieldType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatterBuilder3.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatterBuilder8.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean11 = dateTimeFormatter10.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean14 = dateTimeFormatter13.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter13.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray18 = new org.joda.time.format.DateTimeParser[] { dateTimeParser12, dateTimeParser15, dateTimeParser17 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder3.append(dateTimePrinter9, dateTimeParserArray18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder3.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder21.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter25 = dateTimeFormatterBuilder24.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder26.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter30 = dateTimeFormatterBuilder29.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean32 = dateTimeFormatter31.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser33 = dateTimeFormatter31.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean35 = dateTimeFormatter34.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser36 = dateTimeFormatter34.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser38 = dateTimeFormatter37.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray39 = new org.joda.time.format.DateTimeParser[] { dateTimeParser33, dateTimeParser36, dateTimeParser38 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder24.append(dateTimePrinter30, dateTimeParserArray39);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser42 = dateTimeFormatter41.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter30, dateTimeParser42);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder20.append(dateTimePrinter30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeParserArray18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimePrinter25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimePrinter30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dateTimeParser33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeParser36);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(dateTimeParser38);
        org.junit.Assert.assertNotNull(dateTimeParserArray39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(dateTimeParser42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        java.lang.String str29 = unsupportedDateTimeField28.getName();
//        long long32 = unsupportedDateTimeField28.getDifferenceAsLong(3600000L, 0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology34);
//        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology34.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, 365);
//        int int40 = offsetDateTimeField38.getMinimumValue((long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField38, (int) '#');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = dateTimeFormatter43.withOffsetParsed();
//        org.joda.time.ReadableInterval readableInterval45 = null;
//        org.joda.time.ReadableInterval readableInterval46 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval45);
//        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((java.lang.Object) readableInterval45);
//        org.joda.time.MutableDateTime mutableDateTime48 = dateTime47.toMutableDateTime();
//        org.joda.time.DateTime.Property property49 = dateTime47.secondOfMinute();
//        org.joda.time.DateTime dateTime51 = dateTime47.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime52 = dateTime47.toLocalDateTime();
//        java.lang.String str53 = dateTimeFormatter44.print((org.joda.time.ReadablePartial) localDateTime52);
//        org.joda.time.chrono.GregorianChronology gregorianChronology54 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone55 = gregorianChronology54.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter56 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter57 = dateTimeFormatter56.withOffsetParsed();
//        org.joda.time.ReadableInterval readableInterval58 = null;
//        org.joda.time.ReadableInterval readableInterval59 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval58);
//        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((java.lang.Object) readableInterval58);
//        org.joda.time.MutableDateTime mutableDateTime61 = dateTime60.toMutableDateTime();
//        org.joda.time.DateTime.Property property62 = dateTime60.secondOfMinute();
//        org.joda.time.DateTime dateTime64 = dateTime60.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime65 = dateTime60.toLocalDateTime();
//        java.lang.String str66 = dateTimeFormatter57.print((org.joda.time.ReadablePartial) localDateTime65);
//        int[] intArray68 = gregorianChronology54.get((org.joda.time.ReadablePartial) localDateTime65, (-1209599903L));
//        int int69 = offsetDateTimeField38.getMinimumValue((org.joda.time.ReadablePartial) localDateTime52, intArray68);
//        java.util.Locale locale70 = null;
//        try {
//            java.lang.String str71 = unsupportedDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDateTime52, locale70);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:47.922" + "'", str11.equals("����-��-��T14:31:47.922"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "weekyear" + "'", str29.equals("weekyear"));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 366 + "'", int40 == 366);
//        org.junit.Assert.assertNotNull(dateTimeFormatter43);
//        org.junit.Assert.assertNotNull(dateTimeFormatter44);
//        org.junit.Assert.assertNotNull(readableInterval46);
//        org.junit.Assert.assertNotNull(mutableDateTime48);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(localDateTime52);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "2019-W24" + "'", str53.equals("2019-W24"));
//        org.junit.Assert.assertNotNull(gregorianChronology54);
//        org.junit.Assert.assertNotNull(dateTimeZone55);
//        org.junit.Assert.assertNotNull(dateTimeFormatter56);
//        org.junit.Assert.assertNotNull(dateTimeFormatter57);
//        org.junit.Assert.assertNotNull(readableInterval59);
//        org.junit.Assert.assertNotNull(mutableDateTime61);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(localDateTime65);
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "2019-W24" + "'", str66.equals("2019-W24"));
//        org.junit.Assert.assertNotNull(intArray68);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 366 + "'", int69 == 366);
//    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendFractionOfHour(24, 52257628);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendTwoDigitWeekyear((int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendWeekyear(52263, (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder8.appendYearOfEra(100, (int) ' ');
//        java.util.TimeZone timeZone17 = null;
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forTimeZone(timeZone17);
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval21 = null;
//        org.joda.time.ReadableInterval readableInterval22 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval21);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((java.lang.Object) readableInterval21);
//        org.joda.time.DateTime.Property property24 = dateTime23.weekOfWeekyear();
//        org.joda.time.DateTime dateTime26 = dateTime23.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay27 = dateTime26.toTimeOfDay();
//        java.lang.String str28 = dateTimeFormatter20.print((org.joda.time.ReadablePartial) timeOfDay27);
//        org.joda.time.DateTime dateTime29 = dateTime19.withFields((org.joda.time.ReadablePartial) timeOfDay27);
//        org.joda.time.DateTime dateTime31 = dateTime19.withEra(0);
//        org.joda.time.DateTime.Property property32 = dateTime31.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder8.appendFixedSignedDecimal(dateTimeFieldType33, 1970);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder7.appendFixedSignedDecimal(dateTimeFieldType33, 166);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertNotNull(readableInterval22);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(timeOfDay27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "����-��-��T14:31:47.975" + "'", str28.equals("����-��-��T14:31:47.975"));
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gregorianChronology1.millis();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.weekOfWeekyear();
        org.joda.time.DurationField durationField4 = gregorianChronology1.hours();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology1.getZone();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.ReadableInterval readableInterval7 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) readableInterval6);
        org.joda.time.DateTime.Property property9 = dateTime8.weekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime8.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
        org.joda.time.DateTime dateTime14 = dateTime11.withZoneRetainFields(dateTimeZone13);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone13);
        long long17 = cachedDateTimeZone15.nextTransition((long) (short) 0);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeZone) cachedDateTimeZone15);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology19.getZone();
        java.lang.String str21 = dateTimeZone20.getID();
        boolean boolean22 = zonedChronology18.equals((java.lang.Object) dateTimeZone20);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (-28800000), (org.joda.time.Chronology) zonedChronology18);
        org.joda.time.DateTimeZone dateTimeZone24 = zonedChronology18.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(readableInterval7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9972000000L + "'", long17 == 9972000000L);
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "UTC" + "'", str21.equals("UTC"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeZone24);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        try {
            org.joda.time.DateTime dateTime7 = dateTime5.withDayOfWeek(52286);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52286 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        java.lang.String str29 = unsupportedDateTimeField28.getName();
//        long long32 = unsupportedDateTimeField28.getDifferenceAsLong(3600000L, 0L);
//        org.joda.time.ReadablePartial readablePartial33 = null;
//        int[] intArray35 = null;
//        java.util.Locale locale37 = null;
//        try {
//            int[] intArray38 = unsupportedDateTimeField28.set(readablePartial33, 0, intArray35, "����-��-��T14:31:46.540", locale37);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:48.372" + "'", str11.equals("����-��-��T14:31:48.372"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "weekyear" + "'", str29.equals("weekyear"));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 57600);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withDefaultYear((-870));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        long long31 = unsupportedDateTimeField28.add((long) 52274482, (long) 13);
//        java.util.Locale locale33 = null;
//        try {
//            java.lang.String str34 = unsupportedDateTimeField28.getAsText(52274482, locale33);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:48.652" + "'", str11.equals("����-��-��T14:31:48.652"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 7914674482L + "'", long31 == 7914674482L);
//    }

//    @Test
//    public void test431() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test431");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        try {
//            long long30 = unsupportedDateTimeField28.remainder(1577572274309L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:49.136" + "'", str11.equals("����-��-��T14:31:49.136"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "weekOfWeekyear", 24, (-870));
        long long6 = fixedDateTimeZone4.previousTransition((long) 12775);
        long long9 = fixedDateTimeZone4.adjustOffset((long) 6, true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 12775L + "'", long6 == 12775L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 6L + "'", long9 == 6L);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException2.prependMessage("����-��-��T14:31:39.672");
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int6 = offsetDateTimeField5.getMaximumValue();
        long long8 = offsetDateTimeField5.roundHalfFloor((long) (byte) 10);
        long long10 = offsetDateTimeField5.roundFloor((long) 365);
        long long12 = offsetDateTimeField5.roundCeiling(0L);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField5.getMaximumTextLength(locale13);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 377 + "'", int6 == 377);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfDay();
        boolean boolean6 = dateTime2.isEqual((long) (-870));
        org.joda.time.DateTime dateTime8 = dateTime2.plusMonths((int) 'a');
        org.joda.time.DateTime.Property property9 = dateTime2.millisOfDay();
        try {
            org.joda.time.DateTime dateTime11 = property9.setCopy("����-��-��T14:31:00.636");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"����-��-��T14:31:00.636\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test436");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime.Property property8 = dateTime6.millisOfDay();
//        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
//        int int10 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime13 = dateTime6.withDurationAdded((long) (short) 0, (int) (byte) 0);
//        boolean boolean15 = dateTime6.isBefore((long) 10);
//        org.joda.time.DateTime.Property property16 = dateTime6.year();
//        org.joda.time.DateTime dateTime18 = dateTime6.plusMinutes((int) (short) 0);
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.yearOfEra();
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(52286, 0, 20, 52881764, 52307, (int) '#', (org.joda.time.Chronology) gregorianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52881764 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 10, 1560609097384L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 15606090973840");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(466);
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter0.printTo(appendable3, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) 52263);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(52263, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendCenturyOfEra(31, 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendDayOfYear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        java.lang.String str29 = unsupportedDateTimeField28.getName();
//        long long32 = unsupportedDateTimeField28.getDifferenceAsLong(3600000L, 0L);
//        java.util.Locale locale34 = null;
//        try {
//            java.lang.String str35 = unsupportedDateTimeField28.getAsShortText(2019L, locale34);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:51.495" + "'", str11.equals("����-��-��T14:31:51.495"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "weekyear" + "'", str29.equals("weekyear"));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test444");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
//        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
//        int int7 = dateTime6.getDayOfYear();
//        org.joda.time.ReadableInterval readableInterval8 = null;
//        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) readableInterval8);
//        org.joda.time.DateTime.Property property11 = dateTime10.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = dateTime10.withWeekOfWeekyear((int) '4');
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime6, (org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime.Property property15 = dateTime10.monthOfYear();
//        org.joda.time.DateTime dateTime16 = property15.roundHalfEvenCopy();
//        java.lang.String str17 = property15.getAsString();
//        java.lang.String str18 = property15.getAsString();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 166 + "'", int7 == 166);
//        org.junit.Assert.assertNotNull(readableInterval9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "6" + "'", str17.equals("6"));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "6" + "'", str18.equals("6"));
//    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("����-��-��T14:31:22.266", (java.lang.Number) (short) 1, (java.lang.Number) 0.0d, (java.lang.Number) 484288086L);
        java.lang.Number number5 = illegalFieldValueException4.getIllegalNumberValue();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 1 + "'", number5.equals((short) 1));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int6 = offsetDateTimeField5.getMaximumValue();
        int int8 = offsetDateTimeField5.getLeapAmount(1577572274309L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 377 + "'", int6 == 377);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendTimeZoneOffset("24", "Property[weekOfWeekyear]", true, (int) 'a', 166);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMillisOfSecond(12775);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test449");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
//        org.joda.time.ReadableInterval readableInterval5 = null;
//        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
//        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
//        org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((int) '4');
//        java.util.TimeZone timeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
//        org.joda.time.DateTime dateTime13 = dateTime10.withZoneRetainFields(dateTimeZone12);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
//        long long16 = cachedDateTimeZone14.nextTransition((long) (short) 0);
//        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology0.getZone();
//        org.joda.time.DurationField durationField19 = gregorianChronology0.days();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology0.year();
//        java.util.TimeZone timeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now(dateTimeZone22);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval25 = null;
//        org.joda.time.ReadableInterval readableInterval26 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval25);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((java.lang.Object) readableInterval25);
//        org.joda.time.DateTime.Property property28 = dateTime27.weekOfWeekyear();
//        org.joda.time.DateTime dateTime30 = dateTime27.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay31 = dateTime30.toTimeOfDay();
//        java.lang.String str32 = dateTimeFormatter24.print((org.joda.time.ReadablePartial) timeOfDay31);
//        org.joda.time.DateTime dateTime33 = dateTime23.withFields((org.joda.time.ReadablePartial) timeOfDay31);
//        org.joda.time.DateTime dateTime35 = dateTime23.withEra(0);
//        org.joda.time.DateTime.Property property36 = dateTime35.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType37 = property36.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType37, "377");
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField41 = new org.joda.time.field.RemainderDateTimeField(dateTimeField20, dateTimeFieldType37, 871);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(readableInterval6);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9972000000L + "'", long16 == 9972000000L);
//        org.junit.Assert.assertNotNull(zonedChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertNotNull(readableInterval26);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(timeOfDay31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "����-��-��T14:31:51.991" + "'", str32.equals("����-��-��T14:31:51.991"));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFieldType37);
//    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test450");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        java.lang.String str29 = unsupportedDateTimeField28.getName();
//        org.joda.time.DurationField durationField30 = unsupportedDateTimeField28.getDurationField();
//        try {
//            java.lang.String str32 = unsupportedDateTimeField28.getAsText((long) 'a');
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:52.030" + "'", str11.equals("����-��-��T14:31:52.030"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "weekyear" + "'", str29.equals("weekyear"));
//        org.junit.Assert.assertNotNull(durationField30);
//    }

//    @Test
//    public void test451() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test451");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
//        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
//        long long9 = offsetDateTimeField5.roundHalfFloor(0L);
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval14 = null;
//        org.joda.time.ReadableInterval readableInterval15 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval14);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) readableInterval14);
//        org.joda.time.DateTime.Property property17 = dateTime16.weekOfWeekyear();
//        org.joda.time.DateTime dateTime19 = dateTime16.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay20 = dateTime19.toTimeOfDay();
//        java.lang.String str21 = dateTimeFormatter13.print((org.joda.time.ReadablePartial) timeOfDay20);
//        org.joda.time.DateTime dateTime22 = dateTime12.withFields((org.joda.time.ReadablePartial) timeOfDay20);
//        org.joda.time.DateTime dateTime24 = dateTime12.withEra(0);
//        org.joda.time.DateTime.Property property25 = dateTime24.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property25.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, "377");
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType26, 52303605, 52305, (int) (short) 10);
//        boolean boolean34 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 52303605, (java.lang.Object) "����-��-��T14:31:31.881");
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(readableInterval15);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(timeOfDay20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "����-��-��T14:31:52.303" + "'", str21.equals("����-��-��T14:31:52.303"));
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "weekOfWeekyear", 24, (-870));
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology7.millis();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.weekOfWeekyear();
        org.joda.time.DurationField durationField10 = gregorianChronology7.hours();
        int int11 = gregorianChronology7.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField12 = gregorianChronology7.seconds();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter6.withChronology((org.joda.time.Chronology) gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(52263, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendYearOfEra(100, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

//    @Test
//    public void test454() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test454");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
//        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
//        long long10 = offsetDateTimeField5.getDifferenceAsLong((long) (byte) -1, (long) 100);
//        long long12 = offsetDateTimeField5.remainder((long) 466);
//        int int14 = offsetDateTimeField5.getMinimumValue((long) 100);
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.ReadableInterval readableInterval16 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((java.lang.Object) readableInterval15);
//        org.joda.time.DateTime.Property property18 = dateTime17.weekOfWeekyear();
//        org.joda.time.DateTime dateTime20 = dateTime17.withWeekOfWeekyear((int) '4');
//        java.util.TimeZone timeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
//        org.joda.time.DateTime dateTime23 = dateTime20.withZoneRetainFields(dateTimeZone22);
//        org.joda.time.ReadableDuration readableDuration24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime23.minus(readableDuration24);
//        org.joda.time.LocalDateTime localDateTime26 = dateTime25.toLocalDateTime();
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = offsetDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDateTime26, locale27);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 466L + "'", long12 == 466L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 366 + "'", int14 == 366);
//        org.junit.Assert.assertNotNull(readableInterval16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(localDateTime26);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2" + "'", str28.equals("2"));
//    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(0, (-870));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-870) + "'", int2 == (-870));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatterBuilder3.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatterBuilder8.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean11 = dateTimeFormatter10.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean14 = dateTimeFormatter13.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter13.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray18 = new org.joda.time.format.DateTimeParser[] { dateTimeParser12, dateTimeParser15, dateTimeParser17 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder3.append(dateTimePrinter9, dateTimeParserArray18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder3.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendTwoDigitYear((-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder20.appendTwoDigitWeekyear(522840, true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeParserArray18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
        org.joda.time.ReadableInterval readableInterval8 = null;
        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) readableInterval8);
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
        org.joda.time.DateTime.Property property12 = dateTime10.secondOfMinute();
        org.joda.time.DateTime dateTime14 = dateTime10.withMonthOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property15 = dateTime14.weekOfWeekyear();
        org.joda.time.TimeOfDay timeOfDay16 = dateTime14.toTimeOfDay();
        int int17 = offsetDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay16);
        long long19 = offsetDateTimeField5.roundFloor((long) 2);
        try {
            long long22 = offsetDateTimeField5.set((long) (-28800000), 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for clockhourOfHalfday must be in the range [366,377]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
        org.junit.Assert.assertNotNull(readableInterval9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(timeOfDay16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 366 + "'", int17 == 366);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(57600, 'a', 8, 0, (int) (byte) 0, true, (int) (short) 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder8.setFixedSavings("", 0);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder8.addCutover(377, 'a', 8, (int) (short) 10, 52278114, true, 52288104);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 12775, (long) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1277500 + "'", int2 == 1277500);
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        org.joda.time.DateTime dateTime8 = dateTime5.withZoneRetainFields(dateTimeZone7);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) cachedDateTimeZone9);
//        int int12 = cachedDateTimeZone9.getStandardOffset((long) 57600);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology14);
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 365);
//        int int20 = offsetDateTimeField18.getMinimumValue((long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField18, (int) '#');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter23.withOffsetParsed();
//        org.joda.time.ReadableInterval readableInterval25 = null;
//        org.joda.time.ReadableInterval readableInterval26 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval25);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((java.lang.Object) readableInterval25);
//        org.joda.time.MutableDateTime mutableDateTime28 = dateTime27.toMutableDateTime();
//        org.joda.time.DateTime.Property property29 = dateTime27.secondOfMinute();
//        org.joda.time.DateTime dateTime31 = dateTime27.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime32 = dateTime27.toLocalDateTime();
//        java.lang.String str33 = dateTimeFormatter24.print((org.joda.time.ReadablePartial) localDateTime32);
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone35 = gregorianChronology34.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter36.withOffsetParsed();
//        org.joda.time.ReadableInterval readableInterval38 = null;
//        org.joda.time.ReadableInterval readableInterval39 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval38);
//        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((java.lang.Object) readableInterval38);
//        org.joda.time.MutableDateTime mutableDateTime41 = dateTime40.toMutableDateTime();
//        org.joda.time.DateTime.Property property42 = dateTime40.secondOfMinute();
//        org.joda.time.DateTime dateTime44 = dateTime40.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime45 = dateTime40.toLocalDateTime();
//        java.lang.String str46 = dateTimeFormatter37.print((org.joda.time.ReadablePartial) localDateTime45);
//        int[] intArray48 = gregorianChronology34.get((org.joda.time.ReadablePartial) localDateTime45, (-1209599903L));
//        int int49 = offsetDateTimeField18.getMinimumValue((org.joda.time.ReadablePartial) localDateTime32, intArray48);
//        boolean boolean50 = cachedDateTimeZone9.isLocalDateTimeGap(localDateTime32);
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-28800000) + "'", int12 == (-28800000));
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 366 + "'", int20 == 366);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertNotNull(readableInterval26);
//        org.junit.Assert.assertNotNull(mutableDateTime28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(localDateTime32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2019-W24" + "'", str33.equals("2019-W24"));
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertNotNull(dateTimeFormatter36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertNotNull(readableInterval39);
//        org.junit.Assert.assertNotNull(mutableDateTime41);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(localDateTime45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "2019-W24" + "'", str46.equals("2019-W24"));
//        org.junit.Assert.assertNotNull(intArray48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 366 + "'", int49 == 366);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test461");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        java.lang.String str29 = unsupportedDateTimeField28.getName();
//        long long32 = unsupportedDateTimeField28.getDifferenceAsLong(3600000L, 0L);
//        org.joda.time.ReadablePartial readablePartial33 = null;
//        java.util.Locale locale34 = null;
//        try {
//            java.lang.String str35 = unsupportedDateTimeField28.getAsShortText(readablePartial33, locale34);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:53.545" + "'", str11.equals("����-��-��T14:31:53.545"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "weekyear" + "'", str29.equals("weekyear"));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 960);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
//        int int6 = dateTime2.getSecondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        boolean boolean8 = dateTime2.isSupported(dateTimeFieldType7);
//        boolean boolean10 = dateTime2.isBefore((long) 870);
//        org.joda.time.ReadableInterval readableInterval11 = null;
//        org.joda.time.ReadableInterval readableInterval12 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) readableInterval11);
//        org.joda.time.MutableDateTime mutableDateTime14 = dateTime13.toMutableDateTime();
//        org.joda.time.DateTime.Property property15 = dateTime13.secondOfMinute();
//        org.joda.time.DateTime dateTime17 = dateTime13.plusMillis((int) (byte) 10);
//        int int18 = dateTime17.getDayOfYear();
//        org.joda.time.DateTime dateTime20 = dateTime17.minusSeconds(166);
//        boolean boolean21 = dateTime2.isEqual((org.joda.time.ReadableInstant) dateTime20);
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52313 + "'", int6 == 52313);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(readableInterval12);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 166 + "'", int18 == 166);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.DateTime dateTime13 = dateTime10.withZoneRetainFields(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        long long16 = cachedDateTimeZone14.nextTransition((long) (short) 0);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone18 = cachedDateTimeZone14.getUncachedZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(readableInterval6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9972000000L + "'", long16 == 9972000000L);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(52273);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test466");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
//        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
//        org.joda.time.ReadableInterval readableInterval8 = null;
//        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) readableInterval8);
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
//        org.joda.time.DateTime.Property property12 = dateTime10.secondOfMinute();
//        org.joda.time.DateTime dateTime14 = dateTime10.withMonthOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekOfWeekyear();
//        org.joda.time.TimeOfDay timeOfDay16 = dateTime14.toTimeOfDay();
//        int int17 = offsetDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay16);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendFractionOfHour(166, (int) (byte) 10);
//        org.joda.time.format.DateTimePrinter dateTimePrinter22 = dateTimeFormatterBuilder21.toPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder23.appendFractionOfHour(166, (int) (byte) 10);
//        org.joda.time.format.DateTimePrinter dateTimePrinter27 = dateTimeFormatterBuilder26.toPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        boolean boolean29 = dateTimeFormatter28.isParser();
//        org.joda.time.format.DateTimeParser dateTimeParser30 = dateTimeFormatter28.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        boolean boolean32 = dateTimeFormatter31.isParser();
//        org.joda.time.format.DateTimeParser dateTimeParser33 = dateTimeFormatter31.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        org.joda.time.format.DateTimeParser dateTimeParser35 = dateTimeFormatter34.getParser();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray36 = new org.joda.time.format.DateTimeParser[] { dateTimeParser30, dateTimeParser33, dateTimeParser35 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder21.append(dateTimePrinter27, dateTimeParserArray36);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder21.appendDayOfWeekShortText();
//        java.util.TimeZone timeZone39 = null;
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forTimeZone(timeZone39);
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now(dateTimeZone40);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval43 = null;
//        org.joda.time.ReadableInterval readableInterval44 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval43);
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((java.lang.Object) readableInterval43);
//        org.joda.time.DateTime.Property property46 = dateTime45.weekOfWeekyear();
//        org.joda.time.DateTime dateTime48 = dateTime45.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay49 = dateTime48.toTimeOfDay();
//        java.lang.String str50 = dateTimeFormatter42.print((org.joda.time.ReadablePartial) timeOfDay49);
//        org.joda.time.DateTime dateTime51 = dateTime41.withFields((org.joda.time.ReadablePartial) timeOfDay49);
//        org.joda.time.DateTime dateTime53 = dateTime41.withEra(0);
//        org.joda.time.DateTime.Property property54 = dateTime53.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType55 = property54.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException57 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType55, "377");
//        org.joda.time.ReadableInterval readableInterval58 = null;
//        org.joda.time.ReadableInterval readableInterval59 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval58);
//        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((java.lang.Object) readableInterval58);
//        org.joda.time.DateTime.Property property61 = dateTime60.weekOfWeekyear();
//        int int62 = property61.getMinimumValueOverall();
//        org.joda.time.DurationField durationField63 = property61.getDurationField();
//        long long66 = durationField63.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField67 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType55, durationField63);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder21.appendFixedSignedDecimal(dateTimeFieldType55, 100);
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField71 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType55, 52313);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
//        org.junit.Assert.assertNotNull(readableInterval9);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(timeOfDay16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 366 + "'", int17 == 366);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
//        org.junit.Assert.assertNotNull(dateTimePrinter22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(dateTimePrinter27);
//        org.junit.Assert.assertNotNull(dateTimeFormatter28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(dateTimeParser30);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertNotNull(dateTimeParser33);
//        org.junit.Assert.assertNotNull(dateTimeFormatter34);
//        org.junit.Assert.assertNotNull(dateTimeParser35);
//        org.junit.Assert.assertNotNull(dateTimeParserArray36);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTimeFormatter42);
//        org.junit.Assert.assertNotNull(readableInterval44);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(timeOfDay49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "����-��-��T14:31:53.970" + "'", str50.equals("����-��-��T14:31:53.970"));
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(dateTimeFieldType55);
//        org.junit.Assert.assertNotNull(readableInterval59);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
//        org.junit.Assert.assertNotNull(durationField63);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-1209599903L) + "'", long66 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField67);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
//    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        org.joda.time.DateTime dateTime8 = dateTime5.withZoneRetainFields(dateTimeZone7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        long long11 = cachedDateTimeZone9.nextTransition((long) (short) 0);
        long long13 = cachedDateTimeZone9.nextTransition((long) 10);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        long long16 = cachedDateTimeZone9.convertUTCToLocal((long) 20);
        boolean boolean17 = cachedDateTimeZone9.isFixed();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9972000000L + "'", long11 == 9972000000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9972000000L + "'", long13 == 9972000000L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-28799980L) + "'", long16 == (-28799980L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test468");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str2 = dateTimeZone0.getName((long) 52305);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pacific Standard Time" + "'", str2.equals("Pacific Standard Time"));
//    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(8, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        org.joda.time.Interval interval6 = property4.toInterval();
        org.joda.time.DateTime dateTime8 = property4.addToCopy((long) 31);
        java.util.Locale locale10 = null;
        java.lang.String str11 = dateTime8.toString("57", locale10);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(interval6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "57" + "'", str11.equals("57"));
    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        org.joda.time.ReadableInterval readableInterval29 = null;
//        org.joda.time.ReadableInterval readableInterval30 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval29);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((java.lang.Object) readableInterval29);
//        org.joda.time.DateTime.Property property32 = dateTime31.weekOfWeekyear();
//        java.lang.String str33 = property32.getName();
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone35 = gregorianChronology34.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter36.withOffsetParsed();
//        org.joda.time.ReadableInterval readableInterval38 = null;
//        org.joda.time.ReadableInterval readableInterval39 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval38);
//        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((java.lang.Object) readableInterval38);
//        org.joda.time.MutableDateTime mutableDateTime41 = dateTime40.toMutableDateTime();
//        org.joda.time.DateTime.Property property42 = dateTime40.secondOfMinute();
//        org.joda.time.DateTime dateTime44 = dateTime40.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime45 = dateTime40.toLocalDateTime();
//        java.lang.String str46 = dateTimeFormatter37.print((org.joda.time.ReadablePartial) localDateTime45);
//        int[] intArray48 = gregorianChronology34.get((org.joda.time.ReadablePartial) localDateTime45, (-1209599903L));
//        int int49 = property32.compareTo((org.joda.time.ReadablePartial) localDateTime45);
//        java.util.Locale locale50 = null;
//        try {
//            java.lang.String str51 = unsupportedDateTimeField28.getAsShortText((org.joda.time.ReadablePartial) localDateTime45, locale50);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:54.293" + "'", str11.equals("����-��-��T14:31:54.293"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertNotNull(readableInterval30);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "weekOfWeekyear" + "'", str33.equals("weekOfWeekyear"));
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertNotNull(dateTimeFormatter36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertNotNull(readableInterval39);
//        org.junit.Assert.assertNotNull(mutableDateTime41);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(localDateTime45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "2019-W24" + "'", str46.equals("2019-W24"));
//        org.junit.Assert.assertNotNull(intArray48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
//        org.joda.time.ReadableInterval readableInterval5 = null;
//        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime7.toMutableDateTime();
//        org.joda.time.DateTime.Property property9 = dateTime7.secondOfMinute();
//        org.joda.time.DateTime dateTime11 = dateTime7.withMonthOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
//        java.util.TimeZone timeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        org.joda.time.DateTime dateTime16 = dateTime11.toDateTime(dateTimeZone14);
//        org.joda.time.DateTime dateTime17 = dateTime2.withZoneRetainFields(dateTimeZone14);
//        int int18 = dateTime2.getWeekOfWeekyear();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(readableInterval6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 24 + "'", int18 == 24);
//    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology3);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 365);
//        int int9 = offsetDateTimeField7.getMinimumValue((long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, (int) '#');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter12.withOffsetParsed();
//        org.joda.time.ReadableInterval readableInterval14 = null;
//        org.joda.time.ReadableInterval readableInterval15 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval14);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) readableInterval14);
//        org.joda.time.MutableDateTime mutableDateTime17 = dateTime16.toMutableDateTime();
//        org.joda.time.DateTime.Property property18 = dateTime16.secondOfMinute();
//        org.joda.time.DateTime dateTime20 = dateTime16.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime21 = dateTime16.toLocalDateTime();
//        java.lang.String str22 = dateTimeFormatter13.print((org.joda.time.ReadablePartial) localDateTime21);
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter25.withOffsetParsed();
//        org.joda.time.ReadableInterval readableInterval27 = null;
//        org.joda.time.ReadableInterval readableInterval28 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval27);
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((java.lang.Object) readableInterval27);
//        org.joda.time.MutableDateTime mutableDateTime30 = dateTime29.toMutableDateTime();
//        org.joda.time.DateTime.Property property31 = dateTime29.secondOfMinute();
//        org.joda.time.DateTime dateTime33 = dateTime29.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime34 = dateTime29.toLocalDateTime();
//        java.lang.String str35 = dateTimeFormatter26.print((org.joda.time.ReadablePartial) localDateTime34);
//        int[] intArray37 = gregorianChronology23.get((org.joda.time.ReadablePartial) localDateTime34, (-1209599903L));
//        int int38 = offsetDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) localDateTime21, intArray37);
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDateTime21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 366 + "'", int9 == 366);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(readableInterval15);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(localDateTime21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019-W24" + "'", str22.equals("2019-W24"));
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(readableInterval28);
//        org.junit.Assert.assertNotNull(mutableDateTime30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(localDateTime34);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2019-W24" + "'", str35.equals("2019-W24"));
//        org.junit.Assert.assertNotNull(intArray37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 366 + "'", int38 == 366);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusMonths(1277500);
        org.junit.Assert.assertNotNull(dateTime2);
    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
//        int int6 = dateTime2.getSecondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        boolean boolean8 = dateTime2.isSupported(dateTimeFieldType7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 365);
//        int int15 = dateTime2.get(dateTimeField12);
//        java.util.TimeZone timeZone16 = null;
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forTimeZone(timeZone16);
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval20 = null;
//        org.joda.time.ReadableInterval readableInterval21 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval20);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((java.lang.Object) readableInterval20);
//        org.joda.time.DateTime.Property property23 = dateTime22.weekOfWeekyear();
//        org.joda.time.DateTime dateTime25 = dateTime22.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay26 = dateTime25.toTimeOfDay();
//        java.lang.String str27 = dateTimeFormatter19.print((org.joda.time.ReadablePartial) timeOfDay26);
//        org.joda.time.DateTime dateTime28 = dateTime18.withFields((org.joda.time.ReadablePartial) timeOfDay26);
//        org.joda.time.DateTime dateTime30 = dateTime18.withEra(0);
//        org.joda.time.DateTime.Property property31 = dateTime30.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property31.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType32, "377");
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField36 = new org.joda.time.field.RemainderDateTimeField(dateTimeField12, dateTimeFieldType32, (-28800000));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52314 + "'", int6 == 52314);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertNotNull(readableInterval21);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(timeOfDay26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "����-��-��T14:31:54.547" + "'", str27.equals("����-��-��T14:31:54.547"));
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        try {
            long long2 = dateTimeFormatter0.parseMillis("Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Coordinated Universal Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology7.getZone();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology7.weekyear();
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(24, 1970, (int) (short) 10, (-28800000), (-100), (int) ' ', (org.joda.time.Chronology) gregorianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

//    @Test
//    public void test479() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test479");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        org.joda.time.DateTime dateTime8 = dateTime5.withZoneRetainFields(dateTimeZone7);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = cachedDateTimeZone9.equals(obj10);
//        java.lang.String str13 = cachedDateTimeZone9.getName((long) 522840);
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatterBuilder4.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfHour(166, (int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter10 = dateTimeFormatterBuilder9.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean12 = dateTimeFormatter11.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser13 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean15 = dateTimeFormatter14.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser16 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser13, dateTimeParser16, dateTimeParser18 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder4.append(dateTimePrinter10, dateTimeParserArray19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser22 = dateTimeFormatter21.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter10, dateTimeParser22);
        try {
            org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.parse("weekOfWeekyear", dateTimeFormatter23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"weekOfWeekyear\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimePrinter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTimeParser13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dateTimeParser16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeParserArray19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeParser22);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test482");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        long long31 = unsupportedDateTimeField28.add((long) 52274482, (long) 13);
//        org.joda.time.DurationField durationField32 = unsupportedDateTimeField28.getDurationField();
//        try {
//            long long34 = unsupportedDateTimeField28.roundHalfCeiling((long) 52257628);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:54.680" + "'", str11.equals("����-��-��T14:31:54.680"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 7914674482L + "'", long31 == 7914674482L);
//        org.junit.Assert.assertNotNull(durationField32);
//    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
//        int int6 = dateTime5.getWeekyear();
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime.Property property8 = dateTime5.dayOfYear();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577572315047L + "'", long7 == 1577572315047L);
//        org.junit.Assert.assertNotNull(property8);
//    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime2.year();
        int int7 = property6.getMaximumValueOverall();
        boolean boolean9 = property6.equals((java.lang.Object) "1969365T160000.365-0800");
        java.lang.String str10 = property6.getAsString();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292278993 + "'", int7 == 292278993);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) readableInterval5);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.DateTime dateTime13 = dateTime10.withZoneRetainFields(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        long long16 = cachedDateTimeZone14.nextTransition((long) (short) 0);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology18.getZone();
        java.lang.String str20 = dateTimeZone19.getID();
        boolean boolean21 = zonedChronology17.equals((java.lang.Object) dateTimeZone19);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone19);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(readableInterval6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9972000000L + "'", long16 == 9972000000L);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        java.lang.String str29 = unsupportedDateTimeField28.getName();
//        org.joda.time.DurationField durationField30 = unsupportedDateTimeField28.getDurationField();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.dateTime();
//        org.joda.time.ReadableInterval readableInterval32 = null;
//        org.joda.time.ReadableInterval readableInterval33 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval32);
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((java.lang.Object) readableInterval32);
//        org.joda.time.MutableDateTime mutableDateTime35 = dateTime34.toMutableDateTime();
//        org.joda.time.DateTime.Property property36 = dateTime34.secondOfMinute();
//        org.joda.time.DateTime dateTime38 = dateTime34.plusMillis((int) (byte) 10);
//        int int39 = dateTime38.getDayOfYear();
//        org.joda.time.ReadableInterval readableInterval40 = null;
//        org.joda.time.ReadableInterval readableInterval41 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval40);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((java.lang.Object) readableInterval40);
//        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
//        org.joda.time.DateTime dateTime45 = dateTime42.withWeekOfWeekyear((int) '4');
//        org.joda.time.Chronology chronology46 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime38, (org.joda.time.ReadableInstant) dateTime42);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter47 = dateTimeFormatter31.withChronology(chronology46);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter48 = dateTimeFormatter31.withOffsetParsed();
//        java.util.TimeZone timeZone49 = null;
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.forTimeZone(timeZone49);
//        org.joda.time.DateTime dateTime51 = org.joda.time.DateTime.now(dateTimeZone50);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval53 = null;
//        org.joda.time.ReadableInterval readableInterval54 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval53);
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((java.lang.Object) readableInterval53);
//        org.joda.time.DateTime.Property property56 = dateTime55.weekOfWeekyear();
//        org.joda.time.DateTime dateTime58 = dateTime55.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay59 = dateTime58.toTimeOfDay();
//        java.lang.String str60 = dateTimeFormatter52.print((org.joda.time.ReadablePartial) timeOfDay59);
//        org.joda.time.DateTime dateTime61 = dateTime51.withFields((org.joda.time.ReadablePartial) timeOfDay59);
//        java.lang.String str62 = dateTimeFormatter31.print((org.joda.time.ReadablePartial) timeOfDay59);
//        int[] intArray64 = null;
//        try {
//            int[] intArray66 = unsupportedDateTimeField28.addWrapPartial((org.joda.time.ReadablePartial) timeOfDay59, (-2608), intArray64, 24);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:55.676" + "'", str11.equals("����-��-��T14:31:55.676"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "weekyear" + "'", str29.equals("weekyear"));
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(readableInterval33);
//        org.junit.Assert.assertNotNull(mutableDateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 166 + "'", int39 == 166);
//        org.junit.Assert.assertNotNull(readableInterval41);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(chronology46);
//        org.junit.Assert.assertNotNull(dateTimeFormatter47);
//        org.junit.Assert.assertNotNull(dateTimeFormatter48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTimeFormatter52);
//        org.junit.Assert.assertNotNull(readableInterval54);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(timeOfDay59);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "����-��-��T14:31:55.683" + "'", str60.equals("����-��-��T14:31:55.683"));
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "����-��-��T14:31:55.683" + "'", str62.equals("����-��-��T14:31:55.683"));
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "weekOfWeekyear", 24, (-870));
        long long6 = fixedDateTimeZone4.previousTransition((long) 12775);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.ReadableInterval readableInterval8 = null;
        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) readableInterval8);
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
        org.joda.time.DateTime.Property property12 = dateTime10.secondOfMinute();
        org.joda.time.DateTime dateTime14 = dateTime10.withMonthOfYear((int) (byte) 1);
        org.joda.time.DateTime dateTime16 = dateTime10.minusDays((int) (byte) 100);
        org.joda.time.DateTime dateTime18 = dateTime16.minusYears(1);
        boolean boolean19 = fixedDateTimeZone4.equals((java.lang.Object) 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 12775L + "'", long6 == 12775L);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(readableInterval9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime2.withMonthOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        org.joda.time.TimeOfDay timeOfDay8 = dateTime6.toTimeOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology10.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DurationField durationField14 = iSOChronology13.halfdays();
        org.joda.time.DurationField durationField15 = iSOChronology13.weeks();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology13.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology13.minuteOfHour();
        org.joda.time.DateTime dateTime18 = dateTime6.withChronology((org.joda.time.Chronology) iSOChronology13);
        org.joda.time.DateTime dateTime20 = dateTime18.minusYears((int) (byte) -1);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(timeOfDay8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int7 = offsetDateTimeField5.getMinimumValue((long) 19);
        org.joda.time.ReadableInterval readableInterval8 = null;
        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) readableInterval8);
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
        org.joda.time.DateTime.Property property12 = dateTime10.secondOfMinute();
        org.joda.time.DateTime dateTime14 = dateTime10.withMonthOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property15 = dateTime14.weekOfWeekyear();
        org.joda.time.TimeOfDay timeOfDay16 = dateTime14.toTimeOfDay();
        int int17 = offsetDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay16);
        long long19 = offsetDateTimeField5.roundFloor((long) 2);
        boolean boolean20 = offsetDateTimeField5.isLenient();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
        org.junit.Assert.assertNotNull(readableInterval9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(timeOfDay16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 366 + "'", int17 == 366);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test491");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear((int) '4');
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime12 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay10);
//        org.joda.time.DateTime dateTime14 = dateTime2.withEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "377");
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) readableInterval19);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        int int23 = property22.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property22.getDurationField();
//        long long27 = durationField24.subtract((long) 'a', 2);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
//        long long31 = unsupportedDateTimeField28.add((long) 52274482, (long) 13);
//        org.joda.time.DurationField durationField32 = unsupportedDateTimeField28.getDurationField();
//        int int35 = unsupportedDateTimeField28.getDifference(96L, 1577572260761L);
//        boolean boolean36 = unsupportedDateTimeField28.isLenient();
//        org.joda.time.ReadableInterval readableInterval37 = null;
//        org.joda.time.ReadableInterval readableInterval38 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval37);
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((java.lang.Object) readableInterval37);
//        org.joda.time.YearMonthDay yearMonthDay40 = dateTime39.toYearMonthDay();
//        try {
//            int int41 = unsupportedDateTimeField28.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay40);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-��-��T14:31:56.152" + "'", str11.equals("����-��-��T14:31:56.152"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(readableInterval20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1209599903L) + "'", long27 == (-1209599903L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 7914674482L + "'", long31 == 7914674482L);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-2608) + "'", int35 == (-2608));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(readableInterval38);
//        org.junit.Assert.assertNotNull(yearMonthDay40);
//    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int6 = offsetDateTimeField5.getMaximumValue();
        long long8 = offsetDateTimeField5.roundHalfFloor((long) (byte) 10);
        long long10 = offsetDateTimeField5.roundFloor((long) 365);
        long long12 = offsetDateTimeField5.roundCeiling(0L);
        org.joda.time.DateTimeField dateTimeField13 = offsetDateTimeField5.getWrappedField();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 377 + "'", int6 == 377);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.minus(readableDuration4);
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.ReadableInterval readableInterval7 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) readableInterval6);
        org.joda.time.DateTime.Property property9 = dateTime8.weekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime8.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
        org.joda.time.DateTime dateTime14 = dateTime11.withZoneRetainFields(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = dateTime2.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime16 = dateTime2.toDateTime();
        org.joda.time.DateTime dateTime17 = dateTime2.toDateTime();
        int int18 = dateTime17.getYearOfCentury();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(readableInterval7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 19 + "'", int18 == 19);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.minus(readableDuration4);
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.ReadableInterval readableInterval7 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) readableInterval6);
        org.joda.time.DateTime.Property property9 = dateTime8.weekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime8.withWeekOfWeekyear((int) '4');
        java.util.TimeZone timeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
        org.joda.time.DateTime dateTime14 = dateTime11.withZoneRetainFields(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = dateTime2.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime17 = dateTime2.withSecondOfMinute(24);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(readableInterval7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        org.joda.time.DateTime dateTime8 = dateTime5.withZoneRetainFields(dateTimeZone7);
//        java.lang.String str9 = dateTimeZone7.getID();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone7);
//        java.lang.String str12 = dateTimeZone7.getShortName((long) 52263199);
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "America/Los_Angeles" + "'", str9.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PST" + "'", str12.equals("PST"));
//    }

//    @Test
//    public void test496() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test496");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableInterval4);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime.Property property8 = dateTime6.millisOfDay();
//        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
//        int int10 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime6);
//        java.util.Locale locale12 = null;
//        try {
//            java.lang.String str13 = dateTime2.toString("����-��-��T14:31:54.738", locale12);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(readableInterval5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
//        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
//        int int7 = dateTime6.getDayOfYear();
//        org.joda.time.ReadableInterval readableInterval8 = null;
//        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) readableInterval8);
//        org.joda.time.DateTime.Property property11 = dateTime10.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = dateTime10.withWeekOfWeekyear((int) '4');
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime6, (org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime.Property property15 = dateTime10.monthOfYear();
//        org.joda.time.ReadableInterval readableInterval16 = null;
//        org.joda.time.ReadableInterval readableInterval17 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval16);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) readableInterval16);
//        org.joda.time.DateTime.Property property19 = dateTime18.weekOfWeekyear();
//        org.joda.time.DateTime.Property property20 = dateTime18.millisOfDay();
//        boolean boolean21 = property15.equals((java.lang.Object) property20);
//        org.joda.time.DateTime dateTime22 = property15.roundHalfEvenCopy();
//        org.joda.time.DateTimeZone dateTimeZone23 = dateTime22.getZone();
//        int int24 = dateTime22.getYear();
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 166 + "'", int7 == 166);
//        org.junit.Assert.assertNotNull(readableInterval9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(readableInterval17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
//    }

//    @Test
//    public void test498() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test498");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) readableInterval0);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
//        int int6 = dateTime5.getWeekyear();
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.ReadableInterval readableInterval8 = null;
//        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) readableInterval8);
//        org.joda.time.DateTime.Property property11 = dateTime10.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = dateTime10.withWeekOfWeekyear((int) '4');
//        org.joda.time.MutableDateTime mutableDateTime14 = dateTime10.toMutableDateTimeISO();
//        java.util.Locale locale15 = null;
//        java.util.Calendar calendar16 = dateTime10.toCalendar(locale15);
//        int int17 = dateTime10.getMinuteOfDay();
//        boolean boolean18 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime21 = dateTime10.minusWeeks(3);
//        org.junit.Assert.assertNotNull(readableInterval1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577572316660L + "'", long7 == 1577572316660L);
//        org.junit.Assert.assertNotNull(readableInterval9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertNotNull(calendar16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 871 + "'", int17 == 871);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(dateTime21);
//    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(52263, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneName();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendFractionOfHour(0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '#', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray6 = gregorianChronology1.get(readablePeriod3, (long) '4', (long) 12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }
}

