import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        int int4 = dateTime3.getSecondOfMinute();
//        org.joda.time.DateTime dateTime9 = dateTime3.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime11 = dateTime3.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime13);
//        int int16 = gJChronology15.getMinimumDaysInFirstWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        org.joda.time.Chronology chronology18 = dateTimeFormatter17.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTimeFormatter17.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology15, dateTimeZone19);
//        long long26 = zonedChronology20.getDateTimeMillis(1560630623999L, (int) (short) 0, 0, 12, 3);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone29);
//        int int31 = dateTime30.getSecondOfMinute();
//        org.joda.time.DateTime dateTime36 = dateTime30.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime38 = dateTime30.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime40 = dateTime38.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone28, (org.joda.time.ReadableInstant) dateTime40);
//        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone27, (org.joda.time.ReadableInstant) dateTime40);
//        int int43 = gJChronology42.getMinimumDaysInFirstWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        org.joda.time.Chronology chronology45 = dateTimeFormatter44.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone46 = dateTimeFormatter44.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology47 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology42, dateTimeZone46);
//        org.joda.time.Chronology chronology48 = zonedChronology20.withZone(dateTimeZone46);
//        try {
//            long long54 = zonedChronology20.getDateTimeMillis((long) 'a', 2019, 53, 2, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNull(chronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(zonedChronology20);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560556812003L + "'", long26 == 1560556812003L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(gJChronology41);
//        org.junit.Assert.assertNotNull(gJChronology42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 4 + "'", int43 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter44);
//        org.junit.Assert.assertNull(chronology45);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertNotNull(zonedChronology47);
//        org.junit.Assert.assertNotNull(chronology48);
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        boolean boolean4 = monthDay2.isSupported(dateTimeFieldType3);
        org.joda.time.MonthDay monthDay6 = monthDay2.withDayOfMonth(15);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay8 = monthDay6.plus(readablePeriod7);
        org.joda.time.MonthDay.Property property9 = monthDay8.dayOfMonth();
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.parse("");
        int int12 = property9.compareTo((org.joda.time.ReadablePartial) monthDay11);
        int int13 = property9.getMaximumValueOverall();
        org.joda.time.Instant instant15 = new org.joda.time.Instant((-86L));
        org.joda.time.Instant instant16 = instant15.toInstant();
        long long17 = instant15.getMillis();
        org.joda.time.Instant instant19 = instant15.plus(720015L);
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.Instant instant21 = instant19.minus(readableDuration20);
        boolean boolean22 = property9.equals((java.lang.Object) instant21);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 31 + "'", int13 == 31);
        org.junit.Assert.assertNotNull(instant16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-86L) + "'", long17 == (-86L));
        org.junit.Assert.assertNotNull(instant19);
        org.junit.Assert.assertNotNull(instant21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        try {
            long long8 = buddhistChronology0.getDateTimeMillis(43, 52, 0, 54, 7, 30, 52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
//        int int4 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusDays((int) (byte) 10);
//        org.joda.time.DateTime.Property property7 = dateTime6.millisOfSecond();
//        org.joda.time.DateTime dateTime8 = property7.withMaximumValue();
//        org.joda.time.DateTimeZone dateTimeZone9 = dateTime8.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
//        try {
//            long long18 = gregorianChronology10.getDateTimeMillis(6, (int) (byte) 0, 45, 40, 0, 29, 4);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 40 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        java.util.Locale locale6 = null;
        int int7 = delegatedDateTimeField5.getMaximumTextLength(locale6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = delegatedDateTimeField5.getType();
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeField[] dateTimeFieldArray10 = monthDay9.getFields();
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField5.getAsText((org.joda.time.ReadablePartial) monthDay9, (-1), locale12);
        long long16 = delegatedDateTimeField5.addWrapField((long) 15, 12);
        long long18 = delegatedDateTimeField5.roundHalfCeiling(0L);
        java.util.Locale locale20 = null;
        java.lang.String str21 = delegatedDateTimeField5.getAsShortText(10, locale20);
        long long24 = delegatedDateTimeField5.add((long) '#', (long) 41);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) delegatedDateTimeField5, 30, 32, 14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 30 for minuteOfHour must be in the range [32,14]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(dateTimeFieldArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1" + "'", str13.equals("-1"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 720015L + "'", long16 == 720015L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10" + "'", str21.equals("10"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2460035L + "'", long24 == 2460035L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField0);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
//        int int4 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusDays((int) (byte) 10);
//        org.joda.time.DateTime.Property property7 = dateTime6.millisOfSecond();
//        org.joda.time.DateTime dateTime8 = property7.withMaximumValue();
//        org.joda.time.DateTimeZone dateTimeZone9 = dateTime8.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
//        boolean boolean12 = dateTimeZone9.isStandardOffset((long) 2034);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime5 = property4.roundHalfCeilingCopy();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readablePeriod6);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusYears(15);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds(1);
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime5.toMutableDateTime();
//        long long9 = mutableDateTime8.getMillis();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 473328000028L + "'", long9 == 473328000028L);
//    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
//        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.clockhourOfDay();
//        org.joda.time.DurationField durationField3 = copticChronology1.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField6 = iSOChronology5.halfdays();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        int int10 = dateTime9.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone11 = dateTime9.getZone();
//        org.joda.time.Chronology chronology12 = iSOChronology5.withZone(dateTimeZone11);
//        java.lang.String str13 = dateTimeZone11.getID();
//        org.joda.time.Chronology chronology14 = copticChronology1.withZone(dateTimeZone11);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter0.withZone(dateTimeZone11);
//        try {
//            org.joda.time.DateTime dateTime17 = dateTimeFormatter15.parseDateTime("26");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"26\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(copticChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "America/Los_Angeles" + "'", str13.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.era();
        java.lang.Class<?> wildcardClass3 = iSOChronology1.getClass();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 20);
        long long9 = offsetDateTimeField6.getDifferenceAsLong(1560630624063L, (long) 100);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        boolean boolean14 = monthDay12.isSupported(dateTimeFieldType13);
        org.joda.time.MonthDay monthDay16 = monthDay12.withDayOfMonth(15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay18 = monthDay16.plus(readablePeriod17);
        org.joda.time.MonthDay monthDay20 = monthDay18.plusDays(22);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology23);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = null;
        boolean boolean26 = monthDay24.isSupported(dateTimeFieldType25);
        org.joda.time.MonthDay monthDay28 = monthDay24.withDayOfMonth(15);
        int[] intArray30 = iSOChronology21.get((org.joda.time.ReadablePartial) monthDay28, (long) (short) -1);
        int int31 = offsetDateTimeField6.getMinimumValue((org.joda.time.ReadablePartial) monthDay18, intArray30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone33);
        org.joda.time.DurationField durationField35 = iSOChronology34.halfdays();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField36, dateTimeFieldType37);
        java.util.Locale locale39 = null;
        int int40 = delegatedDateTimeField38.getMaximumTextLength(locale39);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = delegatedDateTimeField38.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder32.appendText(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder32.appendSecondOfMinute((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean46 = dateTimeFormatterBuilder45.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone48);
        org.joda.time.DurationField durationField50 = iSOChronology49.halfdays();
        org.joda.time.DateTimeField dateTimeField51 = iSOChronology49.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField53 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField51, dateTimeFieldType52);
        java.util.Locale locale54 = null;
        int int55 = delegatedDateTimeField53.getMaximumTextLength(locale54);
        org.joda.time.DateTimeFieldType dateTimeFieldType56 = delegatedDateTimeField53.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder47.appendText(dateTimeFieldType56);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder45.appendText(dateTimeFieldType56);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder32.appendFixedSignedDecimal(dateTimeFieldType56, (int) (byte) 1);
        boolean boolean61 = monthDay18.isSupported(dateTimeFieldType56);
        org.joda.time.MonthDay.Property property62 = monthDay18.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 18062L + "'", long9 == 18062L);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 21 + "'", int31 == 21);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2 + "'", int55 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType56);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder57);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(property62);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
        org.joda.time.DateTime dateTime5 = dateTime1.minusWeeks((int) (byte) 1);
        org.joda.time.Chronology chronology6 = dateTime1.getChronology();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime1.minus(readableDuration7);
        org.joda.time.DateTime dateTime9 = dateTime8.toDateTime();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.era();
//        java.lang.Class<?> wildcardClass3 = iSOChronology1.getClass();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.dayOfMonth();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 20);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology8);
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
//        boolean boolean11 = monthDay9.isSupported(dateTimeFieldType10);
//        org.joda.time.MonthDay monthDay13 = monthDay9.withDayOfMonth(15);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
//        org.joda.time.DateTime dateTime17 = dateTime15.withHourOfDay(0);
//        int int18 = dateTime15.getDayOfMonth();
//        org.joda.time.DateTime dateTime19 = monthDay9.toDateTime((org.joda.time.ReadableInstant) dateTime15);
//        int int20 = offsetDateTimeField6.getMinimumValue((org.joda.time.ReadablePartial) monthDay9);
//        long long22 = offsetDateTimeField6.roundFloor((long) 9);
//        java.lang.String str23 = offsetDateTimeField6.getName();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(monthDay13);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 31 + "'", int18 == 31);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 21 + "'", int20 == 21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "dayOfMonth" + "'", str23.equals("dayOfMonth"));
//    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        int int4 = dateTime3.getSecondOfMinute();
//        org.joda.time.DateTime dateTime9 = dateTime3.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime11 = dateTime3.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime.Property property16 = dateTime13.hourOfDay();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = property16.getAsText(locale17);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "16" + "'", str18.equals("16"));
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("15", "--07-07", 48627451, (int) (byte) -1);
        int int6 = fixedDateTimeZone4.getOffset((long) 10);
        int int8 = fixedDateTimeZone4.getStandardOffset((-28799244L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 48627451 + "'", int6 == 48627451);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        java.util.Locale locale6 = null;
        int int7 = delegatedDateTimeField5.getMaximumTextLength(locale6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = delegatedDateTimeField5.getType();
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeField[] dateTimeFieldArray10 = monthDay9.getFields();
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField5.getAsText((org.joda.time.ReadablePartial) monthDay9, (-1), locale12);
        long long16 = delegatedDateTimeField5.addWrapField((long) 15, 12);
        long long18 = delegatedDateTimeField5.roundHalfCeiling(0L);
        java.util.Locale locale20 = null;
        java.lang.String str21 = delegatedDateTimeField5.getAsText(0, locale20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean23 = dateTimeFormatterBuilder22.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.joda.time.DurationField durationField27 = iSOChronology26.halfdays();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField28, dateTimeFieldType29);
        java.util.Locale locale31 = null;
        int int32 = delegatedDateTimeField30.getMaximumTextLength(locale31);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = delegatedDateTimeField30.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder24.appendText(dateTimeFieldType33);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder22.appendText(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, dateTimeFieldType33, 19, 0, (int) '4');
        java.util.Locale locale41 = null;
        java.lang.String str42 = offsetDateTimeField39.getAsText((long) 20, locale41);
        try {
            long long45 = offsetDateTimeField39.add((long) 59, 1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 68 for minuteOfHour must be in the range [19,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(dateTimeFieldArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1" + "'", str13.equals("-1"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 720015L + "'", long16 == 720015L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2 + "'", int32 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "19" + "'", str42.equals("19"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "dayOfWeek");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
//        int int4 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusDays((int) (byte) 10);
//        int int7 = dateTime6.getYearOfCentury();
//        int int8 = dateTime6.getEra();
//        int int9 = dateTime6.getSecondOfDay();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 70 + "'", int7 == 70);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 57600 + "'", int9 == 57600);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
        org.joda.time.DateTime dateTime5 = dateTime3.plusYears(15);
        org.joda.time.DateTime dateTime6 = dateTime3.toDateTimeISO();
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 14, (int) (byte) -1);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime12 = dateTime6.withPeriodAdded(readablePeriod10, 891);
        org.joda.time.DateMidnight dateMidnight13 = dateTime6.toDateMidnight();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateMidnight13);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        java.util.Locale locale6 = null;
        int int7 = delegatedDateTimeField5.getMaximumTextLength(locale6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = delegatedDateTimeField5.getType();
        java.util.Locale locale9 = null;
        int int10 = delegatedDateTimeField5.getMaximumTextLength(locale9);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        boolean boolean15 = monthDay13.isSupported(dateTimeFieldType14);
        org.joda.time.MonthDay monthDay17 = monthDay13.withDayOfMonth(15);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.MonthDay monthDay19 = monthDay17.plus(readablePeriod18);
        org.joda.time.MonthDay monthDay21 = monthDay19.plusDays(24);
        java.util.Locale locale23 = null;
        java.lang.String str24 = delegatedDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) monthDay19, 41, locale23);
        long long27 = delegatedDateTimeField5.addWrapField((long) 39, 17);
        java.lang.String str28 = delegatedDateTimeField5.getName();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "41" + "'", str24.equals("41"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1020039L + "'", long27 == 1020039L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "minuteOfHour" + "'", str28.equals("minuteOfHour"));
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        int int4 = dateTime3.getSecondOfMinute();
//        org.joda.time.DateTime dateTime9 = dateTime3.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime11 = dateTime3.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime13);
//        int int16 = gJChronology15.getMinimumDaysInFirstWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        org.joda.time.Chronology chronology18 = dateTimeFormatter17.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTimeFormatter17.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology15, dateTimeZone19);
//        long long26 = zonedChronology20.getDateTimeMillis(1560630623999L, (int) (short) 0, 0, 12, 3);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone29);
//        int int31 = dateTime30.getSecondOfMinute();
//        org.joda.time.DateTime dateTime36 = dateTime30.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime38 = dateTime30.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime40 = dateTime38.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone28, (org.joda.time.ReadableInstant) dateTime40);
//        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone27, (org.joda.time.ReadableInstant) dateTime40);
//        int int43 = gJChronology42.getMinimumDaysInFirstWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        org.joda.time.Chronology chronology45 = dateTimeFormatter44.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone46 = dateTimeFormatter44.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology47 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology42, dateTimeZone46);
//        org.joda.time.Chronology chronology48 = zonedChronology20.withZone(dateTimeZone46);
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology50 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone49);
//        org.joda.time.DurationField durationField51 = iSOChronology50.halfdays();
//        org.joda.time.DateTimeField dateTimeField52 = iSOChronology50.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime(dateTimeZone53);
//        int int55 = dateTime54.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone56 = dateTime54.getZone();
//        org.joda.time.Chronology chronology57 = iSOChronology50.withZone(dateTimeZone56);
//        java.lang.String str58 = dateTimeZone56.getID();
//        org.joda.time.Chronology chronology59 = zonedChronology20.withZone(dateTimeZone56);
//        org.joda.time.DurationField durationField60 = zonedChronology20.years();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNull(chronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(zonedChronology20);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560556812003L + "'", long26 == 1560556812003L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(gJChronology41);
//        org.junit.Assert.assertNotNull(gJChronology42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 4 + "'", int43 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter44);
//        org.junit.Assert.assertNull(chronology45);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertNotNull(zonedChronology47);
//        org.junit.Assert.assertNotNull(chronology48);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertNotNull(iSOChronology50);
//        org.junit.Assert.assertNotNull(durationField51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone56);
//        org.junit.Assert.assertNotNull(chronology57);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "America/Los_Angeles" + "'", str58.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(chronology59);
//        org.junit.Assert.assertNotNull(durationField60);
//    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        boolean boolean4 = monthDay2.isSupported(dateTimeFieldType3);
//        org.joda.time.MonthDay monthDay6 = monthDay2.withDayOfMonth(15);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime dateTime10 = dateTime8.withHourOfDay(0);
//        int int11 = dateTime8.getDayOfMonth();
//        org.joda.time.DateTime dateTime12 = monthDay2.toDateTime((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("15", "--07-07", 48627451, (int) (byte) -1);
//        int int19 = fixedDateTimeZone17.getOffset((long) 10);
//        org.joda.time.DateTime dateTime20 = dateTime8.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 31 + "'", int11 == 31);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 48627451 + "'", int19 == 48627451);
//        org.junit.Assert.assertNotNull(dateTime20);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.halfdays();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType5);
        java.util.Locale locale7 = null;
        int int8 = delegatedDateTimeField6.getMaximumTextLength(locale7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = delegatedDateTimeField6.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendLiteral("15");
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
//        java.io.Writer writer3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        int int6 = dateTime5.getSecondOfMinute();
//        org.joda.time.DateTime dateTime11 = dateTime5.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime13 = dateTime11.plusYears((-1));
//        java.lang.String str14 = dateTime13.toString();
//        java.lang.String str15 = dateTime13.toString();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
//        org.joda.time.DurationField durationField18 = iSOChronology17.halfdays();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
//        int int22 = dateTime21.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone23 = dateTime21.getZone();
//        org.joda.time.Chronology chronology24 = iSOChronology17.withZone(dateTimeZone23);
//        org.joda.time.DateTime dateTime25 = dateTime13.toDateTime(dateTimeZone23);
//        org.joda.time.DateTime dateTime27 = dateTime25.minusWeeks((int) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(dateTimeZone28);
//        org.joda.time.DateTime dateTime31 = dateTime29.withHourOfDay(0);
//        org.joda.time.DateTime dateTime32 = dateTime31.withEarlierOffsetAtOverlap();
//        boolean boolean33 = dateTime25.isAfter((org.joda.time.ReadableInstant) dateTime32);
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone34);
//        org.joda.time.MonthDay monthDay36 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology35);
//        org.joda.time.DateTimeFieldType dateTimeFieldType37 = null;
//        boolean boolean38 = monthDay36.isSupported(dateTimeFieldType37);
//        org.joda.time.MonthDay monthDay40 = monthDay36.withDayOfMonth(15);
//        org.joda.time.DateTime dateTime41 = dateTime32.withFields((org.joda.time.ReadablePartial) monthDay36);
//        org.joda.time.DateTime dateTime43 = dateTime41.plusWeeks(22);
//        try {
//            dateTimeFormatter0.printTo(writer3, (org.joda.time.ReadableInstant) dateTime41);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1968-12-31T10:13:15.013-08:00" + "'", str14.equals("1968-12-31T10:13:15.013-08:00"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1968-12-31T10:13:15.013-08:00" + "'", str15.equals("1968-12-31T10:13:15.013-08:00"));
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(monthDay40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime43);
//    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
//        java.util.Locale locale6 = null;
//        int int7 = delegatedDateTimeField5.getMaximumTextLength(locale6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = delegatedDateTimeField5.getType();
//        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeField[] dateTimeFieldArray10 = monthDay9.getFields();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField5.getAsText((org.joda.time.ReadablePartial) monthDay9, (-1), locale12);
//        org.joda.time.MonthDay monthDay15 = monthDay9.plusDays(810);
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        int int18 = dateTime17.getSecondOfMinute();
//        org.joda.time.DateTime dateTime23 = dateTime17.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime25 = dateTime23.plusYears((-1));
//        java.lang.String str26 = dateTime25.toString();
//        java.lang.String str27 = dateTime25.toString();
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
//        org.joda.time.DurationField durationField30 = iSOChronology29.halfdays();
//        org.joda.time.DateTimeField dateTimeField31 = iSOChronology29.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(dateTimeZone32);
//        int int34 = dateTime33.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone35 = dateTime33.getZone();
//        org.joda.time.Chronology chronology36 = iSOChronology29.withZone(dateTimeZone35);
//        org.joda.time.DateTime dateTime37 = dateTime25.toDateTime(dateTimeZone35);
//        org.joda.time.DateTime dateTime39 = dateTime37.minusWeeks((int) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone40 = null;
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime(dateTimeZone40);
//        org.joda.time.DateTime dateTime43 = dateTime41.withHourOfDay(0);
//        org.joda.time.DateTime dateTime44 = dateTime43.withEarlierOffsetAtOverlap();
//        boolean boolean45 = dateTime37.isAfter((org.joda.time.ReadableInstant) dateTime44);
//        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone46);
//        org.joda.time.MonthDay monthDay48 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology47);
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = null;
//        boolean boolean50 = monthDay48.isSupported(dateTimeFieldType49);
//        org.joda.time.MonthDay monthDay52 = monthDay48.withDayOfMonth(15);
//        org.joda.time.DateTime dateTime53 = dateTime44.withFields((org.joda.time.ReadablePartial) monthDay48);
//        org.joda.time.ReadableInstant readableInstant54 = null;
//        boolean boolean55 = dateTime44.isBefore(readableInstant54);
//        org.joda.time.DateTime dateTime57 = dateTime44.plusWeeks((int) (short) 100);
//        boolean boolean58 = monthDay9.equals((java.lang.Object) dateTime44);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1" + "'", str13.equals("-1"));
//        org.junit.Assert.assertNotNull(monthDay15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1968-12-31T10:13:15.013-08:00" + "'", str26.equals("1968-12-31T10:13:15.013-08:00"));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1968-12-31T10:13:15.013-08:00" + "'", str27.equals("1968-12-31T10:13:15.013-08:00"));
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertNotNull(chronology36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertNotNull(iSOChronology47);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(monthDay52);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        int int5 = property4.getMaximumValue();
        org.joda.time.Interval interval6 = property4.toInterval();
        java.util.Locale locale7 = null;
        int int8 = property4.getMaximumTextLength(locale7);
        java.util.Locale locale9 = null;
        int int10 = property4.getMaximumShortTextLength(locale9);
        java.util.Locale locale11 = null;
        int int12 = property4.getMaximumShortTextLength(locale11);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(interval6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
//        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
//        boolean boolean9 = monthDay7.isSupported(dateTimeFieldType8);
//        int int10 = property4.compareTo((org.joda.time.ReadablePartial) monthDay7);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
//        org.joda.time.DurationField durationField13 = iSOChronology12.halfdays();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.minuteOfHour();
//        boolean boolean15 = property4.equals((java.lang.Object) dateTimeField14);
//        java.lang.String str16 = property4.getAsShortText();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Dec" + "'", str16.equals("Dec"));
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        int int5 = julianChronology4.getMinimumDaysInFirstWeek();
        int int6 = julianChronology4.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.Chronology chronology10 = julianChronology4.withZone(dateTimeZone7);
        int int11 = julianChronology4.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTime dateTime7 = dateTime1.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime9 = dateTime7.plusYears((-1));
//        java.lang.String str10 = dateTime9.toString();
//        java.lang.String str11 = dateTime9.toString();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
//        org.joda.time.DurationField durationField14 = iSOChronology13.halfdays();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        int int18 = dateTime17.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTime17.getZone();
//        org.joda.time.Chronology chronology20 = iSOChronology13.withZone(dateTimeZone19);
//        org.joda.time.DateTime dateTime21 = dateTime9.toDateTime(dateTimeZone19);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusWeeks((int) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(dateTimeZone24);
//        org.joda.time.DateTime dateTime27 = dateTime25.withHourOfDay(0);
//        org.joda.time.DateTime dateTime28 = dateTime27.withEarlierOffsetAtOverlap();
//        boolean boolean29 = dateTime21.isAfter((org.joda.time.ReadableInstant) dateTime28);
//        org.joda.time.DateTime.Property property30 = dateTime28.centuryOfEra();
//        int int31 = property30.getMaximumValueOverall();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1968-12-31T10:13:15.013-08:00" + "'", str10.equals("1968-12-31T10:13:15.013-08:00"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1968-12-31T10:13:15.013-08:00" + "'", str11.equals("1968-12-31T10:13:15.013-08:00"));
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2922789 + "'", int31 == 2922789);
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(17, false);
        boolean boolean4 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(2000, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        boolean boolean9 = dateTimeFormatterBuilder8.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.era();
        java.lang.Class<?> wildcardClass3 = iSOChronology1.getClass();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 20);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 1);
        long long10 = offsetDateTimeField6.roundFloor((long) 51);
        java.lang.String str11 = offsetDateTimeField6.toString();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str11.equals("DateTimeField[dayOfMonth]"));
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
//        java.util.Locale locale6 = null;
//        int int7 = delegatedDateTimeField5.getMaximumTextLength(locale6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = delegatedDateTimeField5.getType();
//        java.util.Locale locale9 = null;
//        int int10 = delegatedDateTimeField5.getMaximumTextLength(locale9);
//        org.joda.time.DurationField durationField11 = delegatedDateTimeField5.getDurationField();
//        org.joda.time.DurationField durationField12 = delegatedDateTimeField5.getLeapDurationField();
//        java.lang.String str13 = delegatedDateTimeField5.toString();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
//        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology15);
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
//        boolean boolean18 = monthDay16.isSupported(dateTimeFieldType17);
//        org.joda.time.MonthDay monthDay20 = monthDay16.withDayOfMonth(15);
//        int int21 = delegatedDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) monthDay16);
//        org.joda.time.MonthDay monthDay23 = monthDay16.minusMonths(0);
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology25);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
//        boolean boolean28 = monthDay26.isSupported(dateTimeFieldType27);
//        org.joda.time.MonthDay monthDay30 = monthDay26.withDayOfMonth(15);
//        int int31 = monthDay26.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology33.era();
//        java.lang.Class<?> wildcardClass35 = iSOChronology33.getClass();
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology33.dayOfMonth();
//        org.joda.time.DurationField durationField37 = iSOChronology33.seconds();
//        org.joda.time.MonthDay monthDay38 = monthDay26.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology33);
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
//        org.joda.time.DurationField durationField41 = iSOChronology40.halfdays();
//        org.joda.time.DateTimeField dateTimeField42 = iSOChronology40.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField44 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField42, dateTimeFieldType43);
//        java.util.Locale locale45 = null;
//        int int46 = delegatedDateTimeField44.getMaximumTextLength(locale45);
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = delegatedDateTimeField44.getType();
//        org.joda.time.MonthDay monthDay48 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeField[] dateTimeFieldArray49 = monthDay48.getFields();
//        java.util.Locale locale51 = null;
//        java.lang.String str52 = delegatedDateTimeField44.getAsText((org.joda.time.ReadablePartial) monthDay48, (-1), locale51);
//        long long55 = delegatedDateTimeField44.addWrapField((long) 15, 12);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone57);
//        org.joda.time.DurationField durationField59 = iSOChronology58.halfdays();
//        org.joda.time.DateTimeField dateTimeField60 = iSOChronology58.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType61 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField62 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField60, dateTimeFieldType61);
//        java.util.Locale locale63 = null;
//        int int64 = delegatedDateTimeField62.getMaximumTextLength(locale63);
//        org.joda.time.DateTimeFieldType dateTimeFieldType65 = delegatedDateTimeField62.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder56.appendText(dateTimeFieldType65);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder56.appendSecondOfMinute((int) (byte) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = new org.joda.time.format.DateTimeFormatterBuilder();
//        boolean boolean70 = dateTimeFormatterBuilder69.canBuildFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder71 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone72 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology73 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone72);
//        org.joda.time.DurationField durationField74 = iSOChronology73.halfdays();
//        org.joda.time.DateTimeField dateTimeField75 = iSOChronology73.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType76 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField77 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField75, dateTimeFieldType76);
//        java.util.Locale locale78 = null;
//        int int79 = delegatedDateTimeField77.getMaximumTextLength(locale78);
//        org.joda.time.DateTimeFieldType dateTimeFieldType80 = delegatedDateTimeField77.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder81 = dateTimeFormatterBuilder71.appendText(dateTimeFieldType80);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder82 = dateTimeFormatterBuilder69.appendText(dateTimeFieldType80);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder84 = dateTimeFormatterBuilder56.appendFixedSignedDecimal(dateTimeFieldType80, (int) (byte) 1);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField85 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField44, dateTimeFieldType80);
//        int int86 = monthDay26.indexOf(dateTimeFieldType80);
//        int int87 = monthDay16.indexOf(dateTimeFieldType80);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNull(durationField12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str13.equals("DateTimeField[minuteOfHour]"));
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(monthDay23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(monthDay30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(iSOChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(monthDay38);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(monthDay48);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray49);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "-1" + "'", str52.equals("-1"));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 720015L + "'", long55 == 720015L);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(iSOChronology58);
//        org.junit.Assert.assertNotNull(durationField59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 2 + "'", int64 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType65);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone72);
//        org.junit.Assert.assertNotNull(iSOChronology73);
//        org.junit.Assert.assertNotNull(durationField74);
//        org.junit.Assert.assertNotNull(dateTimeField75);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 2 + "'", int79 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType80);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder81);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder82);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder84);
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + (-1) + "'", int86 == (-1));
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + (-1) + "'", int87 == (-1));
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        boolean boolean5 = monthDay3.isSupported(dateTimeFieldType4);
        org.joda.time.MonthDay monthDay7 = monthDay3.withDayOfMonth(15);
        int[] intArray9 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay7, (long) (short) -1);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField11 = iSOChronology0.halfdays();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTime dateTime7 = dateTime1.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime9 = dateTime7.plusYears((-1));
//        java.lang.String str10 = dateTime9.toString();
//        org.joda.time.DateTime dateTime12 = dateTime9.withYearOfCentury(13);
//        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
//        org.joda.time.Instant instant14 = new org.joda.time.Instant((java.lang.Object) dateTime12);
//        org.joda.time.DateTime dateTime16 = dateTime12.minusDays(48634686);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1968-12-31T10:13:15.013-08:00" + "'", str10.equals("1968-12-31T10:13:15.013-08:00"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(35, 40);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1400 + "'", int2 == 1400);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
//        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
//        int int5 = property4.getMaximumValue();
//        org.joda.time.DateTime dateTime6 = property4.withMaximumValue();
//        int int7 = property4.get();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property4.getAsText(locale8);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "December" + "'", str9.equals("December"));
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property3 = dateTime0.yearOfCentury();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        boolean boolean4 = monthDay2.isSupported(dateTimeFieldType3);
//        org.joda.time.MonthDay monthDay6 = monthDay2.withDayOfMonth(15);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime dateTime10 = dateTime8.withHourOfDay(0);
//        int int11 = dateTime8.getDayOfMonth();
//        org.joda.time.DateTime dateTime12 = monthDay2.toDateTime((org.joda.time.ReadableInstant) dateTime8);
//        boolean boolean13 = dateTime8.isBeforeNow();
//        org.joda.time.DateTime.Property property14 = dateTime8.dayOfMonth();
//        int int15 = property14.getMaximumValue();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 31 + "'", int11 == 31);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 31 + "'", int15 == 31);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.halfdays();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType5);
        java.util.Locale locale7 = null;
        int int8 = delegatedDateTimeField6.getMaximumTextLength(locale7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = delegatedDateTimeField6.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendFractionOfHour(12, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder10.appendHourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder10.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendFractionOfDay(42, 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder18.appendFractionOfSecond(31, 0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
//        java.util.Locale locale6 = null;
//        int int7 = delegatedDateTimeField5.getMaximumTextLength(locale6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = delegatedDateTimeField5.getType();
//        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeField[] dateTimeFieldArray10 = monthDay9.getFields();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField5.getAsText((org.joda.time.ReadablePartial) monthDay9, (-1), locale12);
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
//        org.joda.time.DurationField durationField16 = iSOChronology15.halfdays();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType18);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = delegatedDateTimeField19.getAsText((long) (short) 1, locale21);
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
//        org.joda.time.DurationField durationField25 = iSOChronology24.halfdays();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology24.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(dateTimeZone27);
//        org.joda.time.DateTime dateTime30 = dateTime28.withHourOfDay(0);
//        org.joda.time.DateTime.Property property31 = dateTime30.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
//        org.joda.time.MonthDay monthDay34 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology33);
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = null;
//        boolean boolean36 = monthDay34.isSupported(dateTimeFieldType35);
//        int int37 = property31.compareTo((org.joda.time.ReadablePartial) monthDay34);
//        long long39 = iSOChronology24.set((org.joda.time.ReadablePartial) monthDay34, (long) 13);
//        java.util.Locale locale41 = null;
//        java.lang.String str42 = delegatedDateTimeField19.getAsText((org.joda.time.ReadablePartial) monthDay34, 15, locale41);
//        java.util.Locale locale44 = null;
//        java.lang.String str45 = delegatedDateTimeField19.getAsText((long) 0, locale44);
//        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone46);
//        org.joda.time.MonthDay monthDay48 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology47);
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = null;
//        boolean boolean50 = monthDay48.isSupported(dateTimeFieldType49);
//        org.joda.time.MonthDay monthDay52 = monthDay48.withDayOfMonth(15);
//        int int53 = delegatedDateTimeField19.getMaximumValue((org.joda.time.ReadablePartial) monthDay48);
//        org.joda.time.chrono.ISOChronology iSOChronology54 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone55);
//        org.joda.time.MonthDay monthDay57 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology56);
//        org.joda.time.DateTimeFieldType dateTimeFieldType58 = null;
//        boolean boolean59 = monthDay57.isSupported(dateTimeFieldType58);
//        org.joda.time.MonthDay monthDay61 = monthDay57.withDayOfMonth(15);
//        int[] intArray63 = iSOChronology54.get((org.joda.time.ReadablePartial) monthDay61, (long) (short) -1);
//        int int64 = delegatedDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) monthDay48, intArray63);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1" + "'", str13.equals("-1"));
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0" + "'", str22.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(iSOChronology33);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 13L + "'", long39 == 13L);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "15" + "'", str42.equals("15"));
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "0" + "'", str45.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertNotNull(iSOChronology47);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(monthDay52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 59 + "'", int53 == 59);
//        org.junit.Assert.assertNotNull(iSOChronology54);
//        org.junit.Assert.assertNotNull(dateTimeZone55);
//        org.junit.Assert.assertNotNull(iSOChronology56);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(monthDay61);
//        org.junit.Assert.assertNotNull(intArray63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
//        java.lang.Appendable appendable1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        org.joda.time.DateTime dateTime5 = dateTime3.withHourOfDay(0);
//        org.joda.time.DateTime.Property property6 = dateTime5.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology8);
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
//        boolean boolean11 = monthDay9.isSupported(dateTimeFieldType10);
//        int int12 = property6.compareTo((org.joda.time.ReadablePartial) monthDay9);
//        try {
//            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) monthDay9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.halfdays();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType5);
        java.util.Locale locale7 = null;
        int int8 = delegatedDateTimeField6.getMaximumTextLength(locale7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = delegatedDateTimeField6.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType9);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (int) (byte) -1, 43);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.era();
        java.lang.Class<?> wildcardClass18 = iSOChronology16.getClass();
        org.joda.time.DurationField durationField19 = iSOChronology16.seconds();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.DurationField durationField22 = iSOChronology21.halfdays();
        org.joda.time.DurationField durationField23 = iSOChronology21.halfdays();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField24 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType9, durationField19, durationField23);
        int int26 = preciseDateTimeField24.getMinimumValue((long) 47);
        long long27 = preciseDateTimeField24.getUnitMillis();
        java.util.Locale locale28 = null;
        int int29 = preciseDateTimeField24.getMaximumShortTextLength(locale28);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1000L + "'", long27 == 1000L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 5 + "'", int29 == 5);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTime dateTime7 = dateTime1.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime9 = dateTime1.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
//        org.joda.time.DateTime dateTime13 = dateTime11.withHourOfDay(0);
//        int int14 = dateTime11.getDayOfMonth();
//        boolean boolean15 = dateTime9.isBefore((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTime dateTime17 = dateTime11.plusDays(43199);
//        try {
//            org.joda.time.DateTime dateTime19 = dateTime17.withDayOfWeek(54);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 54 for dayOfWeek must be in the range [1,7]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("monthOfYear", number1, (java.lang.Number) 52L, (java.lang.Number) 49);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
//        int int4 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusDays((int) (byte) 10);
//        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfDay();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.halfdays();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType7);
        java.util.Locale locale9 = null;
        int int10 = delegatedDateTimeField8.getMaximumTextLength(locale9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = delegatedDateTimeField8.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder2.appendText(dateTimeFieldType11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DurationField durationField17 = iSOChronology16.halfdays();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18, dateTimeFieldType19);
        java.util.Locale locale21 = null;
        int int22 = delegatedDateTimeField20.getMaximumTextLength(locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField20.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder14.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder14.appendSecondOfMinute((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean28 = dateTimeFormatterBuilder27.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DurationField durationField32 = iSOChronology31.halfdays();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField35 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField33, dateTimeFieldType34);
        java.util.Locale locale36 = null;
        int int37 = delegatedDateTimeField35.getMaximumTextLength(locale36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = delegatedDateTimeField35.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder29.appendText(dateTimeFieldType38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder27.appendText(dateTimeFieldType38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder14.appendFixedSignedDecimal(dateTimeFieldType38, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder13.appendSignedDecimal(dateTimeFieldType38, (int) (byte) 10, 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException49 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, (java.lang.Number) 473328000028L, (java.lang.Number) 34, (java.lang.Number) 25);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2 + "'", int37 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        java.util.Locale locale6 = null;
        int int7 = delegatedDateTimeField5.getMaximumTextLength(locale6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = delegatedDateTimeField5.getType();
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeField[] dateTimeFieldArray10 = monthDay9.getFields();
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField5.getAsText((org.joda.time.ReadablePartial) monthDay9, (-1), locale12);
        long long16 = delegatedDateTimeField5.addWrapField((long) 15, 12);
        long long18 = delegatedDateTimeField5.roundHalfCeiling(0L);
        java.lang.String str20 = delegatedDateTimeField5.getAsShortText(13000L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(dateTimeFieldArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1" + "'", str13.equals("-1"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 720015L + "'", long16 == 720015L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendHourOfHalfday(30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendDayOfWeekShortText();
        boolean boolean6 = dateTimeFormatterBuilder4.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        int int4 = dateTime3.getSecondOfMinute();
//        org.joda.time.DateTime dateTime9 = dateTime3.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime11 = dateTime3.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime13);
//        int int16 = gJChronology15.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
//        org.joda.time.DurationField durationField19 = iSOChronology18.halfdays();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology18.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
//        int int23 = dateTime22.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone24 = dateTime22.getZone();
//        org.joda.time.Chronology chronology25 = iSOChronology18.withZone(dateTimeZone24);
//        java.lang.String str26 = dateTimeZone24.getID();
//        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone24);
//        long long31 = dateTimeZone24.convertLocalToUTC(1560630635325L, false, 10L);
//        org.joda.time.Chronology chronology32 = gJChronology15.withZone(dateTimeZone24);
//        org.joda.time.DateTimeField dateTimeField33 = gJChronology15.yearOfCentury();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "America/Los_Angeles" + "'", str26.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(julianChronology27);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560655835325L + "'", long31 == 1560655835325L);
//        org.junit.Assert.assertNotNull(chronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        boolean boolean4 = monthDay2.isSupported(dateTimeFieldType3);
//        org.joda.time.MonthDay monthDay6 = monthDay2.withDayOfMonth(15);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime dateTime10 = dateTime8.withHourOfDay(0);
//        int int11 = dateTime8.getDayOfMonth();
//        org.joda.time.DateTime dateTime12 = monthDay2.toDateTime((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime14 = dateTime8.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime dateTime16 = dateTime8.plusWeeks(1969);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 31 + "'", int11 == 31);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTime dateTime4 = dateTime1.minusMillis(2);
//        boolean boolean5 = dateTime1.isBeforeNow();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.DateTime dateTime9 = dateTime7.withHourOfDay(0);
//        org.joda.time.DateTime.Property property10 = dateTime9.monthOfYear();
//        org.joda.time.DateTime dateTime11 = property10.roundHalfCeilingCopy();
//        java.util.Locale locale12 = null;
//        int int13 = property10.getMaximumTextLength(locale12);
//        org.joda.time.DateTimeField dateTimeField14 = property10.getField();
//        int int15 = dateTime1.get(dateTimeField14);
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        int int18 = dateTime17.getSecondOfMinute();
//        org.joda.time.DateTime dateTime23 = dateTime17.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime25 = dateTime23.plusYears((-1));
//        java.lang.String str26 = dateTime25.toString();
//        java.lang.String str27 = dateTime25.toString();
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
//        org.joda.time.DurationField durationField30 = iSOChronology29.halfdays();
//        org.joda.time.DateTimeField dateTimeField31 = iSOChronology29.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(dateTimeZone32);
//        int int34 = dateTime33.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone35 = dateTime33.getZone();
//        org.joda.time.Chronology chronology36 = iSOChronology29.withZone(dateTimeZone35);
//        org.joda.time.DateTime dateTime37 = dateTime25.toDateTime(dateTimeZone35);
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime(dateTimeZone38);
//        java.util.GregorianCalendar gregorianCalendar40 = dateTime39.toGregorianCalendar();
//        org.joda.time.LocalTime localTime41 = dateTime39.toLocalTime();
//        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone35, (org.joda.time.ReadableInstant) dateTime39, 1);
//        org.joda.time.DateTime dateTime44 = dateTime1.withZoneRetainFields(dateTimeZone35);
//        org.joda.time.DateTime dateTime46 = dateTime1.withHourOfDay(1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1968-12-31T10:13:15.013-08:00" + "'", str26.equals("1968-12-31T10:13:15.013-08:00"));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1968-12-31T10:13:15.013-08:00" + "'", str27.equals("1968-12-31T10:13:15.013-08:00"));
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertNotNull(chronology36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(gregorianCalendar40);
//        org.junit.Assert.assertNotNull(localTime41);
//        org.junit.Assert.assertNotNull(gJChronology43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTime46);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        boolean boolean4 = gregorianChronology1.equals((java.lang.Object) 20);
        org.joda.time.DurationField durationField5 = gregorianChronology1.years();
        java.lang.String str6 = gregorianChronology1.toString();
        org.joda.time.Chronology chronology7 = gregorianChronology1.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        java.util.Locale locale6 = null;
        int int7 = delegatedDateTimeField5.getMaximumTextLength(locale6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = delegatedDateTimeField5.getType();
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeField[] dateTimeFieldArray10 = monthDay9.getFields();
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField5.getAsText((org.joda.time.ReadablePartial) monthDay9, (-1), locale12);
        long long16 = delegatedDateTimeField5.addWrapField((long) 15, 12);
        long long18 = delegatedDateTimeField5.remainder((long) 12);
        java.util.Locale locale19 = null;
        int int20 = delegatedDateTimeField5.getMaximumShortTextLength(locale19);
        long long23 = delegatedDateTimeField5.addWrapField((long) 36, 48627451);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(dateTimeFieldArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1" + "'", str13.equals("-1"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 720015L + "'", long16 == 720015L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 12L + "'", long18 == 12L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1860036L + "'", long23 == 1860036L);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
//        int int4 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusDays((int) (byte) 10);
//        org.joda.time.DateTime.Property property7 = dateTime6.millisOfSecond();
//        org.joda.time.DateTime dateTime8 = property7.withMaximumValue();
//        org.joda.time.DateTime dateTime10 = property7.addToCopy((long) (short) 0);
//        org.joda.time.DateTime dateTime12 = dateTime10.plusMonths(2000);
//        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
//        org.joda.time.DateTime dateTime14 = property13.roundHalfEvenCopy();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        int int4 = dateTime3.getSecondOfMinute();
//        org.joda.time.DateTime dateTime9 = dateTime3.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime11 = dateTime3.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime13);
//        int int16 = gJChronology15.getMinimumDaysInFirstWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        org.joda.time.Chronology chronology18 = dateTimeFormatter17.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTimeFormatter17.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology15, dateTimeZone19);
//        long long26 = zonedChronology20.getDateTimeMillis(1560630623999L, (int) (short) 0, 0, 12, 3);
//        org.joda.time.DateTimeField dateTimeField27 = zonedChronology20.weekOfWeekyear();
//        try {
//            long long33 = zonedChronology20.getDateTimeMillis(1560556812003L, 38, 7, 2000, (-46));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 38 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNull(chronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(zonedChronology20);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560556812003L + "'", long26 == 1560556812003L);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.era();
        java.lang.Class<?> wildcardClass3 = iSOChronology1.getClass();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 20);
        int int8 = offsetDateTimeField6.getMinimumValue((-1L));
        java.util.Locale locale9 = null;
        int int10 = offsetDateTimeField6.getMaximumShortTextLength(locale9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField6.getAsText(0L, locale12);
        int int16 = offsetDateTimeField6.getDifference((long) 9, (long) 2019);
        try {
            long long19 = offsetDateTimeField6.set((long) (-1104), "");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 21 + "'", int8 == 21);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "21" + "'", str13.equals("21"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(chronology4);
//        int int6 = dateTime5.getYear();
//        org.joda.time.LocalTime localTime7 = dateTime5.toLocalTime();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        org.joda.time.DateTime dateTime11 = dateTime9.withHourOfDay(0);
//        org.joda.time.DateTime.Property property12 = dateTime11.minuteOfHour();
//        boolean boolean13 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime11);
//        java.lang.Class<?> wildcardClass14 = dateTime11.getClass();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
//        org.junit.Assert.assertNotNull(localTime7);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTime dateTime7 = dateTime1.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime9 = dateTime7.plusYears((-1));
//        java.lang.String str10 = dateTime9.toString();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime9.plus(readablePeriod11);
//        org.joda.time.DateTime dateTime14 = dateTime9.minusMonths(74);
//        org.joda.time.Instant instant15 = dateTime9.toInstant();
//        org.joda.time.Instant instant16 = instant15.toInstant();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1968-12-31T10:13:15.013-08:00" + "'", str10.equals("1968-12-31T10:13:15.013-08:00"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(instant15);
//        org.junit.Assert.assertNotNull(instant16);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((long) 12, (org.joda.time.Chronology) buddhistChronology1);
        org.junit.Assert.assertNotNull(buddhistChronology1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.weekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.minutes();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        java.util.Locale locale7 = null;
        java.lang.String str8 = delegatedDateTimeField5.getAsText((long) (short) 1, locale7);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        boolean boolean13 = monthDay11.isSupported(dateTimeFieldType12);
        org.joda.time.MonthDay monthDay15 = monthDay11.withDayOfMonth(15);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.MonthDay monthDay17 = monthDay15.plus(readablePeriod16);
        int int18 = monthDay17.getDayOfMonth();
        int int19 = delegatedDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) monthDay17);
        long long22 = delegatedDateTimeField5.add((-59L), 27);
        long long24 = delegatedDateTimeField5.roundHalfFloor((long) 9);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1619941L + "'", long22 == 1619941L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.era();
//        java.lang.Class<?> wildcardClass3 = iSOChronology1.getClass();
//        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DurationField durationField5 = iSOChronology1.millis();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        int int8 = dateTime7.getSecondOfMinute();
//        org.joda.time.DateTime dateTime13 = dateTime7.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime15 = dateTime13.plusYears((-1));
//        java.lang.String str16 = dateTime15.toString();
//        java.lang.String str17 = dateTime15.toString();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
//        org.joda.time.DurationField durationField20 = iSOChronology19.halfdays();
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology19.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
//        int int24 = dateTime23.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone25 = dateTime23.getZone();
//        org.joda.time.Chronology chronology26 = iSOChronology19.withZone(dateTimeZone25);
//        org.joda.time.DateTime dateTime27 = dateTime15.toDateTime(dateTimeZone25);
//        org.joda.time.DateTime dateTime29 = dateTime27.minusWeeks((int) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
//        org.joda.time.DateTime dateTime33 = dateTime31.withHourOfDay(0);
//        org.joda.time.DateTime dateTime34 = dateTime33.withEarlierOffsetAtOverlap();
//        boolean boolean35 = dateTime27.isAfter((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone36);
//        org.joda.time.MonthDay monthDay38 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = null;
//        boolean boolean40 = monthDay38.isSupported(dateTimeFieldType39);
//        org.joda.time.MonthDay monthDay42 = monthDay38.withDayOfMonth(15);
//        org.joda.time.DateTime dateTime43 = dateTime34.withFields((org.joda.time.ReadablePartial) monthDay38);
//        org.joda.time.DateTime dateTime45 = dateTime43.plusWeeks(22);
//        org.joda.time.ReadableDateTime readableDateTime46 = null;
//        org.joda.time.chrono.LimitChronology limitChronology47 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.ReadableDateTime) dateTime43, readableDateTime46);
//        org.joda.time.DateTime dateTime48 = limitChronology47.getUpperLimit();
//        try {
//            long long53 = limitChronology47.getDateTimeMillis(57, (int) 'a', 5, 26);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1968-12-31T10:13:15.013-08:00" + "'", str16.equals("1968-12-31T10:13:15.013-08:00"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1968-12-31T10:13:15.013-08:00" + "'", str17.equals("1968-12-31T10:13:15.013-08:00"));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(iSOChronology37);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(monthDay42);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(limitChronology47);
//        org.junit.Assert.assertNull(dateTime48);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.era();
        java.lang.Class<?> wildcardClass3 = iSOChronology1.getClass();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 20);
        org.joda.time.DateTimeField dateTimeField7 = offsetDateTimeField6.getWrappedField();
        java.lang.String str9 = offsetDateTimeField6.getAsShortText(86400000L);
        org.joda.time.DurationField durationField10 = offsetDateTimeField6.getRangeDurationField();
        long long12 = offsetDateTimeField6.roundCeiling(0L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "22" + "'", str9.equals("22"));
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
//        int int3 = dateTime1.getYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfHour();
//        try {
//            org.joda.time.DateTime dateTime6 = dateTime1.withDayOfMonth(56);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 56 for dayOfMonth must be in the range [1,31]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianCalendar2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
//        org.junit.Assert.assertNotNull(property4);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(42, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 49, (java.lang.Number) 0L, (java.lang.Number) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
//        int int4 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusDays((int) (byte) 10);
//        org.joda.time.DateTime.Property property7 = dateTime6.millisOfSecond();
//        org.joda.time.DateTime dateTime8 = property7.withMaximumValue();
//        org.joda.time.DateTime dateTime10 = property7.addToCopy((long) 47);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        java.util.Locale locale6 = null;
        int int7 = delegatedDateTimeField5.getMaximumTextLength(locale6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = delegatedDateTimeField5.getType();
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeField[] dateTimeFieldArray10 = monthDay9.getFields();
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField5.getAsText((org.joda.time.ReadablePartial) monthDay9, (-1), locale12);
        long long16 = delegatedDateTimeField5.addWrapField((long) 15, 12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = iSOChronology19.halfdays();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology19.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21, dateTimeFieldType22);
        java.util.Locale locale24 = null;
        int int25 = delegatedDateTimeField23.getMaximumTextLength(locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = delegatedDateTimeField23.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder17.appendText(dateTimeFieldType26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder17.appendSecondOfMinute((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean31 = dateTimeFormatterBuilder30.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone33);
        org.joda.time.DurationField durationField35 = iSOChronology34.halfdays();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField36, dateTimeFieldType37);
        java.util.Locale locale39 = null;
        int int40 = delegatedDateTimeField38.getMaximumTextLength(locale39);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = delegatedDateTimeField38.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder32.appendText(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder30.appendText(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder17.appendFixedSignedDecimal(dateTimeFieldType41, (int) (byte) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField46 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, dateTimeFieldType41);
        java.lang.String str48 = delegatedDateTimeField46.getAsText(0L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(dateTimeFieldArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1" + "'", str13.equals("-1"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 720015L + "'", long16 == 720015L);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "0" + "'", str48.equals("0"));
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        int int4 = dateTime3.getSecondOfMinute();
//        org.joda.time.DateTime dateTime9 = dateTime3.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime11 = dateTime3.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime13);
//        int int16 = gJChronology15.getMinimumDaysInFirstWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        org.joda.time.Chronology chronology18 = dateTimeFormatter17.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTimeFormatter17.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology15, dateTimeZone19);
//        try {
//            long long26 = zonedChronology20.getDateTimeMillis((long) (byte) 1, 14, 10, (-46), 48);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -46 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNull(chronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(zonedChronology20);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
        org.joda.time.DateTime.Property property4 = dateTime3.dayOfWeek();
        org.joda.time.DurationField durationField5 = property4.getRangeDurationField();
        org.joda.time.DateTime dateTime7 = property4.addWrapFieldToCopy(55);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusYears(15);
//        org.joda.time.DateTime dateTime6 = dateTime3.toDateTimeISO();
//        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 14, (int) (byte) -1);
//        int int10 = dateTime9.getWeekOfWeekyear();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 40);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, 473328000028L, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.halfdays();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType5);
        java.util.Locale locale7 = null;
        int int8 = delegatedDateTimeField6.getMaximumTextLength(locale7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = delegatedDateTimeField6.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.appendSecondOfMinute((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder0.appendYearOfEra(38, (int) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = copticChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.year();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.lang.String str4 = dateTimeZone2.getShortName((long) 13);
//        boolean boolean6 = dateTimeZone2.isStandardOffset(0L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((-86L));
        org.joda.time.Instant instant2 = instant1.toInstant();
        org.joda.time.Instant instant4 = instant2.minus((long) 28);
        org.joda.time.Instant instant6 = instant4.minus((long) 35);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant8 = instant6.plus(readableDuration7);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant8);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.era();
        java.lang.Class<?> wildcardClass3 = iSOChronology1.getClass();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 20);
        org.joda.time.DateTimeField dateTimeField7 = offsetDateTimeField6.getWrappedField();
        java.util.Locale locale9 = null;
        java.lang.String str10 = offsetDateTimeField6.getAsShortText(26, locale9);
        org.joda.time.DurationField durationField11 = offsetDateTimeField6.getLeapDurationField();
        boolean boolean13 = offsetDateTimeField6.isLeap((-180L));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "26" + "'", str10.equals("26"));
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        try {
            long long8 = gregorianChronology1.getDateTimeMillis(34, (int) '#', 10, 811);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        int int4 = dateTime3.getSecondOfMinute();
//        org.joda.time.DateTime dateTime9 = dateTime3.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime11 = dateTime3.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime13);
//        java.lang.String str16 = gJChronology15.toString();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "GJChronology[America/Los_Angeles,cutover=1068-12-31T23:52:58.028Z]" + "'", str16.equals("GJChronology[America/Los_Angeles,cutover=1068-12-31T23:52:58.028Z]"));
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        int int1 = monthDay0.size();
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.era();
//        java.lang.Class<?> wildcardClass3 = iSOChronology1.getClass();
//        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DurationField durationField5 = iSOChronology1.millis();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        int int8 = dateTime7.getSecondOfMinute();
//        org.joda.time.DateTime dateTime13 = dateTime7.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime15 = dateTime13.plusYears((-1));
//        java.lang.String str16 = dateTime15.toString();
//        java.lang.String str17 = dateTime15.toString();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
//        org.joda.time.DurationField durationField20 = iSOChronology19.halfdays();
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology19.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
//        int int24 = dateTime23.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone25 = dateTime23.getZone();
//        org.joda.time.Chronology chronology26 = iSOChronology19.withZone(dateTimeZone25);
//        org.joda.time.DateTime dateTime27 = dateTime15.toDateTime(dateTimeZone25);
//        org.joda.time.DateTime dateTime29 = dateTime27.minusWeeks((int) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
//        org.joda.time.DateTime dateTime33 = dateTime31.withHourOfDay(0);
//        org.joda.time.DateTime dateTime34 = dateTime33.withEarlierOffsetAtOverlap();
//        boolean boolean35 = dateTime27.isAfter((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone36);
//        org.joda.time.MonthDay monthDay38 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = null;
//        boolean boolean40 = monthDay38.isSupported(dateTimeFieldType39);
//        org.joda.time.MonthDay monthDay42 = monthDay38.withDayOfMonth(15);
//        org.joda.time.DateTime dateTime43 = dateTime34.withFields((org.joda.time.ReadablePartial) monthDay38);
//        org.joda.time.DateTime dateTime45 = dateTime43.plusWeeks(22);
//        org.joda.time.ReadableDateTime readableDateTime46 = null;
//        org.joda.time.chrono.LimitChronology limitChronology47 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.ReadableDateTime) dateTime43, readableDateTime46);
//        org.joda.time.DateTime dateTime48 = limitChronology47.getLowerLimit();
//        org.joda.time.DateTimeField dateTimeField49 = limitChronology47.millisOfSecond();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1968-12-31T10:13:15.013-08:00" + "'", str16.equals("1968-12-31T10:13:15.013-08:00"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1968-12-31T10:13:15.013-08:00" + "'", str17.equals("1968-12-31T10:13:15.013-08:00"));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(iSOChronology37);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(monthDay42);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(limitChronology47);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        boolean boolean4 = monthDay2.isSupported(dateTimeFieldType3);
//        org.joda.time.MonthDay monthDay6 = monthDay2.withDayOfMonth(15);
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.MonthDay monthDay8 = monthDay6.plus(readablePeriod7);
//        org.joda.time.MonthDay.Property property9 = monthDay8.dayOfMonth();
//        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.parse("");
//        int int12 = property9.compareTo((org.joda.time.ReadablePartial) monthDay11);
//        org.joda.time.MonthDay monthDay14 = property9.addToCopy((int) (byte) 0);
//        int int15 = property9.getMaximumValueOverall();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime19 = dateTime17.withHourOfDay(0);
//        int int20 = dateTime17.getDayOfMonth();
//        org.joda.time.DateTime dateTime22 = dateTime17.plusDays((int) (byte) 10);
//        org.joda.time.DateTime.Property property23 = dateTime22.millisOfSecond();
//        org.joda.time.DateTime dateTime24 = property23.withMaximumValue();
//        int int25 = property9.compareTo((org.joda.time.ReadableInstant) dateTime24);
//        java.util.Locale locale26 = null;
//        int int27 = property9.getMaximumShortTextLength(locale26);
//        org.joda.time.MonthDay monthDay29 = property9.addToCopy(48634686);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(monthDay11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(monthDay14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 31 + "'", int15 == 31);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 31 + "'", int20 == 31);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
//        org.junit.Assert.assertNotNull(monthDay29);
//    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTime dateTime7 = dateTime1.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime9 = dateTime1.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime11 = dateTime9.minusYears(1);
//        org.joda.time.DateTime dateTime14 = dateTime9.withDurationAdded((-15L), 0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
//        java.io.Writer writer3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.DateTime dateTime7 = dateTime5.withHourOfDay(0);
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.toDateTime(chronology8);
//        int int10 = dateTime9.getYear();
//        org.joda.time.LocalTime localTime11 = dateTime9.toLocalTime();
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime9.toDateTime(chronology12);
//        org.joda.time.DateTime dateTime15 = dateTime9.minus((long) 37);
//        try {
//            dateTimeFormatter0.printTo(writer3, (org.joda.time.ReadableInstant) dateTime9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
//        org.junit.Assert.assertNotNull(localTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(32);
        org.joda.time.Chronology chronology3 = dateTimeFormatter2.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.era();
        java.lang.Class<?> wildcardClass3 = iSOChronology1.getClass();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 20);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 1);
        long long10 = offsetDateTimeField6.remainder(86400000L);
        long long13 = offsetDateTimeField6.addWrapField((long) 100, (int) (short) 100);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 604800100L + "'", long13 == 604800100L);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        int int4 = dateTime3.getSecondOfMinute();
//        org.joda.time.DateTime dateTime9 = dateTime3.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime11 = dateTime3.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime13);
//        int int16 = gJChronology15.getMinimumDaysInFirstWeek();
//        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = copticChronology17.clockhourOfDay();
//        org.joda.time.DurationField durationField19 = copticChronology17.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
//        org.joda.time.DurationField durationField22 = iSOChronology21.halfdays();
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology21.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(dateTimeZone24);
//        int int26 = dateTime25.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone27 = dateTime25.getZone();
//        org.joda.time.Chronology chronology28 = iSOChronology21.withZone(dateTimeZone27);
//        java.lang.String str29 = dateTimeZone27.getID();
//        org.joda.time.Chronology chronology30 = copticChronology17.withZone(dateTimeZone27);
//        org.joda.time.Chronology chronology31 = gJChronology15.withZone(dateTimeZone27);
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
//        org.joda.time.DurationField durationField34 = iSOChronology33.halfdays();
//        org.joda.time.DateTimeField dateTimeField35 = iSOChronology33.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField35, dateTimeFieldType36);
//        java.util.Locale locale38 = null;
//        int int39 = delegatedDateTimeField37.getMaximumTextLength(locale38);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = delegatedDateTimeField37.getType();
//        org.joda.time.MonthDay monthDay41 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeField[] dateTimeFieldArray42 = monthDay41.getFields();
//        java.util.Locale locale44 = null;
//        java.lang.String str45 = delegatedDateTimeField37.getAsText((org.joda.time.ReadablePartial) monthDay41, (-1), locale44);
//        long long48 = delegatedDateTimeField37.addWrapField((long) 15, 12);
//        long long50 = delegatedDateTimeField37.roundHalfCeiling(0L);
//        java.util.Locale locale52 = null;
//        java.lang.String str53 = delegatedDateTimeField37.getAsShortText(10, locale52);
//        long long56 = delegatedDateTimeField37.add((long) '#', (long) 41);
//        boolean boolean58 = delegatedDateTimeField37.isLeap((long) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField60 = new org.joda.time.field.SkipUndoDateTimeField(chronology31, (org.joda.time.DateTimeField) delegatedDateTimeField37, 13);
//        int int62 = skipUndoDateTimeField60.get((long) 15);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
//        org.junit.Assert.assertNotNull(copticChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "America/Los_Angeles" + "'", str29.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(chronology30);
//        org.junit.Assert.assertNotNull(chronology31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(iSOChronology33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertNotNull(monthDay41);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray42);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "-1" + "'", str45.equals("-1"));
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 720015L + "'", long48 == 720015L);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "10" + "'", str53.equals("10"));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 2460035L + "'", long56 == 2460035L);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
//    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        int int4 = dateTime3.getSecondOfMinute();
//        org.joda.time.DateTime dateTime9 = dateTime3.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime11 = dateTime3.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime13);
//        int int16 = gJChronology15.getMinimumDaysInFirstWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        org.joda.time.Chronology chronology18 = dateTimeFormatter17.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTimeFormatter17.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology15, dateTimeZone19);
//        long long26 = zonedChronology20.getDateTimeMillis(1560630623999L, (int) (short) 0, 0, 12, 3);
//        org.joda.time.DateTimeField dateTimeField27 = zonedChronology20.halfdayOfDay();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNull(chronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(zonedChronology20);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560556812003L + "'", long26 == 1560556812003L);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("dayOfWeek");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"dayOfWeek\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 11);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendTwoDigitYear(58, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear((int) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        int int5 = julianChronology4.getMinimumDaysInFirstWeek();
        int int6 = julianChronology4.getMinimumDaysInFirstWeek();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(17, false);
        boolean boolean11 = julianChronology4.equals((java.lang.Object) dateTimeFormatterBuilder10);
        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology4.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeZone12);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        boolean boolean4 = monthDay2.isSupported(dateTimeFieldType3);
        org.joda.time.MonthDay monthDay6 = monthDay2.withDayOfMonth(15);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay8 = monthDay6.plus(readablePeriod7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay10 = monthDay8.minus(readablePeriod9);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray11 = monthDay10.getFieldTypes();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray11);
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime1.getZone();
//        java.lang.String str4 = dateTimeZone3.getID();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "America/Los_Angeles" + "'", str4.equals("America/Los_Angeles"));
//    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.clockhourOfDay();
//        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
//        boolean boolean4 = copticChronology0.equals((java.lang.Object) "UTC");
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        org.joda.time.DurationField durationField7 = iSOChronology6.halfdays();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8, dateTimeFieldType9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField10.getAsText((long) (short) 1, locale12);
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
//        org.joda.time.DurationField durationField16 = iSOChronology15.halfdays();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone18);
//        org.joda.time.DateTime dateTime21 = dateTime19.withHourOfDay(0);
//        org.joda.time.DateTime.Property property22 = dateTime21.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
//        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology24);
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
//        boolean boolean27 = monthDay25.isSupported(dateTimeFieldType26);
//        int int28 = property22.compareTo((org.joda.time.ReadablePartial) monthDay25);
//        long long30 = iSOChronology15.set((org.joda.time.ReadablePartial) monthDay25, (long) 13);
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = delegatedDateTimeField10.getAsText((org.joda.time.ReadablePartial) monthDay25, 15, locale32);
//        int int35 = delegatedDateTimeField10.getLeapAmount((-86L));
//        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField10);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 14256000013L + "'", long30 == 14256000013L);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "15" + "'", str33.equals("15"));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        int int5 = dateTime4.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone6 = dateTime4.getZone();
//        int int7 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        boolean boolean1 = dateTimeFormatterBuilder0.canBuildFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
//        dateTimeFormatterBuilder2.clear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        int int6 = dateTime5.getSecondOfMinute();
//        org.joda.time.DateTime dateTime11 = dateTime5.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime13 = dateTime5.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
//        org.joda.time.DateTime dateTime17 = dateTime15.withHourOfDay(0);
//        int int18 = dateTime15.getDayOfMonth();
//        boolean boolean19 = dateTime13.isBefore((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        boolean boolean21 = dateTimeFormatter20.isPrinter();
//        java.lang.String str22 = dateTime15.toString(dateTimeFormatter20);
//        java.util.Locale locale23 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter20.withLocale(locale23);
//        org.joda.time.format.DateTimePrinter dateTimePrinter25 = dateTimeFormatter24.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatter26.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter25, dateTimeParser27);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.appendClockhourOfHalfday(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder29.appendCenturyOfEra(0, 2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder29.appendClockhourOfDay(9);
//        org.joda.time.format.DateTimeParser dateTimeParser37 = dateTimeFormatterBuilder29.toParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder38.appendClockhourOfHalfday(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder38.appendCenturyOfEra(0, 2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder38.appendClockhourOfDay(9);
//        org.joda.time.format.DateTimeParser dateTimeParser46 = dateTimeFormatterBuilder38.toParser();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray47 = new org.joda.time.format.DateTimeParser[] { dateTimeParser37, dateTimeParser46 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder2.append(dateTimePrinter25, dateTimeParserArray47);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone50);
//        org.joda.time.DurationField durationField52 = iSOChronology51.halfdays();
//        org.joda.time.DateTimeField dateTimeField53 = iSOChronology51.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType54 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField55 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField53, dateTimeFieldType54);
//        java.util.Locale locale56 = null;
//        int int57 = delegatedDateTimeField55.getMaximumTextLength(locale56);
//        org.joda.time.DateTimeFieldType dateTimeFieldType58 = delegatedDateTimeField55.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder49.appendText(dateTimeFieldType58);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder49.appendSecondOfMinute((int) (byte) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = new org.joda.time.format.DateTimeFormatterBuilder();
//        boolean boolean63 = dateTimeFormatterBuilder62.canBuildFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone65 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology66 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone65);
//        org.joda.time.DurationField durationField67 = iSOChronology66.halfdays();
//        org.joda.time.DateTimeField dateTimeField68 = iSOChronology66.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType69 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField70 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField68, dateTimeFieldType69);
//        java.util.Locale locale71 = null;
//        int int72 = delegatedDateTimeField70.getMaximumTextLength(locale71);
//        org.joda.time.DateTimeFieldType dateTimeFieldType73 = delegatedDateTimeField70.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder74 = dateTimeFormatterBuilder64.appendText(dateTimeFieldType73);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder75 = dateTimeFormatterBuilder62.appendText(dateTimeFieldType73);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder77 = dateTimeFormatterBuilder49.appendFixedSignedDecimal(dateTimeFieldType73, (int) (byte) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder78 = dateTimeFormatterBuilder48.appendShortText(dateTimeFieldType73);
//        org.joda.time.DateTimeZone dateTimeZone79 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology80 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone79);
//        org.joda.time.DateTimeField dateTimeField81 = iSOChronology80.era();
//        java.lang.Class<?> wildcardClass82 = iSOChronology80.getClass();
//        org.joda.time.MonthDay monthDay83 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology80);
//        org.joda.time.DurationField durationField84 = iSOChronology80.days();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField85 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType73, durationField84);
//        try {
//            int int87 = unsupportedDateTimeField85.getLeapAmount((-180L));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 36 + "'", int6 == 36);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "20" + "'", str22.equals("20"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertNotNull(dateTimePrinter25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(dateTimeParser27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertNotNull(dateTimeParser37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(dateTimeParser46);
//        org.junit.Assert.assertNotNull(dateTimeParserArray47);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertNotNull(iSOChronology51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2 + "'", int57 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType58);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone65);
//        org.junit.Assert.assertNotNull(iSOChronology66);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertNotNull(dateTimeField68);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2 + "'", int72 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType73);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder74);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder75);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder77);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder78);
//        org.junit.Assert.assertNotNull(dateTimeZone79);
//        org.junit.Assert.assertNotNull(iSOChronology80);
//        org.junit.Assert.assertNotNull(dateTimeField81);
//        org.junit.Assert.assertNotNull(wildcardClass82);
//        org.junit.Assert.assertNotNull(durationField84);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField85);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((-1104), 48665042, 23, (int) ' ');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 28 + "'", int4 == 28);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
//        int int4 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusDays((int) (byte) 10);
//        org.joda.time.DateTime.Property property7 = dateTime6.millisOfSecond();
//        org.joda.time.DateTime dateTime9 = dateTime6.plusMinutes(48627451);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = delegatedDateTimeField5.getAsText((long) (short) 1, locale7);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.DurationField durationField11 = iSOChronology10.halfdays();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology10.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
//        org.joda.time.DateTime dateTime16 = dateTime14.withHourOfDay(0);
//        org.joda.time.DateTime.Property property17 = dateTime16.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
//        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
//        boolean boolean22 = monthDay20.isSupported(dateTimeFieldType21);
//        int int23 = property17.compareTo((org.joda.time.ReadablePartial) monthDay20);
//        long long25 = iSOChronology10.set((org.joda.time.ReadablePartial) monthDay20, (long) 13);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = delegatedDateTimeField5.getAsText((org.joda.time.ReadablePartial) monthDay20, 15, locale27);
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
//        org.joda.time.MonthDay monthDay31 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology30);
//        java.lang.String str32 = monthDay31.toString();
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = delegatedDateTimeField5.getAsText((org.joda.time.ReadablePartial) monthDay31, (int) (short) 0, locale34);
//        int int37 = delegatedDateTimeField5.getLeapAmount(18062L);
//        long long39 = delegatedDateTimeField5.roundCeiling((long) 2019);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 14256000013L + "'", long25 == 14256000013L);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "15" + "'", str28.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "--06-15" + "'", str32.equals("--06-15"));
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "0" + "'", str35.equals("0"));
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 60000L + "'", long39 == 60000L);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        java.util.Locale locale6 = null;
        int int7 = delegatedDateTimeField5.getMaximumTextLength(locale6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = delegatedDateTimeField5.getType();
        java.util.Locale locale9 = null;
        int int10 = delegatedDateTimeField5.getMaximumTextLength(locale9);
        org.joda.time.DurationField durationField11 = delegatedDateTimeField5.getDurationField();
        java.util.Locale locale12 = null;
        int int13 = delegatedDateTimeField5.getMaximumShortTextLength(locale12);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField5.getLeapDurationField();
        int int17 = delegatedDateTimeField5.getDifference((long) 28, 0L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField2 = copticChronology0.weekyears();
        org.joda.time.DurationField durationField3 = copticChronology0.eras();
        try {
            long long8 = copticChronology0.getDateTimeMillis(6, 1969, 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        int int6 = dateTime5.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime5.getZone();
//        org.joda.time.Chronology chronology8 = iSOChronology1.withZone(dateTimeZone7);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology1.hourOfHalfday();
//        org.joda.time.Chronology chronology10 = iSOChronology1.withUTC();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 36 + "'", int6 == 36);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(chronology10);
//    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        boolean boolean4 = monthDay2.isSupported(dateTimeFieldType3);
//        org.joda.time.MonthDay monthDay6 = monthDay2.withDayOfMonth(15);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime dateTime10 = dateTime8.withHourOfDay(0);
//        int int11 = dateTime8.getDayOfMonth();
//        org.joda.time.DateTime dateTime12 = monthDay2.toDateTime((org.joda.time.ReadableInstant) dateTime8);
//        boolean boolean13 = dateTime8.isBeforeNow();
//        org.joda.time.DateTime dateTime15 = dateTime8.minusMinutes(15);
//        org.joda.time.DateTime dateTime16 = dateTime15.withTimeAtStartOfDay();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
//        java.util.Locale locale6 = null;
//        int int7 = delegatedDateTimeField5.getMaximumTextLength(locale6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = delegatedDateTimeField5.getType();
//        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeField[] dateTimeFieldArray10 = monthDay9.getFields();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField5.getAsText((org.joda.time.ReadablePartial) monthDay9, (-1), locale12);
//        long long16 = delegatedDateTimeField5.addWrapField((long) 15, 12);
//        long long18 = delegatedDateTimeField5.roundHalfCeiling(0L);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = delegatedDateTimeField5.getAsText(0, locale20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = delegatedDateTimeField5.getAsText((long) (byte) 1, locale23);
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(dateTimeZone25);
//        int int27 = dateTime26.getSecondOfMinute();
//        org.joda.time.DateTime dateTime32 = dateTime26.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone33);
//        org.joda.time.DateTimeField dateTimeField35 = iSOChronology34.era();
//        java.lang.Class<?> wildcardClass36 = iSOChronology34.getClass();
//        org.joda.time.DateTimeField dateTimeField37 = iSOChronology34.dayOfMonth();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, 20);
//        long long42 = offsetDateTimeField39.getDifferenceAsLong(1560630624063L, (long) 100);
//        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone43);
//        org.joda.time.MonthDay monthDay45 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology44);
//        org.joda.time.DateTimeFieldType dateTimeFieldType46 = null;
//        boolean boolean47 = monthDay45.isSupported(dateTimeFieldType46);
//        org.joda.time.MonthDay monthDay49 = monthDay45.withDayOfMonth(15);
//        org.joda.time.ReadablePeriod readablePeriod50 = null;
//        org.joda.time.MonthDay monthDay51 = monthDay49.plus(readablePeriod50);
//        org.joda.time.MonthDay monthDay53 = monthDay51.plusDays(22);
//        org.joda.time.chrono.ISOChronology iSOChronology54 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone55);
//        org.joda.time.MonthDay monthDay57 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology56);
//        org.joda.time.DateTimeFieldType dateTimeFieldType58 = null;
//        boolean boolean59 = monthDay57.isSupported(dateTimeFieldType58);
//        org.joda.time.MonthDay monthDay61 = monthDay57.withDayOfMonth(15);
//        int[] intArray63 = iSOChronology54.get((org.joda.time.ReadablePartial) monthDay61, (long) (short) -1);
//        int int64 = offsetDateTimeField39.getMinimumValue((org.joda.time.ReadablePartial) monthDay51, intArray63);
//        org.joda.time.DateTime dateTime65 = dateTime26.withFields((org.joda.time.ReadablePartial) monthDay51);
//        int[] intArray67 = null;
//        try {
//            int[] intArray69 = delegatedDateTimeField5.add((org.joda.time.ReadablePartial) monthDay51, (-1), intArray67, (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1" + "'", str13.equals("-1"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 720015L + "'", long16 == 720015L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "0" + "'", str24.equals("0"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 36 + "'", int27 == 36);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 18062L + "'", long42 == 18062L);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertNotNull(iSOChronology44);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(monthDay49);
//        org.junit.Assert.assertNotNull(monthDay51);
//        org.junit.Assert.assertNotNull(monthDay53);
//        org.junit.Assert.assertNotNull(iSOChronology54);
//        org.junit.Assert.assertNotNull(dateTimeZone55);
//        org.junit.Assert.assertNotNull(iSOChronology56);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(monthDay61);
//        org.junit.Assert.assertNotNull(intArray63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 21 + "'", int64 == 21);
//        org.junit.Assert.assertNotNull(dateTime65);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.halfdays();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType5);
        java.util.Locale locale7 = null;
        int int8 = delegatedDateTimeField6.getMaximumTextLength(locale7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = delegatedDateTimeField6.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType9);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (int) (byte) -1, 43);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.era();
        java.lang.Class<?> wildcardClass18 = iSOChronology16.getClass();
        org.joda.time.DurationField durationField19 = iSOChronology16.seconds();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.DurationField durationField22 = iSOChronology21.halfdays();
        org.joda.time.DurationField durationField23 = iSOChronology21.halfdays();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField24 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType9, durationField19, durationField23);
        org.joda.time.DurationField durationField25 = preciseDateTimeField24.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(durationField25);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
//        int int4 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusDays((int) (byte) 10);
//        org.joda.time.DateTime.Property property7 = dateTime6.millisOfSecond();
//        org.joda.time.DateTime dateTime8 = property7.withMaximumValue();
//        java.util.Locale locale9 = null;
//        int int10 = property7.getMaximumShortTextLength(locale9);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property7.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 42, "dayOfWeek");
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
        org.joda.time.DateTime dateTime5 = dateTime1.minusWeeks((int) (byte) 1);
        org.joda.time.Chronology chronology6 = dateTime1.getChronology();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime1.minus(readableDuration7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) dateTime8);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getSecondOfMinute();
//        int int3 = dateTime1.getEra();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36 + "'", int2 == 36);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(chronology4);
//        int int6 = dateTime5.getYear();
//        int int7 = dateTime5.getSecondOfMinute();
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime10 = dateTime5.withPeriodAdded(readablePeriod8, 811);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 36 + "'", int7 == 36);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("Dec", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Dec/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.era();
        java.lang.Class<?> wildcardClass3 = iSOChronology1.getClass();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 20);
        org.joda.time.DateTimeField dateTimeField7 = offsetDateTimeField6.getWrappedField();
        org.joda.time.DurationField durationField8 = offsetDateTimeField6.getDurationField();
        java.util.Locale locale9 = null;
        int int10 = offsetDateTimeField6.getMaximumShortTextLength(locale9);
        long long12 = offsetDateTimeField6.roundHalfCeiling(28800100L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        int int3 = dateTime2.getSecondOfMinute();
//        org.joda.time.DateTime dateTime8 = dateTime2.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime10 = dateTime2.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime12 = dateTime10.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
//        int int16 = dateTime15.getSecondOfMinute();
//        org.joda.time.DateTime dateTime21 = dateTime15.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime23 = dateTime15.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone24);
//        org.joda.time.DateTime dateTime27 = dateTime23.withZone(dateTimeZone24);
//        int int28 = dateTime23.getCenturyOfEra();
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeUtils.getZone(dateTimeZone29);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(dateTimeZone32);
//        int int34 = dateTime33.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone35 = dateTime33.getZone();
//        int int36 = dateTimeZone29.getOffset((org.joda.time.ReadableInstant) dateTime33);
//        org.joda.time.ReadableDuration readableDuration37 = null;
//        org.joda.time.DateTime dateTime38 = dateTime33.minus(readableDuration37);
//        org.joda.time.chrono.LimitChronology limitChronology39 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology13, (org.joda.time.ReadableDateTime) dateTime23, (org.joda.time.ReadableDateTime) dateTime33);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 36 + "'", int3 == 36);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 36 + "'", int16 == 36);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 36 + "'", int34 == 36);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(limitChronology39);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        int int5 = property4.getMaximumValue();
        org.joda.time.Interval interval6 = property4.toInterval();
        java.util.Locale locale7 = null;
        int int8 = property4.getMaximumTextLength(locale7);
        org.joda.time.DurationField durationField9 = property4.getLeapDurationField();
        org.joda.time.DateTimeField dateTimeField10 = property4.getField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(interval6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        int int6 = dateTime5.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime5.getZone();
//        org.joda.time.Chronology chronology8 = iSOChronology1.withZone(dateTimeZone7);
//        java.lang.String str10 = dateTimeZone7.getName((long) 2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        int int14 = cachedDateTimeZone12.getOffset((long) 12);
//        long long16 = cachedDateTimeZone12.convertUTCToLocal(756L);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
//        org.joda.time.DurationField durationField20 = iSOChronology19.halfdays();
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology19.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21, dateTimeFieldType22);
//        java.util.Locale locale24 = null;
//        int int25 = delegatedDateTimeField23.getMaximumTextLength(locale24);
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = delegatedDateTimeField23.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder17.appendText(dateTimeFieldType26);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder17.appendSecondOfMinute((int) (byte) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = new org.joda.time.format.DateTimeFormatterBuilder();
//        boolean boolean31 = dateTimeFormatterBuilder30.canBuildFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone33);
//        org.joda.time.DurationField durationField35 = iSOChronology34.halfdays();
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType37 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField36, dateTimeFieldType37);
//        java.util.Locale locale39 = null;
//        int int40 = delegatedDateTimeField38.getMaximumTextLength(locale39);
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = delegatedDateTimeField38.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder32.appendText(dateTimeFieldType41);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder30.appendText(dateTimeFieldType41);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder17.appendFixedSignedDecimal(dateTimeFieldType41, (int) (byte) 1);
//        boolean boolean46 = cachedDateTimeZone12.equals((java.lang.Object) dateTimeFormatterBuilder45);
//        long long50 = cachedDateTimeZone12.convertLocalToUTC((long) 48627451, false, 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 37 + "'", int6 == 37);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Pacific Standard Time" + "'", str10.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-28800000) + "'", int14 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-28799244L) + "'", long16 == (-28799244L));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 77427451L + "'", long50 == 77427451L);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-6) + "'", int1 == (-6));
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        int int4 = dateTime3.getSecondOfMinute();
//        org.joda.time.DateTime dateTime9 = dateTime3.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime11 = dateTime3.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime13);
//        int int16 = gJChronology15.getMinimumDaysInFirstWeek();
//        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = copticChronology17.clockhourOfDay();
//        org.joda.time.DurationField durationField19 = copticChronology17.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
//        org.joda.time.DurationField durationField22 = iSOChronology21.halfdays();
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology21.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(dateTimeZone24);
//        int int26 = dateTime25.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone27 = dateTime25.getZone();
//        org.joda.time.Chronology chronology28 = iSOChronology21.withZone(dateTimeZone27);
//        java.lang.String str29 = dateTimeZone27.getID();
//        org.joda.time.Chronology chronology30 = copticChronology17.withZone(dateTimeZone27);
//        org.joda.time.Chronology chronology31 = gJChronology15.withZone(dateTimeZone27);
//        org.joda.time.DateTimeField dateTimeField32 = gJChronology15.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone33);
//        org.joda.time.DurationField durationField35 = iSOChronology34.halfdays();
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType37 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField36, dateTimeFieldType37);
//        java.util.Locale locale39 = null;
//        int int40 = delegatedDateTimeField38.getMaximumTextLength(locale39);
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = delegatedDateTimeField38.getType();
//        java.util.Locale locale42 = null;
//        int int43 = delegatedDateTimeField38.getMaximumTextLength(locale42);
//        org.joda.time.DurationField durationField44 = delegatedDateTimeField38.getDurationField();
//        java.util.Locale locale45 = null;
//        int int46 = delegatedDateTimeField38.getMaximumShortTextLength(locale45);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone47);
//        org.joda.time.MonthDay monthDay49 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology48);
//        org.joda.time.DateTimeFieldType dateTimeFieldType50 = null;
//        boolean boolean51 = monthDay49.isSupported(dateTimeFieldType50);
//        org.joda.time.MonthDay monthDay53 = monthDay49.withDayOfMonth(15);
//        org.joda.time.ReadablePeriod readablePeriod54 = null;
//        org.joda.time.MonthDay monthDay55 = monthDay53.plus(readablePeriod54);
//        org.joda.time.MonthDay.Property property56 = monthDay55.dayOfMonth();
//        org.joda.time.MonthDay monthDay58 = org.joda.time.MonthDay.parse("");
//        int int59 = property56.compareTo((org.joda.time.ReadablePartial) monthDay58);
//        org.joda.time.MonthDay monthDay61 = property56.addToCopy((int) (byte) 0);
//        int[] intArray63 = new int[] { 32 };
//        int int64 = delegatedDateTimeField38.getMaximumValue((org.joda.time.ReadablePartial) monthDay61, intArray63);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField66 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology15, (org.joda.time.DateTimeField) delegatedDateTimeField38, 38);
//        int int67 = skipDateTimeField66.getMinimumValue();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 37 + "'", int4 == 37);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
//        org.junit.Assert.assertNotNull(copticChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 37 + "'", int26 == 37);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "America/Los_Angeles" + "'", str29.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(chronology30);
//        org.junit.Assert.assertNotNull(chronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2 + "'", int43 == 2);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertNotNull(iSOChronology48);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(monthDay53);
//        org.junit.Assert.assertNotNull(monthDay55);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertNotNull(monthDay58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
//        org.junit.Assert.assertNotNull(monthDay61);
//        org.junit.Assert.assertNotNull(intArray63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 59 + "'", int64 == 59);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("December");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"December\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.halfdays();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType5);
        java.util.Locale locale7 = null;
        int int8 = delegatedDateTimeField6.getMaximumTextLength(locale7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = delegatedDateTimeField6.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.appendSecondOfMinute((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendTimeZoneName();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap14 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendTimeZoneName(strMap14);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder13.appendLiteral('4');
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) 9);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendMillisOfDay(2922789);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gregorianChronology0.equals(obj1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTime dateTime7 = dateTime1.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime9 = dateTime7.plusYears((-1));
//        java.lang.String str10 = dateTime9.toString();
//        java.lang.String str11 = dateTime9.toString();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
//        org.joda.time.DurationField durationField14 = iSOChronology13.halfdays();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        int int18 = dateTime17.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTime17.getZone();
//        org.joda.time.Chronology chronology20 = iSOChronology13.withZone(dateTimeZone19);
//        org.joda.time.DateTime dateTime21 = dateTime9.toDateTime(dateTimeZone19);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusWeeks((int) (short) 0);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone28 = new org.joda.time.tz.FixedDateTimeZone("Pacific Standard Time", "", 27, 34);
//        org.joda.time.DateTime dateTime29 = dateTime21.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone28);
//        org.joda.time.LocalTime localTime30 = dateTime29.toLocalTime();
//        org.joda.time.DateTime.Property property31 = dateTime29.year();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38 + "'", int2 == 38);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2018-06-15T10:13:15.013-07:00" + "'", str10.equals("2018-06-15T10:13:15.013-07:00"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2018-06-15T10:13:15.013-07:00" + "'", str11.equals("2018-06-15T10:13:15.013-07:00"));
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 38 + "'", int18 == 38);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(localTime30);
//        org.junit.Assert.assertNotNull(property31);
//    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        boolean boolean1 = dateTimeFormatterBuilder0.canBuildFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
//        dateTimeFormatterBuilder2.clear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        int int6 = dateTime5.getSecondOfMinute();
//        org.joda.time.DateTime dateTime11 = dateTime5.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime13 = dateTime5.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
//        org.joda.time.DateTime dateTime17 = dateTime15.withHourOfDay(0);
//        int int18 = dateTime15.getDayOfMonth();
//        boolean boolean19 = dateTime13.isBefore((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        boolean boolean21 = dateTimeFormatter20.isPrinter();
//        java.lang.String str22 = dateTime15.toString(dateTimeFormatter20);
//        java.util.Locale locale23 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter20.withLocale(locale23);
//        org.joda.time.format.DateTimePrinter dateTimePrinter25 = dateTimeFormatter24.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatter26.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter25, dateTimeParser27);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.appendClockhourOfHalfday(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder29.appendCenturyOfEra(0, 2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder29.appendClockhourOfDay(9);
//        org.joda.time.format.DateTimeParser dateTimeParser37 = dateTimeFormatterBuilder29.toParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder38.appendClockhourOfHalfday(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder38.appendCenturyOfEra(0, 2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder38.appendClockhourOfDay(9);
//        org.joda.time.format.DateTimeParser dateTimeParser46 = dateTimeFormatterBuilder38.toParser();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray47 = new org.joda.time.format.DateTimeParser[] { dateTimeParser37, dateTimeParser46 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder2.append(dateTimePrinter25, dateTimeParserArray47);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone50);
//        org.joda.time.DurationField durationField52 = iSOChronology51.halfdays();
//        org.joda.time.DateTimeField dateTimeField53 = iSOChronology51.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType54 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField55 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField53, dateTimeFieldType54);
//        java.util.Locale locale56 = null;
//        int int57 = delegatedDateTimeField55.getMaximumTextLength(locale56);
//        org.joda.time.DateTimeFieldType dateTimeFieldType58 = delegatedDateTimeField55.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder49.appendText(dateTimeFieldType58);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder49.appendSecondOfMinute((int) (byte) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = new org.joda.time.format.DateTimeFormatterBuilder();
//        boolean boolean63 = dateTimeFormatterBuilder62.canBuildFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone65 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology66 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone65);
//        org.joda.time.DurationField durationField67 = iSOChronology66.halfdays();
//        org.joda.time.DateTimeField dateTimeField68 = iSOChronology66.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType69 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField70 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField68, dateTimeFieldType69);
//        java.util.Locale locale71 = null;
//        int int72 = delegatedDateTimeField70.getMaximumTextLength(locale71);
//        org.joda.time.DateTimeFieldType dateTimeFieldType73 = delegatedDateTimeField70.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder74 = dateTimeFormatterBuilder64.appendText(dateTimeFieldType73);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder75 = dateTimeFormatterBuilder62.appendText(dateTimeFieldType73);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder77 = dateTimeFormatterBuilder49.appendFixedSignedDecimal(dateTimeFieldType73, (int) (byte) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder78 = dateTimeFormatterBuilder48.appendShortText(dateTimeFieldType73);
//        org.joda.time.DateTimeZone dateTimeZone79 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology80 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone79);
//        org.joda.time.DateTimeField dateTimeField81 = iSOChronology80.era();
//        java.lang.Class<?> wildcardClass82 = iSOChronology80.getClass();
//        org.joda.time.MonthDay monthDay83 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology80);
//        org.joda.time.DurationField durationField84 = iSOChronology80.days();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField85 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType73, durationField84);
//        java.util.Locale locale88 = null;
//        try {
//            long long89 = unsupportedDateTimeField85.set((long) 14, "", locale88);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 38 + "'", int6 == 38);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "20" + "'", str22.equals("20"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertNotNull(dateTimePrinter25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(dateTimeParser27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertNotNull(dateTimeParser37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(dateTimeParser46);
//        org.junit.Assert.assertNotNull(dateTimeParserArray47);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertNotNull(iSOChronology51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2 + "'", int57 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType58);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone65);
//        org.junit.Assert.assertNotNull(iSOChronology66);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertNotNull(dateTimeField68);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2 + "'", int72 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType73);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder74);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder75);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder77);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder78);
//        org.junit.Assert.assertNotNull(dateTimeZone79);
//        org.junit.Assert.assertNotNull(iSOChronology80);
//        org.junit.Assert.assertNotNull(dateTimeField81);
//        org.junit.Assert.assertNotNull(wildcardClass82);
//        org.junit.Assert.assertNotNull(durationField84);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField85);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        java.util.Locale locale6 = null;
        int int7 = delegatedDateTimeField5.getMaximumTextLength(locale6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = delegatedDateTimeField5.getType();
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeField[] dateTimeFieldArray10 = monthDay9.getFields();
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField5.getAsText((org.joda.time.ReadablePartial) monthDay9, (-1), locale12);
        org.joda.time.MonthDay monthDay15 = monthDay9.plusDays(810);
        try {
            int int17 = monthDay15.getValue((-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(dateTimeFieldArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1" + "'", str13.equals("-1"));
        org.junit.Assert.assertNotNull(monthDay15);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
        org.joda.time.DateTime dateTime5 = dateTime3.plusYears(15);
        org.joda.time.DateTime dateTime7 = dateTime3.withYearOfEra(1);
        org.joda.time.DateTime dateTime9 = dateTime7.withYearOfCentury(3);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMonths(4);
        org.joda.time.DateTime dateTime13 = dateTime11.minusMonths(40);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendPattern("0");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral("Dec");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test138");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime1.getZone();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38 + "'", int2 == 38);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
//        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
//        int int5 = property4.getMaximumValue();
//        org.joda.time.Interval interval6 = property4.toInterval();
//        java.util.Locale locale7 = null;
//        int int8 = property4.getMaximumTextLength(locale7);
//        java.util.Locale locale9 = null;
//        int int10 = property4.getMaximumShortTextLength(locale9);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
//        org.joda.time.DurationField durationField13 = iSOChronology12.halfdays();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType15);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = delegatedDateTimeField16.getAsText((long) (short) 1, locale18);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
//        org.joda.time.DurationField durationField22 = iSOChronology21.halfdays();
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology21.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(dateTimeZone24);
//        org.joda.time.DateTime dateTime27 = dateTime25.withHourOfDay(0);
//        org.joda.time.DateTime.Property property28 = dateTime27.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
//        org.joda.time.MonthDay monthDay31 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology30);
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = null;
//        boolean boolean33 = monthDay31.isSupported(dateTimeFieldType32);
//        int int34 = property28.compareTo((org.joda.time.ReadablePartial) monthDay31);
//        long long36 = iSOChronology21.set((org.joda.time.ReadablePartial) monthDay31, (long) 13);
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = delegatedDateTimeField16.getAsText((org.joda.time.ReadablePartial) monthDay31, 15, locale38);
//        java.util.Locale locale41 = null;
//        java.lang.String str42 = delegatedDateTimeField16.getAsText((long) 0, locale41);
//        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone43);
//        org.joda.time.MonthDay monthDay45 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology44);
//        org.joda.time.DateTimeFieldType dateTimeFieldType46 = null;
//        boolean boolean47 = monthDay45.isSupported(dateTimeFieldType46);
//        org.joda.time.MonthDay monthDay49 = monthDay45.withDayOfMonth(15);
//        int int50 = delegatedDateTimeField16.getMaximumValue((org.joda.time.ReadablePartial) monthDay45);
//        org.joda.time.DateTimeZone dateTimeZone51 = null;
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime(dateTimeZone53);
//        int int55 = dateTime54.getSecondOfMinute();
//        org.joda.time.DateTime dateTime60 = dateTime54.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime62 = dateTime54.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime64 = dateTime62.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology65 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone52, (org.joda.time.ReadableInstant) dateTime64);
//        org.joda.time.chrono.GJChronology gJChronology66 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone51, (org.joda.time.ReadableInstant) dateTime64);
//        int int67 = gJChronology66.getMinimumDaysInFirstWeek();
//        org.joda.time.chrono.CopticChronology copticChronology68 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField69 = copticChronology68.clockhourOfDay();
//        org.joda.time.DurationField durationField70 = copticChronology68.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone71 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology72 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone71);
//        org.joda.time.DurationField durationField73 = iSOChronology72.halfdays();
//        org.joda.time.DateTimeField dateTimeField74 = iSOChronology72.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone75 = null;
//        org.joda.time.DateTime dateTime76 = new org.joda.time.DateTime(dateTimeZone75);
//        int int77 = dateTime76.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone78 = dateTime76.getZone();
//        org.joda.time.Chronology chronology79 = iSOChronology72.withZone(dateTimeZone78);
//        java.lang.String str80 = dateTimeZone78.getID();
//        org.joda.time.Chronology chronology81 = copticChronology68.withZone(dateTimeZone78);
//        org.joda.time.Chronology chronology82 = gJChronology66.withZone(dateTimeZone78);
//        org.joda.time.MonthDay monthDay83 = monthDay45.withChronologyRetainFields(chronology82);
//        org.joda.time.Chronology chronology84 = monthDay83.getChronology();
//        int int85 = property4.compareTo((org.joda.time.ReadablePartial) monthDay83);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(interval6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 14256000013L + "'", long36 == 14256000013L);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "15" + "'", str39.equals("15"));
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "0" + "'", str42.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertNotNull(iSOChronology44);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(monthDay49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 59 + "'", int50 == 59);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 39 + "'", int55 == 39);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(gJChronology65);
//        org.junit.Assert.assertNotNull(gJChronology66);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 4 + "'", int67 == 4);
//        org.junit.Assert.assertNotNull(copticChronology68);
//        org.junit.Assert.assertNotNull(dateTimeField69);
//        org.junit.Assert.assertNotNull(durationField70);
//        org.junit.Assert.assertNotNull(dateTimeZone71);
//        org.junit.Assert.assertNotNull(iSOChronology72);
//        org.junit.Assert.assertNotNull(durationField73);
//        org.junit.Assert.assertNotNull(dateTimeField74);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 39 + "'", int77 == 39);
//        org.junit.Assert.assertNotNull(dateTimeZone78);
//        org.junit.Assert.assertNotNull(chronology79);
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "America/Los_Angeles" + "'", str80.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(chronology81);
//        org.junit.Assert.assertNotNull(chronology82);
//        org.junit.Assert.assertNotNull(monthDay83);
//        org.junit.Assert.assertNotNull(chronology84);
//        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime dateTime5 = dateTime1.withDurationAdded((long) (short) -1, 0);
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test142");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
//        int int4 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusDays((int) (byte) 10);
//        int int7 = dateTime6.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        org.joda.time.DateTime dateTime11 = dateTime9.withHourOfDay(0);
//        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
//        int int13 = property12.getMaximumValue();
//        org.joda.time.DateTime dateTime14 = property12.getDateTime();
//        org.joda.time.DateTime dateTime15 = property12.getDateTime();
//        int int16 = dateTime6.compareTo((org.joda.time.ReadableInstant) dateTime15);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        boolean boolean1 = dateTimeFormatterBuilder0.canBuildFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
//        dateTimeFormatterBuilder2.clear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        int int6 = dateTime5.getSecondOfMinute();
//        org.joda.time.DateTime dateTime11 = dateTime5.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime13 = dateTime5.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
//        org.joda.time.DateTime dateTime17 = dateTime15.withHourOfDay(0);
//        int int18 = dateTime15.getDayOfMonth();
//        boolean boolean19 = dateTime13.isBefore((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        boolean boolean21 = dateTimeFormatter20.isPrinter();
//        java.lang.String str22 = dateTime15.toString(dateTimeFormatter20);
//        java.util.Locale locale23 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter20.withLocale(locale23);
//        org.joda.time.format.DateTimePrinter dateTimePrinter25 = dateTimeFormatter24.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatter26.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter25, dateTimeParser27);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.appendClockhourOfHalfday(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder29.appendCenturyOfEra(0, 2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder29.appendClockhourOfDay(9);
//        org.joda.time.format.DateTimeParser dateTimeParser37 = dateTimeFormatterBuilder29.toParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder38.appendClockhourOfHalfday(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder38.appendCenturyOfEra(0, 2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder38.appendClockhourOfDay(9);
//        org.joda.time.format.DateTimeParser dateTimeParser46 = dateTimeFormatterBuilder38.toParser();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray47 = new org.joda.time.format.DateTimeParser[] { dateTimeParser37, dateTimeParser46 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder2.append(dateTimePrinter25, dateTimeParserArray47);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone50);
//        org.joda.time.DurationField durationField52 = iSOChronology51.halfdays();
//        org.joda.time.DateTimeField dateTimeField53 = iSOChronology51.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType54 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField55 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField53, dateTimeFieldType54);
//        java.util.Locale locale56 = null;
//        int int57 = delegatedDateTimeField55.getMaximumTextLength(locale56);
//        org.joda.time.DateTimeFieldType dateTimeFieldType58 = delegatedDateTimeField55.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder49.appendText(dateTimeFieldType58);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder49.appendSecondOfMinute((int) (byte) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = new org.joda.time.format.DateTimeFormatterBuilder();
//        boolean boolean63 = dateTimeFormatterBuilder62.canBuildFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone65 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology66 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone65);
//        org.joda.time.DurationField durationField67 = iSOChronology66.halfdays();
//        org.joda.time.DateTimeField dateTimeField68 = iSOChronology66.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType69 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField70 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField68, dateTimeFieldType69);
//        java.util.Locale locale71 = null;
//        int int72 = delegatedDateTimeField70.getMaximumTextLength(locale71);
//        org.joda.time.DateTimeFieldType dateTimeFieldType73 = delegatedDateTimeField70.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder74 = dateTimeFormatterBuilder64.appendText(dateTimeFieldType73);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder75 = dateTimeFormatterBuilder62.appendText(dateTimeFieldType73);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder77 = dateTimeFormatterBuilder49.appendFixedSignedDecimal(dateTimeFieldType73, (int) (byte) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder78 = dateTimeFormatterBuilder48.appendShortText(dateTimeFieldType73);
//        org.joda.time.DateTimeZone dateTimeZone79 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology80 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone79);
//        org.joda.time.DateTimeField dateTimeField81 = iSOChronology80.era();
//        java.lang.Class<?> wildcardClass82 = iSOChronology80.getClass();
//        org.joda.time.MonthDay monthDay83 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology80);
//        org.joda.time.DurationField durationField84 = iSOChronology80.days();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField85 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType73, durationField84);
//        org.joda.time.DurationField durationField86 = unsupportedDateTimeField85.getRangeDurationField();
//        long long89 = unsupportedDateTimeField85.getDifferenceAsLong(38L, (long) 59);
//        java.util.Locale locale92 = null;
//        try {
//            long long93 = unsupportedDateTimeField85.set(1560630630160L, "2018-06-15T10:13:15.013-07:00", locale92);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39 + "'", int6 == 39);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "20" + "'", str22.equals("20"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertNotNull(dateTimePrinter25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(dateTimeParser27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertNotNull(dateTimeParser37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(dateTimeParser46);
//        org.junit.Assert.assertNotNull(dateTimeParserArray47);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertNotNull(iSOChronology51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2 + "'", int57 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType58);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone65);
//        org.junit.Assert.assertNotNull(iSOChronology66);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertNotNull(dateTimeField68);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2 + "'", int72 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType73);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder74);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder75);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder77);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder78);
//        org.junit.Assert.assertNotNull(dateTimeZone79);
//        org.junit.Assert.assertNotNull(iSOChronology80);
//        org.junit.Assert.assertNotNull(dateTimeField81);
//        org.junit.Assert.assertNotNull(wildcardClass82);
//        org.junit.Assert.assertNotNull(durationField84);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField85);
//        org.junit.Assert.assertNull(durationField86);
//        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 0L + "'", long89 == 0L);
//    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        int int4 = dateTime3.getSecondOfMinute();
//        org.joda.time.DateTime dateTime9 = dateTime3.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime11 = dateTime3.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime13);
//        int int16 = gJChronology15.getMinimumDaysInFirstWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        org.joda.time.Chronology chronology18 = dateTimeFormatter17.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTimeFormatter17.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology15, dateTimeZone19);
//        long long26 = zonedChronology20.getDateTimeMillis(1560630623999L, (int) (short) 0, 0, 12, 3);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone29);
//        int int31 = dateTime30.getSecondOfMinute();
//        org.joda.time.DateTime dateTime36 = dateTime30.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime38 = dateTime30.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime40 = dateTime38.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone28, (org.joda.time.ReadableInstant) dateTime40);
//        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone27, (org.joda.time.ReadableInstant) dateTime40);
//        int int43 = gJChronology42.getMinimumDaysInFirstWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        org.joda.time.Chronology chronology45 = dateTimeFormatter44.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone46 = dateTimeFormatter44.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology47 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology42, dateTimeZone46);
//        org.joda.time.Chronology chronology48 = zonedChronology20.withZone(dateTimeZone46);
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology50 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone49);
//        org.joda.time.DurationField durationField51 = iSOChronology50.halfdays();
//        org.joda.time.DateTimeField dateTimeField52 = iSOChronology50.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime(dateTimeZone53);
//        int int55 = dateTime54.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone56 = dateTime54.getZone();
//        org.joda.time.Chronology chronology57 = iSOChronology50.withZone(dateTimeZone56);
//        java.lang.String str58 = dateTimeZone56.getID();
//        org.joda.time.Chronology chronology59 = zonedChronology20.withZone(dateTimeZone56);
//        org.joda.time.DateTimeZone dateTimeZone60 = zonedChronology20.getZone();
//        long long66 = zonedChronology20.getDateTimeMillis((long) 2019, 10, 43, 13, 59);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 39 + "'", int4 == 39);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNull(chronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(zonedChronology20);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560556812003L + "'", long26 == 1560556812003L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 39 + "'", int31 == 39);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(gJChronology41);
//        org.junit.Assert.assertNotNull(gJChronology42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 4 + "'", int43 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter44);
//        org.junit.Assert.assertNull(chronology45);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertNotNull(zonedChronology47);
//        org.junit.Assert.assertNotNull(chronology48);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertNotNull(iSOChronology50);
//        org.junit.Assert.assertNotNull(durationField51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 39 + "'", int55 == 39);
//        org.junit.Assert.assertNotNull(dateTimeZone56);
//        org.junit.Assert.assertNotNull(chronology57);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "America/Los_Angeles" + "'", str58.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(chronology59);
//        org.junit.Assert.assertNotNull(dateTimeZone60);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 38593059L + "'", long66 == 38593059L);
//    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.era();
//        java.lang.Class<?> wildcardClass3 = iSOChronology1.getClass();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.dayOfMonth();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 20);
//        int int8 = offsetDateTimeField6.getMinimumValue((-1L));
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        int int11 = dateTime10.getSecondOfMinute();
//        org.joda.time.DateTime dateTime16 = dateTime10.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime18 = dateTime16.plusYears((-1));
//        java.lang.String str19 = dateTime18.toString();
//        java.lang.String str20 = dateTime18.toString();
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
//        org.joda.time.DurationField durationField23 = iSOChronology22.halfdays();
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(dateTimeZone25);
//        int int27 = dateTime26.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone28 = dateTime26.getZone();
//        org.joda.time.Chronology chronology29 = iSOChronology22.withZone(dateTimeZone28);
//        org.joda.time.DateTime dateTime30 = dateTime18.toDateTime(dateTimeZone28);
//        org.joda.time.DateTime dateTime32 = dateTime30.minusWeeks((int) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(dateTimeZone33);
//        org.joda.time.DateTime dateTime36 = dateTime34.withHourOfDay(0);
//        org.joda.time.DateTime dateTime37 = dateTime36.withEarlierOffsetAtOverlap();
//        boolean boolean38 = dateTime30.isAfter((org.joda.time.ReadableInstant) dateTime37);
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
//        org.joda.time.MonthDay monthDay41 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology40);
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = null;
//        boolean boolean43 = monthDay41.isSupported(dateTimeFieldType42);
//        org.joda.time.MonthDay monthDay45 = monthDay41.withDayOfMonth(15);
//        org.joda.time.DateTime dateTime46 = dateTime37.withFields((org.joda.time.ReadablePartial) monthDay41);
//        java.util.Locale locale47 = null;
//        java.lang.String str48 = offsetDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) monthDay41, locale47);
//        long long50 = offsetDateTimeField6.roundFloor((long) 31);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 21 + "'", int8 == 21);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 40 + "'", int11 == 40);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2018-06-15T10:13:15.013-07:00" + "'", str19.equals("2018-06-15T10:13:15.013-07:00"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2018-06-15T10:13:15.013-07:00" + "'", str20.equals("2018-06-15T10:13:15.013-07:00"));
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 40 + "'", int27 == 40);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(monthDay45);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "15" + "'", str48.equals("15"));
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
//    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTime dateTime7 = dateTime1.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime9 = dateTime7.plusYears((-1));
//        java.lang.String str10 = dateTime9.toString();
//        java.lang.String str11 = dateTime9.toString();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
//        org.joda.time.DurationField durationField14 = iSOChronology13.halfdays();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        int int18 = dateTime17.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTime17.getZone();
//        org.joda.time.Chronology chronology20 = iSOChronology13.withZone(dateTimeZone19);
//        org.joda.time.DateTime dateTime21 = dateTime9.toDateTime(dateTimeZone19);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusWeeks((int) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(dateTimeZone24);
//        org.joda.time.DateTime dateTime27 = dateTime25.withHourOfDay(0);
//        org.joda.time.DateTime dateTime28 = dateTime27.withEarlierOffsetAtOverlap();
//        boolean boolean29 = dateTime21.isAfter((org.joda.time.ReadableInstant) dateTime28);
//        org.joda.time.DateTime.Property property30 = dateTime28.centuryOfEra();
//        java.lang.String str31 = property30.getAsShortText();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40 + "'", int2 == 40);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2018-06-15T10:13:15.013-07:00" + "'", str10.equals("2018-06-15T10:13:15.013-07:00"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2018-06-15T10:13:15.013-07:00" + "'", str11.equals("2018-06-15T10:13:15.013-07:00"));
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 40 + "'", int18 == 40);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "20" + "'", str31.equals("20"));
//    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        int int6 = dateTime5.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime5.getZone();
//        org.joda.time.Chronology chronology8 = iSOChronology1.withZone(dateTimeZone7);
//        java.lang.String str10 = dateTimeZone7.getName((long) 2);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
//        java.lang.String str12 = buddhistChronology11.toString();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
//        int int17 = dateTime16.getSecondOfMinute();
//        org.joda.time.DateTime dateTime22 = dateTime16.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime24 = dateTime16.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime26 = dateTime24.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, (org.joda.time.ReadableInstant) dateTime26);
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (org.joda.time.ReadableInstant) dateTime26);
//        int int29 = gJChronology28.getMinimumDaysInFirstWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        org.joda.time.Chronology chronology31 = dateTimeFormatter30.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone32 = dateTimeFormatter30.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology28, dateTimeZone32);
//        long long39 = zonedChronology33.getDateTimeMillis(1560630623999L, (int) (short) 0, 0, 12, 3);
//        org.joda.time.DateTimeZone dateTimeZone40 = null;
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime(dateTimeZone42);
//        int int44 = dateTime43.getSecondOfMinute();
//        org.joda.time.DateTime dateTime49 = dateTime43.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime51 = dateTime43.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime53 = dateTime51.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology54 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41, (org.joda.time.ReadableInstant) dateTime53);
//        org.joda.time.chrono.GJChronology gJChronology55 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone40, (org.joda.time.ReadableInstant) dateTime53);
//        int int56 = gJChronology55.getMinimumDaysInFirstWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter57 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        org.joda.time.Chronology chronology58 = dateTimeFormatter57.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone59 = dateTimeFormatter57.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology60 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology55, dateTimeZone59);
//        org.joda.time.Chronology chronology61 = zonedChronology33.withZone(dateTimeZone59);
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology63 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone62);
//        org.joda.time.DurationField durationField64 = iSOChronology63.halfdays();
//        org.joda.time.DateTimeField dateTimeField65 = iSOChronology63.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone66 = null;
//        org.joda.time.DateTime dateTime67 = new org.joda.time.DateTime(dateTimeZone66);
//        int int68 = dateTime67.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone69 = dateTime67.getZone();
//        org.joda.time.Chronology chronology70 = iSOChronology63.withZone(dateTimeZone69);
//        java.lang.String str71 = dateTimeZone69.getID();
//        org.joda.time.Chronology chronology72 = zonedChronology33.withZone(dateTimeZone69);
//        org.joda.time.Chronology chronology73 = buddhistChronology11.withZone(dateTimeZone69);
//        try {
//            org.joda.time.chrono.GJChronology gJChronology76 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone69, (long) 43, 70);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 70");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 40 + "'", int6 == 40);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Pacific Standard Time" + "'", str10.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(buddhistChronology11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str12.equals("BuddhistChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 40 + "'", int17 == 40);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(gJChronology27);
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter30);
//        org.junit.Assert.assertNull(chronology31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(zonedChronology33);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560556812003L + "'", long39 == 1560556812003L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 40 + "'", int44 == 40);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(gJChronology54);
//        org.junit.Assert.assertNotNull(gJChronology55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter57);
//        org.junit.Assert.assertNull(chronology58);
//        org.junit.Assert.assertNotNull(dateTimeZone59);
//        org.junit.Assert.assertNotNull(zonedChronology60);
//        org.junit.Assert.assertNotNull(chronology61);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertNotNull(iSOChronology63);
//        org.junit.Assert.assertNotNull(durationField64);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 40 + "'", int68 == 40);
//        org.junit.Assert.assertNotNull(dateTimeZone69);
//        org.junit.Assert.assertNotNull(chronology70);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "America/Los_Angeles" + "'", str71.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(chronology72);
//        org.junit.Assert.assertNotNull(chronology73);
//    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        int int4 = dateTime3.getSecondOfMinute();
//        org.joda.time.DateTime dateTime9 = dateTime3.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime11 = dateTime3.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime13);
//        int int16 = gJChronology15.getMinimumDaysInFirstWeek();
//        boolean boolean18 = gJChronology15.equals((java.lang.Object) "38");
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 40 + "'", int4 == 40);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        int int5 = property4.getMaximumValue();
        org.joda.time.DateTime dateTime6 = property4.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.DurationField durationField9 = iSOChronology8.halfdays();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.minuteOfHour();
        org.joda.time.DateTime dateTime11 = dateTime6.toDateTime((org.joda.time.Chronology) iSOChronology8);
        org.joda.time.DateTime.Property property12 = dateTime11.hourOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendCenturyOfEra(0, 2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendClockhourOfDay(9);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendTwoDigitWeekyear(10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendWeekyear(25, 42);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
//        boolean boolean15 = dateTimeFormatterBuilder14.canBuildFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder14.appendMinuteOfDay(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendPattern("0");
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
//        int int23 = dateTime22.getSecondOfMinute();
//        org.joda.time.DateTime dateTime28 = dateTime22.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime30 = dateTime22.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime(dateTimeZone31);
//        org.joda.time.DateTime dateTime34 = dateTime32.withHourOfDay(0);
//        int int35 = dateTime32.getDayOfMonth();
//        boolean boolean36 = dateTime30.isBefore((org.joda.time.ReadableInstant) dateTime32);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        boolean boolean38 = dateTimeFormatter37.isPrinter();
//        java.lang.String str39 = dateTime32.toString(dateTimeFormatter37);
//        java.util.Locale locale40 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter37.withLocale(locale40);
//        org.joda.time.format.DateTimePrinter dateTimePrinter42 = dateTimeFormatter41.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        org.joda.time.format.DateTimeParser dateTimeParser44 = dateTimeFormatter43.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter42, dateTimeParser44);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder18.append(dateTimePrinter42);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = new org.joda.time.format.DateTimeFormatterBuilder();
//        boolean boolean48 = dateTimeFormatterBuilder47.canBuildFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder47.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter50 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        org.joda.time.format.DateTimeParser dateTimeParser51 = dateTimeFormatter50.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder49.append(dateTimeParser51);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder10.append(dateTimePrinter42, dateTimeParser51);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder54.appendClockhourOfHalfday(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder54.appendCenturyOfEra(0, 2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder54.appendClockhourOfDay(9);
//        org.joda.time.format.DateTimeParser dateTimeParser62 = dateTimeFormatterBuilder54.toParser();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray63 = new org.joda.time.format.DateTimeParser[] { dateTimeParser62 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder7.append(dateTimePrinter42, dateTimeParserArray63);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder64.appendHalfdayOfDayText();
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 41 + "'", int23 == 41);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 15 + "'", int35 == 15);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "20" + "'", str39.equals("20"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter41);
//        org.junit.Assert.assertNotNull(dateTimePrinter42);
//        org.junit.Assert.assertNotNull(dateTimeFormatter43);
//        org.junit.Assert.assertNotNull(dateTimeParser44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
//        org.junit.Assert.assertNotNull(dateTimeFormatter50);
//        org.junit.Assert.assertNotNull(dateTimeParser51);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
//        org.junit.Assert.assertNotNull(dateTimeParser62);
//        org.junit.Assert.assertNotNull(dateTimeParserArray63);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
//    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test151");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.era();
//        java.lang.Class<?> wildcardClass3 = iSOChronology1.getClass();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.dayOfMonth();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 20);
//        long long9 = offsetDateTimeField6.getDifferenceAsLong(1560630624063L, (long) 100);
//        long long11 = offsetDateTimeField6.roundCeiling(1L);
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
//        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology13);
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
//        boolean boolean16 = monthDay14.isSupported(dateTimeFieldType15);
//        org.joda.time.MonthDay monthDay18 = monthDay14.withDayOfMonth(15);
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.MonthDay monthDay20 = monthDay18.plus(readablePeriod19);
//        org.joda.time.MonthDay monthDay22 = monthDay20.plusDays(24);
//        int int23 = offsetDateTimeField6.getMinimumValue((org.joda.time.ReadablePartial) monthDay20);
//        org.joda.time.chrono.CopticChronology copticChronology24 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField25 = copticChronology24.clockhourOfDay();
//        org.joda.time.DurationField durationField26 = copticChronology24.weekyears();
//        java.lang.String str27 = copticChronology24.toString();
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.clockhourOfDay();
//        org.joda.time.MonthDay monthDay31 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology29);
//        boolean boolean32 = copticChronology24.equals((java.lang.Object) monthDay31);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = offsetDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) monthDay31, locale33);
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
//        org.joda.time.DurationField durationField37 = iSOChronology36.halfdays();
//        org.joda.time.DateTimeField dateTimeField38 = iSOChronology36.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField40 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField38, dateTimeFieldType39);
//        java.util.Locale locale42 = null;
//        java.lang.String str43 = delegatedDateTimeField40.getAsText((long) (short) 1, locale42);
//        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone44);
//        org.joda.time.DurationField durationField46 = iSOChronology45.halfdays();
//        org.joda.time.DateTimeField dateTimeField47 = iSOChronology45.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone48 = null;
//        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime(dateTimeZone48);
//        org.joda.time.DateTime dateTime51 = dateTime49.withHourOfDay(0);
//        org.joda.time.DateTime.Property property52 = dateTime51.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology54 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone53);
//        org.joda.time.MonthDay monthDay55 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology54);
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = null;
//        boolean boolean57 = monthDay55.isSupported(dateTimeFieldType56);
//        int int58 = property52.compareTo((org.joda.time.ReadablePartial) monthDay55);
//        long long60 = iSOChronology45.set((org.joda.time.ReadablePartial) monthDay55, (long) 13);
//        java.util.Locale locale62 = null;
//        java.lang.String str63 = delegatedDateTimeField40.getAsText((org.joda.time.ReadablePartial) monthDay55, 15, locale62);
//        java.util.Locale locale65 = null;
//        java.lang.String str66 = offsetDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) monthDay55, 2000, locale65);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 18062L + "'", long9 == 18062L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 86400000L + "'", long11 == 86400000L);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 21 + "'", int23 == 21);
//        org.junit.Assert.assertNotNull(copticChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "CopticChronology[UTC]" + "'", str27.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "15" + "'", str34.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertNotNull(iSOChronology36);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "0" + "'", str43.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(dateTimeZone53);
//        org.junit.Assert.assertNotNull(iSOChronology54);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 14256000013L + "'", long60 == 14256000013L);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "15" + "'", str63.equals("15"));
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "2000" + "'", str66.equals("2000"));
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
        org.joda.time.DateTime dateTime5 = dateTime3.plusYears(15);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime5.toMutableDateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime10 = dateTime5.withTimeAtStartOfDay();
        org.joda.time.TimeOfDay timeOfDay11 = dateTime5.toTimeOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(timeOfDay11);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
//        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfHour();
//        org.joda.time.DurationField durationField5 = property4.getRangeDurationField();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.DateTime dateTime9 = dateTime7.withHourOfDay(0);
//        org.joda.time.DateTime dateTime10 = dateTime9.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime12 = dateTime10.withMillis((-1L));
//        org.joda.time.ReadableDuration readableDuration13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.plus(readableDuration13);
//        int int15 = property4.getDifference((org.joda.time.ReadableInstant) dateTime14);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 26009731 + "'", int15 == 26009731);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTime();
        int int5 = mutableDateTime4.getYearOfEra();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        int int4 = dateTime3.getSecondOfMinute();
//        org.joda.time.DateTime dateTime9 = dateTime3.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime11 = dateTime3.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime13);
//        int int16 = gJChronology15.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 0);
//        org.joda.time.Chronology chronology19 = gJChronology15.withZone(dateTimeZone18);
//        org.joda.time.DateTimeZone dateTimeZone20 = gJChronology15.getZone();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 41 + "'", int4 == 41);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
//        org.joda.time.DurationField durationField8 = iSOChronology7.halfdays();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
//        int int12 = dateTime11.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone13 = dateTime11.getZone();
//        org.joda.time.Chronology chronology14 = iSOChronology7.withZone(dateTimeZone13);
//        try {
//            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(2019, 19, 48634686, 49, 811, 2000, dateTimeZone13);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 49 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 41 + "'", int12 == 41);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(chronology14);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.clockhourOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField2);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        java.io.Writer writer1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        int int4 = dateTime3.getSecondOfMinute();
//        org.joda.time.DateTime dateTime6 = dateTime3.minusMillis(2);
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime3.minus(readableDuration7);
//        try {
//            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 42 + "'", int4 == 42);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-15T13:30:39.285-07:00");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3, (int) (short) 1);
        int int8 = julianChronology7.getMinimumDaysInFirstWeek();
        int int9 = julianChronology7.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
        org.joda.time.Chronology chronology13 = julianChronology7.withZone(dateTimeZone10);
        boolean boolean14 = jodaTimePermission1.equals((java.lang.Object) chronology13);
        org.joda.time.JodaTimePermission jodaTimePermission16 = new org.joda.time.JodaTimePermission("2019-06-15T13:30:39.285-07:00");
        boolean boolean17 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendClockhourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendHourOfHalfday(30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder22.appendDayOfWeekShortText();
        boolean boolean24 = jodaTimePermission16.equals((java.lang.Object) dateTimeFormatterBuilder22);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15T13:30:39.285-07:00" + "'", str2.equals("2019-06-15T13:30:39.285-07:00"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withHourOfDay(0);
//        org.joda.time.DateTime.Property property5 = dateTime4.monthOfYear();
//        int int6 = property5.getMaximumValue();
//        org.joda.time.Interval interval7 = property5.toInterval();
//        java.util.Locale locale8 = null;
//        int int9 = property5.getMaximumTextLength(locale8);
//        java.util.Locale locale10 = null;
//        int int11 = property5.getMaximumShortTextLength(locale10);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
//        int int14 = gregorianChronology13.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
//        org.joda.time.Chronology chronology17 = gregorianChronology13.withZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) locale10, dateTimeZone15);
//        java.lang.String str19 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
//        org.junit.Assert.assertNotNull(interval7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019-06-15" + "'", str19.equals("2019-06-15"));
//    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTime dateTime7 = dateTime1.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.era();
//        org.joda.time.DateTime dateTime11 = dateTime1.toDateTime((org.joda.time.Chronology) iSOChronology9);
//        int int12 = dateTime1.getMinuteOfDay();
//        org.joda.time.DateTime dateTime14 = dateTime1.minusDays(24);
//        int int15 = dateTime1.getMonthOfYear();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42 + "'", int2 == 42);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 811 + "'", int12 == 811);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test162");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
//        int int4 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusDays((int) (byte) 10);
//        org.joda.time.DateTime.Property property7 = dateTime6.millisOfSecond();
//        org.joda.time.DateTime dateTime9 = dateTime6.plusHours((int) (short) 0);
//        int int10 = dateTime6.getEra();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        boolean boolean9 = monthDay7.isSupported(dateTimeFieldType8);
        int int10 = property4.compareTo((org.joda.time.ReadablePartial) monthDay7);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 21);
        boolean boolean13 = property4.equals((java.lang.Object) dateTime12);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        int int5 = property4.get();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        boolean boolean10 = monthDay8.isSupported(dateTimeFieldType9);
        org.joda.time.MonthDay monthDay12 = monthDay8.withDayOfMonth(15);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.MonthDay monthDay14 = monthDay12.plus(readablePeriod13);
        int int15 = monthDay14.getDayOfMonth();
        org.joda.time.MonthDay monthDay17 = monthDay14.plusDays((int) '4');
        int int18 = property4.compareTo((org.joda.time.ReadablePartial) monthDay14);
        org.joda.time.DateTime dateTime19 = property4.withMaximumValue();
        org.joda.time.DurationField durationField20 = property4.getDurationField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(durationField20);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test165");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
//        int int4 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusDays((int) (byte) 10);
//        org.joda.time.DateTime.Property property7 = dateTime6.millisOfSecond();
//        org.joda.time.DateTime dateTime9 = dateTime6.plusHours((int) (short) 0);
//        int int10 = dateTime6.getYearOfEra();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        java.util.Locale locale6 = null;
        int int7 = delegatedDateTimeField5.getMaximumTextLength(locale6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = delegatedDateTimeField5.getType();
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeField[] dateTimeFieldArray10 = monthDay9.getFields();
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField5.getAsText((org.joda.time.ReadablePartial) monthDay9, (-1), locale12);
        long long16 = delegatedDateTimeField5.addWrapField((long) 15, 12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = iSOChronology19.halfdays();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology19.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21, dateTimeFieldType22);
        java.util.Locale locale24 = null;
        int int25 = delegatedDateTimeField23.getMaximumTextLength(locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = delegatedDateTimeField23.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder17.appendText(dateTimeFieldType26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder17.appendSecondOfMinute((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean31 = dateTimeFormatterBuilder30.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone33);
        org.joda.time.DurationField durationField35 = iSOChronology34.halfdays();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField36, dateTimeFieldType37);
        java.util.Locale locale39 = null;
        int int40 = delegatedDateTimeField38.getMaximumTextLength(locale39);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = delegatedDateTimeField38.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder32.appendText(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder30.appendText(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder17.appendFixedSignedDecimal(dateTimeFieldType41, (int) (byte) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField46 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, dateTimeFieldType41);
        int int47 = delegatedDateTimeField5.getMaximumValue();
        boolean boolean49 = delegatedDateTimeField5.isLeap((long) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(dateTimeFieldArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1" + "'", str13.equals("-1"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 720015L + "'", long16 == 720015L);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 59 + "'", int47 == 59);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.parse("Jun");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Jun\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(25, 42);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendHourOfHalfday(39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
        org.joda.time.DateTime dateTime5 = dateTime1.minusWeeks((int) (byte) 1);
        org.joda.time.Chronology chronology6 = dateTime1.getChronology();
        org.joda.time.TimeOfDay timeOfDay7 = dateTime1.toTimeOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(timeOfDay7);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Pacific Standard Time", "", 27, 34);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(52L);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal((long) 891);
        long long10 = fixedDateTimeZone4.nextTransition(38L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 27 + "'", int6 == 27);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 27 + "'", int8 == 27);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 38L + "'", long10 == 38L);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test172");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        int int4 = dateTime3.getSecondOfMinute();
//        org.joda.time.DateTime dateTime9 = dateTime3.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime11 = dateTime3.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime13);
//        int int16 = gJChronology15.getMinimumDaysInFirstWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        org.joda.time.Chronology chronology18 = dateTimeFormatter17.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTimeFormatter17.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology15, dateTimeZone19);
//        long long26 = zonedChronology20.getDateTimeMillis(1560630623999L, (int) (short) 0, 0, 12, 3);
//        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) zonedChronology20);
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(dateTimeZone28);
//        int int30 = dateTime29.getSecondOfMinute();
//        org.joda.time.DateTime dateTime35 = dateTime29.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime37 = dateTime29.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime(dateTimeZone38);
//        org.joda.time.DateTime dateTime41 = dateTime39.withHourOfDay(0);
//        int int42 = dateTime39.getDayOfMonth();
//        boolean boolean43 = dateTime37.isBefore((org.joda.time.ReadableInstant) dateTime39);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        boolean boolean45 = dateTimeFormatter44.isPrinter();
//        java.lang.String str46 = dateTime39.toString(dateTimeFormatter44);
//        java.util.Locale locale47 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter48 = dateTimeFormatter44.withLocale(locale47);
//        org.joda.time.format.DateTimePrinter dateTimePrinter49 = dateTimeFormatter48.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter50 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        org.joda.time.format.DateTimeParser dateTimeParser51 = dateTimeFormatter50.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter49, dateTimeParser51);
//        boolean boolean53 = zonedChronology20.equals((java.lang.Object) dateTimeFormatter52);
//        try {
//            long long58 = zonedChronology20.getDateTimeMillis((int) (short) 10, 46, (int) 'a', 54);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 46 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 42 + "'", int4 == 42);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNull(chronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(zonedChronology20);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560556812003L + "'", long26 == 1560556812003L);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 42 + "'", int30 == 42);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 15 + "'", int42 == 15);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "20" + "'", str46.equals("20"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter48);
//        org.junit.Assert.assertNotNull(dateTimePrinter49);
//        org.junit.Assert.assertNotNull(dateTimeFormatter50);
//        org.junit.Assert.assertNotNull(dateTimeParser51);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        java.util.Locale locale6 = null;
        int int7 = delegatedDateTimeField5.getMaximumTextLength(locale6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = delegatedDateTimeField5.getType();
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeField[] dateTimeFieldArray10 = monthDay9.getFields();
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField5.getAsText((org.joda.time.ReadablePartial) monthDay9, (-1), locale12);
        long long16 = delegatedDateTimeField5.addWrapField((long) 15, 12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = iSOChronology19.halfdays();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology19.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21, dateTimeFieldType22);
        java.util.Locale locale24 = null;
        int int25 = delegatedDateTimeField23.getMaximumTextLength(locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = delegatedDateTimeField23.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder17.appendText(dateTimeFieldType26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder17.appendSecondOfMinute((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean31 = dateTimeFormatterBuilder30.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone33);
        org.joda.time.DurationField durationField35 = iSOChronology34.halfdays();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField36, dateTimeFieldType37);
        java.util.Locale locale39 = null;
        int int40 = delegatedDateTimeField38.getMaximumTextLength(locale39);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = delegatedDateTimeField38.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder32.appendText(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder30.appendText(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder17.appendFixedSignedDecimal(dateTimeFieldType41, (int) (byte) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField46 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, dateTimeFieldType41);
        long long49 = delegatedDateTimeField5.add(0L, 35L);
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone50);
        org.joda.time.MonthDay monthDay52 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology51);
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = null;
        boolean boolean54 = monthDay52.isSupported(dateTimeFieldType53);
        org.joda.time.MonthDay monthDay56 = monthDay52.withDayOfMonth(15);
        org.joda.time.ReadablePeriod readablePeriod57 = null;
        org.joda.time.MonthDay monthDay58 = monthDay56.plus(readablePeriod57);
        int int59 = monthDay56.getDayOfMonth();
        int int60 = delegatedDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) monthDay56);
        java.util.Locale locale62 = null;
        java.lang.String str63 = delegatedDateTimeField5.getAsShortText((long) (-1), locale62);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(dateTimeFieldArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1" + "'", str13.equals("-1"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 720015L + "'", long16 == 720015L);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 2100000L + "'", long49 == 2100000L);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(iSOChronology51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(monthDay56);
        org.junit.Assert.assertNotNull(monthDay58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 15 + "'", int59 == 15);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "59" + "'", str63.equals("59"));
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test174");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime1.getZone();
//        boolean boolean4 = dateTime1.isEqualNow();
//        org.joda.time.DateTime dateTime6 = dateTime1.withMillis((long) 59);
//        org.joda.time.DateTime dateTime8 = dateTime6.plus(0L);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43 + "'", int2 == 43);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        org.joda.time.DateTimeField dateTimeField6 = delegatedDateTimeField5.getWrappedField();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.LocalTime localTime3 = dateTime1.toLocalTime();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.withPeriodAdded(readablePeriod4, 32);
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(localTime3);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendTwoDigitYear(58, false);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.era();
        java.lang.Class<?> wildcardClass12 = iSOChronology10.getClass();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        long long18 = offsetDateTimeField15.getDifferenceAsLong(1560630624063L, (long) 100);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology20);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        boolean boolean23 = monthDay21.isSupported(dateTimeFieldType22);
        org.joda.time.MonthDay monthDay25 = monthDay21.withDayOfMonth(15);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.MonthDay monthDay27 = monthDay25.plus(readablePeriod26);
        org.joda.time.MonthDay monthDay29 = monthDay27.plusDays(22);
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone31);
        org.joda.time.MonthDay monthDay33 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = null;
        boolean boolean35 = monthDay33.isSupported(dateTimeFieldType34);
        org.joda.time.MonthDay monthDay37 = monthDay33.withDayOfMonth(15);
        int[] intArray39 = iSOChronology30.get((org.joda.time.ReadablePartial) monthDay37, (long) (short) -1);
        int int40 = offsetDateTimeField15.getMinimumValue((org.joda.time.ReadablePartial) monthDay27, intArray39);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone42);
        org.joda.time.DurationField durationField44 = iSOChronology43.halfdays();
        org.joda.time.DateTimeField dateTimeField45 = iSOChronology43.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField47 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField45, dateTimeFieldType46);
        java.util.Locale locale48 = null;
        int int49 = delegatedDateTimeField47.getMaximumTextLength(locale48);
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = delegatedDateTimeField47.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder41.appendText(dateTimeFieldType50);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder41.appendSecondOfMinute((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean55 = dateTimeFormatterBuilder54.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone57);
        org.joda.time.DurationField durationField59 = iSOChronology58.halfdays();
        org.joda.time.DateTimeField dateTimeField60 = iSOChronology58.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField62 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField60, dateTimeFieldType61);
        java.util.Locale locale63 = null;
        int int64 = delegatedDateTimeField62.getMaximumTextLength(locale63);
        org.joda.time.DateTimeFieldType dateTimeFieldType65 = delegatedDateTimeField62.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder56.appendText(dateTimeFieldType65);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder54.appendText(dateTimeFieldType65);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder41.appendFixedSignedDecimal(dateTimeFieldType65, (int) (byte) 1);
        boolean boolean70 = monthDay27.isSupported(dateTimeFieldType65);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder71 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType65);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 18062L + "'", long18 == 18062L);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(iSOChronology32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(monthDay37);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 21 + "'", int40 == 21);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(iSOChronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2 + "'", int49 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(iSOChronology58);
        org.junit.Assert.assertNotNull(durationField59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 2 + "'", int64 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder71);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(29, 166);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 195 + "'", int2 == 195);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        int int5 = property4.getMaximumValue();
        org.joda.time.Interval interval6 = property4.toInterval();
        java.util.Locale locale7 = null;
        int int8 = property4.getMaximumTextLength(locale7);
        java.lang.String str9 = property4.getAsString();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(interval6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "6" + "'", str9.equals("6"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (-1));
        int int2 = dateTime1.getSecondOfMinute();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder3.addCutover(24, ' ', 100, (int) '4', 0, true, 38);
        org.joda.time.DateTimeZone dateTimeZone14 = dateTimeZoneBuilder3.toDateTimeZone("0", false);
        org.joda.time.DateTime dateTime15 = dateTime1.withZone(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59 + "'", int2 == 59);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test181");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = delegatedDateTimeField5.getAsText((long) (short) 1, locale7);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        boolean boolean13 = monthDay11.isSupported(dateTimeFieldType12);
//        org.joda.time.MonthDay monthDay15 = monthDay11.withDayOfMonth(15);
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.MonthDay monthDay17 = monthDay15.plus(readablePeriod16);
//        int int18 = monthDay17.getDayOfMonth();
//        int int19 = delegatedDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) monthDay17);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
//        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology21);
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        boolean boolean24 = monthDay22.isSupported(dateTimeFieldType23);
//        org.joda.time.MonthDay monthDay26 = monthDay22.withDayOfMonth(15);
//        int int27 = monthDay22.getDayOfMonth();
//        int int28 = delegatedDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) monthDay22);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(monthDay15);
//        org.junit.Assert.assertNotNull(monthDay17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(monthDay26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 15 + "'", int27 == 15);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
        org.joda.time.DateTime dateTime5 = dateTime3.plusYears(15);
        org.joda.time.DateTime dateTime7 = dateTime5.plusSeconds((int) (short) 1);
        boolean boolean9 = dateTime5.isAfter((long) 43199);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((-86L));
        org.joda.time.Instant instant2 = instant1.toInstant();
        long long3 = instant1.getMillis();
        boolean boolean5 = instant1.isEqual(0L);
        org.joda.time.DateTime dateTime6 = instant1.toDateTimeISO();
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-86L) + "'", long3 == (-86L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("15", (java.lang.Number) 0, (java.lang.Number) 41, (java.lang.Number) 86400000L);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        org.junit.Assert.assertNull(dateTimeFieldType5);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        java.util.Locale locale6 = null;
        int int7 = delegatedDateTimeField5.getMaximumTextLength(locale6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = delegatedDateTimeField5.getType();
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeField[] dateTimeFieldArray10 = monthDay9.getFields();
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField5.getAsText((org.joda.time.ReadablePartial) monthDay9, (-1), locale12);
        long long16 = delegatedDateTimeField5.addWrapField((long) 15, 12);
        long long18 = delegatedDateTimeField5.roundHalfCeiling(0L);
        java.util.Locale locale20 = null;
        java.lang.String str21 = delegatedDateTimeField5.getAsText(0, locale20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField25 = iSOChronology24.halfdays();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology24.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField26, dateTimeFieldType27);
        java.util.Locale locale29 = null;
        int int30 = delegatedDateTimeField28.getMaximumTextLength(locale29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = delegatedDateTimeField28.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder22.appendText(dateTimeFieldType31);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField34 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, dateTimeFieldType31, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(dateTimeFieldArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1" + "'", str13.equals("-1"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 720015L + "'", long16 == 720015L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        java.util.Locale locale6 = null;
        int int7 = delegatedDateTimeField5.getMaximumTextLength(locale6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = delegatedDateTimeField5.getType();
        java.util.Locale locale9 = null;
        int int10 = delegatedDateTimeField5.getMaximumTextLength(locale9);
        org.joda.time.DurationField durationField11 = delegatedDateTimeField5.getDurationField();
        org.joda.time.DurationField durationField12 = delegatedDateTimeField5.getLeapDurationField();
        java.lang.String str13 = delegatedDateTimeField5.toString();
        long long15 = delegatedDateTimeField5.roundFloor(30L);
        org.joda.time.DurationField durationField16 = delegatedDateTimeField5.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNull(durationField12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str13.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(durationField16);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTime dateTime7 = dateTime1.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.era();
//        org.joda.time.DateTime dateTime11 = dateTime1.toDateTime((org.joda.time.Chronology) iSOChronology9);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusMinutes((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime14 = dateTime11.toMutableDateTimeISO();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43 + "'", int2 == 43);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.era();
        java.lang.Class<?> wildcardClass4 = iSOChronology2.getClass();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 20);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(1560630624063L, (long) 100);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        boolean boolean15 = monthDay13.isSupported(dateTimeFieldType14);
        org.joda.time.MonthDay monthDay17 = monthDay13.withDayOfMonth(15);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.MonthDay monthDay19 = monthDay17.plus(readablePeriod18);
        org.joda.time.MonthDay monthDay21 = monthDay19.plusDays(22);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        boolean boolean27 = monthDay25.isSupported(dateTimeFieldType26);
        org.joda.time.MonthDay monthDay29 = monthDay25.withDayOfMonth(15);
        int[] intArray31 = iSOChronology22.get((org.joda.time.ReadablePartial) monthDay29, (long) (short) -1);
        int int32 = offsetDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) monthDay19, intArray31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone34);
        org.joda.time.DurationField durationField36 = iSOChronology35.halfdays();
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology35.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField39 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField37, dateTimeFieldType38);
        java.util.Locale locale40 = null;
        int int41 = delegatedDateTimeField39.getMaximumTextLength(locale40);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = delegatedDateTimeField39.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder33.appendText(dateTimeFieldType42);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder33.appendSecondOfMinute((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean47 = dateTimeFormatterBuilder46.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology50 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone49);
        org.joda.time.DurationField durationField51 = iSOChronology50.halfdays();
        org.joda.time.DateTimeField dateTimeField52 = iSOChronology50.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField54 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField52, dateTimeFieldType53);
        java.util.Locale locale55 = null;
        int int56 = delegatedDateTimeField54.getMaximumTextLength(locale55);
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = delegatedDateTimeField54.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder48.appendText(dateTimeFieldType57);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder46.appendText(dateTimeFieldType57);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder33.appendFixedSignedDecimal(dateTimeFieldType57, (int) (byte) 1);
        boolean boolean62 = monthDay19.isSupported(dateTimeFieldType57);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField63 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 18062L + "'", long10 == 18062L);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 21 + "'", int32 == 21);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2 + "'", int41 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(iSOChronology50);
        org.junit.Assert.assertNotNull(durationField51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2 + "'", int56 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withHourOfDay(0);
        org.joda.time.DateTime dateTime5 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime5.withMillis((-1L));
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.era();
        java.lang.Class<?> wildcardClass11 = iSOChronology9.getClass();
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.MonthDay monthDay14 = monthDay12.withMonthOfYear((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
        org.joda.time.DurationField durationField18 = iSOChronology17.halfdays();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19, dateTimeFieldType20);
        java.util.Locale locale22 = null;
        int int23 = delegatedDateTimeField21.getMaximumTextLength(locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField21.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder15.appendText(dateTimeFieldType24);
        int int26 = monthDay12.indexOf(dateTimeFieldType24);
        org.joda.time.DateTime dateTime28 = dateTime5.withField(dateTimeFieldType24, 34);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField29 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(dateTime28);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("15", "--07-07", 48627451, (int) (byte) -1);
        long long6 = fixedDateTimeZone4.nextTransition(0L);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.withHourOfDay(0);
        org.joda.time.DateTime.Property property11 = dateTime10.monthOfYear();
        int int12 = property11.getMaximumValue();
        org.joda.time.Interval interval13 = property11.toInterval();
        java.util.Locale locale14 = null;
        int int15 = property11.getMaximumTextLength(locale14);
        java.util.Locale locale16 = null;
        int int17 = property11.getMaximumShortTextLength(locale16);
        boolean boolean18 = fixedDateTimeZone4.equals((java.lang.Object) int17);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
        org.junit.Assert.assertNotNull(interval13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = iSOChronology4.halfdays();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        int int9 = dateTime8.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
//        org.joda.time.Chronology chronology11 = iSOChronology4.withZone(dateTimeZone10);
//        java.lang.String str12 = dateTimeZone10.getID();
//        org.joda.time.Chronology chronology13 = gregorianChronology1.withZone(dateTimeZone10);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology1.millisOfDay();
//        java.lang.String str15 = gregorianChronology1.toString();
//        org.joda.time.Chronology chronology16 = gregorianChronology1.withUTC();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 44 + "'", int9 == 44);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "America/Los_Angeles" + "'", str12.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str15.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(chronology16);
//    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        boolean boolean1 = dateTimeFormatterBuilder0.canBuildFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
//        dateTimeFormatterBuilder2.clear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        int int6 = dateTime5.getSecondOfMinute();
//        org.joda.time.DateTime dateTime11 = dateTime5.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime13 = dateTime5.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
//        org.joda.time.DateTime dateTime17 = dateTime15.withHourOfDay(0);
//        int int18 = dateTime15.getDayOfMonth();
//        boolean boolean19 = dateTime13.isBefore((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        boolean boolean21 = dateTimeFormatter20.isPrinter();
//        java.lang.String str22 = dateTime15.toString(dateTimeFormatter20);
//        java.util.Locale locale23 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter20.withLocale(locale23);
//        org.joda.time.format.DateTimePrinter dateTimePrinter25 = dateTimeFormatter24.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatter26.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter25, dateTimeParser27);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.appendClockhourOfHalfday(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder29.appendCenturyOfEra(0, 2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder29.appendClockhourOfDay(9);
//        org.joda.time.format.DateTimeParser dateTimeParser37 = dateTimeFormatterBuilder29.toParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder38.appendClockhourOfHalfday(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder38.appendCenturyOfEra(0, 2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder38.appendClockhourOfDay(9);
//        org.joda.time.format.DateTimeParser dateTimeParser46 = dateTimeFormatterBuilder38.toParser();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray47 = new org.joda.time.format.DateTimeParser[] { dateTimeParser37, dateTimeParser46 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder2.append(dateTimePrinter25, dateTimeParserArray47);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone50);
//        org.joda.time.DurationField durationField52 = iSOChronology51.halfdays();
//        org.joda.time.DateTimeField dateTimeField53 = iSOChronology51.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType54 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField55 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField53, dateTimeFieldType54);
//        java.util.Locale locale56 = null;
//        int int57 = delegatedDateTimeField55.getMaximumTextLength(locale56);
//        org.joda.time.DateTimeFieldType dateTimeFieldType58 = delegatedDateTimeField55.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder49.appendText(dateTimeFieldType58);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder49.appendSecondOfMinute((int) (byte) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = new org.joda.time.format.DateTimeFormatterBuilder();
//        boolean boolean63 = dateTimeFormatterBuilder62.canBuildFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone65 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology66 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone65);
//        org.joda.time.DurationField durationField67 = iSOChronology66.halfdays();
//        org.joda.time.DateTimeField dateTimeField68 = iSOChronology66.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType69 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField70 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField68, dateTimeFieldType69);
//        java.util.Locale locale71 = null;
//        int int72 = delegatedDateTimeField70.getMaximumTextLength(locale71);
//        org.joda.time.DateTimeFieldType dateTimeFieldType73 = delegatedDateTimeField70.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder74 = dateTimeFormatterBuilder64.appendText(dateTimeFieldType73);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder75 = dateTimeFormatterBuilder62.appendText(dateTimeFieldType73);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder77 = dateTimeFormatterBuilder49.appendFixedSignedDecimal(dateTimeFieldType73, (int) (byte) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder78 = dateTimeFormatterBuilder48.appendShortText(dateTimeFieldType73);
//        org.joda.time.DateTimeZone dateTimeZone79 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology80 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone79);
//        org.joda.time.DateTimeField dateTimeField81 = iSOChronology80.era();
//        java.lang.Class<?> wildcardClass82 = iSOChronology80.getClass();
//        org.joda.time.MonthDay monthDay83 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology80);
//        org.joda.time.DurationField durationField84 = iSOChronology80.days();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField85 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType73, durationField84);
//        try {
//            long long87 = unsupportedDateTimeField85.roundHalfCeiling((long) 4);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 44 + "'", int6 == 44);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "20" + "'", str22.equals("20"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertNotNull(dateTimePrinter25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(dateTimeParser27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertNotNull(dateTimeParser37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(dateTimeParser46);
//        org.junit.Assert.assertNotNull(dateTimeParserArray47);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertNotNull(iSOChronology51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2 + "'", int57 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType58);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone65);
//        org.junit.Assert.assertNotNull(iSOChronology66);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertNotNull(dateTimeField68);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2 + "'", int72 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType73);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder74);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder75);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder77);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder78);
//        org.junit.Assert.assertNotNull(dateTimeZone79);
//        org.junit.Assert.assertNotNull(iSOChronology80);
//        org.junit.Assert.assertNotNull(dateTimeField81);
//        org.junit.Assert.assertNotNull(wildcardClass82);
//        org.junit.Assert.assertNotNull(durationField84);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField85);
//    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test193");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.era();
//        java.lang.Class<?> wildcardClass3 = iSOChronology1.getClass();
//        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DurationField durationField5 = iSOChronology1.millis();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        int int8 = dateTime7.getSecondOfMinute();
//        org.joda.time.DateTime dateTime13 = dateTime7.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime15 = dateTime13.plusYears((-1));
//        java.lang.String str16 = dateTime15.toString();
//        java.lang.String str17 = dateTime15.toString();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
//        org.joda.time.DurationField durationField20 = iSOChronology19.halfdays();
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology19.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
//        int int24 = dateTime23.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone25 = dateTime23.getZone();
//        org.joda.time.Chronology chronology26 = iSOChronology19.withZone(dateTimeZone25);
//        org.joda.time.DateTime dateTime27 = dateTime15.toDateTime(dateTimeZone25);
//        org.joda.time.DateTime dateTime29 = dateTime27.minusWeeks((int) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
//        org.joda.time.DateTime dateTime33 = dateTime31.withHourOfDay(0);
//        org.joda.time.DateTime dateTime34 = dateTime33.withEarlierOffsetAtOverlap();
//        boolean boolean35 = dateTime27.isAfter((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone36);
//        org.joda.time.MonthDay monthDay38 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = null;
//        boolean boolean40 = monthDay38.isSupported(dateTimeFieldType39);
//        org.joda.time.MonthDay monthDay42 = monthDay38.withDayOfMonth(15);
//        org.joda.time.DateTime dateTime43 = dateTime34.withFields((org.joda.time.ReadablePartial) monthDay38);
//        org.joda.time.DateTime dateTime45 = dateTime43.plusWeeks(22);
//        org.joda.time.ReadableDateTime readableDateTime46 = null;
//        org.joda.time.chrono.LimitChronology limitChronology47 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.ReadableDateTime) dateTime43, readableDateTime46);
//        org.joda.time.DateTime dateTime48 = limitChronology47.getUpperLimit();
//        org.joda.time.DateTime dateTime49 = limitChronology47.getUpperLimit();
//        org.joda.time.DurationField durationField50 = limitChronology47.weekyears();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 44 + "'", int8 == 44);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2018-06-15T10:13:15.013-07:00" + "'", str16.equals("2018-06-15T10:13:15.013-07:00"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2018-06-15T10:13:15.013-07:00" + "'", str17.equals("2018-06-15T10:13:15.013-07:00"));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 44 + "'", int24 == 44);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(iSOChronology37);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(monthDay42);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(limitChronology47);
//        org.junit.Assert.assertNull(dateTime48);
//        org.junit.Assert.assertNull(dateTime49);
//        org.junit.Assert.assertNotNull(durationField50);
//    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test194");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        boolean boolean1 = dateTimeFormatterBuilder0.canBuildFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
//        dateTimeFormatterBuilder2.clear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        int int6 = dateTime5.getSecondOfMinute();
//        org.joda.time.DateTime dateTime11 = dateTime5.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime13 = dateTime5.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
//        org.joda.time.DateTime dateTime17 = dateTime15.withHourOfDay(0);
//        int int18 = dateTime15.getDayOfMonth();
//        boolean boolean19 = dateTime13.isBefore((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        boolean boolean21 = dateTimeFormatter20.isPrinter();
//        java.lang.String str22 = dateTime15.toString(dateTimeFormatter20);
//        java.util.Locale locale23 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter20.withLocale(locale23);
//        org.joda.time.format.DateTimePrinter dateTimePrinter25 = dateTimeFormatter24.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatter26.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter25, dateTimeParser27);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.appendClockhourOfHalfday(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder29.appendCenturyOfEra(0, 2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder29.appendClockhourOfDay(9);
//        org.joda.time.format.DateTimeParser dateTimeParser37 = dateTimeFormatterBuilder29.toParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder38.appendClockhourOfHalfday(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder38.appendCenturyOfEra(0, 2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder38.appendClockhourOfDay(9);
//        org.joda.time.format.DateTimeParser dateTimeParser46 = dateTimeFormatterBuilder38.toParser();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray47 = new org.joda.time.format.DateTimeParser[] { dateTimeParser37, dateTimeParser46 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder2.append(dateTimePrinter25, dateTimeParserArray47);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone50);
//        org.joda.time.DurationField durationField52 = iSOChronology51.halfdays();
//        org.joda.time.DateTimeField dateTimeField53 = iSOChronology51.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType54 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField55 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField53, dateTimeFieldType54);
//        java.util.Locale locale56 = null;
//        int int57 = delegatedDateTimeField55.getMaximumTextLength(locale56);
//        org.joda.time.DateTimeFieldType dateTimeFieldType58 = delegatedDateTimeField55.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder49.appendText(dateTimeFieldType58);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder49.appendSecondOfMinute((int) (byte) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = new org.joda.time.format.DateTimeFormatterBuilder();
//        boolean boolean63 = dateTimeFormatterBuilder62.canBuildFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone65 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology66 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone65);
//        org.joda.time.DurationField durationField67 = iSOChronology66.halfdays();
//        org.joda.time.DateTimeField dateTimeField68 = iSOChronology66.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType69 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField70 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField68, dateTimeFieldType69);
//        java.util.Locale locale71 = null;
//        int int72 = delegatedDateTimeField70.getMaximumTextLength(locale71);
//        org.joda.time.DateTimeFieldType dateTimeFieldType73 = delegatedDateTimeField70.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder74 = dateTimeFormatterBuilder64.appendText(dateTimeFieldType73);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder75 = dateTimeFormatterBuilder62.appendText(dateTimeFieldType73);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder77 = dateTimeFormatterBuilder49.appendFixedSignedDecimal(dateTimeFieldType73, (int) (byte) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder78 = dateTimeFormatterBuilder48.appendShortText(dateTimeFieldType73);
//        org.joda.time.DateTimeZone dateTimeZone79 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology80 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone79);
//        org.joda.time.DateTimeField dateTimeField81 = iSOChronology80.era();
//        java.lang.Class<?> wildcardClass82 = iSOChronology80.getClass();
//        org.joda.time.MonthDay monthDay83 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology80);
//        org.joda.time.DurationField durationField84 = iSOChronology80.days();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField85 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType73, durationField84);
//        long long88 = unsupportedDateTimeField85.add((long) 47, 47);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 45 + "'", int6 == 45);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "20" + "'", str22.equals("20"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertNotNull(dateTimePrinter25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(dateTimeParser27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertNotNull(dateTimeParser37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(dateTimeParser46);
//        org.junit.Assert.assertNotNull(dateTimeParserArray47);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertNotNull(iSOChronology51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2 + "'", int57 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType58);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone65);
//        org.junit.Assert.assertNotNull(iSOChronology66);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertNotNull(dateTimeField68);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2 + "'", int72 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType73);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder74);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder75);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder77);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder78);
//        org.junit.Assert.assertNotNull(dateTimeZone79);
//        org.junit.Assert.assertNotNull(iSOChronology80);
//        org.junit.Assert.assertNotNull(dateTimeField81);
//        org.junit.Assert.assertNotNull(wildcardClass82);
//        org.junit.Assert.assertNotNull(durationField84);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField85);
//        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 4060800047L + "'", long88 == 4060800047L);
//    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test195");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTime dateTime7 = dateTime1.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime9 = dateTime7.plusYears((-1));
//        java.lang.String str10 = dateTime9.toString();
//        org.joda.time.DateTime dateTime12 = dateTime9.withYearOfCentury(13);
//        int int13 = dateTime12.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45 + "'", int2 == 45);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2018-06-15T10:13:15.013-07:00" + "'", str10.equals("2018-06-15T10:13:15.013-07:00"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        boolean boolean4 = monthDay2.isSupported(dateTimeFieldType3);
        org.joda.time.MonthDay monthDay6 = monthDay2.withDayOfMonth(15);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay8 = monthDay6.plus(readablePeriod7);
        org.joda.time.MonthDay.Property property9 = monthDay8.dayOfMonth();
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.parse("");
        int int12 = property9.compareTo((org.joda.time.ReadablePartial) monthDay11);
        org.joda.time.MonthDay monthDay14 = property9.addToCopy((int) (byte) 0);
        org.joda.time.MonthDay monthDay15 = property9.getMonthDay();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(monthDay15);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        int int4 = dateTime3.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone5 = dateTime3.getZone();
//        boolean boolean6 = dateTime3.isEqualNow();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTime3.toString("25", locale8);
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
//        org.joda.time.DurationField durationField12 = iSOChronology11.halfdays();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
//        int int16 = dateTime15.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone17 = dateTime15.getZone();
//        org.joda.time.Chronology chronology18 = iSOChronology11.withZone(dateTimeZone17);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone17);
//        org.joda.time.DateTime dateTime20 = dateTime3.withChronology((org.joda.time.Chronology) buddhistChronology19);
//        try {
//            org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay(4, 46, (org.joda.time.Chronology) buddhistChronology19);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 46 for dayOfMonth must not be larger than 31");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 45 + "'", int4 == 45);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "25" + "'", str9.equals("25"));
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 45 + "'", int16 == 45);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(buddhistChronology19);
//        org.junit.Assert.assertNotNull(dateTime20);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((-86L));
        org.joda.time.Instant instant2 = instant1.toInstant();
        org.joda.time.Instant instant5 = instant1.withDurationAdded((long) 0, 0);
        org.joda.time.Chronology chronology6 = instant1.getChronology();
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(24, ' ', 100, (int) '4', 0, true, 38);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeZoneBuilder0.toDateTimeZone("0", false);
        java.io.DataOutput dataOutput13 = null;
        try {
            dateTimeZoneBuilder0.writeTo("0", dataOutput13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.halfdays();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType5);
        java.util.Locale locale7 = null;
        int int8 = delegatedDateTimeField6.getMaximumTextLength(locale7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = delegatedDateTimeField6.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType9);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (int) (byte) -1, 43);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.era();
        java.lang.Class<?> wildcardClass18 = iSOChronology16.getClass();
        org.joda.time.DurationField durationField19 = iSOChronology16.seconds();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.DurationField durationField22 = iSOChronology21.halfdays();
        org.joda.time.DurationField durationField23 = iSOChronology21.halfdays();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField24 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType9, durationField19, durationField23);
        int int26 = preciseDateTimeField24.getMinimumValue((long) 47);
        long long27 = preciseDateTimeField24.getUnitMillis();
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = null;
        boolean boolean32 = monthDay30.isSupported(dateTimeFieldType31);
        org.joda.time.MonthDay monthDay34 = monthDay30.withDayOfMonth(15);
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.MonthDay monthDay36 = monthDay34.plus(readablePeriod35);
        org.joda.time.MonthDay.Property property37 = monthDay36.dayOfMonth();
        org.joda.time.MonthDay monthDay39 = property37.setCopy("25");
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone41);
        org.joda.time.DurationField durationField43 = iSOChronology42.halfdays();
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology42.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField46 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField44, dateTimeFieldType45);
        java.util.Locale locale47 = null;
        int int48 = delegatedDateTimeField46.getMaximumTextLength(locale47);
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = delegatedDateTimeField46.getType();
        java.util.Locale locale50 = null;
        int int51 = delegatedDateTimeField46.getMaximumTextLength(locale50);
        org.joda.time.DurationField durationField52 = delegatedDateTimeField46.getDurationField();
        java.util.Locale locale53 = null;
        int int54 = delegatedDateTimeField46.getMaximumShortTextLength(locale53);
        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone55);
        org.joda.time.MonthDay monthDay57 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology56);
        org.joda.time.DateTimeFieldType dateTimeFieldType58 = null;
        boolean boolean59 = monthDay57.isSupported(dateTimeFieldType58);
        org.joda.time.MonthDay monthDay61 = monthDay57.withDayOfMonth(15);
        org.joda.time.ReadablePeriod readablePeriod62 = null;
        org.joda.time.MonthDay monthDay63 = monthDay61.plus(readablePeriod62);
        org.joda.time.MonthDay.Property property64 = monthDay63.dayOfMonth();
        org.joda.time.MonthDay monthDay66 = org.joda.time.MonthDay.parse("");
        int int67 = property64.compareTo((org.joda.time.ReadablePartial) monthDay66);
        org.joda.time.MonthDay monthDay69 = property64.addToCopy((int) (byte) 0);
        int[] intArray71 = new int[] { 32 };
        int int72 = delegatedDateTimeField46.getMaximumValue((org.joda.time.ReadablePartial) monthDay69, intArray71);
        try {
            int[] intArray74 = preciseDateTimeField24.addWrapPartial((org.joda.time.ReadablePartial) monthDay39, 37, intArray71, 2922789);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 37");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1000L + "'", long27 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertNotNull(monthDay36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(monthDay39);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2 + "'", int48 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2 + "'", int51 == 2);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2 + "'", int54 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone55);
        org.junit.Assert.assertNotNull(iSOChronology56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(monthDay61);
        org.junit.Assert.assertNotNull(monthDay63);
        org.junit.Assert.assertNotNull(property64);
        org.junit.Assert.assertNotNull(monthDay66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertNotNull(monthDay69);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 59 + "'", int72 == 59);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DurationField durationField3 = iSOChronology1.halfdays();
        org.joda.time.DurationField durationField4 = iSOChronology1.months();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField7 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType5, 34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTime();
        org.joda.time.Chronology chronology5 = dateTime1.getChronology();
        org.joda.time.DateTime.Property property6 = dateTime1.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMinuteOfDay(0);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.clockhourOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = iSOChronology10.halfdays();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology10.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, dateTimeFieldType13);
        java.util.Locale locale15 = null;
        int int16 = delegatedDateTimeField14.getMaximumTextLength(locale15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = delegatedDateTimeField14.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder8.appendText(dateTimeFieldType17);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType17, 2019, 3, 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType17, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean26 = dateTimeFormatterBuilder25.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
        org.joda.time.DurationField durationField30 = iSOChronology29.halfdays();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology29.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField33 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField31, dateTimeFieldType32);
        java.util.Locale locale34 = null;
        int int35 = delegatedDateTimeField33.getMaximumTextLength(locale34);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = delegatedDateTimeField33.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder27.appendText(dateTimeFieldType36);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder25.appendText(dateTimeFieldType36);
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.DurationField durationField41 = iSOChronology40.halfdays();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology40.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField44 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField42, dateTimeFieldType43);
        java.util.Locale locale45 = null;
        int int46 = delegatedDateTimeField44.getMaximumTextLength(locale45);
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = delegatedDateTimeField44.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder25.appendSignedDecimal(dateTimeFieldType47, 26, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean52 = dateTimeFormatterBuilder51.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology55 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone54);
        org.joda.time.DurationField durationField56 = iSOChronology55.halfdays();
        org.joda.time.DateTimeField dateTimeField57 = iSOChronology55.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType58 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField59 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField57, dateTimeFieldType58);
        java.util.Locale locale60 = null;
        int int61 = delegatedDateTimeField59.getMaximumTextLength(locale60);
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = delegatedDateTimeField59.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder53.appendText(dateTimeFieldType62);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder51.appendText(dateTimeFieldType62);
        org.joda.time.DateTimeZone dateTimeZone65 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology66 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone65);
        org.joda.time.DurationField durationField67 = iSOChronology66.halfdays();
        org.joda.time.DateTimeField dateTimeField68 = iSOChronology66.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType69 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField70 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField68, dateTimeFieldType69);
        java.util.Locale locale71 = null;
        int int72 = delegatedDateTimeField70.getMaximumTextLength(locale71);
        org.joda.time.DateTimeFieldType dateTimeFieldType73 = delegatedDateTimeField70.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder76 = dateTimeFormatterBuilder51.appendSignedDecimal(dateTimeFieldType73, 26, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder79 = dateTimeFormatterBuilder25.appendDecimal(dateTimeFieldType73, (int) (byte) 10, 26);
        org.joda.time.IllegalFieldValueException illegalFieldValueException81 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType73, "12");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder83 = dateTimeFormatterBuilder24.appendFixedDecimal(dateTimeFieldType73, 52);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder85 = dateTimeFormatterBuilder24.appendSecondOfDay((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2 + "'", int35 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertNotNull(iSOChronology55);
        org.junit.Assert.assertNotNull(durationField56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2 + "'", int61 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertNotNull(dateTimeZone65);
        org.junit.Assert.assertNotNull(iSOChronology66);
        org.junit.Assert.assertNotNull(durationField67);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2 + "'", int72 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType73);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder76);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder79);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder83);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder85);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.halfdays();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType7);
        java.util.Locale locale9 = null;
        int int10 = delegatedDateTimeField8.getMaximumTextLength(locale9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = delegatedDateTimeField8.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder2.appendText(dateTimeFieldType11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType11);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.DurationField durationField16 = iSOChronology15.halfdays();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType18);
        java.util.Locale locale20 = null;
        int int21 = delegatedDateTimeField19.getMaximumTextLength(locale20);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = delegatedDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType22, 26, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean27 = dateTimeFormatterBuilder26.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
        org.joda.time.DurationField durationField31 = iSOChronology30.halfdays();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology30.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField32, dateTimeFieldType33);
        java.util.Locale locale35 = null;
        int int36 = delegatedDateTimeField34.getMaximumTextLength(locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = delegatedDateTimeField34.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder28.appendText(dateTimeFieldType37);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder26.appendText(dateTimeFieldType37);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone40);
        org.joda.time.DurationField durationField42 = iSOChronology41.halfdays();
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology41.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField45 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField43, dateTimeFieldType44);
        java.util.Locale locale46 = null;
        int int47 = delegatedDateTimeField45.getMaximumTextLength(locale46);
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = delegatedDateTimeField45.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder26.appendSignedDecimal(dateTimeFieldType48, 26, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder0.appendDecimal(dateTimeFieldType48, (int) (byte) 10, 26);
        org.joda.time.IllegalFieldValueException illegalFieldValueException56 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType48, "12");
        illegalFieldValueException56.prependMessage("51");
        org.joda.time.DateTimeFieldType dateTimeFieldType59 = illegalFieldValueException56.getDateTimeFieldType();
        java.lang.Throwable throwable60 = null;
        try {
            illegalFieldValueException56.addSuppressed(throwable60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2 + "'", int36 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2 + "'", int47 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(dateTimeFieldType59);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("15", "--07-07", 48627451, (int) (byte) -1);
        int int6 = fixedDateTimeZone4.getOffset((long) 10);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 48627451 + "'", int6 == 48627451);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        boolean boolean4 = monthDay2.isSupported(dateTimeFieldType3);
        org.joda.time.MonthDay monthDay6 = monthDay2.withDayOfMonth(15);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay8 = monthDay6.plus(readablePeriod7);
        org.joda.time.MonthDay.Property property9 = monthDay8.dayOfMonth();
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.parse("");
        int int12 = property9.compareTo((org.joda.time.ReadablePartial) monthDay11);
        org.joda.time.MonthDay monthDay14 = property9.addToCopy((int) (byte) 0);
        java.util.Locale locale15 = null;
        int int16 = property9.getMaximumTextLength(locale15);
        int int17 = property9.getMaximumValueOverall();
        int int18 = property9.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 31 + "'", int17 == 31);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 31 + "'", int18 == 31);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test208");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
//        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
//        boolean boolean9 = monthDay7.isSupported(dateTimeFieldType8);
//        int int10 = property4.compareTo((org.joda.time.ReadablePartial) monthDay7);
//        org.joda.time.DateTimeField dateTimeField11 = property4.getField();
//        long long12 = property4.remainder();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1211506323L + "'", long12 == 1211506323L);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        java.util.Locale locale6 = null;
        int int7 = delegatedDateTimeField5.getMaximumTextLength(locale6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = delegatedDateTimeField5.getType();
        java.util.Locale locale9 = null;
        int int10 = delegatedDateTimeField5.getMaximumTextLength(locale9);
        org.joda.time.DurationField durationField11 = delegatedDateTimeField5.getDurationField();
        java.util.Locale locale12 = null;
        int int13 = delegatedDateTimeField5.getMaximumShortTextLength(locale12);
        long long15 = delegatedDateTimeField5.roundCeiling(100L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 60000L + "'", long15 == 60000L);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        boolean boolean9 = monthDay7.isSupported(dateTimeFieldType8);
        int int10 = property4.compareTo((org.joda.time.ReadablePartial) monthDay7);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.DurationField durationField13 = iSOChronology12.halfdays();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.minuteOfHour();
        boolean boolean15 = property4.equals((java.lang.Object) dateTimeField14);
        int int16 = property4.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test211");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
//        int int4 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusDays((int) (byte) 10);
//        org.joda.time.DateTime.Property property7 = dateTime6.millisOfSecond();
//        int int8 = dateTime6.getMillisOfDay();
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime6.minus(readableDuration9);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 48706459 + "'", int8 == 48706459);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime5 = property4.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime6 = property4.withMinimumValue();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test213");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTime dateTime7 = dateTime1.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime9 = dateTime7.plusYears((-1));
//        java.lang.String str10 = dateTime9.toString();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime9.plus(readablePeriod11);
//        org.joda.time.DateTime dateTime14 = dateTime9.minusMonths(74);
//        org.joda.time.Instant instant15 = dateTime9.toInstant();
//        boolean boolean17 = instant15.isAfter(14256000013L);
//        org.joda.time.MutableDateTime mutableDateTime18 = instant15.toMutableDateTime();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46 + "'", int2 == 46);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2018-06-15T10:13:15.013-07:00" + "'", str10.equals("2018-06-15T10:13:15.013-07:00"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(instant15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        boolean boolean4 = monthDay2.isSupported(dateTimeFieldType3);
        org.joda.time.MonthDay monthDay6 = monthDay2.withDayOfMonth(15);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay8 = monthDay6.plus(readablePeriod7);
        org.joda.time.MonthDay.Property property9 = monthDay8.dayOfMonth();
        org.joda.time.MonthDay monthDay11 = property9.setCopy("1");
        java.util.Locale locale12 = null;
        java.lang.String str13 = property9.getAsShortText(locale12);
        int int14 = property9.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "15" + "'", str13.equals("15"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 30 + "'", int14 == 30);
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test215");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTime dateTime7 = dateTime1.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime9 = dateTime1.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
//        org.joda.time.DateTime dateTime13 = dateTime11.withHourOfDay(0);
//        int int14 = dateTime11.getDayOfMonth();
//        boolean boolean15 = dateTime9.isBefore((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTime dateTime17 = dateTime11.plusDays(43199);
//        org.joda.time.DateTime dateTime19 = dateTime11.withSecondOfMinute(51);
//        int int20 = dateTime19.getDayOfYear();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46 + "'", int2 == 46);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 166 + "'", int20 == 166);
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.era();
        java.lang.Class<?> wildcardClass3 = iSOChronology1.getClass();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 20);
        int int8 = offsetDateTimeField6.getMinimumValue((-1L));
        java.util.Locale locale9 = null;
        int int10 = offsetDateTimeField6.getMaximumShortTextLength(locale9);
        boolean boolean11 = offsetDateTimeField6.isLenient();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 21 + "'", int8 == 21);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long3 = durationField0.subtract((long) 38, 1560630623999L);
        org.junit.Assert.assertNotNull(durationField0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1560630623961L) + "'", long3 == (-1560630623961L));
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test218");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        int int4 = dateTime3.getSecondOfMinute();
//        org.joda.time.DateTime dateTime9 = dateTime3.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime11 = dateTime3.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime13);
//        int int16 = gJChronology15.getMinimumDaysInFirstWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        org.joda.time.Chronology chronology18 = dateTimeFormatter17.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTimeFormatter17.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology15, dateTimeZone19);
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
//        org.joda.time.DurationField durationField23 = iSOChronology22.halfdays();
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.minuteOfHour();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology15, dateTimeField24);
//        int int27 = skipDateTimeField25.get(1560630620075L);
//        boolean boolean28 = skipDateTimeField25.isSupported();
//        long long31 = skipDateTimeField25.set(2460035L, 22);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 46 + "'", int4 == 46);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNull(chronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(zonedChronology20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 30 + "'", int27 == 30);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1320035L + "'", long31 == 1320035L);
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.halfdays();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType5);
        java.util.Locale locale7 = null;
        int int8 = delegatedDateTimeField6.getMaximumTextLength(locale7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = delegatedDateTimeField6.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType9);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (int) (byte) -1, 43);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.era();
        java.lang.Class<?> wildcardClass18 = iSOChronology16.getClass();
        org.joda.time.DurationField durationField19 = iSOChronology16.seconds();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.DurationField durationField22 = iSOChronology21.halfdays();
        org.joda.time.DurationField durationField23 = iSOChronology21.halfdays();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField24 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType9, durationField19, durationField23);
        long long26 = preciseDateTimeField24.roundFloor(28800074L);
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone27);
        org.joda.time.DurationField durationField29 = iSOChronology28.halfdays();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField30, dateTimeFieldType31);
        java.util.Locale locale33 = null;
        int int34 = delegatedDateTimeField32.getMaximumTextLength(locale33);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = delegatedDateTimeField32.getType();
        java.util.Locale locale36 = null;
        int int37 = delegatedDateTimeField32.getMaximumTextLength(locale36);
        org.joda.time.DurationField durationField38 = delegatedDateTimeField32.getDurationField();
        org.joda.time.DurationField durationField39 = delegatedDateTimeField32.getLeapDurationField();
        java.lang.String str40 = delegatedDateTimeField32.toString();
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone41);
        org.joda.time.MonthDay monthDay43 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = null;
        boolean boolean45 = monthDay43.isSupported(dateTimeFieldType44);
        org.joda.time.MonthDay monthDay47 = monthDay43.withDayOfMonth(15);
        int int48 = delegatedDateTimeField32.getMinimumValue((org.joda.time.ReadablePartial) monthDay43);
        org.joda.time.MonthDay monthDay50 = monthDay43.minusMonths(0);
        int int51 = preciseDateTimeField24.getMinimumValue((org.joda.time.ReadablePartial) monthDay43);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 28800000L + "'", long26 == 28800000L);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2 + "'", int34 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2 + "'", int37 == 2);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNull(durationField39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str40.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(monthDay47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(monthDay50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendPattern("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendDayOfYear(9);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatterBuilder9.toFormatter();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendLiteral('#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test222");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        boolean boolean4 = monthDay2.isSupported(dateTimeFieldType3);
//        org.joda.time.MonthDay monthDay6 = monthDay2.withDayOfMonth(15);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime dateTime10 = dateTime8.withHourOfDay(0);
//        int int11 = dateTime8.getDayOfMonth();
//        org.joda.time.DateTime dateTime12 = monthDay2.toDateTime((org.joda.time.ReadableInstant) dateTime8);
//        boolean boolean13 = dateTime8.isBeforeNow();
//        org.joda.time.DateTime.Property property14 = dateTime8.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
//        org.joda.time.DateTime dateTime18 = dateTime16.withHourOfDay(0);
//        org.joda.time.Chronology chronology19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime18.toDateTime(chronology19);
//        org.joda.time.DateTime dateTime22 = dateTime18.withMillisOfDay(810);
//        int int23 = property14.getDifference((org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.Interval interval24 = property14.toInterval();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(interval24);
//    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(17, false);
        boolean boolean4 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(2000, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendYearOfCentury((int) '4', 36);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder8.appendYearOfCentury(0, 23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test224");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
//        boolean boolean5 = dateTime1.isAfter((long) (short) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
//        boolean boolean7 = dateTimeFormatterBuilder6.canBuildFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMonthOfYearText();
//        dateTimeFormatterBuilder8.clear();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
//        int int12 = dateTime11.getSecondOfMinute();
//        org.joda.time.DateTime dateTime17 = dateTime11.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime19 = dateTime11.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
//        org.joda.time.DateTime dateTime23 = dateTime21.withHourOfDay(0);
//        int int24 = dateTime21.getDayOfMonth();
//        boolean boolean25 = dateTime19.isBefore((org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        boolean boolean27 = dateTimeFormatter26.isPrinter();
//        java.lang.String str28 = dateTime21.toString(dateTimeFormatter26);
//        java.util.Locale locale29 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter26.withLocale(locale29);
//        org.joda.time.format.DateTimePrinter dateTimePrinter31 = dateTimeFormatter30.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        org.joda.time.format.DateTimeParser dateTimeParser33 = dateTimeFormatter32.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter31, dateTimeParser33);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder35.appendClockhourOfHalfday(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder35.appendCenturyOfEra(0, 2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder35.appendClockhourOfDay(9);
//        org.joda.time.format.DateTimeParser dateTimeParser43 = dateTimeFormatterBuilder35.toParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder44.appendClockhourOfHalfday(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder44.appendCenturyOfEra(0, 2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder44.appendClockhourOfDay(9);
//        org.joda.time.format.DateTimeParser dateTimeParser52 = dateTimeFormatterBuilder44.toParser();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray53 = new org.joda.time.format.DateTimeParser[] { dateTimeParser43, dateTimeParser52 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder8.append(dateTimePrinter31, dateTimeParserArray53);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology57 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone56);
//        org.joda.time.DurationField durationField58 = iSOChronology57.halfdays();
//        org.joda.time.DateTimeField dateTimeField59 = iSOChronology57.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType60 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField61 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField59, dateTimeFieldType60);
//        java.util.Locale locale62 = null;
//        int int63 = delegatedDateTimeField61.getMaximumTextLength(locale62);
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = delegatedDateTimeField61.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder55.appendText(dateTimeFieldType64);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder55.appendSecondOfMinute((int) (byte) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = new org.joda.time.format.DateTimeFormatterBuilder();
//        boolean boolean69 = dateTimeFormatterBuilder68.canBuildFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder70 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone71 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology72 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone71);
//        org.joda.time.DurationField durationField73 = iSOChronology72.halfdays();
//        org.joda.time.DateTimeField dateTimeField74 = iSOChronology72.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType75 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField76 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField74, dateTimeFieldType75);
//        java.util.Locale locale77 = null;
//        int int78 = delegatedDateTimeField76.getMaximumTextLength(locale77);
//        org.joda.time.DateTimeFieldType dateTimeFieldType79 = delegatedDateTimeField76.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder80 = dateTimeFormatterBuilder70.appendText(dateTimeFieldType79);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder81 = dateTimeFormatterBuilder68.appendText(dateTimeFieldType79);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder83 = dateTimeFormatterBuilder55.appendFixedSignedDecimal(dateTimeFieldType79, (int) (byte) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder84 = dateTimeFormatterBuilder54.appendShortText(dateTimeFieldType79);
//        org.joda.time.DateTime dateTime86 = dateTime1.withField(dateTimeFieldType79, (int) ' ');
//        org.joda.time.DateTime.Property property87 = dateTime86.year();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 47 + "'", int12 == 47);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 15 + "'", int24 == 15);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "20" + "'", str28.equals("20"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter30);
//        org.junit.Assert.assertNotNull(dateTimePrinter31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter32);
//        org.junit.Assert.assertNotNull(dateTimeParser33);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(dateTimeParser43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
//        org.junit.Assert.assertNotNull(dateTimeParser52);
//        org.junit.Assert.assertNotNull(dateTimeParserArray53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
//        org.junit.Assert.assertNotNull(dateTimeZone56);
//        org.junit.Assert.assertNotNull(iSOChronology57);
//        org.junit.Assert.assertNotNull(durationField58);
//        org.junit.Assert.assertNotNull(dateTimeField59);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2 + "'", int63 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone71);
//        org.junit.Assert.assertNotNull(iSOChronology72);
//        org.junit.Assert.assertNotNull(durationField73);
//        org.junit.Assert.assertNotNull(dateTimeField74);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 2 + "'", int78 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType79);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder80);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder81);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder83);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder84);
//        org.junit.Assert.assertNotNull(dateTime86);
//        org.junit.Assert.assertNotNull(property87);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        java.util.Locale locale6 = null;
        int int7 = delegatedDateTimeField5.getMaximumTextLength(locale6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = delegatedDateTimeField5.getType();
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeField[] dateTimeFieldArray10 = monthDay9.getFields();
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField5.getAsText((org.joda.time.ReadablePartial) monthDay9, (-1), locale12);
        long long16 = delegatedDateTimeField5.addWrapField((long) 15, 12);
        int int17 = delegatedDateTimeField5.getMaximumValue();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) delegatedDateTimeField5, 48667485, 100, 13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 48667485 for minuteOfHour must be in the range [100,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(dateTimeFieldArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1" + "'", str13.equals("-1"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 720015L + "'", long16 == 720015L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 59 + "'", int17 == 59);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(48627451);
        java.lang.String str2 = dateTimeZone1.getID();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+13:30:27.451" + "'", str2.equals("+13:30:27.451"));
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        int int4 = dateTime3.getSecondOfMinute();
//        org.joda.time.DateTime dateTime9 = dateTime3.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime11 = dateTime3.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime13);
//        int int16 = gJChronology15.getMinimumDaysInFirstWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        org.joda.time.Chronology chronology18 = dateTimeFormatter17.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTimeFormatter17.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology15, dateTimeZone19);
//        long long26 = zonedChronology20.getDateTimeMillis(1560630623999L, (int) (short) 0, 0, 12, 3);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone29);
//        int int31 = dateTime30.getSecondOfMinute();
//        org.joda.time.DateTime dateTime36 = dateTime30.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime38 = dateTime30.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime40 = dateTime38.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone28, (org.joda.time.ReadableInstant) dateTime40);
//        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone27, (org.joda.time.ReadableInstant) dateTime40);
//        int int43 = gJChronology42.getMinimumDaysInFirstWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        org.joda.time.Chronology chronology45 = dateTimeFormatter44.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone46 = dateTimeFormatter44.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology47 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology42, dateTimeZone46);
//        org.joda.time.Chronology chronology48 = zonedChronology20.withZone(dateTimeZone46);
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology50 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone49);
//        org.joda.time.DurationField durationField51 = iSOChronology50.halfdays();
//        org.joda.time.DateTimeField dateTimeField52 = iSOChronology50.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime(dateTimeZone53);
//        int int55 = dateTime54.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone56 = dateTime54.getZone();
//        org.joda.time.Chronology chronology57 = iSOChronology50.withZone(dateTimeZone56);
//        java.lang.String str58 = dateTimeZone56.getID();
//        org.joda.time.Chronology chronology59 = zonedChronology20.withZone(dateTimeZone56);
//        org.joda.time.DateTimeZone dateTimeZone60 = zonedChronology20.getZone();
//        org.joda.time.DateTimeZone dateTimeZone61 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology62 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone61);
//        org.joda.time.DateTimeField dateTimeField63 = iSOChronology62.era();
//        java.lang.Class<?> wildcardClass64 = iSOChronology62.getClass();
//        org.joda.time.DateTimeField dateTimeField65 = iSOChronology62.dayOfMonth();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, 20);
//        org.joda.time.DateTimeField dateTimeField68 = offsetDateTimeField67.getWrappedField();
//        org.joda.time.DurationField durationField69 = offsetDateTimeField67.getDurationField();
//        long long71 = offsetDateTimeField67.remainder(780010L);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField73 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) zonedChronology20, (org.joda.time.DateTimeField) offsetDateTimeField67, 0);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 48 + "'", int4 == 48);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNull(chronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(zonedChronology20);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560556812003L + "'", long26 == 1560556812003L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 48 + "'", int31 == 48);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(gJChronology41);
//        org.junit.Assert.assertNotNull(gJChronology42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 4 + "'", int43 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter44);
//        org.junit.Assert.assertNull(chronology45);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertNotNull(zonedChronology47);
//        org.junit.Assert.assertNotNull(chronology48);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertNotNull(iSOChronology50);
//        org.junit.Assert.assertNotNull(durationField51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 48 + "'", int55 == 48);
//        org.junit.Assert.assertNotNull(dateTimeZone56);
//        org.junit.Assert.assertNotNull(chronology57);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "America/Los_Angeles" + "'", str58.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(chronology59);
//        org.junit.Assert.assertNotNull(dateTimeZone60);
//        org.junit.Assert.assertNotNull(dateTimeZone61);
//        org.junit.Assert.assertNotNull(iSOChronology62);
//        org.junit.Assert.assertNotNull(dateTimeField63);
//        org.junit.Assert.assertNotNull(wildcardClass64);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertNotNull(dateTimeField68);
//        org.junit.Assert.assertNotNull(durationField69);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 780010L + "'", long71 == 780010L);
//    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test228");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime1.getZone();
//        boolean boolean4 = dateTime1.isEqualNow();
//        org.joda.time.DateTime dateTime6 = dateTime1.withMillis((long) 59);
//        try {
//            org.joda.time.DateTime dateTime8 = dateTime1.withDayOfMonth(56);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 56 for dayOfMonth must be in the range [1,30]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48 + "'", int2 == 48);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test229");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
//        int int4 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusDays((int) (byte) 10);
//        org.joda.time.DateTime.Property property7 = dateTime6.millisOfSecond();
//        org.joda.time.DateTime dateTime8 = property7.withMaximumValue();
//        org.joda.time.DateTime dateTime10 = property7.addToCopy((long) (short) 0);
//        org.joda.time.DateTime.Property property11 = dateTime10.centuryOfEra();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test230");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        org.joda.time.DateTime dateTime5 = dateTime3.withHourOfDay(0);
//        org.joda.time.DateTime.Property property6 = dateTime5.monthOfYear();
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.DateTime dateTime9 = dateTime5.withDurationAdded(readableDuration7, 22);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
//        org.joda.time.DateTime dateTime13 = dateTime11.withHourOfDay(0);
//        int int14 = dateTime11.getDayOfMonth();
//        org.joda.time.DateTime dateTime16 = dateTime11.plusDays((int) (byte) 10);
//        int int17 = dateTime11.getMinuteOfDay();
//        int int18 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime11);
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 811 + "'", int17 == 811);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test231");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        boolean boolean1 = dateTimeFormatterBuilder0.canBuildFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
//        dateTimeFormatterBuilder2.clear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        int int6 = dateTime5.getSecondOfMinute();
//        org.joda.time.DateTime dateTime11 = dateTime5.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime13 = dateTime5.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
//        org.joda.time.DateTime dateTime17 = dateTime15.withHourOfDay(0);
//        int int18 = dateTime15.getDayOfMonth();
//        boolean boolean19 = dateTime13.isBefore((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        boolean boolean21 = dateTimeFormatter20.isPrinter();
//        java.lang.String str22 = dateTime15.toString(dateTimeFormatter20);
//        java.util.Locale locale23 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter20.withLocale(locale23);
//        org.joda.time.format.DateTimePrinter dateTimePrinter25 = dateTimeFormatter24.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatter26.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter25, dateTimeParser27);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.appendClockhourOfHalfday(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder29.appendCenturyOfEra(0, 2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder29.appendClockhourOfDay(9);
//        org.joda.time.format.DateTimeParser dateTimeParser37 = dateTimeFormatterBuilder29.toParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder38.appendClockhourOfHalfday(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder38.appendCenturyOfEra(0, 2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder38.appendClockhourOfDay(9);
//        org.joda.time.format.DateTimeParser dateTimeParser46 = dateTimeFormatterBuilder38.toParser();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray47 = new org.joda.time.format.DateTimeParser[] { dateTimeParser37, dateTimeParser46 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder2.append(dateTimePrinter25, dateTimeParserArray47);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone50);
//        org.joda.time.DurationField durationField52 = iSOChronology51.halfdays();
//        org.joda.time.DateTimeField dateTimeField53 = iSOChronology51.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType54 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField55 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField53, dateTimeFieldType54);
//        java.util.Locale locale56 = null;
//        int int57 = delegatedDateTimeField55.getMaximumTextLength(locale56);
//        org.joda.time.DateTimeFieldType dateTimeFieldType58 = delegatedDateTimeField55.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder49.appendText(dateTimeFieldType58);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder49.appendSecondOfMinute((int) (byte) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = new org.joda.time.format.DateTimeFormatterBuilder();
//        boolean boolean63 = dateTimeFormatterBuilder62.canBuildFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone65 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology66 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone65);
//        org.joda.time.DurationField durationField67 = iSOChronology66.halfdays();
//        org.joda.time.DateTimeField dateTimeField68 = iSOChronology66.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType69 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField70 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField68, dateTimeFieldType69);
//        java.util.Locale locale71 = null;
//        int int72 = delegatedDateTimeField70.getMaximumTextLength(locale71);
//        org.joda.time.DateTimeFieldType dateTimeFieldType73 = delegatedDateTimeField70.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder74 = dateTimeFormatterBuilder64.appendText(dateTimeFieldType73);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder75 = dateTimeFormatterBuilder62.appendText(dateTimeFieldType73);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder77 = dateTimeFormatterBuilder49.appendFixedSignedDecimal(dateTimeFieldType73, (int) (byte) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder78 = dateTimeFormatterBuilder48.appendShortText(dateTimeFieldType73);
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType73, 4, 0, (-6));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 4 for minuteOfHour must be in the range [0,-6]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 48 + "'", int6 == 48);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "20" + "'", str22.equals("20"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertNotNull(dateTimePrinter25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(dateTimeParser27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertNotNull(dateTimeParser37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(dateTimeParser46);
//        org.junit.Assert.assertNotNull(dateTimeParserArray47);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertNotNull(iSOChronology51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2 + "'", int57 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType58);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone65);
//        org.junit.Assert.assertNotNull(iSOChronology66);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertNotNull(dateTimeField68);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2 + "'", int72 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType73);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder74);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder75);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder77);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder78);
//    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test232");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        int int3 = dateTime2.getSecondOfMinute();
//        org.joda.time.DateTime dateTime8 = dateTime2.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime10 = dateTime2.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime12 = dateTime10.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime12);
//        try {
//            long long21 = gJChronology13.getDateTimeMillis(0, 19, 31, 53, 48665042, 195, 8);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 53 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 49 + "'", int3 == 49);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(gJChronology13);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(26009731, 39, 28, 0, (-46), 56, (-1104), dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -46 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test234");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.era();
//        java.lang.Class<?> wildcardClass3 = iSOChronology1.getClass();
//        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DurationField durationField5 = iSOChronology1.millis();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        int int8 = dateTime7.getSecondOfMinute();
//        org.joda.time.DateTime dateTime13 = dateTime7.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime15 = dateTime13.plusYears((-1));
//        java.lang.String str16 = dateTime15.toString();
//        java.lang.String str17 = dateTime15.toString();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
//        org.joda.time.DurationField durationField20 = iSOChronology19.halfdays();
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology19.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
//        int int24 = dateTime23.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone25 = dateTime23.getZone();
//        org.joda.time.Chronology chronology26 = iSOChronology19.withZone(dateTimeZone25);
//        org.joda.time.DateTime dateTime27 = dateTime15.toDateTime(dateTimeZone25);
//        org.joda.time.DateTime dateTime29 = dateTime27.minusWeeks((int) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
//        org.joda.time.DateTime dateTime33 = dateTime31.withHourOfDay(0);
//        org.joda.time.DateTime dateTime34 = dateTime33.withEarlierOffsetAtOverlap();
//        boolean boolean35 = dateTime27.isAfter((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone36);
//        org.joda.time.MonthDay monthDay38 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = null;
//        boolean boolean40 = monthDay38.isSupported(dateTimeFieldType39);
//        org.joda.time.MonthDay monthDay42 = monthDay38.withDayOfMonth(15);
//        org.joda.time.DateTime dateTime43 = dateTime34.withFields((org.joda.time.ReadablePartial) monthDay38);
//        org.joda.time.DateTime dateTime45 = dateTime43.plusWeeks(22);
//        org.joda.time.ReadableDateTime readableDateTime46 = null;
//        org.joda.time.chrono.LimitChronology limitChronology47 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.ReadableDateTime) dateTime43, readableDateTime46);
//        org.joda.time.DateTime dateTime48 = limitChronology47.getLowerLimit();
//        try {
//            long long53 = limitChronology47.getDateTimeMillis(5, 43, 0, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 43 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 49 + "'", int8 == 49);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2018-06-15T10:13:15.013-07:00" + "'", str16.equals("2018-06-15T10:13:15.013-07:00"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2018-06-15T10:13:15.013-07:00" + "'", str17.equals("2018-06-15T10:13:15.013-07:00"));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 49 + "'", int24 == 49);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(iSOChronology37);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(monthDay42);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(limitChronology47);
//        org.junit.Assert.assertNotNull(dateTime48);
//    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test235");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        int int4 = dateTime3.getSecondOfMinute();
//        org.joda.time.DateTime dateTime9 = dateTime3.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime11 = dateTime3.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime13);
//        int int16 = gJChronology15.getMinimumDaysInFirstWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        org.joda.time.Chronology chronology18 = dateTimeFormatter17.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTimeFormatter17.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology15, dateTimeZone19);
//        long long26 = zonedChronology20.getDateTimeMillis(1560630623999L, (int) (short) 0, 0, 12, 3);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone29);
//        int int31 = dateTime30.getSecondOfMinute();
//        org.joda.time.DateTime dateTime36 = dateTime30.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime38 = dateTime30.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime40 = dateTime38.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone28, (org.joda.time.ReadableInstant) dateTime40);
//        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone27, (org.joda.time.ReadableInstant) dateTime40);
//        int int43 = gJChronology42.getMinimumDaysInFirstWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        org.joda.time.Chronology chronology45 = dateTimeFormatter44.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone46 = dateTimeFormatter44.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology47 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology42, dateTimeZone46);
//        org.joda.time.Chronology chronology48 = zonedChronology20.withZone(dateTimeZone46);
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeUtils.getZone(dateTimeZone46);
//        org.joda.time.chrono.ISOChronology iSOChronology50 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone46);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 49 + "'", int4 == 49);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNull(chronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(zonedChronology20);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560556812003L + "'", long26 == 1560556812003L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 49 + "'", int31 == 49);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(gJChronology41);
//        org.junit.Assert.assertNotNull(gJChronology42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 4 + "'", int43 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter44);
//        org.junit.Assert.assertNull(chronology45);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertNotNull(zonedChronology47);
//        org.junit.Assert.assertNotNull(chronology48);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertNotNull(iSOChronology50);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((-86L));
        org.joda.time.Instant instant2 = instant1.toInstant();
        long long3 = instant1.getMillis();
        org.joda.time.Instant instant5 = instant1.plus(720015L);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Instant instant7 = instant5.minus(readableDuration6);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.Instant instant9 = instant5.plus(readableDuration8);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-86L) + "'", long3 == (-86L));
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant9);
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test237");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        int int4 = dateTime3.getSecondOfMinute();
//        org.joda.time.DateTime dateTime9 = dateTime3.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime11 = dateTime3.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime13);
//        int int16 = gJChronology15.getMinimumDaysInFirstWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        org.joda.time.Chronology chronology18 = dateTimeFormatter17.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTimeFormatter17.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology15, dateTimeZone19);
//        long long26 = zonedChronology20.getDateTimeMillis(1560630623999L, (int) (short) 0, 0, 12, 3);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone29);
//        int int31 = dateTime30.getSecondOfMinute();
//        org.joda.time.DateTime dateTime36 = dateTime30.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime38 = dateTime30.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime40 = dateTime38.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone28, (org.joda.time.ReadableInstant) dateTime40);
//        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone27, (org.joda.time.ReadableInstant) dateTime40);
//        int int43 = gJChronology42.getMinimumDaysInFirstWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        org.joda.time.Chronology chronology45 = dateTimeFormatter44.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone46 = dateTimeFormatter44.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology47 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology42, dateTimeZone46);
//        org.joda.time.Chronology chronology48 = zonedChronology20.withZone(dateTimeZone46);
//        try {
//            org.joda.time.chrono.CopticChronology copticChronology50 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone46, 810);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 810");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 49 + "'", int4 == 49);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNull(chronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(zonedChronology20);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560556812003L + "'", long26 == 1560556812003L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 49 + "'", int31 == 49);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(gJChronology41);
//        org.junit.Assert.assertNotNull(gJChronology42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 4 + "'", int43 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter44);
//        org.junit.Assert.assertNull(chronology45);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertNotNull(zonedChronology47);
//        org.junit.Assert.assertNotNull(chronology48);
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
        org.joda.time.DateTime dateTime4 = dateTime3.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((-1L));
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.plus(readableDuration7);
        org.joda.time.DateTime.Property property9 = dateTime8.dayOfMonth();
        int int10 = property9.getMinimumValueOverall();
        org.joda.time.DateTime dateTime11 = property9.roundCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.era();
        java.lang.Class<?> wildcardClass3 = iSOChronology1.getClass();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 20);
        org.joda.time.DateTimeField dateTimeField7 = offsetDateTimeField6.getWrappedField();
        org.joda.time.DurationField durationField8 = offsetDateTimeField6.getDurationField();
        long long10 = offsetDateTimeField6.roundHalfEven((long) 25);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.era();
        java.lang.Class<?> wildcardClass3 = iSOChronology1.getClass();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 20);
        long long8 = offsetDateTimeField6.roundCeiling((long) 12);
        java.lang.String str10 = offsetDateTimeField6.getAsText((long) 48627451);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 86400000L + "'", long8 == 86400000L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "21" + "'", str10.equals("21"));
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test241");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTime dateTime7 = dateTime1.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime9 = dateTime7.plusYears((-1));
//        java.lang.String str10 = dateTime9.toString();
//        java.lang.String str11 = dateTime9.toString();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
//        org.joda.time.DurationField durationField14 = iSOChronology13.halfdays();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        int int18 = dateTime17.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTime17.getZone();
//        org.joda.time.Chronology chronology20 = iSOChronology13.withZone(dateTimeZone19);
//        org.joda.time.DateTime dateTime21 = dateTime9.toDateTime(dateTimeZone19);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusWeeks((int) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(dateTimeZone24);
//        org.joda.time.DateTime dateTime27 = dateTime25.withHourOfDay(0);
//        org.joda.time.DateTime dateTime28 = dateTime27.withEarlierOffsetAtOverlap();
//        boolean boolean29 = dateTime21.isAfter((org.joda.time.ReadableInstant) dateTime28);
//        org.joda.time.DateTime.Property property30 = dateTime28.centuryOfEra();
//        int int31 = property30.getMinimumValueOverall();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49 + "'", int2 == 49);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2018-06-15T10:13:15.013-07:00" + "'", str10.equals("2018-06-15T10:13:15.013-07:00"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2018-06-15T10:13:15.013-07:00" + "'", str11.equals("2018-06-15T10:13:15.013-07:00"));
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 49 + "'", int18 == 49);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test242");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTime dateTime7 = dateTime1.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime9 = dateTime7.plusYears((-1));
//        java.lang.String str10 = dateTime9.toString();
//        java.lang.String str11 = dateTime9.toString();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
//        org.joda.time.DurationField durationField14 = iSOChronology13.halfdays();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        int int18 = dateTime17.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTime17.getZone();
//        org.joda.time.Chronology chronology20 = iSOChronology13.withZone(dateTimeZone19);
//        org.joda.time.DateTime dateTime21 = dateTime9.toDateTime(dateTimeZone19);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusWeeks((int) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(dateTimeZone24);
//        org.joda.time.DateTime dateTime27 = dateTime25.withHourOfDay(0);
//        org.joda.time.DateTime dateTime28 = dateTime27.withEarlierOffsetAtOverlap();
//        boolean boolean29 = dateTime21.isAfter((org.joda.time.ReadableInstant) dateTime28);
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
//        org.joda.time.MonthDay monthDay32 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology31);
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = null;
//        boolean boolean34 = monthDay32.isSupported(dateTimeFieldType33);
//        org.joda.time.MonthDay monthDay36 = monthDay32.withDayOfMonth(15);
//        org.joda.time.DateTime dateTime37 = dateTime28.withFields((org.joda.time.ReadablePartial) monthDay32);
//        org.joda.time.DateTime.Property property38 = dateTime37.monthOfYear();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50 + "'", int2 == 50);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2018-06-15T10:13:15.013-07:00" + "'", str10.equals("2018-06-15T10:13:15.013-07:00"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2018-06-15T10:13:15.013-07:00" + "'", str11.equals("2018-06-15T10:13:15.013-07:00"));
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 50 + "'", int18 == 50);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(monthDay36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(property38);
//    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test243");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        int int4 = dateTime3.getSecondOfMinute();
//        org.joda.time.DateTime dateTime9 = dateTime3.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime11 = dateTime3.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime13);
//        int int16 = gJChronology15.getMinimumDaysInFirstWeek();
//        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = copticChronology17.clockhourOfDay();
//        org.joda.time.DurationField durationField19 = copticChronology17.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
//        org.joda.time.DurationField durationField22 = iSOChronology21.halfdays();
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology21.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(dateTimeZone24);
//        int int26 = dateTime25.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone27 = dateTime25.getZone();
//        org.joda.time.Chronology chronology28 = iSOChronology21.withZone(dateTimeZone27);
//        java.lang.String str29 = dateTimeZone27.getID();
//        org.joda.time.Chronology chronology30 = copticChronology17.withZone(dateTimeZone27);
//        org.joda.time.Chronology chronology31 = gJChronology15.withZone(dateTimeZone27);
//        org.joda.time.DateTimeField dateTimeField32 = gJChronology15.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone33 = gJChronology15.getZone();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 50 + "'", int4 == 50);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
//        org.junit.Assert.assertNotNull(copticChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 50 + "'", int26 == 50);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "America/Los_Angeles" + "'", str29.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(chronology30);
//        org.junit.Assert.assertNotNull(chronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildFormatter();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(17, false);
        boolean boolean4 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(2000, true);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap8);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter11 = dateTimeFormatter10.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser12 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.append(dateTimePrinter11, dateTimeParser12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimePrinter11);
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test246");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        int int6 = dateTime5.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime5.getZone();
//        org.joda.time.Chronology chronology8 = iSOChronology1.withZone(dateTimeZone7);
//        java.lang.String str10 = dateTimeZone7.getName((long) 2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        long long15 = cachedDateTimeZone12.convertLocalToUTC((long) (byte) 100, false);
//        java.lang.Object obj16 = null;
//        boolean boolean17 = cachedDateTimeZone12.equals(obj16);
//        int int19 = cachedDateTimeZone12.getOffset((long) 22);
//        int int21 = cachedDateTimeZone12.getOffset(12L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 50 + "'", int6 == 50);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Pacific Standard Time" + "'", str10.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800100L + "'", long15 == 28800100L);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-28800000) + "'", int19 == (-28800000));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-28800000) + "'", int21 == (-28800000));
//    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test247");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone0.getName((long) (-6), locale3);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test248");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = iSOChronology4.halfdays();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        int int9 = dateTime8.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
//        org.joda.time.Chronology chronology11 = iSOChronology4.withZone(dateTimeZone10);
//        java.lang.String str12 = dateTimeZone10.getID();
//        org.joda.time.Chronology chronology13 = gregorianChronology1.withZone(dateTimeZone10);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology1.millisOfDay();
//        java.lang.String str15 = gregorianChronology1.toString();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
//        org.joda.time.DurationField durationField18 = iSOChronology17.halfdays();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
//        int int22 = dateTime21.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone23 = dateTime21.getZone();
//        org.joda.time.Chronology chronology24 = iSOChronology17.withZone(dateTimeZone23);
//        java.lang.String str26 = dateTimeZone23.getName((long) 2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23);
//        boolean boolean28 = gregorianChronology1.equals((java.lang.Object) gregorianChronology27);
//        java.lang.Object obj29 = null;
//        boolean boolean30 = gregorianChronology1.equals(obj29);
//        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology1.minuteOfDay();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 50 + "'", int9 == 50);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "America/Los_Angeles" + "'", str12.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str15.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 50 + "'", int22 == 50);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Pacific Standard Time" + "'", str26.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test249");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTime dateTime7 = dateTime1.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.era();
//        org.joda.time.DateTime dateTime11 = dateTime1.toDateTime((org.joda.time.Chronology) iSOChronology9);
//        org.joda.time.DateTime dateTime13 = dateTime1.minusMinutes(57600);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50 + "'", int2 == 50);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test250");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
//        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
//        int int5 = property4.getMaximumValue();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        int int8 = dateTime7.getSecondOfMinute();
//        org.joda.time.DateTime dateTime13 = dateTime7.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.ReadableDuration readableDuration14 = null;
//        org.joda.time.DateTime dateTime16 = dateTime7.withDurationAdded(readableDuration14, 14);
//        boolean boolean17 = dateTime7.isAfterNow();
//        int int18 = property4.compareTo((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime19 = property4.getDateTime();
//        org.joda.time.DateTime dateTime20 = property4.roundCeilingCopy();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 50 + "'", int8 == 50);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        boolean boolean2 = buddhistChronology0.equals((java.lang.Object) 32);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test252");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.DateTime dateTime7 = dateTime5.withHourOfDay(0);
//        org.joda.time.DateTime.Property property8 = dateTime7.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        boolean boolean13 = monthDay11.isSupported(dateTimeFieldType12);
//        int int14 = property8.compareTo((org.joda.time.ReadablePartial) monthDay11);
//        long long16 = iSOChronology1.set((org.joda.time.ReadablePartial) monthDay11, (long) 13);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray17 = monthDay11.getFieldTypes();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 14256000013L + "'", long16 == 14256000013L);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray17);
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test254");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        int int6 = dateTime5.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime5.getZone();
//        org.joda.time.Chronology chronology8 = iSOChronology1.withZone(dateTimeZone7);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
//        org.joda.time.Chronology chronology10 = buddhistChronology9.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(74);
//        org.joda.time.Chronology chronology13 = buddhistChronology9.withZone(dateTimeZone12);
//        java.lang.String str15 = dateTimeZone12.getShortName((-15L));
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 51 + "'", int6 == 51);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.074" + "'", str15.equals("+00:00:00.074"));
//    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test255");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        int int6 = dateTime5.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime5.getZone();
//        org.joda.time.Chronology chronology8 = iSOChronology1.withZone(dateTimeZone7);
//        java.lang.String str10 = dateTimeZone7.getName((long) 2);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
//        int int13 = dateTimeZone7.getOffsetFromLocal(48466L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 51 + "'", int6 == 51);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Pacific Standard Time" + "'", str10.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(buddhistChronology11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-28800000) + "'", int13 == (-28800000));
//    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test256");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
//        int int4 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusDays((int) (byte) 10);
//        org.joda.time.DateTime.Property property7 = dateTime6.millisOfSecond();
//        org.joda.time.DateTime dateTime8 = property7.withMaximumValue();
//        org.joda.time.DateTime dateTime10 = property7.addToCopy((long) (short) 0);
//        org.joda.time.DateTime dateTime12 = dateTime10.plusMonths(2000);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.DurationField durationField15 = iSOChronology14.halfdays();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
//        int int19 = dateTime18.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone20 = dateTime18.getZone();
//        org.joda.time.Chronology chronology21 = iSOChronology14.withZone(dateTimeZone20);
//        java.lang.String str22 = dateTimeZone20.getID();
//        org.joda.time.DateTime dateTime23 = dateTime12.toDateTime(dateTimeZone20);
//        org.joda.time.MutableDateTime mutableDateTime24 = dateTime12.toMutableDateTimeISO();
//        org.joda.time.DateTime.Property property25 = dateTime12.secondOfMinute();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 51 + "'", int19 == 51);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "America/Los_Angeles" + "'", str22.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertNotNull(property25);
//    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test257");
//        org.joda.time.Instant instant1 = new org.joda.time.Instant((-86L));
//        org.joda.time.Instant instant2 = instant1.toInstant();
//        org.joda.time.Instant instant5 = instant1.withDurationAdded((long) 0, 0);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.DateTime dateTime9 = dateTime7.withHourOfDay(0);
//        int int10 = dateTime7.getDayOfMonth();
//        org.joda.time.DateTime dateTime12 = dateTime7.plusDays((int) (byte) 10);
//        org.joda.time.DateTime.Property property13 = dateTime12.millisOfSecond();
//        org.joda.time.DateTime dateTime14 = property13.withMaximumValue();
//        java.util.Locale locale15 = null;
//        int int16 = property13.getMaximumShortTextLength(locale15);
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property13.getFieldType();
//        int int18 = instant1.get(dateTimeFieldType17);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 914 + "'", int18 == 914);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.plus(readableDuration1);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test260");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        int int4 = dateTime3.getSecondOfMinute();
//        org.joda.time.DateTime dateTime9 = dateTime3.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime11 = dateTime3.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime13);
//        int int16 = gJChronology15.getMinimumDaysInFirstWeek();
//        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = copticChronology17.clockhourOfDay();
//        org.joda.time.DurationField durationField19 = copticChronology17.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
//        org.joda.time.DurationField durationField22 = iSOChronology21.halfdays();
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology21.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(dateTimeZone24);
//        int int26 = dateTime25.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone27 = dateTime25.getZone();
//        org.joda.time.Chronology chronology28 = iSOChronology21.withZone(dateTimeZone27);
//        java.lang.String str29 = dateTimeZone27.getID();
//        org.joda.time.Chronology chronology30 = copticChronology17.withZone(dateTimeZone27);
//        org.joda.time.Chronology chronology31 = gJChronology15.withZone(dateTimeZone27);
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
//        org.joda.time.DurationField durationField34 = iSOChronology33.halfdays();
//        org.joda.time.DateTimeField dateTimeField35 = iSOChronology33.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField35, dateTimeFieldType36);
//        java.util.Locale locale38 = null;
//        int int39 = delegatedDateTimeField37.getMaximumTextLength(locale38);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = delegatedDateTimeField37.getType();
//        org.joda.time.MonthDay monthDay41 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeField[] dateTimeFieldArray42 = monthDay41.getFields();
//        java.util.Locale locale44 = null;
//        java.lang.String str45 = delegatedDateTimeField37.getAsText((org.joda.time.ReadablePartial) monthDay41, (-1), locale44);
//        long long48 = delegatedDateTimeField37.addWrapField((long) 15, 12);
//        long long50 = delegatedDateTimeField37.roundHalfCeiling(0L);
//        java.util.Locale locale52 = null;
//        java.lang.String str53 = delegatedDateTimeField37.getAsShortText(10, locale52);
//        long long56 = delegatedDateTimeField37.add((long) '#', (long) 41);
//        boolean boolean58 = delegatedDateTimeField37.isLeap((long) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField60 = new org.joda.time.field.SkipUndoDateTimeField(chronology31, (org.joda.time.DateTimeField) delegatedDateTimeField37, 13);
//        boolean boolean61 = delegatedDateTimeField37.isLenient();
//        java.lang.String str62 = delegatedDateTimeField37.toString();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 51 + "'", int4 == 51);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
//        org.junit.Assert.assertNotNull(copticChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 51 + "'", int26 == 51);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "America/Los_Angeles" + "'", str29.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(chronology30);
//        org.junit.Assert.assertNotNull(chronology31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(iSOChronology33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertNotNull(monthDay41);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray42);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "-1" + "'", str45.equals("-1"));
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 720015L + "'", long48 == 720015L);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "10" + "'", str53.equals("10"));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 2460035L + "'", long56 == 2460035L);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str62.equals("DateTimeField[minuteOfHour]"));
//    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        boolean boolean4 = monthDay2.isSupported(dateTimeFieldType3);
        org.joda.time.MonthDay monthDay6 = monthDay2.withDayOfMonth(15);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay8 = monthDay6.plus(readablePeriod7);
        org.joda.time.MonthDay.Property property9 = monthDay8.dayOfMonth();
        org.joda.time.MonthDay monthDay11 = property9.setCopy("1");
        java.lang.Object obj12 = null;
        boolean boolean13 = property9.equals(obj12);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.halfdays();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType5);
        java.util.Locale locale7 = null;
        int int8 = delegatedDateTimeField6.getMaximumTextLength(locale7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = delegatedDateTimeField6.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType9);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (int) (byte) -1, 43);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.era();
        java.lang.Class<?> wildcardClass18 = iSOChronology16.getClass();
        org.joda.time.DurationField durationField19 = iSOChronology16.seconds();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.DurationField durationField22 = iSOChronology21.halfdays();
        org.joda.time.DurationField durationField23 = iSOChronology21.halfdays();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField24 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType9, durationField19, durationField23);
        boolean boolean25 = preciseDateTimeField24.isLenient();
        int int26 = preciseDateTimeField24.getMaximumValue();
        int int28 = preciseDateTimeField24.getMinimumValue((long) 2);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 43199 + "'", int26 == 43199);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test263");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.era();
//        java.lang.Class<?> wildcardClass3 = iSOChronology1.getClass();
//        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DurationField durationField5 = iSOChronology1.millis();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        int int8 = dateTime7.getSecondOfMinute();
//        org.joda.time.DateTime dateTime13 = dateTime7.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime15 = dateTime13.plusYears((-1));
//        java.lang.String str16 = dateTime15.toString();
//        java.lang.String str17 = dateTime15.toString();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
//        org.joda.time.DurationField durationField20 = iSOChronology19.halfdays();
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology19.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
//        int int24 = dateTime23.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone25 = dateTime23.getZone();
//        org.joda.time.Chronology chronology26 = iSOChronology19.withZone(dateTimeZone25);
//        org.joda.time.DateTime dateTime27 = dateTime15.toDateTime(dateTimeZone25);
//        org.joda.time.DateTime dateTime29 = dateTime27.minusWeeks((int) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
//        org.joda.time.DateTime dateTime33 = dateTime31.withHourOfDay(0);
//        org.joda.time.DateTime dateTime34 = dateTime33.withEarlierOffsetAtOverlap();
//        boolean boolean35 = dateTime27.isAfter((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone36);
//        org.joda.time.MonthDay monthDay38 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = null;
//        boolean boolean40 = monthDay38.isSupported(dateTimeFieldType39);
//        org.joda.time.MonthDay monthDay42 = monthDay38.withDayOfMonth(15);
//        org.joda.time.DateTime dateTime43 = dateTime34.withFields((org.joda.time.ReadablePartial) monthDay38);
//        org.joda.time.DateTime dateTime45 = dateTime43.plusWeeks(22);
//        org.joda.time.ReadableDateTime readableDateTime46 = null;
//        org.joda.time.chrono.LimitChronology limitChronology47 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.ReadableDateTime) dateTime43, readableDateTime46);
//        org.joda.time.DateTime dateTime48 = limitChronology47.getLowerLimit();
//        org.joda.time.DateTime dateTime49 = limitChronology47.getUpperLimit();
//        org.joda.time.DateTime dateTime50 = limitChronology47.getUpperLimit();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 51 + "'", int8 == 51);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2018-06-15T10:13:15.013-07:00" + "'", str16.equals("2018-06-15T10:13:15.013-07:00"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2018-06-15T10:13:15.013-07:00" + "'", str17.equals("2018-06-15T10:13:15.013-07:00"));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 51 + "'", int24 == 51);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(iSOChronology37);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(monthDay42);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(limitChronology47);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNull(dateTime49);
//        org.junit.Assert.assertNull(dateTime50);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(0);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(chronology4);
        int int6 = dateTime5.getYear();
        org.joda.time.LocalTime localTime7 = dateTime5.toLocalTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        boolean boolean9 = dateTime5.isSupported(dateTimeFieldType8);
        org.joda.time.DateTime dateTime10 = dateTime5.toDateTime();
        int int11 = dateTime10.getWeekyear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(localTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test265");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime1.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone4);
//        org.joda.time.TimeOfDay timeOfDay6 = dateTime1.toTimeOfDay();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(timeOfDay6);
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.era();
        java.lang.Class<?> wildcardClass3 = iSOChronology1.getClass();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.dayOfMonth();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 20);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 1);
        boolean boolean10 = offsetDateTimeField6.isLeap((long) 9);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test267");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTime dateTime7 = dateTime1.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime9 = dateTime1.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
//        org.joda.time.DateTime dateTime13 = dateTime11.withHourOfDay(0);
//        int int14 = dateTime11.getDayOfMonth();
//        boolean boolean15 = dateTime9.isBefore((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        boolean boolean17 = dateTimeFormatter16.isPrinter();
//        java.lang.String str18 = dateTime11.toString(dateTimeFormatter16);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter16.withPivotYear((java.lang.Integer) 20);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter16.withZoneUTC();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.era();
//        java.lang.Class<?> wildcardClass3 = iSOChronology1.getClass();
//        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        int int9 = dateTime8.getSecondOfMinute();
//        org.joda.time.DateTime dateTime14 = dateTime8.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime16 = dateTime8.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime18 = dateTime16.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) dateTime18);
//        int int21 = gJChronology20.getMinimumDaysInFirstWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        org.joda.time.Chronology chronology23 = dateTimeFormatter22.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone24 = dateTimeFormatter22.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology20, dateTimeZone24);
//        long long31 = zonedChronology25.getDateTimeMillis(1560630623999L, (int) (short) 0, 0, 12, 3);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(dateTimeZone34);
//        int int36 = dateTime35.getSecondOfMinute();
//        org.joda.time.DateTime dateTime41 = dateTime35.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime43 = dateTime35.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime45 = dateTime43.minusYears(1);
//        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone33, (org.joda.time.ReadableInstant) dateTime45);
//        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone32, (org.joda.time.ReadableInstant) dateTime45);
//        int int48 = gJChronology47.getMinimumDaysInFirstWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        org.joda.time.Chronology chronology50 = dateTimeFormatter49.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone51 = dateTimeFormatter49.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology52 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology47, dateTimeZone51);
//        org.joda.time.Chronology chronology53 = zonedChronology25.withZone(dateTimeZone51);
//        org.joda.time.MonthDay monthDay54 = monthDay4.withChronologyRetainFields(chronology53);
//        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone55);
//        org.joda.time.DateTimeField dateTimeField57 = iSOChronology56.era();
//        java.lang.Class<?> wildcardClass58 = iSOChronology56.getClass();
//        org.joda.time.DateTimeField dateTimeField59 = iSOChronology56.dayOfMonth();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField61 = new org.joda.time.field.OffsetDateTimeField(dateTimeField59, 20);
//        long long63 = offsetDateTimeField61.roundHalfEven((long) 1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField61.getType();
//        org.joda.time.MonthDay.Property property65 = monthDay54.property(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(gJChronology20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertNull(chronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(zonedChronology25);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560556812003L + "'", long31 == 1560556812003L);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 52 + "'", int36 == 52);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(gJChronology46);
//        org.junit.Assert.assertNotNull(gJChronology47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 4 + "'", int48 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter49);
//        org.junit.Assert.assertNull(chronology50);
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertNotNull(zonedChronology52);
//        org.junit.Assert.assertNotNull(chronology53);
//        org.junit.Assert.assertNotNull(monthDay54);
//        org.junit.Assert.assertNotNull(dateTimeZone55);
//        org.junit.Assert.assertNotNull(iSOChronology56);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(wildcardClass58);
//        org.junit.Assert.assertNotNull(dateTimeField59);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 0L + "'", long63 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(property65);
//    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test269");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        boolean boolean1 = dateTimeFormatterBuilder0.canBuildFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
//        dateTimeFormatterBuilder2.clear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        int int6 = dateTime5.getSecondOfMinute();
//        org.joda.time.DateTime dateTime11 = dateTime5.withTime((int) (byte) 10, 13, 15, 13);
//        org.joda.time.DateTime dateTime13 = dateTime5.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
//        org.joda.time.DateTime dateTime17 = dateTime15.withHourOfDay(0);
//        int int18 = dateTime15.getDayOfMonth();
//        boolean boolean19 = dateTime13.isBefore((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        boolean boolean21 = dateTimeFormatter20.isPrinter();
//        java.lang.String str22 = dateTime15.toString(dateTimeFormatter20);
//        java.util.Locale locale23 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter20.withLocale(locale23);
//        org.joda.time.format.DateTimePrinter dateTimePrinter25 = dateTimeFormatter24.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatter26.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter25, dateTimeParser27);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.appendClockhourOfHalfday(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder29.appendCenturyOfEra(0, 2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder29.appendClockhourOfDay(9);
//        org.joda.time.format.DateTimeParser dateTimeParser37 = dateTimeFormatterBuilder29.toParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder38.appendClockhourOfHalfday(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder38.appendCenturyOfEra(0, 2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder38.appendClockhourOfDay(9);
//        org.joda.time.format.DateTimeParser dateTimeParser46 = dateTimeFormatterBuilder38.toParser();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray47 = new org.joda.time.format.DateTimeParser[] { dateTimeParser37, dateTimeParser46 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder2.append(dateTimePrinter25, dateTimeParserArray47);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone50);
//        org.joda.time.DurationField durationField52 = iSOChronology51.halfdays();
//        org.joda.time.DateTimeField dateTimeField53 = iSOChronology51.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType54 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField55 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField53, dateTimeFieldType54);
//        java.util.Locale locale56 = null;
//        int int57 = delegatedDateTimeField55.getMaximumTextLength(locale56);
//        org.joda.time.DateTimeFieldType dateTimeFieldType58 = delegatedDateTimeField55.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder49.appendText(dateTimeFieldType58);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder49.appendSecondOfMinute((int) (byte) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = new org.joda.time.format.DateTimeFormatterBuilder();
//        boolean boolean63 = dateTimeFormatterBuilder62.canBuildFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone65 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology66 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone65);
//        org.joda.time.DurationField durationField67 = iSOChronology66.halfdays();
//        org.joda.time.DateTimeField dateTimeField68 = iSOChronology66.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType69 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField70 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField68, dateTimeFieldType69);
//        java.util.Locale locale71 = null;
//        int int72 = delegatedDateTimeField70.getMaximumTextLength(locale71);
//        org.joda.time.DateTimeFieldType dateTimeFieldType73 = delegatedDateTimeField70.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder74 = dateTimeFormatterBuilder64.appendText(dateTimeFieldType73);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder75 = dateTimeFormatterBuilder62.appendText(dateTimeFieldType73);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder77 = dateTimeFormatterBuilder49.appendFixedSignedDecimal(dateTimeFieldType73, (int) (byte) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder78 = dateTimeFormatterBuilder48.appendShortText(dateTimeFieldType73);
//        org.joda.time.DateTimeZone dateTimeZone79 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ISOChronology iSOChronology80 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone79);
//        org.joda.time.DateTimeField dateTimeField81 = iSOChronology80.era();
//        java.lang.Class<?> wildcardClass82 = iSOChronology80.getClass();
//        org.joda.time.MonthDay monthDay83 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology80);
//        org.joda.time.DurationField durationField84 = iSOChronology80.days();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField85 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType73, durationField84);
//        org.joda.time.DurationField durationField86 = unsupportedDateTimeField85.getLeapDurationField();
//        boolean boolean87 = unsupportedDateTimeField85.isSupported();
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "20" + "'", str22.equals("20"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertNotNull(dateTimePrinter25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(dateTimeParser27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertNotNull(dateTimeParser37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(dateTimeParser46);
//        org.junit.Assert.assertNotNull(dateTimeParserArray47);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertNotNull(iSOChronology51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2 + "'", int57 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType58);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone65);
//        org.junit.Assert.assertNotNull(iSOChronology66);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertNotNull(dateTimeField68);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2 + "'", int72 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType73);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder74);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder75);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder77);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder78);
//        org.junit.Assert.assertNotNull(dateTimeZone79);
//        org.junit.Assert.assertNotNull(iSOChronology80);
//        org.junit.Assert.assertNotNull(dateTimeField81);
//        org.junit.Assert.assertNotNull(wildcardClass82);
//        org.junit.Assert.assertNotNull(durationField84);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField85);
//        org.junit.Assert.assertNull(durationField86);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//    }
//}

