import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 100, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 101L + "'", long2 == 101L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, (int) (byte) 0, (int) (byte) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("", 0, (int) '#', (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for  must be in the range [35,32]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("T16:00:00.000-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'T16:00:00.000-08:00' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        java.util.TimeZone timeZone1 = dateTimeZone0.toTimeZone();
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (-1), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology2 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, dateTimeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test014");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560636316530L + "'", long0 == 1560636316530L);
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 100.0f, "UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test018");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.lang.String str2 = dateTimeFormatter0.print(0L);
//        java.lang.Appendable appendable3 = null;
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(chronology4);
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.withPeriodAdded(readablePeriod6, (int) (byte) 100);
//        org.joda.time.DateTime dateTime10 = dateTime5.minusMinutes(0);
//        try {
//            dateTimeFormatter0.printTo(appendable3, (org.joda.time.ReadableInstant) dateTime5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "T16:00:00.000-08:00" + "'", str2.equals("T16:00:00.000-08:00"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) (short) 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("T16:00:00.000-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"T16:00:00.000-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
        org.joda.time.DateMidnight dateMidnight7 = dateTime6.toDateMidnight();
        int int8 = dateMidnight7.getMillisOfSecond();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateMidnight7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        boolean boolean2 = dateTimeFormatter0.isParser();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dateTimeZone3);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            java.lang.String str2 = dateTimeFormatter0.print(readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test024");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.lang.String str2 = dateTimeFormatter0.print(0L);
//        try {
//            org.joda.time.LocalTime localTime4 = dateTimeFormatter0.parseLocalTime("UTC");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UTC\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "T16:00:00.000-08:00" + "'", str2.equals("T16:00:00.000-08:00"));
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UTC\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField3 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, dateTimeFieldType1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimePrinter3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "T16:00:00.000-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(0L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        boolean boolean2 = dateTimeFormatter0.isParser();
        try {
            org.joda.time.LocalDateTime localDateTime4 = dateTimeFormatter0.parseLocalDateTime("Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Coordinated Universal Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        boolean boolean2 = dateTimeFormatter0.isParser();
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter0.printTo(appendable3, (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendDecimal(dateTimeFieldType3, (int) '#', 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (byte) 10, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(0, 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendHalfdayOfDayText();
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendTimeZoneShortName();
        org.joda.time.format.DateTimeParser dateTimeParser10 = dateTimeFormatterBuilder9.toParser();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder2.append(dateTimePrinter5, dateTimeParser10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeParser10);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test045");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readablePeriod8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfMonth();
//        boolean boolean12 = dateTime9.equals((java.lang.Object) (byte) 0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear(10);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendFixedSignedDecimal(dateTimeFieldType6, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 10.0d, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfEra((int) '#', (int) (short) 1);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYearOfCentury((int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 0, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) 100, (int) (short) 100, 0, (int) 'a', (int) (byte) 0, 3, 15, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
        org.joda.time.DateMidnight dateMidnight7 = dateTime6.toDateMidnight();
        org.joda.time.DateTime dateTime9 = dateTime6.minusHours(10);
        java.util.Locale locale11 = null;
        try {
            java.lang.String str12 = dateTime9.toString("", locale11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateMidnight7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withPeriodAdded(readablePeriod3, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(readableDuration6, (int) (short) 100);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(chronology9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.withPeriodAdded(readablePeriod11, (int) (byte) 100);
        org.joda.time.DateTime dateTime15 = dateTime10.minusMinutes(0);
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime5, (org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now(chronology16);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter0.withChronology(chronology16);
        try {
            org.joda.time.LocalDateTime localDateTime20 = dateTimeFormatter0.parseLocalDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.withPeriodAdded(readablePeriod10, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.withDurationAdded(readableDuration13, (int) (short) 100);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (byte) 100);
        org.joda.time.DateTime dateTime22 = dateTime17.minusMinutes(0);
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime12, (org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now(chronology23);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter7.withChronology(chronology23);
        try {
            org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(0, (int) (short) -1, 0, (int) (byte) 10, (int) (byte) 0, 2, (-1), chronology23);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime8 = dateTime4.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = dateTime4.minusMillis((int) (byte) 10);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime12 = dateTime4.plus(readableDuration11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        try {
            org.joda.time.DateTime dateTime15 = dateTime4.withField(dateTimeFieldType13, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (byte) 1);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test059");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis((int) 'a');
//        org.joda.time.DateTime.Property property7 = dateTime6.dayOfWeek();
//        java.lang.String str8 = property7.getAsString();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "6" + "'", str8.equals("6"));
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        java.lang.Appendable appendable2 = null;
        try {
            dateTimeFormatter0.printTo(appendable2, (long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test061");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.lang.String str3 = dateTimeFormatter1.print(0L);
//        try {
//            org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("6", dateTimeFormatter1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"6\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T16:00:00.000-08:00" + "'", str3.equals("T16:00:00.000-08:00"));
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, chronology1);
        try {
            org.joda.time.DateTime dateTime4 = dateTime2.withDayOfMonth((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,28]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test063");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test064");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.DateTime.Property property6 = dateTime1.millisOfSecond();
//        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime12 = dateTime9.withPeriodAdded(readablePeriod10, (int) (byte) 100);
//        int int13 = dateTime9.getHourOfDay();
//        org.joda.time.Chronology chronology14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) dateTime9, chronology14);
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime15.minus(readablePeriod16);
//        long long18 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        try {
//            org.joda.time.DateTime dateTime20 = dateTime15.withWeekOfWeekyear(0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-2L) + "'", long18 == (-2L));
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (short) 0, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder0.clear();
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.withPeriodAdded(readablePeriod9, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded(readableDuration12, (int) (short) 100);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) (byte) 100);
        org.joda.time.DateTime dateTime21 = dateTime16.minusMinutes(0);
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime11, (org.joda.time.ReadableInstant) dateTime21);
        try {
            org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((int) (byte) 100, (-1), 3, (int) 'a', (int) (byte) 0, (int) (short) 10, (int) (byte) 10, chronology22);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(chronology22);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test070");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.lang.String str2 = dateTimeFormatter0.print(0L);
//        java.lang.StringBuffer stringBuffer3 = null;
//        try {
//            dateTimeFormatter0.printTo(stringBuffer3, (long) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "T16:00:00.000-08:00" + "'", str2.equals("T16:00:00.000-08:00"));
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(readableDuration5, (int) (short) 100);
        int int8 = dateTime7.getWeekyear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("2019-06-15T05:05:22.051-07:00", 1, (int) (byte) 10, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for 2019-06-15T05:05:22.051-07:00 must be in the range [10,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test073");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readablePeriod8);
//        org.joda.time.DateTime.Property property10 = dateTime7.dayOfYear();
//        org.joda.time.DateTime dateTime11 = property10.roundCeilingCopy();
//        java.util.Locale locale13 = null;
//        try {
//            org.joda.time.DateTime dateTime14 = property10.setCopy("UTC", locale13);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"UTC\" for dayOfYear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) ' ', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfEra((int) '#', (int) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendFixedSignedDecimal(dateTimeFieldType5, 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test076");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
//        java.lang.Appendable appendable3 = null;
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(chronology4);
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.withPeriodAdded(readablePeriod6, (int) (byte) 100);
//        org.joda.time.DateTime dateTime10 = dateTime5.minusMinutes(0);
//        org.joda.time.DateTime dateTime12 = dateTime5.withYearOfEra(10);
//        long long13 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DateTime dateTime14 = dateTime12.withLaterOffsetAtOverlap();
//        try {
//            dateTimeFormatter0.printTo(appendable3, (org.joda.time.ReadableInstant) dateTime12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61837261299050L) + "'", long13 == (-61837261299050L));
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) '4', (-1), 2, (int) '#', (int) (byte) 0, 15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test078");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str1 = iSOChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        try {
//            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField4 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField2);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        dateTimeFormatterBuilder1.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField0);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test082");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.util.TimeZone timeZone1 = dateTimeZone0.toTimeZone();
//        java.lang.String str3 = dateTimeZone0.getName((long) (byte) 10);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        try {
//            org.joda.time.DateTime.Property property6 = dateTime4.property(dateTimeFieldType5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime4);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-1L), "2019-06-15T05:05:22.051-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (byte) 0, (java.lang.Number) 0.0f, (java.lang.Number) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField7 = iSOChronology6.eras();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) 'a', 1, 3, (int) (byte) 100, 2000, (int) (byte) -1, (org.joda.time.Chronology) iSOChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.dayOfWeek();
        java.util.Locale locale8 = null;
        int int9 = property7.getMaximumShortTextLength(locale8);
        boolean boolean10 = property7.isLeap();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        java.io.Writer writer1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(writer1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test088");
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str6 = iSOChronology5.toString();
//        try {
//            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(3, (int) (byte) -1, 0, (int) (byte) -1, 100, (org.joda.time.Chronology) iSOChronology5);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str6.equals("ISOChronology[America/Los_Angeles]"));
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
        org.joda.time.format.DateTimeParser[] dateTimeParserArray2 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimePrinter1, dateTimeParserArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parsers supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 366);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test092");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.DateTime.Property property6 = dateTime1.millisOfSecond();
//        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime12 = dateTime9.withPeriodAdded(readablePeriod10, (int) (byte) 100);
//        int int13 = dateTime9.getHourOfDay();
//        org.joda.time.Chronology chronology14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) dateTime9, chronology14);
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime15.minus(readablePeriod16);
//        long long18 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        int int19 = dateTime15.getCenturyOfEra();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20 + "'", int19 == 20);
//    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getName(0L, locale2);
//        try {
//            org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("hi!");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hi!/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) 2019);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test096");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.DateTime.Property property6 = dateTime1.millisOfSecond();
//        boolean boolean8 = property6.equals((java.lang.Object) 100.0f);
//        org.joda.time.DateTime dateTime9 = property6.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime10 = property6.roundHalfFloorCopy();
//        int int11 = property6.get();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = property6.getAsText(locale12);
//        org.joda.time.Interval interval14 = property6.toInterval();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 64 + "'", int11 == 64);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "64" + "'", str13.equals("64"));
//        org.junit.Assert.assertNotNull(interval14);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        int int2 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter0.getZone();
        java.lang.Appendable appendable4 = null;
        try {
            dateTimeFormatter0.printTo(appendable4, (long) 431);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000 + "'", int2 == 2000);
        org.junit.Assert.assertNull(dateTimeZone3);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(2000, 365);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2365 + "'", int2 == 2365);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test101");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
//        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(10);
//        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime10 = dateTime8.withLaterOffsetAtOverlap();
//        boolean boolean12 = dateTime8.isEqual((long) 'a');
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(chronology13);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) (byte) 100);
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime20 = dateTime17.withDurationAdded(readableDuration18, (int) (short) 100);
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(chronology21);
//        org.joda.time.ReadablePeriod readablePeriod23 = null;
//        org.joda.time.DateTime dateTime25 = dateTime22.withPeriodAdded(readablePeriod23, (int) (byte) 100);
//        org.joda.time.DateTime dateTime27 = dateTime22.minusMinutes(0);
//        org.joda.time.Chronology chronology28 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime17, (org.joda.time.ReadableInstant) dateTime27);
//        boolean boolean29 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime27);
//        try {
//            org.joda.time.DateTime dateTime33 = dateTime8.withDate(15, 1970, 2000);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61837261296376L) + "'", long9 == (-61837261296376L));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 15);
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone0.getShortName((long) (short) 0, locale4);
//        java.util.TimeZone timeZone6 = dateTimeZone0.toTimeZone();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
//        org.junit.Assert.assertNotNull(timeZone6);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Coordinated Universal Time");
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test104");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560636325706L + "'", long7 == 1560636325706L);
//    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.DateTime.Property property6 = dateTime1.millisOfSecond();
//        boolean boolean8 = property6.equals((java.lang.Object) 100.0f);
//        org.joda.time.DateTime dateTime9 = property6.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime10 = property6.roundHalfFloorCopy();
//        org.joda.time.DurationField durationField11 = property6.getLeapDurationField();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNull(durationField11);
//    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test106");
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str9 = dateTimeZone7.getName((long) 15);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone7.getShortName((long) (short) 0, locale11);
//        try {
//            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((int) (short) 100, 2365, 0, 100, (int) 'a', (int) '#', 3, dateTimeZone7);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordinated Universal Time" + "'", str9.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UTC" + "'", str12.equals("UTC"));
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.year();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType3, 2, 365, 2365);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str9 = fixedDateTimeZone7.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone7);
        try {
            long long16 = zonedChronology10.getDateTimeMillis((long) (short) -1, (int) '4', 1, 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology10);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test109");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(readableDuration5, (int) (short) 100);
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime12 = dateTime9.withPeriodAdded(readablePeriod10, (int) (byte) 100);
//        org.joda.time.DateTime dateTime14 = dateTime9.minusMinutes(0);
//        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime4, (org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(chronology15);
//        int int17 = dateTime16.getDayOfMonth();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendHourOfHalfday(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendDayOfWeekText();
        boolean boolean7 = dateTimeFormatterBuilder5.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendTimeZoneOffset("64", false, 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatterBuilder0.toFormatter();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str4 = iSOChronology3.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology3.minutes();
//        try {
//            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatterBuilder0, (org.joda.time.Chronology) iSOChronology3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatterBuilder");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField5);
//    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test116");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readablePeriod8);
//        org.joda.time.DateTime.Property property10 = dateTime7.yearOfCentury();
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime15 = dateTime12.withPeriodAdded(readablePeriod13, (int) (byte) 100);
//        int int16 = dateTime12.getHourOfDay();
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) dateTime12, chronology17);
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime18.minus(readablePeriod19);
//        org.joda.time.DateTime dateTime22 = dateTime20.withHourOfDay((int) (byte) 1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        boolean boolean24 = dateTime20.isSupported(dateTimeFieldType23);
//        int int25 = property10.compareTo((org.joda.time.ReadableInstant) dateTime20);
//        int int26 = dateTime20.getDayOfWeek();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        int int2 = dateTimeFormatter0.getDefaultYear();
        try {
            org.joda.time.LocalTime localTime4 = dateTimeFormatter0.parseLocalTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000 + "'", int2 == 2000);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfEra((int) '#', (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendDayOfWeek(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendHourOfHalfday(15);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType9, 2019, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("2019-06-15T15:05:24.687-07:00");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"2019-06-15T15:05:24.687-07:00/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("T16:00:00.000-08:00", "");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNull(durationFieldType3);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("", 100, (-1), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for  must be in the range [-1,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((-61837261298230L), (long) 20);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61837261298250L) + "'", long2 == (-61837261298250L));
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str2 = iSOChronology1.toString();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.weekyearOfCentury();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 64, (org.joda.time.Chronology) iSOChronology1);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str2.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField3);
//    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test125");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
//        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(10);
//        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime10 = dateTime8.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime12 = dateTime8.plus((long) 100);
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        try {
//            int int14 = dateTime8.compareTo(readableInstant13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61837261294309L) + "'", long9 == (-61837261294309L));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("431");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"431/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendHourOfHalfday(1);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder5.appendTimeZoneOffset("2019-06-15T15:05:24.687-07:00", "431", true, 993, 431);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test128");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.DateTime.Property property6 = dateTime1.millisOfSecond();
//        boolean boolean8 = property6.equals((java.lang.Object) 100.0f);
//        org.joda.time.DateTime dateTime9 = property6.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime10 = property6.roundHalfFloorCopy();
//        int int11 = property6.get();
//        int int12 = property6.getMinimumValueOverall();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 963 + "'", int11 == 963);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test129");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str1 = iSOChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType4, 15, (int) '4', 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime8 = dateTime4.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = dateTime8.plusMonths((int) (short) -1);
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime14 = dateTime10.withPeriodAdded(readablePeriod12, (int) 'a');
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str9 = fixedDateTimeZone7.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone7);
        try {
            long long15 = zonedChronology10.getDateTimeMillis((int) (byte) 100, (int) (short) -1, (-1), 15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology10);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test133");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.withPeriodAdded(readablePeriod3, (int) (byte) 100);
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(readableDuration6, (int) (short) 100);
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(chronology9);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.withPeriodAdded(readablePeriod11, (int) (byte) 100);
//        org.joda.time.DateTime dateTime15 = dateTime10.minusMinutes(0);
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime5, (org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now(chronology16);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter0.withChronology(chronology16);
//        org.joda.time.Chronology chronology19 = null;
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(chronology19);
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.withPeriodAdded(readablePeriod21, (int) (byte) 100);
//        org.joda.time.DateTime dateTime25 = dateTime20.minusMinutes(0);
//        org.joda.time.DateMidnight dateMidnight26 = dateTime25.toDateMidnight();
//        org.joda.time.DateTime dateTime28 = dateTime25.minusHours(10);
//        java.lang.String str29 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime28);
//        org.joda.time.DateTime dateTime31 = dateTime28.plusSeconds((int) (byte) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = null;
//        try {
//            int int33 = dateTime28.get(dateTimeFieldType32);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateMidnight26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2019-06-15T05:05:28.471-07:00" + "'", str29.equals("2019-06-15T05:05:28.471-07:00"));
//        org.junit.Assert.assertNotNull(dateTime31);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType3, 431, 993);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test137");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.DateTime dateTime9 = dateTime1.withYear((int) (short) 0);
//        org.joda.time.DateTime dateTime11 = dateTime1.minusWeeks((int) (short) 0);
//        java.lang.String str12 = dateTime11.toString();
//        int int13 = dateTime11.getYear();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019-06-15T15:05:28.760-07:00" + "'", str12.equals("2019-06-15T15:05:28.760-07:00"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime8 = dateTime4.plusHours(993);
        try {
            org.joda.time.DateTime dateTime10 = dateTime4.withEra((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(0, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        java.io.Writer writer1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded(readableDuration7, (int) (short) 100);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(chronology10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.withPeriodAdded(readablePeriod12, (int) (byte) 100);
        org.joda.time.DateTime dateTime16 = dateTime11.minusMinutes(0);
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime6, (org.joda.time.ReadableInstant) dateTime16);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(chronology17);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        java.util.TimeZone timeZone7 = dateTimeZone6.toTimeZone();
        long long10 = dateTimeZone6.convertLocalToUTC(0L, false);
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(0, 3, 431, (int) (byte) 1, (int) (byte) 100, 0, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime8 = dateTime4.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = dateTime4.minusMillis((int) (byte) 10);
        org.joda.time.DateMidnight dateMidnight11 = dateTime4.toDateMidnight();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateMidnight11);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.dayOfWeek();
        java.util.Locale locale8 = null;
        int int9 = property7.getMaximumShortTextLength(locale8);
        java.util.Locale locale11 = null;
        try {
            org.joda.time.DateTime dateTime12 = property7.setCopy("org.joda.time.IllegalFieldValueException: Value \"\" for T16:00:00.000-08:00 is not supported", locale11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"org.joda.time.IllegalFieldValueException: Value \"\" for T16:00:00.000-08:00 is not supported\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime8 = dateTime4.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = dateTime4.minusMillis((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime4.minusDays(2);
        int int13 = dateTime4.getYear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfDay(2, 0);
        boolean boolean7 = dateTimeFormatterBuilder3.canBuildParser();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder3.appendFixedSignedDecimal(dateTimeFieldType8, 64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatterBuilder3.toParser();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap5);
        dateTimeFormatterBuilder3.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendYearOfCentury((int) (byte) 1, 3);
        org.joda.time.format.DateTimePrinter dateTimePrinter13 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendTimeZoneShortName();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatterBuilder17.toParser();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder8.append(dateTimePrinter13, dateTimeParser18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(10);
        org.joda.time.DateTime dateTime10 = dateTime8.plusMinutes(100);
        try {
            org.joda.time.DateTime dateTime12 = dateTime8.withEra(365);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime8 = dateTime4.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = dateTime4.withHourOfDay(20);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test151");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.era();
//        jodaTimePermission1.checkGuard((java.lang.Object) dateTimeField4);
//        java.security.PermissionCollection permissionCollection6 = jodaTimePermission1.newPermissionCollection();
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(permissionCollection6);
//    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
//        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(10);
//        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime10 = dateTime8.withLaterOffsetAtOverlap();
//        boolean boolean12 = dateTime8.isEqual((long) 'a');
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(chronology13);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) (byte) 100);
//        org.joda.time.DateTime dateTime19 = dateTime14.minusMinutes(0);
//        org.joda.time.Chronology chronology20 = null;
//        org.joda.time.MutableDateTime mutableDateTime21 = dateTime14.toMutableDateTime(chronology20);
//        org.joda.time.LocalDate localDate22 = dateTime14.toLocalDate();
//        org.joda.time.DateTime dateTime23 = dateTime8.withFields((org.joda.time.ReadablePartial) localDate22);
//        org.joda.time.DateTime dateTime25 = dateTime8.minusHours(0);
//        int int26 = dateTime25.getCenturyOfEra();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61837261291445L) + "'", long9 == (-61837261291445L));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(mutableDateTime21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str9 = fixedDateTimeZone7.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone7);
        try {
            long long15 = zonedChronology10.getDateTimeMillis(4, 365, 2000, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology10);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.DateTime.Property property6 = dateTime1.millisOfSecond();
//        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime12 = dateTime9.withPeriodAdded(readablePeriod10, (int) (byte) 100);
//        int int13 = dateTime9.getHourOfDay();
//        org.joda.time.Chronology chronology14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) dateTime9, chronology14);
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime15.minus(readablePeriod16);
//        long long18 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        java.util.Locale locale19 = null;
//        int int20 = property6.getMaximumTextLength(locale19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str9 = fixedDateTimeZone7.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology0.yearOfCentury();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField12, (int) (short) 0, 366, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfCentury must be in the range [366,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("6");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"6/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((-61837261294770L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime8 = dateTime4.plusMinutes((int) (byte) 10);
        org.joda.time.LocalTime localTime9 = dateTime4.toLocalTime();
        java.util.Locale locale11 = null;
        try {
            java.lang.String str12 = dateTime4.toString("org.joda.time.IllegalFieldValueException: Value \"\" for T16:00:00.000-08:00 is not supported", locale11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: o");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localTime9);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        long long6 = fixedDateTimeZone4.previousTransition(0L);
        long long8 = fixedDateTimeZone4.nextTransition((long) (byte) 0);
        long long10 = fixedDateTimeZone4.nextTransition((long) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Locale locale13 = null;
        java.lang.String str14 = fixedDateTimeZone4.getShortName(10L, locale13);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.010" + "'", str14.equals("+00:00:00.010"));
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
//        org.joda.time.DateTime dateTime8 = dateTime4.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime10 = dateTime4.minusMillis((int) (byte) 10);
//        org.joda.time.DateTime dateTime12 = dateTime4.minusDays(2);
//        org.joda.time.DateTime dateTime14 = dateTime4.withCenturyOfEra((int) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str17 = dateTimeZone15.getName((long) 15);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone15.getShortName((long) (short) 0, locale19);
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = dateTimeZone15.getShortName((long) (short) 100, locale22);
//        org.joda.time.DateTime dateTime24 = dateTime14.withZoneRetainFields(dateTimeZone15);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = dateTimeZone15.getName((-61837261294770L), locale26);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Coordinated Universal Time" + "'", str17.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "UTC" + "'", str23.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Coordinated Universal Time" + "'", str27.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) 4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
//        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(10);
//        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime10 = dateTime8.withLaterOffsetAtOverlap();
//        boolean boolean12 = dateTime8.isEqual((long) 'a');
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(chronology13);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) (byte) 100);
//        org.joda.time.DateTime dateTime19 = dateTime14.minusMinutes(0);
//        org.joda.time.Chronology chronology20 = null;
//        org.joda.time.MutableDateTime mutableDateTime21 = dateTime14.toMutableDateTime(chronology20);
//        org.joda.time.LocalDate localDate22 = dateTime14.toLocalDate();
//        org.joda.time.DateTime dateTime23 = dateTime8.withFields((org.joda.time.ReadablePartial) localDate22);
//        try {
//            org.joda.time.DateTime dateTime25 = dateTime23.withDayOfMonth((int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,28]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61837261290725L) + "'", long9 == (-61837261290725L));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(mutableDateTime21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTime23);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(10);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) ' ');
        try {
            org.joda.time.DateTime dateTime12 = dateTime1.withWeekOfWeekyear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test165");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.lang.String str2 = dateTimeFormatter0.print(0L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZoneUTC();
//        try {
//            org.joda.time.DateTime dateTime5 = dateTimeFormatter0.parseDateTime("431");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"431\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "T16:00:00.000-08:00" + "'", str2.equals("T16:00:00.000-08:00"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildFormatter();
        try {
            org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatterBuilder0.toPrinter();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
        org.joda.time.DateMidnight dateMidnight7 = dateTime6.toDateMidnight();
        org.joda.time.DateTime dateTime9 = dateTime6.minusHours(10);
        org.joda.time.DateTime dateTime11 = dateTime9.minus((long) '4');
        boolean boolean13 = dateTime9.isAfter(0L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateMidnight7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test168");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str1 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField2 = iSOChronology0.minutes();
//        long long5 = durationField2.subtract(0L, (long) 2019);
//        org.joda.time.DurationFieldType durationFieldType6 = null;
//        try {
//            org.joda.time.field.DecoratedDurationField decoratedDurationField7 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-121140000L) + "'", long5 == (-121140000L));
//    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test169");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 15);
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone0.getShortName((long) (short) 0, locale4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone0.getShortName((long) (short) 100, locale7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone0);
//        try {
//            org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) '4');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 52");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField5 = offsetDateTimeField3.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType6, (int) '4', 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField8 = iSOChronology7.eras();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str16 = fixedDateTimeZone14.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, (org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone18 = zonedChronology17.getZone();
        try {
            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(0, 1, (int) (short) 0, (int) (short) 1, (int) (short) 100, (-4), 24, (org.joda.time.Chronology) zonedChronology17);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis(64, (int) '4', 2, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(6, 100, (int) (byte) 0, (int) 'a', 4, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(64, '#', 0, (int) (byte) 100, 5, true, 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder0.addRecurringSavings("", 2365, 2019, (int) (short) 100, 'a', 0, 993, 6, false, 5);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder27 = dateTimeZoneBuilder19.addCutover(963, '#', 431, 19, 0, true, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder19);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendYearOfEra((int) '#', (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder1.appendDayOfWeek(3);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.withPeriodAdded(readablePeriod10, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.withDurationAdded(readableDuration13, (int) (short) 100);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (byte) 100);
        org.joda.time.DateTime dateTime22 = dateTime17.minusMinutes(0);
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime12, (org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now(chronology23);
        org.joda.time.DateTime.Property property25 = dateTime24.monthOfYear();
        org.joda.time.DateTime dateTime26 = property25.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property25.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder1.appendShortText(dateTimeFieldType27);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField29 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 366, (java.lang.Number) 100, (java.lang.Number) (-61837261298250L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(readableDuration5, (int) (short) 100);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.withPeriodAdded(readablePeriod10, (int) (byte) 100);
        org.joda.time.DateTime dateTime14 = dateTime9.minusMinutes(0);
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime4, (org.joda.time.ReadableInstant) dateTime14);
        try {
            java.lang.String str17 = dateTime4.toString("Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: oo");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(chronology15);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatterBuilder3.toParser();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap5);
        dateTimeFormatterBuilder3.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.appendFractionOfMinute(366, 366);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime8 = dateTime4.plusMinutes((int) (byte) 10);
        org.joda.time.LocalTime localTime9 = dateTime4.toLocalTime();
        try {
            org.joda.time.DateTime dateTime13 = dateTime4.withDate((int) (byte) 10, 1970, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localTime9);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test182");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) (byte) 100);
//        int int7 = dateTime3.getHourOfDay();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) dateTime3, chronology8);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.minus(readablePeriod10);
//        org.joda.time.LocalDateTime localDateTime12 = dateTime11.toLocalDateTime();
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDateTime12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(localDateTime12);
//    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test183");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime1.toMutableDateTime(chronology7);
//        org.joda.time.DateTime dateTime10 = dateTime1.withHourOfDay((int) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
//        java.util.TimeZone timeZone12 = dateTimeZone11.toTimeZone();
//        java.lang.String str14 = dateTimeZone11.getName((long) (byte) 10);
//        org.joda.time.DateTime dateTime15 = dateTime1.toDateTime(dateTimeZone11);
//        org.joda.time.DurationFieldType durationFieldType16 = null;
//        try {
//            org.joda.time.DateTime dateTime18 = dateTime1.withFieldAdded(durationFieldType16, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Coordinated Universal Time" + "'", str14.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test184");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str1 = iSOChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
//        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
//        try {
//            long long9 = iSOChronology0.getDateTimeMillis(993, (-1), 431, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str10 = fixedDateTimeZone8.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology11.getZone();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(1560636316453L, dateTimeZone12);
        org.joda.time.DateTime.Property property14 = dateTime13.dayOfMonth();
        java.util.Locale locale16 = null;
        try {
            org.joda.time.DateTime dateTime17 = property14.setCopy("64", locale16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 64 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withZone(dateTimeZone2);
        try {
            org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("UTC", dateTimeFormatter3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UTC\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime8 = dateTime4.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = dateTime4.minusMillis((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime4.minusDays(2);
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime4.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str7 = iSOChronology6.toString();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.weekyearOfCentury();
//        org.joda.time.Chronology chronology9 = iSOChronology6.withUTC();
//        org.joda.time.DurationField durationField10 = iSOChronology6.eras();
//        try {
//            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((int) (short) 10, 1970, (-4), (int) '#', (int) (short) -1, 6, (org.joda.time.Chronology) iSOChronology6);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str7.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
//        long long5 = offsetDateTimeField3.roundCeiling((long) (short) -1);
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime10 = dateTime7.withPeriodAdded(readablePeriod8, (int) (byte) 100);
//        org.joda.time.DateTime dateTime12 = dateTime7.minusMinutes(0);
//        org.joda.time.DateTime dateTime14 = dateTime7.withYearOfEra(10);
//        long long15 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTime dateTime16 = dateTime14.withLaterOffsetAtOverlap();
//        boolean boolean18 = dateTime14.isEqual((long) 'a');
//        org.joda.time.Chronology chronology19 = null;
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(chronology19);
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.withPeriodAdded(readablePeriod21, (int) (byte) 100);
//        org.joda.time.DateTime dateTime25 = dateTime20.minusMinutes(0);
//        org.joda.time.Chronology chronology26 = null;
//        org.joda.time.MutableDateTime mutableDateTime27 = dateTime20.toMutableDateTime(chronology26);
//        org.joda.time.LocalDate localDate28 = dateTime20.toLocalDate();
//        org.joda.time.DateTime dateTime29 = dateTime14.withFields((org.joda.time.ReadablePartial) localDate28);
//        boolean boolean30 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate28);
//        int[] intArray38 = new int[] { 6, 79533557, 963, 993, 3, 24 };
//        try {
//            int[] intArray40 = offsetDateTimeField3.set((org.joda.time.ReadablePartial) localDate28, 1970, intArray38, 30);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1970");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61837261287751L) + "'", long15 == (-61837261287751L));
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(intArray38);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
        java.util.Locale locale6 = null;
        try {
            long long7 = offsetDateTimeField3.set(0L, "2019-W24", locale6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-W24\" for millisOfSecond is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test192");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(readableDuration5, (int) (short) 100);
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime12 = dateTime9.withPeriodAdded(readablePeriod10, (int) (byte) 100);
//        org.joda.time.DateTime dateTime14 = dateTime9.minusMinutes(0);
//        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime4, (org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(chronology15);
//        org.joda.time.DateTime.Property property17 = dateTime16.monthOfYear();
//        long long18 = property17.remainder();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1263934383L + "'", long18 == 1263934383L);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1560636316453L, 365);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 569632255505345L + "'", long2 == 569632255505345L);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
        java.io.Writer writer3 = null;
        try {
            dateTimeFormatter0.printTo(writer3, (-61837261293834L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((-61837261301932L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
        int int4 = offsetDateTimeField3.getMaximumValue();
        java.lang.String str6 = offsetDateTimeField3.getAsText(0L);
        long long9 = offsetDateTimeField3.add((-61837261301676L), (int) (byte) -1);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1014 + "'", int4 == 1014);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61837261301677L) + "'", long9 == (-61837261301677L));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str13 = fixedDateTimeZone11.getNameKey(0L);
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(2365, 6, 19, 4, 64, 366, (int) (byte) 0, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 64 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField6 = iSOChronology5.eras();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str14 = fixedDateTimeZone12.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology5, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology5.hourOfDay();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology5.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology5.weekyearOfCentury();
        try {
            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((int) (byte) 100, 4, 0, (-4), (int) (short) -1, (org.joda.time.Chronology) iSOChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -4 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        try {
            long long2 = dateTimeFormatter0.parseMillis("ISOChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[America/Los_Angeles]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str9 = fixedDateTimeZone7.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology10.era();
        org.joda.time.Chronology chronology12 = zonedChronology10.withUTC();
        try {
            long long17 = zonedChronology10.getDateTimeMillis(993, 64, 97, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 64 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test202");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str1 = iSOChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
        int int4 = offsetDateTimeField3.getMaximumValue();
        try {
            long long7 = offsetDateTimeField3.set((long) 6, "+00:00:00.010");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"+00:00:00.010\" for millisOfSecond is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1014 + "'", int4 == 1014);
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test205");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
//        java.io.Writer writer1 = null;
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) (byte) 100);
//        int int7 = dateTime3.getHourOfDay();
//        org.joda.time.DateTime.Property property8 = dateTime3.millisOfSecond();
//        boolean boolean10 = property8.equals((java.lang.Object) 100.0f);
//        org.joda.time.DateTime dateTime11 = property8.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime12 = property8.roundHalfFloorCopy();
//        org.joda.time.LocalTime localTime13 = dateTime12.toLocalTime();
//        try {
//            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localTime13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(localTime13);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 24, (java.lang.Number) 0.0f, (java.lang.Number) (-61837261301932L));
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertNull(durationFieldType5);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(chronology4);
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.withPeriodAdded(readablePeriod6, (int) (byte) 100);
//        org.joda.time.DateTime dateTime10 = dateTime5.minusMinutes(0);
//        org.joda.time.DateTime dateTime12 = dateTime5.withYearOfEra(10);
//        long long13 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DateTime dateTime14 = dateTime12.withLaterOffsetAtOverlap();
//        boolean boolean16 = dateTime12.isEqual((long) 'a');
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(chronology17);
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.DateTime dateTime21 = dateTime18.withPeriodAdded(readablePeriod19, (int) (byte) 100);
//        org.joda.time.DateTime dateTime23 = dateTime18.minusMinutes(0);
//        org.joda.time.Chronology chronology24 = null;
//        org.joda.time.MutableDateTime mutableDateTime25 = dateTime18.toMutableDateTime(chronology24);
//        org.joda.time.LocalDate localDate26 = dateTime18.toLocalDate();
//        org.joda.time.DateTime dateTime27 = dateTime12.withFields((org.joda.time.ReadablePartial) localDate26);
//        boolean boolean28 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate26);
//        int[] intArray35 = new int[] { (-1), 97, (byte) -1, 993, 3 };
//        try {
//            int[] intArray37 = offsetDateTimeField3.addWrapPartial((org.joda.time.ReadablePartial) localDate26, (int) '4', intArray35, 674);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61837261286218L) + "'", long13 == (-61837261286218L));
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(mutableDateTime25);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNotNull(intArray35);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(10);
        org.joda.time.DateTime dateTime10 = dateTime8.plusMinutes(100);
        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfSecond((int) (short) 1);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime12.minus(readablePeriod13);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-61837261293834L), 19);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1174907964582846L) + "'", long2 == (-1174907964582846L));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 100, (-61837261288556L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-6183726128855600L) + "'", long2 == (-6183726128855600L));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfHour();
        org.joda.time.DateTime dateTime8 = property7.roundFloorCopy();
        java.util.GregorianCalendar gregorianCalendar9 = dateTime8.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField6 = iSOChronology5.eras();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.clockhourOfHalfday();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(15, 0, 30, 4, 19, (org.joda.time.Chronology) iSOChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(79533557, 1970, (int) (short) 1, 2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str9 = fixedDateTimeZone7.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone11 = zonedChronology10.getZone();
        try {
            long long19 = zonedChronology10.getDateTimeMillis((int) 'a', 0, (int) ' ', 2019, (int) (short) -1, (int) (byte) 0, 963);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test217");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readablePeriod8);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
//        int int16 = fixedDateTimeZone14.getOffsetFromLocal((-1L));
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone14);
//        org.joda.time.MutableDateTime mutableDateTime18 = dateTime7.toMutableDateTime(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField6 = new org.joda.time.field.DecoratedDurationField(durationField4, durationFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 963, (long) 3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 966L + "'", long2 == 966L);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (-61837261290390L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime8 = dateTime4.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = dateTime8.plusMonths((int) (short) -1);
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime12.withEarlierOffsetAtOverlap();
        org.joda.time.DurationFieldType durationFieldType14 = null;
        try {
            org.joda.time.DateTime dateTime16 = dateTime13.withFieldAdded(durationFieldType14, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test224");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 15);
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone0.getShortName((long) (short) 0, locale4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone0.getShortName((long) (short) 100, locale7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone0);
//        long long12 = dateTimeZone0.convertLocalToUTC((long) 100, false);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test226");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.DateTime.Property property6 = dateTime1.millisOfSecond();
//        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField8 = property6.getRangeDurationField();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(durationField8);
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
        long long7 = durationField4.subtract(1560636328611L, 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560636328611L + "'", long7 == 1560636328611L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "2019-06-15T15:05:28.760-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, chronology1);
        int int3 = dateTime2.getWeekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime2.getZone();
        org.joda.time.DateTime dateTime6 = dateTime2.withMillisOfDay(5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1970 + "'", int3 == 1970);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
        boolean boolean5 = offsetDateTimeField3.isSupported();
        long long7 = offsetDateTimeField3.roundCeiling((long) 3);
        boolean boolean9 = offsetDateTimeField3.isLeap((long) 3);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3L + "'", long7 == 3L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readablePeriod8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfMonth();
//        java.util.Locale locale11 = null;
//        int int12 = property10.getMaximumShortTextLength(locale11);
//        java.lang.String str13 = property10.getAsString();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "15" + "'", str13.equals("15"));
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gregorianChronology0.equals(obj1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 15);
        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getDurationField();
        boolean boolean8 = offsetDateTimeField6.isSupported();
        boolean boolean9 = gregorianChronology0.equals((java.lang.Object) offsetDateTimeField6);
        try {
            long long12 = offsetDateTimeField6.set((long) (byte) 1, "2019-06-15T15:05:34.415-07:00");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-15T15:05:34.415-07:00\" for millisOfSecond is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(10);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.plus(readablePeriod9);
        org.joda.time.DateTime.Property property11 = dateTime8.dayOfMonth();
        org.joda.time.DateTime dateTime14 = dateTime8.withDurationAdded((long) 4, 2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime14);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.DateTime.Property property6 = dateTime1.millisOfSecond();
//        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
//        long long8 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime7);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560636338044L + "'", long8 == 1560636338044L);
//    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test236");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readablePeriod8);
//        org.joda.time.DateTime.Property property10 = dateTime7.dayOfYear();
//        org.joda.time.DateTime dateTime11 = property10.roundCeilingCopy();
//        java.util.Locale locale13 = null;
//        org.joda.time.DateTime dateTime14 = property10.setCopy("6", locale13);
//        int int15 = property10.getMaximumValueOverall();
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (byte) 100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
//        boolean boolean22 = dateTime20.isSupported(dateTimeFieldType21);
//        org.joda.time.DateTime dateTime24 = dateTime20.plusMinutes((int) (byte) 10);
//        org.joda.time.LocalTime localTime25 = dateTime20.toLocalTime();
//        try {
//            int int26 = property10.compareTo((org.joda.time.ReadablePartial) localTime25);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfYear' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 366 + "'", int15 == 366);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(localTime25);
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
        boolean boolean5 = offsetDateTimeField3.isSupported();
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withPeriodAdded(readablePeriod8, (int) (byte) 100);
        org.joda.time.DateTime dateTime12 = dateTime7.minusMinutes(0);
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.MutableDateTime mutableDateTime14 = dateTime7.toMutableDateTime(chronology13);
        org.joda.time.LocalDate localDate15 = dateTime7.toLocalDate();
        int[] intArray21 = new int[] { 15, 19, 963, 2 };
        java.util.Locale locale23 = null;
        try {
            int[] intArray24 = offsetDateTimeField3.set((org.joda.time.ReadablePartial) localDate15, 2000, intArray21, "64", locale23);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2000");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(intArray21);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatter3.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimeParser4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendDayOfMonth((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendMillisOfSecond(30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) 1014, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) 365);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendYearOfEra((int) '#', (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder1.appendDayOfWeek(3);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.withPeriodAdded(readablePeriod10, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.withDurationAdded(readableDuration13, (int) (short) 100);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (byte) 100);
        org.joda.time.DateTime dateTime22 = dateTime17.minusMinutes(0);
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime12, (org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now(chronology23);
        org.joda.time.DateTime.Property property25 = dateTime24.monthOfYear();
        org.joda.time.DateTime dateTime26 = property25.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property25.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder1.appendShortText(dateTimeFieldType27);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField29 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(readableDuration5, (int) (short) 100);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.withPeriodAdded(readablePeriod10, (int) (byte) 100);
        org.joda.time.DateTime dateTime14 = dateTime9.minusMinutes(0);
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime4, (org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(chronology15);
        org.joda.time.DateTime.Property property17 = dateTime16.monthOfYear();
        org.joda.time.DateTime dateTime18 = property17.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property17.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 3L, "2019-06-15T15:05:30.038-07:00");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType19, (int) (short) 0, 366, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [366,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test244");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
//        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(10);
//        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime10 = dateTime8.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime12 = dateTime8.plus((long) 100);
//        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((int) (short) 100);
//        org.joda.time.DateTime.Property property15 = dateTime12.dayOfMonth();
//        java.lang.String str16 = property15.getAsText();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61837261283541L) + "'", long9 == (-61837261283541L));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "15" + "'", str16.equals("15"));
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
        boolean boolean5 = offsetDateTimeField3.isSupported();
        boolean boolean6 = offsetDateTimeField3.isSupported();
        try {
            long long9 = offsetDateTimeField3.set((long) 1970, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for millisOfSecond must be in the range [15,1014]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str9 = fixedDateTimeZone7.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology10.era();
        org.joda.time.Chronology chronology12 = zonedChronology10.withUTC();
        try {
            long long20 = zonedChronology10.getDateTimeMillis((int) ' ', 15, 59, 19, 15, (int) '4', 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 15 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter2.printTo(appendable3, 966L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatterBuilder3.toParser();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap5);
        dateTimeFormatterBuilder3.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendYearOfCentury((int) (byte) 1, 3);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder8.appendTimeZoneOffset("", "org.joda.time.IllegalFieldValueException: Value \"\" for T16:00:00.000-08:00 is not supported", true, 2365, 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("T16:00:00.000-08:00", "");
        java.lang.String str3 = illegalFieldValueException2.toString();
        java.lang.Number number4 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for T16:00:00.000-08:00 is not supported" + "'", str3.equals("org.joda.time.IllegalFieldValueException: Value \"\" for T16:00:00.000-08:00 is not supported"));
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
        boolean boolean5 = offsetDateTimeField3.isSupported();
        long long7 = offsetDateTimeField3.roundCeiling((long) 3);
        java.lang.String str9 = offsetDateTimeField3.getAsText(1560556800001L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3L + "'", long7 == 3L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "16" + "'", str9.equals("16"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("+00:00:00.010");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+00:00:00.010\" is malformed at \":00:00.010\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        try {
            org.joda.time.LocalDate localDate3 = dateTimeFormatter0.parseLocalDate("2019-06-15T15:05:24.687-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-15T15:05:24.687-07:00\" is malformed at \"-06-15T15:05:24.687-07:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 15);
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone0.getShortName((long) (short) 0, locale4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone0.getShortName((long) (short) 100, locale7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone0);
//        java.lang.String str11 = dateTimeZone0.getName((-61837261293712L));
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordinated Universal Time" + "'", str11.equals("Coordinated Universal Time"));
//    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test254");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.DateTime.Property property6 = dateTime1.millisOfSecond();
//        boolean boolean8 = property6.equals((java.lang.Object) 100.0f);
//        org.joda.time.DateTime dateTime9 = property6.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime10 = property6.roundHalfFloorCopy();
//        int int11 = dateTime10.getMillisOfSecond();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 959 + "'", int11 == 959);
//    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
//        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(10);
//        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime10 = dateTime8.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime12 = dateTime8.plus((long) 100);
//        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((int) (short) 100);
//        org.joda.time.DateTime.Property property15 = dateTime12.dayOfMonth();
//        org.joda.time.DateTime dateTime16 = property15.withMaximumValue();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61837261282318L) + "'", long9 == (-61837261282318L));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((-1L));
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(timeZone8);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendHourOfHalfday(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendDayOfWeek(6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendWeekOfWeekyear(959);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test259");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readablePeriod8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfMonth();
//        long long11 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime9);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560636339981L + "'", long11 == 1560636339981L);
//    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str9 = fixedDateTimeZone7.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology10.era();
        org.joda.time.Chronology chronology12 = zonedChronology10.withUTC();
        try {
            long long20 = zonedChronology10.getDateTimeMillis((int) (byte) -1, (int) (short) 10, 6, (int) (short) 100, (int) ' ', (int) (short) 100, 963);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        try {
            org.joda.time.MutableDateTime mutableDateTime3 = dateTimeFormatter0.parseMutableDateTime("GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
//        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
//        boolean boolean5 = offsetDateTimeField3.isSupported();
//        boolean boolean6 = offsetDateTimeField3.isSupported();
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(chronology7);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withPeriodAdded(readablePeriod9, (int) (byte) 100);
//        int int12 = dateTime8.getHourOfDay();
//        org.joda.time.DateTime.Property property13 = dateTime8.millisOfSecond();
//        boolean boolean15 = property13.equals((java.lang.Object) 100.0f);
//        org.joda.time.DateTime dateTime16 = property13.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime17 = property13.roundHalfFloorCopy();
//        org.joda.time.LocalTime localTime18 = dateTime17.toLocalTime();
//        boolean boolean19 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime18);
//        int int20 = offsetDateTimeField3.getMaximumValue((org.joda.time.ReadablePartial) localTime18);
//        try {
//            int int23 = offsetDateTimeField3.getDifference(1560636328611L, (-121140000L));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 1560757468611");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(localTime18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1014 + "'", int20 == 1014);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 1560636338044L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 569632255505345L, 993);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test266");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
//        int int4 = offsetDateTimeField3.getMaximumValue();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology5);
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime9 = dateTime6.withPeriodAdded(readablePeriod7, (int) (byte) 100);
//        int int10 = dateTime6.getHourOfDay();
//        long long11 = dateTime6.getMillis();
//        org.joda.time.DateTime dateTime13 = dateTime6.plus((long) 15);
//        org.joda.time.LocalTime localTime14 = dateTime6.toLocalTime();
//        int[] intArray21 = new int[] { ' ', (byte) 10, 1014, 431, 959 };
//        java.util.Locale locale23 = null;
//        try {
//            int[] intArray24 = offsetDateTimeField3.set((org.joda.time.ReadablePartial) localTime14, 10, intArray21, "64", locale23);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1014 + "'", int4 == 1014);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560636340485L + "'", long11 == 1560636340485L);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(localTime14);
//        org.junit.Assert.assertNotNull(intArray21);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.Object obj6 = null;
        boolean boolean7 = gregorianChronology5.equals(obj6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 15);
        org.joda.time.DurationField durationField12 = offsetDateTimeField11.getDurationField();
        boolean boolean13 = offsetDateTimeField11.isSupported();
        boolean boolean14 = gregorianChronology5.equals((java.lang.Object) offsetDateTimeField11);
        try {
            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((int) (short) 0, 20, 6, (int) (byte) -1, 100, (org.joda.time.Chronology) gregorianChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(674, (int) (byte) 10, 1, (int) (short) 1, 1970, 366, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.DateTime.Property property6 = dateTime1.millisOfSecond();
//        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime12 = dateTime9.withPeriodAdded(readablePeriod10, (int) (byte) 100);
//        int int13 = dateTime9.getHourOfDay();
//        org.joda.time.Chronology chronology14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) dateTime9, chronology14);
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime15.minus(readablePeriod16);
//        long long18 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        java.util.Locale locale19 = null;
//        int int20 = property6.getMaximumShortTextLength(locale19);
//        int int21 = property6.getMinimumValueOverall();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(chronology4);
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.withPeriodAdded(readablePeriod6, (int) (byte) 100);
//        int int9 = dateTime5.getHourOfDay();
//        long long10 = dateTime5.getMillis();
//        org.joda.time.DateTime dateTime12 = dateTime5.plus((long) 15);
//        org.joda.time.LocalTime localTime13 = dateTime5.toLocalTime();
//        int[] intArray21 = new int[] { 2000, (-4), (short) 10, 100, 10, 674 };
//        try {
//            int[] intArray23 = offsetDateTimeField3.addWrapField((org.joda.time.ReadablePartial) localTime13, 59, intArray21, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 59");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560636340766L + "'", long10 == 1560636340766L);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(localTime13);
//        org.junit.Assert.assertNotNull(intArray21);
//    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str1 = iSOChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.era();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfMinute();
//        org.joda.time.DurationField durationField6 = iSOChronology0.minutes();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(durationField6);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
        int int6 = offsetDateTimeField3.getMinimumValue((-61837261293834L));
        org.joda.time.ReadablePartial readablePartial7 = null;
        int[] intArray9 = new int[] {};
        java.util.Locale locale11 = null;
        try {
            int[] intArray12 = offsetDateTimeField3.set(readablePartial7, 10, intArray9, "2019-06-15T05:05:22.051-07:00", locale11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-15T05:05:22.051-07:00\" for millisOfSecond is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNotNull(intArray9);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withPeriodAdded(readablePeriod3, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(readableDuration6, (int) (short) 100);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(chronology9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.withPeriodAdded(readablePeriod11, (int) (byte) 100);
        org.joda.time.DateTime dateTime15 = dateTime10.minusMinutes(0);
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime5, (org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now(chronology16);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter0.withChronology(chronology16);
        boolean boolean19 = dateTimeFormatter18.isParser();
        try {
            org.joda.time.DateTime dateTime21 = dateTimeFormatter18.parseDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test274");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readablePeriod8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfMonth();
//        java.util.Locale locale11 = null;
//        int int12 = property10.getMaximumShortTextLength(locale11);
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(chronology13);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) (byte) 100);
//        int int18 = dateTime14.getHourOfDay();
//        org.joda.time.DateTime.Property property19 = dateTime14.millisOfSecond();
//        org.joda.time.DateTime dateTime20 = property19.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(chronology21);
//        org.joda.time.ReadablePeriod readablePeriod23 = null;
//        org.joda.time.DateTime dateTime25 = dateTime22.withPeriodAdded(readablePeriod23, (int) (byte) 100);
//        int int26 = dateTime22.getHourOfDay();
//        org.joda.time.Chronology chronology27 = null;
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) dateTime22, chronology27);
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime28.minus(readablePeriod29);
//        long long31 = property19.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime28);
//        int int32 = property10.compareTo((org.joda.time.ReadableInstant) dateTime28);
//        org.joda.time.DateTime dateTime34 = dateTime28.minusMillis(993);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 15 + "'", int26 == 15);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(dateTime34);
//    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime1.toMutableDateTime(chronology7);
//        boolean boolean9 = mutableDateTime8.isAfterNow();
//        org.joda.time.Instant instant10 = mutableDateTime8.toInstant();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.date();
//        java.lang.String str12 = instant10.toString(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(instant10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019-06-15" + "'", str12.equals("2019-06-15"));
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        long long6 = fixedDateTimeZone4.previousTransition(0L);
        long long8 = fixedDateTimeZone4.nextTransition((long) (byte) 0);
        long long10 = fixedDateTimeZone4.nextTransition((long) 100);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        long long17 = fixedDateTimeZone15.previousTransition(0L);
        long long19 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone15, (long) 20);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone20 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str22 = cachedDateTimeZone20.getNameKey((-61837261285963L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 20L + "'", long19 == 20L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-15T15:05:30.038-07:00");
        boolean boolean3 = jodaTimePermission1.equals((java.lang.Object) 1560636339981L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str9 = fixedDateTimeZone7.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology0.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        long long20 = fixedDateTimeZone18.previousTransition(0L);
        long long22 = fixedDateTimeZone18.nextTransition((long) (byte) 0);
        long long24 = fixedDateTimeZone18.nextTransition((long) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone25 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        int int27 = cachedDateTimeZone25.getStandardOffset((long) (byte) 1);
        int int29 = cachedDateTimeZone25.getOffset((-61837261290390L));
        org.joda.time.DateTimeZone dateTimeZone30 = cachedDateTimeZone25.getUncachedZone();
        org.joda.time.Chronology chronology31 = iSOChronology0.withZone(dateTimeZone30);
        org.joda.time.ReadableInstant readableInstant32 = null;
        int int33 = dateTimeZone30.getOffset(readableInstant32);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 100 + "'", int27 == 100);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 10 + "'", int33 == 10);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendHourOfHalfday(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendDayOfWeekText();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.withPeriodAdded(readablePeriod9, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded(readableDuration12, (int) (short) 100);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) (byte) 100);
        org.joda.time.DateTime dateTime21 = dateTime16.minusMinutes(0);
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime11, (org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now(chronology22);
        org.joda.time.DateTime.Property property24 = dateTime23.monthOfYear();
        org.joda.time.DateTime dateTime25 = property24.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder6.appendShortText(dateTimeFieldType26);
        org.joda.time.format.DateTimePrinter dateTimePrinter28 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.format.DateTimeParser dateTimeParser30 = dateTimeFormatter29.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter28, dateTimeParser30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder6.appendOptional(dateTimeParser30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTimeParser30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(10);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.plus(readablePeriod9);
        org.joda.time.DateTime dateTime12 = dateTime8.plusDays(30);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("2019-06-15T15:05:28.760-07:00", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-15T15:05:28.760-07:00\" is malformed at \"-15T15:05:28.760-07:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        long long12 = fixedDateTimeZone10.previousTransition(0L);
        long long14 = fixedDateTimeZone10.nextTransition((long) (byte) 0);
        long long16 = fixedDateTimeZone10.nextTransition((long) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        int int19 = cachedDateTimeZone17.getStandardOffset((long) (byte) 1);
        int int21 = cachedDateTimeZone17.getStandardOffset((long) 1970);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        boolean boolean23 = cachedDateTimeZone17.equals((java.lang.Object) dateTimeZone22);
        try {
            org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(0, (int) '#', (int) ' ', 0, 2, (int) (short) 100, dateTimeZone22);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "15");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(2000, 1970, 2365, 2, 97, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str10 = fixedDateTimeZone8.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology11.getZone();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(1560636316453L, dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = null;
        try {
            int int15 = dateTime13.get(dateTimeField14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeField must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("2019-06-15T15:05:24.687-07:00");
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 30);
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test290");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 15);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        long long7 = dateTimeZone0.convertLocalToUTC(1560636328611L, true, 1560636338044L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560636328611L + "'", long7 == 1560636328611L);
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        long long6 = fixedDateTimeZone4.previousTransition(0L);
        long long8 = fixedDateTimeZone4.nextTransition((long) (byte) 0);
        long long10 = fixedDateTimeZone4.nextTransition((long) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Locale locale13 = null;
        java.lang.String str14 = fixedDateTimeZone4.getShortName((-61837261298250L), locale13);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.010" + "'", str14.equals("+00:00:00.010"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, 674L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime8 = dateTime4.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = dateTime8.plusMonths((int) (short) -1);
        try {
            org.joda.time.DateTime dateTime12 = dateTime10.withDayOfWeek((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfDay(2, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfMinute(0, 2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendFractionOfSecond((int) (byte) 0, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder6.appendMinuteOfDay(30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime8 = dateTime4.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = dateTime4.minusMillis((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime4.minusDays(2);
        org.joda.time.DateTime dateTime14 = dateTime4.withCenturyOfEra((int) (short) 0);
        org.joda.time.DateTime.Property property15 = dateTime4.monthOfYear();
        try {
            org.joda.time.DateTime dateTime17 = property15.setCopy("ISOChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"ISOChronology[America/Los_Angeles]\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str9 = fixedDateTimeZone7.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology10.era();
        org.joda.time.Chronology chronology12 = zonedChronology10.withUTC();
        try {
            long long20 = zonedChronology10.getDateTimeMillis((int) 'a', (int) 'a', 6, 366, (int) 'a', (int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 366 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("15", 0, (int) (short) 1, 431);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for 15 must be in the range [1,431]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.DateTime dateTime9 = dateTime1.withYear((int) (short) 0);
//        org.joda.time.DateTime dateTime11 = dateTime1.minusWeeks((int) (short) 0);
//        java.lang.String str12 = dateTime11.toString();
//        org.joda.time.DateTime dateTime14 = dateTime11.plusSeconds((int) (byte) -1);
//        org.joda.time.DateTime.Property property15 = dateTime14.hourOfDay();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969-12-31T16:00:00.030-08:00" + "'", str12.equals("1969-12-31T16:00:00.030-08:00"));
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.dayOfWeek();
        org.joda.time.DateTime dateTime8 = property7.roundCeilingCopy();
        org.joda.time.DateMidnight dateMidnight9 = dateTime8.toDateMidnight();
        java.util.GregorianCalendar gregorianCalendar10 = dateTime8.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(gregorianCalendar10);
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readablePeriod8);
//        org.joda.time.DateTime dateTime11 = dateTime9.withHourOfDay((int) (byte) 1);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusWeeks(0);
//        org.joda.time.DateTime dateTime14 = dateTime13.toDateTimeISO();
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
//        try {
//            org.joda.time.DateTime dateTime17 = dateTime14.withField(dateTimeFieldType15, 16);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(1, 24, (-1), 97, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withPeriodAdded(readablePeriod3, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(readableDuration6, (int) (short) 100);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(chronology9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.withPeriodAdded(readablePeriod11, (int) (byte) 100);
        org.joda.time.DateTime dateTime15 = dateTime10.minusMinutes(0);
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime5, (org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now(chronology16);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter0.withChronology(chronology16);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter18.withPivotYear((java.lang.Integer) 1014);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test303");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readablePeriod8);
//        org.joda.time.DateTime dateTime11 = dateTime9.withHourOfDay((int) (byte) 1);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusWeeks(0);
//        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds((int) ' ');
//        org.joda.time.DateTime.Property property16 = dateTime13.weekyear();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) '4', (int) (short) 1, 100, 42, 2019, (int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 42 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(19, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test306");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readablePeriod8);
//        org.joda.time.DateTime.Property property10 = dateTime7.dayOfYear();
//        org.joda.time.DateTime dateTime11 = property10.roundFloorCopy();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.year();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfHour();
        try {
            long long11 = iSOChronology0.getDateTimeMillis((int) (byte) -1, 1, (int) '4', 905, 963, (int) (short) 0, 11687);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 905 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        long long11 = fixedDateTimeZone9.previousTransition(0L);
        long long13 = fixedDateTimeZone9.nextTransition((long) (byte) 0);
        long long15 = fixedDateTimeZone9.nextTransition((long) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        int int18 = cachedDateTimeZone16.getStandardOffset((long) (byte) 1);
        int int20 = cachedDateTimeZone16.getOffset((-61837261290390L));
        org.joda.time.DateTimeZone dateTimeZone21 = cachedDateTimeZone16.getUncachedZone();
        try {
            org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(365, 0, (int) (byte) 100, 1, 959, dateTimeZone21);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 959 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 100 + "'", int18 == 100);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
        org.junit.Assert.assertNotNull(dateTimeZone21);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendSecondOfMinute(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendCenturyOfEra(959, 6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        long long6 = fixedDateTimeZone4.previousTransition(0L);
        long long8 = fixedDateTimeZone4.nextTransition((long) (byte) 0);
        long long10 = fixedDateTimeZone4.nextTransition((long) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int13 = cachedDateTimeZone11.getStandardOffset((long) (byte) 1);
        int int15 = cachedDateTimeZone11.getStandardOffset((long) 1970);
        long long17 = cachedDateTimeZone11.previousTransition((long) ' ');
        long long19 = cachedDateTimeZone11.nextTransition((long) 674);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder22.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder22.appendDayOfWeek(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendPattern("");
        boolean boolean29 = cachedDateTimeZone11.equals((java.lang.Object) dateTimeFormatterBuilder28);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 32L + "'", long17 == 32L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 674L + "'", long19 == 674L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.DateTime.Property property6 = dateTime1.millisOfSecond();
//        int int7 = dateTime1.getDayOfWeek();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
//    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
//        java.lang.String str5 = offsetDateTimeField3.getAsText(0L);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str7 = iSOChronology6.toString();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.weekyearOfCentury();
//        org.joda.time.Chronology chronology9 = iSOChronology6.withUTC();
//        org.joda.time.DurationField durationField10 = iSOChronology6.eras();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology6);
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(chronology12);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime16 = dateTime13.withPeriodAdded(readablePeriod14, (int) (byte) 100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
//        boolean boolean18 = dateTime16.isSupported(dateTimeFieldType17);
//        org.joda.time.DateTime dateTime20 = dateTime16.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime22 = dateTime16.minusMillis((int) (byte) 10);
//        org.joda.time.LocalDate localDate23 = dateTime16.toLocalDate();
//        long long25 = iSOChronology6.set((org.joda.time.ReadablePartial) localDate23, (-6183726128855600L));
//        int[] intArray30 = new int[] { ' ', (-4), 19 };
//        try {
//            int[] intArray32 = offsetDateTimeField3.add((org.joda.time.ReadablePartial) localDate23, (int) (byte) 10, intArray30, (int) '4');
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "15" + "'", str5.equals("15"));
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str7.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-22833600L) + "'", long25 == (-22833600L));
//        org.junit.Assert.assertNotNull(intArray30);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str9 = fixedDateTimeZone7.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone7);
        try {
            long long18 = iSOChronology0.getDateTimeMillis(59, 19, 0, 19, 366, 24, 431);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 366 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology10);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime8 = dateTime4.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = dateTime8.plusMonths((int) (short) -1);
        try {
            org.joda.time.DateTime dateTime12 = dateTime10.withMonthOfYear(54330513);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 54330513 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) (byte) 100);
//        int int7 = dateTime3.getHourOfDay();
//        org.joda.time.DateTime.Property property8 = dateTime3.millisOfSecond();
//        boolean boolean10 = property8.equals((java.lang.Object) 100.0f);
//        org.joda.time.DateTime dateTime11 = property8.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime12 = property8.roundHalfFloorCopy();
//        org.joda.time.LocalTime localTime13 = dateTime12.toLocalTime();
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localTime13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(localTime13);
//    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test319");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.DateTime dateTime9 = dateTime1.withYear((int) (short) 0);
//        org.joda.time.DateTime dateTime11 = dateTime1.minusWeeks((int) (short) 0);
//        java.lang.String str12 = dateTime11.toString();
//        org.joda.time.DateTime.Property property13 = dateTime11.weekyear();
//        int int14 = dateTime11.getEra();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969-12-31T16:00:00.030-08:00" + "'", str12.equals("1969-12-31T16:00:00.030-08:00"));
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatterBuilder3.toParser();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendDayOfWeek(19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gregorianChronology0.equals(obj1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        java.util.TimeZone timeZone4 = dateTimeZone3.toTimeZone();
//        java.lang.String str6 = dateTimeZone3.getName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone3);
//        org.joda.time.Chronology chronology8 = gregorianChronology0.withZone(dateTimeZone3);
//        try {
//            org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3, 30);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 30");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(chronology8);
//    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test322");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readablePeriod8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfMonth();
//        java.util.Locale locale11 = null;
//        int int12 = property10.getMaximumShortTextLength(locale11);
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(chronology13);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) (byte) 100);
//        int int18 = dateTime14.getHourOfDay();
//        org.joda.time.DateTime.Property property19 = dateTime14.millisOfSecond();
//        org.joda.time.DateTime dateTime20 = property19.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(chronology21);
//        org.joda.time.ReadablePeriod readablePeriod23 = null;
//        org.joda.time.DateTime dateTime25 = dateTime22.withPeriodAdded(readablePeriod23, (int) (byte) 100);
//        int int26 = dateTime22.getHourOfDay();
//        org.joda.time.Chronology chronology27 = null;
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) dateTime22, chronology27);
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime28.minus(readablePeriod29);
//        long long31 = property19.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime28);
//        int int32 = property10.compareTo((org.joda.time.ReadableInstant) dateTime28);
//        org.joda.time.DateTime dateTime34 = property10.addToCopy((int) '#');
//        long long35 = property10.remainder();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 16 + "'", int18 == 16);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 16 + "'", int26 == 16);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 57600030L + "'", long35 == 57600030L);
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str10 = fixedDateTimeZone8.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology11.getZone();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(1560636316453L, dateTimeZone12);
        org.joda.time.DateTime.Property property14 = dateTime13.dayOfMonth();
        try {
            org.joda.time.DateTime dateTime16 = property14.setCopy("T16:00:00.000-08:00");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"T16:00:00.000-08:00\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(property14);
    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test324");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.lang.String str2 = dateTimeFormatter0.print(0L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZoneUTC();
//        try {
//            org.joda.time.LocalDate localDate5 = dateTimeFormatter3.parseLocalDate("");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "T16:00:00.000-08:00" + "'", str2.equals("T16:00:00.000-08:00"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (-61837261301676L), 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime8 = dateTime4.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = dateTime8.plusMonths((int) (short) -1);
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime12.withEarlierOffsetAtOverlap();
        try {
            org.joda.time.DateTime dateTime17 = dateTime12.withDate(0, 2019, 1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(1560636332628L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("", (int) (byte) 0, 67, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for  must be in the range [67,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
//        org.joda.time.DateMidnight dateMidnight7 = dateTime6.toDateMidnight();
//        org.joda.time.DateTime dateTime9 = dateTime6.minusHours(10);
//        org.joda.time.DateTime dateTime10 = dateTime9.toDateTimeISO();
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime15 = dateTime12.withPeriodAdded(readablePeriod13, (int) (byte) 100);
//        org.joda.time.DateTime dateTime17 = dateTime12.minusMinutes(0);
//        org.joda.time.DateMidnight dateMidnight18 = dateTime17.toDateMidnight();
//        org.joda.time.DateTime dateTime20 = dateTime17.minusHours(10);
//        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
//        int int22 = dateTime10.compareTo((org.joda.time.ReadableInstant) dateTime21);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateMidnight18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str10 = fixedDateTimeZone8.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology11.getZone();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(1560636316453L, dateTimeZone12);
        org.joda.time.DurationFieldType durationFieldType14 = null;
        try {
            org.joda.time.DateTime dateTime16 = dateTime13.withFieldAdded(durationFieldType14, 365);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str1 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField2 = iSOChronology0.minutes();
//        long long5 = durationField2.subtract(0L, (long) 2019);
//        long long8 = durationField2.subtract(1L, 0);
//        org.joda.time.DurationFieldType durationFieldType9 = null;
//        try {
//            org.joda.time.field.DecoratedDurationField decoratedDurationField10 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-121140000L) + "'", long5 == (-121140000L));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatterBuilder3.toParser();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap5);
        boolean boolean7 = dateTimeFormatterBuilder3.canBuildFormatter();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder3.appendTimeZoneOffset("ZonedChronology[ISOChronology[UTC], ]", true, 959, 366);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(19, 10, 905, (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.DateTime dateTime9 = dateTime1.withYear((int) (short) 0);
//        org.joda.time.DateTime dateTime11 = dateTime1.minusWeeks((int) (short) 0);
//        java.lang.String str12 = dateTime11.toString();
//        org.joda.time.DateTime.Property property13 = dateTime11.weekyear();
//        org.joda.time.DateTime dateTime15 = dateTime11.withWeekyear((int) (byte) -1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2068-11-27T12:11:17.584-08:00" + "'", str12.equals("2068-11-27T12:11:17.584-08:00"));
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test338");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str1 = iSOChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.era();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfHalfday();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime5 = dateTime4.withEarlierOffsetAtOverlap();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendClockhourOfDay((int) (byte) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendTimeZoneShortName();
//        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatterBuilder11.toParser();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap13 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendTimeZoneName(strMap13);
//        dateTimeFormatterBuilder11.clear();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder11.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendClockhourOfDay((int) (byte) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder18.appendYearOfEra((int) (byte) 100, 0);
//        org.joda.time.format.DateTimePrinter dateTimePrinter24 = dateTimeFormatterBuilder23.toPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.tTime();
//        org.joda.time.format.DateTimeParser dateTimeParser26 = dateTimeFormatter25.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter24, dateTimeParser26);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder17.appendOptional(dateTimeParser26);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter7, dateTimeParser26);
//        boolean boolean30 = dateTime5.equals((java.lang.Object) dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimePrinter7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeParser12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertNotNull(dateTimePrinter24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(dateTimeParser26);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test339");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str1 = iSOChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyear();
//        try {
//            long long9 = iSOChronology0.getDateTimeMillis((-61837261282318L), 11687, 0, 959, (int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 11687 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str10 = fixedDateTimeZone8.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology11.getZone();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(1560636316453L, dateTimeZone12);
        org.joda.time.DateTime dateTime15 = dateTime13.minusWeeks(24);
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.withDurationAdded(readableDuration16, 16);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
        long long5 = offsetDateTimeField3.roundCeiling((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField8 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType6, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField7 = iSOChronology6.eras();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.year();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology6.minuteOfHour();
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((int) (byte) 1, 2068, 42, 10, 2019, 3, (org.joda.time.Chronology) iSOChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test345");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
//        long long5 = offsetDateTimeField3.roundCeiling((long) (short) -1);
//        int int6 = offsetDateTimeField3.getMinimumValue();
//        boolean boolean8 = offsetDateTimeField3.isLeap((-61837261299738L));
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 15);
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(chronology13);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) (byte) 100);
//        org.joda.time.DateTime dateTime19 = dateTime14.minusMinutes(0);
//        org.joda.time.DateTime dateTime21 = dateTime14.withYearOfEra(10);
//        long long22 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.DateTime dateTime23 = dateTime21.withLaterOffsetAtOverlap();
//        boolean boolean25 = dateTime21.isEqual((long) 'a');
//        org.joda.time.Chronology chronology26 = null;
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(chronology26);
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.DateTime dateTime30 = dateTime27.withPeriodAdded(readablePeriod28, (int) (byte) 100);
//        org.joda.time.DateTime dateTime32 = dateTime27.minusMinutes(0);
//        org.joda.time.Chronology chronology33 = null;
//        org.joda.time.MutableDateTime mutableDateTime34 = dateTime27.toMutableDateTime(chronology33);
//        org.joda.time.LocalDate localDate35 = dateTime27.toLocalDate();
//        org.joda.time.DateTime dateTime36 = dateTime21.withFields((org.joda.time.ReadablePartial) localDate35);
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) localDate35, 3, locale38);
//        int[] intArray46 = new int[] { 1, 54330513, 97, 11, 993 };
//        java.util.Locale locale48 = null;
//        try {
//            int[] intArray49 = offsetDateTimeField3.set((org.joda.time.ReadablePartial) localDate35, 42, intArray46, "+00:00:00.010", locale48);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"+00:00:00.010\" for millisOfSecond is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-61823015743541L) + "'", long22 == (-61823015743541L));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(mutableDateTime34);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "3" + "'", str39.equals("3"));
//        org.junit.Assert.assertNotNull(intArray46);
//    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfDay(2, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfMinute(905, 15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.lang.Object obj7 = null;
//        boolean boolean8 = gregorianChronology6.equals(obj7);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        java.util.TimeZone timeZone10 = dateTimeZone9.toTimeZone();
//        java.lang.String str12 = dateTimeZone9.getName((long) (byte) 10);
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone9);
//        org.joda.time.Chronology chronology14 = gregorianChronology6.withZone(dateTimeZone9);
//        try {
//            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(365, 905, (int) (short) 100, 2, (int) (byte) -1, 30, chronology14);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Coordinated Universal Time" + "'", str12.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(chronology14);
//    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.era();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.clockhourOfHalfday();
//        try {
//            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) dateTimeField1, (org.joda.time.Chronology) iSOChronology2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDateTimeField");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str9 = fixedDateTimeZone7.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.hourOfDay();
        org.joda.time.Chronology chronology12 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology0.hourOfDay();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        long long17 = iSOChronology0.add(readablePeriod14, (-61837261299738L), (int) ' ');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61837261299738L) + "'", long17 == (-61837261299738L));
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readablePeriod8);
//        org.joda.time.DateTime dateTime11 = dateTime9.withHourOfDay((int) (byte) 1);
//        java.util.Date date12 = dateTime9.toDate();
//        org.joda.time.DateTime.Property property13 = dateTime9.weekOfWeekyear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        boolean boolean15 = property13.equals((java.lang.Object) dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(64, '#', 0, (int) (byte) 100, 5, true, 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder0.addRecurringSavings("", 2365, 2019, (int) (short) 100, 'a', 0, 993, 6, false, 5);
        java.io.OutputStream outputStream21 = null;
        try {
            dateTimeZoneBuilder0.writeTo("2019-06-15T15:05:24.687-07:00", outputStream21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder19);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(0, (int) (short) 100, 2, 11, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime8 = dateTime4.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = dateTime4.minusMillis((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime4.minusDays(2);
        org.joda.time.DateTime dateTime14 = dateTime4.withCenturyOfEra((int) (short) 0);
        org.joda.time.DateTime.Property property15 = dateTime4.monthOfYear();
        org.joda.time.DateTime dateTime17 = dateTime4.withMillisOfDay(905);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gregorianChronology0.equals(obj1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 15);
        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getDurationField();
        boolean boolean8 = offsetDateTimeField6.isSupported();
        boolean boolean9 = gregorianChronology0.equals((java.lang.Object) offsetDateTimeField6);
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology0.getZone();
        org.joda.time.Chronology chronology11 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test356");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        java.io.Writer writer1 = null;
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) (byte) 100);
//        int int7 = dateTime3.getHourOfDay();
//        org.joda.time.DateTime.Property property8 = dateTime3.millisOfSecond();
//        try {
//            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
//        org.junit.Assert.assertNotNull(property8);
//    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 3, 1560616766400L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560616766403L + "'", long2 == 1560616766403L);
    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.weekyearOfCentury();
//        org.joda.time.Chronology chronology5 = iSOChronology2.withUTC();
//        org.joda.time.DurationField durationField6 = iSOChronology2.eras();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology2);
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime12 = dateTime9.withPeriodAdded(readablePeriod10, (int) (byte) 100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
//        boolean boolean14 = dateTime12.isSupported(dateTimeFieldType13);
//        org.joda.time.DateTime dateTime16 = dateTime12.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime18 = dateTime12.minusMillis((int) (byte) 10);
//        org.joda.time.LocalDate localDate19 = dateTime12.toLocalDate();
//        long long21 = iSOChronology2.set((org.joda.time.ReadablePartial) localDate19, (-6183726128855600L));
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDate19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 3121263566400L + "'", long21 == 3121263566400L);
//    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(chronology4);
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.withPeriodAdded(readablePeriod6, (int) (byte) 100);
//        org.joda.time.DateTime dateTime10 = dateTime5.minusMinutes(0);
//        org.joda.time.DateTime dateTime12 = dateTime5.withYearOfEra(10);
//        long long13 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DateTime dateTime14 = dateTime12.withLaterOffsetAtOverlap();
//        boolean boolean16 = dateTime12.isEqual((long) 'a');
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(chronology17);
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.DateTime dateTime21 = dateTime18.withPeriodAdded(readablePeriod19, (int) (byte) 100);
//        org.joda.time.DateTime dateTime23 = dateTime18.minusMinutes(0);
//        org.joda.time.Chronology chronology24 = null;
//        org.joda.time.MutableDateTime mutableDateTime25 = dateTime18.toMutableDateTime(chronology24);
//        org.joda.time.LocalDate localDate26 = dateTime18.toLocalDate();
//        org.joda.time.DateTime dateTime27 = dateTime12.withFields((org.joda.time.ReadablePartial) localDate26);
//        java.util.Locale locale29 = null;
//        java.lang.String str30 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate26, 3, locale29);
//        org.joda.time.ReadablePartial readablePartial31 = null;
//        java.util.Locale locale32 = null;
//        try {
//            java.lang.String str33 = offsetDateTimeField3.getAsShortText(readablePartial31, locale32);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61823015742267L) + "'", long13 == (-61823015742267L));
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(mutableDateTime25);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "3" + "'", str30.equals("3"));
//    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
//        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
//        boolean boolean5 = offsetDateTimeField3.isSupported();
//        int int7 = offsetDateTimeField3.getMaximumValue((long) 5);
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime12 = dateTime9.withPeriodAdded(readablePeriod10, (int) (byte) 100);
//        int int13 = dateTime9.getHourOfDay();
//        long long14 = dateTime9.getMillis();
//        org.joda.time.DateTime dateTime16 = dateTime9.plus((long) 15);
//        org.joda.time.LocalTime localTime17 = dateTime9.toLocalTime();
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localTime17, 0, locale19);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1014 + "'", int7 == 1014);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3121272679752L + "'", long14 == 3121272679752L);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(localTime17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
//    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission5 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean6 = jodaTimePermission3.implies((java.security.Permission) jodaTimePermission5);
        jodaTimePermission5.checkGuard((java.lang.Object) "T16:00:00.000-08:00");
        boolean boolean9 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission5);
        java.lang.String str10 = jodaTimePermission5.getActions();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("Coordinated Universal Time", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Coordinated Universal Time/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.DateTime dateTime9 = dateTime1.withYear((int) (short) 0);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime1.plus(readablePeriod10);
//        try {
//            org.joda.time.DateTime dateTime13 = dateTime1.withSecondOfMinute(97);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test364");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readablePeriod8);
//        int int10 = dateTime9.getYearOfCentury();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 68 + "'", int10 == 68);
//    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) -1, 993, (int) (short) -1, (int) '#', (int) (short) 100, 79533557, 16, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
        int int4 = offsetDateTimeField3.getMaximumValue();
        java.lang.String str6 = offsetDateTimeField3.getAsText(0L);
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsShortText(59, locale8);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1014 + "'", int4 == 1014);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "59" + "'", str9.equals("59"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendDayOfWeek(10);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.withPeriodAdded(readablePeriod9, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded(readableDuration12, (int) (short) 100);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) (byte) 100);
        org.joda.time.DateTime dateTime21 = dateTime16.minusMinutes(0);
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime11, (org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now(chronology22);
        org.joda.time.DateTime.Property property24 = dateTime23.monthOfYear();
        org.joda.time.DateTime dateTime25 = property24.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, (java.lang.Number) 3L, "2019-06-15T15:05:30.038-07:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder2.appendShortText(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test368");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.era();
//        jodaTimePermission1.checkGuard((java.lang.Object) dateTimeField4);
//        java.lang.String str6 = jodaTimePermission1.getActions();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
//        jodaTimePermission1.checkGuard((java.lang.Object) property9);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendClockhourOfDay((int) (byte) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder13.appendTimeZoneShortName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.appendFractionOfDay(2, 0);
//        boolean boolean18 = dateTimeFormatterBuilder14.canBuildParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder14.appendFractionOfDay(97, (int) '4');
//        boolean boolean22 = jodaTimePermission1.equals((java.lang.Object) dateTimeFormatterBuilder21);
//        org.joda.time.Chronology chronology23 = null;
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(chronology23);
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime27 = dateTime24.withPeriodAdded(readablePeriod25, (int) (byte) 100);
//        int int28 = dateTime24.getHourOfDay();
//        org.joda.time.Chronology chronology29 = null;
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) dateTime24, chronology29);
//        org.joda.time.ReadablePeriod readablePeriod31 = null;
//        org.joda.time.DateTime dateTime32 = dateTime30.minus(readablePeriod31);
//        org.joda.time.DateTime dateTime34 = dateTime32.withHourOfDay((int) (byte) 1);
//        java.util.Date date35 = dateTime32.toDate();
//        org.joda.time.DateTime.Property property36 = dateTime32.weekOfWeekyear();
//        org.joda.time.DateTime.Property property37 = dateTime32.secondOfMinute();
//        boolean boolean38 = jodaTimePermission1.equals((java.lang.Object) dateTime32);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendDayOfWeek(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendSecondOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendWeekyear((int) (short) 100, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendSecondOfDay((int) (byte) 1);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendCenturyOfEra(0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readablePeriod8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfMonth();
//        java.util.Locale locale11 = null;
//        int int12 = property10.getMaximumShortTextLength(locale11);
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(chronology13);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) (byte) 100);
//        int int18 = dateTime14.getHourOfDay();
//        org.joda.time.DateTime.Property property19 = dateTime14.millisOfSecond();
//        org.joda.time.DateTime dateTime20 = property19.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(chronology21);
//        org.joda.time.ReadablePeriod readablePeriod23 = null;
//        org.joda.time.DateTime dateTime25 = dateTime22.withPeriodAdded(readablePeriod23, (int) (byte) 100);
//        int int26 = dateTime22.getHourOfDay();
//        org.joda.time.Chronology chronology27 = null;
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) dateTime22, chronology27);
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime28.minus(readablePeriod29);
//        long long31 = property19.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime28);
//        int int32 = property10.compareTo((org.joda.time.ReadableInstant) dateTime28);
//        int int33 = property10.getMaximumValue();
//        long long34 = property10.remainder();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 12 + "'", int18 == 12);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 30 + "'", int33 == 30);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 43880629L + "'", long34 == 43880629L);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readablePeriod8);
//        org.joda.time.DateTime dateTime11 = dateTime9.withHourOfDay((int) (byte) 1);
//        java.util.Date date12 = dateTime9.toDate();
//        org.joda.time.DateTime.Property property13 = dateTime9.weekOfWeekyear();
//        java.lang.String str14 = property13.getAsShortText();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "48" + "'", str14.equals("48"));
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("2019-06-15T15:05:26.574-07:00");
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendHourOfHalfday(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendLiteral("2019-06-15T05:05:22.051-07:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.appendClockhourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder3.appendFractionOfDay((int) (short) 10, 24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendDayOfWeek(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendSecondOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendWeekyear((int) (short) 100, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendTimeZoneId();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

//    @Test
//    public void test376() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test376");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.DateTime dateTime9 = dateTime1.withYear((int) (short) 0);
//        org.joda.time.DateTime dateTime11 = dateTime1.minusWeeks((int) (short) 0);
//        java.lang.String str12 = dateTime11.toString();
//        org.joda.time.DateTime dateTime14 = dateTime11.plusSeconds((int) (byte) -1);
//        org.joda.time.DateTime dateTime16 = dateTime11.withWeekyear(0);
//        org.joda.time.DateTime.Property property17 = dateTime11.hourOfDay();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2068-11-27T12:11:21.495-08:00" + "'", str12.equals("2068-11-27T12:11:21.495-08:00"));
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 1024L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(12, (int) '4', (int) '4', 1970, 2068, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test379");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.DateTime.Property property6 = dateTime1.millisOfSecond();
//        boolean boolean8 = property6.equals((java.lang.Object) 100.0f);
//        org.joda.time.DateTime dateTime9 = property6.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime10 = property6.roundHalfFloorCopy();
//        boolean boolean11 = property6.isLeap();
//        int int12 = property6.getMinimumValueOverall();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test380");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
//        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(10);
//        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime10 = dateTime8.withLaterOffsetAtOverlap();
//        boolean boolean12 = dateTime8.isEqual((long) 'a');
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(chronology13);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) (byte) 100);
//        org.joda.time.DateTime dateTime19 = dateTime14.minusMinutes(0);
//        org.joda.time.Chronology chronology20 = null;
//        org.joda.time.MutableDateTime mutableDateTime21 = dateTime14.toMutableDateTime(chronology20);
//        org.joda.time.LocalDate localDate22 = dateTime14.toLocalDate();
//        org.joda.time.DateTime dateTime23 = dateTime8.withFields((org.joda.time.ReadablePartial) localDate22);
//        org.joda.time.DateTime dateTime25 = dateTime8.plusWeeks((int) '#');
//        org.joda.time.DateTime dateTime26 = dateTime25.withEarlierOffsetAtOverlap();
//        try {
//            org.joda.time.DateTime dateTime28 = dateTime25.withHourOfDay(690);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 690 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61823015740013L) + "'", long9 == (-61823015740013L));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(mutableDateTime21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime26);
//    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        java.util.TimeZone timeZone1 = dateTimeZone0.toTimeZone();
        try {
            org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.tz.FixedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(timeZone1);
    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test382");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
//        org.joda.time.DateTime dateTime8 = dateTime4.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime10 = dateTime8.plusMonths((int) (short) -1);
//        org.joda.time.DateTime.Property property11 = dateTime8.centuryOfEra();
//        org.joda.time.DateTime dateTime13 = property11.addToCopy(2019);
//        int int14 = dateTime13.getMillisOfSecond();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 36 + "'", int14 == 36);
//    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readablePeriod8);
//        org.joda.time.DateTime dateTime11 = dateTime9.withHourOfDay((int) (byte) 1);
//        java.util.Date date12 = dateTime9.toDate();
//        org.joda.time.DateTime.Property property13 = dateTime9.weekOfWeekyear();
//        java.lang.String str14 = property13.toString();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Property[weekOfWeekyear]" + "'", str14.equals("Property[weekOfWeekyear]"));
//    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readablePeriod8);
//        org.joda.time.DateTime.Property property10 = dateTime7.dayOfYear();
//        org.joda.time.DateTime dateTime11 = property10.roundCeilingCopy();
//        org.joda.time.DateTime dateTime13 = property10.addToCopy((-1));
//        try {
//            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) (-1));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
//        org.joda.time.DateTime dateTime8 = dateTime4.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime10 = dateTime4.minusMillis((int) (byte) 10);
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime15 = dateTime12.withPeriodAdded(readablePeriod13, (int) (byte) 100);
//        org.joda.time.DateTime dateTime17 = dateTime12.minusMinutes(0);
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.MutableDateTime mutableDateTime19 = dateTime12.toMutableDateTime(chronology18);
//        int int20 = dateTime10.compareTo((org.joda.time.ReadableInstant) mutableDateTime19);
//        int int21 = dateTime10.getDayOfWeek();
//        org.joda.time.ReadableDuration readableDuration22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime10.plus(readableDuration22);
//        org.joda.time.DateTime.Property property24 = dateTime23.secondOfDay();
//        boolean boolean26 = dateTime23.isBefore((-1174907964582846L));
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(1014, 12, 959);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 66 + "'", int3 == 66);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str9 = fixedDateTimeZone7.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone11 = zonedChronology10.getZone();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        long long15 = zonedChronology10.add(readablePeriod12, (long) 'a', 674);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 97L + "'", long15 == 97L);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test389() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test389");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.DateTime.Property property6 = dateTime1.millisOfSecond();
//        boolean boolean8 = property6.equals((java.lang.Object) 100.0f);
//        org.joda.time.DateTime dateTime9 = property6.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime10 = property6.roundHalfFloorCopy();
//        int int11 = property6.get();
//        org.joda.time.DateTime dateTime12 = property6.getDateTime();
//        org.joda.time.DurationField durationField13 = property6.getLeapDurationField();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 578 + "'", int11 == 578);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNull(durationField13);
//    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime8 = dateTime4.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = dateTime4.minusMillis((int) (byte) 10);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.withPeriodAdded(readablePeriod13, (int) (byte) 100);
        org.joda.time.DateTime dateTime17 = dateTime12.minusMinutes(0);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.MutableDateTime mutableDateTime19 = dateTime12.toMutableDateTime(chronology18);
        int int20 = dateTime10.compareTo((org.joda.time.ReadableInstant) mutableDateTime19);
        org.joda.time.DateTime.Property property21 = dateTime10.yearOfCentury();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(property21);
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test391");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.DateTime.Property property6 = dateTime1.millisOfSecond();
//        boolean boolean8 = property6.equals((java.lang.Object) 100.0f);
//        org.joda.time.DateTime dateTime9 = property6.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime10 = property6.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime11 = property6.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime12 = property6.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField13 = property6.getRangeDurationField();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readablePeriod8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfMonth();
//        java.util.Locale locale11 = null;
//        int int12 = property10.getMaximumShortTextLength(locale11);
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(chronology13);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) (byte) 100);
//        int int18 = dateTime14.getHourOfDay();
//        org.joda.time.DateTime.Property property19 = dateTime14.millisOfSecond();
//        org.joda.time.DateTime dateTime20 = property19.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(chronology21);
//        org.joda.time.ReadablePeriod readablePeriod23 = null;
//        org.joda.time.DateTime dateTime25 = dateTime22.withPeriodAdded(readablePeriod23, (int) (byte) 100);
//        int int26 = dateTime22.getHourOfDay();
//        org.joda.time.Chronology chronology27 = null;
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) dateTime22, chronology27);
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime28.minus(readablePeriod29);
//        long long31 = property19.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime28);
//        int int32 = property10.compareTo((org.joda.time.ReadableInstant) dateTime28);
//        java.util.Locale locale33 = null;
//        int int34 = property10.getMaximumTextLength(locale33);
//        java.lang.String str35 = property10.getName();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 12 + "'", int18 == 12);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2 + "'", int34 == 2);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "dayOfMonth" + "'", str35.equals("dayOfMonth"));
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 16, (long) 674);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10784 + "'", int2 == 10784);
    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZoneUTC();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(chronology3);
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, (int) (byte) 100);
//        org.joda.time.DateTime dateTime9 = dateTime4.minusMinutes(0);
//        org.joda.time.DateTime dateTime11 = dateTime4.withYearOfEra(10);
//        long long12 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTime dateTime13 = dateTime11.withLaterOffsetAtOverlap();
//        boolean boolean15 = dateTime11.isEqual((long) 'a');
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (byte) 100);
//        org.joda.time.DateTime dateTime22 = dateTime17.minusMinutes(0);
//        org.joda.time.Chronology chronology23 = null;
//        org.joda.time.MutableDateTime mutableDateTime24 = dateTime17.toMutableDateTime(chronology23);
//        org.joda.time.LocalDate localDate25 = dateTime17.toLocalDate();
//        org.joda.time.DateTime dateTime26 = dateTime11.withFields((org.joda.time.ReadablePartial) localDate25);
//        java.lang.String str27 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate25);
//        try {
//            org.joda.time.LocalDate localDate29 = dateTimeFormatter0.parseLocalDate("2068-11-27T12:11:17.584-08:00");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2068-11-27T12:11:17.584-08:00\" is malformed at \"-11-27T12:11:17.584-08:00\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimePrinter1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61823015739142L) + "'", long12 == (-61823015739142L));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2068-W48" + "'", str27.equals("2068-W48"));
//    }

//    @Test
//    public void test395() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test395");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gregorianChronology0.equals(obj1);
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 15);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getDurationField();
//        boolean boolean8 = offsetDateTimeField6.isSupported();
//        boolean boolean9 = gregorianChronology0.equals((java.lang.Object) offsetDateTimeField6);
//        org.joda.time.DateTimeField dateTimeField10 = offsetDateTimeField6.getWrappedField();
//        long long12 = offsetDateTimeField6.roundHalfCeiling(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimePrinter dateTimePrinter14 = dateTimeFormatter13.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withZoneUTC();
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (byte) 100);
//        org.joda.time.DateTime dateTime22 = dateTime17.minusMinutes(0);
//        org.joda.time.DateTime dateTime24 = dateTime17.withYearOfEra(10);
//        long long25 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTime dateTime26 = dateTime24.withLaterOffsetAtOverlap();
//        boolean boolean28 = dateTime24.isEqual((long) 'a');
//        org.joda.time.Chronology chronology29 = null;
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(chronology29);
//        org.joda.time.ReadablePeriod readablePeriod31 = null;
//        org.joda.time.DateTime dateTime33 = dateTime30.withPeriodAdded(readablePeriod31, (int) (byte) 100);
//        org.joda.time.DateTime dateTime35 = dateTime30.minusMinutes(0);
//        org.joda.time.Chronology chronology36 = null;
//        org.joda.time.MutableDateTime mutableDateTime37 = dateTime30.toMutableDateTime(chronology36);
//        org.joda.time.LocalDate localDate38 = dateTime30.toLocalDate();
//        org.joda.time.DateTime dateTime39 = dateTime24.withFields((org.joda.time.ReadablePartial) localDate38);
//        java.lang.String str40 = dateTimeFormatter13.print((org.joda.time.ReadablePartial) localDate38);
//        int[] intArray46 = new int[] { 1970, 42, 0, 54330513, 0 };
//        int int47 = offsetDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDate38, intArray46);
//        java.lang.String str48 = offsetDateTimeField6.toString();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(dateTimePrinter14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-61823015739109L) + "'", long25 == (-61823015739109L));
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(mutableDateTime37);
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "2068-W48" + "'", str40.equals("2068-W48"));
//        org.junit.Assert.assertNotNull(intArray46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1014 + "'", int47 == 1014);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str48.equals("DateTimeField[millisOfSecond]"));
//    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.DateTime.Property property6 = dateTime1.millisOfSecond();
//        boolean boolean8 = property6.equals((java.lang.Object) 100.0f);
//        org.joda.time.DateTime dateTime9 = property6.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime10 = property6.roundHalfFloorCopy();
//        boolean boolean11 = property6.isLeap();
//        org.joda.time.DateTime dateTime13 = property6.addToCopy((long) (byte) 0);
//        int int14 = dateTime13.getEra();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
        java.lang.Integer int3 = dateTimeFormatter2.getPivotYear();
        java.io.Writer writer4 = null;
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.withPeriodAdded(readablePeriod7, (int) (byte) 100);
        org.joda.time.DateTime dateTime11 = dateTime6.minusMinutes(0);
        org.joda.time.DateTime dateTime13 = dateTime6.withYearOfEra(10);
        org.joda.time.DateTime dateTime15 = dateTime6.withMinuteOfHour(1);
        try {
            dateTimeFormatter2.printTo(writer4, (org.joda.time.ReadableInstant) dateTime6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(int3);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
        boolean boolean5 = offsetDateTimeField3.isSupported();
        long long7 = offsetDateTimeField3.roundCeiling((long) 3);
        boolean boolean9 = offsetDateTimeField3.isLeap(101L);
        long long12 = offsetDateTimeField3.add((long) 'a', 79533557);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3L + "'", long7 == 3L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 79533654L + "'", long12 == 79533654L);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 100L, (java.lang.Number) (-3L), (java.lang.Number) (byte) 1);
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) 97);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 230);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 230 + "'", int1 == 230);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendDayOfWeek(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendLiteral('4');
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(chronology9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.withPeriodAdded(readablePeriod11, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.withDurationAdded(readableDuration14, (int) (short) 100);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(chronology17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime21 = dateTime18.withPeriodAdded(readablePeriod19, (int) (byte) 100);
        org.joda.time.DateTime dateTime23 = dateTime18.minusMinutes(0);
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime13, (org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now(chronology24);
        org.joda.time.DateTime.Property property26 = dateTime25.monthOfYear();
        org.joda.time.DateTime dateTime27 = property26.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property26.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 3L, "2019-06-15T15:05:30.038-07:00");
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder2.appendFraction(dateTimeFieldType28, (-1), (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime8 = dateTime4.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = dateTime8.plusMonths((int) (short) -1);
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime12.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime15 = dateTime12.withWeekyear(578);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        long long7 = fixedDateTimeZone5.previousTransition(0L);
        long long9 = fixedDateTimeZone5.nextTransition((long) (byte) 0);
        long long11 = fixedDateTimeZone5.nextTransition((long) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        int int14 = cachedDateTimeZone12.getStandardOffset((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone15 = cachedDateTimeZone12.getUncachedZone();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((-61837261293575L), dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertNotNull(dateTimeZone15);
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.DateTime.Property property6 = dateTime1.millisOfSecond();
//        boolean boolean8 = property6.equals((java.lang.Object) 100.0f);
//        org.joda.time.DateTime dateTime9 = property6.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime10 = property6.roundHalfFloorCopy();
//        boolean boolean11 = property6.isLeap();
//        org.joda.time.DateTime dateTime13 = property6.addToCopy((long) (byte) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfSecond();
//        int int16 = dateTime13.get(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 17 + "'", int16 == 17);
//    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test407");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        long long6 = dateTime1.getMillis();
//        org.joda.time.DateTime dateTime8 = dateTime1.plus((long) 15);
//        org.joda.time.DateTime dateTime10 = dateTime8.minusSeconds((int) (byte) 100);
//        org.joda.time.DateTime.Property property11 = dateTime10.year();
//        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime10);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 3121272684132L + "'", long6 == 3121272684132L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(chronology12);
//    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfDay(2, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfMinute(0, 2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendSecondOfMinute((int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder9.appendSignedDecimal(dateTimeFieldType12, 15, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

//    @Test
//    public void test409() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test409");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
//        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime10 = dateTime7.withPeriodAdded(readablePeriod8, (int) (byte) 100);
//        int int11 = dateTime7.getHourOfDay();
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) dateTime7, chronology12);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime13.minus(readablePeriod14);
//        org.joda.time.LocalDateTime localDateTime16 = dateTime15.toLocalDateTime();
//        boolean boolean17 = dateTimeZone5.isLocalDateTimeGap(localDateTime16);
//        int[] intArray19 = null;
//        int[] intArray21 = offsetDateTimeField3.addWrapPartial((org.joda.time.ReadablePartial) localDateTime16, 0, intArray19, 0);
//        long long23 = offsetDateTimeField3.roundHalfEven((long) 97);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(localDateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNull(intArray21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
//    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfDay(3);
        try {
            java.lang.String str8 = dateTime4.toString("ZonedChronology[ISOChronology[UTC], ]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: o");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readablePeriod8);
//        org.joda.time.DateTime.Property property10 = dateTime7.dayOfYear();
//        org.joda.time.DateTime dateTime11 = property10.roundCeilingCopy();
//        java.util.Locale locale13 = null;
//        org.joda.time.DateTime dateTime14 = property10.setCopy("6", locale13);
//        int int15 = dateTime14.getSecondOfMinute();
//        org.joda.time.DateTime dateTime17 = dateTime14.withMinuteOfHour(0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 24 + "'", int15 == 24);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readablePeriod8);
//        int int10 = dateTime7.getYear();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime7.minus(readablePeriod11);
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        try {
//            int int14 = dateTime12.compareTo(readableInstant13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2068 + "'", int10 == 2068);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str10 = fixedDateTimeZone8.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology11.getZone();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(1560636316453L, dateTimeZone12);
        org.joda.time.DateTime.Property property14 = dateTime13.dayOfMonth();
        java.util.Locale locale15 = null;
        int int16 = property14.getMaximumTextLength(locale15);
        org.joda.time.DateTime dateTime17 = property14.roundFloorCopy();
        org.joda.time.DateTime dateTime19 = dateTime17.plusSeconds(1);
        boolean boolean21 = dateTime17.isBefore(0L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

//    @Test
//    public void test415() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test415");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime1.toMutableDateTime(chronology7);
//        org.joda.time.DateTime dateTime10 = dateTime1.withHourOfDay((int) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
//        java.util.TimeZone timeZone12 = dateTimeZone11.toTimeZone();
//        java.lang.String str14 = dateTimeZone11.getName((long) (byte) 10);
//        org.joda.time.DateTime dateTime15 = dateTime1.toDateTime(dateTimeZone11);
//        org.joda.time.DateTime dateTime17 = dateTime15.plusHours((int) '4');
//        org.joda.time.DateTime.Property property18 = dateTime15.minuteOfHour();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Coordinated Universal Time" + "'", str14.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-15T15:05:30.038-07:00");
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) "2019-06-15T15:05:30.038-07:00");
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        long long11 = fixedDateTimeZone9.previousTransition(0L);
        long long13 = fixedDateTimeZone9.nextTransition((long) (byte) 0);
        long long15 = fixedDateTimeZone9.nextTransition((long) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        int int18 = cachedDateTimeZone16.getStandardOffset((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone16.getUncachedZone();
        try {
            org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(959, 0, 0, 79533557, 4, dateTimeZone19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 79533557 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 100 + "'", int18 == 100);
        org.junit.Assert.assertNotNull(dateTimeZone19);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendDayOfWeek(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendSecondOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendWeekyear((int) (short) 100, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendSecondOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder8.appendLiteral('a');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) 905);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

//    @Test
//    public void test420() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test420");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
//        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(10);
//        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime10 = dateTime8.withLaterOffsetAtOverlap();
//        boolean boolean12 = dateTime8.isEqual((long) 'a');
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(chronology13);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) (byte) 100);
//        org.joda.time.DateTime dateTime19 = dateTime14.minusMinutes(0);
//        org.joda.time.Chronology chronology20 = null;
//        org.joda.time.MutableDateTime mutableDateTime21 = dateTime14.toMutableDateTime(chronology20);
//        org.joda.time.LocalDate localDate22 = dateTime14.toLocalDate();
//        org.joda.time.DateTime dateTime23 = dateTime8.withFields((org.joda.time.ReadablePartial) localDate22);
//        org.joda.time.DateTime dateTime25 = dateTime8.plusWeeks((int) '#');
//        org.joda.time.DateTime dateTime26 = dateTime25.withEarlierOffsetAtOverlap();
//        try {
//            org.joda.time.DateTime dateTime30 = dateTime26.withDate(0, 1014, (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1014 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61823015736290L) + "'", long9 == (-61823015736290L));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(mutableDateTime21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime26);
//    }

//    @Test
//    public void test421() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test421");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, chronology1);
//        int int3 = dateTime2.getWeekyear();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(chronology4);
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.withPeriodAdded(readablePeriod6, (int) (byte) 100);
//        org.joda.time.DateTime dateTime10 = dateTime8.minusMillis((int) 'a');
//        org.joda.time.DateTime.Property property11 = dateTime10.dayOfWeek();
//        org.joda.time.DateTime dateTime12 = property11.roundCeilingCopy();
//        org.joda.time.DateMidnight dateMidnight13 = dateTime12.toDateMidnight();
//        boolean boolean14 = dateTime2.isBefore((org.joda.time.ReadableInstant) dateMidnight13);
//        int int15 = dateMidnight13.getWeekOfWeekyear();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1970 + "'", int3 == 1970);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateMidnight13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 48 + "'", int15 == 48);
//    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("T16:00:00.000-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"T16:00:00.000-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (-121140000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readablePeriod8);
//        org.joda.time.DateTime.Property property10 = dateTime7.yearOfCentury();
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime15 = dateTime12.withPeriodAdded(readablePeriod13, (int) (byte) 100);
//        int int16 = dateTime12.getHourOfDay();
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) dateTime12, chronology17);
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime18.minus(readablePeriod19);
//        org.joda.time.DateTime dateTime22 = dateTime20.withHourOfDay((int) (byte) 1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        boolean boolean24 = dateTime20.isSupported(dateTimeFieldType23);
//        int int25 = property10.compareTo((org.joda.time.ReadableInstant) dateTime20);
//        int int26 = dateTime20.getMinuteOfHour();
//        org.joda.time.DateTime dateTime28 = dateTime20.minus((-61837261301676L));
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 11 + "'", int26 == 11);
//        org.junit.Assert.assertNotNull(dateTime28);
//    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfEra((int) '#', (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendDayOfWeek(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendHourOfHalfday(15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendFractionOfSecond(0, 2000);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.append(dateTimeFormatter12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No formatter supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(578, 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 582 + "'", int2 == 582);
    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str1 = iSOChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
//        long long7 = offsetDateTimeField5.roundHalfCeiling(79533557L);
//        long long9 = offsetDateTimeField5.roundFloor(0L);
//        try {
//            long long12 = offsetDateTimeField5.set(1L, 16);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 16 for dayOfWeek must be in the range [366,372]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 115200000L + "'", long7 == 115200000L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-57600000L) + "'", long9 == (-57600000L));
//    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("DateTimeField[millisOfSecond]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"DateTimeField[millisOfSecond]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
//        org.joda.time.DateTime dateTime8 = dateTime4.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime10 = dateTime8.plusMonths((int) (short) -1);
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
//        org.joda.time.DateTime.Property property12 = dateTime10.dayOfWeek();
//        org.joda.time.DateTime dateTime17 = dateTime10.withTime(19, 19, 0, 100);
//        int int18 = dateTime17.getDayOfMonth();
//        org.joda.time.DateTime.Property property19 = dateTime17.hourOfDay();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 27 + "'", int18 == 27);
//        org.junit.Assert.assertNotNull(property19);
//    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
//        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
//        boolean boolean5 = offsetDateTimeField3.isSupported();
//        long long7 = offsetDateTimeField3.roundCeiling((long) 3);
//        boolean boolean9 = offsetDateTimeField3.isLeap(101L);
//        long long11 = offsetDateTimeField3.roundFloor(0L);
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(chronology12);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime16 = dateTime13.withPeriodAdded(readablePeriod14, (int) (byte) 100);
//        org.joda.time.DateTime dateTime18 = dateTime13.minusMinutes(0);
//        org.joda.time.DateTime dateTime20 = dateTime13.withYearOfEra(10);
//        long long21 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.DateTime dateTime22 = dateTime20.withLaterOffsetAtOverlap();
//        boolean boolean24 = dateTime20.isEqual((long) 'a');
//        org.joda.time.Chronology chronology25 = null;
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(chronology25);
//        org.joda.time.ReadablePeriod readablePeriod27 = null;
//        org.joda.time.DateTime dateTime29 = dateTime26.withPeriodAdded(readablePeriod27, (int) (byte) 100);
//        org.joda.time.DateTime dateTime31 = dateTime26.minusMinutes(0);
//        org.joda.time.Chronology chronology32 = null;
//        org.joda.time.MutableDateTime mutableDateTime33 = dateTime26.toMutableDateTime(chronology32);
//        org.joda.time.LocalDate localDate34 = dateTime26.toLocalDate();
//        org.joda.time.DateTime dateTime35 = dateTime20.withFields((org.joda.time.ReadablePartial) localDate34);
//        java.util.Locale locale36 = null;
//        try {
//            java.lang.String str37 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate34, locale36);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfSecond' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3L + "'", long7 == 3L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61823015735832L) + "'", long21 == (-61823015735832L));
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(mutableDateTime33);
//        org.junit.Assert.assertNotNull(localDate34);
//        org.junit.Assert.assertNotNull(dateTime35);
//    }

//    @Test
//    public void test431() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test431");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readablePeriod8);
//        org.joda.time.DateTime.Property property10 = dateTime7.dayOfYear();
//        org.joda.time.DateTime dateTime11 = property10.roundCeilingCopy();
//        java.util.Locale locale13 = null;
//        org.joda.time.DateTime dateTime14 = property10.setCopy("6", locale13);
//        org.joda.time.DateTime dateTime15 = dateTime14.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime17 = dateTime15.withMinuteOfHour(0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, 973L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime8 = dateTime4.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = dateTime8.plusMonths((int) (short) -1);
        org.joda.time.DateTime.Property property11 = dateTime8.centuryOfEra();
        org.joda.time.DateTime.Property property12 = dateTime8.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
//        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(10);
//        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime10 = dateTime8.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property11 = dateTime8.dayOfWeek();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61823015735636L) + "'", long9 == (-61823015735636L));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str9 = fixedDateTimeZone7.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.hourOfDay();
        org.joda.time.Chronology chronology12 = iSOChronology0.withUTC();
        try {
            long long17 = iSOChronology0.getDateTimeMillis(0, 690, 0, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 690 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 0, (int) (byte) 1, 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 30 + "'", int3 == 30);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("0010-06-15T15:05:33.444-07:52:58", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"0010-06-15T15:05:33.444-07:52:58\" is malformed at \"-15T15:05:33.444-07:52:58\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
        int int6 = offsetDateTimeField3.getMinimumValue((-61837261293834L));
        long long8 = offsetDateTimeField3.remainder((long) 690);
        java.util.Locale locale9 = null;
        int int10 = offsetDateTimeField3.getMaximumShortTextLength(locale9);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str1 = iSOChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
//        org.joda.time.DurationField durationField4 = iSOChronology0.seconds();
//        try {
//            long long12 = iSOChronology0.getDateTimeMillis((int) (short) -1, 30, (int) (short) -1, 963, 54330513, 2068, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 963 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendYearOfEra((int) (byte) 100, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test442");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.withPeriodAdded(readablePeriod3, (int) (byte) 100);
//        int int6 = dateTime2.getHourOfDay();
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) dateTime2, chronology7);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime8.minus(readablePeriod9);
//        org.joda.time.DateTime.Property property11 = dateTime8.dayOfYear();
//        org.joda.time.DateTime dateTime12 = property11.roundCeilingCopy();
//        java.util.Locale locale14 = null;
//        org.joda.time.DateTime dateTime15 = property11.setCopy("6", locale14);
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 963, chronology16);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(chronology16);
//    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readablePeriod8);
//        org.joda.time.LocalDateTime localDateTime10 = dateTime9.toLocalDateTime();
//        try {
//            org.joda.time.DateTime dateTime12 = dateTime9.withSecondOfMinute(2000);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(localDateTime10);
//    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(17, 0, 1, (-26570460), 10, 15, 27, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -26570460 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test446() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test446");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str1 = iSOChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.era();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.weekyearOfCentury();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test447");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.DateTime.Property property6 = dateTime1.millisOfSecond();
//        boolean boolean8 = property6.equals((java.lang.Object) 100.0f);
//        org.joda.time.DateTime dateTime9 = property6.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime10 = property6.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime11 = property6.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime12 = property6.withMinimumValue();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(64, '#', 0, (int) (byte) 100, 5, true, 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder0.addRecurringSavings("", 2365, 2019, (int) (short) 100, 'a', 0, 993, 6, false, 5);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder27 = dateTimeZoneBuilder0.addCutover((-1), '#', 0, (int) ' ', (int) (byte) 0, true, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder19);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 3L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatterBuilder3.toParser();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField9 = iSOChronology8.eras();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str17 = fixedDateTimeZone15.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology8, (org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology8.hourOfDay();
        org.joda.time.Chronology chronology20 = iSOChronology8.withUTC();
        try {
            org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatterBuilder7, (org.joda.time.Chronology) iSOChronology8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatterBuilder");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(chronology20);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.DataOutput dataOutput2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("48", dataOutput2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear(10);
        java.lang.Class<?> wildcardClass6 = dateTimeFormatterBuilder2.getClass();
        dateTimeFormatterBuilder2.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder2.appendFractionOfMinute(0, 963);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

//    @Test
//    public void test453() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test453");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
//        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(10);
//        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime10 = dateTime8.withLaterOffsetAtOverlap();
//        boolean boolean12 = dateTime8.isEqual((long) 'a');
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(chronology13);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) (byte) 100);
//        org.joda.time.DateTime dateTime19 = dateTime14.minusMinutes(0);
//        org.joda.time.Chronology chronology20 = null;
//        org.joda.time.MutableDateTime mutableDateTime21 = dateTime14.toMutableDateTime(chronology20);
//        org.joda.time.LocalDate localDate22 = dateTime14.toLocalDate();
//        org.joda.time.DateTime dateTime23 = dateTime8.withFields((org.joda.time.ReadablePartial) localDate22);
//        boolean boolean24 = dateTime8.isEqualNow();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61823015734151L) + "'", long9 == (-61823015734151L));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(mutableDateTime21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//    }

//    @Test
//    public void test454() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test454");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.era();
//        jodaTimePermission1.checkGuard((java.lang.Object) dateTimeField4);
//        java.lang.String str6 = jodaTimePermission1.getActions();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
//        jodaTimePermission1.checkGuard((java.lang.Object) property9);
//        java.lang.String str11 = jodaTimePermission1.toString();
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str11.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
//    }

//    @Test
//    public void test455() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test455");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
//        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(10);
//        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime10 = dateTime8.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime12 = dateTime8.plus((long) 100);
//        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((int) (short) 100);
//        org.joda.time.DateTime.Property property15 = dateTime12.dayOfMonth();
//        org.joda.time.ReadableDuration readableDuration16 = null;
//        org.joda.time.DateTime dateTime18 = dateTime12.withDurationAdded(readableDuration16, (int) (short) 1);
//        org.joda.time.DateTime dateTime20 = dateTime18.minusMinutes(79533557);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61823015734014L) + "'", long9 == (-61823015734014L));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str9 = fixedDateTimeZone7.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology0.minuteOfHour();
        try {
            long long20 = iSOChronology0.getDateTimeMillis(366, (int) (short) -1, 27, 30, 1970, 1, 11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 30 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gregorianChronology0.equals(obj1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 15);
        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getDurationField();
        boolean boolean8 = offsetDateTimeField6.isSupported();
        boolean boolean9 = gregorianChronology0.equals((java.lang.Object) offsetDateTimeField6);
        int int11 = offsetDateTimeField6.get((-61837261290785L));
        long long13 = offsetDateTimeField6.roundFloor(79533557L);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField6.getAsShortText(2000, locale15);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 230 + "'", int11 == 230);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 79533557L + "'", long13 == 79533557L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2000" + "'", str16.equals("2000"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval3);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        boolean boolean8 = dateTime6.isSupported(dateTimeFieldType7);
        java.util.GregorianCalendar gregorianCalendar9 = dateTime6.toGregorianCalendar();
        org.joda.time.DateTime dateTime10 = dateTime6.toDateTime();
        try {
            org.joda.time.DateTime dateTime12 = dateTime10.withSecondOfMinute((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(413, (int) (short) 1, 963, (int) 'a', 36);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(64, '#', 0, (int) (byte) 100, 5, true, 0);
        java.io.OutputStream outputStream10 = null;
        try {
            dateTimeZoneBuilder8.writeTo("", outputStream10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
        org.joda.time.DateMidnight dateMidnight7 = dateTime6.toDateMidnight();
        org.joda.time.DateTime dateTime9 = dateTime6.withYear(365);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateMidnight7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfDay(2, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfMinute(0, 2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendFractionOfSecond((int) (byte) 0, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder6.appendMonthOfYear(963);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder6.appendMillisOfSecond((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
//        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(10);
//        org.joda.time.DateTime dateTime10 = dateTime8.minus(1560636316530L);
//        int int11 = dateTime10.getHourOfDay();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 14 + "'", int11 == 14);
//    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "2019-06-15T15:05:28.760-07:00");
        java.lang.Throwable throwable3 = null;
        try {
            illegalFieldValueException2.addSuppressed(throwable3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test466");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readablePeriod8);
//        org.joda.time.DateTime dateTime11 = dateTime9.withHourOfDay((int) (byte) 1);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusWeeks(0);
//        org.joda.time.Chronology chronology14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(chronology14);
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.withPeriodAdded(readablePeriod16, (int) (byte) 100);
//        org.joda.time.DateTime dateTime20 = dateTime15.minusMinutes(0);
//        boolean boolean21 = dateTime11.isBefore((org.joda.time.ReadableInstant) dateTime15);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str9 = fixedDateTimeZone7.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.hourOfDay();
        org.joda.time.Chronology chronology12 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone14 = iSOChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test468");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str1 = iSOChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.era();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfHalfday();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.monthOfYear();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str9 = fixedDateTimeZone7.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology10.era();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder12.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder12.appendYearOfEra((int) '#', (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder12.appendDayOfWeek(3);
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(chronology19);
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withPeriodAdded(readablePeriod21, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration24 = null;
        org.joda.time.DateTime dateTime26 = dateTime23.withDurationAdded(readableDuration24, (int) (short) 100);
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(chronology27);
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.DateTime dateTime31 = dateTime28.withPeriodAdded(readablePeriod29, (int) (byte) 100);
        org.joda.time.DateTime dateTime33 = dateTime28.minusMinutes(0);
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime23, (org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(chronology34);
        org.joda.time.DateTime.Property property36 = dateTime35.monthOfYear();
        org.joda.time.DateTime dateTime37 = property36.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property36.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType38);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField41 = new org.joda.time.field.RemainderDateTimeField(dateTimeField11, dateTimeFieldType38, 690);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must be supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readablePeriod8);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        java.util.Locale locale11 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter10.withLocale(locale11);
//        boolean boolean13 = dateTimeFormatter12.isParser();
//        java.lang.String str14 = dateTime7.toString(dateTimeFormatter12);
//        org.joda.time.Chronology chronology15 = null;
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(chronology15);
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) (byte) 100);
//        int int20 = dateTime16.getHourOfDay();
//        long long21 = dateTime16.getMillis();
//        org.joda.time.DateTime dateTime23 = dateTime16.plus((long) 15);
//        java.lang.String str24 = dateTimeFormatter12.print((org.joda.time.ReadableInstant) dateTime23);
//        try {
//            org.joda.time.DateTime dateTime26 = dateTime23.withDayOfWeek((int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2068-11-27T12:11:29.217" + "'", str14.equals("2068-11-27T12:11:29.217"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 3121272689218L + "'", long21 == 3121272689218L);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2068-11-27T12:11:29.233" + "'", str24.equals("2068-11-27T12:11:29.233"));
//    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
//        org.joda.time.DateTime dateTime8 = dateTime4.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime10 = dateTime4.minusMillis((int) (byte) 10);
//        org.joda.time.DateTime dateTime12 = dateTime4.minusDays(2);
//        org.joda.time.DateTime dateTime14 = dateTime4.withCenturyOfEra((int) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str17 = dateTimeZone15.getName((long) 15);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone15.getShortName((long) (short) 0, locale19);
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = dateTimeZone15.getShortName((long) (short) 100, locale22);
//        org.joda.time.DateTime dateTime24 = dateTime14.withZoneRetainFields(dateTimeZone15);
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = dateTimeZone15.getShortName(43880629L, locale27);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Coordinated Universal Time" + "'", str17.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "UTC" + "'", str23.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
//    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
//        java.lang.String str9 = fixedDateTimeZone7.getNameKey((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone7);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology0.yearOfCentury();
//        java.lang.String str13 = iSOChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology0.minuteOfDay();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
//        org.junit.Assert.assertNotNull(zonedChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str13.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField14);
//    }

//    @Test
//    public void test474() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test474");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str1 = iSOChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
//        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
//        org.joda.time.DurationFieldType durationFieldType5 = null;
//        try {
//            org.joda.time.field.ScaledDurationField scaledDurationField7 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType5, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (short) 10, 32L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 320L + "'", long2 == 320L);
    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test477");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readablePeriod8);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        java.util.Locale locale11 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter10.withLocale(locale11);
//        boolean boolean13 = dateTimeFormatter12.isParser();
//        java.lang.String str14 = dateTime7.toString(dateTimeFormatter12);
//        org.joda.time.DurationFieldType durationFieldType15 = null;
//        try {
//            org.joda.time.DateTime dateTime17 = dateTime7.withFieldAdded(durationFieldType15, 919);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2068-11-27T12:11:29.469" + "'", str14.equals("2068-11-27T12:11:29.469"));
//    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(2, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 64 + "'", int2 == 64);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendDayOfWeek(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendPattern("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendDayOfYear(72680694);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

//    @Test
//    public void test480() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test480");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readablePeriod8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfMonth();
//        java.util.Locale locale11 = null;
//        int int12 = property10.getMaximumShortTextLength(locale11);
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(chronology13);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) (byte) 100);
//        int int18 = dateTime14.getHourOfDay();
//        org.joda.time.DateTime.Property property19 = dateTime14.millisOfSecond();
//        org.joda.time.DateTime dateTime20 = property19.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(chronology21);
//        org.joda.time.ReadablePeriod readablePeriod23 = null;
//        org.joda.time.DateTime dateTime25 = dateTime22.withPeriodAdded(readablePeriod23, (int) (byte) 100);
//        int int26 = dateTime22.getHourOfDay();
//        org.joda.time.Chronology chronology27 = null;
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) dateTime22, chronology27);
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime28.minus(readablePeriod29);
//        long long31 = property19.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime28);
//        int int32 = property10.compareTo((org.joda.time.ReadableInstant) dateTime28);
//        org.joda.time.DateTime dateTime33 = property10.roundHalfCeilingCopy();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 12 + "'", int18 == 12);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-2L) + "'", long31 == (-2L));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(dateTime33);
//    }

//    @Test
//    public void test481() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test481");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
//        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
//        boolean boolean5 = offsetDateTimeField3.isSupported();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime10 = dateTime7.withPeriodAdded(readablePeriod8, (int) (byte) 100);
//        int int11 = dateTime7.getHourOfDay();
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) dateTime7, chronology12);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime13.minus(readablePeriod14);
//        org.joda.time.DateTime dateTime17 = dateTime15.withHourOfDay((int) (byte) 1);
//        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.TimeOfDay timeOfDay19 = dateTime15.toTimeOfDay();
//        int[] intArray21 = null;
//        try {
//            int[] intArray23 = offsetDateTimeField3.add((org.joda.time.ReadablePartial) timeOfDay19, 97, intArray21, 79533557);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(timeOfDay19);
//    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        try {
            long long2 = dateTimeFormatter0.parseMillis("UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UTC\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(chronology3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.withPeriodAdded(readablePeriod7, (int) (byte) 100);
        org.joda.time.DateTime dateTime11 = dateTime6.minusMinutes(0);
        org.joda.time.DateTime dateTime13 = dateTime6.withYearOfEra(10);
        org.joda.time.DateTime dateTime15 = dateTime6.minusYears((int) ' ');
        int int16 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime18 = dateTime4.plusDays((int) (byte) 10);
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(chronology19);
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withPeriodAdded(readablePeriod21, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration24 = null;
        org.joda.time.DateTime dateTime26 = dateTime23.withDurationAdded(readableDuration24, (int) (short) 100);
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(chronology27);
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.DateTime dateTime31 = dateTime28.withPeriodAdded(readablePeriod29, (int) (byte) 100);
        org.joda.time.DateTime dateTime33 = dateTime28.minusMinutes(0);
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime23, (org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(chronology34);
        org.joda.time.DateTime.Property property36 = dateTime35.monthOfYear();
        org.joda.time.DateTime dateTime37 = property36.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property36.getFieldType();
        boolean boolean39 = dateTime18.isSupported(dateTimeFieldType38);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType38, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1014, (org.joda.time.Chronology) iSOChronology1);
        org.junit.Assert.assertNotNull(iSOChronology1);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendYearOfEra((int) (byte) 100, 0);
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatterBuilder5.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.format.DateTimeParser dateTimeParser8 = dateTimeFormatter7.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter6, dateTimeParser8);
        java.lang.StringBuffer stringBuffer10 = null;
        try {
            dateTimeFormatter9.printTo(stringBuffer10, 1560636325706L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimePrinter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeParser8);
    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZoneUTC();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(chronology3);
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, (int) (byte) 100);
//        org.joda.time.DateTime dateTime9 = dateTime4.minusMinutes(0);
//        org.joda.time.DateTime dateTime11 = dateTime4.withYearOfEra(10);
//        long long12 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTime dateTime13 = dateTime11.withLaterOffsetAtOverlap();
//        boolean boolean15 = dateTime11.isEqual((long) 'a');
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (byte) 100);
//        org.joda.time.DateTime dateTime22 = dateTime17.minusMinutes(0);
//        org.joda.time.Chronology chronology23 = null;
//        org.joda.time.MutableDateTime mutableDateTime24 = dateTime17.toMutableDateTime(chronology23);
//        org.joda.time.LocalDate localDate25 = dateTime17.toLocalDate();
//        org.joda.time.DateTime dateTime26 = dateTime11.withFields((org.joda.time.ReadablePartial) localDate25);
//        java.lang.String str27 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate25);
//        boolean boolean28 = dateTimeFormatter0.isPrinter();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimePrinter1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61823015731885L) + "'", long12 == (-61823015731885L));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2068-W48" + "'", str27.equals("2068-W48"));
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//    }

//    @Test
//    public void test487() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test487");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.date();
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) (byte) 100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        boolean boolean8 = dateTime6.isSupported(dateTimeFieldType7);
//        org.joda.time.DateTime dateTime10 = dateTime6.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime12 = dateTime6.minusMillis((int) (byte) 10);
//        org.joda.time.ReadableDuration readableDuration13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime6.plus(readableDuration13);
//        java.lang.String str15 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime14);
//        try {
//            org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.parse("2019-W24", dateTimeFormatter1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-W24\" is malformed at \"W24\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2068-11-27" + "'", str15.equals("2068-11-27"));
//    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        java.io.Writer writer2 = null;
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("0010-06-15T15:05:33.444-07:52:58");
        try {
            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadableInstant) dateTime4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime4);
    }

//    @Test
//    public void test489() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test489");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readablePeriod8);
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime12 = dateTime9.withDurationAdded(readableDuration10, (int) (byte) 0);
//        org.joda.time.DateTime dateTime14 = dateTime9.plusMillis((int) (short) 1);
//        java.lang.String str16 = dateTime9.toString("3");
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "3" + "'", str16.equals("3"));
//    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendHourOfHalfday(1);
        boolean boolean6 = dateTimeFormatterBuilder3.canBuildFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = dateTimeFormatter7.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.append(dateTimePrinter8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitYear(10784, true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimePrinter8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test491");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) (byte) 100);
//        org.joda.time.DateTime dateTime8 = dateTime3.minusMinutes(0);
//        org.joda.time.DateTime dateTime10 = dateTime3.withYearOfEra(10);
//        org.joda.time.DateTime dateTime12 = dateTime3.minusYears((int) ' ');
//        int int13 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DateTime dateTime15 = dateTime1.plusDays((int) (byte) 10);
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (byte) 100);
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, (int) (short) 100);
//        org.joda.time.Chronology chronology24 = null;
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(chronology24);
//        org.joda.time.ReadablePeriod readablePeriod26 = null;
//        org.joda.time.DateTime dateTime28 = dateTime25.withPeriodAdded(readablePeriod26, (int) (byte) 100);
//        org.joda.time.DateTime dateTime30 = dateTime25.minusMinutes(0);
//        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime20, (org.joda.time.ReadableInstant) dateTime30);
//        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now(chronology31);
//        org.joda.time.DateTime.Property property33 = dateTime32.monthOfYear();
//        org.joda.time.DateTime dateTime34 = property33.roundHalfCeilingCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property33.getFieldType();
//        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType35);
//        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField38 = iSOChronology37.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField(dateTimeField38, 15);
//        org.joda.time.DurationField durationField41 = offsetDateTimeField40.getDurationField();
//        org.joda.time.DurationField durationField42 = offsetDateTimeField40.getRangeDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str44 = iSOChronology43.toString();
//        org.joda.time.DateTimeField dateTimeField45 = iSOChronology43.weekyearOfCentury();
//        org.joda.time.Chronology chronology46 = iSOChronology43.withUTC();
//        org.joda.time.DurationField durationField47 = iSOChronology43.seconds();
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField48 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField42, durationField47);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The effective range must be at least 2");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(chronology31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(iSOChronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(iSOChronology43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str44.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(chronology46);
//        org.junit.Assert.assertNotNull(durationField47);
//    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test492");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readablePeriod8);
//        org.joda.time.DateTime.Property property10 = dateTime7.dayOfYear();
//        org.joda.time.DateTime dateTime11 = property10.roundCeilingCopy();
//        java.util.Locale locale13 = null;
//        org.joda.time.DateTime dateTime14 = property10.setCopy("6", locale13);
//        org.joda.time.DateTime dateTime15 = dateTime14.withEarlierOffsetAtOverlap();
//        org.joda.time.LocalDateTime localDateTime16 = dateTime14.toLocalDateTime();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime14.minus(readablePeriod17);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(localDateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (-61837261298250L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfDay(2, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfMinute(0, 2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendFractionOfSecond((int) (byte) 0, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder6.appendMinuteOfDay(2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.appendCenturyOfEra((int) (byte) 1, 79533557);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap18 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendTimeZoneShortName(strMap18);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder17.appendTimeZoneOffset("2068-11-27T12:11:19.820", false, 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfEra((int) '#', (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendDayOfWeek(3);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.withPeriodAdded(readablePeriod9, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded(readableDuration12, (int) (short) 100);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) (byte) 100);
        org.joda.time.DateTime dateTime21 = dateTime16.minusMinutes(0);
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime11, (org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now(chronology22);
        org.joda.time.DateTime.Property property24 = dateTime23.monthOfYear();
        org.joda.time.DateTime dateTime25 = property24.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder0.appendShortText(dateTimeFieldType26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder28.appendHourOfDay(20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        long long6 = fixedDateTimeZone4.previousTransition(0L);
        long long8 = fixedDateTimeZone4.nextTransition((long) (byte) 0);
        long long10 = fixedDateTimeZone4.nextTransition((long) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int13 = cachedDateTimeZone11.getStandardOffset((long) (byte) 1);
        int int15 = cachedDateTimeZone11.getStandardOffset((long) 1970);
        org.joda.time.DateTimeZone dateTimeZone16 = cachedDateTimeZone11.getUncachedZone();
        boolean boolean17 = cachedDateTimeZone11.isFixed();
        long long19 = cachedDateTimeZone11.previousTransition((long) 431);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 431L + "'", long19 == 431L);
    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
//        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("hi!");
//        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
//        java.lang.String str5 = jodaTimePermission1.toString();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str7 = iSOChronology6.toString();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.era();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology6.clockhourOfHalfday();
//        jodaTimePermission1.checkGuard((java.lang.Object) dateTimeField9);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str5.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str7.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str9 = fixedDateTimeZone7.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone11 = zonedChronology10.getZone();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.withWeekyear(993);
        int int15 = dateTime14.getWeekyear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 993 + "'", int15 == 993);
    }
}

