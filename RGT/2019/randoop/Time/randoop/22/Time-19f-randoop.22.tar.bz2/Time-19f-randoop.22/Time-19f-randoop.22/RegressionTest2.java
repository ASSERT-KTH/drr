import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime8 = dateTime4.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = dateTime8.plusMonths((int) (short) -1);
        org.joda.time.DateTime.Property property11 = dateTime8.centuryOfEra();
        org.joda.time.DateTime dateTime13 = property11.setCopy((int) (byte) 10);
        org.joda.time.DateTime dateTime15 = dateTime13.plus((long) 187);
        org.joda.time.DateTime.Property property16 = dateTime13.hourOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) (byte) 100);
        org.joda.time.DateTime dateTime8 = dateTime3.minusMinutes(0);
        org.joda.time.DateTime dateTime10 = dateTime3.withYearOfEra(10);
        org.joda.time.DateTime dateTime12 = dateTime3.minusYears((int) ' ');
        int int13 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime15 = dateTime1.plusDays((int) (byte) 10);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, (int) (short) 100);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(chronology24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.withPeriodAdded(readablePeriod26, (int) (byte) 100);
        org.joda.time.DateTime dateTime30 = dateTime25.minusMinutes(0);
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime20, (org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now(chronology31);
        org.joda.time.DateTime.Property property33 = dateTime32.monthOfYear();
        org.joda.time.DateTime dateTime34 = property33.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property33.getFieldType();
        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType35);
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
        org.joda.time.ReadableDuration readableDuration38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.minus(readableDuration38);
        org.joda.time.DateTime.Property property40 = dateTime39.minuteOfDay();
        org.joda.time.DurationField durationField41 = property40.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField42 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField41);
        long long45 = unsupportedDateTimeField42.add((-61837261293808L), 43880629L);
        long long48 = unsupportedDateTimeField42.getDifferenceAsLong((long) (short) 1, (long) 'a');
        try {
            long long51 = unsupportedDateTimeField42.set((long) 320, "ISOChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 3729449084306192L + "'", long45 == 3729449084306192L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test003");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
//        org.joda.time.DateTime dateTime8 = dateTime4.plusHours(993);
//        org.joda.time.DateTimeZone dateTimeZone9 = dateTime4.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 15);
//        org.joda.time.DurationField durationField14 = offsetDateTimeField13.getDurationField();
//        boolean boolean15 = offsetDateTimeField13.isSupported();
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (byte) 100);
//        int int21 = dateTime17.getHourOfDay();
//        org.joda.time.Chronology chronology22 = null;
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((java.lang.Object) dateTime17, chronology22);
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime23.minus(readablePeriod24);
//        org.joda.time.DateTime.Property property26 = dateTime23.dayOfYear();
//        org.joda.time.DateTime dateTime27 = property26.roundCeilingCopy();
//        java.util.Locale locale29 = null;
//        org.joda.time.DateTime dateTime30 = property26.setCopy("6", locale29);
//        org.joda.time.DateTime dateTime31 = dateTime30.withEarlierOffsetAtOverlap();
//        org.joda.time.LocalDateTime localDateTime32 = dateTime30.toLocalDateTime();
//        int int33 = offsetDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) localDateTime32);
//        org.joda.time.DateTime dateTime34 = dateTime4.withFields((org.joda.time.ReadablePartial) localDateTime32);
//        int int35 = dateTime4.getWeekyear();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(localDateTime32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 15 + "'", int33 == 15);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1970 + "'", int35 == 1970);
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (byte) -1);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, 6);
        long long10 = offsetDateTimeField6.roundHalfEven(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, (int) (byte) 100, 17, 963);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
        boolean boolean5 = offsetDateTimeField3.isSupported();
        long long7 = offsetDateTimeField3.roundCeiling((long) 3);
        long long9 = offsetDateTimeField3.roundHalfFloor(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3L + "'", long7 == 3L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale2 = null;
        java.lang.String str5 = defaultNameProvider0.getName(locale2, "15", "ZonedChronology[ISOChronology[UTC], ]");
        java.util.Locale locale6 = null;
        java.lang.String str9 = defaultNameProvider0.getName(locale6, "2019-W24", "767");
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
        int int4 = offsetDateTimeField3.getMaximumValue();
        int int6 = offsetDateTimeField3.getLeapAmount((-6183726128855600L));
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsText((-61837261285963L), locale8);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1014 + "'", int4 == 1014);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "52" + "'", str9.equals("52"));
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test009");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
//        java.lang.Integer int3 = dateTimeFormatter0.getPivotYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withDefaultYear((int) (byte) -1);
//        java.lang.Appendable appendable6 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str8 = iSOChronology7.toString();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.weekyearOfCentury();
//        org.joda.time.Chronology chronology10 = iSOChronology7.withUTC();
//        org.joda.time.DurationField durationField11 = iSOChronology7.eras();
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology7);
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(chronology13);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) (byte) 100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        boolean boolean19 = dateTime17.isSupported(dateTimeFieldType18);
//        org.joda.time.DateTime dateTime21 = dateTime17.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime23 = dateTime17.minusMillis((int) (byte) 10);
//        org.joda.time.LocalDate localDate24 = dateTime17.toLocalDate();
//        long long26 = iSOChronology7.set((org.joda.time.ReadablePartial) localDate24, (-6183726128855600L));
//        try {
//            dateTimeFormatter5.printTo(appendable6, (org.joda.time.ReadablePartial) localDate24);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNull(int3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ISOChronology[UTC]" + "'", str8.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 63144400L + "'", long26 == 63144400L);
//    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test011");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        boolean boolean8 = dateTime6.isSupported(dateTimeFieldType7);
//        java.util.GregorianCalendar gregorianCalendar9 = dateTime6.toGregorianCalendar();
//        org.joda.time.DateTime dateTime10 = dateTime6.toDateTime();
//        org.joda.time.DateTime dateTime12 = dateTime6.withMillis((-61837261290006L));
//        int int13 = dateTime6.getMillisOfDay();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gregorianCalendar9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 320 + "'", int13 == 320);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
        boolean boolean5 = offsetDateTimeField3.isSupported();
        long long7 = offsetDateTimeField3.roundCeiling((long) 3);
        boolean boolean9 = offsetDateTimeField3.isLeap(101L);
        long long12 = offsetDateTimeField3.add((long) 365, 97);
        int int14 = offsetDateTimeField3.getLeapAmount((long) 6);
        org.joda.time.DateTimeField dateTimeField15 = offsetDateTimeField3.getWrappedField();
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (byte) 100);
        org.joda.time.DateTime dateTime22 = dateTime17.minusMinutes(0);
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.MutableDateTime mutableDateTime24 = dateTime17.toMutableDateTime(chronology23);
        org.joda.time.LocalDate localDate25 = dateTime17.toLocalDate();
        int int26 = offsetDateTimeField3.getMaximumValue((org.joda.time.ReadablePartial) localDate25);
        long long28 = offsetDateTimeField3.roundHalfEven((long) '4');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3L + "'", long7 == 3L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 462L + "'", long12 == 462L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1014 + "'", int26 == 1014);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 52L + "'", long28 == 52L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) (byte) 100);
        org.joda.time.DateTime dateTime8 = dateTime3.minusMinutes(0);
        org.joda.time.DateTime dateTime10 = dateTime3.withYearOfEra(10);
        org.joda.time.DateTime dateTime12 = dateTime3.minusYears((int) ' ');
        int int13 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime15 = dateTime1.plusDays((int) (byte) 10);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, (int) (short) 100);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(chronology24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.withPeriodAdded(readablePeriod26, (int) (byte) 100);
        org.joda.time.DateTime dateTime30 = dateTime25.minusMinutes(0);
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime20, (org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now(chronology31);
        org.joda.time.DateTime.Property property33 = dateTime32.monthOfYear();
        org.joda.time.DateTime dateTime34 = property33.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property33.getFieldType();
        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType35);
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
        org.joda.time.ReadableDuration readableDuration38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.minus(readableDuration38);
        org.joda.time.DateTime.Property property40 = dateTime39.minuteOfDay();
        org.joda.time.DurationField durationField41 = property40.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField42 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField41);
        long long45 = unsupportedDateTimeField42.add((-61837261293808L), 43880629L);
        boolean boolean46 = unsupportedDateTimeField42.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = unsupportedDateTimeField42.getType();
        try {
            int int49 = unsupportedDateTimeField42.getLeapAmount((long) 2068);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 3729449084306192L + "'", long45 == 3729449084306192L);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        long long6 = fixedDateTimeZone4.previousTransition(0L);
        long long8 = fixedDateTimeZone4.nextTransition((long) (byte) 0);
        long long10 = fixedDateTimeZone4.nextTransition((long) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int13 = cachedDateTimeZone11.getStandardOffset((long) (byte) 1);
        int int15 = cachedDateTimeZone11.getOffset((-61837261290390L));
        org.joda.time.DateTimeZone dateTimeZone16 = cachedDateTimeZone11.getUncachedZone();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now(dateTimeZone16);
        org.joda.time.TimeOfDay timeOfDay18 = dateTime17.toTimeOfDay();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(timeOfDay18);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) (byte) 100);
        org.joda.time.DateTime dateTime8 = dateTime3.minusMinutes(0);
        org.joda.time.DateTime dateTime10 = dateTime3.withYearOfEra(10);
        org.joda.time.DateTime dateTime12 = dateTime3.minusYears((int) ' ');
        int int13 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime15 = dateTime1.plusDays((int) (byte) 10);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, (int) (short) 100);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(chronology24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.withPeriodAdded(readablePeriod26, (int) (byte) 100);
        org.joda.time.DateTime dateTime30 = dateTime25.minusMinutes(0);
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime20, (org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now(chronology31);
        org.joda.time.DateTime.Property property33 = dateTime32.monthOfYear();
        org.joda.time.DateTime dateTime34 = property33.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property33.getFieldType();
        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType35);
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
        org.joda.time.ReadableDuration readableDuration38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.minus(readableDuration38);
        org.joda.time.DateTime.Property property40 = dateTime39.minuteOfDay();
        org.joda.time.DurationField durationField41 = property40.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField42 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField41);
        java.util.Locale locale45 = null;
        try {
            long long46 = unsupportedDateTimeField42.set((long) 649, "2019-06-15T15:05:34.415-07:00", locale45);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField42);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) (byte) 100);
        org.joda.time.DateTime dateTime8 = dateTime3.minusMinutes(0);
        org.joda.time.DateTime dateTime10 = dateTime3.withYearOfEra(10);
        org.joda.time.DateTime dateTime12 = dateTime3.minusYears((int) ' ');
        int int13 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime15 = dateTime1.plusDays((int) (byte) 10);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, (int) (short) 100);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(chronology24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.withPeriodAdded(readablePeriod26, (int) (byte) 100);
        org.joda.time.DateTime dateTime30 = dateTime25.minusMinutes(0);
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime20, (org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now(chronology31);
        org.joda.time.DateTime.Property property33 = dateTime32.monthOfYear();
        org.joda.time.DateTime dateTime34 = property33.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property33.getFieldType();
        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType35);
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
        org.joda.time.ReadableDuration readableDuration38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.minus(readableDuration38);
        org.joda.time.DateTime.Property property40 = dateTime39.minuteOfDay();
        org.joda.time.DurationField durationField41 = property40.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField42 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField41);
        try {
            long long44 = unsupportedDateTimeField42.roundHalfCeiling(1560636328659L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField42);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.era();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = iSOChronology0.weekyears();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("T16:00:00.000-08:00", "");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "T16:00:00.000-08:00" + "'", str4.equals("T16:00:00.000-08:00"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("152", "1970-01-01T00:00:01.929");
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) (byte) 100);
        org.joda.time.DateTime dateTime8 = dateTime3.minusMinutes(0);
        org.joda.time.DateTime dateTime10 = dateTime3.withYearOfEra(10);
        org.joda.time.DateTime dateTime12 = dateTime3.minusYears((int) ' ');
        int int13 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime15 = dateTime1.plusDays((int) (byte) 10);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, (int) (short) 100);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(chronology24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.withPeriodAdded(readablePeriod26, (int) (byte) 100);
        org.joda.time.DateTime dateTime30 = dateTime25.minusMinutes(0);
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime20, (org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now(chronology31);
        org.joda.time.DateTime.Property property33 = dateTime32.monthOfYear();
        org.joda.time.DateTime dateTime34 = property33.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property33.getFieldType();
        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType35);
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
        org.joda.time.ReadableDuration readableDuration38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.minus(readableDuration38);
        org.joda.time.DateTime.Property property40 = dateTime39.minuteOfDay();
        org.joda.time.DurationField durationField41 = property40.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField42 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField41);
        long long45 = unsupportedDateTimeField42.add((-61837261293808L), 43880629L);
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = unsupportedDateTimeField42.getType();
        try {
            int int48 = unsupportedDateTimeField42.getMaximumValue((-61823015718551L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 3729449084306192L + "'", long45 == 3729449084306192L);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test021");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
//        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
//        boolean boolean5 = offsetDateTimeField3.isSupported();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime10 = dateTime7.withPeriodAdded(readablePeriod8, (int) (byte) 100);
//        int int11 = dateTime7.getHourOfDay();
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) dateTime7, chronology12);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime13.minus(readablePeriod14);
//        org.joda.time.DateTime.Property property16 = dateTime13.dayOfYear();
//        org.joda.time.DateTime dateTime17 = property16.roundCeilingCopy();
//        java.util.Locale locale19 = null;
//        org.joda.time.DateTime dateTime20 = property16.setCopy("6", locale19);
//        org.joda.time.DateTime dateTime21 = dateTime20.withEarlierOffsetAtOverlap();
//        org.joda.time.LocalDateTime localDateTime22 = dateTime20.toLocalDateTime();
//        int int23 = offsetDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) localDateTime22);
//        int int25 = offsetDateTimeField3.get((-61823015740307L));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(localDateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 15 + "'", int23 == 15);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 708 + "'", int25 == 708);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(readableDuration5, (int) (short) 100);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.withPeriodAdded(readablePeriod10, (int) (byte) 100);
        org.joda.time.DateTime dateTime14 = dateTime9.minusMinutes(0);
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime4, (org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(chronology15);
        org.joda.time.DateTime.Property property17 = dateTime16.monthOfYear();
        org.joda.time.DateTime dateTime18 = property17.roundHalfEvenCopy();
        try {
            org.joda.time.DateTime dateTime20 = property17.setCopy("168");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"168\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(2365, 0, 0, 36, 100, 339);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 36 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test024");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readablePeriod8);
//        int int10 = dateTime7.getWeekOfWeekyear();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(10);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.plus(readablePeriod9);
        org.joda.time.DateTime.Property property11 = dateTime8.dayOfMonth();
        org.joda.time.DateTime dateTime14 = dateTime8.withDurationAdded((-61837261301932L), 690);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) (byte) 100);
        org.joda.time.DateTime dateTime8 = dateTime3.minusMinutes(0);
        org.joda.time.DateTime dateTime10 = dateTime3.withYearOfEra(10);
        org.joda.time.DateTime dateTime12 = dateTime3.minusYears((int) ' ');
        int int13 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime15 = dateTime1.plusDays((int) (byte) 10);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, (int) (short) 100);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(chronology24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.withPeriodAdded(readablePeriod26, (int) (byte) 100);
        org.joda.time.DateTime dateTime30 = dateTime25.minusMinutes(0);
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime20, (org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now(chronology31);
        org.joda.time.DateTime.Property property33 = dateTime32.monthOfYear();
        org.joda.time.DateTime dateTime34 = property33.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property33.getFieldType();
        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType35);
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
        org.joda.time.ReadableDuration readableDuration38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.minus(readableDuration38);
        org.joda.time.DateTime.Property property40 = dateTime39.minuteOfDay();
        org.joda.time.DurationField durationField41 = property40.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField42 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField41);
        long long45 = unsupportedDateTimeField42.add((-61837261293808L), 43880629L);
        boolean boolean46 = unsupportedDateTimeField42.isSupported();
        org.joda.time.DurationField durationField47 = unsupportedDateTimeField42.getRangeDurationField();
        try {
            int int48 = unsupportedDateTimeField42.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 3729449084306192L + "'", long45 == 3729449084306192L);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(durationField47);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str9 = fixedDateTimeZone7.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone7);
        java.lang.Object obj11 = null;
        boolean boolean12 = zonedChronology10.equals(obj11);
        org.joda.time.DateTimeZone dateTimeZone13 = zonedChronology10.getZone();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeZone13);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatterBuilder3.toParser();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap5);
        dateTimeFormatterBuilder3.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField10 = iSOChronology9.eras();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str18 = fixedDateTimeZone16.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology9, (org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology9.hourOfDay();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology9.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology9.dayOfYear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder23.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder23.appendYearOfEra((int) '#', (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder23.appendDayOfWeek(3);
        org.joda.time.Chronology chronology30 = null;
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(chronology30);
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime34 = dateTime31.withPeriodAdded(readablePeriod32, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration35 = null;
        org.joda.time.DateTime dateTime37 = dateTime34.withDurationAdded(readableDuration35, (int) (short) 100);
        org.joda.time.Chronology chronology38 = null;
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime(chronology38);
        org.joda.time.ReadablePeriod readablePeriod40 = null;
        org.joda.time.DateTime dateTime42 = dateTime39.withPeriodAdded(readablePeriod40, (int) (byte) 100);
        org.joda.time.DateTime dateTime44 = dateTime39.minusMinutes(0);
        org.joda.time.Chronology chronology45 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime34, (org.joda.time.ReadableInstant) dateTime44);
        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now(chronology45);
        org.joda.time.DateTime.Property property47 = dateTime46.monthOfYear();
        org.joda.time.DateTime dateTime48 = property47.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = property47.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder23.appendShortText(dateTimeFieldType49);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, dateTimeFieldType49, 2019, 674, 12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder3.appendFixedSignedDecimal(dateTimeFieldType49, 776555);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(chronology45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTimeFieldType49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str10 = fixedDateTimeZone8.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone8);
        long long15 = zonedChronology11.add(30L, (long) 2019, 330);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 48, (org.joda.time.Chronology) zonedChronology11);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 666300L + "'", long15 == 666300L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime1.toMutableDateTime(chronology7);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(chronology9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.withPeriodAdded(readablePeriod11, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.withDurationAdded(readableDuration14, (int) (short) 100);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(chronology17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime21 = dateTime18.withPeriodAdded(readablePeriod19, (int) (byte) 100);
        org.joda.time.DateTime dateTime23 = dateTime18.minusMinutes(0);
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime13, (org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now(chronology24);
        org.joda.time.DateTime.Property property26 = dateTime25.monthOfYear();
        org.joda.time.DateTime dateTime27 = property26.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property26.getFieldType();
        boolean boolean29 = mutableDateTime8.isSupported(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.era();
        jodaTimePermission1.checkGuard((java.lang.Object) dateTimeField4);
        java.lang.String str6 = jodaTimePermission1.getActions();
        java.lang.String str7 = jodaTimePermission1.getActions();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.withPeriodAdded(readablePeriod10, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.withDurationAdded(readableDuration13, (int) (short) 100);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (byte) 100);
        org.joda.time.DateTime dateTime22 = dateTime17.minusMinutes(0);
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime12, (org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now(chronology23);
        org.joda.time.DateTime.Property property25 = dateTime24.monthOfYear();
        org.joda.time.DateTime dateTime27 = dateTime24.withMillis((-61823015739109L));
        jodaTimePermission1.checkGuard((java.lang.Object) dateTime27);
        java.lang.String str29 = jodaTimePermission1.toString();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str29.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        long long8 = fixedDateTimeZone6.previousTransition(0L);
        long long10 = fixedDateTimeZone6.nextTransition((long) (byte) 0);
        int int12 = fixedDateTimeZone6.getStandardOffset(1560616766400L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        boolean boolean14 = fixedDateTimeZone6.isFixed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test033");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
//        int int4 = offsetDateTimeField3.getMaximumValue();
//        java.lang.String str6 = offsetDateTimeField3.getAsText(0L);
//        long long8 = offsetDateTimeField3.roundHalfEven(1970L);
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(chronology9);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.withPeriodAdded(readablePeriod11, (int) (byte) 100);
//        org.joda.time.DateTime dateTime15 = dateTime10.minusMinutes(0);
//        org.joda.time.DateTime dateTime17 = dateTime10.withYearOfEra(10);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime dateTime19 = dateTime17.withLaterOffsetAtOverlap();
//        boolean boolean21 = dateTime17.isEqual((long) 'a');
//        org.joda.time.Chronology chronology22 = null;
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(chronology22);
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.withPeriodAdded(readablePeriod24, (int) (byte) 100);
//        org.joda.time.DateTime dateTime28 = dateTime23.minusMinutes(0);
//        org.joda.time.Chronology chronology29 = null;
//        org.joda.time.MutableDateTime mutableDateTime30 = dateTime23.toMutableDateTime(chronology29);
//        org.joda.time.LocalDate localDate31 = dateTime23.toLocalDate();
//        org.joda.time.DateTime dateTime32 = dateTime17.withFields((org.joda.time.ReadablePartial) localDate31);
//        boolean boolean33 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate31);
//        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.lang.Object obj36 = null;
//        boolean boolean37 = gregorianChronology35.equals(obj36);
//        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField39 = iSOChronology38.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, 15);
//        org.joda.time.DurationField durationField42 = offsetDateTimeField41.getDurationField();
//        boolean boolean43 = offsetDateTimeField41.isSupported();
//        boolean boolean44 = gregorianChronology35.equals((java.lang.Object) offsetDateTimeField41);
//        org.joda.time.DateTimeField dateTimeField45 = offsetDateTimeField41.getWrappedField();
//        long long47 = offsetDateTimeField41.roundHalfCeiling(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter48 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimePrinter dateTimePrinter49 = dateTimeFormatter48.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter50 = dateTimeFormatter48.withZoneUTC();
//        org.joda.time.Chronology chronology51 = null;
//        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime(chronology51);
//        org.joda.time.ReadablePeriod readablePeriod53 = null;
//        org.joda.time.DateTime dateTime55 = dateTime52.withPeriodAdded(readablePeriod53, (int) (byte) 100);
//        org.joda.time.DateTime dateTime57 = dateTime52.minusMinutes(0);
//        org.joda.time.DateTime dateTime59 = dateTime52.withYearOfEra(10);
//        long long60 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime59);
//        org.joda.time.DateTime dateTime61 = dateTime59.withLaterOffsetAtOverlap();
//        boolean boolean63 = dateTime59.isEqual((long) 'a');
//        org.joda.time.Chronology chronology64 = null;
//        org.joda.time.DateTime dateTime65 = new org.joda.time.DateTime(chronology64);
//        org.joda.time.ReadablePeriod readablePeriod66 = null;
//        org.joda.time.DateTime dateTime68 = dateTime65.withPeriodAdded(readablePeriod66, (int) (byte) 100);
//        org.joda.time.DateTime dateTime70 = dateTime65.minusMinutes(0);
//        org.joda.time.Chronology chronology71 = null;
//        org.joda.time.MutableDateTime mutableDateTime72 = dateTime65.toMutableDateTime(chronology71);
//        org.joda.time.LocalDate localDate73 = dateTime65.toLocalDate();
//        org.joda.time.DateTime dateTime74 = dateTime59.withFields((org.joda.time.ReadablePartial) localDate73);
//        java.lang.String str75 = dateTimeFormatter48.print((org.joda.time.ReadablePartial) localDate73);
//        int[] intArray81 = new int[] { 1970, 42, 0, 54330513, 0 };
//        int int82 = offsetDateTimeField41.getMaximumValue((org.joda.time.ReadablePartial) localDate73, intArray81);
//        try {
//            int[] intArray84 = offsetDateTimeField3.add((org.joda.time.ReadablePartial) localDate31, 0, intArray81, 48);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Maximum value exceeded for add");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1014 + "'", int4 == 1014);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1970L + "'", long8 == 1970L);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-61851599999680L) + "'", long18 == (-61851599999680L));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(mutableDateTime30);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(iSOChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 10L + "'", long47 == 10L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter48);
//        org.junit.Assert.assertNotNull(dateTimePrinter49);
//        org.junit.Assert.assertNotNull(dateTimeFormatter50);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-61851599999680L) + "'", long60 == (-61851599999680L));
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(dateTime68);
//        org.junit.Assert.assertNotNull(dateTime70);
//        org.junit.Assert.assertNotNull(mutableDateTime72);
//        org.junit.Assert.assertNotNull(localDate73);
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "1970-W01" + "'", str75.equals("1970-W01"));
//        org.junit.Assert.assertNotNull(intArray81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1014 + "'", int82 == 1014);
//    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test034");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.DateTime.Property property6 = dateTime1.millisOfSecond();
//        boolean boolean8 = property6.equals((java.lang.Object) 100.0f);
//        org.joda.time.DateTime dateTime9 = property6.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime10 = property6.roundHalfFloorCopy();
//        boolean boolean11 = property6.isLeap();
//        org.joda.time.DateTime dateTime13 = property6.addToCopy((long) (byte) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str15 = iSOChronology14.toString();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.era();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology14.clockhourOfHalfday();
//        org.joda.time.DateTime dateTime18 = dateTime13.toDateTime((org.joda.time.Chronology) iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ISOChronology[UTC]" + "'", str15.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        long long6 = fixedDateTimeZone4.previousTransition(0L);
        long long8 = fixedDateTimeZone4.nextTransition((long) (byte) 0);
        long long10 = fixedDateTimeZone4.nextTransition((long) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int13 = cachedDateTimeZone11.getStandardOffset((long) (byte) 1);
        int int15 = cachedDateTimeZone11.getOffset((-61837261290390L));
        long long17 = cachedDateTimeZone11.convertUTCToLocal((-61823015736074L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61823015736064L) + "'", long17 == (-61823015736064L));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.era();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone6 = iSOChronology0.getZone();
        long long8 = dateTimeZone6.convertUTCToLocal((long) 'a');
        int int10 = dateTimeZone6.getOffsetFromLocal(3729449084306192L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.era();
        jodaTimePermission1.checkGuard((java.lang.Object) dateTimeField4);
        java.lang.String str6 = jodaTimePermission1.getActions();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        jodaTimePermission1.checkGuard((java.lang.Object) property9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder13.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.appendFractionOfDay(2, 0);
        boolean boolean18 = dateTimeFormatterBuilder14.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder14.appendFractionOfDay(97, (int) '4');
        boolean boolean22 = jodaTimePermission1.equals((java.lang.Object) dateTimeFormatterBuilder21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder21.appendClockhourOfHalfday(365);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(chronology25);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.DateTime dateTime29 = dateTime26.withPeriodAdded(readablePeriod27, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration30 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.withDurationAdded(readableDuration30, (int) (short) 100);
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(chronology33);
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime37 = dateTime34.withPeriodAdded(readablePeriod35, (int) (byte) 100);
        org.joda.time.DateTime dateTime39 = dateTime34.minusMinutes(0);
        org.joda.time.Chronology chronology40 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime29, (org.joda.time.ReadableInstant) dateTime39);
        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now(chronology40);
        org.joda.time.DateTime.Property property42 = dateTime41.monthOfYear();
        org.joda.time.DateTime dateTime43 = property42.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property42.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException47 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType44, (java.lang.Number) 3L, "2019-06-15T15:05:30.038-07:00");
        org.joda.time.IllegalFieldValueException illegalFieldValueException49 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType44, "2019-06-15T15:05:30.038-07:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder24.appendText(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, chronology1);
        try {
            org.joda.time.DateTime dateTime4 = dateTime2.withWeekOfWeekyear(100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for weekOfWeekyear must be in the range [1,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((-1L));
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology8, dateTimeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTimeZone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyear();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField5 = iSOChronology4.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str13 = fixedDateTimeZone11.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology4.hourOfDay();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology4.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology4.dayOfYear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder18.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder18.appendYearOfEra((int) '#', (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder18.appendDayOfWeek(3);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(chronology25);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.DateTime dateTime29 = dateTime26.withPeriodAdded(readablePeriod27, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration30 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.withDurationAdded(readableDuration30, (int) (short) 100);
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(chronology33);
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime37 = dateTime34.withPeriodAdded(readablePeriod35, (int) (byte) 100);
        org.joda.time.DateTime dateTime39 = dateTime34.minusMinutes(0);
        org.joda.time.Chronology chronology40 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime29, (org.joda.time.ReadableInstant) dateTime39);
        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now(chronology40);
        org.joda.time.DateTime.Property property42 = dateTime41.monthOfYear();
        org.joda.time.DateTime dateTime43 = property42.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property42.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder18.appendShortText(dateTimeFieldType44);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, dateTimeFieldType44, 2019, 674, 12);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField51 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType44, 11);
        long long54 = dividedDateTimeField51.add((long) 36, 59);
        int int55 = dividedDateTimeField51.getMinimumValue();
        int int56 = dividedDateTimeField51.getDivisor();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField51);
        try {
            long long60 = dividedDateTimeField51.add((long) 168, 1263934383L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 13903278213");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 20480947200036L + "'", long54 == 20480947200036L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-26570460) + "'", int55 == (-26570460));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 11 + "'", int56 == 11);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 230401970L, (java.lang.Number) 3121272684132L, (java.lang.Number) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test042");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
//        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("hi!");
//        org.joda.time.JodaTimePermission jodaTimePermission5 = new org.joda.time.JodaTimePermission("hi!");
//        boolean boolean6 = jodaTimePermission3.implies((java.security.Permission) jodaTimePermission5);
//        jodaTimePermission5.checkGuard((java.lang.Object) "T16:00:00.000-08:00");
//        boolean boolean9 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission5);
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(chronology10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime14 = dateTime11.withPeriodAdded(readablePeriod12, (int) (byte) 100);
//        int int15 = dateTime11.getHourOfDay();
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((java.lang.Object) dateTime11, chronology16);
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime17.minus(readablePeriod18);
//        org.joda.time.DateTime dateTime21 = dateTime19.withHourOfDay((int) (byte) 1);
//        java.util.Date date22 = dateTime19.toDate();
//        jodaTimePermission1.checkGuard((java.lang.Object) dateTime19);
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField25 = iSOChronology24.eras();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology24.dayOfYear();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone31 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
//        java.lang.String str33 = fixedDateTimeZone31.getNameKey((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology34 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology24, (org.joda.time.DateTimeZone) fixedDateTimeZone31);
//        jodaTimePermission1.checkGuard((java.lang.Object) iSOChronology24);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
//        org.junit.Assert.assertNotNull(zonedChronology34);
//    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test043");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readablePeriod8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfMonth();
//        java.util.Locale locale11 = null;
//        int int12 = property10.getMaximumShortTextLength(locale11);
//        int int13 = property10.get();
//        java.lang.String str14 = property10.getAsShortText();
//        org.joda.time.DateTime dateTime16 = property10.setCopy((int) (byte) 10);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1" + "'", str14.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test044");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.DateTime.Property property6 = dateTime1.millisOfSecond();
//        boolean boolean8 = property6.equals((java.lang.Object) 100.0f);
//        org.joda.time.DateTime dateTime9 = property6.roundHalfEvenCopy();
//        java.lang.String str10 = property6.getAsShortText();
//        org.joda.time.DateTime dateTime11 = property6.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime12 = property6.roundFloorCopy();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "320" + "'", str10.equals("320"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.era();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime5 = dateTime4.withEarlierOffsetAtOverlap();
        int int6 = dateTime4.getMinuteOfHour();
        org.joda.time.DateTime dateTime8 = dateTime4.minusYears(1929);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str10 = fixedDateTimeZone8.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology11.getZone();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(1560636316453L, dateTimeZone12);
        org.joda.time.DateTime dateTime15 = dateTime13.minusHours(431);
        boolean boolean16 = dateTime15.isEqualNow();
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.withDurationAdded(readableDuration17, (int) (short) 0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        long long6 = fixedDateTimeZone4.previousTransition(0L);
        long long8 = fixedDateTimeZone4.nextTransition((long) (byte) 0);
        long long10 = fixedDateTimeZone4.nextTransition((long) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int13 = cachedDateTimeZone11.getStandardOffset((long) (byte) 1);
        int int15 = cachedDateTimeZone11.getStandardOffset((long) 1970);
        boolean boolean16 = cachedDateTimeZone11.isFixed();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test048");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
//        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(10);
//        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime.Property property10 = dateTime8.weekOfWeekyear();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61851599999680L) + "'", long9 == (-61851599999680L));
//        org.junit.Assert.assertNotNull(property10);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((-1L));
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.withYearOfEra(963);
        org.junit.Assert.assertNotNull(dateTime3);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test051");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gregorianChronology0.equals(obj1);
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 15);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getDurationField();
//        boolean boolean8 = offsetDateTimeField6.isSupported();
//        boolean boolean9 = gregorianChronology0.equals((java.lang.Object) offsetDateTimeField6);
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(chronology10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime14 = dateTime11.withPeriodAdded(readablePeriod12, (int) (byte) 100);
//        int int15 = dateTime11.getHourOfDay();
//        org.joda.time.DateTime.Property property16 = dateTime11.millisOfSecond();
//        boolean boolean18 = property16.equals((java.lang.Object) 100.0f);
//        org.joda.time.DateTime dateTime19 = property16.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime20 = property16.roundHalfFloorCopy();
//        int int21 = property16.get();
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = property16.getAsText(locale22);
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = property16.getAsText(locale24);
//        boolean boolean26 = gregorianChronology0.equals((java.lang.Object) property16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property16.getFieldType();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 320 + "'", int21 == 320);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "320" + "'", str23.equals("320"));
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "320" + "'", str25.equals("320"));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) (byte) 100);
        org.joda.time.DateTime dateTime8 = dateTime3.minusMinutes(0);
        org.joda.time.DateTime dateTime10 = dateTime3.withYearOfEra(10);
        org.joda.time.DateTime dateTime12 = dateTime3.minusYears((int) ' ');
        int int13 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime.Property property14 = dateTime12.monthOfYear();
        org.joda.time.DateTime dateTime16 = property14.setCopy((int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        int int6 = offsetDateTimeField5.getMaximumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 372 + "'", int6 == 372);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField2 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test055");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
//        long long6 = fixedDateTimeZone4.previousTransition(0L);
//        long long8 = fixedDateTimeZone4.nextTransition((long) (byte) 0);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        int int10 = dateTime9.getDayOfYear();
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test056");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readablePeriod8);
//        org.joda.time.DateTime.Property property10 = dateTime7.dayOfYear();
//        org.joda.time.DateTime dateTime11 = property10.roundCeilingCopy();
//        org.joda.time.DateTime dateTime13 = property10.addToCopy((-1));
//        int int14 = dateTime13.getYearOfCentury();
//        org.joda.time.DateTime dateTime15 = dateTime13.withTimeAtStartOfDay();
//        org.joda.time.DateTime dateTime17 = dateTime13.withYearOfCentury((int) (byte) 0);
//        java.lang.String str18 = dateTime13.toString();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 69 + "'", int14 == 69);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1969-12-31T00:00:00.320Z" + "'", str18.equals("1969-12-31T00:00:00.320Z"));
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfDay(2, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendYearOfCentury(690, (int) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
        int int4 = offsetDateTimeField3.getMaximumValue();
        java.lang.String str6 = offsetDateTimeField3.getAsText(0L);
        int int7 = offsetDateTimeField3.getOffset();
        long long10 = offsetDateTimeField3.add(1560636332627L, (long) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder13.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendHourOfHalfday(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendDayOfWeekText();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(chronology18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.DateTime dateTime22 = dateTime19.withPeriodAdded(readablePeriod20, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.DateTime dateTime25 = dateTime22.withDurationAdded(readableDuration23, (int) (short) 100);
        org.joda.time.Chronology chronology26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(chronology26);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime30 = dateTime27.withPeriodAdded(readablePeriod28, (int) (byte) 100);
        org.joda.time.DateTime dateTime32 = dateTime27.minusMinutes(0);
        org.joda.time.Chronology chronology33 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime22, (org.joda.time.ReadableInstant) dateTime32);
        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now(chronology33);
        org.joda.time.DateTime.Property property35 = dateTime34.monthOfYear();
        org.joda.time.DateTime dateTime36 = property35.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = property35.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder17.appendShortText(dateTimeFieldType37);
        org.joda.time.IllegalFieldValueException illegalFieldValueException40 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType37, "15");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType37, 15);
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(chronology43);
        org.joda.time.ReadablePeriod readablePeriod45 = null;
        org.joda.time.DateTime dateTime47 = dateTime44.withPeriodAdded(readablePeriod45, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration48 = null;
        org.joda.time.DateTime dateTime50 = dateTime47.withDurationAdded(readableDuration48, (int) (short) 100);
        org.joda.time.Chronology chronology51 = null;
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime(chronology51);
        org.joda.time.ReadablePeriod readablePeriod53 = null;
        org.joda.time.DateTime dateTime55 = dateTime52.withPeriodAdded(readablePeriod53, (int) (byte) 100);
        org.joda.time.DateTime dateTime57 = dateTime52.minusMinutes(0);
        org.joda.time.Chronology chronology58 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime47, (org.joda.time.ReadableInstant) dateTime57);
        org.joda.time.DateTime dateTime59 = org.joda.time.DateTime.now(chronology58);
        org.joda.time.DateTime.Property property60 = dateTime59.monthOfYear();
        org.joda.time.DateTime dateTime61 = property60.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property60.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException65 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType62, (java.lang.Number) 3L, "2019-06-15T15:05:30.038-07:00");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField66 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField42, dateTimeFieldType62);
        long long68 = remainderDateTimeField42.roundHalfEven((long) 959);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1014 + "'", int4 == 1014);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560636332628L + "'", long10 == 1560636332628L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 959L + "'", long68 == 959L);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test059");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZoneUTC();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(chronology3);
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, (int) (byte) 100);
//        org.joda.time.DateTime dateTime9 = dateTime4.minusMinutes(0);
//        org.joda.time.DateTime dateTime11 = dateTime4.withYearOfEra(10);
//        long long12 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTime dateTime13 = dateTime11.withLaterOffsetAtOverlap();
//        boolean boolean15 = dateTime11.isEqual((long) 'a');
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (byte) 100);
//        org.joda.time.DateTime dateTime22 = dateTime17.minusMinutes(0);
//        org.joda.time.Chronology chronology23 = null;
//        org.joda.time.MutableDateTime mutableDateTime24 = dateTime17.toMutableDateTime(chronology23);
//        org.joda.time.LocalDate localDate25 = dateTime17.toLocalDate();
//        org.joda.time.DateTime dateTime26 = dateTime11.withFields((org.joda.time.ReadablePartial) localDate25);
//        java.lang.String str27 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate25);
//        try {
//            org.joda.time.DateTime dateTime29 = dateTimeFormatter0.parseDateTime("+00:00:00.010");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+00:00:00.010\" is malformed at \":00:00.010\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimePrinter1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61851599999680L) + "'", long12 == (-61851599999680L));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1970-W01" + "'", str27.equals("1970-W01"));
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(chronology3);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test061");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
//        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(10);
//        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.minus(readablePeriod10);
//        try {
//            org.joda.time.DateTime dateTime13 = dateTime8.withWeekOfWeekyear(649);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 649 for weekOfWeekyear must be in the range [1,53]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61851599999680L) + "'", long9 == (-61851599999680L));
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(chronology3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.withPeriodAdded(readablePeriod7, (int) (byte) 100);
        org.joda.time.DateTime dateTime11 = dateTime6.minusMinutes(0);
        org.joda.time.DateTime dateTime13 = dateTime6.withYearOfEra(10);
        org.joda.time.DateTime dateTime15 = dateTime6.minusYears((int) ' ');
        int int16 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime18 = dateTime4.plusDays((int) (byte) 10);
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(chronology19);
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withPeriodAdded(readablePeriod21, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration24 = null;
        org.joda.time.DateTime dateTime26 = dateTime23.withDurationAdded(readableDuration24, (int) (short) 100);
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(chronology27);
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.DateTime dateTime31 = dateTime28.withPeriodAdded(readablePeriod29, (int) (byte) 100);
        org.joda.time.DateTime dateTime33 = dateTime28.minusMinutes(0);
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime23, (org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(chronology34);
        org.joda.time.DateTime.Property property36 = dateTime35.monthOfYear();
        org.joda.time.DateTime dateTime37 = property36.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property36.getFieldType();
        boolean boolean39 = dateTime18.isSupported(dateTimeFieldType38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder1.appendText(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
        boolean boolean5 = offsetDateTimeField3.isSupported();
        boolean boolean6 = offsetDateTimeField3.isSupported();
        boolean boolean8 = offsetDateTimeField3.isLeap((-61837261301676L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) (byte) 100);
        org.joda.time.DateTime dateTime8 = dateTime3.minusMinutes(0);
        org.joda.time.DateTime dateTime10 = dateTime3.withYearOfEra(10);
        org.joda.time.DateTime dateTime12 = dateTime3.minusYears((int) ' ');
        int int13 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime15 = dateTime1.plusDays((int) (byte) 10);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, (int) (short) 100);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(chronology24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.withPeriodAdded(readablePeriod26, (int) (byte) 100);
        org.joda.time.DateTime dateTime30 = dateTime25.minusMinutes(0);
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime20, (org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now(chronology31);
        org.joda.time.DateTime.Property property33 = dateTime32.monthOfYear();
        org.joda.time.DateTime dateTime34 = property33.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property33.getFieldType();
        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType35);
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
        org.joda.time.ReadableDuration readableDuration38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.minus(readableDuration38);
        org.joda.time.DateTime.Property property40 = dateTime39.minuteOfDay();
        org.joda.time.DurationField durationField41 = property40.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField42 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField41);
        long long45 = unsupportedDateTimeField42.add((-61837261293808L), 43880629L);
        long long48 = unsupportedDateTimeField42.getDifferenceAsLong((long) (short) 1, (long) 'a');
        try {
            boolean boolean50 = unsupportedDateTimeField42.isLeap(11965L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 3729449084306192L + "'", long45 == 3729449084306192L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(readableDuration5, (int) (short) 100);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.withPeriodAdded(readablePeriod10, (int) (byte) 100);
        org.joda.time.DateTime dateTime14 = dateTime9.minusMinutes(0);
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime4, (org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(chronology15);
        org.joda.time.DateTime.Property property17 = dateTime16.monthOfYear();
        org.joda.time.DateTime dateTime18 = property17.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property17.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 3L, "2019-06-15T15:05:30.038-07:00");
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, "6");
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test066");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.withPeriodAdded(readablePeriod3, (int) (byte) 100);
//        int int6 = dateTime2.getHourOfDay();
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) dateTime2, chronology7);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime8.minus(readablePeriod9);
//        org.joda.time.LocalDateTime localDateTime11 = dateTime10.toLocalDateTime();
//        boolean boolean12 = dateTimeZone0.isLocalDateTimeGap(localDateTime11);
//        try {
//            org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 366);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 366");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(localDateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField3 = iSOChronology0.weeks();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField5 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test068");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendHalfdayOfDayText();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendTimeZoneShortName(strMap5);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitYear(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendSecondOfMinute(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder12.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.append(dateTimeFormatter14);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder12.appendHalfdayOfDayText();
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(chronology17);
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.DateTime dateTime21 = dateTime18.withPeriodAdded(readablePeriod19, (int) (byte) 100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
//        boolean boolean23 = dateTime21.isSupported(dateTimeFieldType22);
//        org.joda.time.DateTime dateTime25 = dateTime21.plusHours(993);
//        org.joda.time.DateTimeZone dateTimeZone26 = dateTime21.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 15);
//        org.joda.time.DurationField durationField31 = offsetDateTimeField30.getDurationField();
//        boolean boolean32 = offsetDateTimeField30.isSupported();
//        org.joda.time.Chronology chronology33 = null;
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(chronology33);
//        org.joda.time.ReadablePeriod readablePeriod35 = null;
//        org.joda.time.DateTime dateTime37 = dateTime34.withPeriodAdded(readablePeriod35, (int) (byte) 100);
//        int int38 = dateTime34.getHourOfDay();
//        org.joda.time.Chronology chronology39 = null;
//        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((java.lang.Object) dateTime34, chronology39);
//        org.joda.time.ReadablePeriod readablePeriod41 = null;
//        org.joda.time.DateTime dateTime42 = dateTime40.minus(readablePeriod41);
//        org.joda.time.DateTime.Property property43 = dateTime40.dayOfYear();
//        org.joda.time.DateTime dateTime44 = property43.roundCeilingCopy();
//        java.util.Locale locale46 = null;
//        org.joda.time.DateTime dateTime47 = property43.setCopy("6", locale46);
//        org.joda.time.DateTime dateTime48 = dateTime47.withEarlierOffsetAtOverlap();
//        org.joda.time.LocalDateTime localDateTime49 = dateTime47.toLocalDateTime();
//        int int50 = offsetDateTimeField30.getMinimumValue((org.joda.time.ReadablePartial) localDateTime49);
//        org.joda.time.DateTime dateTime51 = dateTime21.withFields((org.joda.time.ReadablePartial) localDateTime49);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder52.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder52.appendYearOfEra((int) '#', (int) (short) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder52.appendDayOfWeek(3);
//        org.joda.time.Chronology chronology59 = null;
//        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime(chronology59);
//        org.joda.time.ReadablePeriod readablePeriod61 = null;
//        org.joda.time.DateTime dateTime63 = dateTime60.withPeriodAdded(readablePeriod61, (int) (byte) 100);
//        org.joda.time.ReadableDuration readableDuration64 = null;
//        org.joda.time.DateTime dateTime66 = dateTime63.withDurationAdded(readableDuration64, (int) (short) 100);
//        org.joda.time.Chronology chronology67 = null;
//        org.joda.time.DateTime dateTime68 = new org.joda.time.DateTime(chronology67);
//        org.joda.time.ReadablePeriod readablePeriod69 = null;
//        org.joda.time.DateTime dateTime71 = dateTime68.withPeriodAdded(readablePeriod69, (int) (byte) 100);
//        org.joda.time.DateTime dateTime73 = dateTime68.minusMinutes(0);
//        org.joda.time.Chronology chronology74 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime63, (org.joda.time.ReadableInstant) dateTime73);
//        org.joda.time.DateTime dateTime75 = org.joda.time.DateTime.now(chronology74);
//        org.joda.time.DateTime.Property property76 = dateTime75.monthOfYear();
//        org.joda.time.DateTime dateTime77 = property76.roundHalfCeilingCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType78 = property76.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder79 = dateTimeFormatterBuilder52.appendShortText(dateTimeFieldType78);
//        org.joda.time.DateTime.Property property80 = dateTime21.property(dateTimeFieldType78);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder82 = dateTimeFormatterBuilder16.appendFixedDecimal(dateTimeFieldType78, 67);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder84 = dateTimeFormatterBuilder6.appendFixedSignedDecimal(dateTimeFieldType78, 960);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder87 = dateTimeFormatterBuilder84.appendYearOfEra(690, 366);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(iSOChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(localDateTime49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 15 + "'", int50 == 15);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(dateTime66);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(dateTime73);
//        org.junit.Assert.assertNotNull(chronology74);
//        org.junit.Assert.assertNotNull(dateTime75);
//        org.junit.Assert.assertNotNull(property76);
//        org.junit.Assert.assertNotNull(dateTime77);
//        org.junit.Assert.assertNotNull(dateTimeFieldType78);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder79);
//        org.junit.Assert.assertNotNull(property80);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder82);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder84);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder87);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 330, 138);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test070");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
//        java.lang.String str9 = fixedDateTimeZone7.getNameKey((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
//        java.util.TimeZone timeZone12 = dateTimeZone11.toTimeZone();
//        java.lang.String str14 = dateTimeZone11.getName((long) (byte) 10);
//        java.lang.String str15 = dateTimeZone11.toString();
//        org.joda.time.Chronology chronology16 = zonedChronology10.withZone(dateTimeZone11);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
//        org.junit.Assert.assertNotNull(zonedChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Coordinated Universal Time" + "'", str14.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
//        org.junit.Assert.assertNotNull(chronology16);
//    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test071");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readablePeriod8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfMonth();
//        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
//        int int12 = property10.getMinimumValue();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (byte) -1);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, 6);
        java.util.Locale locale9 = null;
        int int10 = offsetDateTimeField8.getMaximumShortTextLength(locale9);
        long long13 = offsetDateTimeField8.add(0L, 72680694);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 72680694L + "'", long13 == 72680694L);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test073");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.DateTime.Property property6 = dateTime1.millisOfSecond();
//        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime9 = property6.setCopy(11);
//        org.joda.time.DateTime dateTime11 = dateTime9.withYearOfEra(2068);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime8 = dateTime4.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = dateTime8.plusMonths((int) (short) -1);
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime8.toMutableDateTime();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime8.plus(readablePeriod12);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) 708, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) (byte) 100);
        org.joda.time.DateTime dateTime8 = dateTime3.minusMinutes(0);
        org.joda.time.DateTime dateTime10 = dateTime3.withYearOfEra(10);
        org.joda.time.DateTime dateTime12 = dateTime3.minusYears((int) ' ');
        int int13 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime15 = dateTime1.plusDays((int) (byte) 10);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, (int) (short) 100);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(chronology24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.withPeriodAdded(readablePeriod26, (int) (byte) 100);
        org.joda.time.DateTime dateTime30 = dateTime25.minusMinutes(0);
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime20, (org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now(chronology31);
        org.joda.time.DateTime.Property property33 = dateTime32.monthOfYear();
        org.joda.time.DateTime dateTime34 = property33.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property33.getFieldType();
        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType35);
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
        org.joda.time.ReadableDuration readableDuration38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.minus(readableDuration38);
        org.joda.time.DateTime.Property property40 = dateTime39.minuteOfDay();
        org.joda.time.DurationField durationField41 = property40.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField42 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField41);
        long long45 = unsupportedDateTimeField42.add((-61837261293808L), 43880629L);
        boolean boolean46 = unsupportedDateTimeField42.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = unsupportedDateTimeField42.getType();
        try {
            long long50 = unsupportedDateTimeField42.addWrapField((-61837261297024L), 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 3729449084306192L + "'", long45 == 3729449084306192L);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyear();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField5 = iSOChronology4.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str13 = fixedDateTimeZone11.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology4.hourOfDay();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology4.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology4.dayOfYear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder18.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder18.appendYearOfEra((int) '#', (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder18.appendDayOfWeek(3);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(chronology25);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.DateTime dateTime29 = dateTime26.withPeriodAdded(readablePeriod27, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration30 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.withDurationAdded(readableDuration30, (int) (short) 100);
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(chronology33);
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime37 = dateTime34.withPeriodAdded(readablePeriod35, (int) (byte) 100);
        org.joda.time.DateTime dateTime39 = dateTime34.minusMinutes(0);
        org.joda.time.Chronology chronology40 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime29, (org.joda.time.ReadableInstant) dateTime39);
        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now(chronology40);
        org.joda.time.DateTime.Property property42 = dateTime41.monthOfYear();
        org.joda.time.DateTime dateTime43 = property42.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property42.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder18.appendShortText(dateTimeFieldType44);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, dateTimeFieldType44, 2019, 674, 12);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField51 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType44, 11);
        long long53 = dividedDateTimeField51.remainder((long) 100);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField54 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField51);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 100L + "'", long53 == 100L);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyear();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField5 = iSOChronology4.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str13 = fixedDateTimeZone11.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology4.hourOfDay();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology4.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology4.dayOfYear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder18.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder18.appendYearOfEra((int) '#', (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder18.appendDayOfWeek(3);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(chronology25);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.DateTime dateTime29 = dateTime26.withPeriodAdded(readablePeriod27, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration30 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.withDurationAdded(readableDuration30, (int) (short) 100);
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(chronology33);
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime37 = dateTime34.withPeriodAdded(readablePeriod35, (int) (byte) 100);
        org.joda.time.DateTime dateTime39 = dateTime34.minusMinutes(0);
        org.joda.time.Chronology chronology40 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime29, (org.joda.time.ReadableInstant) dateTime39);
        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now(chronology40);
        org.joda.time.DateTime.Property property42 = dateTime41.monthOfYear();
        org.joda.time.DateTime dateTime43 = property42.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property42.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder18.appendShortText(dateTimeFieldType44);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, dateTimeFieldType44, 2019, 674, 12);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField51 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType44, 11);
        long long54 = dividedDateTimeField51.add((long) 36, 59);
        int int55 = dividedDateTimeField51.getMinimumValue();
        int int56 = dividedDateTimeField51.getDivisor();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField51);
        long long60 = dividedDateTimeField51.getDifferenceAsLong(6998816L, (-61823015733898L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 20480947200036L + "'", long54 == 20480947200036L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-26570460) + "'", int55 == (-26570460));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 11 + "'", int56 == 11);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 178L + "'", long60 == 178L);
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test079");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(readableDuration5, (int) (short) 100);
//        int int8 = dateTime7.getMinuteOfHour();
//        int int9 = dateTime7.getDayOfWeek();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
//    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test080");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
//        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(10);
//        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime10 = dateTime8.withLaterOffsetAtOverlap();
//        int int11 = dateTime10.getMinuteOfHour();
//        org.joda.time.DateTime.Property property12 = dateTime10.centuryOfEra();
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(chronology13);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) (byte) 100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        boolean boolean19 = dateTime17.isSupported(dateTimeFieldType18);
//        org.joda.time.DateTime dateTime21 = dateTime17.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime23 = dateTime17.minusMillis((int) (byte) 10);
//        org.joda.time.DateTime dateTime25 = dateTime17.minusDays(2);
//        org.joda.time.DateTime dateTime27 = dateTime17.withCenturyOfEra((int) (short) 0);
//        org.joda.time.DateTime.Property property28 = dateTime17.monthOfYear();
//        org.joda.time.DateTime dateTime29 = property28.roundFloorCopy();
//        org.joda.time.LocalDateTime localDateTime30 = dateTime29.toLocalDateTime();
//        int int31 = property12.compareTo((org.joda.time.ReadablePartial) localDateTime30);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61851599999680L) + "'", long9 == (-61851599999680L));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(localDateTime30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendHourOfHalfday(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendDayOfWeekText();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.withPeriodAdded(readablePeriod9, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded(readableDuration12, (int) (short) 100);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) (byte) 100);
        org.joda.time.DateTime dateTime21 = dateTime16.minusMinutes(0);
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime11, (org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now(chronology22);
        org.joda.time.DateTime.Property property24 = dateTime23.monthOfYear();
        org.joda.time.DateTime dateTime25 = property24.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder6.appendShortText(dateTimeFieldType26);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.format.DateTimeParser dateTimeParser29 = dateTimeFormatter28.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder27.append(dateTimeParser29);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder30.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendMillisOfSecond(2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTimeParser29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfDay(2, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfMinute(0, 2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendFractionOfSecond((int) (byte) 0, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder6.appendMinuteOfDay(2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder17.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendHourOfHalfday(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder18.appendLiteral("2019-06-15T05:05:22.051-07:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder22.appendTwoDigitYear(431, false);
        org.joda.time.Chronology chronology26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(chronology26);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime30 = dateTime27.withPeriodAdded(readablePeriod28, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration31 = null;
        org.joda.time.DateTime dateTime33 = dateTime30.withDurationAdded(readableDuration31, (int) (short) 100);
        org.joda.time.Chronology chronology34 = null;
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(chronology34);
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.DateTime dateTime38 = dateTime35.withPeriodAdded(readablePeriod36, (int) (byte) 100);
        org.joda.time.DateTime dateTime40 = dateTime35.minusMinutes(0);
        org.joda.time.Chronology chronology41 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime30, (org.joda.time.ReadableInstant) dateTime40);
        org.joda.time.DateTime dateTime42 = org.joda.time.DateTime.now(chronology41);
        org.joda.time.DateTime.Property property43 = dateTime42.monthOfYear();
        org.joda.time.DateTime dateTime44 = property43.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property43.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException48 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType45, (java.lang.Number) 3L, "2019-06-15T15:05:30.038-07:00");
        org.joda.time.IllegalFieldValueException illegalFieldValueException50 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType45, "2019-06-15T15:05:30.038-07:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder22.appendFixedSignedDecimal(dateTimeFieldType45, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder6.appendFixedDecimal(dateTimeFieldType45, 413);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap55 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder6.appendTimeZoneShortName(strMap55);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test083");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gregorianChronology0.equals(obj1);
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 15);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getDurationField();
//        boolean boolean8 = offsetDateTimeField6.isSupported();
//        boolean boolean9 = gregorianChronology0.equals((java.lang.Object) offsetDateTimeField6);
//        int int11 = offsetDateTimeField6.get((-61837261290785L));
//        long long13 = offsetDateTimeField6.roundFloor(79533557L);
//        org.joda.time.Chronology chronology14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(chronology14);
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.withPeriodAdded(readablePeriod16, (int) (byte) 100);
//        int int19 = dateTime15.getHourOfDay();
//        long long20 = dateTime15.getMillis();
//        org.joda.time.DateTime dateTime22 = dateTime15.plus((long) 15);
//        org.joda.time.LocalTime localTime23 = dateTime15.toLocalTime();
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = offsetDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) localTime23, locale24);
//        long long28 = offsetDateTimeField6.add(9L, (long) 3);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 230 + "'", int11 == 230);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 79533557L + "'", long13 == 79533557L);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 320L + "'", long20 == 320L);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(localTime23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "320" + "'", str25.equals("320"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 12L + "'", long28 == 12L);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) (byte) 100);
        org.joda.time.DateTime dateTime8 = dateTime3.minusMinutes(0);
        org.joda.time.DateTime dateTime10 = dateTime3.withYearOfEra(10);
        org.joda.time.DateTime dateTime12 = dateTime3.minusYears((int) ' ');
        int int13 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime15 = dateTime1.plusDays((int) (byte) 10);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, (int) (short) 100);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(chronology24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.withPeriodAdded(readablePeriod26, (int) (byte) 100);
        org.joda.time.DateTime dateTime30 = dateTime25.minusMinutes(0);
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime20, (org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now(chronology31);
        org.joda.time.DateTime.Property property33 = dateTime32.monthOfYear();
        org.joda.time.DateTime dateTime34 = property33.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property33.getFieldType();
        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType35);
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
        org.joda.time.ReadableDuration readableDuration38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.minus(readableDuration38);
        org.joda.time.DateTime.Property property40 = dateTime39.minuteOfDay();
        org.joda.time.DurationField durationField41 = property40.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField42 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField41);
        long long45 = unsupportedDateTimeField42.add((-61837261293808L), 43880629L);
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = unsupportedDateTimeField42.getType();
        java.util.Locale locale48 = null;
        try {
            java.lang.String str49 = unsupportedDateTimeField42.getAsText((long) 690, locale48);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 3729449084306192L + "'", long45 == 3729449084306192L);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) (byte) 100);
        org.joda.time.DateTime dateTime8 = dateTime3.minusMinutes(0);
        org.joda.time.DateTime dateTime10 = dateTime3.withYearOfEra(10);
        org.joda.time.DateTime dateTime12 = dateTime3.minusYears((int) ' ');
        int int13 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime15 = dateTime1.plusDays((int) (byte) 10);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, (int) (short) 100);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(chronology24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.withPeriodAdded(readablePeriod26, (int) (byte) 100);
        org.joda.time.DateTime dateTime30 = dateTime25.minusMinutes(0);
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime20, (org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now(chronology31);
        org.joda.time.DateTime.Property property33 = dateTime32.monthOfYear();
        org.joda.time.DateTime dateTime34 = property33.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property33.getFieldType();
        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType35);
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
        org.joda.time.ReadableDuration readableDuration38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.minus(readableDuration38);
        org.joda.time.DateTime.Property property40 = dateTime39.minuteOfDay();
        org.joda.time.DurationField durationField41 = property40.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField42 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField41);
        long long45 = unsupportedDateTimeField42.add((-61837261293808L), 43880629L);
        boolean boolean46 = unsupportedDateTimeField42.isSupported();
        try {
            int int48 = unsupportedDateTimeField42.getLeapAmount((long) 75);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 3729449084306192L + "'", long45 == 3729449084306192L);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime8 = dateTime4.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = dateTime4.minusMillis((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime4.minusDays(2);
        org.joda.time.Chronology chronology13 = dateTime12.getChronology();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology13);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test087");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.DateTime dateTime9 = dateTime1.withYear((int) (short) 0);
//        org.joda.time.DateTime dateTime11 = dateTime1.minusWeeks((int) (short) 0);
//        java.lang.String str12 = dateTime11.toString();
//        org.joda.time.DateTime.Property property13 = dateTime11.weekyear();
//        boolean boolean15 = property13.equals((java.lang.Object) 75);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970-01-01T00:00:00.320Z" + "'", str12.equals("1970-01-01T00:00:00.320Z"));
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(readableDuration5, (int) (short) 100);
        org.joda.time.DateTime dateTime9 = dateTime7.minusMinutes((int) (byte) 1);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMillis(690);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "(\"org.joda.time.JodaTimePermission\" \"hi!\")");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gregorianChronology0.equals(obj1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 15);
        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getDurationField();
        boolean boolean8 = offsetDateTimeField6.isSupported();
        boolean boolean9 = gregorianChronology0.equals((java.lang.Object) offsetDateTimeField6);
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology0.yearOfCentury();
        org.joda.time.DurationField durationField13 = gregorianChronology0.halfdays();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("ZonedChronology[ISOChronology[UTC], ]", "2019-06-15T15:05:26.574-07:00", 431, 963);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test092");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readablePeriod8);
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime12 = dateTime9.withDurationAdded(readableDuration10, (int) (byte) 0);
//        org.joda.time.DateTime dateTime14 = dateTime9.plusMillis((int) (short) 1);
//        org.joda.time.Chronology chronology15 = null;
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(chronology15);
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) (byte) 100);
//        int int20 = dateTime16.getHourOfDay();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((java.lang.Object) dateTime16, chronology21);
//        org.joda.time.ReadablePeriod readablePeriod23 = null;
//        org.joda.time.DateTime dateTime24 = dateTime22.minus(readablePeriod23);
//        org.joda.time.DateTime dateTime26 = dateTime24.withHourOfDay((int) (byte) 1);
//        boolean boolean27 = dateTime9.isEqual((org.joda.time.ReadableInstant) dateTime26);
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField29 = iSOChronology28.eras();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.dayOfYear();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone35 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
//        java.lang.String str37 = fixedDateTimeZone35.getNameKey((-1L));
//        org.joda.time.chrono.ZonedChronology zonedChronology38 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology28, (org.joda.time.DateTimeZone) fixedDateTimeZone35);
//        org.joda.time.DateTimeField dateTimeField39 = zonedChronology38.era();
//        int int40 = dateTime26.get(dateTimeField39);
//        boolean boolean42 = dateTime26.isAfter((long) (-4));
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
//        org.junit.Assert.assertNotNull(zonedChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str9 = fixedDateTimeZone7.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone7);
        long long14 = zonedChronology10.add(30L, (long) 2019, 330);
        org.joda.time.DateTimeZone dateTimeZone15 = zonedChronology10.getZone();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 666300L + "'", long14 == 666300L);
        org.junit.Assert.assertNotNull(dateTimeZone15);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test094");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.ReadableDuration readableDuration1 = null;
//        org.joda.time.DateTime dateTime2 = dateTime0.minus(readableDuration1);
//        org.joda.time.DateTime dateTime4 = dateTime0.withCenturyOfEra((int) (short) 10);
//        int int5 = dateTime0.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str8 = dateTimeZone6.getName((long) 15);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = dateTimeZone6.getShortName((long) (short) 0, locale10);
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = dateTimeZone6.getShortName((long) (short) 100, locale13);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone6);
//        int int17 = dateTimeZone6.getOffsetFromLocal((long) 100);
//        org.joda.time.DateTime dateTime18 = dateTime0.toDateTime(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test095");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.DateTime dateTime9 = dateTime1.withYear((int) (short) 0);
//        org.joda.time.DateTime dateTime11 = dateTime1.minusWeeks((int) (short) 0);
//        java.lang.String str12 = dateTime11.toString();
//        org.joda.time.DateTime dateTime14 = dateTime11.plusSeconds((int) (byte) -1);
//        org.joda.time.DateTime dateTime16 = dateTime11.plusMillis((int) (byte) 10);
//        org.joda.time.DateTime dateTime18 = dateTime16.minusMillis(0);
//        org.joda.time.DateTimeField dateTimeField19 = null;
//        try {
//            int int20 = dateTime16.get(dateTimeField19);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeField must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970-01-01T00:00:00.320Z" + "'", str12.equals("1970-01-01T00:00:00.320Z"));
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatterBuilder3.toParser();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap5);
        dateTimeFormatterBuilder3.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendYearOfCentury((int) (byte) 1, 3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendFractionOfDay(366, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder12.appendYearOfEra(14, 919);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder12.appendFractionOfMinute(0, (-26570460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test097");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) (byte) 100);
//        org.joda.time.DateTime dateTime8 = dateTime3.minusMinutes(0);
//        org.joda.time.DateTime dateTime10 = dateTime3.withYearOfEra(10);
//        org.joda.time.DateTime dateTime12 = dateTime3.minusYears((int) ' ');
//        int int13 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DateTime dateTime15 = dateTime1.plusDays((int) (byte) 10);
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (byte) 100);
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, (int) (short) 100);
//        org.joda.time.Chronology chronology24 = null;
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(chronology24);
//        org.joda.time.ReadablePeriod readablePeriod26 = null;
//        org.joda.time.DateTime dateTime28 = dateTime25.withPeriodAdded(readablePeriod26, (int) (byte) 100);
//        org.joda.time.DateTime dateTime30 = dateTime25.minusMinutes(0);
//        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime20, (org.joda.time.ReadableInstant) dateTime30);
//        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now(chronology31);
//        org.joda.time.DateTime.Property property33 = dateTime32.monthOfYear();
//        org.joda.time.DateTime dateTime34 = property33.roundHalfCeilingCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property33.getFieldType();
//        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType35);
//        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
//        org.joda.time.ReadableDuration readableDuration38 = null;
//        org.joda.time.DateTime dateTime39 = dateTime37.minus(readableDuration38);
//        org.joda.time.DateTime.Property property40 = dateTime39.minuteOfDay();
//        org.joda.time.DurationField durationField41 = property40.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField42 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField41);
//        long long45 = unsupportedDateTimeField42.add((-61837261293808L), 43880629L);
//        boolean boolean46 = unsupportedDateTimeField42.isSupported();
//        org.joda.time.DurationField durationField47 = unsupportedDateTimeField42.getRangeDurationField();
//        java.lang.String str48 = unsupportedDateTimeField42.toString();
//        org.joda.time.Chronology chronology49 = null;
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime(chronology49);
//        org.joda.time.ReadablePeriod readablePeriod51 = null;
//        org.joda.time.DateTime dateTime53 = dateTime50.withPeriodAdded(readablePeriod51, (int) (byte) 100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType54 = null;
//        boolean boolean55 = dateTime53.isSupported(dateTimeFieldType54);
//        org.joda.time.DateTime dateTime57 = dateTime53.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime59 = dateTime57.plusMonths((int) (short) -1);
//        org.joda.time.DateTime dateTime61 = dateTime59.withWeekyear((int) '4');
//        org.joda.time.Chronology chronology62 = null;
//        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime(chronology62);
//        org.joda.time.ReadablePeriod readablePeriod64 = null;
//        org.joda.time.DateTime dateTime66 = dateTime63.withPeriodAdded(readablePeriod64, (int) (byte) 100);
//        int int67 = dateTime63.getHourOfDay();
//        org.joda.time.Chronology chronology68 = null;
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime((java.lang.Object) dateTime63, chronology68);
//        org.joda.time.Chronology chronology70 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime59, (org.joda.time.ReadableInstant) dateTime63);
//        org.joda.time.Chronology chronology72 = null;
//        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime((long) (short) -1, chronology72);
//        int int74 = dateTime73.getWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone75 = dateTime73.getZone();
//        long long79 = dateTimeZone75.convertLocalToUTC(0L, true, (long) 1);
//        org.joda.time.Chronology chronology80 = null;
//        org.joda.time.DateTime dateTime81 = new org.joda.time.DateTime(chronology80);
//        org.joda.time.ReadablePeriod readablePeriod82 = null;
//        org.joda.time.DateTime dateTime84 = dateTime81.withPeriodAdded(readablePeriod82, (int) (byte) 100);
//        int int85 = dateTime81.getHourOfDay();
//        org.joda.time.Chronology chronology86 = null;
//        org.joda.time.DateTime dateTime87 = new org.joda.time.DateTime((java.lang.Object) dateTime81, chronology86);
//        org.joda.time.ReadablePeriod readablePeriod88 = null;
//        org.joda.time.DateTime dateTime89 = dateTime87.minus(readablePeriod88);
//        org.joda.time.LocalDateTime localDateTime90 = dateTime89.toLocalDateTime();
//        boolean boolean91 = dateTimeZone75.isLocalDateTimeGap(localDateTime90);
//        org.joda.time.DateTime dateTime92 = dateTime59.withFields((org.joda.time.ReadablePartial) localDateTime90);
//        int[] intArray95 = new int[] { 10 };
//        try {
//            int[] intArray97 = unsupportedDateTimeField42.set((org.joda.time.ReadablePartial) localDateTime90, 339, intArray95, 339);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(chronology31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField42);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 3729449084306192L + "'", long45 == 3729449084306192L);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNull(durationField47);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "UnsupportedDateTimeField" + "'", str48.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(dateTime66);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
//        org.junit.Assert.assertNotNull(chronology70);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1970 + "'", int74 == 1970);
//        org.junit.Assert.assertNotNull(dateTimeZone75);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 0L + "'", long79 == 0L);
//        org.junit.Assert.assertNotNull(dateTime84);
//        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
//        org.junit.Assert.assertNotNull(dateTime89);
//        org.junit.Assert.assertNotNull(localDateTime90);
//        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
//        org.junit.Assert.assertNotNull(dateTime92);
//        org.junit.Assert.assertNotNull(intArray95);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendFractionOfSecond(365, (int) ' ');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHour();
        boolean boolean9 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeFormatterBuilder7, (java.lang.Object) dateTimeFormatter8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) (byte) 100);
        org.joda.time.DateTime dateTime8 = dateTime3.minusMinutes(0);
        org.joda.time.DateTime dateTime10 = dateTime3.withYearOfEra(10);
        org.joda.time.DateTime dateTime12 = dateTime3.minusYears((int) ' ');
        int int13 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime15 = dateTime1.plusDays((int) (byte) 10);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, (int) (short) 100);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(chronology24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.withPeriodAdded(readablePeriod26, (int) (byte) 100);
        org.joda.time.DateTime dateTime30 = dateTime25.minusMinutes(0);
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime20, (org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now(chronology31);
        org.joda.time.DateTime.Property property33 = dateTime32.monthOfYear();
        org.joda.time.DateTime dateTime34 = property33.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property33.getFieldType();
        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType35);
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
        org.joda.time.ReadableDuration readableDuration38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.minus(readableDuration38);
        org.joda.time.DateTime.Property property40 = dateTime39.minuteOfDay();
        org.joda.time.DurationField durationField41 = property40.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField42 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField41);
        try {
            int int44 = unsupportedDateTimeField42.get(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField42);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withPeriodAdded(readablePeriod3, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        boolean boolean7 = dateTime5.isSupported(dateTimeFieldType6);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMonths((int) (short) -1);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        org.joda.time.DateTime.Property property13 = dateTime11.dayOfWeek();
        org.joda.time.DateTime dateTime18 = dateTime11.withTime(19, 19, 0, 100);
        java.lang.String str19 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime18);
        java.lang.Appendable appendable20 = null;
        org.joda.time.ReadablePartial readablePartial21 = null;
        try {
            dateTimeFormatter0.printTo(appendable20, readablePartial21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "19" + "'", str19.equals("19"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str9 = fixedDateTimeZone7.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology10.era();
        org.joda.time.Chronology chronology12 = zonedChronology10.withUTC();
        org.joda.time.Chronology chronology13 = zonedChronology10.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(chronology13);
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test103");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime1.toMutableDateTime(chronology7);
//        org.joda.time.LocalDate localDate9 = dateTime1.toLocalDate();
//        int int10 = dateTime1.getMonthOfYear();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test104");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
//        org.joda.time.DateTime dateTime8 = dateTime4.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime10 = dateTime4.minusMillis((int) (byte) 10);
//        org.joda.time.DateTime dateTime12 = dateTime4.minusDays(2);
//        org.joda.time.DateTime dateTime14 = dateTime4.withCenturyOfEra((int) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str17 = dateTimeZone15.getName((long) 15);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone15.getShortName((long) (short) 0, locale19);
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = dateTimeZone15.getShortName((long) (short) 100, locale22);
//        org.joda.time.DateTime dateTime24 = dateTime14.withZoneRetainFields(dateTimeZone15);
//        org.joda.time.DateTime dateTime26 = dateTime14.withWeekyear(2019);
//        org.joda.time.DateTime dateTime28 = dateTime26.withMonthOfYear(12);
//        org.joda.time.DateTime.Property property29 = dateTime26.minuteOfHour();
//        org.joda.time.DateTime.Property property30 = dateTime26.centuryOfEra();
//        org.joda.time.DateTime.Property property31 = dateTime26.secondOfMinute();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Coordinated Universal Time" + "'", str17.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "UTC" + "'", str23.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(property31);
//    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test105");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gregorianChronology0.equals(obj1);
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(chronology3);
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, (int) (byte) 100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
//        boolean boolean9 = dateTime7.isSupported(dateTimeFieldType8);
//        org.joda.time.DateTime dateTime11 = dateTime7.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime13 = dateTime7.minusMillis((int) (byte) 10);
//        org.joda.time.LocalDate localDate14 = dateTime7.toLocalDate();
//        long long16 = gregorianChronology0.set((org.joda.time.ReadablePartial) localDate14, 1L);
//        java.lang.String str17 = gregorianChronology0.toString();
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(chronology18);
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        org.joda.time.DateTime dateTime22 = dateTime19.withPeriodAdded(readablePeriod20, (int) (byte) 100);
//        org.joda.time.DateTime dateTime24 = dateTime19.minusMinutes(0);
//        org.joda.time.DateTime dateTime26 = dateTime19.withYearOfEra(10);
//        org.joda.time.ReadablePeriod readablePeriod27 = null;
//        org.joda.time.DateTime dateTime28 = dateTime26.plus(readablePeriod27);
//        org.joda.time.DateTime.Property property29 = dateTime26.dayOfMonth();
//        org.joda.time.DurationField durationField30 = property29.getDurationField();
//        boolean boolean31 = gregorianChronology0.equals((java.lang.Object) durationField30);
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology0.yearOfEra();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "GregorianChronology[UTC]" + "'", str17.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test106");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.lang.Object obj2 = null;
//        boolean boolean3 = gregorianChronology1.equals(obj2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 15);
//        org.joda.time.DurationField durationField8 = offsetDateTimeField7.getDurationField();
//        boolean boolean9 = offsetDateTimeField7.isSupported();
//        boolean boolean10 = gregorianChronology1.equals((java.lang.Object) offsetDateTimeField7);
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime15 = dateTime12.withPeriodAdded(readablePeriod13, (int) (byte) 100);
//        int int16 = dateTime12.getHourOfDay();
//        org.joda.time.DateTime.Property property17 = dateTime12.millisOfSecond();
//        boolean boolean19 = property17.equals((java.lang.Object) 100.0f);
//        org.joda.time.DateTime dateTime20 = property17.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime21 = property17.roundHalfFloorCopy();
//        int int22 = property17.get();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = property17.getAsText(locale23);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = property17.getAsText(locale25);
//        boolean boolean27 = gregorianChronology1.equals((java.lang.Object) property17);
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) "2019-06-15T15:05:30.038-07:00", (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeZone dateTimeZone29 = gregorianChronology1.getZone();
//        try {
//            long long34 = gregorianChronology1.getDateTimeMillis(1014, 67, 36, 43879275);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 67 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 320 + "'", int22 == 320);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "320" + "'", str24.equals("320"));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "320" + "'", str26.equals("320"));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.LocalTime localTime3 = dateTimeFormatter1.parseLocalTime("32");
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(localTime3);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test108");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readablePeriod8);
//        org.joda.time.DateTime dateTime11 = dateTime9.withHourOfDay((int) (byte) 1);
//        java.util.Date date12 = dateTime9.toDate();
//        org.joda.time.DateTime.Property property13 = dateTime9.weekOfWeekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray15 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType14 };
//        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList16 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
//        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList16, dateTimeFieldTypeArray15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList16, false, false);
//        java.util.Locale locale21 = dateTimeFormatter20.getLocale();
//        java.lang.Appendable appendable22 = null;
//        org.joda.time.Chronology chronology23 = null;
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(chronology23);
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime27 = dateTime24.withPeriodAdded(readablePeriod25, (int) (byte) 100);
//        int int28 = dateTime24.getHourOfDay();
//        org.joda.time.Chronology chronology29 = null;
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) dateTime24, chronology29);
//        org.joda.time.ReadablePeriod readablePeriod31 = null;
//        org.joda.time.DateTime dateTime32 = dateTime30.minus(readablePeriod31);
//        int int33 = dateTime30.getYear();
//        org.joda.time.ReadablePeriod readablePeriod34 = null;
//        org.joda.time.DateTime dateTime35 = dateTime30.minus(readablePeriod34);
//        org.joda.time.DateTime dateTime37 = dateTime30.plus(1560636332628L);
//        java.util.GregorianCalendar gregorianCalendar38 = dateTime37.toGregorianCalendar();
//        try {
//            dateTimeFormatter20.printTo(appendable22, (org.joda.time.ReadableInstant) dateTime37);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertNull(locale21);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1970 + "'", int33 == 1970);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(gregorianCalendar38);
//    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test109");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfEra((int) '#', (int) (short) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendDayOfWeek(3);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendHourOfHalfday(15);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendFractionOfSecond(0, 2000);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendHourOfDay(0);
//        org.joda.time.Chronology chronology14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(chronology14);
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.withPeriodAdded(readablePeriod16, (int) (byte) 100);
//        int int19 = dateTime15.getHourOfDay();
//        org.joda.time.Chronology chronology20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) dateTime15, chronology20);
//        org.joda.time.ReadablePeriod readablePeriod22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime21.minus(readablePeriod22);
//        org.joda.time.DateTime dateTime25 = dateTime23.withHourOfDay((int) (byte) 1);
//        java.util.Date date26 = dateTime23.toDate();
//        org.joda.time.DateTime.Property property27 = dateTime23.weekOfWeekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder11.appendDecimal(dateTimeFieldType28, 11, 2019);
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.lang.Object obj34 = null;
//        boolean boolean35 = gregorianChronology33.equals(obj34);
//        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField37 = iSOChronology36.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, 15);
//        org.joda.time.DurationField durationField40 = offsetDateTimeField39.getDurationField();
//        boolean boolean41 = offsetDateTimeField39.isSupported();
//        boolean boolean42 = gregorianChronology33.equals((java.lang.Object) offsetDateTimeField39);
//        org.joda.time.Chronology chronology43 = null;
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(chronology43);
//        org.joda.time.ReadablePeriod readablePeriod45 = null;
//        org.joda.time.DateTime dateTime47 = dateTime44.withPeriodAdded(readablePeriod45, (int) (byte) 100);
//        int int48 = dateTime44.getHourOfDay();
//        org.joda.time.DateTime.Property property49 = dateTime44.millisOfSecond();
//        boolean boolean51 = property49.equals((java.lang.Object) 100.0f);
//        org.joda.time.DateTime dateTime52 = property49.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime53 = property49.roundHalfFloorCopy();
//        int int54 = property49.get();
//        java.util.Locale locale55 = null;
//        java.lang.String str56 = property49.getAsText(locale55);
//        java.util.Locale locale57 = null;
//        java.lang.String str58 = property49.getAsText(locale57);
//        boolean boolean59 = gregorianChronology33.equals((java.lang.Object) property49);
//        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((java.lang.Object) "2019-06-15T15:05:30.038-07:00", (org.joda.time.Chronology) gregorianChronology33);
//        org.joda.time.DateTimeZone dateTimeZone61 = gregorianChronology33.getZone();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone66 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
//        long long68 = fixedDateTimeZone66.previousTransition(0L);
//        long long70 = fixedDateTimeZone66.nextTransition((long) (byte) 0);
//        long long72 = fixedDateTimeZone66.nextTransition((long) 100);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone73 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone66);
//        int int75 = cachedDateTimeZone73.getStandardOffset((long) (byte) 1);
//        int int77 = cachedDateTimeZone73.getStandardOffset((long) 1970);
//        long long79 = cachedDateTimeZone73.previousTransition((long) ' ');
//        long long81 = cachedDateTimeZone73.nextTransition((long) 674);
//        org.joda.time.Chronology chronology82 = gregorianChronology33.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone73);
//        try {
//            org.joda.time.DateTime dateTime83 = new org.joda.time.DateTime((java.lang.Object) 2019, (org.joda.time.DateTimeZone) cachedDateTimeZone73);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(iSOChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 320 + "'", int54 == 320);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "320" + "'", str56.equals("320"));
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "320" + "'", str58.equals("320"));
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone61);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 0L + "'", long70 == 0L);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 100L + "'", long72 == 100L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone73);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 100 + "'", int75 == 100);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 100 + "'", int77 == 100);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 32L + "'", long79 == 32L);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 674L + "'", long81 == 674L);
//        org.junit.Assert.assertNotNull(chronology82);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendDayOfWeek(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMillisOfSecond(1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatter11.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder15.appendTimeZoneShortName();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatterBuilder16.toParser();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap18 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder16.appendTimeZoneName(strMap18);
        dateTimeFormatterBuilder16.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder16.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder21.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder23.appendYearOfEra((int) (byte) 100, 0);
        org.joda.time.format.DateTimePrinter dateTimePrinter29 = dateTimeFormatterBuilder28.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.format.DateTimeParser dateTimeParser31 = dateTimeFormatter30.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter29, dateTimeParser31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder22.appendOptional(dateTimeParser31);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter12, dateTimeParser31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder8.append(dateTimeParser31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimePrinter12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimePrinter29);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTimeParser31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test111");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime1.toMutableDateTime(chronology7);
//        org.joda.time.DateTime dateTime10 = dateTime1.withHourOfDay((int) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
//        java.util.TimeZone timeZone12 = dateTimeZone11.toTimeZone();
//        java.lang.String str14 = dateTimeZone11.getName((long) (byte) 10);
//        org.joda.time.DateTime dateTime15 = dateTime1.toDateTime(dateTimeZone11);
//        org.joda.time.DateTime dateTime17 = dateTime1.minusSeconds(12);
//        org.joda.time.DateTime.Property property18 = dateTime1.yearOfEra();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Coordinated Universal Time" + "'", str14.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test112");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.DateTime.Property property6 = dateTime1.millisOfSecond();
//        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime12 = dateTime9.withPeriodAdded(readablePeriod10, (int) (byte) 100);
//        int int13 = dateTime9.getHourOfDay();
//        org.joda.time.Chronology chronology14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) dateTime9, chronology14);
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime15.minus(readablePeriod16);
//        long long18 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime dateTime19 = property6.roundFloorCopy();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test113");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
//        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
//        boolean boolean5 = offsetDateTimeField3.isSupported();
//        boolean boolean6 = offsetDateTimeField3.isSupported();
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(chronology7);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withPeriodAdded(readablePeriod9, (int) (byte) 100);
//        int int12 = dateTime8.getHourOfDay();
//        org.joda.time.DateTime.Property property13 = dateTime8.millisOfSecond();
//        boolean boolean15 = property13.equals((java.lang.Object) 100.0f);
//        org.joda.time.DateTime dateTime16 = property13.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime17 = property13.roundHalfFloorCopy();
//        org.joda.time.LocalTime localTime18 = dateTime17.toLocalTime();
//        boolean boolean19 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime18);
//        int int20 = offsetDateTimeField3.getMaximumValue((org.joda.time.ReadablePartial) localTime18);
//        boolean boolean22 = offsetDateTimeField3.isLeap(10L);
//        int int23 = offsetDateTimeField3.getMaximumValue();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(localTime18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1014 + "'", int20 == 1014);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1014 + "'", int23 == 1014);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 24, (java.lang.Number) 0.0f, (java.lang.Number) (-61837261301932L));
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException8 = new org.joda.time.IllegalFieldValueException("T16:00:00.000-08:00", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException("T16:00:00.000-08:00", "");
        java.lang.String str12 = illegalFieldValueException11.toString();
        illegalFieldValueException8.addSuppressed((java.lang.Throwable) illegalFieldValueException11);
        org.joda.time.DurationFieldType durationFieldType14 = illegalFieldValueException8.getDurationFieldType();
        java.lang.String str15 = illegalFieldValueException8.toString();
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException("T16:00:00.000-08:00", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException("T16:00:00.000-08:00", "");
        java.lang.String str22 = illegalFieldValueException21.toString();
        illegalFieldValueException18.addSuppressed((java.lang.Throwable) illegalFieldValueException21);
        java.lang.String str24 = illegalFieldValueException21.getIllegalValueAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = illegalFieldValueException21.getDateTimeFieldType();
        java.lang.Number number26 = illegalFieldValueException21.getUpperBound();
        illegalFieldValueException8.addSuppressed((java.lang.Throwable) illegalFieldValueException21);
        java.lang.String str28 = illegalFieldValueException21.getIllegalValueAsString();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException21);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-61837261301932L) + "'", number5.equals((-61837261301932L)));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for T16:00:00.000-08:00 is not supported" + "'", str12.equals("org.joda.time.IllegalFieldValueException: Value \"\" for T16:00:00.000-08:00 is not supported"));
        org.junit.Assert.assertNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for T16:00:00.000-08:00 is not supported" + "'", str15.equals("org.joda.time.IllegalFieldValueException: Value \"\" for T16:00:00.000-08:00 is not supported"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for T16:00:00.000-08:00 is not supported" + "'", str22.equals("org.joda.time.IllegalFieldValueException: Value \"\" for T16:00:00.000-08:00 is not supported"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNull(dateTimeFieldType25);
        org.junit.Assert.assertNull(number26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime8 = dateTime4.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = dateTime8.plusMonths((int) (short) -1);
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime12.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime15 = dateTime12.plusSeconds(2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(readableDuration5, (int) (short) 100);
        int int8 = dateTime7.getMinuteOfHour();
        int int9 = dateTime7.getMinuteOfHour();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test117");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readablePeriod8);
//        org.joda.time.DateTime.Property property10 = dateTime7.dayOfYear();
//        org.joda.time.DateTime dateTime11 = property10.roundCeilingCopy();
//        org.joda.time.DateTime dateTime13 = property10.addToCopy((-1));
//        int int14 = dateTime13.getYearOfCentury();
//        org.joda.time.DateTime dateTime15 = dateTime13.withTimeAtStartOfDay();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTime13.toString("30", locale17);
//        org.joda.time.DateTime.Property property19 = dateTime13.weekOfWeekyear();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 69 + "'", int14 == 69);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "30" + "'", str18.equals("30"));
//        org.junit.Assert.assertNotNull(property19);
//    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test118");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfDay(2, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfMinute(0, 2000);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendFractionOfSecond((int) (byte) 0, 1970);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear(100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendMillisOfSecond(2365);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendClockhourOfDay((int) (byte) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder17.appendYearOfEra((int) (byte) 100, 0);
//        org.joda.time.format.DateTimePrinter dateTimePrinter23 = dateTimeFormatterBuilder22.toPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.dateParser();
//        int int25 = dateTimeFormatter24.getDefaultYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimePrinter dateTimePrinter27 = dateTimeFormatter26.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter26.withZoneUTC();
//        org.joda.time.Chronology chronology29 = null;
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(chronology29);
//        org.joda.time.ReadablePeriod readablePeriod31 = null;
//        org.joda.time.DateTime dateTime33 = dateTime30.withPeriodAdded(readablePeriod31, (int) (byte) 100);
//        org.joda.time.DateTime dateTime35 = dateTime30.minusMinutes(0);
//        org.joda.time.DateTime dateTime37 = dateTime30.withYearOfEra(10);
//        long long38 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime37);
//        org.joda.time.DateTime dateTime39 = dateTime37.withLaterOffsetAtOverlap();
//        boolean boolean41 = dateTime37.isEqual((long) 'a');
//        org.joda.time.Chronology chronology42 = null;
//        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime(chronology42);
//        org.joda.time.ReadablePeriod readablePeriod44 = null;
//        org.joda.time.DateTime dateTime46 = dateTime43.withPeriodAdded(readablePeriod44, (int) (byte) 100);
//        org.joda.time.DateTime dateTime48 = dateTime43.minusMinutes(0);
//        org.joda.time.Chronology chronology49 = null;
//        org.joda.time.MutableDateTime mutableDateTime50 = dateTime43.toMutableDateTime(chronology49);
//        org.joda.time.LocalDate localDate51 = dateTime43.toLocalDate();
//        org.joda.time.DateTime dateTime52 = dateTime37.withFields((org.joda.time.ReadablePartial) localDate51);
//        java.lang.String str53 = dateTimeFormatter26.print((org.joda.time.ReadablePartial) localDate51);
//        org.joda.time.Chronology chronology54 = null;
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime(chronology54);
//        org.joda.time.ReadablePeriod readablePeriod56 = null;
//        org.joda.time.DateTime dateTime58 = dateTime55.withPeriodAdded(readablePeriod56, (int) (byte) 100);
//        org.joda.time.DateTime dateTime60 = dateTime55.minusMinutes(0);
//        org.joda.time.Chronology chronology61 = null;
//        org.joda.time.MutableDateTime mutableDateTime62 = dateTime55.toMutableDateTime(chronology61);
//        boolean boolean63 = mutableDateTime62.isAfterNow();
//        int int66 = dateTimeFormatter26.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime62, "T16:00:00.000-08:00", 2);
//        int int69 = dateTimeFormatter24.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime62, "", 67);
//        org.joda.time.format.DateTimeParser dateTimeParser70 = dateTimeFormatter24.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter71 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.format.DateTimePrinter dateTimePrinter72 = dateTimeFormatter71.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter73 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimePrinter dateTimePrinter74 = dateTimeFormatter73.getPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder75 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder77 = dateTimeFormatterBuilder75.appendClockhourOfDay((int) (byte) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder80 = dateTimeFormatterBuilder75.appendYearOfEra((int) (byte) 100, 0);
//        org.joda.time.format.DateTimePrinter dateTimePrinter81 = dateTimeFormatterBuilder80.toPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter82 = org.joda.time.format.ISODateTimeFormat.tTime();
//        org.joda.time.format.DateTimeParser dateTimeParser83 = dateTimeFormatter82.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter84 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter81, dateTimeParser83);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter85 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter74, dateTimeParser83);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter86 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter72, dateTimeParser83);
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray87 = new org.joda.time.format.DateTimeParser[] { dateTimeParser70, dateTimeParser83 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder88 = dateTimeFormatterBuilder14.append(dateTimePrinter23, dateTimeParserArray87);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//        org.junit.Assert.assertNotNull(dateTimePrinter23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2000 + "'", int25 == 2000);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(dateTimePrinter27);
//        org.junit.Assert.assertNotNull(dateTimeFormatter28);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-61851599999680L) + "'", long38 == (-61851599999680L));
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(mutableDateTime50);
//        org.junit.Assert.assertNotNull(localDate51);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "1970-W01" + "'", str53.equals("1970-W01"));
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(mutableDateTime62);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-4) + "'", int66 == (-4));
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-68) + "'", int69 == (-68));
//        org.junit.Assert.assertNotNull(dateTimeParser70);
//        org.junit.Assert.assertNotNull(dateTimeFormatter71);
//        org.junit.Assert.assertNotNull(dateTimePrinter72);
//        org.junit.Assert.assertNotNull(dateTimeFormatter73);
//        org.junit.Assert.assertNotNull(dateTimePrinter74);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder77);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder80);
//        org.junit.Assert.assertNotNull(dateTimePrinter81);
//        org.junit.Assert.assertNotNull(dateTimeFormatter82);
//        org.junit.Assert.assertNotNull(dateTimeParser83);
//        org.junit.Assert.assertNotNull(dateTimeParserArray87);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder88);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey(0L);
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone4.getShortName(1560636332628L, locale8);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        try {
            int[] intArray13 = iSOChronology10.get(readablePeriod11, 3729449084306192L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.010" + "'", str9.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(iSOChronology10);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 365);
        long long7 = offsetDateTimeField5.roundHalfCeiling(79533557L);
        int int9 = offsetDateTimeField5.getLeapAmount(97L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 86400000L + "'", long7 == 86400000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        long long6 = fixedDateTimeZone4.previousTransition(0L);
        long long8 = fixedDateTimeZone4.nextTransition((long) (byte) 0);
        long long10 = fixedDateTimeZone4.nextTransition((long) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int13 = cachedDateTimeZone11.getStandardOffset((long) (byte) 1);
        int int15 = cachedDateTimeZone11.getStandardOffset((long) 1970);
        org.joda.time.DateTimeZone dateTimeZone16 = cachedDateTimeZone11.getUncachedZone();
        boolean boolean17 = cachedDateTimeZone11.isFixed();
        int int19 = cachedDateTimeZone11.getStandardOffset(0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) (byte) 100);
        org.joda.time.DateTime dateTime8 = dateTime3.minusMinutes(0);
        org.joda.time.DateTime dateTime10 = dateTime3.withYearOfEra(10);
        org.joda.time.DateTime dateTime12 = dateTime3.minusYears((int) ' ');
        int int13 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime15 = dateTime1.plusDays((int) (byte) 10);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, (int) (short) 100);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(chronology24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.withPeriodAdded(readablePeriod26, (int) (byte) 100);
        org.joda.time.DateTime dateTime30 = dateTime25.minusMinutes(0);
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime20, (org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now(chronology31);
        org.joda.time.DateTime.Property property33 = dateTime32.monthOfYear();
        org.joda.time.DateTime dateTime34 = property33.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property33.getFieldType();
        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType35);
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
        org.joda.time.ReadableDuration readableDuration38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.minus(readableDuration38);
        org.joda.time.DateTime.Property property40 = dateTime39.minuteOfDay();
        org.joda.time.DurationField durationField41 = property40.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField42 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField41);
        long long45 = unsupportedDateTimeField42.add((-61837261293808L), 43880629L);
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = unsupportedDateTimeField42.getType();
        java.lang.String str47 = unsupportedDateTimeField42.getName();
        org.joda.time.ReadablePartial readablePartial48 = null;
        int[] intArray52 = new int[] { 9, 10 };
        try {
            int[] intArray54 = unsupportedDateTimeField42.set(readablePartial48, 339, intArray52, 33);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 3729449084306192L + "'", long45 == 3729449084306192L);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "monthOfYear" + "'", str47.equals("monthOfYear"));
        org.junit.Assert.assertNotNull(intArray52);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test123");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readablePeriod8);
//        org.joda.time.DateTime.Property property10 = dateTime7.dayOfYear();
//        org.joda.time.DateTime dateTime11 = property10.roundCeilingCopy();
//        org.joda.time.DateTime dateTime12 = property10.roundHalfCeilingCopy();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(64, '#', 0, (int) (byte) 100, 5, true, 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder0.addRecurringSavings("", 2365, 2019, (int) (short) 100, 'a', 0, 993, 6, false, 5);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder21 = dateTimeZoneBuilder19.setStandardOffset(138);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder19);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder21);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(readableDuration5, (int) (short) 100);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.withPeriodAdded(readablePeriod10, (int) (byte) 100);
        org.joda.time.DateTime dateTime14 = dateTime9.minusMinutes(0);
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime4, (org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(chronology15);
        org.joda.time.DateTime.Property property17 = dateTime16.monthOfYear();
        org.joda.time.DateTime dateTime19 = dateTime16.withMillisOfDay(919);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime8 = dateTime4.plusMinutes((int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology9.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime4.toMutableDateTime((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology9.millisOfSecond();
        org.joda.time.DurationField durationField15 = iSOChronology9.weekyears();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) (byte) 100);
        org.joda.time.DateTime dateTime8 = dateTime3.minusMinutes(0);
        org.joda.time.DateTime dateTime10 = dateTime3.withYearOfEra(10);
        org.joda.time.DateTime dateTime12 = dateTime3.minusYears((int) ' ');
        int int13 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime15 = dateTime1.plusDays((int) (byte) 10);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, (int) (short) 100);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(chronology24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.withPeriodAdded(readablePeriod26, (int) (byte) 100);
        org.joda.time.DateTime dateTime30 = dateTime25.minusMinutes(0);
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime20, (org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now(chronology31);
        org.joda.time.DateTime.Property property33 = dateTime32.monthOfYear();
        org.joda.time.DateTime dateTime34 = property33.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property33.getFieldType();
        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType35);
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
        org.joda.time.ReadableDuration readableDuration38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.minus(readableDuration38);
        org.joda.time.DateTime.Property property40 = dateTime39.minuteOfDay();
        org.joda.time.DurationField durationField41 = property40.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField42 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField41);
        long long45 = unsupportedDateTimeField42.add((-61837261293808L), 43880629L);
        try {
            long long47 = unsupportedDateTimeField42.roundHalfEven((-61823015729807L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 3729449084306192L + "'", long45 == 3729449084306192L);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test129");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readablePeriod8);
//        org.joda.time.LocalDateTime localDateTime10 = dateTime9.toLocalDateTime();
//        boolean boolean11 = dateTime9.isBeforeNow();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime9.toMutableDateTime();
//        org.joda.time.DateTime dateTime14 = dateTime9.plusYears((int) (short) 1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(localDateTime10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test130");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, chronology6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readablePeriod8);
//        org.joda.time.DateTime.Property property10 = dateTime7.yearOfCentury();
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime15 = dateTime12.withPeriodAdded(readablePeriod13, (int) (byte) 100);
//        int int16 = dateTime12.getHourOfDay();
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) dateTime12, chronology17);
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime18.minus(readablePeriod19);
//        org.joda.time.DateTime dateTime22 = dateTime20.withHourOfDay((int) (byte) 1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        boolean boolean24 = dateTime20.isSupported(dateTimeFieldType23);
//        int int25 = property10.compareTo((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.DateTime dateTime26 = property10.getDateTime();
//        org.joda.time.DateTime dateTime28 = property10.setCopy(42);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        long long5 = iSOChronology0.add((long) (-4), 0L, (-26570460));
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTimeZone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-4L) + "'", long5 == (-4L));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(960, 15, 919, 11, 4, 649, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 649 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfDay(2, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfMinute(0, 2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendFractionOfSecond((int) (byte) 0, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder6.appendFractionOfHour(578, 67);
        boolean boolean16 = dateTimeFormatterBuilder15.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test134");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
//        long long6 = fixedDateTimeZone4.previousTransition(0L);
//        long long8 = fixedDateTimeZone4.nextTransition((long) (byte) 0);
//        long long10 = fixedDateTimeZone4.nextTransition((long) 100);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        int int13 = cachedDateTimeZone11.getStandardOffset((long) (byte) 1);
//        int int15 = cachedDateTimeZone11.getStandardOffset((long) 1970);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        boolean boolean17 = cachedDateTimeZone11.equals((java.lang.Object) dateTimeZone16);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone16.getShortName(1560616766400L, locale19);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) (byte) 100);
        org.joda.time.DateTime dateTime8 = dateTime3.minusMinutes(0);
        org.joda.time.DateTime dateTime10 = dateTime3.withYearOfEra(10);
        org.joda.time.DateTime dateTime12 = dateTime3.minusYears((int) ' ');
        int int13 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime15 = dateTime1.plusDays((int) (byte) 10);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, (int) (short) 100);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(chronology24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.withPeriodAdded(readablePeriod26, (int) (byte) 100);
        org.joda.time.DateTime dateTime30 = dateTime25.minusMinutes(0);
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime20, (org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now(chronology31);
        org.joda.time.DateTime.Property property33 = dateTime32.monthOfYear();
        org.joda.time.DateTime dateTime34 = property33.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property33.getFieldType();
        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType35);
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
        org.joda.time.ReadableDuration readableDuration38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.minus(readableDuration38);
        org.joda.time.DateTime.Property property40 = dateTime39.minuteOfDay();
        org.joda.time.DurationField durationField41 = property40.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField42 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField41);
        long long45 = unsupportedDateTimeField42.add((-61837261293808L), 43880629L);
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = unsupportedDateTimeField42.getType();
        java.lang.String str47 = unsupportedDateTimeField42.getName();
        java.lang.String str48 = unsupportedDateTimeField42.toString();
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 3729449084306192L + "'", long45 == 3729449084306192L);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "monthOfYear" + "'", str47.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "UnsupportedDateTimeField" + "'", str48.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendHourOfHalfday(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendDayOfWeekText();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.withPeriodAdded(readablePeriod9, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded(readableDuration12, (int) (short) 100);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) (byte) 100);
        org.joda.time.DateTime dateTime21 = dateTime16.minusMinutes(0);
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime11, (org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now(chronology22);
        org.joda.time.DateTime.Property property24 = dateTime23.monthOfYear();
        org.joda.time.DateTime dateTime25 = property24.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder6.appendShortText(dateTimeFieldType26);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, "15");
        java.lang.String str30 = illegalFieldValueException29.getIllegalValueAsString();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "15" + "'", str30.equals("15"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str9 = fixedDateTimeZone7.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.hourOfDay();
        org.joda.time.Chronology chronology12 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone14 = iSOChronology0.getZone();
        java.util.TimeZone timeZone15 = dateTimeZone14.toTimeZone();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(timeZone15);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test138");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        int int5 = dateTime1.getHourOfDay();
//        long long6 = dateTime1.getMillis();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) -1, chronology8);
//        int int10 = dateTime9.getWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone11 = dateTime9.getZone();
//        int int12 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime.Property property13 = dateTime9.yearOfCentury();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 320L + "'", long6 == 320L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1970 + "'", int10 == 1970);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(property13);
//    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test139");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime1.toMutableDateTime(chronology7);
//        org.joda.time.DateTime dateTime10 = dateTime1.withHourOfDay((int) (byte) 0);
//        org.joda.time.DateTime dateTime12 = dateTime1.withYear(0);
//        org.joda.time.DateTime.Property property13 = dateTime1.year();
//        org.joda.time.DurationField durationField14 = property13.getDurationField();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
//        java.util.TimeZone timeZone16 = dateTimeZone15.toTimeZone();
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(chronology17);
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.DateTime dateTime21 = dateTime18.withPeriodAdded(readablePeriod19, (int) (byte) 100);
//        int int22 = dateTime18.getHourOfDay();
//        org.joda.time.Chronology chronology23 = null;
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((java.lang.Object) dateTime18, chronology23);
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime24.minus(readablePeriod25);
//        org.joda.time.LocalDateTime localDateTime27 = dateTime26.toLocalDateTime();
//        boolean boolean28 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDateTime27);
//        boolean boolean29 = dateTimeZone15.isLocalDateTimeGap(localDateTime27);
//        int int30 = property13.compareTo((org.joda.time.ReadablePartial) localDateTime27);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(localDateTime27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test140");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
//        org.joda.time.DateTime dateTime8 = dateTime4.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime10 = dateTime4.minusMillis((int) (byte) 10);
//        org.joda.time.DateTime dateTime12 = dateTime4.minusDays(2);
//        org.joda.time.DateTime dateTime14 = dateTime4.withCenturyOfEra((int) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str17 = dateTimeZone15.getName((long) 15);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone15.getShortName((long) (short) 0, locale19);
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = dateTimeZone15.getShortName((long) (short) 100, locale22);
//        org.joda.time.DateTime dateTime24 = dateTime14.withZoneRetainFields(dateTimeZone15);
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
//        org.joda.time.DurationField durationField26 = iSOChronology25.months();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Coordinated Universal Time" + "'", str17.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "UTC" + "'", str23.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str9 = fixedDateTimeZone7.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone7);
        java.lang.Object obj11 = null;
        boolean boolean12 = zonedChronology10.equals(obj11);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology10.clockhourOfDay();
        boolean boolean15 = zonedChronology10.equals((java.lang.Object) 1560636337342L);
        org.joda.time.DateTimeZone dateTimeZone16 = zonedChronology10.getZone();
        org.joda.time.Chronology chronology17 = zonedChronology10.withUTC();
        org.joda.time.DateTimeField dateTimeField18 = zonedChronology10.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField19 = zonedChronology10.millisOfSecond();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (byte) -1);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, 6);
        long long10 = offsetDateTimeField6.roundHalfFloor(0L);
        boolean boolean11 = offsetDateTimeField6.isLenient();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
        int int4 = offsetDateTimeField3.getMaximumValue();
        java.lang.String str6 = offsetDateTimeField3.getAsText(0L);
        int int7 = offsetDateTimeField3.getOffset();
        long long10 = offsetDateTimeField3.add(1560636332627L, (long) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder13.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendHourOfHalfday(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendDayOfWeekText();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(chronology18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.DateTime dateTime22 = dateTime19.withPeriodAdded(readablePeriod20, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.DateTime dateTime25 = dateTime22.withDurationAdded(readableDuration23, (int) (short) 100);
        org.joda.time.Chronology chronology26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(chronology26);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime30 = dateTime27.withPeriodAdded(readablePeriod28, (int) (byte) 100);
        org.joda.time.DateTime dateTime32 = dateTime27.minusMinutes(0);
        org.joda.time.Chronology chronology33 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime22, (org.joda.time.ReadableInstant) dateTime32);
        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now(chronology33);
        org.joda.time.DateTime.Property property35 = dateTime34.monthOfYear();
        org.joda.time.DateTime dateTime36 = property35.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = property35.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder17.appendShortText(dateTimeFieldType37);
        org.joda.time.IllegalFieldValueException illegalFieldValueException40 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType37, "15");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType37, 15);
        long long44 = remainderDateTimeField42.roundCeiling(3121272677156L);
        long long46 = remainderDateTimeField42.roundFloor((long) 15);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1014 + "'", int4 == 1014);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560636332628L + "'", long10 == 1560636332628L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 3121272677156L + "'", long44 == 3121272677156L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 15L + "'", long46 == 15L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) (byte) 100);
        org.joda.time.DateTime dateTime8 = dateTime3.minusMinutes(0);
        org.joda.time.DateTime dateTime10 = dateTime3.withYearOfEra(10);
        org.joda.time.DateTime dateTime12 = dateTime3.minusYears((int) ' ');
        int int13 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime15 = dateTime1.plusDays((int) (byte) 10);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, (int) (short) 100);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(chronology24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.withPeriodAdded(readablePeriod26, (int) (byte) 100);
        org.joda.time.DateTime dateTime30 = dateTime25.minusMinutes(0);
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime20, (org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now(chronology31);
        org.joda.time.DateTime.Property property33 = dateTime32.monthOfYear();
        org.joda.time.DateTime dateTime34 = property33.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property33.getFieldType();
        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType35);
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
        org.joda.time.ReadableDuration readableDuration38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.minus(readableDuration38);
        org.joda.time.DateTime.Property property40 = dateTime39.minuteOfDay();
        org.joda.time.DurationField durationField41 = property40.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField42 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField41);
        long long45 = unsupportedDateTimeField42.add((-61837261293808L), 43880629L);
        long long48 = unsupportedDateTimeField42.getDifferenceAsLong((long) (short) 1, (long) 'a');
        try {
            long long50 = unsupportedDateTimeField42.roundHalfEven((long) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 3729449084306192L + "'", long45 == 3729449084306192L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyear();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField5 = iSOChronology4.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str13 = fixedDateTimeZone11.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology4.hourOfDay();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology4.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology4.dayOfYear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder18.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder18.appendYearOfEra((int) '#', (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder18.appendDayOfWeek(3);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(chronology25);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.DateTime dateTime29 = dateTime26.withPeriodAdded(readablePeriod27, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration30 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.withDurationAdded(readableDuration30, (int) (short) 100);
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(chronology33);
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime37 = dateTime34.withPeriodAdded(readablePeriod35, (int) (byte) 100);
        org.joda.time.DateTime dateTime39 = dateTime34.minusMinutes(0);
        org.joda.time.Chronology chronology40 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime29, (org.joda.time.ReadableInstant) dateTime39);
        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now(chronology40);
        org.joda.time.DateTime.Property property42 = dateTime41.monthOfYear();
        org.joda.time.DateTime dateTime43 = property42.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property42.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder18.appendShortText(dateTimeFieldType44);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, dateTimeFieldType44, 2019, 674, 12);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField51 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType44, 11);
        boolean boolean52 = dividedDateTimeField51.isSupported();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        try {
            org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.parse("1970-01-01T00:00:01.944", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1970-01-01T00:00:01.944\" is malformed at \"-01-01T00:00:01.944\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
        boolean boolean5 = offsetDateTimeField3.isSupported();
        long long7 = offsetDateTimeField3.roundCeiling((long) 3);
        long long9 = offsetDateTimeField3.roundCeiling(1560636316530L);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsText((int) ' ', locale11);
        boolean boolean14 = offsetDateTimeField3.isLeap((-2L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3L + "'", long7 == 3L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560636316530L + "'", long9 == 1560636316530L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "32" + "'", str12.equals("32"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.era();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.year();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
        boolean boolean5 = offsetDateTimeField3.isSupported();
        boolean boolean6 = offsetDateTimeField3.isSupported();
        org.joda.time.DurationField durationField7 = offsetDateTimeField3.getDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
        int int4 = offsetDateTimeField3.getMaximumValue();
        java.lang.String str6 = offsetDateTimeField3.getAsText(0L);
        int int7 = offsetDateTimeField3.getOffset();
        long long10 = offsetDateTimeField3.add(1560636332627L, (long) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder13.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendHourOfHalfday(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendDayOfWeekText();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(chronology18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.DateTime dateTime22 = dateTime19.withPeriodAdded(readablePeriod20, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.DateTime dateTime25 = dateTime22.withDurationAdded(readableDuration23, (int) (short) 100);
        org.joda.time.Chronology chronology26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(chronology26);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime30 = dateTime27.withPeriodAdded(readablePeriod28, (int) (byte) 100);
        org.joda.time.DateTime dateTime32 = dateTime27.minusMinutes(0);
        org.joda.time.Chronology chronology33 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime22, (org.joda.time.ReadableInstant) dateTime32);
        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now(chronology33);
        org.joda.time.DateTime.Property property35 = dateTime34.monthOfYear();
        org.joda.time.DateTime dateTime36 = property35.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = property35.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder17.appendShortText(dateTimeFieldType37);
        org.joda.time.IllegalFieldValueException illegalFieldValueException40 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType37, "15");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType37, 15);
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(chronology43);
        org.joda.time.ReadablePeriod readablePeriod45 = null;
        org.joda.time.DateTime dateTime47 = dateTime44.withPeriodAdded(readablePeriod45, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration48 = null;
        org.joda.time.DateTime dateTime50 = dateTime47.withDurationAdded(readableDuration48, (int) (short) 100);
        org.joda.time.Chronology chronology51 = null;
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime(chronology51);
        org.joda.time.ReadablePeriod readablePeriod53 = null;
        org.joda.time.DateTime dateTime55 = dateTime52.withPeriodAdded(readablePeriod53, (int) (byte) 100);
        org.joda.time.DateTime dateTime57 = dateTime52.minusMinutes(0);
        org.joda.time.Chronology chronology58 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime47, (org.joda.time.ReadableInstant) dateTime57);
        org.joda.time.DateTime dateTime59 = org.joda.time.DateTime.now(chronology58);
        org.joda.time.DateTime.Property property60 = dateTime59.monthOfYear();
        org.joda.time.DateTime dateTime61 = property60.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property60.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException65 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType62, (java.lang.Number) 3L, "2019-06-15T15:05:30.038-07:00");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField66 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField42, dateTimeFieldType62);
        long long68 = remainderDateTimeField42.roundHalfCeiling((-61837261288556L));
        long long70 = remainderDateTimeField42.roundHalfFloor((long) 33);
        int int72 = remainderDateTimeField42.get(3121272705081L);
        try {
            long long75 = remainderDateTimeField42.set((long) 66, "1970-01-01");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1970-01-01\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1014 + "'", int4 == 1014);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560636332628L + "'", long10 == 1560636332628L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-61837261288556L) + "'", long68 == (-61837261288556L));
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 33L + "'", long70 == 33L);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 6 + "'", int72 == 6);
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test151");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
//        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(10);
//        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime10 = dateTime8.withLaterOffsetAtOverlap();
//        boolean boolean12 = dateTime8.isEqual((long) 'a');
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(chronology13);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) (byte) 100);
//        org.joda.time.DateTime dateTime19 = dateTime14.minusMinutes(0);
//        org.joda.time.Chronology chronology20 = null;
//        org.joda.time.MutableDateTime mutableDateTime21 = dateTime14.toMutableDateTime(chronology20);
//        org.joda.time.LocalDate localDate22 = dateTime14.toLocalDate();
//        org.joda.time.DateTime dateTime23 = dateTime8.withFields((org.joda.time.ReadablePartial) localDate22);
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime25 = dateTime23.withZone(dateTimeZone24);
//        try {
//            org.joda.time.DateTime dateTime27 = dateTime25.withSecondOfMinute(67);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 67 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61851599999680L) + "'", long9 == (-61851599999680L));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(mutableDateTime21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(dateTime25);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.era();
        jodaTimePermission1.checkGuard((java.lang.Object) dateTimeField4);
        java.lang.String str6 = jodaTimePermission1.getActions();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        jodaTimePermission1.checkGuard((java.lang.Object) property9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder13.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.appendFractionOfDay(2, 0);
        boolean boolean18 = dateTimeFormatterBuilder14.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder14.appendFractionOfDay(97, (int) '4');
        boolean boolean22 = jodaTimePermission1.equals((java.lang.Object) dateTimeFormatterBuilder21);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatterBuilder21.toFormatter();
        java.lang.StringBuffer stringBuffer24 = null;
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(chronology25);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.DateTime dateTime29 = dateTime26.withPeriodAdded(readablePeriod27, (int) (byte) 100);
        org.joda.time.DateTime dateTime31 = dateTime26.minusMinutes(0);
        org.joda.time.DateTime dateTime33 = dateTime26.withYearOfEra(10);
        org.joda.time.DateTime dateTime35 = dateTime26.withMinuteOfHour(1);
        try {
            dateTimeFormatter23.printTo(stringBuffer24, (org.joda.time.ReadableInstant) dateTime26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 2019, (long) 1929);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 90L + "'", long2 == 90L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
        boolean boolean5 = offsetDateTimeField3.isSupported();
        int int7 = offsetDateTimeField3.getMaximumValue((long) 5);
        java.lang.String str8 = offsetDateTimeField3.toString();
        long long11 = offsetDateTimeField3.add((long) 27, 330);
        int int13 = offsetDateTimeField3.getLeapAmount((-3L));
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) (-3L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1014 + "'", int7 == 1014);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str8.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 357L + "'", long11 == 357L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendHourOfHalfday(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfHour(2019, 2068);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendSecondOfMinute((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendCenturyOfEra(24, 15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gregorianChronology0.equals(obj1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 15);
        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getDurationField();
        boolean boolean8 = offsetDateTimeField6.isSupported();
        boolean boolean9 = gregorianChronology0.equals((java.lang.Object) offsetDateTimeField6);
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology0.yearOfCentury();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder15.appendTimeZoneShortName();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatterBuilder16.toParser();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap18 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder16.appendTimeZoneName(strMap18);
        boolean boolean20 = dateTimeFormatterBuilder16.canBuildFormatter();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(chronology21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.DateTime dateTime25 = dateTime22.withPeriodAdded(readablePeriod23, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.withDurationAdded(readableDuration26, (int) (short) 100);
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(chronology29);
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.DateTime dateTime33 = dateTime30.withPeriodAdded(readablePeriod31, (int) (byte) 100);
        org.joda.time.DateTime dateTime35 = dateTime30.minusMinutes(0);
        org.joda.time.Chronology chronology36 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime25, (org.joda.time.ReadableInstant) dateTime35);
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now(chronology36);
        org.joda.time.DateTime.Property property38 = dateTime37.monthOfYear();
        org.joda.time.DateTime dateTime39 = property38.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property38.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType40, (java.lang.Number) 3L, "2019-06-15T15:05:30.038-07:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder16.appendFixedSignedDecimal(dateTimeFieldType40, 2);
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField12, dateTimeFieldType40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test157");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime1.toMutableDateTime(chronology7);
//        org.joda.time.DateTime dateTime10 = dateTime1.withHourOfDay((int) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
//        java.util.TimeZone timeZone12 = dateTimeZone11.toTimeZone();
//        java.lang.String str14 = dateTimeZone11.getName((long) (byte) 10);
//        org.joda.time.DateTime dateTime15 = dateTime1.toDateTime(dateTimeZone11);
//        java.lang.Object obj16 = null;
//        boolean boolean17 = dateTime1.equals(obj16);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Coordinated Universal Time" + "'", str14.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
        int int4 = offsetDateTimeField3.getMaximumValue();
        java.lang.String str6 = offsetDateTimeField3.getAsText(0L);
        long long9 = offsetDateTimeField3.set((-61837261293712L), 97);
        long long12 = offsetDateTimeField3.add((long) 708, (long) 11);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1014 + "'", int4 == 1014);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61837261293918L) + "'", long9 == (-61837261293918L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 719L + "'", long12 == 719L);
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test159");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes(0);
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime1.toMutableDateTime(chronology7);
//        org.joda.time.DateTime dateTime10 = dateTime1.withHourOfDay((int) (byte) 0);
//        org.joda.time.DateTime dateTime12 = dateTime1.withYear(0);
//        org.joda.time.DateTime.Property property13 = dateTime1.year();
//        java.lang.String str14 = property13.getAsText();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1970" + "'", str14.equals("1970"));
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneShortName();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatterBuilder5.toParser();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendTimeZoneName(strMap7);
        dateTimeFormatterBuilder5.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder12.appendYearOfEra((int) (byte) 100, 0);
        org.joda.time.format.DateTimePrinter dateTimePrinter18 = dateTimeFormatterBuilder17.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter19.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter18, dateTimeParser20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder11.appendOptional(dateTimeParser20);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter1, dateTimeParser20);
        java.util.Locale locale24 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter23.withLocale(locale24);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimePrinter18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(dateTimeParser20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, chronology2);
        int int4 = dateTime3.getWeekyear();
        org.joda.time.DateTime dateTime6 = dateTime3.minusSeconds((int) '4');
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((-10L), chronology7);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test162");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.tTime();
//        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatter3.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimeParser4);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(963, (int) (byte) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendYearOfEra((int) '#', (int) (short) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder9.appendDayOfWeek(3);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder9.appendHourOfHalfday(15);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendFractionOfSecond(0, 2000);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendHourOfDay(0);
//        org.joda.time.Chronology chronology23 = null;
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(chronology23);
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime27 = dateTime24.withPeriodAdded(readablePeriod25, (int) (byte) 100);
//        int int28 = dateTime24.getHourOfDay();
//        org.joda.time.Chronology chronology29 = null;
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) dateTime24, chronology29);
//        org.joda.time.ReadablePeriod readablePeriod31 = null;
//        org.joda.time.DateTime dateTime32 = dateTime30.minus(readablePeriod31);
//        org.joda.time.DateTime dateTime34 = dateTime32.withHourOfDay((int) (byte) 1);
//        java.util.Date date35 = dateTime32.toDate();
//        org.joda.time.DateTime.Property property36 = dateTime32.weekOfWeekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType37 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder20.appendDecimal(dateTimeFieldType37, 11, 2019);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType37);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType37, "767");
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(dateTimeParser4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFieldType37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendHourOfHalfday(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendDayOfWeekText();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.withPeriodAdded(readablePeriod9, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded(readableDuration12, (int) (short) 100);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) (byte) 100);
        org.joda.time.DateTime dateTime21 = dateTime16.minusMinutes(0);
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime11, (org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now(chronology22);
        org.joda.time.DateTime.Property property24 = dateTime23.monthOfYear();
        org.joda.time.DateTime dateTime25 = property24.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder6.appendShortText(dateTimeFieldType26);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.format.DateTimeParser dateTimeParser29 = dateTimeFormatter28.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder27.append(dateTimeParser29);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder30.appendFractionOfHour(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTimeParser29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str9 = fixedDateTimeZone7.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology0.minuteOfHour();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(chronology13);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) (byte) 100);
        org.joda.time.DateTime dateTime21 = dateTime16.minusMinutes(0);
        org.joda.time.DateTime dateTime23 = dateTime16.withYearOfEra(10);
        org.joda.time.DateTime dateTime25 = dateTime16.minusYears((int) ' ');
        int int26 = dateTime14.compareTo((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime.Property property27 = dateTime25.monthOfYear();
        org.joda.time.DateTime dateTime28 = property27.getDateTime();
        boolean boolean29 = iSOChronology0.equals((java.lang.Object) property27);
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.era();
        jodaTimePermission1.checkGuard((java.lang.Object) dateTimeField4);
        java.lang.String str6 = jodaTimePermission1.getActions();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        jodaTimePermission1.checkGuard((java.lang.Object) property9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder13.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.appendFractionOfDay(2, 0);
        boolean boolean18 = dateTimeFormatterBuilder14.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder14.appendFractionOfDay(97, (int) '4');
        boolean boolean22 = jodaTimePermission1.equals((java.lang.Object) dateTimeFormatterBuilder21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder21.appendClockhourOfHalfday(365);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder21.append(dateTimeFormatter25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No formatter supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYear(0, 66);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test167");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
//        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
//        boolean boolean5 = offsetDateTimeField3.isSupported();
//        boolean boolean6 = offsetDateTimeField3.isSupported();
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(chronology7);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withPeriodAdded(readablePeriod9, (int) (byte) 100);
//        int int12 = dateTime8.getHourOfDay();
//        org.joda.time.DateTime.Property property13 = dateTime8.millisOfSecond();
//        boolean boolean15 = property13.equals((java.lang.Object) 100.0f);
//        org.joda.time.DateTime dateTime16 = property13.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime17 = property13.roundHalfFloorCopy();
//        org.joda.time.LocalTime localTime18 = dateTime17.toLocalTime();
//        boolean boolean19 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime18);
//        int int20 = offsetDateTimeField3.getMaximumValue((org.joda.time.ReadablePartial) localTime18);
//        boolean boolean22 = offsetDateTimeField3.isLeap(10L);
//        org.joda.time.DateTimeField dateTimeField23 = offsetDateTimeField3.getWrappedField();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(localTime18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1014 + "'", int20 == 1014);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test168");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        java.util.Locale locale1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
//        java.lang.Appendable appendable3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology5);
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime9 = dateTime6.withPeriodAdded(readablePeriod7, (int) (byte) 100);
//        int int10 = dateTime6.getHourOfDay();
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) dateTime6, chronology11);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.minus(readablePeriod13);
//        org.joda.time.LocalDateTime localDateTime15 = dateTime14.toLocalDateTime();
//        boolean boolean16 = dateTimeZone4.isLocalDateTimeGap(localDateTime15);
//        try {
//            dateTimeFormatter0.printTo(appendable3, (org.joda.time.ReadablePartial) localDateTime15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(localDateTime15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test169");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
//        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis((int) 'a');
//        int int7 = dateTime6.getSecondOfMinute();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.lang.Object obj9 = null;
//        boolean boolean10 = gregorianChronology8.equals(obj9);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 15);
//        org.joda.time.DurationField durationField15 = offsetDateTimeField14.getDurationField();
//        boolean boolean16 = offsetDateTimeField14.isSupported();
//        boolean boolean17 = gregorianChronology8.equals((java.lang.Object) offsetDateTimeField14);
//        org.joda.time.DateTime dateTime18 = dateTime6.withChronology((org.joda.time.Chronology) gregorianChronology8);
//        try {
//            long long26 = gregorianChronology8.getDateTimeMillis(43879275, 339, (-1), 67, 0, (-4), 48);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 67 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(readableDuration5, (int) (short) 100);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.withPeriodAdded(readablePeriod10, (int) (byte) 100);
        org.joda.time.DateTime dateTime14 = dateTime9.minusMinutes(0);
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime4, (org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(chronology15);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
        java.util.TimeZone timeZone18 = dateTimeZone17.toTimeZone();
        long long21 = dateTimeZone17.convertLocalToUTC(0L, false);
        java.util.TimeZone timeZone22 = dateTimeZone17.toTimeZone();
        org.joda.time.chrono.ZonedChronology zonedChronology23 = org.joda.time.chrono.ZonedChronology.getInstance(chronology15, dateTimeZone17);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField25 = iSOChronology24.eras();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology24.clockhourOfHalfday();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone31 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        long long33 = fixedDateTimeZone31.previousTransition(0L);
        long long36 = fixedDateTimeZone31.adjustOffset((long) (byte) -1, true);
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.UTC;
        long long39 = fixedDateTimeZone31.getMillisKeepLocal(dateTimeZone37, (long) 963);
        org.joda.time.Chronology chronology40 = iSOChronology24.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone31);
        org.joda.time.Chronology chronology41 = zonedChronology23.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone31);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(zonedChronology23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-1L) + "'", long36 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 973L + "'", long39 == 973L);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertNotNull(chronology41);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test171");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
//        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("hi!");
//        org.joda.time.JodaTimePermission jodaTimePermission5 = new org.joda.time.JodaTimePermission("hi!");
//        boolean boolean6 = jodaTimePermission3.implies((java.security.Permission) jodaTimePermission5);
//        jodaTimePermission5.checkGuard((java.lang.Object) "T16:00:00.000-08:00");
//        boolean boolean9 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission5);
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(chronology10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime14 = dateTime11.withPeriodAdded(readablePeriod12, (int) (byte) 100);
//        int int15 = dateTime11.getHourOfDay();
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((java.lang.Object) dateTime11, chronology16);
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime17.minus(readablePeriod18);
//        org.joda.time.DateTime dateTime21 = dateTime19.withHourOfDay((int) (byte) 1);
//        java.util.Date date22 = dateTime19.toDate();
//        jodaTimePermission1.checkGuard((java.lang.Object) dateTime19);
//        org.joda.time.JodaTimePermission jodaTimePermission25 = new org.joda.time.JodaTimePermission("hi!");
//        org.joda.time.Chronology chronology26 = null;
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(chronology26);
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.DateTime dateTime30 = dateTime27.withPeriodAdded(readablePeriod28, (int) (byte) 100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = null;
//        boolean boolean32 = dateTime30.isSupported(dateTimeFieldType31);
//        org.joda.time.DateTime dateTime34 = dateTime30.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime36 = dateTime30.minusMillis((int) (byte) 10);
//        org.joda.time.DateTime dateTime38 = dateTime30.minusDays(2);
//        org.joda.time.DateTime dateTime40 = dateTime30.withCenturyOfEra((int) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str43 = dateTimeZone41.getName((long) 15);
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = dateTimeZone41.getShortName((long) (short) 0, locale45);
//        java.util.Locale locale48 = null;
//        java.lang.String str49 = dateTimeZone41.getShortName((long) (short) 100, locale48);
//        org.joda.time.DateTime dateTime50 = dateTime40.withZoneRetainFields(dateTimeZone41);
//        boolean boolean51 = jodaTimePermission25.equals((java.lang.Object) dateTimeZone41);
//        boolean boolean52 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission25);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Coordinated Universal Time" + "'", str43.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "UTC" + "'", str46.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "UTC" + "'", str49.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) (byte) 100);
        org.joda.time.DateTime dateTime8 = dateTime3.minusMinutes(0);
        org.joda.time.DateTime dateTime10 = dateTime3.withYearOfEra(10);
        org.joda.time.DateTime dateTime12 = dateTime3.minusYears((int) ' ');
        int int13 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime15 = dateTime1.plusDays((int) (byte) 10);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, (int) (short) 100);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(chronology24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.withPeriodAdded(readablePeriod26, (int) (byte) 100);
        org.joda.time.DateTime dateTime30 = dateTime25.minusMinutes(0);
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime20, (org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now(chronology31);
        org.joda.time.DateTime.Property property33 = dateTime32.monthOfYear();
        org.joda.time.DateTime dateTime34 = property33.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property33.getFieldType();
        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType35);
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
        org.joda.time.ReadableDuration readableDuration38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.minus(readableDuration38);
        org.joda.time.DateTime.Property property40 = dateTime39.minuteOfDay();
        org.joda.time.DurationField durationField41 = property40.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField42 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField41);
        long long45 = unsupportedDateTimeField42.add((-61837261293808L), 43880629L);
        boolean boolean46 = unsupportedDateTimeField42.isSupported();
        org.joda.time.DurationField durationField47 = unsupportedDateTimeField42.getRangeDurationField();
        java.lang.String str48 = unsupportedDateTimeField42.toString();
        java.lang.String str49 = unsupportedDateTimeField42.toString();
        boolean boolean50 = unsupportedDateTimeField42.isSupported();
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 3729449084306192L + "'", long45 == 3729449084306192L);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(durationField47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "UnsupportedDateTimeField" + "'", str48.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "UnsupportedDateTimeField" + "'", str49.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyear();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField5 = iSOChronology4.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 10, (int) (short) 100);
        java.lang.String str13 = fixedDateTimeZone11.getNameKey((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology4.hourOfDay();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology4.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology4.dayOfYear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder18.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder18.appendYearOfEra((int) '#', (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder18.appendDayOfWeek(3);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(chronology25);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.DateTime dateTime29 = dateTime26.withPeriodAdded(readablePeriod27, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration30 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.withDurationAdded(readableDuration30, (int) (short) 100);
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(chronology33);
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime37 = dateTime34.withPeriodAdded(readablePeriod35, (int) (byte) 100);
        org.joda.time.DateTime dateTime39 = dateTime34.minusMinutes(0);
        org.joda.time.Chronology chronology40 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime29, (org.joda.time.ReadableInstant) dateTime39);
        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now(chronology40);
        org.joda.time.DateTime.Property property42 = dateTime41.monthOfYear();
        org.joda.time.DateTime dateTime43 = property42.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property42.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder18.appendShortText(dateTimeFieldType44);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, dateTimeFieldType44, 2019, 674, 12);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField51 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType44, 11);
        int int53 = dividedDateTimeField51.get((long) 10);
        int int54 = dividedDateTimeField51.getDivisor();
        int int56 = dividedDateTimeField51.get(0L);
        long long59 = dividedDateTimeField51.set((-61823015740307L), 2365);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 179 + "'", int53 == 179);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 11 + "'", int54 == 11);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 179 + "'", int56 == 179);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 759130689859693L + "'", long59 == 759130689859693L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 15);
        int int4 = offsetDateTimeField3.getMaximumValue();
        java.lang.String str6 = offsetDateTimeField3.getAsText(0L);
        int int7 = offsetDateTimeField3.getOffset();
        long long10 = offsetDateTimeField3.add(1560636332627L, (long) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendClockhourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder13.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendHourOfHalfday(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendDayOfWeekText();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(chronology18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.DateTime dateTime22 = dateTime19.withPeriodAdded(readablePeriod20, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.DateTime dateTime25 = dateTime22.withDurationAdded(readableDuration23, (int) (short) 100);
        org.joda.time.Chronology chronology26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(chronology26);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime30 = dateTime27.withPeriodAdded(readablePeriod28, (int) (byte) 100);
        org.joda.time.DateTime dateTime32 = dateTime27.minusMinutes(0);
        org.joda.time.Chronology chronology33 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime22, (org.joda.time.ReadableInstant) dateTime32);
        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now(chronology33);
        org.joda.time.DateTime.Property property35 = dateTime34.monthOfYear();
        org.joda.time.DateTime dateTime36 = property35.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = property35.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder17.appendShortText(dateTimeFieldType37);
        org.joda.time.IllegalFieldValueException illegalFieldValueException40 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType37, "15");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType37, 15);
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(chronology43);
        org.joda.time.ReadablePeriod readablePeriod45 = null;
        org.joda.time.DateTime dateTime47 = dateTime44.withPeriodAdded(readablePeriod45, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration48 = null;
        org.joda.time.DateTime dateTime50 = dateTime47.withDurationAdded(readableDuration48, (int) (short) 100);
        org.joda.time.Chronology chronology51 = null;
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime(chronology51);
        org.joda.time.ReadablePeriod readablePeriod53 = null;
        org.joda.time.DateTime dateTime55 = dateTime52.withPeriodAdded(readablePeriod53, (int) (byte) 100);
        org.joda.time.DateTime dateTime57 = dateTime52.minusMinutes(0);
        org.joda.time.Chronology chronology58 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime47, (org.joda.time.ReadableInstant) dateTime57);
        org.joda.time.DateTime dateTime59 = org.joda.time.DateTime.now(chronology58);
        org.joda.time.DateTime.Property property60 = dateTime59.monthOfYear();
        org.joda.time.DateTime dateTime61 = property60.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property60.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException65 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType62, (java.lang.Number) 3L, "2019-06-15T15:05:30.038-07:00");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField66 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField42, dateTimeFieldType62);
        long long68 = remainderDateTimeField42.roundHalfCeiling((-61837261288556L));
        long long70 = remainderDateTimeField42.roundHalfFloor((long) 33);
        long long72 = remainderDateTimeField42.remainder((long) 36);
        long long74 = remainderDateTimeField42.roundHalfCeiling(86400000L);
        org.joda.time.DurationField durationField75 = remainderDateTimeField42.getRangeDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1014 + "'", int4 == 1014);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560636332628L + "'", long10 == 1560636332628L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-61837261288556L) + "'", long68 == (-61837261288556L));
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 33L + "'", long70 == 33L);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 0L + "'", long72 == 0L);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 86400000L + "'", long74 == 86400000L);
        org.junit.Assert.assertNotNull(durationField75);
    }
}

