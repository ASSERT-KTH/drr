import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        org.joda.time.DurationFieldType durationFieldType1 = null;
        int int2 = periodType0.indexOf(durationFieldType1);
        org.joda.time.PeriodType periodType3 = periodType0.withMillisRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.era();
        org.joda.time.DurationField durationField6 = gregorianChronology4.halfdays();
        org.joda.time.DurationField durationField7 = gregorianChronology4.days();
        org.joda.time.DurationField durationField8 = gregorianChronology4.halfdays();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology4.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) (byte) 10);
        int int15 = offsetDateTimeField13.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField13.getAsText(readablePartial16, 1, locale18);
        org.joda.time.ReadablePartial readablePartial20 = null;
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField13.getAsText(readablePartial20, (int) (byte) 100, locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField13.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField26 = new org.joda.time.field.RemainderDateTimeField(dateTimeField9, dateTimeFieldType24, 4);
        long long28 = remainderDateTimeField26.roundCeiling(1560629037229L);
        long long30 = remainderDateTimeField26.roundCeiling((-112L));
        long long32 = remainderDateTimeField26.roundCeiling(0L);
        long long34 = remainderDateTimeField26.remainder((long) 100);
        boolean boolean35 = periodType3.equals((java.lang.Object) remainderDateTimeField26);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 43210 + "'", int15 == 43210);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "100" + "'", str23.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577664000000L + "'", long28 == 1577664000000L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31795200000L + "'", long30 == 31795200000L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 31795200000L + "'", long32 == 31795200000L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 259200100L + "'", long34 == 259200100L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test002");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        long long3 = dateTimeZone0.adjustOffset((long) '4', false);
//        boolean boolean5 = dateTimeZone0.isStandardOffset((long) '#');
//        java.lang.String str7 = dateTimeZone0.getShortName(1L);
//        int int9 = dateTimeZone0.getOffsetFromLocal((long) 1);
//        long long12 = dateTimeZone0.convertLocalToUTC((-210866673600000L), false);
//        long long15 = dateTimeZone0.convertLocalToUTC(31795200000L, false);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.UTC;
//        long long19 = dateTimeZone16.adjustOffset((long) '4', false);
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours(1);
//        org.joda.time.chrono.ZonedChronology zonedChronology23 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology20, dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.UTC;
//        long long27 = dateTimeZone24.adjustOffset((long) '4', false);
//        boolean boolean29 = dateTimeZone24.isStandardOffset((long) '#');
//        java.lang.String str31 = dateTimeZone24.getShortName(1L);
//        long long33 = dateTimeZone22.getMillisKeepLocal(dateTimeZone24, 2440588L);
//        int int35 = dateTimeZone24.getOffsetFromLocal(86409L);
//        long long37 = dateTimeZone0.getMillisKeepLocal(dateTimeZone24, 105L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-210866673600000L) + "'", long12 == (-210866673600000L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31795200000L + "'", long15 == 31795200000L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 52L + "'", long19 == 52L);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(zonedChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 52L + "'", long27 == 52L);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "UTC" + "'", str31.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 6040588L + "'", long33 == 6040588L);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 105L + "'", long37 == 105L);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        java.lang.String str2 = lenientChronology1.toString();
        org.joda.time.Period period4 = org.joda.time.Period.days((int) (short) -1);
        org.joda.time.Period period6 = period4.plusYears((int) (byte) 1);
        org.joda.time.Period period8 = period4.plusMillis((int) (short) -1);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType10 = periodType9.withMinutesRemoved();
        org.joda.time.Period period11 = period8.withPeriodType(periodType10);
        int[] intArray13 = lenientChronology1.get((org.joda.time.ReadablePeriod) period8, 2441000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(lenientChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "LenientChronology[GregorianChronology[UTC]]" + "'", str2.equals("LenientChronology[GregorianChronology[UTC]]"));
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(10L, periodType1, chronology2);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        int int5 = periodType1.indexOf(durationFieldType4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.dayOfYear();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.clockhourOfHalfday();
        boolean boolean9 = periodType1.equals((java.lang.Object) gregorianChronology6);
        org.joda.time.Chronology chronology10 = gregorianChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology6.hourOfHalfday();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.PeriodType periodType3 = period2.getPeriodType();
        org.joda.time.Hours hours4 = period2.toStandardHours();
        int int5 = period2.getMinutes();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(hours4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) 10);
        int int30 = offsetDateTimeField28.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField28.getAsText(readablePartial31, 1, locale33);
        org.joda.time.ReadablePartial readablePartial35 = null;
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField28.getAsText(readablePartial35, (int) (byte) 100, locale37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType39);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = dividedDateTimeField40.getType();
        java.util.Locale locale42 = null;
        int int43 = dividedDateTimeField40.getMaximumTextLength(locale42);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 43210 + "'", int30 == 43210);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "100" + "'", str38.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2 + "'", int43 == 2);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "112");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 100, (int) (byte) 0, (int) '4', (int) (byte) 10);
        org.joda.time.Period period6 = period4.minusDays(1);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period9 = new org.joda.time.Period((long) (short) 1, periodType8);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period11 = period9.normalizedStandard(periodType10);
        org.joda.time.DurationFieldType durationFieldType13 = periodType10.getFieldType(1);
        org.joda.time.Period period15 = period4.withFieldAdded(durationFieldType13, 8);
        int int16 = period15.getMonths();
        org.joda.time.Period period18 = period15.plusMinutes((int) (byte) 0);
        org.joda.time.Period period20 = org.joda.time.Period.weeks((int) 'a');
        org.joda.time.Period period22 = period20.withMillis(1);
        org.joda.time.Period period24 = period22.withMinutes(0);
        org.joda.time.Period period25 = period15.plus((org.joda.time.ReadablePeriod) period24);
        org.joda.time.Period period27 = period24.withWeeks(28);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(1820L, (-205889342400000L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -374718603168000000");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
        long long7 = dateTimeZone4.adjustOffset((long) '4', false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.year();
        org.joda.time.Period period10 = new org.joda.time.Period(0L, periodType3, (org.joda.time.Chronology) iSOChronology8);
        java.lang.String str11 = periodType3.toString();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType15 = periodType14.withMinutesRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology16);
        org.joda.time.Period period18 = new org.joda.time.Period(0L, (-60266045221990L), periodType14, (org.joda.time.Chronology) lenientChronology17);
        org.joda.time.Period period19 = new org.joda.time.Period(35L, 0L, periodType3, (org.joda.time.Chronology) lenientChronology17);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PeriodType[YearWeekDay]" + "'", str11.equals("PeriodType[YearWeekDay]"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(lenientChronology17);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("(\"org.joda.time.JodaTimePermission\" \"hi!\")", (java.lang.Number) (-2999L), (java.lang.Number) (-72645112427327L), (java.lang.Number) 311040002440587L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) 10);
        int int30 = offsetDateTimeField28.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField28.getAsText(readablePartial31, 1, locale33);
        org.joda.time.ReadablePartial readablePartial35 = null;
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField28.getAsText(readablePartial35, (int) (byte) 100, locale37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType39);
        long long43 = dividedDateTimeField40.addWrapField((long) (short) 0, 43210);
        int int45 = dividedDateTimeField40.get((-17999903L));
        org.joda.time.ReadablePartial readablePartial46 = null;
        int int47 = dividedDateTimeField40.getMinimumValue(readablePartial46);
        long long50 = dividedDateTimeField40.addWrapField(7977178000L, (int) (byte) 1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 43210 + "'", int30 == 43210);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "100" + "'", str38.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-252201600000L) + "'", long43 == (-252201600000L));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 17 + "'", int45 == 17);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 134380378000L + "'", long50 == 134380378000L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.joda.time.Period period6 = new org.joda.time.Period((int) (byte) 100, (int) (byte) 0, (int) '4', (int) (byte) 10);
        org.joda.time.Period period8 = period6.minusDays(1);
        org.joda.time.Period period10 = period8.plusMinutes((int) (byte) 100);
        org.joda.time.Period period12 = org.joda.time.Period.days(0);
        org.joda.time.Period period14 = period12.plusWeeks((int) (byte) -1);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.Period period16 = period14.withFields(readablePeriod15);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.months();
        org.joda.time.PeriodType periodType19 = periodType18.withMonthsRemoved();
        org.joda.time.PeriodType periodType20 = periodType19.withDaysRemoved();
        org.joda.time.Period period21 = new org.joda.time.Period((long) '4', periodType20);
        boolean boolean22 = period16.equals((java.lang.Object) periodType20);
        org.joda.time.Period period23 = period8.normalizedStandard(periodType20);
        org.joda.time.PeriodType periodType24 = periodType20.withWeeksRemoved();
        org.joda.time.Period period25 = new org.joda.time.Period(0L, (-259199999997L), periodType20);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(periodType24);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
        org.joda.time.ReadablePartial readablePartial3 = null;
        int[] intArray4 = null;
        try {
            iSOChronology0.validate(readablePartial3, intArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException2.prependMessage("hi!");
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        java.lang.Number number6 = illegalFieldValueException2.getUpperBound();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.Number number8 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNull(dateTimeFieldType7);
        org.junit.Assert.assertNull(number8);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(5);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "PT0S", (int) (byte) 0, 0);
        int int8 = fixedDateTimeZone6.getOffsetFromLocal((long) 8);
        int int10 = fixedDateTimeZone6.getOffsetFromLocal(51999L);
        long long12 = dateTimeZone1.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone6, 100L);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        int int15 = fixedDateTimeZone6.getOffset((long) (short) 100);
        java.lang.Object obj16 = null;
        boolean boolean17 = fixedDateTimeZone6.equals(obj16);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 105L + "'", long12 == 105L);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(10L, periodType1, chronology2);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        int int5 = periodType1.indexOf(durationFieldType4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.dayOfYear();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.clockhourOfHalfday();
        boolean boolean9 = periodType1.equals((java.lang.Object) gregorianChronology6);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) 1, periodType11);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period14 = period12.normalizedStandard(periodType13);
        org.joda.time.DurationFieldType durationFieldType16 = periodType13.getFieldType(1);
        int int17 = periodType1.indexOf(durationFieldType16);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField18 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType16);
        java.lang.String str19 = unsupportedDurationField18.toString();
        boolean boolean20 = unsupportedDurationField18.isSupported();
        try {
            long long22 = unsupportedDurationField18.getMillis((-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weeks field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(durationFieldType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(unsupportedDurationField18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "UnsupportedDurationField[weeks]" + "'", str19.equals("UnsupportedDurationField[weeks]"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(10L, periodType1, chronology2);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        int int5 = periodType1.indexOf(durationFieldType4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.dayOfYear();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.clockhourOfHalfday();
        boolean boolean9 = periodType1.equals((java.lang.Object) gregorianChronology6);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) 1, periodType11);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period14 = period12.normalizedStandard(periodType13);
        org.joda.time.DurationFieldType durationFieldType16 = periodType13.getFieldType(1);
        int int17 = periodType1.indexOf(durationFieldType16);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField18 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType16);
        org.joda.time.DurationFieldType durationFieldType19 = unsupportedDurationField18.getType();
        try {
            long long22 = unsupportedDurationField18.getValueAsLong(9856L, (-60266073599985L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weeks field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(durationFieldType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(unsupportedDurationField18);
        org.junit.Assert.assertNotNull(durationFieldType19);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.Chronology chronology4 = lenientChronology2.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 10);
        int int10 = offsetDateTimeField8.get((-210866068800000L));
        int int11 = offsetDateTimeField8.getMinimumValue();
        int int14 = offsetDateTimeField8.getDifference((-315705600000L), (long) 'a');
        boolean boolean16 = offsetDateTimeField8.isLeap((long) 35);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField8.getAsText(35L, locale18);
        org.joda.time.DurationField durationField20 = offsetDateTimeField8.getRangeDurationField();
        boolean boolean21 = lenientChronology2.equals((java.lang.Object) offsetDateTimeField8);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 43210 + "'", int10 == 43210);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-315705600) + "'", int14 == (-315705600));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10" + "'", str19.equals("10"));
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("UnsupportedDurationField[weeks]");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        long long6 = dateTimeZone3.adjustOffset((long) '4', false);
        long long9 = dateTimeZone3.convertLocalToUTC((long) 10, false);
        int int11 = dateTimeZone3.getOffsetFromLocal((long) (byte) 0);
        java.util.TimeZone timeZone12 = dateTimeZone3.toTimeZone();
        boolean boolean13 = jodaTimePermission1.equals((java.lang.Object) dateTimeZone3);
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(0L, chronology1);
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, periodType5);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period8 = period6.normalizedStandard(periodType7);
        org.joda.time.DurationFieldType durationFieldType10 = periodType7.getFieldType(1);
        int int11 = periodType3.indexOf(durationFieldType10);
        org.joda.time.Period period13 = period2.withFieldAdded(durationFieldType10, (-10));
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(durationFieldType10, "ZonedChronology[ISOChronology[UTC], +01:00]");
        java.lang.Number number16 = illegalFieldValueException15.getIllegalNumberValue();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNull(number16);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) -1);
        int int2 = period1.getMinutes();
        org.joda.time.Period period4 = period1.withMillis((int) (byte) 100);
        org.joda.time.Period period6 = period1.minusYears((int) (byte) 10);
        org.joda.time.Period period8 = period6.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.era();
        org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) period6, periodType9, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 1, periodType14);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period17 = period15.normalizedStandard(periodType16);
        org.joda.time.DurationFieldType durationFieldType19 = periodType16.getFieldType(1);
        boolean boolean20 = period6.isSupported(durationFieldType19);
        org.joda.time.field.PreciseDurationField preciseDurationField22 = new org.joda.time.field.PreciseDurationField(durationFieldType19, (long) 86409);
        long long23 = preciseDurationField22.getUnitMillis();
        java.lang.String str24 = preciseDurationField22.toString();
        long long27 = preciseDurationField22.getMillis((long) '#', (-60266073599990L));
        long long30 = preciseDurationField22.getValueAsLong(105L, (long) 43210);
        long long32 = preciseDurationField22.getValueAsLong(31795200000L);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 86409L + "'", long23 == 86409L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "DurationField[weeks]" + "'", str24.equals("DurationField[weeks]"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 3024315L + "'", long27 == 3024315L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 367961L + "'", long32 == 367961L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("org.joda.time.IllegalFieldValueException: Value \"\" for hi! is not supported", (-5), 0, 3600000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -5 for org.joda.time.IllegalFieldValueException: Value \"\" for hi! is not supported must be in the range [0,3600000]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("UTC", (-1), 10, (int) (byte) -1, 'a', (int) (short) 100, (int) (byte) -1, 100, false, 10);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder0.addCutover((int) (byte) 0, '4', (int) (short) -1, (int) '#', 0, false, (int) (byte) 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder22 = dateTimeZoneBuilder0.setFixedSavings("LenientChronology[GregorianChronology[America/Los_Angeles]]", (int) (byte) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder24 = dateTimeZoneBuilder22.setStandardOffset((int) (byte) 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder26 = dateTimeZoneBuilder24.setStandardOffset(57609);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder19);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder22);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder24);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder26);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0S", (int) (byte) 0, 0);
        org.joda.time.Period period6 = org.joda.time.Period.days((int) (short) -1);
        int int7 = period6.getMinutes();
        org.joda.time.Period period9 = period6.withMillis((int) (byte) 100);
        org.joda.time.Period period11 = period6.minusYears((int) (byte) 10);
        org.joda.time.Period period13 = period11.plusSeconds((int) (byte) -1);
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) period11);
        java.lang.String str16 = fixedDateTimeZone4.getNameKey((long) 10);
        long long18 = fixedDateTimeZone4.convertUTCToLocal(346000L);
        boolean boolean19 = fixedDateTimeZone4.isFixed();
        int int21 = fixedDateTimeZone4.getOffsetFromLocal(67744656L);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "PT0S" + "'", str16.equals("PT0S"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 346000L + "'", long18 == 346000L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long3 = dateTimeZone0.adjustOffset((long) '4', false);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(1);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, dateTimeZone6);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        int int10 = cachedDateTimeZone8.getOffset((-210866673599000L));
        org.joda.time.LocalDateTime localDateTime11 = null;
        boolean boolean12 = cachedDateTimeZone8.isLocalDateTimeGap(localDateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3600000 + "'", int10 == 3600000);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1560629038067L, 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560629038067L + "'", long2 == 1560629038067L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 100, number2, (java.lang.Number) 2419452L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 10);
        int int5 = offsetDateTimeField3.get((-210866068800000L));
        int int6 = offsetDateTimeField3.getMinimumValue();
        int int9 = offsetDateTimeField3.getDifference((-315705600000L), (long) 'a');
        boolean boolean11 = offsetDateTimeField3.isLeap((long) 35);
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField3.getAsText(35L, locale13);
        org.joda.time.DurationField durationField15 = offsetDateTimeField3.getRangeDurationField();
        org.joda.time.ReadablePartial readablePartial16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) (byte) 10);
        int int22 = offsetDateTimeField20.get((-210866068800000L));
        int int23 = offsetDateTimeField20.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial24 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, (int) (byte) 10);
        int int31 = offsetDateTimeField29.get((-210866068800000L));
        long long33 = offsetDateTimeField29.roundHalfFloor(0L);
        boolean boolean35 = offsetDateTimeField29.isLeap((long) 8);
        org.joda.time.ReadablePartial readablePartial36 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology38.dayOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology40 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology38);
        org.joda.time.Period period42 = org.joda.time.Period.days((int) (short) -1);
        int int43 = period42.getMinutes();
        org.joda.time.Period period45 = period42.withMillis((int) (byte) 100);
        org.joda.time.Period period47 = period42.minusYears((int) (byte) 10);
        int[] intArray49 = lenientChronology40.get((org.joda.time.ReadablePeriod) period42, (long) (short) 0);
        int[] intArray51 = offsetDateTimeField29.addWrapPartial(readablePartial36, (int) (short) 100, intArray49, (int) (byte) 0);
        int[] intArray53 = offsetDateTimeField20.add(readablePartial24, (int) (short) 10, intArray49, 0);
        int int54 = offsetDateTimeField3.getMaximumValue(readablePartial16, intArray49);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 43210 + "'", int5 == 43210);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-315705600) + "'", int9 == (-315705600));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10" + "'", str14.equals("10"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 43210 + "'", int22 == 43210);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 43210 + "'", int31 == 43210);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(lenientChronology40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 86409 + "'", int54 == 86409);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.millis();
        java.lang.Class<?> wildcardClass4 = gregorianChronology0.getClass();
        java.lang.Object obj5 = null;
        boolean boolean6 = gregorianChronology0.equals(obj5);
        org.joda.time.DurationField durationField7 = gregorianChronology0.months();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.joda.time.Period period1 = org.joda.time.Period.days(0);
        org.joda.time.Period period3 = org.joda.time.Period.days(0);
        org.joda.time.Period period4 = period1.plus((org.joda.time.ReadablePeriod) period3);
        org.joda.time.PeriodType periodType5 = period4.getPeriodType();
        org.joda.time.Period period7 = period4.plusWeeks(4);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long3 = dateTimeZone0.adjustOffset((long) '4', false);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(1);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, dateTimeZone6);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        java.lang.String str10 = cachedDateTimeZone8.getNameKey((long) 5);
        org.joda.time.DateTimeZone dateTimeZone11 = cachedDateTimeZone8.getUncachedZone();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType2 = periodType1.withMinutesRemoved();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        long long6 = dateTimeZone3.adjustOffset((long) '4', false);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours(1);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, dateTimeZone9);
        org.joda.time.Period period11 = new org.joda.time.Period((-259199999997L), periodType2, (org.joda.time.Chronology) iSOChronology7);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(zonedChronology10);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long3 = dateTimeZone0.adjustOffset((long) '4', false);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(1);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, dateTimeZone6);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        long long10 = cachedDateTimeZone8.nextTransition((long) (byte) 100);
        java.lang.Class<?> wildcardClass11 = cachedDateTimeZone8.getClass();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("UTC", (-1), 10, (int) (byte) -1, 'a', (int) (short) 100, (int) (byte) -1, 100, false, 10);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder22 = dateTimeZoneBuilder11.addRecurringSavings("PT-1H", 0, (int) (byte) 100, (int) (byte) -1, '4', (int) 'a', (int) '#', (int) '4', true, (int) (short) 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder33 = dateTimeZoneBuilder11.addRecurringSavings("PT32.010S", (int) ' ', 3653, (int) (byte) -1, '#', 0, 7, (-41), true, 1825);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder22);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder33);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "60");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) ' ', "ISOChronology[UTC]");
        java.lang.Throwable[] throwableArray3 = illegalInstantException2.getSuppressed();
        java.lang.Throwable[] throwableArray4 = illegalInstantException2.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) -1);
        int int2 = period1.getMinutes();
        org.joda.time.Period period4 = period1.withMillis((int) (byte) 100);
        org.joda.time.Period period6 = period1.minusYears((int) (byte) 10);
        org.joda.time.Period period8 = period6.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.era();
        org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) period6, periodType9, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 1, periodType14);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period17 = period15.normalizedStandard(periodType16);
        org.joda.time.DurationFieldType durationFieldType19 = periodType16.getFieldType(1);
        boolean boolean20 = period6.isSupported(durationFieldType19);
        org.joda.time.field.PreciseDurationField preciseDurationField22 = new org.joda.time.field.PreciseDurationField(durationFieldType19, (long) 86409);
        int int24 = preciseDurationField22.getValue((long) 57609);
        long long27 = preciseDurationField22.getMillis(10, (long) (byte) -1);
        org.joda.time.PeriodType periodType29 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Chronology chronology30 = null;
        org.joda.time.Period period31 = new org.joda.time.Period(10L, periodType29, chronology30);
        org.joda.time.DurationFieldType durationFieldType32 = null;
        int int33 = periodType29.indexOf(durationFieldType32);
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.dayOfYear();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology34.clockhourOfHalfday();
        boolean boolean37 = periodType29.equals((java.lang.Object) gregorianChronology34);
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period40 = new org.joda.time.Period((long) (short) 1, periodType39);
        org.joda.time.PeriodType periodType41 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period42 = period40.normalizedStandard(periodType41);
        org.joda.time.DurationFieldType durationFieldType44 = periodType41.getFieldType(1);
        int int45 = periodType29.indexOf(durationFieldType44);
        org.joda.time.field.DecoratedDurationField decoratedDurationField46 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) preciseDurationField22, durationFieldType44);
        long long49 = decoratedDurationField46.getDifferenceAsLong(86409L, (long) (-349200000));
        long long52 = decoratedDurationField46.getMillis(28, (long) 52);
        long long55 = decoratedDurationField46.getValueAsLong((long) (-3600000), (-80976232428327L));
        long long58 = decoratedDurationField46.add(0L, 0L);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 864090L + "'", long27 == 864090L);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(durationFieldType44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 4042L + "'", long49 == 4042L);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 2419452L + "'", long52 == 2419452L);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-41L) + "'", long55 == (-41L));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 0L + "'", long58 == 0L);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField4 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) -1);
        int int2 = period1.getMinutes();
        org.joda.time.Period period4 = period1.withMillis((int) (byte) 100);
        org.joda.time.Period period6 = period1.minusYears((int) (byte) 10);
        org.joda.time.Period period8 = period6.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.era();
        org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) period6, periodType9, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 1, periodType14);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period17 = period15.normalizedStandard(periodType16);
        org.joda.time.DurationFieldType durationFieldType19 = periodType16.getFieldType(1);
        boolean boolean20 = period6.isSupported(durationFieldType19);
        org.joda.time.field.PreciseDurationField preciseDurationField22 = new org.joda.time.field.PreciseDurationField(durationFieldType19, (long) 86409);
        java.lang.String str23 = preciseDurationField22.getName();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "weeks" + "'", str23.equals("weeks"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) -1);
        int int2 = period1.getMinutes();
        org.joda.time.Period period4 = period1.withMillis((int) (byte) 100);
        org.joda.time.Period period6 = period1.minusYears((int) (byte) 10);
        org.joda.time.Period period8 = period6.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.era();
        org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) period6, periodType9, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 1, periodType14);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period17 = period15.normalizedStandard(periodType16);
        org.joda.time.DurationFieldType durationFieldType19 = periodType16.getFieldType(1);
        boolean boolean20 = period6.isSupported(durationFieldType19);
        org.joda.time.field.PreciseDurationField preciseDurationField22 = new org.joda.time.field.PreciseDurationField(durationFieldType19, (long) 86409);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.dayOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology25 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology23);
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.era();
        org.joda.time.DateTimeZone dateTimeZone28 = gregorianChronology26.getZone();
        org.joda.time.Chronology chronology29 = lenientChronology25.withZone(dateTimeZone28);
        boolean boolean30 = preciseDurationField22.equals((java.lang.Object) lenientChronology25);
        org.joda.time.DurationFieldType durationFieldType31 = preciseDurationField22.getType();
        long long34 = preciseDurationField22.add((-864090L), 0);
        long long37 = preciseDurationField22.getMillis(4925313L, (-3155702205L));
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(lenientChronology25);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-864090L) + "'", long34 == (-864090L));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 425591371017L + "'", long37 == 425591371017L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (short) 1, (java.lang.Number) 100.0f, (java.lang.Number) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("5");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"5\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) 10);
        int int30 = offsetDateTimeField28.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField28.getAsText(readablePartial31, 1, locale33);
        org.joda.time.ReadablePartial readablePartial35 = null;
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField28.getAsText(readablePartial35, (int) (byte) 100, locale37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType39);
        org.joda.time.Period period42 = org.joda.time.Period.days((int) (short) -1);
        int int43 = period42.getMinutes();
        org.joda.time.Period period45 = period42.withMillis((int) (byte) 100);
        org.joda.time.Period period47 = period42.minusYears((int) (byte) 10);
        org.joda.time.Period period49 = period47.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType50 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology51.era();
        org.joda.time.Period period53 = new org.joda.time.Period((java.lang.Object) period47, periodType50, (org.joda.time.Chronology) gregorianChronology51);
        org.joda.time.PeriodType periodType55 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period56 = new org.joda.time.Period((long) (short) 1, periodType55);
        org.joda.time.PeriodType periodType57 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period58 = period56.normalizedStandard(periodType57);
        org.joda.time.DurationFieldType durationFieldType60 = periodType57.getFieldType(1);
        boolean boolean61 = period47.isSupported(durationFieldType60);
        org.joda.time.field.PreciseDurationField preciseDurationField63 = new org.joda.time.field.PreciseDurationField(durationFieldType60, (long) 86409);
        long long64 = preciseDurationField63.getUnitMillis();
        java.lang.String str65 = preciseDurationField63.toString();
        long long66 = preciseDurationField63.getUnitMillis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField67 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, (org.joda.time.DurationField) preciseDurationField63);
        long long70 = unsupportedDateTimeField67.add((long) (-1), 0);
        long long73 = unsupportedDateTimeField67.add((long) (-1), 0);
        try {
            boolean boolean75 = unsupportedDateTimeField67.isLeap((long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 43210 + "'", int30 == 43210);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "100" + "'", str38.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(periodType55);
        org.junit.Assert.assertNotNull(periodType57);
        org.junit.Assert.assertNotNull(period58);
        org.junit.Assert.assertNotNull(durationFieldType60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 86409L + "'", long64 == 86409L);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "DurationField[weeks]" + "'", str65.equals("DurationField[weeks]"));
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 86409L + "'", long66 == 86409L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField67);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-1L) + "'", long70 == (-1L));
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-1L) + "'", long73 == (-1L));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 10);
        int int5 = offsetDateTimeField3.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial6 = null;
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsText(readablePartial6, 1, locale8);
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((long) (byte) 10);
        org.joda.time.ReadablePartial readablePartial12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.dayOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology16 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology14);
        org.joda.time.Period period18 = org.joda.time.Period.days((int) (short) -1);
        int int19 = period18.getMinutes();
        org.joda.time.Period period21 = period18.withMillis((int) (byte) 100);
        org.joda.time.Period period23 = period18.minusYears((int) (byte) 10);
        int[] intArray25 = lenientChronology16.get((org.joda.time.ReadablePeriod) period18, (long) (short) 0);
        try {
            int[] intArray27 = offsetDateTimeField3.addWrapPartial(readablePartial12, 8, intArray25, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 43210 + "'", int5 == 43210);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10" + "'", str11.equals("10"));
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(lenientChronology16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(intArray25);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test047");
//        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.Period period3 = new org.joda.time.Period(10L, periodType1, chronology2);
//        org.joda.time.DurationFieldType durationFieldType4 = null;
//        int int5 = periodType1.indexOf(durationFieldType4);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.clockhourOfHalfday();
//        boolean boolean9 = periodType1.equals((java.lang.Object) gregorianChronology6);
//        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.hours();
//        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) 1, periodType11);
//        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.yearWeekDayTime();
//        org.joda.time.Period period14 = period12.normalizedStandard(periodType13);
//        org.joda.time.DurationFieldType durationFieldType16 = periodType13.getFieldType(1);
//        int int17 = periodType1.indexOf(durationFieldType16);
//        org.joda.time.field.UnsupportedDurationField unsupportedDurationField18 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType16);
//        boolean boolean19 = unsupportedDurationField18.isPrecise();
//        boolean boolean20 = unsupportedDurationField18.isPrecise();
//        org.joda.time.DurationField durationField21 = null;
//        int int22 = unsupportedDurationField18.compareTo(durationField21);
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.era();
//        org.joda.time.DurationField durationField25 = gregorianChronology23.halfdays();
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology23.dayOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology28 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology23);
//        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.dayTime();
//        org.joda.time.Chronology chronology31 = null;
//        org.joda.time.Period period32 = new org.joda.time.Period(10L, periodType30, chronology31);
//        org.joda.time.Period period34 = period32.withSeconds((int) ' ');
//        boolean boolean35 = lenientChronology28.equals((java.lang.Object) ' ');
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.UTC;
//        boolean boolean38 = dateTimeZone36.isStandardOffset((long) (short) 10);
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = dateTimeZone36.getShortName((long) (short) 10, locale40);
//        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone36);
//        long long45 = dateTimeZone36.adjustOffset(10L, false);
//        org.joda.time.Chronology chronology46 = lenientChronology28.withZone(dateTimeZone36);
//        org.joda.time.DateTimeField dateTimeField47 = lenientChronology28.yearOfCentury();
//        org.joda.time.Period period49 = org.joda.time.Period.days((int) (short) -1);
//        int int50 = period49.getMinutes();
//        org.joda.time.Period period52 = period49.withMillis((int) (byte) 100);
//        org.joda.time.Period period54 = period49.minusYears((int) (byte) 10);
//        org.joda.time.Period period56 = period54.plusSeconds((int) (byte) -1);
//        org.joda.time.PeriodType periodType57 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology58 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField59 = gregorianChronology58.era();
//        org.joda.time.Period period60 = new org.joda.time.Period((java.lang.Object) period54, periodType57, (org.joda.time.Chronology) gregorianChronology58);
//        org.joda.time.PeriodType periodType61 = period54.getPeriodType();
//        boolean boolean62 = lenientChronology28.equals((java.lang.Object) periodType61);
//        boolean boolean63 = unsupportedDurationField18.equals((java.lang.Object) periodType61);
//        java.lang.String str64 = unsupportedDurationField18.toString();
//        org.junit.Assert.assertNotNull(periodType1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(periodType11);
//        org.junit.Assert.assertNotNull(periodType13);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(durationFieldType16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(unsupportedDurationField18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(lenientChronology28);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertNotNull(period34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "UTC" + "'", str41.equals("UTC"));
//        org.junit.Assert.assertNotNull(gregorianChronology42);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 10L + "'", long45 == 10L);
//        org.junit.Assert.assertNotNull(chronology46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertNotNull(period49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
//        org.junit.Assert.assertNotNull(period52);
//        org.junit.Assert.assertNotNull(period54);
//        org.junit.Assert.assertNotNull(period56);
//        org.junit.Assert.assertNotNull(gregorianChronology58);
//        org.junit.Assert.assertNotNull(dateTimeField59);
//        org.junit.Assert.assertNotNull(periodType61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "UnsupportedDurationField[weeks]" + "'", str64.equals("UnsupportedDurationField[weeks]"));
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) 0);
        org.joda.time.Period period3 = period1.minusMinutes((int) (short) 10);
        org.joda.time.Period period5 = period3.minusSeconds(7);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) 10);
        int int30 = offsetDateTimeField28.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField28.getAsText(readablePartial31, 1, locale33);
        org.joda.time.ReadablePartial readablePartial35 = null;
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField28.getAsText(readablePartial35, (int) (byte) 100, locale37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType39);
        long long43 = dividedDateTimeField40.addWrapField((long) (short) 0, 43210);
        int int45 = dividedDateTimeField40.get((-17999903L));
        long long48 = dividedDateTimeField40.set((-60266073600000L), 5);
        long long51 = dividedDateTimeField40.set(259200034L, 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 43210 + "'", int30 == 43210);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "100" + "'", str38.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-252201600000L) + "'", long43 == (-252201600000L));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 17 + "'", int45 == 17);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-61528291200000L) + "'", long48 == (-61528291200000L));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-2145571199966L) + "'", long51 == (-2145571199966L));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 10);
        int int5 = offsetDateTimeField3.get((-210866068800000L));
        java.lang.String str7 = offsetDateTimeField3.getAsText(6040588L);
        long long9 = offsetDateTimeField3.roundHalfEven((long) (short) 0);
        int int11 = offsetDateTimeField3.getMaximumValue(1820100L);
        long long13 = offsetDateTimeField3.remainder((long) '#');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 43210 + "'", int5 == 43210);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "6050" + "'", str7.equals("6050"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 86409 + "'", int11 == 86409);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 35L + "'", long13 == 35L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.joda.time.Period period1 = org.joda.time.Period.months(10);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 10);
        int int5 = offsetDateTimeField3.get((-210866068800000L));
        org.joda.time.DurationField durationField6 = offsetDateTimeField3.getLeapDurationField();
        java.util.Locale locale7 = null;
        int int8 = offsetDateTimeField3.getMaximumTextLength(locale7);
        long long11 = offsetDateTimeField3.add((long) 0, (-3155759914L));
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField3.getType();
        long long15 = offsetDateTimeField3.addWrapField(67744656L, (int) 'a');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 43210 + "'", int5 == 43210);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 5 + "'", int8 == 5);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-3155759914000L) + "'", long11 == (-3155759914000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 67841656L + "'", long15 == 67841656L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period2 = new org.joda.time.Period(2440588L, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DurationField durationField4 = lenientChronology3.hours();
        java.lang.Class<?> wildcardClass5 = durationField4.getClass();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(lenientChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) 10);
        int int30 = offsetDateTimeField28.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField28.getAsText(readablePartial31, 1, locale33);
        org.joda.time.ReadablePartial readablePartial35 = null;
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField28.getAsText(readablePartial35, (int) (byte) 100, locale37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType39);
        org.joda.time.Period period42 = org.joda.time.Period.days((int) (short) -1);
        int int43 = period42.getMinutes();
        org.joda.time.Period period45 = period42.withMillis((int) (byte) 100);
        org.joda.time.Period period47 = period42.minusYears((int) (byte) 10);
        org.joda.time.Period period49 = period47.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType50 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology51.era();
        org.joda.time.Period period53 = new org.joda.time.Period((java.lang.Object) period47, periodType50, (org.joda.time.Chronology) gregorianChronology51);
        org.joda.time.PeriodType periodType55 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period56 = new org.joda.time.Period((long) (short) 1, periodType55);
        org.joda.time.PeriodType periodType57 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period58 = period56.normalizedStandard(periodType57);
        org.joda.time.DurationFieldType durationFieldType60 = periodType57.getFieldType(1);
        boolean boolean61 = period47.isSupported(durationFieldType60);
        org.joda.time.field.PreciseDurationField preciseDurationField63 = new org.joda.time.field.PreciseDurationField(durationFieldType60, (long) 86409);
        long long64 = preciseDurationField63.getUnitMillis();
        java.lang.String str65 = preciseDurationField63.toString();
        long long66 = preciseDurationField63.getUnitMillis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField67 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, (org.joda.time.DurationField) preciseDurationField63);
        org.joda.time.DurationField durationField68 = unsupportedDateTimeField67.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial69 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology71 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField72 = gregorianChronology71.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField74 = new org.joda.time.field.OffsetDateTimeField(dateTimeField72, (int) (byte) 10);
        int int76 = offsetDateTimeField74.get((-210866068800000L));
        long long78 = offsetDateTimeField74.roundHalfFloor(0L);
        boolean boolean80 = offsetDateTimeField74.isLeap((long) 8);
        org.joda.time.ReadablePartial readablePartial81 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology83 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField84 = gregorianChronology83.dayOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology85 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology83);
        org.joda.time.Period period87 = org.joda.time.Period.days((int) (short) -1);
        int int88 = period87.getMinutes();
        org.joda.time.Period period90 = period87.withMillis((int) (byte) 100);
        org.joda.time.Period period92 = period87.minusYears((int) (byte) 10);
        int[] intArray94 = lenientChronology85.get((org.joda.time.ReadablePeriod) period87, (long) (short) 0);
        int[] intArray96 = offsetDateTimeField74.addWrapPartial(readablePartial81, (int) (short) 100, intArray94, (int) (byte) 0);
        try {
            int[] intArray98 = unsupportedDateTimeField67.add(readablePartial69, 97, intArray94, 1815);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 43210 + "'", int30 == 43210);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "100" + "'", str38.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(periodType55);
        org.junit.Assert.assertNotNull(periodType57);
        org.junit.Assert.assertNotNull(period58);
        org.junit.Assert.assertNotNull(durationFieldType60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 86409L + "'", long64 == 86409L);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "DurationField[weeks]" + "'", str65.equals("DurationField[weeks]"));
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 86409L + "'", long66 == 86409L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField67);
        org.junit.Assert.assertNull(durationField68);
        org.junit.Assert.assertNotNull(gregorianChronology71);
        org.junit.Assert.assertNotNull(dateTimeField72);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 43210 + "'", int76 == 43210);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(gregorianChronology83);
        org.junit.Assert.assertNotNull(dateTimeField84);
        org.junit.Assert.assertNotNull(lenientChronology85);
        org.junit.Assert.assertNotNull(period87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
        org.junit.Assert.assertNotNull(period90);
        org.junit.Assert.assertNotNull(period92);
        org.junit.Assert.assertNotNull(intArray94);
        org.junit.Assert.assertNotNull(intArray96);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("UTC", (-1), 10, (int) (byte) -1, 'a', (int) (short) 100, (int) (byte) -1, 100, false, 10);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder0.addCutover((int) (byte) 0, '4', (int) (short) -1, (int) '#', 0, false, (int) (byte) 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder22 = dateTimeZoneBuilder0.setFixedSavings("LenientChronology[GregorianChronology[America/Los_Angeles]]", (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone25 = dateTimeZoneBuilder0.toDateTimeZone("Coordinated Universal Time", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder27 = dateTimeZoneBuilder0.setStandardOffset(57609);
        org.joda.time.DateTimeZone dateTimeZone30 = dateTimeZoneBuilder0.toDateTimeZone("57610", false);
        long long32 = dateTimeZone30.convertUTCToLocal(0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone30);
        long long35 = dateTimeZone30.convertUTCToLocal((-630803375585L));
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder19);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder22);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder27);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 57709L + "'", long32 == 57709L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-630803317876L) + "'", long35 == (-630803317876L));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "hi!", "hi!");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "MonthsNoMonths", "UTC");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getShortName(locale9, "63650", "ISOChronology[UTC]");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) -1);
        int int2 = period1.getMinutes();
        org.joda.time.Period period4 = period1.withMillis((int) (byte) 100);
        org.joda.time.Period period6 = period1.minusYears((int) (byte) 10);
        org.joda.time.Period period8 = period6.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.era();
        org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) period6, periodType9, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 1, periodType14);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period17 = period15.normalizedStandard(periodType16);
        org.joda.time.DurationFieldType durationFieldType19 = periodType16.getFieldType(1);
        boolean boolean20 = period6.isSupported(durationFieldType19);
        org.joda.time.field.PreciseDurationField preciseDurationField22 = new org.joda.time.field.PreciseDurationField(durationFieldType19, (long) 86409);
        int int24 = preciseDurationField22.getValue((long) 57609);
        long long27 = preciseDurationField22.getMillis(10, (long) (byte) -1);
        org.joda.time.PeriodType periodType29 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Chronology chronology30 = null;
        org.joda.time.Period period31 = new org.joda.time.Period(10L, periodType29, chronology30);
        org.joda.time.DurationFieldType durationFieldType32 = null;
        int int33 = periodType29.indexOf(durationFieldType32);
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.dayOfYear();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology34.clockhourOfHalfday();
        boolean boolean37 = periodType29.equals((java.lang.Object) gregorianChronology34);
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period40 = new org.joda.time.Period((long) (short) 1, periodType39);
        org.joda.time.PeriodType periodType41 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period42 = period40.normalizedStandard(periodType41);
        org.joda.time.DurationFieldType durationFieldType44 = periodType41.getFieldType(1);
        int int45 = periodType29.indexOf(durationFieldType44);
        org.joda.time.field.DecoratedDurationField decoratedDurationField46 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) preciseDurationField22, durationFieldType44);
        long long49 = decoratedDurationField46.add(0L, 1);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 864090L + "'", long27 == 864090L);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(durationFieldType44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 86409L + "'", long49 == 86409L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long3 = dateTimeZone0.adjustOffset((long) '4', false);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(1);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, dateTimeZone6);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        java.lang.String str10 = cachedDateTimeZone8.getNameKey((long) 5);
        java.lang.String str12 = cachedDateTimeZone8.getNameKey((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone13 = cachedDateTimeZone8.getUncachedZone();
        java.util.TimeZone timeZone14 = cachedDateTimeZone8.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(timeZone14);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 10);
        int int5 = offsetDateTimeField3.get((-210866068800000L));
        long long7 = offsetDateTimeField3.roundHalfFloor((long) 0);
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray16 = new int[] { 3, (-10), (byte) 1, '4', (-3600000), 43210 };
        java.util.Locale locale18 = null;
        try {
            int[] intArray19 = offsetDateTimeField3.set(readablePartial8, (-50), intArray16, "", locale18);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 43210 + "'", int5 == 43210);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((-210866846400000L), (long) 'a', periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.centuryOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("LenientChronology[GregorianChronology[America/Los_Angeles]]", "", (int) '4', (int) '#');
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        boolean boolean6 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "hi!", "hi!");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "UTC", "UTC");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getName(locale9, "+01:00", "");
        java.util.Locale locale13 = null;
        java.lang.String str16 = defaultNameProvider0.getName(locale13, "PeriodType[Hours]", "PeriodType[YearWeekDay]");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(2);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period(10L, periodType7, chronology8);
        org.joda.time.Period period11 = period9.withSeconds((int) ' ');
        boolean boolean12 = lenientChronology5.equals((java.lang.Object) ' ');
        org.joda.time.DateTimeField dateTimeField13 = lenientChronology5.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.era();
        org.joda.time.DurationField durationField16 = gregorianChronology14.halfdays();
        org.joda.time.DurationField durationField17 = gregorianChronology14.days();
        org.joda.time.DurationField durationField18 = gregorianChronology14.halfdays();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology14.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, (int) (byte) 10);
        int int25 = offsetDateTimeField23.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial26 = null;
        java.util.Locale locale28 = null;
        java.lang.String str29 = offsetDateTimeField23.getAsText(readablePartial26, 1, locale28);
        org.joda.time.ReadablePartial readablePartial30 = null;
        java.util.Locale locale32 = null;
        java.lang.String str33 = offsetDateTimeField23.getAsText(readablePartial30, (int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = offsetDateTimeField23.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField36 = new org.joda.time.field.RemainderDateTimeField(dateTimeField19, dateTimeFieldType34, 4);
        long long38 = remainderDateTimeField36.roundFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology39.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField(dateTimeField40, (int) (byte) 10);
        int int44 = offsetDateTimeField42.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial45 = null;
        java.util.Locale locale47 = null;
        java.lang.String str48 = offsetDateTimeField42.getAsText(readablePartial45, 1, locale47);
        org.joda.time.ReadablePartial readablePartial49 = null;
        java.util.Locale locale51 = null;
        java.lang.String str52 = offsetDateTimeField42.getAsText(readablePartial49, (int) (byte) 100, locale51);
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = offsetDateTimeField42.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField54 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField36, dateTimeFieldType53);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = dividedDateTimeField54.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException58 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType55, (java.lang.Number) 17, "(\"org.joda.time.JodaTimePermission\" \"hi!\")");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField60 = new org.joda.time.field.DividedDateTimeField(dateTimeField13, dateTimeFieldType55, 1815);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 43210 + "'", int25 == 43210);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1" + "'", str29.equals("1"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-259200000L) + "'", long38 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 43210 + "'", int44 == 43210);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1" + "'", str48.equals("1"));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "100" + "'", str52.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) 10);
        int int30 = offsetDateTimeField28.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField28.getAsText(readablePartial31, 1, locale33);
        org.joda.time.ReadablePartial readablePartial35 = null;
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField28.getAsText(readablePartial35, (int) (byte) 100, locale37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType39);
        org.joda.time.Period period42 = org.joda.time.Period.days((int) (short) -1);
        int int43 = period42.getMinutes();
        org.joda.time.Period period45 = period42.withMillis((int) (byte) 100);
        org.joda.time.Period period47 = period42.minusYears((int) (byte) 10);
        org.joda.time.Period period49 = period47.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType50 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology51.era();
        org.joda.time.Period period53 = new org.joda.time.Period((java.lang.Object) period47, periodType50, (org.joda.time.Chronology) gregorianChronology51);
        org.joda.time.PeriodType periodType55 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period56 = new org.joda.time.Period((long) (short) 1, periodType55);
        org.joda.time.PeriodType periodType57 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period58 = period56.normalizedStandard(periodType57);
        org.joda.time.DurationFieldType durationFieldType60 = periodType57.getFieldType(1);
        boolean boolean61 = period47.isSupported(durationFieldType60);
        org.joda.time.field.PreciseDurationField preciseDurationField63 = new org.joda.time.field.PreciseDurationField(durationFieldType60, (long) 86409);
        long long64 = preciseDurationField63.getUnitMillis();
        java.lang.String str65 = preciseDurationField63.toString();
        long long66 = preciseDurationField63.getUnitMillis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField67 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, (org.joda.time.DurationField) preciseDurationField63);
        org.joda.time.DurationField durationField68 = unsupportedDateTimeField67.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial69 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology71 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField72 = gregorianChronology71.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField74 = new org.joda.time.field.OffsetDateTimeField(dateTimeField72, (int) (byte) 10);
        int int76 = offsetDateTimeField74.get((-210866068800000L));
        long long78 = offsetDateTimeField74.roundHalfFloor(0L);
        boolean boolean80 = offsetDateTimeField74.isLeap((long) 8);
        org.joda.time.ReadablePartial readablePartial81 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology83 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField84 = gregorianChronology83.dayOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology85 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology83);
        org.joda.time.Period period87 = org.joda.time.Period.days((int) (short) -1);
        int int88 = period87.getMinutes();
        org.joda.time.Period period90 = period87.withMillis((int) (byte) 100);
        org.joda.time.Period period92 = period87.minusYears((int) (byte) 10);
        int[] intArray94 = lenientChronology85.get((org.joda.time.ReadablePeriod) period87, (long) (short) 0);
        int[] intArray96 = offsetDateTimeField74.addWrapPartial(readablePartial81, (int) (short) 100, intArray94, (int) (byte) 0);
        try {
            int[] intArray98 = unsupportedDateTimeField67.set(readablePartial69, 14832, intArray94, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 43210 + "'", int30 == 43210);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "100" + "'", str38.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(periodType55);
        org.junit.Assert.assertNotNull(periodType57);
        org.junit.Assert.assertNotNull(period58);
        org.junit.Assert.assertNotNull(durationFieldType60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 86409L + "'", long64 == 86409L);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "DurationField[weeks]" + "'", str65.equals("DurationField[weeks]"));
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 86409L + "'", long66 == 86409L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField67);
        org.junit.Assert.assertNull(durationField68);
        org.junit.Assert.assertNotNull(gregorianChronology71);
        org.junit.Assert.assertNotNull(dateTimeField72);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 43210 + "'", int76 == 43210);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(gregorianChronology83);
        org.junit.Assert.assertNotNull(dateTimeField84);
        org.junit.Assert.assertNotNull(lenientChronology85);
        org.junit.Assert.assertNotNull(period87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
        org.junit.Assert.assertNotNull(period90);
        org.junit.Assert.assertNotNull(period92);
        org.junit.Assert.assertNotNull(intArray94);
        org.junit.Assert.assertNotNull(intArray96);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.minusMillis((int) (byte) 1);
        org.joda.time.Period period6 = period4.plusHours((-10));
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) -1);
        int int2 = period1.getMinutes();
        org.joda.time.Period period4 = period1.withMillis((int) (byte) 100);
        org.joda.time.Period period6 = period1.minusYears((int) (byte) 10);
        org.joda.time.Period period8 = period6.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.era();
        org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) period6, periodType9, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 1, periodType14);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period17 = period15.normalizedStandard(periodType16);
        org.joda.time.DurationFieldType durationFieldType19 = periodType16.getFieldType(1);
        boolean boolean20 = period6.isSupported(durationFieldType19);
        org.joda.time.field.PreciseDurationField preciseDurationField22 = new org.joda.time.field.PreciseDurationField(durationFieldType19, (long) 86409);
        int int24 = preciseDurationField22.getValue((long) 57609);
        long long27 = preciseDurationField22.getMillis(10, (long) (byte) -1);
        org.joda.time.PeriodType periodType29 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Chronology chronology30 = null;
        org.joda.time.Period period31 = new org.joda.time.Period(10L, periodType29, chronology30);
        org.joda.time.DurationFieldType durationFieldType32 = null;
        int int33 = periodType29.indexOf(durationFieldType32);
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.dayOfYear();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology34.clockhourOfHalfday();
        boolean boolean37 = periodType29.equals((java.lang.Object) gregorianChronology34);
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period40 = new org.joda.time.Period((long) (short) 1, periodType39);
        org.joda.time.PeriodType periodType41 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period42 = period40.normalizedStandard(periodType41);
        org.joda.time.DurationFieldType durationFieldType44 = periodType41.getFieldType(1);
        int int45 = periodType29.indexOf(durationFieldType44);
        org.joda.time.field.DecoratedDurationField decoratedDurationField46 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) preciseDurationField22, durationFieldType44);
        int int49 = decoratedDurationField46.getDifference((long) (-5), 1560629038067L);
        long long52 = decoratedDurationField46.getMillis((-259199999997L), 0L);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 864090L + "'", long27 == 864090L);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(durationFieldType44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-18060954) + "'", int49 == (-18060954));
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-22397212799740773L) + "'", long52 == (-22397212799740773L));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) 10);
        int int30 = offsetDateTimeField28.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField28.getAsText(readablePartial31, 1, locale33);
        org.joda.time.ReadablePartial readablePartial35 = null;
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField28.getAsText(readablePartial35, (int) (byte) 100, locale37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType39);
        long long43 = dividedDateTimeField40.addWrapField((long) (short) 0, 43210);
        int int45 = dividedDateTimeField40.get((-17999903L));
        long long48 = dividedDateTimeField40.set((-60266073600000L), 5);
        long long51 = dividedDateTimeField40.getDifferenceAsLong((long) 1820, 0L);
        int int52 = dividedDateTimeField40.getMaximumValue();
        int int55 = dividedDateTimeField40.getDifference((long) 100, 100L);
        int int56 = dividedDateTimeField40.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 43210 + "'", int30 == 43210);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "100" + "'", str38.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-252201600000L) + "'", long43 == (-252201600000L));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 17 + "'", int45 == 17);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-61528291200000L) + "'", long48 == (-61528291200000L));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 25 + "'", int52 == 25);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test070");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.dayTime();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.Period period9 = new org.joda.time.Period(10L, periodType7, chronology8);
//        org.joda.time.Period period11 = period9.withSeconds((int) ' ');
//        boolean boolean12 = lenientChronology5.equals((java.lang.Object) ' ');
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
//        boolean boolean15 = dateTimeZone13.isStandardOffset((long) (short) 10);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone13.getShortName((long) (short) 10, locale17);
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
//        long long22 = dateTimeZone13.adjustOffset(10L, false);
//        org.joda.time.Chronology chronology23 = lenientChronology5.withZone(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField24 = lenientChronology5.yearOfCentury();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone29 = new org.joda.time.tz.FixedDateTimeZone("", "PT0S", (int) (byte) 0, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.era();
//        org.joda.time.DurationField durationField32 = gregorianChronology30.halfdays();
//        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology30.clockhourOfDay();
//        boolean boolean34 = fixedDateTimeZone29.equals((java.lang.Object) gregorianChronology30);
//        boolean boolean35 = fixedDateTimeZone29.isFixed();
//        org.joda.time.LocalDateTime localDateTime36 = null;
//        boolean boolean37 = fixedDateTimeZone29.isLocalDateTimeGap(localDateTime36);
//        org.joda.time.chrono.ZonedChronology zonedChronology38 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) lenientChronology5, (org.joda.time.DateTimeZone) fixedDateTimeZone29);
//        org.joda.time.DateTimeField dateTimeField39 = zonedChronology38.dayOfYear();
//        java.lang.String str40 = zonedChronology38.toString();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(lenientChronology5);
//        org.junit.Assert.assertNotNull(periodType7);
//        org.junit.Assert.assertNotNull(period11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "UTC" + "'", str18.equals("UTC"));
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(zonedChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "ZonedChronology[LenientChronology[GregorianChronology[UTC]], ]" + "'", str40.equals("ZonedChronology[LenientChronology[GregorianChronology[UTC]], ]"));
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.joda.time.Period period4 = new org.joda.time.Period((-41), 86409, 0, (int) (byte) -1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        boolean boolean4 = jodaTimePermission1.equals((java.lang.Object) 52L);
        java.security.PermissionCollection permissionCollection5 = jodaTimePermission1.newPermissionCollection();
        org.joda.time.IllegalFieldValueException illegalFieldValueException8 = new org.joda.time.IllegalFieldValueException("PT0S", "MonthsNoMonths");
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException("hi!", "");
        java.lang.String str12 = illegalFieldValueException11.getFieldName();
        java.lang.String str13 = illegalFieldValueException11.getIllegalValueAsString();
        java.lang.Number number14 = illegalFieldValueException11.getLowerBound();
        illegalFieldValueException8.addSuppressed((java.lang.Throwable) illegalFieldValueException11);
        java.lang.String str16 = illegalFieldValueException11.getIllegalStringValue();
        jodaTimePermission1.checkGuard((java.lang.Object) illegalFieldValueException11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(permissionCollection5);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(8);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-8) + "'", int1 == (-8));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 10);
        int int5 = offsetDateTimeField3.get((-210866068800000L));
        java.lang.String str7 = offsetDateTimeField3.getAsText(6040588L);
        org.joda.time.DateTimeField dateTimeField8 = offsetDateTimeField3.getWrappedField();
        org.joda.time.ReadablePartial readablePartial9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) (byte) 10);
        int int16 = offsetDateTimeField14.get((-210866068800000L));
        int int17 = offsetDateTimeField14.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, (int) (byte) 10);
        int int25 = offsetDateTimeField23.get((-210866068800000L));
        long long27 = offsetDateTimeField23.roundHalfFloor(0L);
        boolean boolean29 = offsetDateTimeField23.isLeap((long) 8);
        org.joda.time.ReadablePartial readablePartial30 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology32.dayOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology34 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology32);
        org.joda.time.Period period36 = org.joda.time.Period.days((int) (short) -1);
        int int37 = period36.getMinutes();
        org.joda.time.Period period39 = period36.withMillis((int) (byte) 100);
        org.joda.time.Period period41 = period36.minusYears((int) (byte) 10);
        int[] intArray43 = lenientChronology34.get((org.joda.time.ReadablePeriod) period36, (long) (short) 0);
        int[] intArray45 = offsetDateTimeField23.addWrapPartial(readablePartial30, (int) (short) 100, intArray43, (int) (byte) 0);
        int[] intArray47 = offsetDateTimeField14.add(readablePartial18, (int) (short) 10, intArray43, 0);
        java.util.Locale locale49 = null;
        try {
            int[] intArray50 = offsetDateTimeField3.set(readablePartial9, (-1), intArray47, "P35Y-1W-10DT14832H143.409S", locale49);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"P35Y-1W-10DT14832H143.409S\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 43210 + "'", int5 == 43210);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "6050" + "'", str7.equals("6050"));
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 43210 + "'", int16 == 43210);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 43210 + "'", int25 == 43210);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(lenientChronology34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray47);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundCeiling(1560629037229L);
        long long27 = remainderDateTimeField22.addWrapField((-4925311L), (int) (short) 0);
        java.util.Locale locale28 = null;
        int int29 = remainderDateTimeField22.getMaximumTextLength(locale28);
        java.util.Locale locale31 = null;
        java.lang.String str32 = remainderDateTimeField22.getAsText(6045588L, locale31);
        org.joda.time.ReadablePartial readablePartial33 = null;
        java.util.Locale locale35 = null;
        java.lang.String str36 = remainderDateTimeField22.getAsText(readablePartial33, (-1), locale35);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577664000000L + "'", long24 == 1577664000000L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-4925311L) + "'", long27 == (-4925311L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "3" + "'", str32.equals("3"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "-1" + "'", str36.equals("-1"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("PeriodType[MonthsNoMonths]", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundFloor(0L);
        long long26 = remainderDateTimeField22.roundCeiling(86409L);
        java.util.Locale locale28 = null;
        java.lang.String str29 = remainderDateTimeField22.getAsText((-5), locale28);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 31795200000L + "'", long26 == 31795200000L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "-5" + "'", str29.equals("-5"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) -1);
        int int2 = period1.getMinutes();
        org.joda.time.Period period4 = period1.withMillis((int) (byte) 100);
        org.joda.time.Period period6 = period1.minusYears((int) (byte) 10);
        org.joda.time.Period period8 = period6.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.era();
        org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) period6, periodType9, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 1, periodType14);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period17 = period15.normalizedStandard(periodType16);
        org.joda.time.DurationFieldType durationFieldType19 = periodType16.getFieldType(1);
        boolean boolean20 = period6.isSupported(durationFieldType19);
        org.joda.time.field.PreciseDurationField preciseDurationField22 = new org.joda.time.field.PreciseDurationField(durationFieldType19, (long) 86409);
        long long23 = preciseDurationField22.getUnitMillis();
        java.lang.String str24 = preciseDurationField22.toString();
        java.lang.Object obj25 = null;
        boolean boolean26 = preciseDurationField22.equals(obj25);
        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period(10L, periodType28, chronology29);
        org.joda.time.DurationFieldType durationFieldType31 = null;
        int int32 = periodType28.indexOf(durationFieldType31);
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.dayOfYear();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology33.clockhourOfHalfday();
        boolean boolean36 = periodType28.equals((java.lang.Object) gregorianChronology33);
        org.joda.time.PeriodType periodType37 = org.joda.time.DateTimeUtils.getPeriodType(periodType28);
        boolean boolean38 = preciseDurationField22.equals((java.lang.Object) periodType28);
        long long41 = preciseDurationField22.getDifferenceAsLong(4010241690L, (long) ' ');
        long long43 = preciseDurationField22.getMillis((-8));
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 86409L + "'", long23 == 86409L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "DurationField[weeks]" + "'", str24.equals("DurationField[weeks]"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 46409L + "'", long41 == 46409L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-691272L) + "'", long43 == (-691272L));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) -1);
        int int2 = period1.getMinutes();
        org.joda.time.Period period4 = period1.withMillis((int) (byte) 100);
        org.joda.time.Period period6 = period1.minusYears((int) (byte) 10);
        org.joda.time.Period period8 = period6.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.era();
        org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) period6, periodType9, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 1, periodType14);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period17 = period15.normalizedStandard(periodType16);
        org.joda.time.DurationFieldType durationFieldType19 = periodType16.getFieldType(1);
        boolean boolean20 = period6.isSupported(durationFieldType19);
        org.joda.time.field.PreciseDurationField preciseDurationField22 = new org.joda.time.field.PreciseDurationField(durationFieldType19, (long) 86409);
        int int24 = preciseDurationField22.getValue((long) 57609);
        long long27 = preciseDurationField22.getMillis(10, (long) (byte) -1);
        org.joda.time.PeriodType periodType29 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Chronology chronology30 = null;
        org.joda.time.Period period31 = new org.joda.time.Period(10L, periodType29, chronology30);
        org.joda.time.DurationFieldType durationFieldType32 = null;
        int int33 = periodType29.indexOf(durationFieldType32);
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.dayOfYear();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology34.clockhourOfHalfday();
        boolean boolean37 = periodType29.equals((java.lang.Object) gregorianChronology34);
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period40 = new org.joda.time.Period((long) (short) 1, periodType39);
        org.joda.time.PeriodType periodType41 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period42 = period40.normalizedStandard(periodType41);
        org.joda.time.DurationFieldType durationFieldType44 = periodType41.getFieldType(1);
        int int45 = periodType29.indexOf(durationFieldType44);
        org.joda.time.field.DecoratedDurationField decoratedDurationField46 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) preciseDurationField22, durationFieldType44);
        boolean boolean47 = decoratedDurationField46.isPrecise();
        boolean boolean48 = decoratedDurationField46.isPrecise();
        long long51 = decoratedDurationField46.add((-72645112427327L), (long) 1300);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 864090L + "'", long27 == 864090L);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(durationFieldType44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-72645000095627L) + "'", long51 == (-72645000095627L));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.joda.time.Period period1 = org.joda.time.Period.months(1820);
        org.joda.time.Period period3 = period1.withHours(0);
        org.joda.time.Period period5 = period1.withWeeks(25);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File[] fileArray2 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = zoneInfoCompiler0.compile(file1, fileArray2);
        org.junit.Assert.assertNotNull(fileArray2);
        org.junit.Assert.assertNotNull(strMap3);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(8);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.joda.time.Period period4 = new org.joda.time.Period(0, 28, 0, 57);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) 10);
        int int30 = offsetDateTimeField28.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField28.getAsText(readablePartial31, 1, locale33);
        org.joda.time.ReadablePartial readablePartial35 = null;
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField28.getAsText(readablePartial35, (int) (byte) 100, locale37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType39);
        org.joda.time.Period period42 = org.joda.time.Period.days((int) (short) -1);
        int int43 = period42.getMinutes();
        org.joda.time.Period period45 = period42.withMillis((int) (byte) 100);
        org.joda.time.Period period47 = period42.minusYears((int) (byte) 10);
        org.joda.time.Period period49 = period47.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType50 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology51.era();
        org.joda.time.Period period53 = new org.joda.time.Period((java.lang.Object) period47, periodType50, (org.joda.time.Chronology) gregorianChronology51);
        org.joda.time.PeriodType periodType55 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period56 = new org.joda.time.Period((long) (short) 1, periodType55);
        org.joda.time.PeriodType periodType57 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period58 = period56.normalizedStandard(periodType57);
        org.joda.time.DurationFieldType durationFieldType60 = periodType57.getFieldType(1);
        boolean boolean61 = period47.isSupported(durationFieldType60);
        org.joda.time.field.PreciseDurationField preciseDurationField63 = new org.joda.time.field.PreciseDurationField(durationFieldType60, (long) 86409);
        long long64 = preciseDurationField63.getUnitMillis();
        java.lang.String str65 = preciseDurationField63.toString();
        long long66 = preciseDurationField63.getUnitMillis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField67 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, (org.joda.time.DurationField) preciseDurationField63);
        org.joda.time.DateTimeFieldType dateTimeFieldType68 = unsupportedDateTimeField67.getType();
        int int71 = unsupportedDateTimeField67.getDifference((long) ' ', 134380378000L);
        org.joda.time.ReadablePartial readablePartial72 = null;
        java.util.Locale locale74 = null;
        try {
            java.lang.String str75 = unsupportedDateTimeField67.getAsText(readablePartial72, 10, locale74);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 43210 + "'", int30 == 43210);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "100" + "'", str38.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(periodType55);
        org.junit.Assert.assertNotNull(periodType57);
        org.junit.Assert.assertNotNull(period58);
        org.junit.Assert.assertNotNull(durationFieldType60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 86409L + "'", long64 == 86409L);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "DurationField[weeks]" + "'", str65.equals("DurationField[weeks]"));
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 86409L + "'", long66 == 86409L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField67);
        org.junit.Assert.assertNotNull(dateTimeFieldType68);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1555166) + "'", int71 == (-1555166));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) -1);
        org.joda.time.Period period3 = period1.plusYears((int) (byte) 1);
        org.joda.time.Period period5 = period3.minusWeeks((int) (short) 0);
        org.joda.time.DurationFieldType durationFieldType7 = period5.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField8 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType7);
        long long9 = unsupportedDurationField8.getUnitMillis();
        boolean boolean10 = unsupportedDurationField8.isPrecise();
        try {
            long long12 = unsupportedDurationField8.getMillis((-18060954));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertNotNull(unsupportedDurationField8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.joda.time.Period period1 = org.joda.time.Period.days(0);
        org.joda.time.Period period3 = org.joda.time.Period.days(0);
        org.joda.time.Period period4 = period1.plus((org.joda.time.ReadablePeriod) period3);
        org.joda.time.Period period6 = period4.minusWeeks(10);
        org.joda.time.Period period8 = period4.withSeconds(0);
        org.joda.time.Period period10 = period4.minusMonths((-5));
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(0L, chronology1);
        int int3 = period2.getMillis();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType5 = periodType4.withMillisRemoved();
        org.joda.time.Period period6 = period2.withPeriodType(periodType4);
        org.joda.time.MutablePeriod mutablePeriod7 = period6.toMutablePeriod();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(mutablePeriod7);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) 10);
        int int30 = offsetDateTimeField28.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField28.getAsText(readablePartial31, 1, locale33);
        org.joda.time.ReadablePartial readablePartial35 = null;
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField28.getAsText(readablePartial35, (int) (byte) 100, locale37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType39);
        org.joda.time.Period period42 = org.joda.time.Period.days((int) (short) -1);
        int int43 = period42.getMinutes();
        org.joda.time.Period period45 = period42.withMillis((int) (byte) 100);
        org.joda.time.Period period47 = period42.minusYears((int) (byte) 10);
        org.joda.time.Period period49 = period47.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType50 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology51.era();
        org.joda.time.Period period53 = new org.joda.time.Period((java.lang.Object) period47, periodType50, (org.joda.time.Chronology) gregorianChronology51);
        org.joda.time.PeriodType periodType55 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period56 = new org.joda.time.Period((long) (short) 1, periodType55);
        org.joda.time.PeriodType periodType57 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period58 = period56.normalizedStandard(periodType57);
        org.joda.time.DurationFieldType durationFieldType60 = periodType57.getFieldType(1);
        boolean boolean61 = period47.isSupported(durationFieldType60);
        org.joda.time.field.PreciseDurationField preciseDurationField63 = new org.joda.time.field.PreciseDurationField(durationFieldType60, (long) 86409);
        long long64 = preciseDurationField63.getUnitMillis();
        java.lang.String str65 = preciseDurationField63.toString();
        long long66 = preciseDurationField63.getUnitMillis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField67 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, (org.joda.time.DurationField) preciseDurationField63);
        long long70 = unsupportedDateTimeField67.add((long) (-1), 0);
        org.joda.time.ReadablePartial readablePartial71 = null;
        int[] intArray73 = null;
        try {
            int[] intArray75 = unsupportedDateTimeField67.set(readablePartial71, (int) (short) 1, intArray73, 57609);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 43210 + "'", int30 == 43210);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "100" + "'", str38.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(periodType55);
        org.junit.Assert.assertNotNull(periodType57);
        org.junit.Assert.assertNotNull(period58);
        org.junit.Assert.assertNotNull(durationFieldType60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 86409L + "'", long64 == 86409L);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "DurationField[weeks]" + "'", str65.equals("DurationField[weeks]"));
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 86409L + "'", long66 == 86409L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField67);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-1L) + "'", long70 == (-1L));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) 10);
        int int30 = offsetDateTimeField28.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField28.getAsText(readablePartial31, 1, locale33);
        org.joda.time.ReadablePartial readablePartial35 = null;
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField28.getAsText(readablePartial35, (int) (byte) 100, locale37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType39);
        org.joda.time.Period period42 = org.joda.time.Period.days((int) (short) -1);
        int int43 = period42.getMinutes();
        org.joda.time.Period period45 = period42.withMillis((int) (byte) 100);
        org.joda.time.Period period47 = period42.minusYears((int) (byte) 10);
        org.joda.time.Period period49 = period47.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType50 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology51.era();
        org.joda.time.Period period53 = new org.joda.time.Period((java.lang.Object) period47, periodType50, (org.joda.time.Chronology) gregorianChronology51);
        org.joda.time.PeriodType periodType55 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period56 = new org.joda.time.Period((long) (short) 1, periodType55);
        org.joda.time.PeriodType periodType57 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period58 = period56.normalizedStandard(periodType57);
        org.joda.time.DurationFieldType durationFieldType60 = periodType57.getFieldType(1);
        boolean boolean61 = period47.isSupported(durationFieldType60);
        org.joda.time.field.PreciseDurationField preciseDurationField63 = new org.joda.time.field.PreciseDurationField(durationFieldType60, (long) 86409);
        long long64 = preciseDurationField63.getUnitMillis();
        java.lang.String str65 = preciseDurationField63.toString();
        long long66 = preciseDurationField63.getUnitMillis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField67 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, (org.joda.time.DurationField) preciseDurationField63);
        long long70 = unsupportedDateTimeField67.add((long) (-1), 0);
        int int73 = unsupportedDateTimeField67.getDifference((long) 10, (long) (-315705600));
        org.joda.time.DurationField durationField74 = unsupportedDateTimeField67.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = unsupportedDateTimeField67.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException79 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType75, (java.lang.Number) (byte) -1, (java.lang.Number) (-3653619L), (java.lang.Number) 3600001L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 43210 + "'", int30 == 43210);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "100" + "'", str38.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(periodType55);
        org.junit.Assert.assertNotNull(periodType57);
        org.junit.Assert.assertNotNull(period58);
        org.junit.Assert.assertNotNull(durationFieldType60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 86409L + "'", long64 == 86409L);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "DurationField[weeks]" + "'", str65.equals("DurationField[weeks]"));
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 86409L + "'", long66 == 86409L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField67);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-1L) + "'", long70 == (-1L));
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 3653 + "'", int73 == 3653);
        org.junit.Assert.assertNotNull(durationField74);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) 10);
        int int30 = offsetDateTimeField28.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField28.getAsText(readablePartial31, 1, locale33);
        org.joda.time.ReadablePartial readablePartial35 = null;
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField28.getAsText(readablePartial35, (int) (byte) 100, locale37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType39);
        long long43 = dividedDateTimeField40.addWrapField((long) (short) 0, 43210);
        int int45 = dividedDateTimeField40.get((-17999903L));
        long long48 = dividedDateTimeField40.set((-60266073600000L), 5);
        long long51 = dividedDateTimeField40.getDifferenceAsLong((long) 1820, 0L);
        int int52 = dividedDateTimeField40.getMaximumValue();
        int int53 = dividedDateTimeField40.getMinimumValue();
        org.joda.time.chrono.GregorianChronology gregorianChronology54 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology54.era();
        org.joda.time.DurationField durationField56 = gregorianChronology54.halfdays();
        org.joda.time.DurationField durationField57 = gregorianChronology54.days();
        org.joda.time.DurationField durationField58 = gregorianChronology54.halfdays();
        org.joda.time.DateTimeField dateTimeField59 = gregorianChronology54.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology60 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField61 = gregorianChronology60.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField63 = new org.joda.time.field.OffsetDateTimeField(dateTimeField61, (int) (byte) 10);
        int int65 = offsetDateTimeField63.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial66 = null;
        java.util.Locale locale68 = null;
        java.lang.String str69 = offsetDateTimeField63.getAsText(readablePartial66, 1, locale68);
        org.joda.time.ReadablePartial readablePartial70 = null;
        java.util.Locale locale72 = null;
        java.lang.String str73 = offsetDateTimeField63.getAsText(readablePartial70, (int) (byte) 100, locale72);
        org.joda.time.DateTimeFieldType dateTimeFieldType74 = offsetDateTimeField63.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField76 = new org.joda.time.field.RemainderDateTimeField(dateTimeField59, dateTimeFieldType74, 4);
        long long78 = remainderDateTimeField76.roundFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology79 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField80 = gregorianChronology79.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField82 = new org.joda.time.field.OffsetDateTimeField(dateTimeField80, (int) (byte) 10);
        int int84 = offsetDateTimeField82.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial85 = null;
        java.util.Locale locale87 = null;
        java.lang.String str88 = offsetDateTimeField82.getAsText(readablePartial85, 1, locale87);
        org.joda.time.ReadablePartial readablePartial89 = null;
        java.util.Locale locale91 = null;
        java.lang.String str92 = offsetDateTimeField82.getAsText(readablePartial89, (int) (byte) 100, locale91);
        org.joda.time.DateTimeFieldType dateTimeFieldType93 = offsetDateTimeField82.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField94 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField76, dateTimeFieldType93);
        org.joda.time.DateTimeFieldType dateTimeFieldType95 = dividedDateTimeField94.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField97 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField40, dateTimeFieldType95, 97);
        try {
            long long99 = dividedDateTimeField97.roundCeiling(0L);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekyearOfCentury must be in the range [1,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 43210 + "'", int30 == 43210);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "100" + "'", str38.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-252201600000L) + "'", long43 == (-252201600000L));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 17 + "'", int45 == 17);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-61528291200000L) + "'", long48 == (-61528291200000L));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 25 + "'", int52 == 25);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(durationField56);
        org.junit.Assert.assertNotNull(durationField57);
        org.junit.Assert.assertNotNull(durationField58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(gregorianChronology60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 43210 + "'", int65 == 43210);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "1" + "'", str69.equals("1"));
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "100" + "'", str73.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType74);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + (-259200000L) + "'", long78 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology79);
        org.junit.Assert.assertNotNull(dateTimeField80);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 43210 + "'", int84 == 43210);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "1" + "'", str88.equals("1"));
        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "100" + "'", str92.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType93);
        org.junit.Assert.assertNotNull(dateTimeFieldType95);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test091");
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.months();
//        org.joda.time.PeriodType periodType3 = periodType2.withMonthsRemoved();
//        org.joda.time.PeriodType periodType4 = periodType3.withDaysRemoved();
//        org.joda.time.PeriodType periodType5 = periodType3.withMinutesRemoved();
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.chrono.LenientChronology lenientChronology7 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology6);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
//        long long11 = dateTimeZone8.adjustOffset((long) '4', false);
//        boolean boolean13 = dateTimeZone8.isStandardOffset((long) '#');
//        java.lang.String str15 = dateTimeZone8.getShortName(1L);
//        org.joda.time.Chronology chronology16 = gregorianChronology6.withZone(dateTimeZone8);
//        org.joda.time.DurationField durationField17 = gregorianChronology6.halfdays();
//        org.joda.time.Period period18 = new org.joda.time.Period((long) 'a', 0L, periodType5, (org.joda.time.Chronology) gregorianChronology6);
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology6.era();
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(periodType3);
//        org.junit.Assert.assertNotNull(periodType4);
//        org.junit.Assert.assertNotNull(periodType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(lenientChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 52L + "'", long11 == 52L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0S", (int) (byte) 0, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.era();
        org.joda.time.DurationField durationField7 = gregorianChronology5.halfdays();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.clockhourOfDay();
        boolean boolean9 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology5);
        int int11 = fixedDateTimeZone4.getStandardOffset((long) 1);
        int int13 = fixedDateTimeZone4.getStandardOffset((long) 'a');
        long long17 = fixedDateTimeZone4.convertLocalToUTC((long) (-100), true, 1L);
        java.lang.String str18 = fixedDateTimeZone4.getID();
        java.lang.String str20 = fixedDateTimeZone4.getNameKey((long) (byte) 100);
        java.util.TimeZone timeZone21 = fixedDateTimeZone4.toTimeZone();
        int int23 = fixedDateTimeZone4.getOffsetFromLocal(4010241690L);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone28 = new org.joda.time.tz.FixedDateTimeZone("", "PT0S", (int) (byte) 0, 0);
        org.joda.time.Period period30 = org.joda.time.Period.days((int) (short) -1);
        int int31 = period30.getMinutes();
        org.joda.time.Period period33 = period30.withMillis((int) (byte) 100);
        org.joda.time.Period period35 = period30.minusYears((int) (byte) 10);
        org.joda.time.Period period37 = period35.plusSeconds((int) (byte) -1);
        boolean boolean38 = fixedDateTimeZone28.equals((java.lang.Object) period35);
        java.lang.String str40 = fixedDateTimeZone28.getNameKey((long) 10);
        long long42 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone28, 0L);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-100L) + "'", long17 == (-100L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PT0S" + "'", str20.equals("PT0S"));
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "PT0S" + "'", str40.equals("PT0S"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) -1);
        int int2 = period1.getMinutes();
        org.joda.time.Period period4 = period1.withMillis((int) (byte) 100);
        org.joda.time.Period period6 = period1.minusYears((int) (byte) 10);
        org.joda.time.Period period8 = period6.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.era();
        org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) period6, periodType9, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 1, periodType14);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period17 = period15.normalizedStandard(periodType16);
        org.joda.time.DurationFieldType durationFieldType19 = periodType16.getFieldType(1);
        boolean boolean20 = period6.isSupported(durationFieldType19);
        org.joda.time.field.PreciseDurationField preciseDurationField22 = new org.joda.time.field.PreciseDurationField(durationFieldType19, (long) 86409);
        int int24 = preciseDurationField22.getValue((long) 57609);
        long long27 = preciseDurationField22.getMillis(10, (long) (byte) -1);
        org.joda.time.PeriodType periodType29 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Chronology chronology30 = null;
        org.joda.time.Period period31 = new org.joda.time.Period(10L, periodType29, chronology30);
        org.joda.time.DurationFieldType durationFieldType32 = null;
        int int33 = periodType29.indexOf(durationFieldType32);
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.dayOfYear();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology34.clockhourOfHalfday();
        boolean boolean37 = periodType29.equals((java.lang.Object) gregorianChronology34);
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period40 = new org.joda.time.Period((long) (short) 1, periodType39);
        org.joda.time.PeriodType periodType41 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period42 = period40.normalizedStandard(periodType41);
        org.joda.time.DurationFieldType durationFieldType44 = periodType41.getFieldType(1);
        int int45 = periodType29.indexOf(durationFieldType44);
        org.joda.time.field.DecoratedDurationField decoratedDurationField46 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) preciseDurationField22, durationFieldType44);
        long long49 = decoratedDurationField46.getDifferenceAsLong(86409L, (long) (-349200000));
        long long52 = decoratedDurationField46.getMillis(28, (long) 52);
        long long55 = decoratedDurationField46.getValueAsLong((long) (-3600000), (-80976232428327L));
        long long58 = decoratedDurationField46.getDifferenceAsLong((long) (-10), 7L);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 864090L + "'", long27 == 864090L);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(durationFieldType44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 4042L + "'", long49 == 4042L);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 2419452L + "'", long52 == 2419452L);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-41L) + "'", long55 == (-41L));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 0L + "'", long58 == 0L);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test094");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 10);
//        int int5 = offsetDateTimeField3.get((-210866068800000L));
//        org.joda.time.ReadablePartial readablePartial6 = null;
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = offsetDateTimeField3.getAsText(readablePartial6, 1, locale8);
//        org.joda.time.DateTimeField dateTimeField10 = offsetDateTimeField3.getWrappedField();
//        org.joda.time.ReadablePartial readablePartial11 = null;
//        int int12 = offsetDateTimeField3.getMaximumValue(readablePartial11);
//        java.lang.String str14 = offsetDateTimeField3.getAsShortText((long) 97);
//        boolean boolean15 = offsetDateTimeField3.isSupported();
//        org.joda.time.ReadablePartial readablePartial16 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.chrono.LenientChronology lenientChronology18 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology17);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.UTC;
//        long long22 = dateTimeZone19.adjustOffset((long) '4', false);
//        boolean boolean24 = dateTimeZone19.isStandardOffset((long) '#');
//        java.lang.String str26 = dateTimeZone19.getShortName(1L);
//        org.joda.time.Chronology chronology27 = gregorianChronology17.withZone(dateTimeZone19);
//        org.joda.time.chrono.LenientChronology lenientChronology28 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology17);
//        org.joda.time.Period period30 = org.joda.time.Period.weeks((-1));
//        org.joda.time.Period period32 = period30.withHours((int) ' ');
//        org.joda.time.Seconds seconds33 = period32.toStandardSeconds();
//        int[] intArray35 = lenientChronology28.get((org.joda.time.ReadablePeriod) period32, 0L);
//        int int36 = offsetDateTimeField3.getMaximumValue(readablePartial16, intArray35);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 43210 + "'", int5 == 43210);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86409 + "'", int12 == 86409);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10" + "'", str14.equals("10"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(lenientChronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 52L + "'", long22 == 52L);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UTC" + "'", str26.equals("UTC"));
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(lenientChronology28);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertNotNull(period32);
//        org.junit.Assert.assertNotNull(seconds33);
//        org.junit.Assert.assertNotNull(intArray35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 86409 + "'", int36 == 86409);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException2.prependMessage("hi!");
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        java.lang.Number number6 = illegalFieldValueException2.getUpperBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException("Coordinated Universal Time", (java.lang.Number) 2440587L, (java.lang.Number) (byte) 10, (java.lang.Number) 0.0d);
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException14.prependMessage("hi!");
        illegalFieldValueException11.addSuppressed((java.lang.Throwable) illegalFieldValueException14);
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException14);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(number6);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test096");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
//        long long7 = dateTimeZone4.adjustOffset((long) '4', false);
//        boolean boolean9 = dateTimeZone4.isStandardOffset((long) '#');
//        java.lang.String str11 = dateTimeZone4.getShortName(1L);
//        org.joda.time.Chronology chronology12 = gregorianChronology2.withZone(dateTimeZone4);
//        org.joda.time.Chronology chronology13 = iSOChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.UTC;
//        long long17 = dateTimeZone14.adjustOffset((long) '4', false);
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours(1);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology18, dateTimeZone20);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone20);
//        long long24 = cachedDateTimeZone22.nextTransition((long) (byte) 100);
//        int int26 = cachedDateTimeZone22.getOffset((-259200000L));
//        org.joda.time.chrono.ZonedChronology zonedChronology27 = org.joda.time.chrono.ZonedChronology.getInstance(chronology13, (org.joda.time.DateTimeZone) cachedDateTimeZone22);
//        org.joda.time.DateTimeField dateTimeField28 = zonedChronology27.secondOfMinute();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(lenientChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 3600000 + "'", int26 == 3600000);
//        org.junit.Assert.assertNotNull(zonedChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) 100, (-1555166));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1555066) + "'", int2 == (-1555066));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.joda.time.Period period1 = org.joda.time.Period.days(0);
        org.joda.time.Period period3 = org.joda.time.Period.days(0);
        org.joda.time.Period period4 = period1.plus((org.joda.time.ReadablePeriod) period3);
        org.joda.time.Period period6 = period4.plusYears(0);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        long long12 = dateTimeZone9.adjustOffset((long) '4', false);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.year();
        org.joda.time.Period period15 = new org.joda.time.Period(0L, periodType8, (org.joda.time.Chronology) iSOChronology13);
        java.lang.String str16 = periodType8.toString();
        org.joda.time.PeriodType periodType17 = periodType8.withMonthsRemoved();
        org.joda.time.Period period18 = period4.withPeriodType(periodType8);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 52L + "'", long12 == 52L);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "PeriodType[YearWeekDay]" + "'", str16.equals("PeriodType[YearWeekDay]"));
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(period18);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) -1);
        org.joda.time.Period period3 = period1.plusYears((int) (byte) 1);
        org.joda.time.Period period5 = period3.minusWeeks((int) (short) 0);
        org.joda.time.DurationFieldType durationFieldType7 = period5.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField8 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType7);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField9 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType7);
        org.joda.time.Period period11 = org.joda.time.Period.days(0);
        org.joda.time.Period period13 = period11.plusWeeks((int) (byte) -1);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.Period period15 = period13.withFields(readablePeriod14);
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.months();
        org.joda.time.PeriodType periodType18 = periodType17.withMonthsRemoved();
        org.joda.time.PeriodType periodType19 = periodType18.withDaysRemoved();
        org.joda.time.Period period20 = new org.joda.time.Period((long) '4', periodType19);
        boolean boolean21 = period15.equals((java.lang.Object) periodType19);
        org.joda.time.PeriodType periodType22 = periodType19.withMonthsRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology24 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology23);
        java.lang.String str25 = lenientChronology24.toString();
        org.joda.time.DateTimeField dateTimeField26 = lenientChronology24.secondOfDay();
        try {
            org.joda.time.Period period27 = new org.joda.time.Period((java.lang.Object) durationFieldType7, periodType22, (org.joda.time.Chronology) lenientChronology24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.DurationFieldType$StandardDurationFieldType");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertNotNull(unsupportedDurationField8);
        org.junit.Assert.assertNotNull(unsupportedDurationField9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(lenientChronology24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "LenientChronology[GregorianChronology[UTC]]" + "'", str25.equals("LenientChronology[GregorianChronology[UTC]]"));
        org.junit.Assert.assertNotNull(dateTimeField26);
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test100");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.dayTime();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.Period period9 = new org.joda.time.Period(10L, periodType7, chronology8);
//        org.joda.time.Period period11 = period9.withSeconds((int) ' ');
//        boolean boolean12 = lenientChronology5.equals((java.lang.Object) ' ');
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
//        boolean boolean15 = dateTimeZone13.isStandardOffset((long) (short) 10);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone13.getShortName((long) (short) 10, locale17);
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
//        long long22 = dateTimeZone13.adjustOffset(10L, false);
//        org.joda.time.Chronology chronology23 = lenientChronology5.withZone(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField24 = lenientChronology5.yearOfCentury();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone29 = new org.joda.time.tz.FixedDateTimeZone("", "PT0S", (int) (byte) 0, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.era();
//        org.joda.time.DurationField durationField32 = gregorianChronology30.halfdays();
//        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology30.clockhourOfDay();
//        boolean boolean34 = fixedDateTimeZone29.equals((java.lang.Object) gregorianChronology30);
//        boolean boolean35 = fixedDateTimeZone29.isFixed();
//        org.joda.time.LocalDateTime localDateTime36 = null;
//        boolean boolean37 = fixedDateTimeZone29.isLocalDateTimeGap(localDateTime36);
//        org.joda.time.chrono.ZonedChronology zonedChronology38 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) lenientChronology5, (org.joda.time.DateTimeZone) fixedDateTimeZone29);
//        org.joda.time.DateTimeField dateTimeField39 = zonedChronology38.dayOfYear();
//        org.joda.time.Chronology chronology40 = zonedChronology38.withUTC();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(lenientChronology5);
//        org.junit.Assert.assertNotNull(periodType7);
//        org.junit.Assert.assertNotNull(period11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "UTC" + "'", str18.equals("UTC"));
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(zonedChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(chronology40);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long3 = dateTimeZone0.adjustOffset((long) '4', false);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(1);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, dateTimeZone6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.era();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        boolean boolean13 = zonedChronology7.equals((java.lang.Object) dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology7.millisOfDay();
        org.joda.time.DateTimeField dateTimeField15 = zonedChronology7.dayOfMonth();
        long long21 = zonedChronology7.getDateTimeMillis((-210865896000000L), 12, 52, 7, 100);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-210865896472900L) + "'", long21 == (-210865896472900L));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 0, (-315670600L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) 10);
        int int30 = offsetDateTimeField28.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField28.getAsText(readablePartial31, 1, locale33);
        org.joda.time.ReadablePartial readablePartial35 = null;
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField28.getAsText(readablePartial35, (int) (byte) 100, locale37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType39);
        long long42 = remainderDateTimeField22.roundHalfFloor((-210865896000000L));
        long long44 = remainderDateTimeField22.roundHalfFloor((-864089903L));
        org.joda.time.DateTimeField dateTimeField45 = remainderDateTimeField22.getWrappedField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 43210 + "'", int30 == 43210);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "100" + "'", str38.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-210863779200000L) + "'", long42 == (-210863779200000L));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-259200000L) + "'", long44 == (-259200000L));
        org.junit.Assert.assertNotNull(dateTimeField45);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test104");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
//        long long7 = dateTimeZone4.adjustOffset((long) '4', false);
//        boolean boolean9 = dateTimeZone4.isStandardOffset((long) '#');
//        java.lang.String str11 = dateTimeZone4.getShortName(1L);
//        org.joda.time.Chronology chronology12 = gregorianChronology2.withZone(dateTimeZone4);
//        org.joda.time.Chronology chronology13 = iSOChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.UTC;
//        long long17 = dateTimeZone14.adjustOffset((long) '4', false);
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours(1);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology18, dateTimeZone20);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone20);
//        long long24 = cachedDateTimeZone22.nextTransition((long) (byte) 100);
//        int int26 = cachedDateTimeZone22.getOffset((-259200000L));
//        org.joda.time.chrono.ZonedChronology zonedChronology27 = org.joda.time.chrono.ZonedChronology.getInstance(chronology13, (org.joda.time.DateTimeZone) cachedDateTimeZone22);
//        int int29 = cachedDateTimeZone22.getStandardOffset(0L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(lenientChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 3600000 + "'", int26 == 3600000);
//        org.junit.Assert.assertNotNull(zonedChronology27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 3600000 + "'", int29 == 3600000);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(5);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "PT0S", (int) (byte) 0, 0);
        int int8 = fixedDateTimeZone6.getOffsetFromLocal((long) 8);
        int int10 = fixedDateTimeZone6.getOffsetFromLocal(51999L);
        long long12 = dateTimeZone1.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone6, 100L);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DurationField durationField14 = gregorianChronology13.eras();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 105L + "'", long12 == 105L);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField3 = gregorianChronology0.halfdays();
        org.joda.time.Period period5 = org.joda.time.Period.weeks((-1));
        int[] intArray7 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period5, (long) (-50));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.PeriodType periodType3 = period2.getPeriodType();
        org.joda.time.Period period4 = period2.normalizedStandard();
        org.joda.time.Period period6 = period4.minusMillis(7);
        java.lang.String str7 = period4.toString();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PT0S" + "'", str7.equals("PT0S"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfCentury();
        org.joda.time.Period period3 = org.joda.time.Period.days(0);
        org.joda.time.Period period5 = org.joda.time.Period.days(0);
        org.joda.time.Period period6 = period3.plus((org.joda.time.ReadablePeriod) period5);
        boolean boolean7 = iSOChronology0.equals((java.lang.Object) period5);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.era();
        org.joda.time.DurationField durationField10 = gregorianChronology8.halfdays();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.clockhourOfDay();
        boolean boolean12 = iSOChronology0.equals((java.lang.Object) gregorianChronology8);
        org.joda.time.DurationField durationField13 = iSOChronology0.minutes();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        java.lang.Number number7 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) 10);
        int int30 = offsetDateTimeField28.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField28.getAsText(readablePartial31, 1, locale33);
        org.joda.time.ReadablePartial readablePartial35 = null;
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField28.getAsText(readablePartial35, (int) (byte) 100, locale37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType39);
        org.joda.time.Period period42 = org.joda.time.Period.days((int) (short) -1);
        int int43 = period42.getMinutes();
        org.joda.time.Period period45 = period42.withMillis((int) (byte) 100);
        org.joda.time.Period period47 = period42.minusYears((int) (byte) 10);
        org.joda.time.Period period49 = period47.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType50 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology51.era();
        org.joda.time.Period period53 = new org.joda.time.Period((java.lang.Object) period47, periodType50, (org.joda.time.Chronology) gregorianChronology51);
        org.joda.time.PeriodType periodType55 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period56 = new org.joda.time.Period((long) (short) 1, periodType55);
        org.joda.time.PeriodType periodType57 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period58 = period56.normalizedStandard(periodType57);
        org.joda.time.DurationFieldType durationFieldType60 = periodType57.getFieldType(1);
        boolean boolean61 = period47.isSupported(durationFieldType60);
        org.joda.time.field.PreciseDurationField preciseDurationField63 = new org.joda.time.field.PreciseDurationField(durationFieldType60, (long) 86409);
        long long64 = preciseDurationField63.getUnitMillis();
        java.lang.String str65 = preciseDurationField63.toString();
        long long66 = preciseDurationField63.getUnitMillis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField67 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, (org.joda.time.DurationField) preciseDurationField63);
        long long70 = unsupportedDateTimeField67.add((-74665144428327L), 8);
        java.util.Locale locale71 = null;
        try {
            int int72 = unsupportedDateTimeField67.getMaximumShortTextLength(locale71);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 43210 + "'", int30 == 43210);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "100" + "'", str38.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(periodType55);
        org.junit.Assert.assertNotNull(periodType57);
        org.junit.Assert.assertNotNull(period58);
        org.junit.Assert.assertNotNull(durationFieldType60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 86409L + "'", long64 == 86409L);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "DurationField[weeks]" + "'", str65.equals("DurationField[weeks]"));
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 86409L + "'", long66 == 86409L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField67);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-74665143737055L) + "'", long70 == (-74665143737055L));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.joda.time.Period period4 = new org.joda.time.Period((-3600000), (-3600000), 5, 2);
        org.joda.time.MutablePeriod mutablePeriod5 = period4.toMutablePeriod();
        org.junit.Assert.assertNotNull(mutablePeriod5);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) 0);
        org.joda.time.Period period3 = period1.minusMinutes((int) (short) 10);
        org.joda.time.Period period5 = period3.withMinutes(97);
        int int6 = period3.getYears();
        org.joda.time.Period period7 = period3.normalizedStandard();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundCeiling(1560629037229L);
        long long27 = remainderDateTimeField22.addWrapField((-4925311L), (int) (short) 0);
        boolean boolean28 = remainderDateTimeField22.isSupported();
        long long31 = remainderDateTimeField22.addWrapField(0L, 10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577664000000L + "'", long24 == 1577664000000L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-4925311L) + "'", long27 == (-4925311L));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-62899200000L) + "'", long31 == (-62899200000L));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundCeiling(1560629037229L);
        long long26 = remainderDateTimeField22.roundCeiling((-112L));
        long long28 = remainderDateTimeField22.roundCeiling(0L);
        try {
            long long31 = remainderDateTimeField22.set(1820100L, "63650");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 63650 for secondOfDay must be in the range [0,3]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577664000000L + "'", long24 == 1577664000000L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 31795200000L + "'", long26 == 31795200000L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31795200000L + "'", long28 == 31795200000L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        boolean boolean2 = dateTimeZone0.isStandardOffset((long) (short) 10);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.lang.String str4 = iSOChronology3.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) (short) 10);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        long long11 = dateTimeZone5.adjustOffset((long) (byte) 10, true);
        org.joda.time.Chronology chronology12 = iSOChronology3.withZone(dateTimeZone5);
        org.joda.time.Chronology chronology13 = iSOChronology3.withUTC();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.UTC;
        java.util.TimeZone timeZone15 = dateTimeZone14.toTimeZone();
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology3, dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology3.halfdayOfDay();
        org.joda.time.DurationField durationField18 = iSOChronology3.eras();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundFloor(0L);
        int int25 = remainderDateTimeField22.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) 'a');
        org.joda.time.Period period3 = period1.minusWeeks(0);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(10L, periodType5, chronology6);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        int int9 = periodType5.indexOf(durationFieldType8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.dayOfYear();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.clockhourOfHalfday();
        boolean boolean13 = periodType5.equals((java.lang.Object) gregorianChronology10);
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period16 = new org.joda.time.Period((long) (short) 1, periodType15);
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period18 = period16.normalizedStandard(periodType17);
        org.joda.time.DurationFieldType durationFieldType20 = periodType17.getFieldType(1);
        int int21 = periodType5.indexOf(durationFieldType20);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField22 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType20);
        org.joda.time.Period period24 = period1.withField(durationFieldType20, (int) (short) 10);
        org.joda.time.Period period26 = org.joda.time.Period.days(0);
        org.joda.time.Period period28 = org.joda.time.Period.days(0);
        org.joda.time.Period period29 = period26.plus((org.joda.time.ReadablePeriod) period28);
        org.joda.time.Weeks weeks30 = period29.toStandardWeeks();
        org.joda.time.Period period31 = period1.minus((org.joda.time.ReadablePeriod) period29);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(unsupportedDurationField22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(weeks30);
        org.junit.Assert.assertNotNull(period31);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("UTC", (-1), 10, (int) (byte) -1, 'a', (int) (short) 100, (int) (byte) -1, 100, false, 10);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder0.addCutover((int) (byte) 0, '4', (int) (short) -1, (int) '#', 0, false, (int) (byte) 0);
        java.io.DataOutput dataOutput21 = null;
        try {
            dateTimeZoneBuilder0.writeTo("DurationField[weeks]", dataOutput21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder19);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = org.joda.time.Period.days(0);
        org.joda.time.Period period5 = org.joda.time.Period.days(0);
        org.joda.time.Period period6 = period3.plus((org.joda.time.ReadablePeriod) period5);
        org.joda.time.Period period7 = period1.withFields((org.joda.time.ReadablePeriod) period3);
        org.joda.time.Period period9 = period3.withDays((int) (short) 100);
        org.joda.time.Period period11 = period9.withMillis(86409);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) 10);
        int int30 = offsetDateTimeField28.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField28.getAsText(readablePartial31, 1, locale33);
        org.joda.time.ReadablePartial readablePartial35 = null;
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField28.getAsText(readablePartial35, (int) (byte) 100, locale37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType39);
        org.joda.time.Period period42 = org.joda.time.Period.days((int) (short) -1);
        int int43 = period42.getMinutes();
        org.joda.time.Period period45 = period42.withMillis((int) (byte) 100);
        org.joda.time.Period period47 = period42.minusYears((int) (byte) 10);
        org.joda.time.Period period49 = period47.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType50 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology51.era();
        org.joda.time.Period period53 = new org.joda.time.Period((java.lang.Object) period47, periodType50, (org.joda.time.Chronology) gregorianChronology51);
        org.joda.time.PeriodType periodType55 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period56 = new org.joda.time.Period((long) (short) 1, periodType55);
        org.joda.time.PeriodType periodType57 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period58 = period56.normalizedStandard(periodType57);
        org.joda.time.DurationFieldType durationFieldType60 = periodType57.getFieldType(1);
        boolean boolean61 = period47.isSupported(durationFieldType60);
        org.joda.time.field.PreciseDurationField preciseDurationField63 = new org.joda.time.field.PreciseDurationField(durationFieldType60, (long) 86409);
        long long64 = preciseDurationField63.getUnitMillis();
        java.lang.String str65 = preciseDurationField63.toString();
        long long66 = preciseDurationField63.getUnitMillis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField67 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, (org.joda.time.DurationField) preciseDurationField63);
        long long70 = unsupportedDateTimeField67.add((long) (-1), 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType71 = unsupportedDateTimeField67.getType();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 43210 + "'", int30 == 43210);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "100" + "'", str38.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(periodType55);
        org.junit.Assert.assertNotNull(periodType57);
        org.junit.Assert.assertNotNull(period58);
        org.junit.Assert.assertNotNull(durationFieldType60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 86409L + "'", long64 == 86409L);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "DurationField[weeks]" + "'", str65.equals("DurationField[weeks]"));
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 86409L + "'", long66 == 86409L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField67);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-1L) + "'", long70 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeFieldType71);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        java.lang.String str2 = lenientChronology1.toString();
        org.joda.time.DurationField durationField3 = lenientChronology1.centuries();
        org.joda.time.DurationField durationField4 = lenientChronology1.centuries();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(lenientChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "LenientChronology[GregorianChronology[UTC]]" + "'", str2.equals("LenientChronology[GregorianChronology[UTC]]"));
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 0, (int) (short) 0, (int) (short) 10, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) -1);
        int int2 = period1.getMinutes();
        org.joda.time.Period period4 = period1.withMillis((int) (byte) 100);
        org.joda.time.Period period6 = period1.minusYears((int) (byte) 10);
        org.joda.time.Period period8 = period6.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.era();
        org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) period6, periodType9, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 1, periodType14);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period17 = period15.normalizedStandard(periodType16);
        org.joda.time.DurationFieldType durationFieldType19 = periodType16.getFieldType(1);
        boolean boolean20 = period6.isSupported(durationFieldType19);
        org.joda.time.field.PreciseDurationField preciseDurationField22 = new org.joda.time.field.PreciseDurationField(durationFieldType19, (long) 86409);
        int int24 = preciseDurationField22.getValue((long) 57609);
        long long27 = preciseDurationField22.getMillis(10, (long) (byte) -1);
        org.joda.time.PeriodType periodType29 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Chronology chronology30 = null;
        org.joda.time.Period period31 = new org.joda.time.Period(10L, periodType29, chronology30);
        org.joda.time.DurationFieldType durationFieldType32 = null;
        int int33 = periodType29.indexOf(durationFieldType32);
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.dayOfYear();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology34.clockhourOfHalfday();
        boolean boolean37 = periodType29.equals((java.lang.Object) gregorianChronology34);
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period40 = new org.joda.time.Period((long) (short) 1, periodType39);
        org.joda.time.PeriodType periodType41 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period42 = period40.normalizedStandard(periodType41);
        org.joda.time.DurationFieldType durationFieldType44 = periodType41.getFieldType(1);
        int int45 = periodType29.indexOf(durationFieldType44);
        org.joda.time.field.DecoratedDurationField decoratedDurationField46 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) preciseDurationField22, durationFieldType44);
        int int49 = decoratedDurationField46.getDifference((long) (-5), 1560629038067L);
        org.joda.time.DurationField durationField50 = decoratedDurationField46.getWrappedField();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 864090L + "'", long27 == 864090L);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(durationFieldType44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-18060954) + "'", int49 == (-18060954));
        org.junit.Assert.assertNotNull(durationField50);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.joda.time.Period period1 = org.joda.time.Period.hours(0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) 10);
        int int30 = offsetDateTimeField28.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField28.getAsText(readablePartial31, 1, locale33);
        org.joda.time.ReadablePartial readablePartial35 = null;
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField28.getAsText(readablePartial35, (int) (byte) 100, locale37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType39);
        long long42 = remainderDateTimeField22.roundHalfFloor((-210865896000000L));
        long long45 = remainderDateTimeField22.addWrapField((long) 5, 52);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 43210 + "'", int30 == 43210);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "100" + "'", str38.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-210863779200000L) + "'", long42 == (-210863779200000L));
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 5L + "'", long45 == 5L);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) 10);
        int int30 = offsetDateTimeField28.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField28.getAsText(readablePartial31, 1, locale33);
        org.joda.time.ReadablePartial readablePartial35 = null;
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField28.getAsText(readablePartial35, (int) (byte) 100, locale37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType39);
        org.joda.time.Period period42 = org.joda.time.Period.days((int) (short) -1);
        int int43 = period42.getMinutes();
        org.joda.time.Period period45 = period42.withMillis((int) (byte) 100);
        org.joda.time.Period period47 = period42.minusYears((int) (byte) 10);
        org.joda.time.Period period49 = period47.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType50 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology51.era();
        org.joda.time.Period period53 = new org.joda.time.Period((java.lang.Object) period47, periodType50, (org.joda.time.Chronology) gregorianChronology51);
        org.joda.time.PeriodType periodType55 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period56 = new org.joda.time.Period((long) (short) 1, periodType55);
        org.joda.time.PeriodType periodType57 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period58 = period56.normalizedStandard(periodType57);
        org.joda.time.DurationFieldType durationFieldType60 = periodType57.getFieldType(1);
        boolean boolean61 = period47.isSupported(durationFieldType60);
        org.joda.time.field.PreciseDurationField preciseDurationField63 = new org.joda.time.field.PreciseDurationField(durationFieldType60, (long) 86409);
        long long64 = preciseDurationField63.getUnitMillis();
        java.lang.String str65 = preciseDurationField63.toString();
        long long66 = preciseDurationField63.getUnitMillis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField67 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, (org.joda.time.DurationField) preciseDurationField63);
        org.joda.time.DateTimeFieldType dateTimeFieldType68 = unsupportedDateTimeField67.getType();
        java.lang.String str69 = unsupportedDateTimeField67.getName();
        java.lang.String str70 = unsupportedDateTimeField67.getName();
        java.util.Locale locale73 = null;
        try {
            long long74 = unsupportedDateTimeField67.set(0L, "UTC", locale73);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 43210 + "'", int30 == 43210);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "100" + "'", str38.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(periodType55);
        org.junit.Assert.assertNotNull(periodType57);
        org.junit.Assert.assertNotNull(period58);
        org.junit.Assert.assertNotNull(durationFieldType60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 86409L + "'", long64 == 86409L);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "DurationField[weeks]" + "'", str65.equals("DurationField[weeks]"));
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 86409L + "'", long66 == 86409L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField67);
        org.junit.Assert.assertNotNull(dateTimeFieldType68);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "secondOfDay" + "'", str69.equals("secondOfDay"));
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "secondOfDay" + "'", str70.equals("secondOfDay"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) 10);
        int int30 = offsetDateTimeField28.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField28.getAsText(readablePartial31, 1, locale33);
        org.joda.time.ReadablePartial readablePartial35 = null;
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField28.getAsText(readablePartial35, (int) (byte) 100, locale37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType39);
        long long42 = remainderDateTimeField22.roundHalfFloor(3155760001000L);
        int int43 = remainderDateTimeField22.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 43210 + "'", int30 == 43210);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "100" + "'", str38.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 3155587200000L + "'", long42 == 3155587200000L);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyear();
        org.joda.time.DurationField durationField2 = iSOChronology0.months();
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.joda.time.Period period1 = org.joda.time.Period.days(0);
        org.joda.time.Period period3 = period1.plusMinutes(86409);
        org.joda.time.Hours hours4 = period1.toStandardHours();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(hours4);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) 10);
        int int30 = offsetDateTimeField28.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField28.getAsText(readablePartial31, 1, locale33);
        org.joda.time.ReadablePartial readablePartial35 = null;
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField28.getAsText(readablePartial35, (int) (byte) 100, locale37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType39);
        long long42 = remainderDateTimeField22.roundHalfFloor((-210865896000000L));
        long long44 = remainderDateTimeField22.roundHalfFloor((-864089903L));
        int int46 = remainderDateTimeField22.get((long) 43210);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 43210 + "'", int30 == 43210);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "100" + "'", str38.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-210863779200000L) + "'", long42 == (-210863779200000L));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-259200000L) + "'", long44 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 3 + "'", int46 == 3);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) 10);
        int int30 = offsetDateTimeField28.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField28.getAsText(readablePartial31, 1, locale33);
        org.joda.time.ReadablePartial readablePartial35 = null;
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField28.getAsText(readablePartial35, (int) (byte) 100, locale37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType39);
        org.joda.time.Period period42 = org.joda.time.Period.days((int) (short) -1);
        int int43 = period42.getMinutes();
        org.joda.time.Period period45 = period42.withMillis((int) (byte) 100);
        org.joda.time.Period period47 = period42.minusYears((int) (byte) 10);
        org.joda.time.Period period49 = period47.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType50 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology51.era();
        org.joda.time.Period period53 = new org.joda.time.Period((java.lang.Object) period47, periodType50, (org.joda.time.Chronology) gregorianChronology51);
        org.joda.time.PeriodType periodType55 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period56 = new org.joda.time.Period((long) (short) 1, periodType55);
        org.joda.time.PeriodType periodType57 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period58 = period56.normalizedStandard(periodType57);
        org.joda.time.DurationFieldType durationFieldType60 = periodType57.getFieldType(1);
        boolean boolean61 = period47.isSupported(durationFieldType60);
        org.joda.time.field.PreciseDurationField preciseDurationField63 = new org.joda.time.field.PreciseDurationField(durationFieldType60, (long) 86409);
        long long64 = preciseDurationField63.getUnitMillis();
        java.lang.String str65 = preciseDurationField63.toString();
        long long66 = preciseDurationField63.getUnitMillis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField67 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, (org.joda.time.DurationField) preciseDurationField63);
        org.joda.time.DurationField durationField68 = unsupportedDateTimeField67.getDurationField();
        long long71 = unsupportedDateTimeField67.add(86409L, (-72645000095627L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 43210 + "'", int30 == 43210);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "100" + "'", str38.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(periodType55);
        org.junit.Assert.assertNotNull(periodType57);
        org.junit.Assert.assertNotNull(period58);
        org.junit.Assert.assertNotNull(durationFieldType60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 86409L + "'", long64 == 86409L);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "DurationField[weeks]" + "'", str65.equals("DurationField[weeks]"));
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 86409L + "'", long66 == 86409L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField67);
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-6277181813262947034L) + "'", long71 == (-6277181813262947034L));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) -1);
        int int2 = period1.getMinutes();
        org.joda.time.Period period4 = period1.withMillis((int) (byte) 100);
        org.joda.time.Period period6 = period1.minusYears((int) (byte) 10);
        org.joda.time.Period period8 = period6.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.era();
        org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) period6, periodType9, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.secondOfMinute();
        org.joda.time.ReadablePartial readablePartial14 = null;
        try {
            long long16 = gregorianChronology10.set(readablePartial14, 2441000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long3 = dateTimeZone0.adjustOffset((long) '4', false);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(1);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, dateTimeZone6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.era();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        boolean boolean13 = zonedChronology7.equals((java.lang.Object) dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology7.millisOfDay();
        org.joda.time.Period period16 = org.joda.time.Period.days(0);
        org.joda.time.Period period18 = period16.plusWeeks((int) (byte) -1);
        org.joda.time.Period period20 = period18.withHours((int) '4');
        org.joda.time.Period period22 = period20.plusMillis((int) '4');
        int[] intArray25 = zonedChronology7.get((org.joda.time.ReadablePeriod) period20, (long) 100, (long) 8);
        java.lang.String str26 = zonedChronology7.toString();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "ZonedChronology[ISOChronology[UTC], +01:00]" + "'", str26.equals("ZonedChronology[ISOChronology[UTC], +01:00]"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period2 = new org.joda.time.Period(2440588L, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DurationField durationField4 = lenientChronology3.weekyears();
        java.lang.String str5 = lenientChronology3.toString();
        org.joda.time.DateTimeField dateTimeField6 = lenientChronology3.centuryOfEra();
        java.lang.Class<?> wildcardClass7 = dateTimeField6.getClass();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(lenientChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "LenientChronology[GregorianChronology[UTC]]" + "'", str5.equals("LenientChronology[GregorianChronology[UTC]]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("5", "", (int) '4', (int) (short) 10);
        long long6 = fixedDateTimeZone4.previousTransition((long) 14832);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 14832L + "'", long6 == 14832L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("org.joda.time.IllegalFieldValueException: hi!: Value \"\" for hi! is not supported", "P-10Y-1D", (int) (short) -1, 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.joda.time.Period period1 = org.joda.time.Period.days(0);
        org.joda.time.Period period3 = period1.plusWeeks((int) (byte) -1);
        org.joda.time.Period period5 = period3.withHours((int) '4');
        org.joda.time.Period period7 = period5.plusMillis((int) '4');
        org.joda.time.Period period9 = period5.minusYears((int) 'a');
        org.joda.time.Period period11 = period5.withWeeks(0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.DurationFieldType durationFieldType2 = null;
        boolean boolean3 = period1.isSupported(durationFieldType2);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.era();
        org.joda.time.DurationField durationField6 = gregorianChronology4.halfdays();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology4.dayOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology9 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(10L, periodType11, chronology12);
        org.joda.time.Period period15 = period13.withSeconds((int) ' ');
        boolean boolean16 = lenientChronology9.equals((java.lang.Object) ' ');
        boolean boolean17 = period1.equals((java.lang.Object) lenientChronology9);
        org.joda.time.DateTimeField dateTimeField18 = lenientChronology9.era();
        org.joda.time.DateTimeField dateTimeField19 = lenientChronology9.dayOfWeek();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(lenientChronology9);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(10L, periodType1, chronology2);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        int int5 = periodType1.indexOf(durationFieldType4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.dayOfYear();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.clockhourOfHalfday();
        boolean boolean9 = periodType1.equals((java.lang.Object) gregorianChronology6);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) 1, periodType11);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period14 = period12.normalizedStandard(periodType13);
        org.joda.time.DurationFieldType durationFieldType16 = periodType13.getFieldType(1);
        int int17 = periodType1.indexOf(durationFieldType16);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField18 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType16);
        java.lang.String str19 = unsupportedDurationField18.getName();
        boolean boolean20 = unsupportedDurationField18.isSupported();
        org.joda.time.DurationFieldType durationFieldType21 = unsupportedDurationField18.getType();
        try {
            long long23 = unsupportedDurationField18.getValueAsLong(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weeks field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(durationFieldType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(unsupportedDurationField18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "weeks" + "'", str19.equals("weeks"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(durationFieldType21);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = gregorianChronology0.add(readablePeriod3, 1L, 100);
        org.joda.time.DurationField durationField7 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField8 = gregorianChronology0.years();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test141");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        long long5 = dateTimeZone2.adjustOffset((long) '4', false);
//        boolean boolean7 = dateTimeZone2.isStandardOffset((long) '#');
//        java.lang.String str9 = dateTimeZone2.getShortName(1L);
//        org.joda.time.Chronology chronology10 = gregorianChronology0.withZone(dateTimeZone2);
//        int int12 = dateTimeZone2.getOffsetFromLocal((long) 0);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(lenientChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withHoursRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 100, (int) (byte) 0, (int) '4', (int) (byte) 10);
        org.joda.time.Period period6 = period4.minusDays(1);
        org.joda.time.Period period8 = period6.plusMinutes((int) (byte) 100);
        org.joda.time.Period period10 = org.joda.time.Period.days(0);
        org.joda.time.Period period12 = period10.plusWeeks((int) (byte) -1);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.Period period14 = period12.withFields(readablePeriod13);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.months();
        org.joda.time.PeriodType periodType17 = periodType16.withMonthsRemoved();
        org.joda.time.PeriodType periodType18 = periodType17.withDaysRemoved();
        org.joda.time.Period period19 = new org.joda.time.Period((long) '4', periodType18);
        boolean boolean20 = period14.equals((java.lang.Object) periodType18);
        org.joda.time.Period period21 = period6.normalizedStandard(periodType18);
        org.joda.time.format.PeriodFormatter periodFormatter22 = null;
        java.lang.String str23 = period6.toString(periodFormatter22);
        org.joda.time.Period period25 = period6.plusMinutes(8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "P-1DT100H52.010S" + "'", str23.equals("P-1DT100H52.010S"));
        org.junit.Assert.assertNotNull(period25);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) -1);
        int int2 = period1.getMinutes();
        org.joda.time.Period period4 = period1.withMillis((int) (byte) 100);
        org.joda.time.Period period6 = period1.minusYears((int) (byte) 10);
        org.joda.time.Period period8 = period6.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.era();
        org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) period6, periodType9, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 1, periodType14);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period17 = period15.normalizedStandard(periodType16);
        org.joda.time.DurationFieldType durationFieldType19 = periodType16.getFieldType(1);
        boolean boolean20 = period6.isSupported(durationFieldType19);
        org.joda.time.field.PreciseDurationField preciseDurationField22 = new org.joda.time.field.PreciseDurationField(durationFieldType19, (long) 86409);
        long long25 = preciseDurationField22.getDifferenceAsLong((-3653619L), 6045588L);
        long long28 = preciseDurationField22.getMillis((long) (-315705600), 0L);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-112L) + "'", long25 == (-112L));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-27279805190400L) + "'", long28 == (-27279805190400L));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) -1);
        int int2 = period1.getMinutes();
        org.joda.time.Period period4 = period1.withMillis((int) (byte) 100);
        org.joda.time.Period period6 = period1.minusYears((int) (byte) 10);
        org.joda.time.Period period8 = period6.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.era();
        org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) period6, periodType9, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 1, periodType14);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period17 = period15.normalizedStandard(periodType16);
        org.joda.time.DurationFieldType durationFieldType19 = periodType16.getFieldType(1);
        boolean boolean20 = period6.isSupported(durationFieldType19);
        org.joda.time.field.PreciseDurationField preciseDurationField22 = new org.joda.time.field.PreciseDurationField(durationFieldType19, (long) 86409);
        long long23 = preciseDurationField22.getUnitMillis();
        long long24 = preciseDurationField22.getUnitMillis();
        org.joda.time.Period period33 = new org.joda.time.Period(10, (int) (short) 100, (int) (byte) 1, 28, 35, 0, 56999, 0);
        boolean boolean34 = preciseDurationField22.equals((java.lang.Object) 56999);
        long long35 = preciseDurationField22.getUnitMillis();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 86409L + "'", long23 == 86409L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 86409L + "'", long24 == 86409L);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 86409L + "'", long35 == 86409L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundHalfFloor(1820100L);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = remainderDateTimeField22.getType();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.joda.time.Period period1 = org.joda.time.Period.months(57);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.PeriodType periodType3 = period2.getPeriodType();
        org.joda.time.Hours hours4 = period2.toStandardHours();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) period2);
        org.joda.time.MutablePeriod mutablePeriod6 = period2.toMutablePeriod();
        org.joda.time.Period period8 = org.joda.time.Period.weeks((int) (byte) 0);
        org.joda.time.Period period10 = period8.minusMinutes((int) (short) 10);
        org.joda.time.Period period12 = period10.withMinutes(97);
        int int13 = period10.getYears();
        org.joda.time.Period period14 = period2.withFields((org.joda.time.ReadablePeriod) period10);
        org.joda.time.Period period16 = org.joda.time.Period.days((int) (short) -1);
        org.joda.time.Period period18 = period16.plusYears((int) (byte) 1);
        org.joda.time.Period period20 = period18.minusWeeks((int) (short) 0);
        org.joda.time.DurationFieldType durationFieldType22 = period20.getFieldType(0);
        org.joda.time.Period period24 = period14.withField(durationFieldType22, 14832);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(hours4);
        org.junit.Assert.assertNotNull(mutablePeriod6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(period24);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException2.prependMessage("hi!");
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        java.lang.Number number6 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-97) + "'", int1 == (-97));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.joda.time.Period period1 = org.joda.time.Period.years(35);
        int int2 = period1.getWeeks();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long3 = dateTimeZone0.adjustOffset((long) '4', false);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(1);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, dateTimeZone6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.era();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        boolean boolean13 = zonedChronology7.equals((java.lang.Object) dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology7.millisOfDay();
        org.joda.time.Period period16 = org.joda.time.Period.days(0);
        org.joda.time.Period period18 = period16.plusWeeks((int) (byte) -1);
        org.joda.time.Period period20 = period18.withHours((int) '4');
        org.joda.time.Period period22 = period20.plusMillis((int) '4');
        int[] intArray25 = zonedChronology7.get((org.joda.time.ReadablePeriod) period20, (long) 100, (long) 8);
        int int26 = period20.getWeeks();
        org.joda.time.format.PeriodFormatter periodFormatter27 = null;
        java.lang.String str28 = period20.toString(periodFormatter27);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "P-1WT52H" + "'", str28.equals("P-1WT52H"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) -1);
        int int2 = period1.getMinutes();
        org.joda.time.Period period4 = period1.withMillis((int) (byte) 100);
        org.joda.time.Period period6 = period1.minusYears((int) (byte) 10);
        org.joda.time.Period period8 = period6.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.era();
        org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) period6, periodType9, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 1, periodType14);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period17 = period15.normalizedStandard(periodType16);
        org.joda.time.DurationFieldType durationFieldType19 = periodType16.getFieldType(1);
        boolean boolean20 = period6.isSupported(durationFieldType19);
        org.joda.time.field.PreciseDurationField preciseDurationField22 = new org.joda.time.field.PreciseDurationField(durationFieldType19, (long) 86409);
        int int24 = preciseDurationField22.getValue((long) 57609);
        long long27 = preciseDurationField22.getMillis(10, (long) (byte) -1);
        org.joda.time.PeriodType periodType29 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Chronology chronology30 = null;
        org.joda.time.Period period31 = new org.joda.time.Period(10L, periodType29, chronology30);
        org.joda.time.DurationFieldType durationFieldType32 = null;
        int int33 = periodType29.indexOf(durationFieldType32);
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.dayOfYear();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology34.clockhourOfHalfday();
        boolean boolean37 = periodType29.equals((java.lang.Object) gregorianChronology34);
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period40 = new org.joda.time.Period((long) (short) 1, periodType39);
        org.joda.time.PeriodType periodType41 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period42 = period40.normalizedStandard(periodType41);
        org.joda.time.DurationFieldType durationFieldType44 = periodType41.getFieldType(1);
        int int45 = periodType29.indexOf(durationFieldType44);
        org.joda.time.field.DecoratedDurationField decoratedDurationField46 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) preciseDurationField22, durationFieldType44);
        long long49 = decoratedDurationField46.getDifferenceAsLong(86409L, (long) (-349200000));
        long long52 = decoratedDurationField46.getMillis(28, (long) 52);
        long long55 = decoratedDurationField46.getDifferenceAsLong(0L, (-5000L));
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 864090L + "'", long27 == 864090L);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(durationFieldType44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 4042L + "'", long49 == 4042L);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 2419452L + "'", long52 == 2419452L);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.joda.time.Period period1 = org.joda.time.Period.days(0);
        org.joda.time.Period period3 = period1.plusWeeks((int) (byte) -1);
        org.joda.time.Period period5 = period1.minusHours((int) (short) 10);
        int int6 = period5.getYears();
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period5.toDurationFrom(readableInstant7);
        org.joda.time.Period period9 = period5.negated();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException2.prependMessage("hi!");
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        java.lang.Throwable[] throwableArray6 = illegalFieldValueException2.getSuppressed();
        java.lang.Throwable[] throwableArray7 = illegalFieldValueException2.getSuppressed();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (byte) 10);
        int int13 = offsetDateTimeField11.get((-210866068800000L));
        int int14 = offsetDateTimeField11.getMinimumValue();
        int int17 = offsetDateTimeField11.getDifference((-315705600000L), (long) 'a');
        boolean boolean19 = offsetDateTimeField11.isLeap((long) 35);
        java.util.Locale locale21 = null;
        java.lang.String str22 = offsetDateTimeField11.getAsText(35L, locale21);
        org.joda.time.DurationField durationField23 = offsetDateTimeField11.getRangeDurationField();
        boolean boolean24 = org.joda.time.field.FieldUtils.equals((java.lang.Object) illegalFieldValueException2, (java.lang.Object) offsetDateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 43210 + "'", int13 == 43210);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-315705600) + "'", int17 == (-315705600));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10" + "'", str22.equals("10"));
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.joda.time.Period period1 = org.joda.time.Period.days(0);
        org.joda.time.Period period3 = period1.plusWeeks((int) (byte) -1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Period period5 = period3.withFields(readablePeriod4);
        org.joda.time.Seconds seconds6 = period5.toStandardSeconds();
        org.joda.time.PeriodType periodType7 = period5.getPeriodType();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(seconds6);
        org.junit.Assert.assertNotNull(periodType7);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) 10);
        int int30 = offsetDateTimeField28.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField28.getAsText(readablePartial31, 1, locale33);
        org.joda.time.ReadablePartial readablePartial35 = null;
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField28.getAsText(readablePartial35, (int) (byte) 100, locale37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType39);
        org.joda.time.Period period42 = org.joda.time.Period.days((int) (short) -1);
        int int43 = period42.getMinutes();
        org.joda.time.Period period45 = period42.withMillis((int) (byte) 100);
        org.joda.time.Period period47 = period42.minusYears((int) (byte) 10);
        org.joda.time.Period period49 = period47.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType50 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology51.era();
        org.joda.time.Period period53 = new org.joda.time.Period((java.lang.Object) period47, periodType50, (org.joda.time.Chronology) gregorianChronology51);
        org.joda.time.PeriodType periodType55 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period56 = new org.joda.time.Period((long) (short) 1, periodType55);
        org.joda.time.PeriodType periodType57 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period58 = period56.normalizedStandard(periodType57);
        org.joda.time.DurationFieldType durationFieldType60 = periodType57.getFieldType(1);
        boolean boolean61 = period47.isSupported(durationFieldType60);
        org.joda.time.field.PreciseDurationField preciseDurationField63 = new org.joda.time.field.PreciseDurationField(durationFieldType60, (long) 86409);
        long long64 = preciseDurationField63.getUnitMillis();
        java.lang.String str65 = preciseDurationField63.toString();
        long long66 = preciseDurationField63.getUnitMillis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField67 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, (org.joda.time.DurationField) preciseDurationField63);
        long long70 = preciseDurationField63.getValueAsLong(56999L, (long) (byte) -1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 43210 + "'", int30 == 43210);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "100" + "'", str38.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(periodType55);
        org.junit.Assert.assertNotNull(periodType57);
        org.junit.Assert.assertNotNull(period58);
        org.junit.Assert.assertNotNull(durationFieldType60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 86409L + "'", long64 == 86409L);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "DurationField[weeks]" + "'", str65.equals("DurationField[weeks]"));
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 86409L + "'", long66 == 86409L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField67);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 0L + "'", long70 == 0L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 10);
        int int5 = offsetDateTimeField3.get((-210866068800000L));
        org.joda.time.DurationField durationField6 = offsetDateTimeField3.getLeapDurationField();
        java.util.Locale locale7 = null;
        int int8 = offsetDateTimeField3.getMaximumTextLength(locale7);
        int int10 = offsetDateTimeField3.getMinimumValue((long) (-100));
        long long13 = offsetDateTimeField3.getDifferenceAsLong((-315619200000L), 32010L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 43210 + "'", int5 == 43210);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 5 + "'", int8 == 5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-315619232L) + "'", long13 == (-315619232L));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(10L, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withSeconds((int) ' ');
        org.joda.time.Period period6 = period5.toPeriod();
        org.joda.time.Duration duration7 = period5.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration7, readableInstant8);
        org.joda.time.Period period11 = org.joda.time.Period.millis((int) (short) 100);
        org.joda.time.MutablePeriod mutablePeriod12 = period11.toMutablePeriod();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period16 = new org.joda.time.Period((long) (short) 1, periodType15);
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period18 = period16.normalizedStandard(periodType17);
        org.joda.time.DurationFieldType durationFieldType20 = periodType17.getFieldType(1);
        int int21 = periodType13.indexOf(durationFieldType20);
        boolean boolean22 = period11.isSupported(durationFieldType20);
        org.joda.time.Period period24 = period9.withField(durationFieldType20, (int) (byte) 100);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(mutablePeriod12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(period24);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) 10);
        int int30 = offsetDateTimeField28.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField28.getAsText(readablePartial31, 1, locale33);
        org.joda.time.ReadablePartial readablePartial35 = null;
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField28.getAsText(readablePartial35, (int) (byte) 100, locale37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType39);
        org.joda.time.Period period42 = org.joda.time.Period.days((int) (short) -1);
        int int43 = period42.getMinutes();
        org.joda.time.Period period45 = period42.withMillis((int) (byte) 100);
        org.joda.time.Period period47 = period42.minusYears((int) (byte) 10);
        org.joda.time.Period period49 = period47.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType50 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology51.era();
        org.joda.time.Period period53 = new org.joda.time.Period((java.lang.Object) period47, periodType50, (org.joda.time.Chronology) gregorianChronology51);
        org.joda.time.PeriodType periodType55 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period56 = new org.joda.time.Period((long) (short) 1, periodType55);
        org.joda.time.PeriodType periodType57 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period58 = period56.normalizedStandard(periodType57);
        org.joda.time.DurationFieldType durationFieldType60 = periodType57.getFieldType(1);
        boolean boolean61 = period47.isSupported(durationFieldType60);
        org.joda.time.field.PreciseDurationField preciseDurationField63 = new org.joda.time.field.PreciseDurationField(durationFieldType60, (long) 86409);
        long long64 = preciseDurationField63.getUnitMillis();
        java.lang.String str65 = preciseDurationField63.toString();
        long long66 = preciseDurationField63.getUnitMillis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField67 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, (org.joda.time.DurationField) preciseDurationField63);
        long long70 = unsupportedDateTimeField67.add((long) (-1), 0);
        long long73 = unsupportedDateTimeField67.add((long) (-1), 0);
        org.joda.time.DurationField durationField74 = unsupportedDateTimeField67.getDurationField();
        org.joda.time.DurationField durationField75 = unsupportedDateTimeField67.getDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 43210 + "'", int30 == 43210);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "100" + "'", str38.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(periodType55);
        org.junit.Assert.assertNotNull(periodType57);
        org.junit.Assert.assertNotNull(period58);
        org.junit.Assert.assertNotNull(durationFieldType60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 86409L + "'", long64 == 86409L);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "DurationField[weeks]" + "'", str65.equals("DurationField[weeks]"));
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 86409L + "'", long66 == 86409L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField67);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-1L) + "'", long70 == (-1L));
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-1L) + "'", long73 == (-1L));
        org.junit.Assert.assertNotNull(durationField74);
        org.junit.Assert.assertNotNull(durationField75);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        boolean boolean4 = jodaTimePermission1.equals((java.lang.Object) 52L);
        java.security.PermissionCollection permissionCollection5 = jodaTimePermission1.newPermissionCollection();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        int int12 = offsetDateTimeField9.getMinimumValue();
        long long14 = offsetDateTimeField9.roundHalfEven((long) (byte) 100);
        long long16 = offsetDateTimeField9.remainder((-60266045221990L));
        boolean boolean17 = jodaTimePermission1.equals((java.lang.Object) offsetDateTimeField9);
        int int19 = offsetDateTimeField9.getMaximumValue((long) (byte) 10);
        java.util.Locale locale20 = null;
        int int21 = offsetDateTimeField9.getMaximumShortTextLength(locale20);
        long long23 = offsetDateTimeField9.roundCeiling(2440588L);
        java.lang.String str25 = offsetDateTimeField9.getAsText(0L);
        int int26 = offsetDateTimeField9.getMinimumValue();
        long long28 = offsetDateTimeField9.remainder(3000L);
        java.lang.String str30 = offsetDateTimeField9.getAsText((-425547043199965L));
        long long32 = offsetDateTimeField9.roundHalfFloor(3024415L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(permissionCollection5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 86409 + "'", int19 == 86409);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 5 + "'", int21 == 5);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2441000L + "'", long23 == 2441000L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10" + "'", str30.equals("10"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 3024000L + "'", long32 == 3024000L);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long3 = dateTimeZone0.adjustOffset((long) '4', false);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(1);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, dateTimeZone6);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        java.lang.String str10 = cachedDateTimeZone8.getNameKey((long) 5);
        java.lang.String str12 = cachedDateTimeZone8.getNameKey((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone13 = cachedDateTimeZone8.getUncachedZone();
        int int15 = cachedDateTimeZone8.getStandardOffset((long) (short) 1);
        long long17 = cachedDateTimeZone8.nextTransition((long) 7);
        boolean boolean18 = cachedDateTimeZone8.isFixed();
        long long20 = cachedDateTimeZone8.previousTransition((-2999L));
        boolean boolean21 = cachedDateTimeZone8.isFixed();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3600000 + "'", int15 == 3600000);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 7L + "'", long17 == 7L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-2999L) + "'", long20 == (-2999L));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.PeriodType periodType3 = period2.getPeriodType();
        org.joda.time.Hours hours4 = period2.toStandardHours();
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) period2);
        org.joda.time.Period period7 = period5.plusWeeks((-3600000));
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.months();
        org.joda.time.PeriodType periodType9 = periodType8.withMonthsRemoved();
        org.joda.time.PeriodType periodType10 = periodType9.withDaysRemoved();
        org.joda.time.PeriodType periodType11 = periodType9.withMinutesRemoved();
        org.joda.time.Period period12 = period7.normalizedStandard(periodType11);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(hours4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withDaysRemoved();
        try {
            org.joda.time.Period period5 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("57610", "", 10, (int) (byte) 10);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) -1);
        int int2 = period1.getMinutes();
        org.joda.time.Period period4 = period1.withMillis((int) (byte) 100);
        org.joda.time.Period period6 = period1.minusYears((int) (byte) 10);
        org.joda.time.Period period8 = period6.plusYears(0);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Duration duration10 = period8.toDurationTo(readableInstant9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.Period period12 = period8.withFields(readablePeriod11);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(duration10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("UTC", (-1), 10, (int) (byte) -1, 'a', (int) (short) 100, (int) (byte) -1, 100, false, 10);
        org.joda.time.DateTimeZone dateTimeZone14 = dateTimeZoneBuilder11.toDateTimeZone("57610", true);
        java.util.TimeZone timeZone15 = dateTimeZone14.toTimeZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(3024000L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3024000 + "'", int1 == 3024000);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.Period period4 = period2.minusDays((int) (short) 100);
        int int5 = period2.getYears();
        org.joda.time.Period period7 = period2.plusMillis(52);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType9 = periodType8.withYearsRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology10);
        java.lang.String str12 = lenientChronology11.toString();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period2, periodType9, (org.joda.time.Chronology) lenientChronology11);
        org.joda.time.PeriodType periodType14 = periodType9.withMonthsRemoved();
        int int15 = periodType14.size();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "LenientChronology[GregorianChronology[UTC]]" + "'", str12.equals("LenientChronology[GregorianChronology[UTC]]"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 100, (int) (byte) 0, (int) '4', (int) (byte) 10);
        org.joda.time.Period period5 = period4.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod6 = period5.toMutablePeriod();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(mutablePeriod6);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long3 = dateTimeZone0.adjustOffset((long) '4', false);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(1);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, dateTimeZone6);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        long long10 = cachedDateTimeZone8.nextTransition((long) (byte) 100);
        long long12 = cachedDateTimeZone8.nextTransition((-80976232428327L));
        boolean boolean13 = cachedDateTimeZone8.isFixed();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-80976232428327L) + "'", long12 == (-80976232428327L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test172");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 10);
//        int int5 = offsetDateTimeField3.get((-210866068800000L));
//        java.lang.String str7 = offsetDateTimeField3.getAsText(6040588L);
//        org.joda.time.DurationField durationField8 = offsetDateTimeField3.getLeapDurationField();
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.chrono.LenientChronology lenientChronology12 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology11);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
//        long long16 = dateTimeZone13.adjustOffset((long) '4', false);
//        boolean boolean18 = dateTimeZone13.isStandardOffset((long) '#');
//        java.lang.String str20 = dateTimeZone13.getShortName(1L);
//        org.joda.time.Chronology chronology21 = gregorianChronology11.withZone(dateTimeZone13);
//        org.joda.time.chrono.LenientChronology lenientChronology22 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology11);
//        org.joda.time.Period period24 = org.joda.time.Period.weeks((-1));
//        org.joda.time.Period period26 = period24.withHours((int) ' ');
//        org.joda.time.Seconds seconds27 = period26.toStandardSeconds();
//        int[] intArray29 = lenientChronology22.get((org.joda.time.ReadablePeriod) period26, 0L);
//        try {
//            int[] intArray31 = offsetDateTimeField3.addWrapPartial(readablePartial9, 57, intArray29, 2);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 57");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 43210 + "'", int5 == 43210);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "6050" + "'", str7.equals("6050"));
//        org.junit.Assert.assertNull(durationField8);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(lenientChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 52L + "'", long16 == 52L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(lenientChronology22);
//        org.junit.Assert.assertNotNull(period24);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertNotNull(seconds27);
//        org.junit.Assert.assertNotNull(intArray29);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.months();
        org.joda.time.PeriodType periodType3 = periodType2.withMonthsRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withDaysRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType4);
        int int6 = period5.getWeeks();
        org.joda.time.Seconds seconds7 = period5.toStandardSeconds();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(seconds7);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) -1);
        org.joda.time.Period period3 = period1.plusYears((int) (byte) 1);
        org.joda.time.Period period5 = period3.minusWeeks((int) (short) 0);
        org.joda.time.DurationFieldType durationFieldType7 = period5.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField8 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType7);
        java.lang.String str9 = unsupportedDurationField8.getName();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertNotNull(unsupportedDurationField8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "years" + "'", str9.equals("years"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) 10);
        int int30 = offsetDateTimeField28.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField28.getAsText(readablePartial31, 1, locale33);
        org.joda.time.ReadablePartial readablePartial35 = null;
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField28.getAsText(readablePartial35, (int) (byte) 100, locale37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType39);
        long long43 = dividedDateTimeField40.addWrapField((long) (short) 0, 43210);
        int int45 = dividedDateTimeField40.get((-17999903L));
        org.joda.time.ReadablePartial readablePartial46 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology47.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, (int) (byte) 10);
        int int52 = offsetDateTimeField50.get((-210866068800000L));
        int int53 = offsetDateTimeField50.getMinimumValue();
        long long55 = offsetDateTimeField50.roundHalfEven((long) (byte) 100);
        long long58 = offsetDateTimeField50.getDifferenceAsLong(1560629037229L, (long) (short) 100);
        org.joda.time.ReadablePartial readablePartial59 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology60 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField61 = gregorianChronology60.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField63 = new org.joda.time.field.OffsetDateTimeField(dateTimeField61, (int) (byte) 10);
        int int65 = offsetDateTimeField63.get((-210866068800000L));
        long long67 = offsetDateTimeField63.roundHalfFloor(0L);
        boolean boolean69 = offsetDateTimeField63.isLeap((long) 8);
        org.joda.time.ReadablePartial readablePartial70 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology72 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField73 = gregorianChronology72.dayOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology74 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology72);
        org.joda.time.Period period76 = org.joda.time.Period.days((int) (short) -1);
        int int77 = period76.getMinutes();
        org.joda.time.Period period79 = period76.withMillis((int) (byte) 100);
        org.joda.time.Period period81 = period76.minusYears((int) (byte) 10);
        int[] intArray83 = lenientChronology74.get((org.joda.time.ReadablePeriod) period76, (long) (short) 0);
        int[] intArray85 = offsetDateTimeField63.addWrapPartial(readablePartial70, (int) (short) 100, intArray83, (int) (byte) 0);
        int int86 = offsetDateTimeField50.getMaximumValue(readablePartial59, intArray83);
        int int87 = dividedDateTimeField40.getMaximumValue(readablePartial46, intArray83);
        long long90 = dividedDateTimeField40.add(3024415L, (-5));
        int int91 = dividedDateTimeField40.getDivisor();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 43210 + "'", int30 == 43210);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "100" + "'", str38.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-252201600000L) + "'", long43 == (-252201600000L));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 17 + "'", int45 == 17);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 43210 + "'", int52 == 43210);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 10 + "'", int53 == 10);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560629037L + "'", long58 == 1560629037L);
        org.junit.Assert.assertNotNull(gregorianChronology60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 43210 + "'", int65 == 43210);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 0L + "'", long67 == 0L);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(gregorianChronology72);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertNotNull(lenientChronology74);
        org.junit.Assert.assertNotNull(period76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(period79);
        org.junit.Assert.assertNotNull(period81);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 86409 + "'", int86 == 86409);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 25 + "'", int87 == 25);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + (-630803375585L) + "'", long90 == (-630803375585L));
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 4 + "'", int91 == 4);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) -1);
        int int2 = period1.getMinutes();
        org.joda.time.Period period4 = period1.withMillis((int) (byte) 100);
        org.joda.time.Period period6 = period1.minusYears((int) (byte) 10);
        org.joda.time.Period period8 = period6.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.era();
        org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) period6, periodType9, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 1, periodType14);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period17 = period15.normalizedStandard(periodType16);
        org.joda.time.DurationFieldType durationFieldType19 = periodType16.getFieldType(1);
        boolean boolean20 = period6.isSupported(durationFieldType19);
        org.joda.time.field.PreciseDurationField preciseDurationField22 = new org.joda.time.field.PreciseDurationField(durationFieldType19, (long) 86409);
        long long23 = preciseDurationField22.getUnitMillis();
        java.lang.String str24 = preciseDurationField22.toString();
        java.lang.Object obj25 = null;
        boolean boolean26 = preciseDurationField22.equals(obj25);
        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period(10L, periodType28, chronology29);
        org.joda.time.DurationFieldType durationFieldType31 = null;
        int int32 = periodType28.indexOf(durationFieldType31);
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.dayOfYear();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology33.clockhourOfHalfday();
        boolean boolean36 = periodType28.equals((java.lang.Object) gregorianChronology33);
        org.joda.time.PeriodType periodType37 = org.joda.time.DateTimeUtils.getPeriodType(periodType28);
        boolean boolean38 = preciseDurationField22.equals((java.lang.Object) periodType28);
        long long41 = preciseDurationField22.getMillis(1820, 864090L);
        boolean boolean42 = preciseDurationField22.isPrecise();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 86409L + "'", long23 == 86409L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "DurationField[weeks]" + "'", str24.equals("DurationField[weeks]"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 157264380L + "'", long41 == 157264380L);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) -1);
        int int2 = period1.getMinutes();
        org.joda.time.Period period4 = period1.withMillis((int) (byte) 100);
        int int5 = period4.getWeeks();
        org.joda.time.Period period6 = period4.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod7 = period4.toMutablePeriod();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(mutablePeriod7);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "hi!", "hi!");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "UTC", "UTC");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getName(locale9, "+01:00", "");
        java.util.Locale locale13 = null;
        java.lang.String str16 = defaultNameProvider0.getShortName(locale13, "PeriodType[YearWeekDay]", "org.joda.time.IllegalFieldValueException: Value \"\" for hi! is not supported");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 10, (int) ' ', (int) (short) -1, (int) (short) 0);
        org.joda.time.Period period6 = org.joda.time.Period.days((int) (short) -1);
        org.joda.time.Period period8 = period6.plusYears((int) (byte) 1);
        org.joda.time.Period period10 = period8.minusWeeks((int) (short) 0);
        org.joda.time.DurationFieldType durationFieldType12 = period10.getFieldType(0);
        org.joda.time.Period period14 = period4.withField(durationFieldType12, 86409);
        org.joda.time.Period period16 = period14.withMillis((int) (byte) 10);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) -1);
        int int2 = period1.getMinutes();
        org.joda.time.Period period4 = period1.withDays((int) (byte) -1);
        int int5 = period4.size();
        org.joda.time.Period period7 = org.joda.time.Period.days((int) (short) -1);
        org.joda.time.Period period9 = period7.plusYears((int) (byte) 1);
        org.joda.time.Period period11 = period9.minusWeeks((int) (short) 0);
        org.joda.time.DurationFieldType durationFieldType13 = period11.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField14 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType13);
        int int15 = period4.indexOf(durationFieldType13);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField16 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType13);
        boolean boolean17 = unsupportedDurationField16.isPrecise();
        try {
            long long19 = unsupportedDurationField16.getMillis((long) 56999);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertNotNull(unsupportedDurationField14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test181");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        long long5 = dateTimeZone2.adjustOffset((long) '4', false);
//        boolean boolean7 = dateTimeZone2.isStandardOffset((long) '#');
//        java.lang.String str9 = dateTimeZone2.getShortName(1L);
//        org.joda.time.Chronology chronology10 = gregorianChronology0.withZone(dateTimeZone2);
//        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeField dateTimeField12 = lenientChronology11.secondOfDay();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(lenientChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(lenientChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) 10);
        int int30 = offsetDateTimeField28.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField28.getAsText(readablePartial31, 1, locale33);
        org.joda.time.ReadablePartial readablePartial35 = null;
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField28.getAsText(readablePartial35, (int) (byte) 100, locale37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType39);
        org.joda.time.Period period42 = org.joda.time.Period.days((int) (short) -1);
        int int43 = period42.getMinutes();
        org.joda.time.Period period45 = period42.withMillis((int) (byte) 100);
        org.joda.time.Period period47 = period42.minusYears((int) (byte) 10);
        org.joda.time.Period period49 = period47.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType50 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology51.era();
        org.joda.time.Period period53 = new org.joda.time.Period((java.lang.Object) period47, periodType50, (org.joda.time.Chronology) gregorianChronology51);
        org.joda.time.PeriodType periodType55 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period56 = new org.joda.time.Period((long) (short) 1, periodType55);
        org.joda.time.PeriodType periodType57 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period58 = period56.normalizedStandard(periodType57);
        org.joda.time.DurationFieldType durationFieldType60 = periodType57.getFieldType(1);
        boolean boolean61 = period47.isSupported(durationFieldType60);
        org.joda.time.field.PreciseDurationField preciseDurationField63 = new org.joda.time.field.PreciseDurationField(durationFieldType60, (long) 86409);
        long long64 = preciseDurationField63.getUnitMillis();
        java.lang.String str65 = preciseDurationField63.toString();
        long long66 = preciseDurationField63.getUnitMillis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField67 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, (org.joda.time.DurationField) preciseDurationField63);
        org.joda.time.DateTimeFieldType dateTimeFieldType68 = unsupportedDateTimeField67.getType();
        java.util.Locale locale70 = null;
        try {
            java.lang.String str71 = unsupportedDateTimeField67.getAsText((-3600000), locale70);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 43210 + "'", int30 == 43210);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "100" + "'", str38.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(periodType55);
        org.junit.Assert.assertNotNull(periodType57);
        org.junit.Assert.assertNotNull(period58);
        org.junit.Assert.assertNotNull(durationFieldType60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 86409L + "'", long64 == 86409L);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "DurationField[weeks]" + "'", str65.equals("DurationField[weeks]"));
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 86409L + "'", long66 == 86409L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField67);
        org.junit.Assert.assertNotNull(dateTimeFieldType68);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 10);
        int int5 = offsetDateTimeField3.get((-210866068800000L));
        long long8 = offsetDateTimeField3.add(0L, (long) (short) 1);
        org.joda.time.DateTimeField dateTimeField9 = offsetDateTimeField3.getWrappedField();
        long long12 = offsetDateTimeField3.add((-100L), (long) (-5));
        boolean boolean14 = offsetDateTimeField3.isLeap((-60266045221990L));
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.yearOfEra();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.clockhourOfHalfday();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        long long21 = gregorianChronology15.add(readablePeriod18, 1L, 100);
        org.joda.time.Chronology chronology22 = gregorianChronology15.withUTC();
        try {
            org.joda.time.Period period23 = new org.joda.time.Period((java.lang.Object) offsetDateTimeField3, (org.joda.time.Chronology) gregorianChronology15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.field.OffsetDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 43210 + "'", int5 == 43210);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1000L + "'", long8 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-5100L) + "'", long12 == (-5100L));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertNotNull(chronology22);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(10L, periodType1, chronology2);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        int int5 = periodType1.indexOf(durationFieldType4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.dayOfYear();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.clockhourOfHalfday();
        boolean boolean9 = periodType1.equals((java.lang.Object) gregorianChronology6);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) 1, periodType11);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period14 = period12.normalizedStandard(periodType13);
        org.joda.time.DurationFieldType durationFieldType16 = periodType13.getFieldType(1);
        int int17 = periodType1.indexOf(durationFieldType16);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField18 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType16);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType16);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder20 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder31 = dateTimeZoneBuilder20.addRecurringSavings("UTC", (-1), 10, (int) (byte) -1, 'a', (int) (short) 100, (int) (byte) -1, 100, false, 10);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder39 = dateTimeZoneBuilder20.addCutover((int) (byte) 0, '4', (int) (short) -1, (int) '#', 0, false, (int) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone42 = dateTimeZoneBuilder39.toDateTimeZone("", true);
        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeUtils.getZone(dateTimeZone42);
        boolean boolean44 = unsupportedDurationField19.equals((java.lang.Object) dateTimeZone43);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(durationFieldType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(unsupportedDurationField18);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder31);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder39);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 1000L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210780360000000L) + "'", long1 == (-210780360000000L));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundCeiling(1560629037229L);
        long long27 = remainderDateTimeField22.addWrapField((-4925311L), (int) (short) 0);
        org.joda.time.DurationField durationField28 = remainderDateTimeField22.getDurationField();
        long long30 = remainderDateTimeField22.roundHalfCeiling(1000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577664000000L + "'", long24 == 1577664000000L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-4925311L) + "'", long27 == (-4925311L));
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-259200000L) + "'", long30 == (-259200000L));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) 10);
        int int30 = offsetDateTimeField28.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField28.getAsText(readablePartial31, 1, locale33);
        org.joda.time.ReadablePartial readablePartial35 = null;
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField28.getAsText(readablePartial35, (int) (byte) 100, locale37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType39);
        org.joda.time.Period period42 = org.joda.time.Period.days((int) (short) -1);
        int int43 = period42.getMinutes();
        org.joda.time.Period period45 = period42.withMillis((int) (byte) 100);
        org.joda.time.Period period47 = period42.minusYears((int) (byte) 10);
        org.joda.time.Period period49 = period47.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType50 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology51.era();
        org.joda.time.Period period53 = new org.joda.time.Period((java.lang.Object) period47, periodType50, (org.joda.time.Chronology) gregorianChronology51);
        org.joda.time.PeriodType periodType55 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period56 = new org.joda.time.Period((long) (short) 1, periodType55);
        org.joda.time.PeriodType periodType57 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period58 = period56.normalizedStandard(periodType57);
        org.joda.time.DurationFieldType durationFieldType60 = periodType57.getFieldType(1);
        boolean boolean61 = period47.isSupported(durationFieldType60);
        org.joda.time.field.PreciseDurationField preciseDurationField63 = new org.joda.time.field.PreciseDurationField(durationFieldType60, (long) 86409);
        long long64 = preciseDurationField63.getUnitMillis();
        java.lang.String str65 = preciseDurationField63.toString();
        long long66 = preciseDurationField63.getUnitMillis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField67 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, (org.joda.time.DurationField) preciseDurationField63);
        org.joda.time.DateTimeFieldType dateTimeFieldType68 = unsupportedDateTimeField67.getType();
        java.lang.String str69 = unsupportedDateTimeField67.getName();
        java.lang.String str70 = unsupportedDateTimeField67.getName();
        try {
            long long73 = unsupportedDateTimeField67.set((long) 57609, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 43210 + "'", int30 == 43210);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "100" + "'", str38.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(periodType55);
        org.junit.Assert.assertNotNull(periodType57);
        org.junit.Assert.assertNotNull(period58);
        org.junit.Assert.assertNotNull(durationFieldType60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 86409L + "'", long64 == 86409L);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "DurationField[weeks]" + "'", str65.equals("DurationField[weeks]"));
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 86409L + "'", long66 == 86409L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField67);
        org.junit.Assert.assertNotNull(dateTimeFieldType68);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "secondOfDay" + "'", str69.equals("secondOfDay"));
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "secondOfDay" + "'", str70.equals("secondOfDay"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) 10);
        int int30 = offsetDateTimeField28.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField28.getAsText(readablePartial31, 1, locale33);
        org.joda.time.ReadablePartial readablePartial35 = null;
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField28.getAsText(readablePartial35, (int) (byte) 100, locale37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType39);
        org.joda.time.Period period42 = org.joda.time.Period.days((int) (short) -1);
        int int43 = period42.getMinutes();
        org.joda.time.Period period45 = period42.withMillis((int) (byte) 100);
        org.joda.time.Period period47 = period42.minusYears((int) (byte) 10);
        org.joda.time.Period period49 = period47.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType50 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology51.era();
        org.joda.time.Period period53 = new org.joda.time.Period((java.lang.Object) period47, periodType50, (org.joda.time.Chronology) gregorianChronology51);
        org.joda.time.PeriodType periodType55 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period56 = new org.joda.time.Period((long) (short) 1, periodType55);
        org.joda.time.PeriodType periodType57 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period58 = period56.normalizedStandard(periodType57);
        org.joda.time.DurationFieldType durationFieldType60 = periodType57.getFieldType(1);
        boolean boolean61 = period47.isSupported(durationFieldType60);
        org.joda.time.field.PreciseDurationField preciseDurationField63 = new org.joda.time.field.PreciseDurationField(durationFieldType60, (long) 86409);
        long long64 = preciseDurationField63.getUnitMillis();
        java.lang.String str65 = preciseDurationField63.toString();
        long long66 = preciseDurationField63.getUnitMillis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField67 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, (org.joda.time.DurationField) preciseDurationField63);
        org.joda.time.DateTimeFieldType dateTimeFieldType68 = unsupportedDateTimeField67.getType();
        int int71 = unsupportedDateTimeField67.getDifference((long) ' ', 134380378000L);
        java.util.Locale locale73 = null;
        try {
            java.lang.String str74 = unsupportedDateTimeField67.getAsShortText(34, locale73);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 43210 + "'", int30 == 43210);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "100" + "'", str38.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(periodType55);
        org.junit.Assert.assertNotNull(periodType57);
        org.junit.Assert.assertNotNull(period58);
        org.junit.Assert.assertNotNull(durationFieldType60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 86409L + "'", long64 == 86409L);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "DurationField[weeks]" + "'", str65.equals("DurationField[weeks]"));
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 86409L + "'", long66 == 86409L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField67);
        org.junit.Assert.assertNotNull(dateTimeFieldType68);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1555166) + "'", int71 == (-1555166));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Coordinated Universal Time", (java.lang.Number) 2440587L, (java.lang.Number) (byte) 10, (java.lang.Number) 0.0d);
        org.joda.time.IllegalFieldValueException illegalFieldValueException7 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException7.prependMessage("hi!");
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException7);
        java.lang.Number number11 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 10 + "'", number11.equals((byte) 10));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) -1);
        org.joda.time.Period period3 = period1.plusYears((int) (byte) 1);
        org.joda.time.Period period5 = period3.minusWeeks((int) (short) 0);
        org.joda.time.DurationFieldType durationFieldType7 = period5.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField8 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType7);
        long long9 = unsupportedDurationField8.getUnitMillis();
        boolean boolean10 = unsupportedDurationField8.isPrecise();
        boolean boolean11 = unsupportedDurationField8.isSupported();
        try {
            long long14 = unsupportedDurationField8.getValueAsLong((long) 12, (-72645000095627L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertNotNull(unsupportedDurationField8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) -1);
        int int2 = period1.getMinutes();
        org.joda.time.Period period4 = period1.withMillis((int) (byte) 100);
        org.joda.time.Period period6 = period1.minusYears((int) (byte) 10);
        org.joda.time.Period period8 = period6.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.era();
        org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) period6, periodType9, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.minuteOfHour();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) -1);
        int int2 = period1.getMinutes();
        org.joda.time.Period period4 = period1.withMillis((int) (byte) 100);
        org.joda.time.Period period6 = period1.minusYears((int) (byte) 10);
        org.joda.time.Period period8 = period6.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.era();
        org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) period6, periodType9, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 1, periodType14);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period17 = period15.normalizedStandard(periodType16);
        org.joda.time.DurationFieldType durationFieldType19 = periodType16.getFieldType(1);
        boolean boolean20 = period6.isSupported(durationFieldType19);
        org.joda.time.field.PreciseDurationField preciseDurationField22 = new org.joda.time.field.PreciseDurationField(durationFieldType19, (long) 86409);
        long long23 = preciseDurationField22.getUnitMillis();
        java.lang.String str24 = preciseDurationField22.toString();
        long long26 = preciseDurationField22.getMillis((-10));
        long long29 = preciseDurationField22.add(0L, (-80976232428327L));
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 86409L + "'", long23 == 86409L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "DurationField[weeks]" + "'", str24.equals("DurationField[weeks]"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-864090L) + "'", long26 == (-864090L));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-6997075267899307743L) + "'", long29 == (-6997075267899307743L));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 10);
        int int5 = offsetDateTimeField3.get((-210866068800000L));
        int int6 = offsetDateTimeField3.getMinimumValue();
        long long8 = offsetDateTimeField3.roundHalfEven((long) (byte) 100);
        java.lang.String str9 = offsetDateTimeField3.getName();
        long long12 = offsetDateTimeField3.getDifferenceAsLong((-60266045222000L), 0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 43210 + "'", int5 == 43210);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "secondOfDay" + "'", str9.equals("secondOfDay"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-60266045222L) + "'", long12 == (-60266045222L));
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test194");
//        org.joda.time.Period period2 = org.joda.time.Period.days(0);
//        org.joda.time.Period period4 = period2.plusWeeks((int) (byte) -1);
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.Period period6 = period4.withFields(readablePeriod5);
//        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.months();
//        org.joda.time.PeriodType periodType9 = periodType8.withMonthsRemoved();
//        org.joda.time.PeriodType periodType10 = periodType9.withDaysRemoved();
//        org.joda.time.Period period11 = new org.joda.time.Period((long) '4', periodType10);
//        boolean boolean12 = period6.equals((java.lang.Object) periodType10);
//        org.joda.time.PeriodType periodType13 = periodType10.withMonthsRemoved();
//        org.joda.time.PeriodType periodType14 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.era();
//        org.joda.time.DurationField durationField17 = gregorianChronology15.halfdays();
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology15.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology15.dayOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology20 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology15);
//        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.dayTime();
//        org.joda.time.Chronology chronology23 = null;
//        org.joda.time.Period period24 = new org.joda.time.Period(10L, periodType22, chronology23);
//        org.joda.time.Period period26 = period24.withSeconds((int) ' ');
//        boolean boolean27 = lenientChronology20.equals((java.lang.Object) ' ');
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.UTC;
//        boolean boolean30 = dateTimeZone28.isStandardOffset((long) (short) 10);
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = dateTimeZone28.getShortName((long) (short) 10, locale32);
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone28);
//        long long37 = dateTimeZone28.adjustOffset(10L, false);
//        org.joda.time.Chronology chronology38 = lenientChronology20.withZone(dateTimeZone28);
//        org.joda.time.DateTimeField dateTimeField39 = lenientChronology20.yearOfCentury();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone44 = new org.joda.time.tz.FixedDateTimeZone("", "PT0S", (int) (byte) 0, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.era();
//        org.joda.time.DurationField durationField47 = gregorianChronology45.halfdays();
//        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology45.clockhourOfDay();
//        boolean boolean49 = fixedDateTimeZone44.equals((java.lang.Object) gregorianChronology45);
//        boolean boolean50 = fixedDateTimeZone44.isFixed();
//        org.joda.time.LocalDateTime localDateTime51 = null;
//        boolean boolean52 = fixedDateTimeZone44.isLocalDateTimeGap(localDateTime51);
//        org.joda.time.chrono.ZonedChronology zonedChronology53 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) lenientChronology20, (org.joda.time.DateTimeZone) fixedDateTimeZone44);
//        org.joda.time.DateTimeField dateTimeField54 = zonedChronology53.dayOfYear();
//        org.joda.time.Period period55 = new org.joda.time.Period((long) (-3600000), periodType14, (org.joda.time.Chronology) zonedChronology53);
//        long long63 = zonedChronology53.getDateTimeMillis((int) (short) -1, 57609, (int) 'a', 25, 25, (-1), 56999);
//        org.joda.time.Chronology chronology64 = zonedChronology53.withUTC();
//        org.junit.Assert.assertNotNull(period2);
//        org.junit.Assert.assertNotNull(period4);
//        org.junit.Assert.assertNotNull(period6);
//        org.junit.Assert.assertNotNull(periodType8);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertNotNull(periodType10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(periodType13);
//        org.junit.Assert.assertNotNull(periodType14);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(lenientChronology20);
//        org.junit.Assert.assertNotNull(periodType22);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "UTC" + "'", str33.equals("UTC"));
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 10L + "'", long37 == 10L);
//        org.junit.Assert.assertNotNull(chronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(gregorianChronology45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(zonedChronology53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 89303995555999L + "'", long63 == 89303995555999L);
//        org.junit.Assert.assertNotNull(chronology64);
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundFloor(0L);
        long long26 = remainderDateTimeField22.roundCeiling(86409L);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 31795200000L + "'", long26 == 31795200000L);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        boolean boolean2 = dateTimeZone0.isStandardOffset((long) (short) 10);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.lang.String str4 = iSOChronology3.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) (short) 10);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        long long11 = dateTimeZone5.adjustOffset((long) (byte) 10, true);
        org.joda.time.Chronology chronology12 = iSOChronology3.withZone(dateTimeZone5);
        org.joda.time.Chronology chronology13 = iSOChronology3.withUTC();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.UTC;
        java.util.TimeZone timeZone15 = dateTimeZone14.toTimeZone();
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology3, dateTimeZone14);
        java.lang.String str17 = zonedChronology16.toString();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str17.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("LenientChronology[GregorianChronology[America/Los_Angeles]]", "", (int) '4', (int) '#');
        long long6 = fixedDateTimeZone4.nextTransition(2440588L);
        int int8 = fixedDateTimeZone4.getOffset(58000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2440588L + "'", long6 == 2440588L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 10);
        int int5 = offsetDateTimeField3.get((-210866068800000L));
        int int6 = offsetDateTimeField3.getMinimumValue();
        long long8 = offsetDateTimeField3.roundHalfEven((long) (byte) 100);
        long long10 = offsetDateTimeField3.remainder((-60266045221990L));
        long long12 = offsetDateTimeField3.roundHalfFloor((long) 1);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int int14 = offsetDateTimeField3.getMaximumValue(readablePartial13);
        long long16 = offsetDateTimeField3.roundHalfEven(3024415L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 43210 + "'", int5 == 43210);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 86409 + "'", int14 == 86409);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3024000L + "'", long16 == 3024000L);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long3 = dateTimeZone0.adjustOffset((long) '4', false);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(1);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, dateTimeZone6);
        org.joda.time.ReadableInstant readableInstant8 = null;
        int int9 = dateTimeZone6.getOffset(readableInstant8);
        long long13 = dateTimeZone6.convertLocalToUTC((long) (-10), true, (long) (-8));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3600000 + "'", int9 == 3600000);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-3600010L) + "'", long13 == (-3600010L));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        org.joda.time.Period period1 = org.joda.time.Period.parse("PT0S");
        org.joda.time.Period period3 = period1.plusHours((int) (short) 1);
        org.joda.time.Period period5 = period1.minusDays(86409);
        org.joda.time.Period period7 = org.joda.time.Period.millis((int) (short) 0);
        org.joda.time.Period period8 = period5.minus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Period period9 = new org.joda.time.Period((java.lang.Object) period8);
        org.joda.time.Period period10 = period9.negated();
        org.joda.time.Period period12 = period10.plusWeeks(0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundFloor(0L);
        long long27 = remainderDateTimeField22.addWrapField(311040002440587L, (-1));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 311008552840587L + "'", long27 == 311008552840587L);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test202");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.Period period2 = new org.joda.time.Period(2440588L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
//        boolean boolean6 = dateTimeZone4.isStandardOffset((long) (short) 10);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone4.getShortName((long) (short) 10, locale8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
//        org.joda.time.Chronology chronology11 = gregorianChronology1.withZone(dateTimeZone4);
//        org.joda.time.chrono.LenientChronology lenientChronology12 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology1);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(lenientChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(lenientChronology12);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) 10);
        int int30 = offsetDateTimeField28.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField28.getAsText(readablePartial31, 1, locale33);
        org.joda.time.ReadablePartial readablePartial35 = null;
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField28.getAsText(readablePartial35, (int) (byte) 100, locale37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType39);
        long long43 = dividedDateTimeField40.addWrapField((long) (short) 0, 43210);
        long long46 = dividedDateTimeField40.add((-74665144428327L), (long) (-50));
        long long49 = dividedDateTimeField40.set((long) (-1555066), 12);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 43210 + "'", int30 == 43210);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "100" + "'", str38.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-252201600000L) + "'", long43 == (-252201600000L));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-80976232428327L) + "'", long46 == (-80976232428327L));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-630807955066L) + "'", long49 == (-630807955066L));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        org.joda.time.DurationFieldType durationFieldType1 = null;
        int int2 = periodType0.indexOf(durationFieldType1);
        org.joda.time.PeriodType periodType3 = periodType0.withMinutesRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) -1);
        int int2 = period1.getMinutes();
        org.joda.time.Period period4 = period1.withMillis((int) (byte) 100);
        org.joda.time.Period period6 = period1.minusYears((int) (byte) 10);
        org.joda.time.Period period8 = period6.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.era();
        org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) period6, periodType9, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 1, periodType14);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period17 = period15.normalizedStandard(periodType16);
        org.joda.time.DurationFieldType durationFieldType19 = periodType16.getFieldType(1);
        boolean boolean20 = period6.isSupported(durationFieldType19);
        org.joda.time.field.PreciseDurationField preciseDurationField22 = new org.joda.time.field.PreciseDurationField(durationFieldType19, (long) 86409);
        int int24 = preciseDurationField22.getValue((long) 57609);
        long long27 = preciseDurationField22.getMillis(10, (long) (byte) -1);
        org.joda.time.PeriodType periodType29 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Chronology chronology30 = null;
        org.joda.time.Period period31 = new org.joda.time.Period(10L, periodType29, chronology30);
        org.joda.time.DurationFieldType durationFieldType32 = null;
        int int33 = periodType29.indexOf(durationFieldType32);
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.dayOfYear();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology34.clockhourOfHalfday();
        boolean boolean37 = periodType29.equals((java.lang.Object) gregorianChronology34);
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period40 = new org.joda.time.Period((long) (short) 1, periodType39);
        org.joda.time.PeriodType periodType41 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period42 = period40.normalizedStandard(periodType41);
        org.joda.time.DurationFieldType durationFieldType44 = periodType41.getFieldType(1);
        int int45 = periodType29.indexOf(durationFieldType44);
        org.joda.time.field.DecoratedDurationField decoratedDurationField46 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) preciseDurationField22, durationFieldType44);
        long long49 = decoratedDurationField46.add((long) 43210, 0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 864090L + "'", long27 == 864090L);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(durationFieldType44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 43210L + "'", long49 == 43210L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int11 = offsetDateTimeField9.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText(readablePartial12, 1, locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText(readablePartial16, (int) (byte) 100, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType20, 4);
        long long24 = remainderDateTimeField22.roundFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) 10);
        int int30 = offsetDateTimeField28.get((-210866068800000L));
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField28.getAsText(readablePartial31, 1, locale33);
        org.joda.time.ReadablePartial readablePartial35 = null;
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField28.getAsText(readablePartial35, (int) (byte) 100, locale37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType39);
        org.joda.time.Period period42 = org.joda.time.Period.days((int) (short) -1);
        int int43 = period42.getMinutes();
        org.joda.time.Period period45 = period42.withMillis((int) (byte) 100);
        org.joda.time.Period period47 = period42.minusYears((int) (byte) 10);
        org.joda.time.Period period49 = period47.plusSeconds((int) (byte) -1);
        org.joda.time.PeriodType periodType50 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology51.era();
        org.joda.time.Period period53 = new org.joda.time.Period((java.lang.Object) period47, periodType50, (org.joda.time.Chronology) gregorianChronology51);
        org.joda.time.PeriodType periodType55 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period56 = new org.joda.time.Period((long) (short) 1, periodType55);
        org.joda.time.PeriodType periodType57 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period58 = period56.normalizedStandard(periodType57);
        org.joda.time.DurationFieldType durationFieldType60 = periodType57.getFieldType(1);
        boolean boolean61 = period47.isSupported(durationFieldType60);
        org.joda.time.field.PreciseDurationField preciseDurationField63 = new org.joda.time.field.PreciseDurationField(durationFieldType60, (long) 86409);
        long long64 = preciseDurationField63.getUnitMillis();
        java.lang.String str65 = preciseDurationField63.toString();
        long long66 = preciseDurationField63.getUnitMillis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField67 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, (org.joda.time.DurationField) preciseDurationField63);
        org.joda.time.DateTimeFieldType dateTimeFieldType68 = unsupportedDateTimeField67.getType();
        java.lang.String str69 = unsupportedDateTimeField67.getName();
        long long72 = unsupportedDateTimeField67.getDifferenceAsLong(346000L, (long) 17);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43210 + "'", int11 == 43210);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 43210 + "'", int30 == 43210);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "100" + "'", str38.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(periodType55);
        org.junit.Assert.assertNotNull(periodType57);
        org.junit.Assert.assertNotNull(period58);
        org.junit.Assert.assertNotNull(durationFieldType60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 86409L + "'", long64 == 86409L);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "DurationField[weeks]" + "'", str65.equals("DurationField[weeks]"));
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 86409L + "'", long66 == 86409L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField67);
        org.junit.Assert.assertNotNull(dateTimeFieldType68);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "secondOfDay" + "'", str69.equals("secondOfDay"));
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 4L + "'", long72 == 4L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.Period period4 = period2.minusDays((int) (short) 100);
        int int5 = period2.getYears();
        org.joda.time.Period period7 = period2.plusMillis(52);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType9 = periodType8.withYearsRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology10);
        java.lang.String str12 = lenientChronology11.toString();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period2, periodType9, (org.joda.time.Chronology) lenientChronology11);
        org.joda.time.Period period15 = period13.minusMillis((-349200000));
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "LenientChronology[GregorianChronology[UTC]]" + "'", str12.equals("LenientChronology[GregorianChronology[UTC]]"));
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 10);
        int int5 = offsetDateTimeField3.get((-210866068800000L));
        java.lang.String str7 = offsetDateTimeField3.getAsText(6040588L);
        org.joda.time.DurationField durationField8 = offsetDateTimeField3.getLeapDurationField();
        java.lang.String str9 = offsetDateTimeField3.getName();
        org.joda.time.DurationField durationField10 = offsetDateTimeField3.getDurationField();
        org.joda.time.ReadablePartial readablePartial11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.dayOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology15 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Period period17 = org.joda.time.Period.days((int) (short) -1);
        int int18 = period17.getMinutes();
        org.joda.time.Period period20 = period17.withMillis((int) (byte) 100);
        org.joda.time.Period period22 = period17.minusYears((int) (byte) 10);
        int[] intArray24 = lenientChronology15.get((org.joda.time.ReadablePeriod) period17, (long) (short) 0);
        java.util.Locale locale26 = null;
        try {
            int[] intArray27 = offsetDateTimeField3.set(readablePartial11, (-97), intArray24, "org.joda.time.IllegalFieldValueException: hi!: Value \"\" for hi! is not supported", locale26);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"org.joda.time.IllegalFieldValueException: hi!: Value \"\" for hi! is not supported\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 43210 + "'", int5 == 43210);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "6050" + "'", str7.equals("6050"));
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "secondOfDay" + "'", str9.equals("secondOfDay"));
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(lenientChronology15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 10);
        int int5 = offsetDateTimeField3.get((-210866068800000L));
        int int6 = offsetDateTimeField3.getMinimumValue();
        int int9 = offsetDateTimeField3.getDifference((-315705600000L), (long) 'a');
        boolean boolean11 = offsetDateTimeField3.isLeap((long) 35);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = offsetDateTimeField3.getMinimumValue(readablePartial12);
        int int15 = offsetDateTimeField3.getMinimumValue((-210865896000000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 43210 + "'", int5 == 43210);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-315705600) + "'", int9 == (-315705600));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long3 = dateTimeZone0.adjustOffset((long) '4', false);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(1);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, dateTimeZone6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.era();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        boolean boolean13 = zonedChronology7.equals((java.lang.Object) dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.UTC;
        long long17 = dateTimeZone14.adjustOffset((long) '4', false);
        long long20 = dateTimeZone14.convertLocalToUTC((long) 10, false);
        int int22 = dateTimeZone14.getOffsetFromLocal((long) (byte) 0);
        org.joda.time.Chronology chronology23 = zonedChronology7.withZone(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone24 = zonedChronology7.getZone();
        try {
            long long30 = zonedChronology7.getDateTimeMillis(272671134364800000L, 56999, (int) '4', 57, 5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 56999 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 100, (int) (byte) 0, (int) '4', (int) (byte) 10);
        org.joda.time.Period period6 = period4.minusDays(1);
        org.joda.time.Period period8 = period4.plusHours((-18060954));
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long3 = dateTimeZone0.adjustOffset((long) '4', false);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.year();
        org.joda.time.Period period10 = new org.joda.time.Period((int) (byte) 100, (int) (byte) 0, (int) '4', (int) (byte) 10);
        org.joda.time.Period period12 = period10.minusDays(1);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 1, periodType14);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period17 = period15.normalizedStandard(periodType16);
        org.joda.time.DurationFieldType durationFieldType19 = periodType16.getFieldType(1);
        org.joda.time.Period period21 = period10.withFieldAdded(durationFieldType19, 8);
        int int22 = period21.getMonths();
        org.joda.time.Period period24 = period21.plusMinutes((int) (byte) 0);
        org.joda.time.Period period26 = period21.plusWeeks(86409);
        int[] intArray29 = iSOChronology4.get((org.joda.time.ReadablePeriod) period21, (-80976232428327L), (-62899200000L));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(intArray29);
    }
}

