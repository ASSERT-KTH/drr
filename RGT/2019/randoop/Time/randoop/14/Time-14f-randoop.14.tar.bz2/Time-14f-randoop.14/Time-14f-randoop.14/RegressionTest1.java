import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (-28800000));
        java.util.Locale locale5 = null;
        int int6 = offsetDateTimeField4.getMaximumShortTextLength(locale5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, (java.lang.Number) (-18000000L), "10");
        try {
            org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField0, dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(0L);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.halfdays();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) cachedDateTimeZone4);
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone4);
        org.joda.time.Chronology chronology7 = zonedChronology6.withUTC();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.year();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone11);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology12);
        org.joda.time.MonthDay monthDay14 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology12);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology16 = julianChronology12.withZone(dateTimeZone15);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) cachedDateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone17.getUncachedZone();
        org.joda.time.Chronology chronology20 = iSOChronology8.withZone(dateTimeZone19);
        org.joda.time.Chronology chronology21 = zonedChronology6.withZone(dateTimeZone19);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(chronology21);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withDefaultYear(2054);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.field.FieldUtils.verifyValueBounds("0", (int) (byte) 0, 0, 1969);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology3);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5);
        org.joda.time.MonthDay monthDay7 = monthDay4.withChronologyRetainFields((org.joda.time.Chronology) julianChronology6);
        java.lang.String str8 = julianChronology6.toString();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.weekyearOfCentury();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) julianChronology6);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(10L);
        int[] intArray14 = julianChronology6.get((org.joda.time.ReadablePartial) monthDay12, (long) 13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = monthDay12.toString("4", locale16);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str8.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "4" + "'", str17.equals("4"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        java.lang.StringBuffer stringBuffer2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer2, (long) 49737830);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.dayOfMonth();
//        org.joda.time.Instant instant4 = gJChronology0.getGregorianCutover();
//        java.lang.String str5 = gJChronology0.toString();
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours(10);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
//        boolean boolean12 = cachedDateTimeZone10.isStandardOffset(10L);
//        org.joda.time.Chronology chronology13 = gregorianChronology6.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone10);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
//        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
//        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology16);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology20 = julianChronology16.withZone(dateTimeZone19);
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now(chronology20);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusWeeks(0);
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone24);
//        org.joda.time.DateTimeField dateTimeField26 = julianChronology25.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField27 = julianChronology25.dayOfWeek();
//        int int28 = dateTime23.get(dateTimeField27);
//        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone10, (org.joda.time.ReadableInstant) dateTime23);
//        org.joda.time.Chronology chronology30 = gJChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone10);
//        try {
//            long long35 = gJChronology0.getDateTimeMillis((-28800000), 153, (int) (byte) 0, 61253);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 153 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(instant4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GJChronology[UTC]" + "'", str5.equals("GJChronology[UTC]"));
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(julianChronology16);
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(julianChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertNotNull(gJChronology29);
//        org.junit.Assert.assertNotNull(chronology30);
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        boolean boolean6 = offsetDateTimeField3.isLenient();
        int int8 = offsetDateTimeField3.getMinimumValue((-187199990L));
        org.joda.time.DurationField durationField9 = offsetDateTimeField3.getRangeDurationField();
        org.joda.time.DurationField durationField10 = offsetDateTimeField3.getDurationField();
        long long13 = offsetDateTimeField3.addWrapField((long) 49715377, 19);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-321075054) + "'", int8 == (-321075054));
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 599665715377L + "'", long13 == 599665715377L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.parse("19");
        int int2 = monthDay1.size();
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (byte) 1, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendDayOfWeekText();
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusHours((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology14);
        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology14);
        org.joda.time.DateTime dateTime17 = dateTime7.toDateTime((org.joda.time.Chronology) julianChronology14);
        org.joda.time.DateTime dateTime18 = dateTime7.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, 13);
        org.joda.time.DateTime dateTime5 = instant1.toDateTimeISO();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readableDuration6);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now(dateTimeZone1);
//        org.joda.time.MonthDay.Property property3 = monthDay2.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5);
//        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology6);
//        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology6);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology10 = julianChronology6.withZone(dateTimeZone9);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(chronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusWeeks(0);
//        org.joda.time.DateTime dateTime15 = dateTime11.plusSeconds(0);
//        org.joda.time.DateTime.Property property16 = dateTime15.yearOfCentury();
//        org.joda.time.DateTime dateTime17 = property16.withMaximumValue();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
//        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology20);
//        org.joda.time.DateTimeField dateTimeField22 = julianChronology20.weekOfWeekyear();
//        boolean boolean23 = property16.equals((java.lang.Object) dateTimeField22);
//        int int24 = property16.getMaximumValueOverall();
//        org.joda.time.DateTime dateTime26 = property16.setCopy((int) (byte) 10);
//        org.joda.time.DateTimeZone dateTimeZone27 = dateTime26.getZone();
//        int int28 = dateTime26.getDayOfWeek();
//        org.joda.time.DateTime dateTime30 = dateTime26.minus((long) 1);
//        boolean boolean31 = property3.equals((java.lang.Object) dateTime26);
//        int int32 = property3.get();
//        int int33 = property3.getMaximumValue();
//        java.lang.String str34 = property3.getName();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(julianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 100 + "'", int24 == 100);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 15 + "'", int32 == 15);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 30 + "'", int33 == 30);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "dayOfMonth" + "'", str34.equals("dayOfMonth"));
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology3);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology7 = julianChronology3.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(chronology7);
        org.joda.time.DateTime dateTime10 = dateTime8.minusWeeks(0);
        org.joda.time.DateTime dateTime12 = dateTime8.plusHours((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone14);
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology15);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.MonthDay monthDay19 = monthDay16.withChronologyRetainFields((org.joda.time.Chronology) julianChronology18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone24);
        org.joda.time.MonthDay monthDay26 = monthDay23.withChronologyRetainFields((org.joda.time.Chronology) julianChronology25);
        java.lang.Class<?> wildcardClass27 = monthDay23.getClass();
        long long29 = julianChronology18.set((org.joda.time.ReadablePartial) monthDay23, 10L);
        org.joda.time.DateTime dateTime30 = dateTime8.toDateTime((org.joda.time.Chronology) julianChronology18);
        java.util.Locale locale31 = null;
        java.util.Calendar calendar32 = dateTime8.toCalendar(locale31);
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.fromCalendarFields(calendar32);
        boolean boolean34 = monthDay0.isAfter((org.joda.time.ReadablePartial) monthDay33);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(calendar32);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        dateTimeFormatterBuilder2.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendYear(0, 45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.dayOfMonth();
//        org.joda.time.Instant instant4 = gJChronology0.getGregorianCutover();
//        java.lang.String str5 = gJChronology0.toString();
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours(10);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
//        boolean boolean12 = cachedDateTimeZone10.isStandardOffset(10L);
//        org.joda.time.Chronology chronology13 = gregorianChronology6.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone10);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
//        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
//        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology16);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology20 = julianChronology16.withZone(dateTimeZone19);
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now(chronology20);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusWeeks(0);
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone24);
//        org.joda.time.DateTimeField dateTimeField26 = julianChronology25.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField27 = julianChronology25.dayOfWeek();
//        int int28 = dateTime23.get(dateTimeField27);
//        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone10, (org.joda.time.ReadableInstant) dateTime23);
//        org.joda.time.Chronology chronology30 = gJChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone10);
//        org.joda.time.DurationField durationField31 = gJChronology0.hours();
//        org.joda.time.Chronology chronology32 = gJChronology0.withUTC();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(instant4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GJChronology[UTC]" + "'", str5.equals("GJChronology[UTC]"));
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(julianChronology16);
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(julianChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertNotNull(gJChronology29);
//        org.junit.Assert.assertNotNull(chronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(chronology32);
//    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now(dateTimeZone1);
//        org.joda.time.MonthDay.Property property3 = monthDay2.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5);
//        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology6);
//        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology6);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology10 = julianChronology6.withZone(dateTimeZone9);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(chronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusWeeks(0);
//        org.joda.time.DateTime dateTime15 = dateTime11.plusSeconds(0);
//        org.joda.time.DateTime.Property property16 = dateTime15.yearOfCentury();
//        org.joda.time.DateTime dateTime17 = property16.withMaximumValue();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
//        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology20);
//        org.joda.time.DateTimeField dateTimeField22 = julianChronology20.weekOfWeekyear();
//        boolean boolean23 = property16.equals((java.lang.Object) dateTimeField22);
//        int int24 = property16.getMaximumValueOverall();
//        org.joda.time.DateTime dateTime26 = property16.setCopy((int) (byte) 10);
//        org.joda.time.DateTimeZone dateTimeZone27 = dateTime26.getZone();
//        int int28 = dateTime26.getDayOfWeek();
//        org.joda.time.DateTime dateTime30 = dateTime26.minus((long) 1);
//        boolean boolean31 = property3.equals((java.lang.Object) dateTime26);
//        org.joda.time.MonthDay monthDay33 = property3.addWrapFieldToCopy(49769163);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(julianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 100 + "'", int24 == 100);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(monthDay33);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, 0);
        long long7 = skipUndoDateTimeField5.roundHalfCeiling((long) (byte) 1);
        int int10 = skipUndoDateTimeField5.getDifference((long) 54, (long) 53330);
        org.joda.time.DurationField durationField11 = skipUndoDateTimeField5.getRangeDurationField();
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField5.getLeapDurationField();
        java.lang.String str14 = skipUndoDateTimeField5.getAsText((long) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNull(durationField12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "3" + "'", str14.equals("3"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology5);
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology9 = julianChronology5.withZone(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(chronology9);
        org.joda.time.DateTime dateTime12 = dateTime10.minusWeeks(0);
        org.joda.time.DateTime dateTime14 = dateTime10.plusHours((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone16);
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology17);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.MonthDay monthDay21 = monthDay18.withChronologyRetainFields((org.joda.time.Chronology) julianChronology20);
        java.lang.String str22 = julianChronology20.toString();
        org.joda.time.DateTime dateTime23 = dateTime10.toDateTime((org.joda.time.Chronology) julianChronology20);
        org.joda.time.DateTime dateTime25 = dateTime10.minus(520L);
        boolean boolean26 = gregorianChronology0.equals((java.lang.Object) 520L);
        org.joda.time.Chronology chronology27 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str22.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(chronology27);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology3);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5);
        org.joda.time.MonthDay monthDay7 = monthDay4.withChronologyRetainFields((org.joda.time.Chronology) julianChronology6);
        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay7);
        boolean boolean9 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay7);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����" + "'", str8.equals("����"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendDayOfWeekText();
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendHourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendLiteral("35");
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatterBuilder6.toParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray12 = new org.joda.time.format.DateTimeParser[] { dateTimeParser11 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder4.append(dateTimePrinter5, dateTimeParserArray12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeParserArray12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "--12-18", "");
        org.junit.Assert.assertNull(str4);
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.dayOfMonth();
//        org.joda.time.Instant instant4 = gJChronology0.getGregorianCutover();
//        java.lang.String str5 = gJChronology0.toString();
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours(10);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
//        boolean boolean12 = cachedDateTimeZone10.isStandardOffset(10L);
//        org.joda.time.Chronology chronology13 = gregorianChronology6.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone10);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
//        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
//        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology16);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology20 = julianChronology16.withZone(dateTimeZone19);
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now(chronology20);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusWeeks(0);
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone24);
//        org.joda.time.DateTimeField dateTimeField26 = julianChronology25.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField27 = julianChronology25.dayOfWeek();
//        int int28 = dateTime23.get(dateTimeField27);
//        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone10, (org.joda.time.ReadableInstant) dateTime23);
//        org.joda.time.Chronology chronology30 = gJChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone10);
//        java.util.TimeZone timeZone31 = null;
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forTimeZone(timeZone31);
//        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
//        org.joda.time.chrono.ZonedChronology zonedChronology34 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone32);
//        try {
//            long long39 = zonedChronology34.getDateTimeMillis(1969, 0, 49729403, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(instant4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GJChronology[UTC]" + "'", str5.equals("GJChronology[UTC]"));
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(julianChronology16);
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(julianChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertNotNull(gJChronology29);
//        org.junit.Assert.assertNotNull(chronology30);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(copticChronology33);
//        org.junit.Assert.assertNotNull(zonedChronology34);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendDayOfMonth(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatterBuilder5.toFormatter();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.append(dateTimePrinter7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(49729403, (int) (short) 0, 15, 216, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 216 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        org.joda.time.DateMidnight dateMidnight11 = dateTime9.toDateMidnight();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) 10, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        long long21 = iSOChronology17.add((long) 6, (long) 36000000, 0);
        org.joda.time.MutableDateTime mutableDateTime22 = dateMidnight11.toMutableDateTime((org.joda.time.Chronology) iSOChronology17);
        boolean boolean24 = mutableDateTime22.isBefore((long) 4);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateMidnight11);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 6L + "'", long21 == 6L);
        org.junit.Assert.assertNotNull(mutableDateTime22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.weekOfWeekyear();
        boolean boolean19 = property12.equals((java.lang.Object) dateTimeField18);
        org.joda.time.DateTime dateTime20 = property12.withMinimumValue();
        org.joda.time.DateTime.Property property21 = dateTime20.weekyear();
        java.lang.String str22 = property21.getAsShortText();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2001" + "'", str22.equals("2001"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) 10, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean7 = fixedDateTimeZone4.equals((java.lang.Object) false);
        long long9 = fixedDateTimeZone4.previousTransition((long) ' ');
        java.lang.String str11 = fixedDateTimeZone4.getNameKey(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long14 = fixedDateTimeZone4.previousTransition((long) 54);
        org.joda.time.Instant instant16 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Instant instant19 = instant16.withDurationAdded(readableDuration17, 13);
        int int20 = fixedDateTimeZone4.getOffset((org.joda.time.ReadableInstant) instant19);
        long long21 = instant19.getMillis();
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 32L + "'", long9 == 32L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 54L + "'", long14 == 54L);
        org.junit.Assert.assertNotNull(instant19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.weekOfWeekyear();
        boolean boolean19 = property12.equals((java.lang.Object) dateTimeField18);
        int int20 = property12.getMaximumValueOverall();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone22);
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology23);
        org.joda.time.MonthDay monthDay25 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology23);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology27 = julianChronology23.withZone(dateTimeZone26);
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now(chronology27);
        org.joda.time.DateTime dateTime30 = dateTime28.minusWeeks(0);
        org.joda.time.DateTime dateTime32 = dateTime28.plusSeconds(0);
        org.joda.time.DateTime.Property property33 = dateTime32.yearOfCentury();
        org.joda.time.DateTime dateTime34 = property33.withMaximumValue();
        long long35 = property12.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.DateTime dateTime37 = property12.addToCopy(1261);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-81L) + "'", long35 == (-81L));
        org.junit.Assert.assertNotNull(dateTime37);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "yearOfCentury");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = cachedDateTimeZone3.getUncachedZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone3);
        org.joda.time.Chronology chronology6 = gJChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone3);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str1 = gJChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.dayOfWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone10);
        org.joda.time.MonthDay monthDay12 = monthDay9.withChronologyRetainFields((org.joda.time.Chronology) julianChronology11);
        java.lang.String str13 = dateTimeFormatter5.print((org.joda.time.ReadablePartial) monthDay12);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray14 = monthDay12.getFieldTypes();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = julianChronology16.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology20);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone22);
        org.joda.time.MonthDay monthDay24 = monthDay21.withChronologyRetainFields((org.joda.time.Chronology) julianChronology23);
        java.lang.Class<?> wildcardClass25 = monthDay21.getClass();
        int[] intArray27 = julianChronology16.get((org.joda.time.ReadablePartial) monthDay21, 1L);
        boolean boolean28 = monthDay12.isAfter((org.joda.time.ReadablePartial) monthDay21);
        boolean boolean29 = gJChronology0.equals((java.lang.Object) monthDay21);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GJChronology[UTC]" + "'", str1.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "����" + "'", str13.equals("����"));
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        org.joda.time.DateTimeField dateTimeField6 = offsetDateTimeField3.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (-28800000));
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField10.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField10.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField15 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType13, 153);
        int int17 = dividedDateTimeField15.get((long) '#');
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (-28800000));
        java.util.Locale locale22 = null;
        int int23 = offsetDateTimeField21.getMaximumShortTextLength(locale22);
        org.joda.time.DateTimeField dateTimeField24 = offsetDateTimeField21.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (-28800000));
        java.util.Locale locale29 = null;
        int int30 = offsetDateTimeField28.getMaximumShortTextLength(locale29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField24, dateTimeFieldType31, 153);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField34 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField15, dateTimeFieldType31);
        long long37 = dividedDateTimeField15.add((long) '4', 153L);
        java.lang.String str39 = dividedDateTimeField15.getAsShortText((long) '4');
        boolean boolean40 = dividedDateTimeField15.isSupported();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 738716716800052L + "'", long37 == 738716716800052L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "12" + "'", str39.equals("12"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
//        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
//        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
//        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
//        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
//        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
//        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
//        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
//        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.weekOfWeekyear();
//        boolean boolean19 = property12.equals((java.lang.Object) dateTimeField18);
//        int int20 = property12.getMaximumValueOverall();
//        org.joda.time.DateTime dateTime22 = property12.setCopy((int) (byte) 10);
//        org.joda.time.DateTime dateTime24 = property12.addWrapFieldToCopy(2019);
//        int int25 = dateTime24.getDayOfMonth();
//        org.joda.time.ReadablePartial readablePartial26 = null;
//        org.joda.time.DateTime dateTime27 = dateTime24.withFields(readablePartial26);
//        int int28 = dateTime24.getSecondOfMinute();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(monthDay4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(julianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 31 + "'", int28 == 31);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        long long6 = offsetDateTimeField3.set((long) (short) 100, "35");
        long long9 = offsetDateTimeField3.getDifferenceAsLong(36000828L, (long) 1);
        long long11 = offsetDateTimeField3.roundFloor((long) 19);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 908779154918400100L + "'", long6 == 908779154918400100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfMinute();
        org.joda.time.Instant instant3 = gJChronology0.getGregorianCutover();
        java.lang.String str4 = gJChronology0.toString();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology0);
        try {
            long long13 = gJChronology0.getDateTimeMillis(57653339, 422, (-28800000), 1969, (-49715377), (int) 'a', 36000000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GJChronology[UTC]" + "'", str4.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.weekOfWeekyear();
        boolean boolean19 = property12.equals((java.lang.Object) dateTimeField18);
        org.joda.time.DateTime dateTime20 = property12.withMinimumValue();
        java.lang.Object obj21 = null;
        boolean boolean22 = property12.equals(obj21);
        org.joda.time.DateTime dateTime23 = property12.roundHalfFloorCopy();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone28 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) 10, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone28);
        org.joda.time.MutableDateTime mutableDateTime30 = dateTime23.toMutableDateTime((org.joda.time.Chronology) iSOChronology29);
        boolean boolean31 = dateTime23.isBeforeNow();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatterBuilder0.toPrinter();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (-28800000));
        java.util.Locale locale7 = null;
        int int8 = offsetDateTimeField6.getMaximumShortTextLength(locale7);
        org.joda.time.DateTimeField dateTimeField9 = offsetDateTimeField6.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (-28800000));
        java.util.Locale locale14 = null;
        int int15 = offsetDateTimeField13.getMaximumShortTextLength(locale14);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField13.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField18 = new org.joda.time.field.DividedDateTimeField(dateTimeField9, dateTimeFieldType16, 153);
        int int20 = dividedDateTimeField18.get((long) '#');
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (-28800000));
        java.util.Locale locale25 = null;
        int int26 = offsetDateTimeField24.getMaximumShortTextLength(locale25);
        org.joda.time.DateTimeField dateTimeField27 = offsetDateTimeField24.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, (-28800000));
        java.util.Locale locale32 = null;
        int int33 = offsetDateTimeField31.getMaximumShortTextLength(locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = offsetDateTimeField31.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(dateTimeField27, dateTimeFieldType34, 153);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField37 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField18, dateTimeFieldType34);
        long long39 = remainderDateTimeField37.roundHalfFloor((-4295408573222000L));
        org.joda.time.Chronology chronology40 = null;
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.DateTimeField dateTimeField43 = julianChronology42.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField45 = new org.joda.time.field.SkipUndoDateTimeField(chronology40, dateTimeField43, 0);
        java.util.Locale locale47 = null;
        java.lang.String str48 = skipUndoDateTimeField45.getAsShortText((int) '4', locale47);
        org.joda.time.MonthDay monthDay50 = new org.joda.time.MonthDay(10L);
        org.joda.time.MonthDay monthDay52 = monthDay50.minusMonths((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone55 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone54);
        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology58 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone57);
        org.joda.time.MonthDay monthDay59 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology58);
        org.joda.time.MonthDay monthDay60 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology58);
        org.joda.time.DateTimeZone dateTimeZone61 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology62 = julianChronology58.withZone(dateTimeZone61);
        org.joda.time.DateTime dateTime63 = org.joda.time.DateTime.now(chronology62);
        org.joda.time.DateTime dateTime65 = dateTime63.plusMillis((int) (short) 0);
        org.joda.time.DateTime dateTime67 = dateTime63.plusYears((int) '#');
        int int68 = dateTimeZone54.getOffset((org.joda.time.ReadableInstant) dateTime63);
        org.joda.time.DateTime dateTime70 = dateTime63.withMinuteOfHour((int) (byte) 1);
        boolean boolean71 = monthDay50.equals((java.lang.Object) (byte) 1);
        org.joda.time.MonthDay monthDay73 = monthDay50.minusDays(153);
        org.joda.time.chrono.ISOChronology iSOChronology74 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField75 = iSOChronology74.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField77 = new org.joda.time.field.OffsetDateTimeField(dateTimeField75, (-28800000));
        java.util.Locale locale78 = null;
        int int79 = offsetDateTimeField77.getMaximumShortTextLength(locale78);
        org.joda.time.DateTimeFieldType dateTimeFieldType80 = offsetDateTimeField77.getType();
        int int81 = monthDay73.indexOf(dateTimeFieldType80);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField82 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField45, dateTimeFieldType80);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField83 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField37, dateTimeFieldType80);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder86 = dateTimeFormatterBuilder0.appendDecimal(dateTimeFieldType80, (-1), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 9 + "'", int33 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-4295406067200000L) + "'", long39 == (-4295406067200000L));
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "52" + "'", str48.equals("52"));
        org.junit.Assert.assertNotNull(monthDay52);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertNotNull(cachedDateTimeZone55);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(julianChronology58);
        org.junit.Assert.assertNotNull(monthDay60);
        org.junit.Assert.assertNotNull(dateTimeZone61);
        org.junit.Assert.assertNotNull(chronology62);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 36000000 + "'", int68 == 36000000);
        org.junit.Assert.assertNotNull(dateTime70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(monthDay73);
        org.junit.Assert.assertNotNull(iSOChronology74);
        org.junit.Assert.assertNotNull(dateTimeField75);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 9 + "'", int79 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + (-1) + "'", int81 == (-1));
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
//        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
//        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
//        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
//        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
//        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
//        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
//        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
//        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.weekOfWeekyear();
//        boolean boolean19 = property12.equals((java.lang.Object) dateTimeField18);
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
//        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology22);
//        org.joda.time.MonthDay monthDay24 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology22);
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology26 = julianChronology22.withZone(dateTimeZone25);
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now(chronology26);
//        org.joda.time.DateTime dateTime29 = dateTime27.minusWeeks(0);
//        org.joda.time.DateTime.Property property30 = dateTime29.millisOfDay();
//        org.joda.time.DateTime dateTime32 = dateTime29.withMillisOfSecond((int) (short) 1);
//        int int33 = property12.getDifference((org.joda.time.ReadableInstant) dateTime32);
//        org.joda.time.DateTime dateTime35 = dateTime32.withDayOfYear(19);
//        org.joda.time.DateTime.Property property36 = dateTime32.millisOfDay();
//        java.lang.String str37 = property36.getAsString();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(monthDay4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(julianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(julianChronology22);
//        org.junit.Assert.assertNotNull(monthDay24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "49772001" + "'", str37.equals("49772001"));
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (short) 1);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter2.withPivotYear((-1));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) 10, (int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        try {
            long long10 = gregorianChronology5.getDateTimeMillis(10, 11, 0, 53335);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        try {
            java.lang.String str4 = dateTime2.toString("year");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: r");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(julianChronology1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) 10, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) 10, (int) (byte) 10);
        org.joda.time.Chronology chronology12 = iSOChronology6.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.Chronology chronology13 = buddhistChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology3);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5);
        org.joda.time.MonthDay monthDay7 = monthDay4.withChronologyRetainFields((org.joda.time.Chronology) julianChronology6);
        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay7);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = monthDay7.getFieldTypes();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone14);
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology15);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.MonthDay monthDay19 = monthDay16.withChronologyRetainFields((org.joda.time.Chronology) julianChronology18);
        java.lang.Class<?> wildcardClass20 = monthDay16.getClass();
        int[] intArray22 = julianChronology11.get((org.joda.time.ReadablePartial) monthDay16, 1L);
        boolean boolean23 = monthDay7.isAfter((org.joda.time.ReadablePartial) monthDay16);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone25);
        org.joda.time.MonthDay monthDay27 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology26);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone28);
        org.joda.time.MonthDay monthDay30 = monthDay27.withChronologyRetainFields((org.joda.time.Chronology) julianChronology29);
        java.lang.Class<?> wildcardClass31 = monthDay27.getClass();
        boolean boolean32 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay27);
        boolean boolean33 = monthDay7.isAfter((org.joda.time.ReadablePartial) monthDay27);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����" + "'", str8.equals("����"));
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(53335, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53335 + "'", int2 == 53335);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, 0);
        long long7 = skipUndoDateTimeField5.roundHalfCeiling((long) (byte) 1);
        long long9 = skipUndoDateTimeField5.roundHalfEven((long) 2004);
        java.lang.String str10 = skipUndoDateTimeField5.getName();
        int int12 = skipUndoDateTimeField5.getLeapAmount((long) 10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hourOfHalfday" + "'", str10.equals("hourOfHalfday"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        org.joda.time.DateTimeField dateTimeField6 = offsetDateTimeField3.getWrappedField();
        int int8 = offsetDateTimeField3.getLeapAmount((long) (byte) 1);
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay(10L);
        org.joda.time.MonthDay monthDay12 = monthDay10.minusMonths((int) (byte) 10);
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay10, (int) (short) 10, locale14);
        long long17 = offsetDateTimeField3.roundHalfEven((long) 422);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10" + "'", str15.equals("10"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.hourOfHalfday();
        org.joda.time.DurationField durationField4 = julianChronology2.hours();
        boolean boolean5 = copticChronology0.equals((java.lang.Object) durationField4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology8);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology8);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology12 = julianChronology8.withZone(dateTimeZone11);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) cachedDateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone15 = cachedDateTimeZone13.getUncachedZone();
        org.joda.time.Chronology chronology16 = copticChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone13);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(chronology16);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now(dateTimeZone1);
//        org.joda.time.MonthDay.Property property3 = monthDay2.dayOfMonth();
//        java.lang.String str4 = property3.getAsText();
//        org.joda.time.MonthDay monthDay6 = property3.addToCopy(1);
//        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay6.getFields();
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.secondOfMinute();
//        org.joda.time.Instant instant11 = gJChronology8.getGregorianCutover();
//        java.lang.String str12 = gJChronology8.toString();
//        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology8);
//        boolean boolean14 = monthDay6.equals((java.lang.Object) chronology13);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "15" + "'", str4.equals("15"));
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "GJChronology[UTC]" + "'", str12.equals("GJChronology[UTC]"));
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        long long6 = offsetDateTimeField3.set((long) (short) 100, "35");
        long long9 = offsetDateTimeField3.getDifferenceAsLong(36000828L, (long) 1);
        long long11 = offsetDateTimeField3.roundCeiling(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 908779154918400100L + "'", long6 == 908779154918400100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology5);
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology9 = julianChronology5.withZone(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(chronology9);
        org.joda.time.DateTime dateTime12 = dateTime10.plusMillis((int) (short) 0);
        org.joda.time.DateTime dateTime14 = dateTime10.plusYears((int) '#');
        int int15 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology18);
        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology22 = julianChronology18.withZone(dateTimeZone21);
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now(chronology22);
        org.joda.time.DateTime dateTime25 = dateTime23.minusWeeks(0);
        org.joda.time.DateTime dateTime27 = dateTime23.plusSeconds(0);
        org.joda.time.DateTime.Property property28 = dateTime27.yearOfCentury();
        org.joda.time.DateTime dateTime29 = property28.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone31);
        org.joda.time.MonthDay monthDay33 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology32);
        org.joda.time.DateTimeField dateTimeField34 = julianChronology32.weekOfWeekyear();
        boolean boolean35 = property28.equals((java.lang.Object) dateTimeField34);
        int int36 = property28.getMaximumValueOverall();
        org.joda.time.DateTime dateTime38 = property28.setCopy((int) (byte) 10);
        int int39 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime38);
        org.joda.time.DateTime dateTime40 = dateTime38.toDateTimeISO();
        org.joda.time.DateTime dateTime42 = dateTime38.minusHours(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 36000000 + "'", int15 == 36000000);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 100 + "'", int36 == 100);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 36000000 + "'", int39 == 36000000);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("35");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendDayOfMonth(61253);
        boolean boolean7 = dateTimeFormatterBuilder6.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1, 3);
        boolean boolean5 = dateTimeZone1.isStandardOffset((long) 133);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatterBuilder0.toPrinter();
        dateTimeFormatterBuilder0.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay(0);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendDayOfWeek(31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendWeekOfWeekyear(30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.MonthDay monthDay6 = monthDay3.withChronologyRetainFields((org.joda.time.Chronology) julianChronology5);
        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.era();
        org.joda.time.Chronology chronology8 = julianChronology5.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (short) 1);
        java.io.Writer writer3 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology6);
        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology10 = julianChronology6.withZone(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(chronology10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusWeeks(0);
        org.joda.time.DateTime dateTime15 = dateTime11.plusHours((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology18);
        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology18);
        org.joda.time.DateTime dateTime21 = dateTime11.toDateTime((org.joda.time.Chronology) julianChronology18);
        org.joda.time.DurationField durationField22 = julianChronology18.weekyears();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((org.joda.time.Chronology) julianChronology18);
        try {
            dateTimeFormatter2.printTo(writer3, (org.joda.time.ReadableInstant) dateTime23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(durationField22);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now(dateTimeZone1);
        org.joda.time.MonthDay.Property property3 = monthDay2.dayOfMonth();
        try {
            org.joda.time.MonthDay monthDay5 = property3.setCopy(1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(10L);
        org.joda.time.MonthDay monthDay3 = monthDay1.minusMonths((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology13 = julianChronology9.withZone(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(chronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusMillis((int) (short) 0);
        org.joda.time.DateTime dateTime18 = dateTime14.plusYears((int) '#');
        int int19 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime21 = dateTime14.withMinuteOfHour((int) (byte) 1);
        boolean boolean22 = monthDay1.equals((java.lang.Object) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter23.withDefaultYear((int) (short) 10);
        java.lang.String str26 = monthDay1.toString(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 36000000 + "'", int19 == 36000000);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "����-W��-�T��:��:��.000" + "'", str26.equals("����-W��-�T��:��:��.000"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        org.joda.time.DateTimeField dateTimeField4 = offsetDateTimeField3.getWrappedField();
        long long6 = offsetDateTimeField3.roundHalfEven((long) 216);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (-28800000));
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField10.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField10.getType();
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField15 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType13, (-49715377));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusHours((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone16);
        org.joda.time.MonthDay monthDay18 = monthDay15.withChronologyRetainFields((org.joda.time.Chronology) julianChronology17);
        java.lang.String str19 = julianChronology17.toString();
        org.joda.time.DateTime dateTime20 = dateTime7.toDateTime((org.joda.time.Chronology) julianChronology17);
        org.joda.time.DateTime dateTime22 = dateTime7.minus(520L);
        org.joda.time.DateTime dateTime24 = dateTime22.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime27 = dateTime22.withDurationAdded((-1193177118L), 49715377);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str19.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology3);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5);
        org.joda.time.MonthDay monthDay7 = monthDay4.withChronologyRetainFields((org.joda.time.Chronology) julianChronology6);
        org.joda.time.MonthDay monthDay9 = monthDay4.withDayOfMonth((int) (byte) 10);
        java.lang.String str10 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay4);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray11 = monthDay4.getFieldTypes();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.MonthDay monthDay14 = monthDay4.withPeriodAdded(readablePeriod12, (int) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "����-���T��:��:��.000" + "'", str10.equals("����-���T��:��:��.000"));
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray11);
        org.junit.Assert.assertNotNull(monthDay14);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
//        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
//        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
//        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
//        int int11 = property10.get();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = property10.getAsShortText(locale12);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(monthDay4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 49774311 + "'", int11 == 49774311);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "49774311" + "'", str13.equals("49774311"));
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.plusMillis((int) (short) 0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusYears((int) '#');
        int int12 = dateTime11.getYearOfCentury();
        org.joda.time.DateTime.Property property13 = dateTime11.weekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 54 + "'", int12 == 54);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        boolean boolean6 = offsetDateTimeField3.isLenient();
        int int7 = offsetDateTimeField3.getMaximumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 263478993 + "'", int7 == 263478993);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("dayOfMonth", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"dayOfMonth/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
//        boolean boolean1 = dateTimeFormatter0.isPrinter();
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
//        org.joda.time.Instant instant6 = gJChronology2.getGregorianCutover();
//        java.lang.String str7 = gJChronology2.toString();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours(10);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
//        boolean boolean14 = cachedDateTimeZone12.isStandardOffset(10L);
//        org.joda.time.Chronology chronology15 = gregorianChronology8.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
//        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology18);
//        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology18);
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology22 = julianChronology18.withZone(dateTimeZone21);
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now(chronology22);
//        org.joda.time.DateTime dateTime25 = dateTime23.minusWeeks(0);
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone26);
//        org.joda.time.DateTimeField dateTimeField28 = julianChronology27.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField29 = julianChronology27.dayOfWeek();
//        int int30 = dateTime25.get(dateTimeField29);
//        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone12, (org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.Chronology chronology32 = gJChronology2.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone12);
//        java.util.TimeZone timeZone33 = null;
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forTimeZone(timeZone33);
//        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone34);
//        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology2, dateTimeZone34);
//        org.joda.time.DateTimeZone dateTimeZone37 = gJChronology2.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = dateTimeFormatter0.withZone(dateTimeZone37);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GJChronology[UTC]" + "'", str7.equals("GJChronology[UTC]"));
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(julianChronology18);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(julianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
//        org.junit.Assert.assertNotNull(gJChronology31);
//        org.junit.Assert.assertNotNull(chronology32);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(copticChronology35);
//        org.junit.Assert.assertNotNull(zonedChronology36);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertNotNull(dateTimeFormatter38);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusHours((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone16);
        org.joda.time.MonthDay monthDay18 = monthDay15.withChronologyRetainFields((org.joda.time.Chronology) julianChronology17);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone20);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology21);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        org.joda.time.MonthDay monthDay25 = monthDay22.withChronologyRetainFields((org.joda.time.Chronology) julianChronology24);
        java.lang.Class<?> wildcardClass26 = monthDay22.getClass();
        long long28 = julianChronology17.set((org.joda.time.ReadablePartial) monthDay22, 10L);
        org.joda.time.DateTime dateTime29 = dateTime7.toDateTime((org.joda.time.Chronology) julianChronology17);
        org.joda.time.Chronology chronology30 = julianChronology17.withUTC();
        org.joda.time.DurationField durationField31 = julianChronology17.eras();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10L + "'", long28 == 10L);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(durationField31);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology5);
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology9 = julianChronology5.withZone(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(chronology9);
        org.joda.time.DateTime dateTime12 = dateTime10.minusWeeks(0);
        org.joda.time.DateTime.Property property13 = dateTime12.millisOfDay();
        org.joda.time.DateTime dateTime15 = dateTime12.plusDays((int) '4');
        int int16 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime12);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-25200000) + "'", int16 == (-25200000));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        boolean boolean6 = offsetDateTimeField3.isLenient();
        int int8 = offsetDateTimeField3.getMinimumValue((-187199990L));
        org.joda.time.DurationField durationField9 = offsetDateTimeField3.getRangeDurationField();
        org.joda.time.DurationField durationField10 = offsetDateTimeField3.getDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (-28800000));
        java.util.Locale locale15 = null;
        int int16 = offsetDateTimeField14.getMaximumShortTextLength(locale15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField14.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (-28800000));
        java.util.Locale locale22 = null;
        int int23 = offsetDateTimeField21.getMaximumShortTextLength(locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField21.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType24, 153);
        int int28 = dividedDateTimeField26.get((long) '#');
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone29);
        org.joda.time.DateTimeField dateTimeField31 = julianChronology30.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology34 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone33);
        org.joda.time.MonthDay monthDay35 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology34);
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone36);
        org.joda.time.MonthDay monthDay38 = monthDay35.withChronologyRetainFields((org.joda.time.Chronology) julianChronology37);
        java.lang.Class<?> wildcardClass39 = monthDay35.getClass();
        int[] intArray41 = julianChronology30.get((org.joda.time.ReadablePartial) monthDay35, 1L);
        int[] intArray48 = new int[] { (byte) 100, 2054, 2054, (short) 1, 2, 54 };
        int int49 = dividedDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) monthDay35, intArray48);
        java.util.Locale locale51 = null;
        java.lang.String str52 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) monthDay35, 10, locale51);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-321075054) + "'", int8 == (-321075054));
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 9 + "'", int16 == 9);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(julianChronology34);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertNotNull(monthDay38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1910320 + "'", int49 == 1910320);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "10" + "'", str52.equals("10"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.plusMillis((int) (short) 0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusMinutes(2004);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, 0);
        long long7 = skipUndoDateTimeField5.roundHalfCeiling((long) (byte) 1);
        long long9 = skipUndoDateTimeField5.roundHalfEven((long) 2004);
        java.util.Locale locale11 = null;
        java.lang.String str12 = skipUndoDateTimeField5.getAsShortText((long) 49715377, locale11);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "5" + "'", str12.equals("5"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) 10, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendHourOfHalfday(20);
        dateTimeFormatterBuilder8.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.MonthDay monthDay6 = monthDay3.withChronologyRetainFields((org.joda.time.Chronology) julianChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology9);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone11);
        org.joda.time.MonthDay monthDay13 = monthDay10.withChronologyRetainFields((org.joda.time.Chronology) julianChronology12);
        java.lang.Class<?> wildcardClass14 = monthDay10.getClass();
        long long16 = julianChronology5.set((org.joda.time.ReadablePartial) monthDay10, 10L);
        org.joda.time.DateTimeField dateTimeField17 = julianChronology5.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology3);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology3);
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology3);
        org.joda.time.DateTimeField dateTimeField7 = julianChronology3.yearOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "+10:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology1.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 2054);
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) offsetDateTimeField6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.field.OffsetDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        java.lang.String str14 = property12.getName();
        int int15 = property12.get();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "yearOfCentury" + "'", str14.equals("yearOfCentury"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 19 + "'", int15 == 19);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property12 = dateTime11.minuteOfDay();
        int int13 = property12.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1439 + "'", int13 == 1439);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) 10, (int) (byte) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
//        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
//        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
//        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
//        org.joda.time.DateTime dateTime11 = dateTime7.plusHours((int) (byte) 1);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
//        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology14);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone16);
//        org.joda.time.MonthDay monthDay18 = monthDay15.withChronologyRetainFields((org.joda.time.Chronology) julianChronology17);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone20);
//        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology21);
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
//        org.joda.time.MonthDay monthDay25 = monthDay22.withChronologyRetainFields((org.joda.time.Chronology) julianChronology24);
//        java.lang.Class<?> wildcardClass26 = monthDay22.getClass();
//        long long28 = julianChronology17.set((org.joda.time.ReadablePartial) monthDay22, 10L);
//        org.joda.time.DateTime dateTime29 = dateTime7.toDateTime((org.joda.time.Chronology) julianChronology17);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
//        java.util.Locale locale31 = dateTimeFormatter30.getLocale();
//        java.lang.String str32 = dateTime7.toString(dateTimeFormatter30);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter30.withOffsetParsed();
//        org.joda.time.Chronology chronology34 = dateTimeFormatter33.getChronology();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(monthDay4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(julianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(julianChronology17);
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(julianChronology21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(julianChronology24);
//        org.junit.Assert.assertNotNull(monthDay25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10L + "'", long28 == 10L);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTimeFormatter30);
//        org.junit.Assert.assertNull(locale31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "13:49:36" + "'", str32.equals("13:49:36"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter33);
//        org.junit.Assert.assertNull(chronology34);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "JulianChronology[America/Los_Angeles]", "GJChronology[UTC]");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "GregorianChronology[America/Los_Angeles]", "JulianChronology[America/Los_Angeles]");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = copticChronology2.minutes();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("2001");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2001\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) 10, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean7 = fixedDateTimeZone4.equals((java.lang.Object) false);
        long long9 = fixedDateTimeZone4.previousTransition((long) ' ');
        java.lang.String str11 = fixedDateTimeZone4.getNameKey(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long14 = fixedDateTimeZone4.previousTransition((long) 54);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) 10, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        long long24 = iSOChronology20.add((long) 6, (long) 36000000, 0);
        org.joda.time.DurationField durationField25 = iSOChronology20.days();
        boolean boolean26 = fixedDateTimeZone4.equals((java.lang.Object) iSOChronology20);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 32L + "'", long9 == 32L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 54L + "'", long14 == 54L);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 6L + "'", long24 == 6L);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(10L);
        org.joda.time.MonthDay monthDay3 = monthDay1.minusMonths((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology13 = julianChronology9.withZone(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(chronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusMillis((int) (short) 0);
        org.joda.time.DateTime dateTime18 = dateTime14.plusYears((int) '#');
        int int19 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime21 = dateTime14.withMinuteOfHour((int) (byte) 1);
        boolean boolean22 = monthDay1.equals((java.lang.Object) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology24 = buddhistChronology23.withUTC();
        org.joda.time.MonthDay monthDay25 = monthDay1.withChronologyRetainFields((org.joda.time.Chronology) buddhistChronology23);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.MonthDay monthDay28 = monthDay25.withPeriodAdded(readablePeriod26, (-28800000));
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 36000000 + "'", int19 == 36000000);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(buddhistChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(monthDay28);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now(dateTimeZone1);
//        org.joda.time.MonthDay.Property property3 = monthDay2.dayOfMonth();
//        java.lang.String str4 = property3.getAsText();
//        int int5 = property3.get();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
//        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology8);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology8);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology12 = julianChronology8.withZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(chronology12);
//        org.joda.time.DateTime dateTime15 = dateTime13.minusWeeks(0);
//        org.joda.time.DateTime dateTime17 = dateTime13.plusHours((int) (byte) 1);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
//        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology20);
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone22);
//        org.joda.time.MonthDay monthDay24 = monthDay21.withChronologyRetainFields((org.joda.time.Chronology) julianChronology23);
//        java.lang.String str25 = julianChronology23.toString();
//        org.joda.time.DateTime dateTime26 = dateTime13.toDateTime((org.joda.time.Chronology) julianChronology23);
//        org.joda.time.DateTime.Property property27 = dateTime26.millisOfSecond();
//        int int28 = property3.compareTo((org.joda.time.ReadableInstant) dateTime26);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "15" + "'", str4.equals("15"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(julianChronology8);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(julianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(julianChronology23);
//        org.junit.Assert.assertNotNull(monthDay24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str25.equals("JulianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = copticChronology2.toString();
        java.lang.String str4 = copticChronology2.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str3.equals("CopticChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str4.equals("CopticChronology[America/Los_Angeles]"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((-187199990L));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, 0);
        int int7 = skipUndoDateTimeField5.getMinimumValue((long) 10);
        int int9 = skipUndoDateTimeField5.getLeapAmount(10L);
        int int11 = skipUndoDateTimeField5.getLeapAmount(0L);
        long long14 = skipUndoDateTimeField5.add(1560631704437L, 1560631716330L);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone16);
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology17);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.MonthDay monthDay21 = monthDay18.withChronologyRetainFields((org.joda.time.Chronology) julianChronology20);
        org.joda.time.MonthDay monthDay23 = monthDay18.withDayOfMonth((int) (byte) 10);
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.MonthDay monthDay25 = monthDay18.plus(readablePeriod24);
        int int26 = skipUndoDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) monthDay18);
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone29);
        org.joda.time.MonthDay monthDay31 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology30);
        org.joda.time.DateTimeField dateTimeField32 = julianChronology30.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField33 = julianChronology30.hourOfDay();
        org.joda.time.MonthDay monthDay34 = new org.joda.time.MonthDay((long) 153, (org.joda.time.Chronology) julianChronology30);
        org.joda.time.MonthDay monthDay35 = monthDay18.withChronologyRetainFields((org.joda.time.Chronology) julianChronology30);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 5618275739419704437L + "'", long14 == 5618275739419704437L);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(monthDay35);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (short) 0, 0, 0, (int) (short) 10, (int) '4', 61253, 4, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 61253 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.MonthDay monthDay6 = monthDay3.withChronologyRetainFields((org.joda.time.Chronology) julianChronology5);
        org.joda.time.MonthDay monthDay8 = monthDay3.withDayOfMonth((int) (byte) 10);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay10 = monthDay3.plus(readablePeriod9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology13);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = monthDay14.withChronologyRetainFields((org.joda.time.Chronology) julianChronology16);
        org.joda.time.MonthDay monthDay19 = monthDay14.withDayOfMonth((int) (byte) 10);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.MonthDay monthDay21 = monthDay14.plus(readablePeriod20);
        boolean boolean22 = monthDay10.isEqual((org.joda.time.ReadablePartial) monthDay14);
        org.joda.time.DurationFieldType durationFieldType23 = null;
        try {
            org.joda.time.MonthDay monthDay25 = monthDay14.withFieldAdded(durationFieldType23, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.withDayOfMonth(11);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = julianChronology12.hourOfHalfday();
        org.joda.time.DurationField durationField14 = julianChronology12.hours();
        boolean boolean15 = copticChronology10.equals((java.lang.Object) durationField14);
        org.joda.time.DateTime dateTime16 = dateTime9.withChronology((org.joda.time.Chronology) copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        boolean boolean14 = property12.isLeap();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusHours((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology14);
        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology14);
        org.joda.time.DateTime dateTime17 = dateTime7.toDateTime((org.joda.time.Chronology) julianChronology14);
        org.joda.time.DateTime dateTime18 = dateTime17.withEarlierOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withZone(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        long long6 = offsetDateTimeField3.set((long) (short) 100, "35");
        long long9 = offsetDateTimeField3.getDifferenceAsLong(36000828L, (long) 1);
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay(10L);
        org.joda.time.MonthDay monthDay13 = monthDay11.minusMonths((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology19);
        org.joda.time.MonthDay monthDay21 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology19);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology23 = julianChronology19.withZone(dateTimeZone22);
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now(chronology23);
        org.joda.time.DateTime dateTime26 = dateTime24.plusMillis((int) (short) 0);
        org.joda.time.DateTime dateTime28 = dateTime24.plusYears((int) '#');
        int int29 = dateTimeZone15.getOffset((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime31 = dateTime24.withMinuteOfHour((int) (byte) 1);
        boolean boolean32 = monthDay11.equals((java.lang.Object) (byte) 1);
        org.joda.time.MonthDay monthDay34 = monthDay11.minusDays(153);
        int int35 = offsetDateTimeField3.getMaximumValue((org.joda.time.ReadablePartial) monthDay11);
        org.joda.time.MonthDay monthDay37 = new org.joda.time.MonthDay(10L);
        org.joda.time.MonthDay monthDay39 = monthDay37.minusMonths((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology41 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone40);
        org.joda.time.DateTimeField dateTimeField42 = julianChronology41.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology45 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone44);
        org.joda.time.MonthDay monthDay46 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology45);
        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology48 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone47);
        org.joda.time.MonthDay monthDay49 = monthDay46.withChronologyRetainFields((org.joda.time.Chronology) julianChronology48);
        java.lang.Class<?> wildcardClass50 = monthDay46.getClass();
        int[] intArray52 = julianChronology41.get((org.joda.time.ReadablePartial) monthDay46, 1L);
        boolean boolean53 = monthDay39.equals((java.lang.Object) monthDay46);
        boolean boolean54 = monthDay11.isEqual((org.joda.time.ReadablePartial) monthDay46);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray55 = monthDay46.getFieldTypes();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 908779154918400100L + "'", long6 == 908779154918400100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 36000000 + "'", int29 == 36000000);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 263478993 + "'", int35 == 263478993);
        org.junit.Assert.assertNotNull(monthDay39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(julianChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(julianChronology45);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(julianChronology48);
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray55);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        try {
            long long8 = copticChronology0.getDateTimeMillis(49737830, 19, 0, 3, 1439, (-321075054), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1439 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.weekOfWeekyear();
        boolean boolean19 = property12.equals((java.lang.Object) dateTimeField18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology22);
        org.joda.time.MonthDay monthDay24 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology26 = julianChronology22.withZone(dateTimeZone25);
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now(chronology26);
        org.joda.time.DateTime dateTime29 = dateTime27.minusWeeks(0);
        org.joda.time.DateTime.Property property30 = dateTime29.millisOfDay();
        org.joda.time.DateTime dateTime32 = dateTime29.withMillisOfSecond((int) (short) 1);
        int int33 = property12.getDifference((org.joda.time.ReadableInstant) dateTime32);
        org.joda.time.DateTime dateTime34 = property12.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime36 = dateTime34.plusHours(13);
        java.util.TimeZone timeZone37 = null;
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forTimeZone(timeZone37);
        org.joda.time.chrono.CopticChronology copticChronology39 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone38);
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTime dateTime41 = dateTime36.withZone(dateTimeZone38);
        long long45 = dateTimeZone38.convertLocalToUTC((-1L), true, 1560631734235L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(copticChronology39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 28799999L + "'", long45 == 28799999L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.MonthDay monthDay6 = monthDay3.withChronologyRetainFields((org.joda.time.Chronology) julianChronology5);
        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.era();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (-28800000));
        java.util.Locale locale12 = null;
        int int13 = offsetDateTimeField11.getMaximumShortTextLength(locale12);
        boolean boolean14 = offsetDateTimeField11.isLenient();
        int int16 = offsetDateTimeField11.getMinimumValue((-187199990L));
        org.joda.time.DurationField durationField17 = offsetDateTimeField11.getRangeDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology5, (org.joda.time.DateTimeField) offsetDateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-321075054) + "'", int16 == (-321075054));
        org.junit.Assert.assertNull(durationField17);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        java.lang.String str3 = dateTimeZone1.getShortName(0L);
        java.lang.String str5 = dateTimeZone1.getName((long) 54);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+10:00" + "'", str3.equals("+10:00"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+10:00" + "'", str5.equals("+10:00"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.plusMillis((int) (short) 0);
        org.joda.time.DateTime dateTime10 = dateTime7.toDateTime();
        org.joda.time.DateTime dateTime12 = dateTime10.minusMillis(49715377);
        int int13 = dateTime10.getWeekyear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1969 + "'", int13 == 1969);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        org.joda.time.DateTimeField dateTimeField6 = offsetDateTimeField3.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (-28800000));
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField10.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField10.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField15 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType13, 153);
        int int17 = dividedDateTimeField15.get((long) '#');
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (-28800000));
        java.util.Locale locale22 = null;
        int int23 = offsetDateTimeField21.getMaximumShortTextLength(locale22);
        org.joda.time.DateTimeField dateTimeField24 = offsetDateTimeField21.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (-28800000));
        java.util.Locale locale29 = null;
        int int30 = offsetDateTimeField28.getMaximumShortTextLength(locale29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField24, dateTimeFieldType31, 153);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField34 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField15, dateTimeFieldType31);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone35);
        org.joda.time.DateTimeField dateTimeField37 = julianChronology36.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology40 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone39);
        org.joda.time.MonthDay monthDay41 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology40);
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology43 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone42);
        org.joda.time.MonthDay monthDay44 = monthDay41.withChronologyRetainFields((org.joda.time.Chronology) julianChronology43);
        java.lang.Class<?> wildcardClass45 = monthDay41.getClass();
        int[] intArray47 = julianChronology36.get((org.joda.time.ReadablePartial) monthDay41, 1L);
        org.joda.time.DurationField durationField48 = julianChronology36.minutes();
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology51 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone50);
        org.joda.time.MonthDay monthDay52 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology51);
        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology54 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone53);
        org.joda.time.MonthDay monthDay55 = monthDay52.withChronologyRetainFields((org.joda.time.Chronology) julianChronology54);
        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology58 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone57);
        org.joda.time.MonthDay monthDay59 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology58);
        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology61 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone60);
        org.joda.time.MonthDay monthDay62 = monthDay59.withChronologyRetainFields((org.joda.time.Chronology) julianChronology61);
        java.lang.Class<?> wildcardClass63 = monthDay59.getClass();
        long long65 = julianChronology54.set((org.joda.time.ReadablePartial) monthDay59, 10L);
        org.joda.time.DurationField durationField66 = julianChronology54.years();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField67 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType31, durationField48, durationField66);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range duration field must be precise");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(julianChronology40);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(julianChronology43);
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(julianChronology51);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(julianChronology54);
        org.junit.Assert.assertNotNull(monthDay55);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(julianChronology58);
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertNotNull(julianChronology61);
        org.junit.Assert.assertNotNull(monthDay62);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 10L + "'", long65 == 10L);
        org.junit.Assert.assertNotNull(durationField66);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.weekOfWeekyear();
        boolean boolean19 = property12.equals((java.lang.Object) dateTimeField18);
        org.joda.time.DateTime dateTime20 = property12.withMinimumValue();
        org.joda.time.DateTime dateTime21 = property12.roundHalfEvenCopy();
        java.lang.String str22 = property12.getAsString();
        java.util.Locale locale23 = null;
        java.lang.String str24 = property12.getAsText(locale23);
        org.joda.time.DurationField durationField25 = property12.getLeapDurationField();
        org.joda.time.DateTime dateTime26 = property12.roundFloorCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "69" + "'", str22.equals("69"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "69" + "'", str24.equals("69"));
        org.junit.Assert.assertNull(durationField25);
        org.junit.Assert.assertNotNull(dateTime26);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(10L);
        java.util.Locale locale3 = null;
        java.lang.String str4 = monthDay1.toString("+10:00", locale3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology7);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone10);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology11);
        org.joda.time.MonthDay monthDay13 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology11);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology15 = julianChronology11.withZone(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(chronology15);
        org.joda.time.DateTime dateTime18 = dateTime16.minusWeeks(0);
        org.joda.time.DateTime dateTime20 = dateTime16.plusHours((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone22);
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology23);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone25);
        org.joda.time.MonthDay monthDay27 = monthDay24.withChronologyRetainFields((org.joda.time.Chronology) julianChronology26);
        java.lang.String str28 = julianChronology26.toString();
        org.joda.time.DateTime dateTime29 = dateTime16.toDateTime((org.joda.time.Chronology) julianChronology26);
        org.joda.time.DateTime dateTime30 = monthDay8.toDateTime((org.joda.time.ReadableInstant) dateTime29);
        boolean boolean31 = monthDay1.isBefore((org.joda.time.ReadablePartial) monthDay8);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+10:00" + "'", str4.equals("+10:00"));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str28.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 9, (java.lang.Number) 9L, (java.lang.Number) 45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology5);
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology9 = julianChronology5.withZone(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(chronology9);
        org.joda.time.DateTime dateTime12 = dateTime10.plusMillis((int) (short) 0);
        org.joda.time.DateTime dateTime14 = dateTime10.plusYears((int) '#');
        int int15 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology18);
        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology22 = julianChronology18.withZone(dateTimeZone21);
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now(chronology22);
        org.joda.time.DateTime dateTime25 = dateTime23.minusWeeks(0);
        org.joda.time.DateTime dateTime27 = dateTime23.plusSeconds(0);
        org.joda.time.DateTime.Property property28 = dateTime27.yearOfCentury();
        org.joda.time.DateTime dateTime29 = property28.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone31);
        org.joda.time.MonthDay monthDay33 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology32);
        org.joda.time.DateTimeField dateTimeField34 = julianChronology32.weekOfWeekyear();
        boolean boolean35 = property28.equals((java.lang.Object) dateTimeField34);
        int int36 = property28.getMaximumValueOverall();
        org.joda.time.DateTime dateTime38 = property28.setCopy((int) (byte) 10);
        int int39 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime38);
        org.joda.time.DateTime dateTime40 = dateTime38.toDateTimeISO();
        org.joda.time.MutableDateTime mutableDateTime41 = dateTime38.toMutableDateTimeISO();
        int int42 = dateTime38.getMonthOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 36000000 + "'", int15 == 36000000);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 100 + "'", int36 == 100);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 36000000 + "'", int39 == 36000000);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(mutableDateTime41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 12 + "'", int42 == 12);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.weekOfWeekyear();
        boolean boolean19 = property12.equals((java.lang.Object) dateTimeField18);
        int int20 = property12.getMaximumValueOverall();
        org.joda.time.DateTime dateTime22 = property12.setCopy((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone23 = dateTime22.getZone();
        org.joda.time.DateTime.Property property24 = dateTime22.monthOfYear();
        org.joda.time.DateTime.Property property25 = dateTime22.secondOfMinute();
        java.lang.String str26 = property25.getAsString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.weekOfWeekyear();
        boolean boolean19 = property12.equals((java.lang.Object) dateTimeField18);
        int int20 = property12.getMaximumValueOverall();
        org.joda.time.DateTime dateTime22 = property12.setCopy((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone23 = dateTime22.getZone();
        int int24 = dateTime22.getDayOfWeek();
        org.joda.time.DateTime dateTime26 = dateTime22.minus((long) 1);
        org.joda.time.DateTime dateTime28 = dateTime26.minusSeconds(1261);
        org.joda.time.DateTime.Property property29 = dateTime28.dayOfWeek();
        java.lang.String str30 = property29.getName();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "dayOfWeek" + "'", str30.equals("dayOfWeek"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        org.joda.time.DateTimeField dateTimeField6 = offsetDateTimeField3.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (-28800000));
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField10.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField10.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField15 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType13, 153);
        int int17 = dividedDateTimeField15.get((long) '#');
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (-28800000));
        java.util.Locale locale22 = null;
        int int23 = offsetDateTimeField21.getMaximumShortTextLength(locale22);
        org.joda.time.DateTimeField dateTimeField24 = offsetDateTimeField21.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (-28800000));
        java.util.Locale locale29 = null;
        int int30 = offsetDateTimeField28.getMaximumShortTextLength(locale29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField24, dateTimeFieldType31, 153);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField34 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField15, dateTimeFieldType31);
        long long36 = remainderDateTimeField34.roundHalfFloor((-4295408573222000L));
        long long38 = remainderDateTimeField34.roundCeiling((long) 49733542);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-4295406067200000L) + "'", long36 == (-4295406067200000L));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 31536000000L + "'", long38 == 31536000000L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.MonthDay monthDay6 = monthDay3.withChronologyRetainFields((org.joda.time.Chronology) julianChronology5);
        org.joda.time.MonthDay monthDay8 = monthDay3.withDayOfMonth((int) (byte) 10);
        org.joda.time.MonthDay monthDay10 = monthDay8.withMonthOfYear(4);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(monthDay10);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral('a');
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildPrinter();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusHours((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology14);
        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology14);
        org.joda.time.DateTime dateTime17 = dateTime7.toDateTime((org.joda.time.Chronology) julianChronology14);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendMillisOfSecond((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder18.appendMinuteOfDay(13);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder18.appendMinuteOfHour(1910473);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (-28800000));
        java.util.Locale locale29 = null;
        int int30 = offsetDateTimeField28.getMaximumShortTextLength(locale29);
        org.joda.time.DateTimeField dateTimeField31 = offsetDateTimeField28.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology32.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, (-28800000));
        java.util.Locale locale36 = null;
        int int37 = offsetDateTimeField35.getMaximumShortTextLength(locale36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField35.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(dateTimeField31, dateTimeFieldType38, 153);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder18.appendSignedDecimal(dateTimeFieldType38, 49733542, 0);
        int int44 = dateTime7.get(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(iSOChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 9 + "'", int37 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1969 + "'", int44 == 1969);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        boolean boolean9 = cachedDateTimeZone7.isStandardOffset(10L);
        java.lang.String str11 = cachedDateTimeZone7.getName(0L);
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((-28798030), (int) '4', 86399999, 2004, 1969, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2004 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+10:00" + "'", str11.equals("+10:00"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        org.joda.time.DateMidnight dateMidnight11 = dateTime9.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime9.plus(readableDuration12);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime9.minus(readableDuration14);
        org.joda.time.DateTime dateTime17 = dateTime15.plusWeeks(216);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateMidnight11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        org.joda.time.DateTimeField dateTimeField6 = offsetDateTimeField3.getWrappedField();
        int int8 = offsetDateTimeField3.getLeapAmount((long) (byte) 1);
        java.lang.String str9 = offsetDateTimeField3.getName();
        int int11 = offsetDateTimeField3.getMinimumValue((long) 15);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "year" + "'", str9.equals("year"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-321075054) + "'", int11 == (-321075054));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, 0);
        int int7 = skipUndoDateTimeField5.getMinimumValue((long) 10);
        long long9 = skipUndoDateTimeField5.roundHalfFloor(10L);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone11);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology12);
        org.joda.time.MonthDay monthDay15 = monthDay13.plusMonths((int) (byte) 100);
        java.util.Locale locale16 = null;
        try {
            java.lang.String str17 = skipUndoDateTimeField5.getAsText((org.joda.time.ReadablePartial) monthDay15, locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'hourOfHalfday' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(monthDay15);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology4);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) monthDay5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(julianChronology4);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(0);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder2.addCutover(216, 'a', 0, (int) '#', 422, false, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = julianChronology2.weekOfWeekyear();
        org.joda.time.Chronology chronology5 = julianChronology2.withUTC();
        try {
            long long10 = julianChronology2.getDateTimeMillis(61253, (int) (short) 100, (int) (short) -1, 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.util.Calendar calendar0 = null;
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.fromCalendarFields(calendar0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The calendar must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) 10, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean7 = fixedDateTimeZone4.equals((java.lang.Object) false);
        long long9 = fixedDateTimeZone4.previousTransition((long) ' ');
        java.lang.String str11 = fixedDateTimeZone4.getNameKey(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long14 = fixedDateTimeZone4.previousTransition((long) 54);
        java.util.TimeZone timeZone15 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 32L + "'", long9 == 32L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 54L + "'", long14 == 54L);
        org.junit.Assert.assertNotNull(timeZone15);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("13:48:35", (java.lang.Number) 1.0f, (java.lang.Number) 100.0d, (java.lang.Number) 100L);
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        java.lang.String str6 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.String str7 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0" + "'", str7.equals("1.0"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.MonthDay monthDay6 = monthDay3.withChronologyRetainFields((org.joda.time.Chronology) julianChronology5);
        org.joda.time.MonthDay monthDay8 = monthDay3.withDayOfMonth((int) (byte) 10);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay10 = monthDay3.plus(readablePeriod9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology13);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = monthDay14.withChronologyRetainFields((org.joda.time.Chronology) julianChronology16);
        org.joda.time.MonthDay monthDay19 = monthDay14.withDayOfMonth((int) (byte) 10);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.MonthDay monthDay21 = monthDay14.plus(readablePeriod20);
        boolean boolean22 = monthDay10.isEqual((org.joda.time.ReadablePartial) monthDay14);
        org.joda.time.MonthDay monthDay24 = monthDay10.plusDays(86399999);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(monthDay24);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology3);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology7 = julianChronology3.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(chronology7);
        org.joda.time.DateTime dateTime10 = dateTime8.minusWeeks(0);
        org.joda.time.DateTime dateTime12 = dateTime8.plusHours((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone14);
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology15);
        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology15);
        org.joda.time.DateTime dateTime18 = dateTime8.toDateTime((org.joda.time.Chronology) julianChronology15);
        org.joda.time.DateTime dateTime19 = dateTime18.withEarlierOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology22);
        org.joda.time.MonthDay monthDay24 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology26 = julianChronology22.withZone(dateTimeZone25);
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now(chronology26);
        org.joda.time.DateTime dateTime29 = dateTime27.minusWeeks(0);
        org.joda.time.DateTime dateTime31 = dateTime27.plusSeconds(0);
        org.joda.time.DateTime.Property property32 = dateTime31.yearOfCentury();
        org.joda.time.DateTime dateTime33 = property32.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone35);
        org.joda.time.MonthDay monthDay37 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology36);
        org.joda.time.DateTimeField dateTimeField38 = julianChronology36.weekOfWeekyear();
        boolean boolean39 = property32.equals((java.lang.Object) dateTimeField38);
        int int40 = property32.getMaximumValueOverall();
        org.joda.time.DateTime dateTime42 = property32.setCopy((int) (byte) 10);
        org.joda.time.DateTime dateTime44 = dateTime42.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property45 = dateTime42.year();
        org.joda.time.DateTime dateTime47 = dateTime42.minusWeeks((int) (byte) 0);
        try {
            org.joda.time.chrono.LimitChronology limitChronology48 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology0, (org.joda.time.ReadableDateTime) dateTime18, (org.joda.time.ReadableDateTime) dateTime42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 100 + "'", int40 == 100);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTime47);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) (short) 10);
        boolean boolean3 = dateTimeFormatter2.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfMinute();
        org.joda.time.Instant instant3 = gJChronology0.getGregorianCutover();
        java.lang.String str4 = gJChronology0.toString();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) 10, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = cachedDateTimeZone15.getUncachedZone();
        org.joda.time.Chronology chronology17 = iSOChronology11.withZone(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology11.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField18, 828);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GJChronology[UTC]" + "'", str4.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay(0);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendDayOfWeek(31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) 10, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) 10, (int) (byte) 10);
        org.joda.time.Chronology chronology11 = iSOChronology5.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        long long15 = cachedDateTimeZone12.adjustOffset(0L, false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, 0);
        int int7 = skipUndoDateTimeField5.getMinimumValue((long) 10);
        int int9 = skipUndoDateTimeField5.getLeapAmount(10L);
        int int11 = skipUndoDateTimeField5.getLeapAmount(0L);
        boolean boolean12 = skipUndoDateTimeField5.isLenient();
        org.joda.time.DurationField durationField13 = skipUndoDateTimeField5.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        boolean boolean2 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology3);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5);
        org.joda.time.MonthDay monthDay7 = monthDay4.withChronologyRetainFields((org.joda.time.Chronology) julianChronology6);
        java.lang.String str8 = julianChronology6.toString();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.weekyearOfCentury();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) julianChronology6);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(10L);
        int[] intArray14 = julianChronology6.get((org.joda.time.ReadablePartial) monthDay12, (long) 13);
        org.joda.time.DateTimeField dateTimeField15 = julianChronology6.secondOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str8.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = julianChronology2.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology7);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9);
        org.joda.time.MonthDay monthDay11 = monthDay8.withChronologyRetainFields((org.joda.time.Chronology) julianChronology10);
        long long13 = julianChronology2.set((org.joda.time.ReadablePartial) monthDay11, (long) 1);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology20 = julianChronology16.withZone(dateTimeZone19);
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now(chronology20);
        org.joda.time.DateTime dateTime23 = dateTime21.minusWeeks(0);
        org.joda.time.DateTime dateTime25 = dateTime21.plusSeconds(0);
        long long26 = dateTime25.getMillis();
        org.joda.time.DateTime.Property property27 = dateTime25.year();
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone29);
        org.joda.time.MonthDay monthDay31 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology30);
        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology30);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology34 = julianChronology30.withZone(dateTimeZone33);
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(chronology34);
        org.joda.time.DateTime dateTime37 = dateTime35.minusWeeks(0);
        org.joda.time.DateTime dateTime39 = dateTime35.plusSeconds(0);
        org.joda.time.DateTime.Property property40 = dateTime39.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = property40.getFieldType();
        int int42 = dateTime25.get(dateTimeFieldType41);
        boolean boolean43 = monthDay11.isSupported(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-187199990L) + "'", long26 == (-187199990L));
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 69 + "'", int42 == 69);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        boolean boolean6 = offsetDateTimeField3.isLenient();
        int int8 = offsetDateTimeField3.getMinimumValue((-187199990L));
        long long10 = offsetDateTimeField3.roundFloor((long) 1910473);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-321075054) + "'", int8 == (-321075054));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.weekOfWeekyear();
        boolean boolean19 = property12.equals((java.lang.Object) dateTimeField18);
        int int20 = property12.getMaximumValueOverall();
        org.joda.time.DateTime dateTime22 = property12.setCopy((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField25 = julianChronology24.days();
        boolean boolean26 = property12.equals((java.lang.Object) durationField25);
        org.joda.time.DateTime dateTime27 = property12.roundHalfCeilingCopy();
        java.util.Date date28 = dateTime27.toDate();
        boolean boolean30 = dateTime27.isEqual(54L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology4);
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology8 = julianChronology4.withZone(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(chronology8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusWeeks(0);
        org.joda.time.DateTime dateTime13 = dateTime9.plusHours((int) (byte) 1);
        org.joda.time.DateTime.Property property14 = dateTime13.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone16);
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology17);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.MonthDay monthDay21 = monthDay18.withChronologyRetainFields((org.joda.time.Chronology) julianChronology20);
        java.lang.String str22 = julianChronology20.toString();
        org.joda.time.DateTimeField dateTimeField23 = julianChronology20.weekyearOfCentury();
        long long27 = julianChronology20.add((long) 153, (-81L), (int) (byte) 0);
        org.joda.time.DateTime dateTime28 = dateTime13.toDateTime((org.joda.time.Chronology) julianChronology20);
        java.lang.String str29 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str22.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 153L + "'", long27 == 153L);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1969-350T13:00:00.010-08:00" + "'", str29.equals("1969-350T13:00:00.010-08:00"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.dayOfMonth();
        org.joda.time.Instant instant4 = gJChronology0.getGregorianCutover();
        java.lang.String str5 = gJChronology0.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        boolean boolean12 = cachedDateTimeZone10.isStandardOffset(10L);
        org.joda.time.Chronology chronology13 = gregorianChronology6.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology20 = julianChronology16.withZone(dateTimeZone19);
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now(chronology20);
        org.joda.time.DateTime dateTime23 = dateTime21.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone24);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology25.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField27 = julianChronology25.dayOfWeek();
        int int28 = dateTime23.get(dateTimeField27);
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone10, (org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.Chronology chronology30 = gJChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone10);
        java.util.TimeZone timeZone31 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forTimeZone(timeZone31);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        org.joda.time.chrono.ZonedChronology zonedChronology34 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = gJChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField36 = gJChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GJChronology[UTC]" + "'", str5.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(zonedChronology34);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(dateTimeField36);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        java.lang.String str2 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        org.joda.time.DateTimeField dateTimeField6 = offsetDateTimeField3.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (-28800000));
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField10.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField10.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField15 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType13, 153);
        int int17 = dividedDateTimeField15.get((long) '#');
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (-28800000));
        java.util.Locale locale22 = null;
        int int23 = offsetDateTimeField21.getMaximumShortTextLength(locale22);
        org.joda.time.DateTimeField dateTimeField24 = offsetDateTimeField21.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (-28800000));
        java.util.Locale locale29 = null;
        int int30 = offsetDateTimeField28.getMaximumShortTextLength(locale29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField24, dateTimeFieldType31, 153);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField34 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField15, dateTimeFieldType31);
        long long36 = remainderDateTimeField34.roundHalfFloor((-4295408573222000L));
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology39 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = julianChronology39.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField(chronology37, dateTimeField40, 0);
        java.util.Locale locale44 = null;
        java.lang.String str45 = skipUndoDateTimeField42.getAsShortText((int) '4', locale44);
        org.joda.time.MonthDay monthDay47 = new org.joda.time.MonthDay(10L);
        org.joda.time.MonthDay monthDay49 = monthDay47.minusMonths((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone52 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone51);
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology55 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone54);
        org.joda.time.MonthDay monthDay56 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology55);
        org.joda.time.MonthDay monthDay57 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology55);
        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology59 = julianChronology55.withZone(dateTimeZone58);
        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now(chronology59);
        org.joda.time.DateTime dateTime62 = dateTime60.plusMillis((int) (short) 0);
        org.joda.time.DateTime dateTime64 = dateTime60.plusYears((int) '#');
        int int65 = dateTimeZone51.getOffset((org.joda.time.ReadableInstant) dateTime60);
        org.joda.time.DateTime dateTime67 = dateTime60.withMinuteOfHour((int) (byte) 1);
        boolean boolean68 = monthDay47.equals((java.lang.Object) (byte) 1);
        org.joda.time.MonthDay monthDay70 = monthDay47.minusDays(153);
        org.joda.time.chrono.ISOChronology iSOChronology71 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField72 = iSOChronology71.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField74 = new org.joda.time.field.OffsetDateTimeField(dateTimeField72, (-28800000));
        java.util.Locale locale75 = null;
        int int76 = offsetDateTimeField74.getMaximumShortTextLength(locale75);
        org.joda.time.DateTimeFieldType dateTimeFieldType77 = offsetDateTimeField74.getType();
        int int78 = monthDay70.indexOf(dateTimeFieldType77);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField79 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField42, dateTimeFieldType77);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField80 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField34, dateTimeFieldType77);
        int int81 = remainderDateTimeField34.getDivisor();
        long long84 = remainderDateTimeField34.getDifferenceAsLong(53242L, (long) (-28800000));
        int int85 = remainderDateTimeField34.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-4295406067200000L) + "'", long36 == (-4295406067200000L));
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(julianChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "52" + "'", str45.equals("52"));
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertNotNull(cachedDateTimeZone52);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertNotNull(julianChronology55);
        org.junit.Assert.assertNotNull(monthDay57);
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertNotNull(chronology59);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 36000000 + "'", int65 == 36000000);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(monthDay70);
        org.junit.Assert.assertNotNull(iSOChronology71);
        org.junit.Assert.assertNotNull(dateTimeField72);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 9 + "'", int76 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-1) + "'", int78 == (-1));
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 153 + "'", int81 == 153);
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 0L + "'", long84 == 0L);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.weekOfWeekyear();
        boolean boolean19 = property12.equals((java.lang.Object) dateTimeField18);
        int int20 = property12.getMaximumValueOverall();
        org.joda.time.DateTime dateTime22 = property12.setCopy((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField25 = julianChronology24.days();
        boolean boolean26 = property12.equals((java.lang.Object) durationField25);
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        org.joda.time.DurationField durationField29 = julianChronology28.days();
        boolean boolean30 = property12.equals((java.lang.Object) julianChronology28);
        org.joda.time.DateTime dateTime31 = property12.withMaximumValue();
        org.joda.time.DateTime dateTime32 = property12.roundFloorCopy();
        org.joda.time.DateTime dateTime34 = property12.addToCopy((long) 828);
        org.joda.time.DateTime dateTime35 = property12.getDateTime();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime35);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        int int11 = property10.get();
        org.joda.time.Instant instant13 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.Instant instant16 = instant13.withDurationAdded(readableDuration14, 13);
        long long17 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) instant16);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property10.getFieldType();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 43200010 + "'", int11 == 43200010);
        org.junit.Assert.assertNotNull(instant16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-187200087L) + "'", long17 == (-187200087L));
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        try {
            org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((int) (short) 1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, 0);
        long long7 = skipUndoDateTimeField5.roundHalfCeiling((long) (byte) 1);
        long long9 = skipUndoDateTimeField5.roundHalfEven((long) 2004);
        long long11 = skipUndoDateTimeField5.roundHalfFloor((long) 54);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField5.getRangeDurationField();
        long long14 = skipUndoDateTimeField5.roundHalfCeiling((-4295408573222000L));
        java.util.Locale locale16 = null;
        java.lang.String str17 = skipUndoDateTimeField5.getAsText(0, locale16);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology20);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone22);
        org.joda.time.MonthDay monthDay24 = monthDay21.withChronologyRetainFields((org.joda.time.Chronology) julianChronology23);
        org.joda.time.MonthDay monthDay26 = monthDay21.withDayOfMonth((int) (byte) 10);
        java.util.Locale locale28 = null;
        java.lang.String str29 = skipUndoDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) monthDay21, 828, locale28);
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology30.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (-28800000));
        java.util.Locale locale34 = null;
        int int35 = offsetDateTimeField33.getMaximumShortTextLength(locale34);
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField33.getAsText(readablePartial36, (int) '#', locale38);
        boolean boolean41 = offsetDateTimeField33.isLeap((long) 19);
        java.lang.String str43 = offsetDateTimeField33.getAsText((long) 1261);
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology46 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone45);
        org.joda.time.MonthDay monthDay47 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology46);
        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology49 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone48);
        org.joda.time.MonthDay monthDay50 = monthDay47.withChronologyRetainFields((org.joda.time.Chronology) julianChronology49);
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology53 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone52);
        org.joda.time.MonthDay monthDay54 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology53);
        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology56 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone55);
        org.joda.time.MonthDay monthDay57 = monthDay54.withChronologyRetainFields((org.joda.time.Chronology) julianChronology56);
        java.lang.Class<?> wildcardClass58 = monthDay54.getClass();
        long long60 = julianChronology49.set((org.joda.time.ReadablePartial) monthDay54, 10L);
        boolean boolean61 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay54);
        int int62 = offsetDateTimeField33.getMaximumValue((org.joda.time.ReadablePartial) monthDay54);
        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology65 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone64);
        org.joda.time.DateTimeField dateTimeField66 = julianChronology65.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone68 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology69 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone68);
        org.joda.time.MonthDay monthDay70 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology69);
        org.joda.time.DateTimeZone dateTimeZone71 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology72 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone71);
        org.joda.time.MonthDay monthDay73 = monthDay70.withChronologyRetainFields((org.joda.time.Chronology) julianChronology72);
        java.lang.Class<?> wildcardClass74 = monthDay70.getClass();
        int[] intArray76 = julianChronology65.get((org.joda.time.ReadablePartial) monthDay70, 1L);
        java.util.Locale locale78 = null;
        try {
            int[] intArray79 = skipUndoDateTimeField5.set((org.joda.time.ReadablePartial) monthDay54, 11, intArray76, "CopticChronology[America/Los_Angeles]", locale78);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"CopticChronology[America/Los_Angeles]\" for hourOfHalfday is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-4295408573222000L) + "'", long14 == (-4295408573222000L));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "828" + "'", str29.equals("828"));
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 9 + "'", int35 == 9);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "35" + "'", str39.equals("35"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "-28798030" + "'", str43.equals("-28798030"));
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(julianChronology46);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(julianChronology49);
        org.junit.Assert.assertNotNull(monthDay50);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(julianChronology53);
        org.junit.Assert.assertNotNull(dateTimeZone55);
        org.junit.Assert.assertNotNull(julianChronology56);
        org.junit.Assert.assertNotNull(monthDay57);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 10L + "'", long60 == 10L);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 263478993 + "'", int62 == 263478993);
        org.junit.Assert.assertNotNull(dateTimeZone64);
        org.junit.Assert.assertNotNull(julianChronology65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(dateTimeZone68);
        org.junit.Assert.assertNotNull(julianChronology69);
        org.junit.Assert.assertNotNull(dateTimeZone71);
        org.junit.Assert.assertNotNull(julianChronology72);
        org.junit.Assert.assertNotNull(monthDay73);
        org.junit.Assert.assertNotNull(wildcardClass74);
        org.junit.Assert.assertNotNull(intArray76);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) 10, (int) (byte) 10);
        long long7 = fixedDateTimeZone4.adjustOffset(599665715377L, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 599665715377L + "'", long7 == 599665715377L);
        org.junit.Assert.assertNotNull(iSOChronology8);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) 10, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        boolean boolean14 = fixedDateTimeZone11.equals((java.lang.Object) false);
        long long16 = fixedDateTimeZone11.previousTransition((long) ' ');
        int int18 = fixedDateTimeZone11.getOffset((long) ' ');
        try {
            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(34, 49733542, 21, 0, (int) (byte) -1, (int) (byte) -1, 2000, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 32L + "'", long16 == 32L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology1.weekyear();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 53339L, (java.lang.Number) (byte) -1, (java.lang.Number) (-4295408573222000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology8);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology8);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology12 = julianChronology8.withZone(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(chronology12);
        org.joda.time.DateTime dateTime15 = dateTime13.minusWeeks(0);
        org.joda.time.DateTime dateTime17 = dateTime13.plusHours((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology20);
        org.joda.time.MonthDay monthDay22 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology20);
        org.joda.time.DateTime dateTime23 = dateTime13.toDateTime((org.joda.time.Chronology) julianChronology20);
        org.joda.time.DurationField durationField24 = julianChronology20.weekyears();
        try {
            org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(57653339, 54, 21, 13, 263478993, 4, (org.joda.time.Chronology) julianChronology20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 263478993 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(durationField24);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(1, 49769163, 1910320, 20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology11.dayOfWeek();
        int int14 = dateTime9.get(dateTimeField13);
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(10L);
        org.joda.time.MonthDay monthDay18 = monthDay16.minusMonths((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone20);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology24);
        org.joda.time.MonthDay monthDay26 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology24);
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology28 = julianChronology24.withZone(dateTimeZone27);
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now(chronology28);
        org.joda.time.DateTime dateTime31 = dateTime29.plusMillis((int) (short) 0);
        org.joda.time.DateTime dateTime33 = dateTime29.plusYears((int) '#');
        int int34 = dateTimeZone20.getOffset((org.joda.time.ReadableInstant) dateTime29);
        org.joda.time.DateTime dateTime36 = dateTime29.withMinuteOfHour((int) (byte) 1);
        boolean boolean37 = monthDay16.equals((java.lang.Object) (byte) 1);
        org.joda.time.MonthDay monthDay39 = monthDay16.minusDays(153);
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology40.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (-28800000));
        java.util.Locale locale44 = null;
        int int45 = offsetDateTimeField43.getMaximumShortTextLength(locale44);
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = offsetDateTimeField43.getType();
        int int47 = monthDay39.indexOf(dateTimeFieldType46);
        org.joda.time.DateTime dateTime49 = dateTime9.withField(dateTimeFieldType46, 1969);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 36000000 + "'", int34 == 36000000);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(monthDay39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 9 + "'", int45 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(dateTime49);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (short) 100);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1910320);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(21, 'a', 2054, 2000, 57653339, false, (int) (byte) 1);
        java.io.DataOutput dataOutput10 = null;
        try {
            dateTimeZoneBuilder8.writeTo("0", dataOutput10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay(0);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildFormatter();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendEraText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("49729403", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 49729403");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        dateTimeFormatterBuilder2.clear();
        dateTimeFormatterBuilder2.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMonthOfYear(69);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder2.appendTimeZoneOffset("57653339", "57653339", false, 21, (-25200000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        org.joda.time.DateTime dateTime12 = dateTime9.plusDays((int) '4');
        org.joda.time.DateTime dateTime14 = dateTime9.withYearOfEra((int) ' ');
        long long15 = dateTime9.getMillis();
        org.joda.time.DateTime dateTime17 = dateTime9.plusMinutes(49733542);
        org.joda.time.DateTime.Property property18 = dateTime9.yearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfMinute();
        org.joda.time.Instant instant3 = gJChronology0.getGregorianCutover();
        org.joda.time.Instant instant4 = instant3.toInstant();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant3.minus(readableDuration5);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        org.joda.time.DateTimeField dateTimeField6 = offsetDateTimeField3.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (-28800000));
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField10.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField10.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField15 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType13, 153);
        int int17 = dividedDateTimeField15.get((long) '#');
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (-28800000));
        java.util.Locale locale22 = null;
        int int23 = offsetDateTimeField21.getMaximumShortTextLength(locale22);
        org.joda.time.DateTimeField dateTimeField24 = offsetDateTimeField21.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (-28800000));
        java.util.Locale locale29 = null;
        int int30 = offsetDateTimeField28.getMaximumShortTextLength(locale29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField24, dateTimeFieldType31, 153);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField34 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField15, dateTimeFieldType31);
        long long37 = dividedDateTimeField15.add((long) '4', 153L);
        org.joda.time.DurationField durationField38 = dividedDateTimeField15.getDurationField();
        long long41 = dividedDateTimeField15.getDifferenceAsLong((long) 216, (long) 21);
        long long44 = dividedDateTimeField15.set((long) 53335, (int) (byte) 10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 738716716800052L + "'", long37 == 738716716800052L);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-9656409546665L) + "'", long44 == (-9656409546665L));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DateTime dateTime12 = property10.addWrapFieldToCopy((int) (short) -1);
        org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfDay(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        boolean boolean4 = dateTimeZone1.isStandardOffset((long) (-321075054));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        boolean boolean6 = offsetDateTimeField3.isLenient();
        int int8 = offsetDateTimeField3.getMinimumValue((-187199990L));
        long long10 = offsetDateTimeField3.roundHalfFloor((-694310399994L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-321075054) + "'", int8 == (-321075054));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-694310400000L) + "'", long10 == (-694310400000L));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(julianChronology10);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology4);
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology8 = julianChronology4.withZone(dateTimeZone7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = cachedDateTimeZone9.getUncachedZone();
        org.joda.time.Chronology chronology12 = iSOChronology0.withZone(dateTimeZone11);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone11);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(buddhistChronology13);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        org.joda.time.DateMidnight dateMidnight11 = dateTime9.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime9.plus(readableDuration12);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime9.minus(readableDuration14);
        java.util.GregorianCalendar gregorianCalendar16 = dateTime15.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateMidnight11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(gregorianCalendar16);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DateTime dateTime12 = property10.addWrapFieldToCopy((int) (short) -1);
        org.joda.time.DateTime dateTime14 = property10.addToCopy(15);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatterBuilder0.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.DateTimeFormat.shortTime();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withLocale(locale4);
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter3.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter2, dateTimeParser6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendWeekOfWeekyear((int) (byte) 0);
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatterBuilder11.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter2, dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) 10, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) 10, (int) (byte) 10);
        org.joda.time.Chronology chronology11 = iSOChronology5.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        int int13 = fixedDateTimeZone10.getOffset((long) (byte) 1);
        java.util.TimeZone timeZone14 = fixedDateTimeZone10.toTimeZone();
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertNotNull(timeZone14);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusHours((int) (byte) 1);
        int int12 = dateTime11.getSecondOfDay();
        org.joda.time.DateTime dateTime14 = dateTime11.withYear((-49715377));
        try {
            org.joda.time.DateTime dateTime18 = dateTime14.withDate(54, 0, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 61200 + "'", int12 == 61200);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusHours((int) (byte) 1);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone14);
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology15);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.MonthDay monthDay19 = monthDay16.withChronologyRetainFields((org.joda.time.Chronology) julianChronology18);
        java.lang.String str20 = julianChronology18.toString();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology18.weekyearOfCentury();
        long long25 = julianChronology18.add((long) 153, (-81L), (int) (byte) 0);
        org.joda.time.DateTime dateTime26 = dateTime11.toDateTime((org.joda.time.Chronology) julianChronology18);
        org.joda.time.DateTime.Property property27 = dateTime26.secondOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str20.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 153L + "'", long25 == 153L);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        int int11 = dateTime9.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 51 + "'", int11 == 51);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        long long6 = offsetDateTimeField3.set((long) (short) 100, "35");
        long long9 = offsetDateTimeField3.getDifferenceAsLong(36000828L, (long) 1);
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay(10L);
        org.joda.time.MonthDay monthDay13 = monthDay11.minusMonths((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology19);
        org.joda.time.MonthDay monthDay21 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology19);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology23 = julianChronology19.withZone(dateTimeZone22);
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now(chronology23);
        org.joda.time.DateTime dateTime26 = dateTime24.plusMillis((int) (short) 0);
        org.joda.time.DateTime dateTime28 = dateTime24.plusYears((int) '#');
        int int29 = dateTimeZone15.getOffset((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime31 = dateTime24.withMinuteOfHour((int) (byte) 1);
        boolean boolean32 = monthDay11.equals((java.lang.Object) (byte) 1);
        org.joda.time.MonthDay monthDay34 = monthDay11.minusDays(153);
        int int35 = offsetDateTimeField3.getMaximumValue((org.joda.time.ReadablePartial) monthDay11);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField3.getAsShortText(0L, locale37);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 908779154918400100L + "'", long6 == 908779154918400100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 36000000 + "'", int29 == 36000000);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 263478993 + "'", int35 == 263478993);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "-28798030" + "'", str38.equals("-28798030"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.weekOfWeekyear();
        boolean boolean19 = property12.equals((java.lang.Object) dateTimeField18);
        int int20 = property12.getMaximumValueOverall();
        org.joda.time.DateTime dateTime22 = property12.setCopy((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField25 = julianChronology24.days();
        boolean boolean26 = property12.equals((java.lang.Object) durationField25);
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        org.joda.time.DurationField durationField29 = julianChronology28.days();
        boolean boolean30 = property12.equals((java.lang.Object) julianChronology28);
        org.joda.time.DateTime dateTime31 = property12.withMaximumValue();
        org.joda.time.DateTime dateTime32 = property12.roundFloorCopy();
        org.joda.time.DateTime.Property property33 = dateTime32.millisOfSecond();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology3.hourOfDay();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((long) 153, (org.joda.time.Chronology) julianChronology3);
        org.joda.time.DateTimeField dateTimeField8 = julianChronology3.clockhourOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYearOfCentury((int) (byte) 0, (int) (byte) 1);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap6 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTimeZoneName(strMap6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTimeZoneOffset("2054-06-02T13:48:53.137-07:00", true, 1, 2522);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        org.joda.time.DateTimeField dateTimeField4 = offsetDateTimeField3.getWrappedField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        long long7 = delegatedDateTimeField5.roundHalfEven(69L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(10L);
        org.joda.time.MonthDay monthDay3 = monthDay1.minusMonths((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology13 = julianChronology9.withZone(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(chronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusMillis((int) (short) 0);
        org.joda.time.DateTime dateTime18 = dateTime14.plusYears((int) '#');
        int int19 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime21 = dateTime14.withMinuteOfHour((int) (byte) 1);
        boolean boolean22 = monthDay1.equals((java.lang.Object) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone24);
        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology25);
        org.joda.time.MonthDay monthDay27 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology25);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology29 = julianChronology25.withZone(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(chronology29);
        org.joda.time.DateTime dateTime32 = dateTime30.minusWeeks(0);
        org.joda.time.DateTime dateTime34 = dateTime30.plusHours((int) (byte) 1);
        org.joda.time.DateTime dateTime35 = monthDay1.toDateTime((org.joda.time.ReadableInstant) dateTime30);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 36000000 + "'", int19 == 36000000);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime35);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DateTime dateTime12 = property10.addToCopy(54);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (-28800000));
        java.util.Locale locale17 = null;
        int int18 = offsetDateTimeField16.getMaximumShortTextLength(locale17);
        org.joda.time.DateTimeField dateTimeField19 = offsetDateTimeField16.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, (-28800000));
        java.util.Locale locale24 = null;
        int int25 = offsetDateTimeField23.getMaximumShortTextLength(locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField23.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField(dateTimeField19, dateTimeFieldType26, 153);
        int int30 = dividedDateTimeField28.get((long) '#');
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (-28800000));
        java.util.Locale locale35 = null;
        int int36 = offsetDateTimeField34.getMaximumShortTextLength(locale35);
        org.joda.time.DateTimeField dateTimeField37 = offsetDateTimeField34.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology38.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, (-28800000));
        java.util.Locale locale42 = null;
        int int43 = offsetDateTimeField41.getMaximumShortTextLength(locale42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = offsetDateTimeField41.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField(dateTimeField37, dateTimeFieldType44, 153);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField47 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField28, dateTimeFieldType44);
        long long50 = remainderDateTimeField47.addWrapField((long) 6, 49737830);
        int int51 = dateTime12.get((org.joda.time.DateTimeField) remainderDateTimeField47);
        java.util.Locale locale53 = null;
        try {
            java.lang.String str54 = dateTime12.toString("hourOfHalfday", locale53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: o");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 9 + "'", int25 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 12 + "'", int30 == 12);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 9 + "'", int36 == 9);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(iSOChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 9 + "'", int43 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-694310399994L) + "'", long50 == (-694310399994L));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 134 + "'", int51 == 134);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology3);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5);
        org.joda.time.MonthDay monthDay7 = monthDay4.withChronologyRetainFields((org.joda.time.Chronology) julianChronology6);
        java.lang.String str8 = julianChronology6.toString();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.weekyearOfCentury();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTime dateTime12 = dateTime10.withMillis((long) 'a');
        try {
            org.joda.time.DateTime dateTime14 = dateTime10.withDayOfWeek((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str8.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.MonthDay monthDay8 = monthDay5.withChronologyRetainFields((org.joda.time.Chronology) julianChronology7);
        java.lang.String str9 = julianChronology7.toString();
        org.joda.time.DurationField durationField10 = julianChronology7.eras();
        try {
            org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay(2, 0, (org.joda.time.Chronology) julianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str9.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.hourOfHalfday();
        org.joda.time.DurationField durationField4 = julianChronology2.hours();
        boolean boolean5 = copticChronology0.equals((java.lang.Object) durationField4);
        org.joda.time.DurationField durationField6 = copticChronology0.weekyears();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DateTime.Property property14 = dateTime13.era();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        org.joda.time.ReadablePartial readablePartial6 = null;
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsText(readablePartial6, (int) '#', locale8);
        boolean boolean11 = offsetDateTimeField3.isLeap((long) 19);
        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 1261);
        java.lang.String str14 = offsetDateTimeField3.getName();
        java.util.Locale locale17 = null;
        long long18 = offsetDateTimeField3.set(1261L, "49729403", locale17);
        int int20 = offsetDateTimeField3.get((long) 0);
        long long23 = offsetDateTimeField3.add((long) (short) 1, (long) 31);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "35" + "'", str9.equals("35"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-28798030" + "'", str13.equals("-28798030"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "year" + "'", str14.equals("year"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2478086433820801261L + "'", long18 == 2478086433820801261L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-28798030) + "'", int20 == (-28798030));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 978307200001L + "'", long23 == 978307200001L);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusHours((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone16);
        org.joda.time.MonthDay monthDay18 = monthDay15.withChronologyRetainFields((org.joda.time.Chronology) julianChronology17);
        java.lang.String str19 = julianChronology17.toString();
        org.joda.time.DateTime dateTime20 = dateTime7.toDateTime((org.joda.time.Chronology) julianChronology17);
        org.joda.time.DateTime dateTime22 = dateTime7.minus(520L);
        org.joda.time.DateTime.Property property23 = dateTime22.yearOfEra();
        java.lang.String str24 = property23.getAsString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str19.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1969" + "'", str24.equals("1969"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendDayOfMonth(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        try {
            org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((java.lang.Object) dateTimeFormatterBuilder0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.format.DateTimeFormatterBuilder");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        org.joda.time.ReadablePartial readablePartial6 = null;
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsText(readablePartial6, (int) '#', locale8);
        boolean boolean11 = offsetDateTimeField3.isLeap((long) 19);
        int int14 = offsetDateTimeField3.getDifference((long) 0, 0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "35" + "'", str9.equals("35"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendTwoDigitWeekyear(45, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.MonthDay monthDay6 = monthDay3.withChronologyRetainFields((org.joda.time.Chronology) julianChronology5);
        try {
            org.joda.time.DateTimeField dateTimeField8 = monthDay3.getField(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(monthDay6);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        long long6 = offsetDateTimeField3.set((long) (short) 100, "35");
        long long9 = offsetDateTimeField3.getDifferenceAsLong(36000828L, (long) 1);
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay(10L);
        org.joda.time.MonthDay monthDay13 = monthDay11.minusMonths((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology19);
        org.joda.time.MonthDay monthDay21 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology19);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology23 = julianChronology19.withZone(dateTimeZone22);
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now(chronology23);
        org.joda.time.DateTime dateTime26 = dateTime24.plusMillis((int) (short) 0);
        org.joda.time.DateTime dateTime28 = dateTime24.plusYears((int) '#');
        int int29 = dateTimeZone15.getOffset((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime31 = dateTime24.withMinuteOfHour((int) (byte) 1);
        boolean boolean32 = monthDay11.equals((java.lang.Object) (byte) 1);
        org.joda.time.MonthDay monthDay34 = monthDay11.minusDays(153);
        int int35 = offsetDateTimeField3.getMaximumValue((org.joda.time.ReadablePartial) monthDay11);
        org.joda.time.MonthDay monthDay37 = new org.joda.time.MonthDay(10L);
        org.joda.time.MonthDay monthDay39 = monthDay37.minusMonths((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology41 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone40);
        org.joda.time.DateTimeField dateTimeField42 = julianChronology41.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology45 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone44);
        org.joda.time.MonthDay monthDay46 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology45);
        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology48 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone47);
        org.joda.time.MonthDay monthDay49 = monthDay46.withChronologyRetainFields((org.joda.time.Chronology) julianChronology48);
        java.lang.Class<?> wildcardClass50 = monthDay46.getClass();
        int[] intArray52 = julianChronology41.get((org.joda.time.ReadablePartial) monthDay46, 1L);
        boolean boolean53 = monthDay39.equals((java.lang.Object) monthDay46);
        boolean boolean54 = monthDay11.isEqual((org.joda.time.ReadablePartial) monthDay46);
        org.joda.time.MonthDay.Property property55 = monthDay11.dayOfMonth();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 908779154918400100L + "'", long6 == 908779154918400100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 36000000 + "'", int29 == 36000000);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 263478993 + "'", int35 == 263478993);
        org.junit.Assert.assertNotNull(monthDay39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(julianChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(julianChronology45);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(julianChronology48);
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(property55);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, 0);
        int int7 = skipUndoDateTimeField5.getMinimumValue((long) 10);
        int int9 = skipUndoDateTimeField5.getLeapAmount(10L);
        int int11 = skipUndoDateTimeField5.getLeapAmount(0L);
        long long14 = skipUndoDateTimeField5.set((long) 'a', 10);
        long long17 = skipUndoDateTimeField5.getDifferenceAsLong((-4295437603200000L), 21600097L);
        java.lang.String str18 = skipUndoDateTimeField5.getName();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 21600097L + "'", long14 == 21600097L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1193177118L) + "'", long17 == (-1193177118L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hourOfHalfday" + "'", str18.equals("hourOfHalfday"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusHours((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone16);
        org.joda.time.MonthDay monthDay18 = monthDay15.withChronologyRetainFields((org.joda.time.Chronology) julianChronology17);
        java.lang.String str19 = julianChronology17.toString();
        org.joda.time.DateTime dateTime20 = dateTime7.toDateTime((org.joda.time.Chronology) julianChronology17);
        org.joda.time.DateTime dateTime22 = dateTime7.minus(520L);
        int int23 = dateTime22.getWeekyear();
        org.joda.time.DateTime.Property property24 = dateTime22.era();
        org.joda.time.DateTime dateTime26 = dateTime22.minusHours(1787253509);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str19.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1969 + "'", int23 == 1969);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        org.joda.time.DateTimeField dateTimeField6 = offsetDateTimeField3.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (-28800000));
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField10.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField10.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField15 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType13, 153);
        int int17 = dividedDateTimeField15.get((long) '#');
        long long19 = dividedDateTimeField15.roundHalfCeiling((long) 0);
        org.joda.time.DurationField durationField20 = dividedDateTimeField15.getRangeDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 599616000000L + "'", long19 == 599616000000L);
        org.junit.Assert.assertNull(durationField20);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DateTime dateTime12 = property10.addToCopy(54);
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime12.toMutableDateTime();
        org.joda.time.DateTime dateTime15 = dateTime12.minusMillis(133);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        boolean boolean6 = offsetDateTimeField3.isLenient();
        int int8 = offsetDateTimeField3.getMinimumValue((-187199990L));
        org.joda.time.DurationField durationField9 = offsetDateTimeField3.getRangeDurationField();
        org.joda.time.DurationField durationField10 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationFieldType durationFieldType11 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField12 = new org.joda.time.field.DecoratedDurationField(durationField10, durationFieldType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-321075054) + "'", int8 == (-321075054));
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        org.joda.time.DateTimeField dateTimeField6 = offsetDateTimeField3.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (-28800000));
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField10.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField10.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField15 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType13, 153);
        int int17 = dividedDateTimeField15.get((long) '#');
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (-28800000));
        java.util.Locale locale22 = null;
        int int23 = offsetDateTimeField21.getMaximumShortTextLength(locale22);
        org.joda.time.DateTimeField dateTimeField24 = offsetDateTimeField21.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (-28800000));
        java.util.Locale locale29 = null;
        int int30 = offsetDateTimeField28.getMaximumShortTextLength(locale29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField24, dateTimeFieldType31, 153);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField34 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField15, dateTimeFieldType31);
        boolean boolean35 = remainderDateTimeField34.isSupported();
        java.util.Locale locale36 = null;
        int int37 = remainderDateTimeField34.getMaximumTextLength(locale36);
        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology38.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, (-28800000));
        long long44 = offsetDateTimeField41.set((long) (short) 100, "35");
        long long47 = offsetDateTimeField41.getDifferenceAsLong(36000828L, (long) 1);
        org.joda.time.MonthDay monthDay49 = new org.joda.time.MonthDay(10L);
        org.joda.time.MonthDay monthDay51 = monthDay49.minusMonths((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone54 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone53);
        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology57 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone56);
        org.joda.time.MonthDay monthDay58 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology57);
        org.joda.time.MonthDay monthDay59 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology57);
        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology61 = julianChronology57.withZone(dateTimeZone60);
        org.joda.time.DateTime dateTime62 = org.joda.time.DateTime.now(chronology61);
        org.joda.time.DateTime dateTime64 = dateTime62.plusMillis((int) (short) 0);
        org.joda.time.DateTime dateTime66 = dateTime62.plusYears((int) '#');
        int int67 = dateTimeZone53.getOffset((org.joda.time.ReadableInstant) dateTime62);
        org.joda.time.DateTime dateTime69 = dateTime62.withMinuteOfHour((int) (byte) 1);
        boolean boolean70 = monthDay49.equals((java.lang.Object) (byte) 1);
        org.joda.time.MonthDay monthDay72 = monthDay49.minusDays(153);
        int int73 = offsetDateTimeField41.getMaximumValue((org.joda.time.ReadablePartial) monthDay49);
        org.joda.time.MonthDay monthDay75 = new org.joda.time.MonthDay(10L);
        org.joda.time.MonthDay monthDay77 = monthDay75.minusMonths((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone78 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology79 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone78);
        org.joda.time.DateTimeField dateTimeField80 = julianChronology79.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone82 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology83 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone82);
        org.joda.time.MonthDay monthDay84 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology83);
        org.joda.time.DateTimeZone dateTimeZone85 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology86 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone85);
        org.joda.time.MonthDay monthDay87 = monthDay84.withChronologyRetainFields((org.joda.time.Chronology) julianChronology86);
        java.lang.Class<?> wildcardClass88 = monthDay84.getClass();
        int[] intArray90 = julianChronology79.get((org.joda.time.ReadablePartial) monthDay84, 1L);
        boolean boolean91 = monthDay77.equals((java.lang.Object) monthDay84);
        boolean boolean92 = monthDay49.isEqual((org.joda.time.ReadablePartial) monthDay84);
        java.util.Locale locale94 = null;
        java.lang.String str95 = remainderDateTimeField34.getAsText((org.joda.time.ReadablePartial) monthDay49, (-321075054), locale94);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 3 + "'", int37 == 3);
        org.junit.Assert.assertNotNull(iSOChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 908779154918400100L + "'", long44 == 908779154918400100L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
        org.junit.Assert.assertNotNull(monthDay51);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(cachedDateTimeZone54);
        org.junit.Assert.assertNotNull(dateTimeZone56);
        org.junit.Assert.assertNotNull(julianChronology57);
        org.junit.Assert.assertNotNull(monthDay59);
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertNotNull(chronology61);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(dateTime66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 36000000 + "'", int67 == 36000000);
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(monthDay72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 263478993 + "'", int73 == 263478993);
        org.junit.Assert.assertNotNull(monthDay77);
        org.junit.Assert.assertNotNull(dateTimeZone78);
        org.junit.Assert.assertNotNull(julianChronology79);
        org.junit.Assert.assertNotNull(dateTimeField80);
        org.junit.Assert.assertNotNull(dateTimeZone82);
        org.junit.Assert.assertNotNull(julianChronology83);
        org.junit.Assert.assertNotNull(dateTimeZone85);
        org.junit.Assert.assertNotNull(julianChronology86);
        org.junit.Assert.assertNotNull(monthDay87);
        org.junit.Assert.assertNotNull(wildcardClass88);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "-321075054" + "'", str95.equals("-321075054"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) (short) 10);
        java.io.Writer writer3 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology6);
        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology10 = julianChronology6.withZone(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(chronology10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusWeeks(0);
        org.joda.time.DateTime dateTime15 = dateTime11.plusSeconds(0);
        org.joda.time.DateTime.Property property16 = dateTime15.yearOfCentury();
        org.joda.time.DateTime dateTime17 = property16.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology20);
        org.joda.time.DateTimeField dateTimeField22 = julianChronology20.weekOfWeekyear();
        boolean boolean23 = property16.equals((java.lang.Object) dateTimeField22);
        int int24 = property16.getMaximumValueOverall();
        org.joda.time.DateTime dateTime26 = property16.setCopy((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone27 = dateTime26.getZone();
        int int28 = dateTime26.getDayOfWeek();
        org.joda.time.DateTime dateTime30 = dateTime26.minus((long) 1);
        org.joda.time.DateTime dateTime32 = dateTime30.minusMonths(53339);
        org.joda.time.DateTime.Property property33 = dateTime30.minuteOfDay();
        try {
            dateTimeFormatter0.printTo(writer3, (org.joda.time.ReadableInstant) dateTime30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 100 + "'", int24 == 100);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.weekOfWeekyear();
        boolean boolean19 = property12.equals((java.lang.Object) dateTimeField18);
        int int20 = property12.getMaximumValueOverall();
        org.joda.time.DateTime dateTime22 = property12.setCopy((int) (byte) 10);
        org.joda.time.DateTime dateTime24 = property12.addWrapFieldToCopy(2019);
        org.joda.time.ReadablePartial readablePartial25 = null;
        try {
            int int26 = property12.compareTo(readablePartial25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) 2054);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) 10, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean7 = fixedDateTimeZone4.equals((java.lang.Object) false);
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        int int10 = fixedDateTimeZone4.getOffset((long) 1787253509);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.weekOfWeekyear();
        boolean boolean19 = property12.equals((java.lang.Object) dateTimeField18);
        int int20 = property12.getMaximumValueOverall();
        org.joda.time.DateTime dateTime22 = property12.setCopy((int) (byte) 10);
        org.joda.time.DateTime dateTime24 = dateTime22.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property25 = dateTime22.dayOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        org.joda.time.DateTimeField dateTimeField6 = offsetDateTimeField3.getWrappedField();
        int int8 = offsetDateTimeField3.getLeapAmount((long) (byte) 1);
        boolean boolean9 = offsetDateTimeField3.isSupported();
        long long12 = offsetDateTimeField3.addWrapField((-9656409546665L), 53330);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1673275881653335L + "'", long12 == 1673275881653335L);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now(dateTimeZone1);
        org.joda.time.MonthDay.Property property3 = monthDay2.dayOfMonth();
        java.lang.String str4 = property3.getAsText();
        java.lang.String str5 = property3.getAsShortText();
        org.joda.time.MonthDay monthDay6 = property3.getMonthDay();
        int int7 = property3.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "31" + "'", str4.equals("31"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31" + "'", str5.equals("31"));
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.weekOfWeekyear();
        boolean boolean19 = property12.equals((java.lang.Object) dateTimeField18);
        int int20 = property12.getMaximumValueOverall();
        org.joda.time.DateTime dateTime22 = property12.setCopy((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone23 = dateTime22.getZone();
        org.joda.time.DateTime.Property property24 = dateTime22.monthOfYear();
        org.joda.time.DateTime.Property property25 = dateTime22.secondOfMinute();
        org.joda.time.DateTime dateTime27 = property25.addToCopy((int) 'a');
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        java.lang.String str14 = property12.getName();
        int int15 = property12.getMaximumValue();
        int int16 = property12.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "yearOfCentury" + "'", str14.equals("yearOfCentury"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, 0);
        long long7 = skipUndoDateTimeField5.roundHalfCeiling((long) (byte) 1);
        int int10 = skipUndoDateTimeField5.getDifference((long) 54, (long) 53330);
        long long12 = skipUndoDateTimeField5.remainder(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        org.joda.time.DateTimeField dateTimeField6 = offsetDateTimeField3.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (-28800000));
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField10.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField10.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField15 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType13, 153);
        int int17 = dividedDateTimeField15.get((long) '#');
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (-28800000));
        java.util.Locale locale22 = null;
        int int23 = offsetDateTimeField21.getMaximumShortTextLength(locale22);
        org.joda.time.DateTimeField dateTimeField24 = offsetDateTimeField21.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (-28800000));
        java.util.Locale locale29 = null;
        int int30 = offsetDateTimeField28.getMaximumShortTextLength(locale29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField24, dateTimeFieldType31, 153);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField34 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField15, dateTimeFieldType31);
        long long36 = remainderDateTimeField34.roundHalfFloor((-4295408573222000L));
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology39 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = julianChronology39.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField(chronology37, dateTimeField40, 0);
        java.util.Locale locale44 = null;
        java.lang.String str45 = skipUndoDateTimeField42.getAsShortText((int) '4', locale44);
        org.joda.time.MonthDay monthDay47 = new org.joda.time.MonthDay(10L);
        org.joda.time.MonthDay monthDay49 = monthDay47.minusMonths((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone52 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone51);
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology55 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone54);
        org.joda.time.MonthDay monthDay56 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology55);
        org.joda.time.MonthDay monthDay57 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology55);
        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology59 = julianChronology55.withZone(dateTimeZone58);
        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now(chronology59);
        org.joda.time.DateTime dateTime62 = dateTime60.plusMillis((int) (short) 0);
        org.joda.time.DateTime dateTime64 = dateTime60.plusYears((int) '#');
        int int65 = dateTimeZone51.getOffset((org.joda.time.ReadableInstant) dateTime60);
        org.joda.time.DateTime dateTime67 = dateTime60.withMinuteOfHour((int) (byte) 1);
        boolean boolean68 = monthDay47.equals((java.lang.Object) (byte) 1);
        org.joda.time.MonthDay monthDay70 = monthDay47.minusDays(153);
        org.joda.time.chrono.ISOChronology iSOChronology71 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField72 = iSOChronology71.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField74 = new org.joda.time.field.OffsetDateTimeField(dateTimeField72, (-28800000));
        java.util.Locale locale75 = null;
        int int76 = offsetDateTimeField74.getMaximumShortTextLength(locale75);
        org.joda.time.DateTimeFieldType dateTimeFieldType77 = offsetDateTimeField74.getType();
        int int78 = monthDay70.indexOf(dateTimeFieldType77);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField79 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField42, dateTimeFieldType77);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField80 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField34, dateTimeFieldType77);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField81 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField80);
        org.joda.time.DurationField durationField82 = dividedDateTimeField80.getDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-4295406067200000L) + "'", long36 == (-4295406067200000L));
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(julianChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "52" + "'", str45.equals("52"));
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertNotNull(cachedDateTimeZone52);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertNotNull(julianChronology55);
        org.junit.Assert.assertNotNull(monthDay57);
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertNotNull(chronology59);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 36000000 + "'", int65 == 36000000);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(monthDay70);
        org.junit.Assert.assertNotNull(iSOChronology71);
        org.junit.Assert.assertNotNull(dateTimeField72);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 9 + "'", int76 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-1) + "'", int78 == (-1));
        org.junit.Assert.assertNotNull(durationField82);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 2000);
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        boolean boolean6 = cachedDateTimeZone4.isStandardOffset(10L);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9);
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology10);
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology10);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology14 = julianChronology10.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(chronology14);
        org.joda.time.DateTime dateTime17 = dateTime15.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = julianChronology19.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology19.dayOfWeek();
        int int22 = dateTime17.get(dateTimeField21);
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone4, (org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTime dateTime25 = dateTime17.withMillisOfDay((int) (short) 0);
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.DateTime dateTime27 = dateTime25.minus(readableDuration26);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, 0);
        int int7 = skipUndoDateTimeField5.getMinimumValue((long) 10);
        long long9 = skipUndoDateTimeField5.remainder(18000000L);
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay(10L);
        org.joda.time.MonthDay monthDay13 = monthDay11.minusMonths((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology19);
        org.joda.time.MonthDay monthDay21 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology19);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology23 = julianChronology19.withZone(dateTimeZone22);
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now(chronology23);
        org.joda.time.DateTime dateTime26 = dateTime24.plusMillis((int) (short) 0);
        org.joda.time.DateTime dateTime28 = dateTime24.plusYears((int) '#');
        int int29 = dateTimeZone15.getOffset((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime31 = dateTime24.withMinuteOfHour((int) (byte) 1);
        boolean boolean32 = monthDay11.equals((java.lang.Object) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology33 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology34 = buddhistChronology33.withUTC();
        org.joda.time.MonthDay monthDay35 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) buddhistChronology33);
        int int36 = skipUndoDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) monthDay35);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 36000000 + "'", int29 == 36000000);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(buddhistChronology33);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.secondOfMinute();
        org.joda.time.Instant instant4 = gJChronology1.getGregorianCutover();
        java.lang.String str5 = gJChronology1.toString();
        boolean boolean6 = julianChronology0.equals((java.lang.Object) gJChronology1);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.monthOfYear();
        int int9 = gJChronology7.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology7.yearOfEra();
        boolean boolean11 = julianChronology0.equals((java.lang.Object) dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GJChronology[UTC]" + "'", str5.equals("GJChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) 10, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) 10, (int) (byte) 10);
        org.joda.time.Chronology chronology12 = iSOChronology6.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone14 = cachedDateTimeZone13.getUncachedZone();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 6, dateTimeZone14);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 2000);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) 49715377);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        long long12 = dateTime11.getMillis();
        org.joda.time.DateTime.Property property13 = dateTime11.year();
        int int14 = dateTime11.getCenturyOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 20 + "'", int14 == 20);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.dayOfMonth();
        org.joda.time.Instant instant4 = gJChronology0.getGregorianCutover();
        java.lang.String str5 = gJChronology0.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        boolean boolean12 = cachedDateTimeZone10.isStandardOffset(10L);
        org.joda.time.Chronology chronology13 = gregorianChronology6.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology20 = julianChronology16.withZone(dateTimeZone19);
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now(chronology20);
        org.joda.time.DateTime dateTime23 = dateTime21.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone24);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology25.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField27 = julianChronology25.dayOfWeek();
        int int28 = dateTime23.get(dateTimeField27);
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone10, (org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.Chronology chronology30 = gJChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone10);
        org.joda.time.Instant instant31 = gJChronology0.getGregorianCutover();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GJChronology[UTC]" + "'", str5.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(instant31);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths(2);
        org.joda.time.DateTime dateTime10 = dateTime7.withEarlierOffsetAtOverlap();
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime7.toMutableDateTime();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.MonthDay monthDay6 = monthDay3.withChronologyRetainFields((org.joda.time.Chronology) julianChronology5);
        org.joda.time.MonthDay monthDay8 = monthDay3.withDayOfMonth((int) (byte) 10);
        boolean boolean9 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay3);
        int[] intArray10 = monthDay3.getValues();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology4);
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology8 = julianChronology4.withZone(dateTimeZone7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = cachedDateTimeZone9.getUncachedZone();
        org.joda.time.Chronology chronology12 = iSOChronology0.withZone(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone14);
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology15);
        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology19 = julianChronology15.withZone(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now(chronology19);
        org.joda.time.DateTime dateTime22 = dateTime20.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        org.joda.time.DateTimeField dateTimeField25 = julianChronology24.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField26 = julianChronology24.dayOfWeek();
        int int27 = dateTime22.get(dateTimeField26);
        boolean boolean28 = iSOChronology0.equals((java.lang.Object) dateTime22);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.weekyearOfCentury();
        org.joda.time.DurationField durationField31 = iSOChronology29.years();
        org.joda.time.DateTime dateTime32 = dateTime22.toDateTime((org.joda.time.Chronology) iSOChronology29);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTime32);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.dayOfMonth();
        org.joda.time.Instant instant4 = gJChronology0.getGregorianCutover();
        java.lang.String str5 = gJChronology0.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        boolean boolean12 = cachedDateTimeZone10.isStandardOffset(10L);
        org.joda.time.Chronology chronology13 = gregorianChronology6.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology20 = julianChronology16.withZone(dateTimeZone19);
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now(chronology20);
        org.joda.time.DateTime dateTime23 = dateTime21.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone24);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology25.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField27 = julianChronology25.dayOfWeek();
        int int28 = dateTime23.get(dateTimeField27);
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone10, (org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.Chronology chronology30 = gJChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone10);
        java.util.TimeZone timeZone31 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forTimeZone(timeZone31);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        org.joda.time.chrono.ZonedChronology zonedChronology34 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone32);
        org.joda.time.chrono.BuddhistChronology buddhistChronology35 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone37);
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology38);
        org.joda.time.MonthDay monthDay40 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology38);
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology42 = julianChronology38.withZone(dateTimeZone41);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone43 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone41);
        org.joda.time.Chronology chronology44 = buddhistChronology35.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone43);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GJChronology[UTC]" + "'", str5.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(zonedChronology34);
        org.junit.Assert.assertNotNull(buddhistChronology35);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(julianChronology38);
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertNotNull(cachedDateTimeZone43);
        org.junit.Assert.assertNotNull(chronology44);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-321075054));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) -1, (int) (byte) -1, 0, 15);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 14 + "'", int4 == 14);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.plusMillis((int) (short) 0);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfYear();
        int int11 = property10.getLeapAmount();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        long long11 = property10.remainder();
        java.lang.String str12 = property10.getAsShortText();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 57600100L + "'", long11 == 57600100L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Wed" + "'", str12.equals("Wed"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "JulianChronology[America/Los_Angeles]", "GJChronology[UTC]");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime14 = property12.addToCopy(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) (short) 10);
        try {
            org.joda.time.LocalDateTime localDateTime4 = dateTimeFormatter0.parseLocalDateTime("dayOfWeek");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"dayOfWeek\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        org.joda.time.DateMidnight dateMidnight11 = dateTime9.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime9.plus(readableDuration12);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone16);
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology17);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.MonthDay monthDay21 = monthDay18.withChronologyRetainFields((org.joda.time.Chronology) julianChronology20);
        java.lang.String str22 = julianChronology20.toString();
        org.joda.time.DateTimeField dateTimeField23 = julianChronology20.weekyearOfCentury();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) julianChronology20);
        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay(10L);
        int[] intArray28 = julianChronology20.get((org.joda.time.ReadablePartial) monthDay26, (long) 13);
        org.joda.time.DateTime dateTime29 = dateTime9.toDateTime((org.joda.time.Chronology) julianChronology20);
        org.joda.time.DurationField durationField30 = julianChronology20.eras();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateMidnight11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str22.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(durationField30);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 'a');
        org.joda.time.Instant instant3 = instant1.withMillis((long) 153);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Instant instant5 = instant3.plus(readableDuration4);
        org.joda.time.Instant instant7 = instant3.withMillis(100L);
        boolean boolean9 = instant7.isEqual(1L);
        org.joda.time.Instant instant11 = instant7.plus((-81L));
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(instant11);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        try {
            org.joda.time.DateTime dateTime14 = dateTime11.withWeekOfWeekyear(422);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 422 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendHourOfDay((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneShortName();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusHours((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology14);
        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology14);
        org.joda.time.DateTime dateTime17 = dateTime7.toDateTime((org.joda.time.Chronology) julianChronology14);
        org.joda.time.DurationField durationField18 = julianChronology14.weekyears();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((org.joda.time.Chronology) julianChronology14);
        org.joda.time.DateTimeField dateTimeField20 = julianChronology14.halfdayOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField20);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfMinute();
        org.joda.time.Instant instant3 = gJChronology0.getGregorianCutover();
        org.joda.time.DurationField durationField4 = gJChronology0.years();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) cachedDateTimeZone2);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(julianChronology4);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = cachedDateTimeZone2.getUncachedZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone2);
        org.joda.time.Chronology chronology5 = gregorianChronology4.withUTC();
        java.lang.String str6 = gregorianChronology4.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[+10:00]" + "'", str6.equals("GregorianChronology[+10:00]"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.weekOfWeekyear();
        boolean boolean19 = property12.equals((java.lang.Object) dateTimeField18);
        org.joda.time.DateTime dateTime20 = property12.withMinimumValue();
        java.lang.Object obj21 = null;
        boolean boolean22 = property12.equals(obj21);
        int int23 = property12.get();
        org.joda.time.DateTime dateTime25 = property12.addToCopy((long) 'a');
        boolean boolean26 = property12.isLeap();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 69 + "'", int23 == 69);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) 10, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean7 = fixedDateTimeZone4.equals((java.lang.Object) false);
        long long9 = fixedDateTimeZone4.previousTransition((long) ' ');
        java.lang.String str11 = fixedDateTimeZone4.getNameKey(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.clockhourOfDay();
        org.joda.time.Chronology chronology14 = buddhistChronology12.withUTC();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.year();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology19);
        org.joda.time.MonthDay monthDay21 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology19);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology23 = julianChronology19.withZone(dateTimeZone22);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone24 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone22);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) cachedDateTimeZone24);
        org.joda.time.DateTimeZone dateTimeZone26 = cachedDateTimeZone24.getUncachedZone();
        org.joda.time.Chronology chronology27 = iSOChronology15.withZone(dateTimeZone26);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone28 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone26);
        org.joda.time.Chronology chronology29 = buddhistChronology12.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone28);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 32L + "'", long9 == 32L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(cachedDateTimeZone24);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(cachedDateTimeZone28);
        org.junit.Assert.assertNotNull(chronology29);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (byte) 0, (int) (short) -1);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) 49715377);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        long long13 = dateTime11.getMillis();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        org.joda.time.DateTimeField dateTimeField6 = offsetDateTimeField3.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (-28800000));
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField10.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField10.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField15 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType13, 153);
        int int17 = dividedDateTimeField15.get((long) '#');
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (-28800000));
        java.util.Locale locale22 = null;
        int int23 = offsetDateTimeField21.getMaximumShortTextLength(locale22);
        org.joda.time.DateTimeField dateTimeField24 = offsetDateTimeField21.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (-28800000));
        java.util.Locale locale29 = null;
        int int30 = offsetDateTimeField28.getMaximumShortTextLength(locale29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField24, dateTimeFieldType31, 153);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField34 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField15, dateTimeFieldType31);
        long long36 = remainderDateTimeField34.roundHalfFloor((-4295408573222000L));
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology39 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = julianChronology39.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField(chronology37, dateTimeField40, 0);
        java.util.Locale locale44 = null;
        java.lang.String str45 = skipUndoDateTimeField42.getAsShortText((int) '4', locale44);
        org.joda.time.MonthDay monthDay47 = new org.joda.time.MonthDay(10L);
        org.joda.time.MonthDay monthDay49 = monthDay47.minusMonths((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone52 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone51);
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology55 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone54);
        org.joda.time.MonthDay monthDay56 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology55);
        org.joda.time.MonthDay monthDay57 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology55);
        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology59 = julianChronology55.withZone(dateTimeZone58);
        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now(chronology59);
        org.joda.time.DateTime dateTime62 = dateTime60.plusMillis((int) (short) 0);
        org.joda.time.DateTime dateTime64 = dateTime60.plusYears((int) '#');
        int int65 = dateTimeZone51.getOffset((org.joda.time.ReadableInstant) dateTime60);
        org.joda.time.DateTime dateTime67 = dateTime60.withMinuteOfHour((int) (byte) 1);
        boolean boolean68 = monthDay47.equals((java.lang.Object) (byte) 1);
        org.joda.time.MonthDay monthDay70 = monthDay47.minusDays(153);
        org.joda.time.chrono.ISOChronology iSOChronology71 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField72 = iSOChronology71.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField74 = new org.joda.time.field.OffsetDateTimeField(dateTimeField72, (-28800000));
        java.util.Locale locale75 = null;
        int int76 = offsetDateTimeField74.getMaximumShortTextLength(locale75);
        org.joda.time.DateTimeFieldType dateTimeFieldType77 = offsetDateTimeField74.getType();
        int int78 = monthDay70.indexOf(dateTimeFieldType77);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField79 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField42, dateTimeFieldType77);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField80 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField34, dateTimeFieldType77);
        int int81 = remainderDateTimeField34.getDivisor();
        long long83 = remainderDateTimeField34.roundHalfCeiling(1560631727858L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-4295406067200000L) + "'", long36 == (-4295406067200000L));
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(julianChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "52" + "'", str45.equals("52"));
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertNotNull(cachedDateTimeZone52);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertNotNull(julianChronology55);
        org.junit.Assert.assertNotNull(monthDay57);
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertNotNull(chronology59);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 36000000 + "'", int65 == 36000000);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(monthDay70);
        org.junit.Assert.assertNotNull(iSOChronology71);
        org.junit.Assert.assertNotNull(dateTimeField72);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 9 + "'", int76 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-1) + "'", int78 == (-1));
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 153 + "'", int81 == 153);
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 1546300800000L + "'", long83 == 1546300800000L);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.weekOfWeekyear();
        boolean boolean19 = property12.equals((java.lang.Object) dateTimeField18);
        int int20 = property12.getMaximumValueOverall();
        org.joda.time.DateTime dateTime22 = property12.setCopy((int) (byte) 10);
        org.joda.time.DateTime dateTime24 = property12.addWrapFieldToCopy(2019);
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        org.joda.time.MonthDay monthDay29 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology28);
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology31 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone30);
        org.joda.time.MonthDay monthDay32 = monthDay29.withChronologyRetainFields((org.joda.time.Chronology) julianChronology31);
        java.lang.String str33 = julianChronology31.toString();
        org.joda.time.DateTimeField dateTimeField34 = julianChronology31.weekyearOfCentury();
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) julianChronology31);
        org.joda.time.Chronology chronology36 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime24, (org.joda.time.ReadableInstant) dateTime35);
        org.joda.time.ReadableInstant readableInstant37 = null;
        org.joda.time.Chronology chronology38 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime24, readableInstant37);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(julianChronology31);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str33.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNotNull(chronology38);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        org.joda.time.DateTimeField dateTimeField6 = offsetDateTimeField3.getWrappedField();
        int int8 = offsetDateTimeField3.getLeapAmount((long) (byte) 1);
        int int10 = offsetDateTimeField3.getMaximumValue((long) 54);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 263478993 + "'", int10 == 263478993);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.weekOfWeekyear();
        boolean boolean19 = property12.equals((java.lang.Object) dateTimeField18);
        int int20 = property12.getMaximumValueOverall();
        org.joda.time.DateTime dateTime22 = property12.setCopy((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField25 = julianChronology24.days();
        boolean boolean26 = property12.equals((java.lang.Object) durationField25);
        org.joda.time.DateTime dateTime27 = property12.roundHalfCeilingCopy();
        java.util.Date date28 = dateTime27.toDate();
        org.joda.time.DateTime dateTime29 = dateTime27.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(dateTime29);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMinuteOfDay(13);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendMinuteOfHour(1910473);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusHours((int) (byte) 1);
        int int12 = dateTime11.getSecondOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (-28800000));
        java.util.Locale locale17 = null;
        int int18 = offsetDateTimeField16.getMaximumShortTextLength(locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField16.getType();
        org.joda.time.DateTime dateTime21 = dateTime11.withField(dateTimeFieldType19, (int) (byte) -1);
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str23 = gJChronology22.toString();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology22.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone25 = gJChronology22.getZone();
        org.joda.time.DateTime dateTime26 = dateTime21.toDateTime(dateTimeZone25);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = null;
        java.lang.String str28 = dateTime26.toString(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 61200 + "'", int12 == 61200);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "GJChronology[UTC]" + "'", str23.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-0001-12-19T00:52:58.100Z" + "'", str28.equals("-0001-12-19T00:52:58.100Z"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        org.joda.time.ReadablePartial readablePartial6 = null;
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsText(readablePartial6, (int) '#', locale8);
        long long12 = offsetDateTimeField3.getDifferenceAsLong(36000828L, (long) 'a');
        int int13 = offsetDateTimeField3.getOffset();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "35" + "'", str9.equals("35"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-28800000) + "'", int13 == (-28800000));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
        int int2 = gJChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, 0);
        long long7 = skipUndoDateTimeField5.roundHalfCeiling((long) (byte) 1);
        long long9 = skipUndoDateTimeField5.roundHalfEven((long) 2004);
        long long11 = skipUndoDateTimeField5.roundHalfFloor((long) 54);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField5.getRangeDurationField();
        long long14 = skipUndoDateTimeField5.roundHalfCeiling((-4295408573222000L));
        java.util.Locale locale16 = null;
        java.lang.String str17 = skipUndoDateTimeField5.getAsText(0, locale16);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology20);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone22);
        org.joda.time.MonthDay monthDay24 = monthDay21.withChronologyRetainFields((org.joda.time.Chronology) julianChronology23);
        org.joda.time.MonthDay monthDay26 = monthDay21.withDayOfMonth((int) (byte) 10);
        java.util.Locale locale28 = null;
        java.lang.String str29 = skipUndoDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) monthDay21, 828, locale28);
        int int31 = skipUndoDateTimeField5.get(828L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-4295408573222000L) + "'", long14 == (-4295408573222000L));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "828" + "'", str29.equals("828"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay5 = monthDay3.plusMonths((int) (byte) 100);
        org.joda.time.MonthDay monthDay7 = monthDay5.plusMonths(49733542);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.MonthDay monthDay9 = monthDay7.plus(readablePeriod8);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(monthDay9);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfMinute();
        org.joda.time.DurationField durationField3 = gJChronology0.minutes();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(10L);
        org.joda.time.MonthDay monthDay3 = monthDay1.minusMonths((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology13 = julianChronology9.withZone(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(chronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusMillis((int) (short) 0);
        org.joda.time.DateTime dateTime18 = dateTime14.plusYears((int) '#');
        int int19 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime21 = dateTime14.withMinuteOfHour((int) (byte) 1);
        boolean boolean22 = monthDay1.equals((java.lang.Object) (byte) 1);
        org.joda.time.MonthDay monthDay24 = monthDay1.minusDays(153);
        org.joda.time.MonthDay.Property property25 = monthDay24.monthOfYear();
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 36000000 + "'", int19 == 36000000);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(property25);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.weekOfWeekyear();
        boolean boolean19 = property12.equals((java.lang.Object) dateTimeField18);
        org.joda.time.DateTime dateTime20 = property12.withMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone22, 3);
        org.joda.time.MutableDateTime mutableDateTime25 = dateTime20.toMutableDateTime((org.joda.time.Chronology) julianChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(mutableDateTime25);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        long long12 = dateTime11.getMillis();
        org.joda.time.DateTime.Property property13 = dateTime11.year();
        org.joda.time.Chronology chronology14 = dateTime11.getChronology();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.weekOfWeekyear();
        boolean boolean19 = property12.equals((java.lang.Object) dateTimeField18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology22);
        org.joda.time.MonthDay monthDay24 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology26 = julianChronology22.withZone(dateTimeZone25);
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now(chronology26);
        org.joda.time.DateTime dateTime29 = dateTime27.minusWeeks(0);
        org.joda.time.DateTime.Property property30 = dateTime29.millisOfDay();
        org.joda.time.DateTime dateTime32 = dateTime29.withMillisOfSecond((int) (short) 1);
        int int33 = property12.getDifference((org.joda.time.ReadableInstant) dateTime32);
        org.joda.time.DateTime dateTime35 = dateTime32.withDayOfYear(19);
        int int36 = dateTime35.getDayOfWeek();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendDayOfMonth(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMonthOfYear((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.halfdays();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(10L);
        org.joda.time.MonthDay monthDay3 = monthDay1.minusMonths((int) (byte) 10);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay5 = monthDay3.minus(readablePeriod4);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(monthDay5);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) 10, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean7 = fixedDateTimeZone4.equals((java.lang.Object) false);
        int int9 = fixedDateTimeZone4.getOffsetFromLocal((long) 1);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = cachedDateTimeZone2.getUncachedZone();
        java.util.Locale locale5 = null;
        java.lang.String str6 = cachedDateTimeZone2.getShortName(28800009L, locale5);
        int int8 = cachedDateTimeZone2.getOffset(520L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+10:00" + "'", str6.equals("+10:00"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 36000000 + "'", int8 == 36000000);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        try {
            long long5 = gJChronology0.getDateTimeMillis(61253, 53330, 19, 30);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 53330 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        org.joda.time.DateTimeField dateTimeField6 = offsetDateTimeField3.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (-28800000));
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField10.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField10.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField15 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType13, 153);
        int int17 = dividedDateTimeField15.get((long) '#');
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (-28800000));
        java.util.Locale locale22 = null;
        int int23 = offsetDateTimeField21.getMaximumShortTextLength(locale22);
        org.joda.time.DateTimeField dateTimeField24 = offsetDateTimeField21.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (-28800000));
        java.util.Locale locale29 = null;
        int int30 = offsetDateTimeField28.getMaximumShortTextLength(locale29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField24, dateTimeFieldType31, 153);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField34 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField15, dateTimeFieldType31);
        long long36 = remainderDateTimeField34.roundHalfFloor((-4295408573222000L));
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology39 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = julianChronology39.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField(chronology37, dateTimeField40, 0);
        java.util.Locale locale44 = null;
        java.lang.String str45 = skipUndoDateTimeField42.getAsShortText((int) '4', locale44);
        org.joda.time.MonthDay monthDay47 = new org.joda.time.MonthDay(10L);
        org.joda.time.MonthDay monthDay49 = monthDay47.minusMonths((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone52 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone51);
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology55 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone54);
        org.joda.time.MonthDay monthDay56 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology55);
        org.joda.time.MonthDay monthDay57 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology55);
        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology59 = julianChronology55.withZone(dateTimeZone58);
        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now(chronology59);
        org.joda.time.DateTime dateTime62 = dateTime60.plusMillis((int) (short) 0);
        org.joda.time.DateTime dateTime64 = dateTime60.plusYears((int) '#');
        int int65 = dateTimeZone51.getOffset((org.joda.time.ReadableInstant) dateTime60);
        org.joda.time.DateTime dateTime67 = dateTime60.withMinuteOfHour((int) (byte) 1);
        boolean boolean68 = monthDay47.equals((java.lang.Object) (byte) 1);
        org.joda.time.MonthDay monthDay70 = monthDay47.minusDays(153);
        org.joda.time.chrono.ISOChronology iSOChronology71 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField72 = iSOChronology71.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField74 = new org.joda.time.field.OffsetDateTimeField(dateTimeField72, (-28800000));
        java.util.Locale locale75 = null;
        int int76 = offsetDateTimeField74.getMaximumShortTextLength(locale75);
        org.joda.time.DateTimeFieldType dateTimeFieldType77 = offsetDateTimeField74.getType();
        int int78 = monthDay70.indexOf(dateTimeFieldType77);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField79 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField42, dateTimeFieldType77);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField80 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField34, dateTimeFieldType77);
        try {
            long long83 = remainderDateTimeField34.set((long) 49715377, 49729403);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 49729403 for year must be in the range [0,152]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-4295406067200000L) + "'", long36 == (-4295406067200000L));
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(julianChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "52" + "'", str45.equals("52"));
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertNotNull(cachedDateTimeZone52);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertNotNull(julianChronology55);
        org.junit.Assert.assertNotNull(monthDay57);
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertNotNull(chronology59);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 36000000 + "'", int65 == 36000000);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(monthDay70);
        org.junit.Assert.assertNotNull(iSOChronology71);
        org.junit.Assert.assertNotNull(dateTimeField72);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 9 + "'", int76 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-1) + "'", int78 == (-1));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = iSOChronology0.equals(obj1);
        org.joda.time.DurationField durationField3 = iSOChronology0.halfdays();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTwoDigitYear(49715377);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendDayOfWeek(36000000);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        boolean boolean6 = offsetDateTimeField3.isLenient();
        int int7 = offsetDateTimeField3.getOffset();
        int int9 = offsetDateTimeField3.getLeapAmount((long) 49769163);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-28800000) + "'", int7 == (-28800000));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) 10, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendTwoDigitYear((int) (byte) 10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendCenturyOfEra((int) (byte) 1, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DateTime dateTime12 = dateTime9.withMinuteOfHour((int) '#');
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str14 = gJChronology13.toString();
        org.joda.time.DateTime dateTime15 = dateTime12.toDateTime((org.joda.time.Chronology) gJChronology13);
        org.joda.time.Chronology chronology16 = dateTime12.getChronology();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "GJChronology[UTC]" + "'", str14.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now(dateTimeZone1);
        org.joda.time.MonthDay.Property property3 = monthDay2.dayOfMonth();
        java.lang.String str4 = property3.getAsText();
        java.lang.String str5 = property3.getAsShortText();
        org.joda.time.MonthDay monthDay6 = property3.getMonthDay();
        java.lang.String str7 = property3.getAsShortText();
        java.util.Locale locale8 = null;
        java.lang.String str9 = property3.getAsShortText(locale8);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "31" + "'", str4.equals("31"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31" + "'", str5.equals("31"));
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31" + "'", str7.equals("31"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31" + "'", str9.equals("31"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology5);
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology9 = julianChronology5.withZone(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(chronology9);
        org.joda.time.DateTime dateTime12 = dateTime10.plusMillis((int) (short) 0);
        org.joda.time.DateTime dateTime14 = dateTime10.plusYears((int) '#');
        int int15 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime17 = dateTime10.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear(2);
        org.joda.time.DateTime.Property property20 = dateTime17.weekOfWeekyear();
        org.joda.time.DateTime dateTime22 = dateTime17.minusHours(53339);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 36000000 + "'", int15 == 36000000);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property12.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, 51, 4, 263478993);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.weekOfWeekyear();
        boolean boolean19 = property12.equals((java.lang.Object) dateTimeField18);
        int int20 = property12.getMaximumValueOverall();
        org.joda.time.DateTime dateTime22 = property12.setCopy((int) (byte) 10);
        org.joda.time.DateTime dateTime24 = property12.addWrapFieldToCopy(2019);
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        org.joda.time.MonthDay monthDay29 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology28);
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology31 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone30);
        org.joda.time.MonthDay monthDay32 = monthDay29.withChronologyRetainFields((org.joda.time.Chronology) julianChronology31);
        java.lang.String str33 = julianChronology31.toString();
        org.joda.time.DateTimeField dateTimeField34 = julianChronology31.weekyearOfCentury();
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) julianChronology31);
        org.joda.time.Chronology chronology36 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime24, (org.joda.time.ReadableInstant) dateTime35);
        org.joda.time.MonthDay monthDay37 = new org.joda.time.MonthDay(chronology36);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(julianChronology31);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str33.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(chronology36);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        org.joda.time.DateTime dateTime12 = dateTime9.withMillis((long) 45);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = copticChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = copticChronology2.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str3.equals("CopticChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        org.joda.time.DateTimeField dateTimeField6 = offsetDateTimeField3.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (-28800000));
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField10.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField10.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField15 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType13, 153);
        int int17 = dividedDateTimeField15.get((long) '#');
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (-28800000));
        java.util.Locale locale22 = null;
        int int23 = offsetDateTimeField21.getMaximumShortTextLength(locale22);
        org.joda.time.DateTimeField dateTimeField24 = offsetDateTimeField21.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (-28800000));
        java.util.Locale locale29 = null;
        int int30 = offsetDateTimeField28.getMaximumShortTextLength(locale29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField24, dateTimeFieldType31, 153);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField34 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField15, dateTimeFieldType31);
        long long36 = remainderDateTimeField34.roundHalfFloor((-4295408573222000L));
        long long39 = remainderDateTimeField34.addWrapField(1560631734235L, 0);
        java.util.Locale locale40 = null;
        int int41 = remainderDateTimeField34.getMaximumTextLength(locale40);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-4295406067200000L) + "'", long36 == (-4295406067200000L));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560631734235L + "'", long39 == 1560631734235L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 3 + "'", int41 == 3);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, 0);
        int int7 = skipUndoDateTimeField5.getMinimumValue((long) 10);
        long long9 = skipUndoDateTimeField5.roundHalfFloor(10L);
        org.joda.time.DurationField durationField10 = skipUndoDateTimeField5.getLeapDurationField();
        boolean boolean11 = skipUndoDateTimeField5.isSupported();
        boolean boolean12 = skipUndoDateTimeField5.isLenient();
        long long14 = skipUndoDateTimeField5.remainder(5618275739419704437L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNull(durationField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2904437L + "'", long14 == 2904437L);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumTextLength(locale4);
        long long8 = offsetDateTimeField3.getDifferenceAsLong((-1L), (long) 61253);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField5 = gJChronology0.centuries();
        org.joda.time.DurationField durationField6 = gJChronology0.centuries();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("13:48:35", (java.lang.Number) 1.0f, (java.lang.Number) 100.0d, (java.lang.Number) 100L);
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        java.lang.Number number6 = illegalFieldValueException4.getLowerBound();
        java.lang.String str7 = illegalFieldValueException4.toString();
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0d + "'", number6.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 1.0 for 13:48:35 must be in the range [100.0,100]" + "'", str7.equals("org.joda.time.IllegalFieldValueException: Value 1.0 for 13:48:35 must be in the range [100.0,100]"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, 0);
        java.util.Locale locale7 = null;
        java.lang.String str8 = skipUndoDateTimeField5.getAsShortText((int) '4', locale7);
        long long10 = skipUndoDateTimeField5.roundHalfEven((long) (short) 10);
        long long12 = skipUndoDateTimeField5.roundHalfEven((long) 19);
        java.lang.String str14 = skipUndoDateTimeField5.getAsShortText((long) (byte) 1);
        java.lang.String str16 = skipUndoDateTimeField5.getAsText((long) 57600100);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52" + "'", str8.equals("52"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "4" + "'", str14.equals("4"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "8" + "'", str16.equals("8"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        java.lang.Class<?> wildcardClass2 = iSOChronology0.getClass();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = cachedDateTimeZone5.getUncachedZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        java.lang.String str9 = cachedDateTimeZone7.getName((long) 2004);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+10:00" + "'", str9.equals("+10:00"));
        org.junit.Assert.assertNotNull(zonedChronology10);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        org.joda.time.DateTimeField dateTimeField6 = offsetDateTimeField3.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (-28800000));
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField10.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField10.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField15 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType13, 153);
        int int17 = dividedDateTimeField15.get((long) '#');
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (-28800000));
        java.util.Locale locale22 = null;
        int int23 = offsetDateTimeField21.getMaximumShortTextLength(locale22);
        org.joda.time.DateTimeField dateTimeField24 = offsetDateTimeField21.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (-28800000));
        java.util.Locale locale29 = null;
        int int30 = offsetDateTimeField28.getMaximumShortTextLength(locale29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField24, dateTimeFieldType31, 153);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField34 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField15, dateTimeFieldType31);
        long long36 = remainderDateTimeField34.roundHalfFloor((-4295408573222000L));
        long long39 = remainderDateTimeField34.addWrapField(1560631734235L, 0);
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.MonthDay monthDay43 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology42);
        org.joda.time.MonthDay monthDay44 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology42);
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology46 = julianChronology42.withZone(dateTimeZone45);
        org.joda.time.DateTime dateTime47 = org.joda.time.DateTime.now(chronology46);
        org.joda.time.DateTime dateTime49 = dateTime47.minusWeeks(0);
        org.joda.time.DateTime.Property property50 = dateTime49.dayOfWeek();
        org.joda.time.DateTime dateTime52 = dateTime49.plusMonths((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology55 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone54);
        org.joda.time.MonthDay monthDay56 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology55);
        org.joda.time.MonthDay monthDay57 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology55);
        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology59 = julianChronology55.withZone(dateTimeZone58);
        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now(chronology59);
        org.joda.time.DateTime dateTime62 = dateTime60.minusWeeks(0);
        org.joda.time.DateTime dateTime64 = dateTime60.plusSeconds(0);
        org.joda.time.DateTime.Property property65 = dateTime64.yearOfCentury();
        org.joda.time.DateTime dateTime66 = property65.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone68 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology69 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone68);
        org.joda.time.MonthDay monthDay70 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology69);
        org.joda.time.DateTimeField dateTimeField71 = julianChronology69.weekOfWeekyear();
        boolean boolean72 = property65.equals((java.lang.Object) dateTimeField71);
        org.joda.time.DateTime dateTime73 = property65.withMinimumValue();
        org.joda.time.DateTime.Property property74 = dateTime73.weekyear();
        org.joda.time.Chronology chronology75 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime49, (org.joda.time.ReadableInstant) dateTime73);
        org.joda.time.DateTime dateTime77 = dateTime73.withMillisOfDay(13);
        org.joda.time.Chronology chronology78 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime73);
        org.joda.time.MonthDay monthDay79 = new org.joda.time.MonthDay((java.lang.Object) long39, chronology78);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-4295406067200000L) + "'", long36 == (-4295406067200000L));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560631734235L + "'", long39 == 1560631734235L);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(chronology46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertNotNull(julianChronology55);
        org.junit.Assert.assertNotNull(monthDay57);
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertNotNull(chronology59);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(property65);
        org.junit.Assert.assertNotNull(dateTime66);
        org.junit.Assert.assertNotNull(dateTimeZone68);
        org.junit.Assert.assertNotNull(julianChronology69);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(dateTime73);
        org.junit.Assert.assertNotNull(property74);
        org.junit.Assert.assertNotNull(chronology75);
        org.junit.Assert.assertNotNull(dateTime77);
        org.junit.Assert.assertNotNull(chronology78);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, 0);
        long long7 = skipUndoDateTimeField5.roundHalfCeiling((long) (byte) 1);
        long long9 = skipUndoDateTimeField5.roundHalfEven((long) 2004);
        long long11 = skipUndoDateTimeField5.roundHalfFloor((long) 54);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField5.getRangeDurationField();
        java.util.Locale locale13 = null;
        int int14 = skipUndoDateTimeField5.getMaximumTextLength(locale13);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now(dateTimeZone1);
        org.joda.time.MonthDay.Property property3 = monthDay2.dayOfMonth();
        java.lang.String str4 = property3.getAsText();
        java.lang.String str5 = property3.getAsShortText();
        int int6 = property3.getMaximumValue();
        int int7 = property3.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "31" + "'", str4.equals("31"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31" + "'", str5.equals("31"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.halfdays();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) cachedDateTimeZone4);
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone4);
        java.lang.String str7 = zonedChronology6.toString();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = cachedDateTimeZone10.getUncachedZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
        org.joda.time.Chronology chronology13 = zonedChronology6.withZone(dateTimeZone11);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[GJChronology[UTC], +10:00]" + "'", str7.equals("ZonedChronology[GJChronology[UTC], +10:00]"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) 10, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) 10, (int) (byte) 10);
        org.joda.time.Chronology chronology11 = iSOChronology5.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        long long13 = fixedDateTimeZone10.nextTransition((-187199990L));
        java.util.TimeZone timeZone14 = fixedDateTimeZone10.toTimeZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        try {
            long long20 = gregorianChronology15.getDateTimeMillis(1910320, 19, (int) (short) 1, (-25200000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25200000 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-187199990L) + "'", long13 == (-187199990L));
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = offsetDateTimeField3.getType();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone14);
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology15);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.MonthDay monthDay19 = monthDay16.withChronologyRetainFields((org.joda.time.Chronology) julianChronology18);
        java.lang.String str20 = julianChronology18.toString();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology18.weekyearOfCentury();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) julianChronology18);
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay(10L);
        int[] intArray26 = julianChronology18.get((org.joda.time.ReadablePartial) monthDay24, (long) 13);
        int[] intArray28 = offsetDateTimeField3.add((org.joda.time.ReadablePartial) monthDay10, 49715377, intArray26, 0);
        java.util.Locale locale29 = null;
        int int30 = offsetDateTimeField3.getMaximumTextLength(locale29);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str20.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        boolean boolean6 = offsetDateTimeField3.isLenient();
        long long9 = offsetDateTimeField3.add((long) 153, 69);
        long long11 = offsetDateTimeField3.roundCeiling(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2177452800153L + "'", long9 == 2177452800153L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.MonthDay monthDay6 = monthDay3.withChronologyRetainFields((org.joda.time.Chronology) julianChronology5);
        java.lang.String str7 = julianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology5.weekyearOfCentury();
        long long12 = julianChronology5.add((long) 153, (-81L), (int) (byte) 0);
        org.joda.time.DurationField durationField13 = julianChronology5.minutes();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str7.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 153L + "'", long12 == 153L);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(10L);
        java.lang.String str3 = monthDay1.toString("4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4" + "'", str3.equals("4"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 2000);
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(mutableDateTime2);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime dateTime13 = dateTime7.minusSeconds(13);
        org.joda.time.DateTime.Property property14 = dateTime7.yearOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.weekOfWeekyear();
        boolean boolean19 = property12.equals((java.lang.Object) dateTimeField18);
        int int20 = property12.getMaximumValueOverall();
        org.joda.time.DateTime dateTime22 = property12.setCopy((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone23 = dateTime22.getZone();
        org.joda.time.DateTime.Property property24 = dateTime22.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone26);
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology27);
        org.joda.time.MonthDay monthDay29 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology27);
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology31 = julianChronology27.withZone(dateTimeZone30);
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now(chronology31);
        org.joda.time.DateTime dateTime34 = dateTime32.minusWeeks(0);
        org.joda.time.DateTime dateTime36 = dateTime32.plusSeconds(0);
        org.joda.time.DateTime.Property property37 = dateTime36.yearOfCentury();
        org.joda.time.DateTime dateTime38 = property37.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology41 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone40);
        org.joda.time.MonthDay monthDay42 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology41);
        org.joda.time.DateTimeField dateTimeField43 = julianChronology41.weekOfWeekyear();
        boolean boolean44 = property37.equals((java.lang.Object) dateTimeField43);
        org.joda.time.DateTime dateTime45 = property37.withMinimumValue();
        java.lang.Object obj46 = null;
        boolean boolean47 = property37.equals(obj46);
        org.joda.time.DateTime dateTime48 = property37.roundHalfFloorCopy();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone53 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) 10, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology54 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone53);
        org.joda.time.MutableDateTime mutableDateTime55 = dateTime48.toMutableDateTime((org.joda.time.Chronology) iSOChronology54);
        org.joda.time.DateTime dateTime57 = dateTime48.plusHours(54);
        int int58 = property24.compareTo((org.joda.time.ReadableInstant) dateTime48);
        org.joda.time.DateTime.Property property59 = dateTime48.secondOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(julianChronology27);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(julianChronology41);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(iSOChronology54);
        org.junit.Assert.assertNotNull(mutableDateTime55);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertNotNull(property59);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        java.lang.StringBuffer stringBuffer2 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology5);
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology9 = julianChronology5.withZone(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(chronology9);
        org.joda.time.DateTime dateTime12 = dateTime10.minusWeeks(0);
        org.joda.time.DateTime.Property property13 = dateTime12.millisOfDay();
        int int14 = property13.get();
        org.joda.time.Instant instant16 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Instant instant19 = instant16.withDurationAdded(readableDuration17, 13);
        long long20 = property13.getDifferenceAsLong((org.joda.time.ReadableInstant) instant19);
        org.joda.time.Instant instant23 = instant19.withDurationAdded((long) (short) -1, (int) (short) -1);
        org.joda.time.Instant instant25 = instant23.minus((long) 86399999);
        try {
            dateTimeFormatter0.printTo(stringBuffer2, (org.joda.time.ReadableInstant) instant25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 57600100 + "'", int14 == 57600100);
        org.junit.Assert.assertNotNull(instant19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 3L + "'", long20 == 3L);
        org.junit.Assert.assertNotNull(instant23);
        org.junit.Assert.assertNotNull(instant25);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 36000000);
        org.joda.time.Instant instant3 = org.joda.time.Instant.now();
        org.joda.time.Instant instant5 = instant3.withMillis((long) 49733542);
        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) instant3);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, 0);
        long long7 = skipUndoDateTimeField5.roundHalfCeiling((long) (byte) 1);
        int int9 = skipUndoDateTimeField5.getMinimumValue((long) (byte) 0);
        int int11 = skipUndoDateTimeField5.getMinimumValue(0L);
        java.lang.String str13 = skipUndoDateTimeField5.getAsText(100L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "4" + "'", str13.equals("4"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.weekOfWeekyear();
        boolean boolean19 = property12.equals((java.lang.Object) dateTimeField18);
        int int20 = property12.getMaximumValueOverall();
        org.joda.time.DateTime dateTime22 = property12.setCopy((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField25 = julianChronology24.days();
        boolean boolean26 = property12.equals((java.lang.Object) durationField25);
        org.joda.time.DateTime dateTime27 = property12.roundHalfCeilingCopy();
        java.util.Date date28 = dateTime27.toDate();
        org.joda.time.MutableDateTime mutableDateTime29 = dateTime27.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(mutableDateTime29);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "2001");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("CopticChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"CopticChronology[America/Los_Ang...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMonthOfYear(0);
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendFractionOfSecond((int) (byte) 10, 51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) 10, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        boolean boolean12 = fixedDateTimeZone9.equals((java.lang.Object) false);
        long long14 = fixedDateTimeZone9.previousTransition((long) ' ');
        java.lang.String str16 = fixedDateTimeZone9.getNameKey(0L);
        java.util.TimeZone timeZone17 = fixedDateTimeZone9.toTimeZone();
        int int19 = fixedDateTimeZone9.getOffsetFromLocal((long) (-49715377));
        try {
            org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((int) (byte) 100, 10, 422, 49733542, 1787253509, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 49733542 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 32L + "'", long14 == 32L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusHours((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone16);
        org.joda.time.MonthDay monthDay18 = monthDay15.withChronologyRetainFields((org.joda.time.Chronology) julianChronology17);
        java.lang.String str19 = julianChronology17.toString();
        org.joda.time.DateTime dateTime20 = dateTime7.toDateTime((org.joda.time.Chronology) julianChronology17);
        int int21 = dateTime7.getSecondOfMinute();
        java.lang.String str22 = dateTime7.toString();
        org.joda.time.DateTime dateTime26 = dateTime7.withDate(12, 10, (int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str19.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1969-12-18T16:00:00.100-08:00" + "'", str22.equals("1969-12-18T16:00:00.100-08:00"));
        org.junit.Assert.assertNotNull(dateTime26);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str2 = gJChronology1.toString();
        org.joda.time.Chronology chronology3 = gJChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.dayOfMonth();
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(1560631727858L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (-28800000));
        long long12 = offsetDateTimeField9.set((long) (short) 100, "35");
        long long15 = offsetDateTimeField9.getDifferenceAsLong(36000828L, (long) 1);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(10L);
        org.joda.time.MonthDay monthDay19 = monthDay17.minusMonths((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone24);
        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology25);
        org.joda.time.MonthDay monthDay27 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology25);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology29 = julianChronology25.withZone(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(chronology29);
        org.joda.time.DateTime dateTime32 = dateTime30.plusMillis((int) (short) 0);
        org.joda.time.DateTime dateTime34 = dateTime30.plusYears((int) '#');
        int int35 = dateTimeZone21.getOffset((org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime37 = dateTime30.withMinuteOfHour((int) (byte) 1);
        boolean boolean38 = monthDay17.equals((java.lang.Object) (byte) 1);
        org.joda.time.MonthDay monthDay40 = monthDay17.minusDays(153);
        int int41 = offsetDateTimeField9.getMaximumValue((org.joda.time.ReadablePartial) monthDay17);
        org.joda.time.MonthDay monthDay43 = new org.joda.time.MonthDay(10L);
        org.joda.time.MonthDay monthDay45 = monthDay43.minusMonths((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology47 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone46);
        org.joda.time.DateTimeField dateTimeField48 = julianChronology47.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology51 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone50);
        org.joda.time.MonthDay monthDay52 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology51);
        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology54 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone53);
        org.joda.time.MonthDay monthDay55 = monthDay52.withChronologyRetainFields((org.joda.time.Chronology) julianChronology54);
        java.lang.Class<?> wildcardClass56 = monthDay52.getClass();
        int[] intArray58 = julianChronology47.get((org.joda.time.ReadablePartial) monthDay52, 1L);
        boolean boolean59 = monthDay45.equals((java.lang.Object) monthDay52);
        boolean boolean60 = monthDay17.isEqual((org.joda.time.ReadablePartial) monthDay52);
        boolean boolean61 = monthDay5.isBefore((org.joda.time.ReadablePartial) monthDay52);
        java.util.Locale locale63 = null;
        java.lang.String str64 = monthDay5.toString("2001", locale63);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[UTC]" + "'", str2.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 908779154918400100L + "'", long12 == 908779154918400100L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 36000000 + "'", int35 == 36000000);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 263478993 + "'", int41 == 263478993);
        org.junit.Assert.assertNotNull(monthDay45);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(julianChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(julianChronology51);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(julianChronology54);
        org.junit.Assert.assertNotNull(monthDay55);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "2001" + "'", str64.equals("2001"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.MonthDay monthDay6 = monthDay3.withChronologyRetainFields((org.joda.time.Chronology) julianChronology5);
        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.era();
        org.joda.time.DurationField durationField8 = julianChronology5.millis();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField5 = gJChronology0.centuries();
        try {
            long long8 = durationField5.subtract((long) 1, (-25200000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1774965326 for year must be in the range [-292275054,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay5 = monthDay3.plusMonths((int) (byte) 100);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType7 = monthDay3.getFieldType(53339);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 53339");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay5);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now(dateTimeZone1);
        org.joda.time.MonthDay.Property property3 = monthDay2.dayOfMonth();
        java.lang.String str4 = property3.getAsText();
        java.lang.String str5 = property3.getAsShortText();
        int int6 = property3.getMaximumValue();
        org.joda.time.MonthDay monthDay8 = property3.addToCopy(2004);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "31" + "'", str4.equals("31"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31" + "'", str5.equals("31"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
        org.junit.Assert.assertNotNull(monthDay8);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (short) 1);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
        java.lang.Appendable appendable4 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology7);
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology7);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology11 = julianChronology7.withZone(dateTimeZone10);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(chronology11);
        org.joda.time.DateTime dateTime14 = dateTime12.minusWeeks(0);
        org.joda.time.DateTime dateTime16 = dateTime12.plusSeconds(0);
        long long17 = dateTime16.getMillis();
        org.joda.time.DateTime.Property property18 = dateTime16.year();
        try {
            dateTimeFormatter2.printTo(appendable4, (org.joda.time.ReadableInstant) dateTime16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
        org.junit.Assert.assertNotNull(property18);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
        int int2 = gJChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, (int) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology4);
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology8 = julianChronology4.withZone(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(chronology8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths(2);
        boolean boolean12 = buddhistChronology0.equals((java.lang.Object) dateTime9);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("13:48:35", (java.lang.Number) 1.0f, (java.lang.Number) 100.0d, (java.lang.Number) 100L);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        illegalFieldValueException4.prependMessage("0");
        org.junit.Assert.assertNull(dateTimeFieldType5);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        org.joda.time.DateTimeField dateTimeField6 = offsetDateTimeField3.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (-28800000));
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField10.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField10.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField15 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType13, 153);
        int int17 = dividedDateTimeField15.get((long) '#');
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (-28800000));
        java.util.Locale locale22 = null;
        int int23 = offsetDateTimeField21.getMaximumShortTextLength(locale22);
        org.joda.time.DateTimeField dateTimeField24 = offsetDateTimeField21.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (-28800000));
        java.util.Locale locale29 = null;
        int int30 = offsetDateTimeField28.getMaximumShortTextLength(locale29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField24, dateTimeFieldType31, 153);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField34 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField15, dateTimeFieldType31);
        long long36 = remainderDateTimeField34.roundHalfFloor((-4295408573222000L));
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology39 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = julianChronology39.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField(chronology37, dateTimeField40, 0);
        java.util.Locale locale44 = null;
        java.lang.String str45 = skipUndoDateTimeField42.getAsShortText((int) '4', locale44);
        org.joda.time.MonthDay monthDay47 = new org.joda.time.MonthDay(10L);
        org.joda.time.MonthDay monthDay49 = monthDay47.minusMonths((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone52 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone51);
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology55 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone54);
        org.joda.time.MonthDay monthDay56 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology55);
        org.joda.time.MonthDay monthDay57 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology55);
        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology59 = julianChronology55.withZone(dateTimeZone58);
        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now(chronology59);
        org.joda.time.DateTime dateTime62 = dateTime60.plusMillis((int) (short) 0);
        org.joda.time.DateTime dateTime64 = dateTime60.plusYears((int) '#');
        int int65 = dateTimeZone51.getOffset((org.joda.time.ReadableInstant) dateTime60);
        org.joda.time.DateTime dateTime67 = dateTime60.withMinuteOfHour((int) (byte) 1);
        boolean boolean68 = monthDay47.equals((java.lang.Object) (byte) 1);
        org.joda.time.MonthDay monthDay70 = monthDay47.minusDays(153);
        org.joda.time.chrono.ISOChronology iSOChronology71 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField72 = iSOChronology71.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField74 = new org.joda.time.field.OffsetDateTimeField(dateTimeField72, (-28800000));
        java.util.Locale locale75 = null;
        int int76 = offsetDateTimeField74.getMaximumShortTextLength(locale75);
        org.joda.time.DateTimeFieldType dateTimeFieldType77 = offsetDateTimeField74.getType();
        int int78 = monthDay70.indexOf(dateTimeFieldType77);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField79 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField42, dateTimeFieldType77);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField80 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField34, dateTimeFieldType77);
        int int81 = remainderDateTimeField34.getDivisor();
        long long84 = remainderDateTimeField34.getDifferenceAsLong(53242L, (long) (-28800000));
        long long86 = remainderDateTimeField34.roundHalfCeiling(60L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-4295406067200000L) + "'", long36 == (-4295406067200000L));
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(julianChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "52" + "'", str45.equals("52"));
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertNotNull(cachedDateTimeZone52);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertNotNull(julianChronology55);
        org.junit.Assert.assertNotNull(monthDay57);
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertNotNull(chronology59);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 36000000 + "'", int65 == 36000000);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(monthDay70);
        org.junit.Assert.assertNotNull(iSOChronology71);
        org.junit.Assert.assertNotNull(dateTimeField72);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 9 + "'", int76 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-1) + "'", int78 == (-1));
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 153 + "'", int81 == 153);
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 0L + "'", long84 == 0L);
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 0L + "'", long86 == 0L);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendDayOfMonth(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendYearOfCentury(57653339, 53339);
        boolean boolean9 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendLiteral("35");
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatterBuilder10.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder0.appendOptional(dateTimeParser15);
        boolean boolean17 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, 0);
        long long7 = skipUndoDateTimeField5.roundHalfCeiling((long) (byte) 1);
        long long9 = skipUndoDateTimeField5.roundHalfEven((long) 2004);
        long long11 = skipUndoDateTimeField5.roundHalfFloor((long) 54);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField5.getRangeDurationField();
        long long14 = skipUndoDateTimeField5.roundHalfCeiling((-4295408573222000L));
        java.util.Locale locale16 = null;
        java.lang.String str17 = skipUndoDateTimeField5.getAsText(0, locale16);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone20);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology21);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        org.joda.time.MonthDay monthDay25 = monthDay22.withChronologyRetainFields((org.joda.time.Chronology) julianChronology24);
        java.lang.String str26 = julianChronology24.toString();
        org.joda.time.DateTimeField dateTimeField27 = julianChronology24.weekyearOfCentury();
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) julianChronology24);
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay(10L);
        int[] intArray32 = julianChronology24.get((org.joda.time.ReadablePartial) monthDay30, (long) 13);
        java.lang.String str34 = monthDay30.toString("10");
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone36);
        org.joda.time.MonthDay monthDay38 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology37);
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology40 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone39);
        org.joda.time.MonthDay monthDay41 = monthDay38.withChronologyRetainFields((org.joda.time.Chronology) julianChronology40);
        java.lang.Class<?> wildcardClass42 = monthDay38.getClass();
        boolean boolean43 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay38);
        boolean boolean44 = monthDay30.isAfter((org.joda.time.ReadablePartial) monthDay38);
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology47 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone46);
        org.joda.time.DateTimeField dateTimeField48 = julianChronology47.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology51 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone50);
        org.joda.time.MonthDay monthDay52 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology51);
        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology54 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone53);
        org.joda.time.MonthDay monthDay55 = monthDay52.withChronologyRetainFields((org.joda.time.Chronology) julianChronology54);
        java.lang.Class<?> wildcardClass56 = monthDay52.getClass();
        int[] intArray58 = julianChronology47.get((org.joda.time.ReadablePartial) monthDay52, 1L);
        int[] intArray60 = skipUndoDateTimeField5.addWrapField((org.joda.time.ReadablePartial) monthDay30, (int) (byte) 0, intArray58, 49769163);
        try {
            org.joda.time.DateTimeField dateTimeField62 = monthDay30.getField(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 13");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-4295408573222000L) + "'", long14 == (-4295408573222000L));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str26.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "10" + "'", str34.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(julianChronology40);
        org.junit.Assert.assertNotNull(monthDay41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(julianChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(julianChronology51);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(julianChronology54);
        org.junit.Assert.assertNotNull(monthDay55);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray60);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setFixedSavings("1", 0);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendDayOfMonth(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfDay(49733542, 22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMonthOfYear(69);
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatterBuilder2.toParser();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfMinute();
        org.joda.time.Instant instant3 = gJChronology0.getGregorianCutover();
        java.lang.String str4 = gJChronology0.toString();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GJChronology[UTC]" + "'", str4.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        org.joda.time.DateTimeField dateTimeField6 = offsetDateTimeField3.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (-28800000));
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField10.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField10.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField15 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType13, 153);
        int int17 = dividedDateTimeField15.get((long) '#');
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (-28800000));
        java.util.Locale locale22 = null;
        int int23 = offsetDateTimeField21.getMaximumShortTextLength(locale22);
        org.joda.time.DateTimeField dateTimeField24 = offsetDateTimeField21.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (-28800000));
        java.util.Locale locale29 = null;
        int int30 = offsetDateTimeField28.getMaximumShortTextLength(locale29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField24, dateTimeFieldType31, 153);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField34 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField15, dateTimeFieldType31);
        boolean boolean35 = remainderDateTimeField34.isSupported();
        long long38 = remainderDateTimeField34.set((-4295406067200000L), 45);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-4295090534400000L) + "'", long38 == (-4295090534400000L));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        org.joda.time.ReadablePartial readablePartial6 = null;
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsText(readablePartial6, (int) '#', locale8);
        boolean boolean11 = offsetDateTimeField3.isLeap((long) 19);
        int int13 = offsetDateTimeField3.getMinimumValue((-18000000L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "35" + "'", str9.equals("35"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-321075054) + "'", int13 == (-321075054));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        int int10 = dateTime7.getHourOfDay();
        boolean boolean12 = dateTime7.isEqual(1560631769066L);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime15 = dateTime7.withPeriodAdded(readablePeriod13, (int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 16 + "'", int10 == 16);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        org.joda.time.ReadablePartial readablePartial6 = null;
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsText(readablePartial6, (int) '#', locale8);
        boolean boolean11 = offsetDateTimeField3.isLeap((long) 19);
        long long14 = offsetDateTimeField3.getDifferenceAsLong(0L, 5618275739419704437L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "35" + "'", str9.equals("35"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-178036070L) + "'", long14 == (-178036070L));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.year();
        long long6 = iSOChronology1.add(28800009L, 0L, 3);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) 100, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.plus(readablePeriod8);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28800009L + "'", long6 == 28800009L);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, 0);
        long long7 = skipUndoDateTimeField5.roundHalfCeiling((long) (byte) 1);
        long long9 = skipUndoDateTimeField5.roundHalfEven((long) 2004);
        long long11 = skipUndoDateTimeField5.roundHalfFloor((long) 54);
        long long14 = skipUndoDateTimeField5.add((long) (-28800000), 13);
        long long17 = skipUndoDateTimeField5.getDifferenceAsLong((long) 45, (long) 4);
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipUndoDateTimeField5.getAsShortText((long) 153, locale19);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 18000000L + "'", long14 == 18000000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "4" + "'", str20.equals("4"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.joda.time.DateTime dateTime3 = dateTimeFormatter0.parseDateTime("16:00:00");
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds(0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfMinute();
        org.joda.time.Instant instant3 = gJChronology0.getGregorianCutover();
        org.joda.time.Instant instant4 = instant3.toInstant();
        org.joda.time.MutableDateTime mutableDateTime5 = instant4.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = offsetDateTimeField3.getType();
        java.lang.Number number8 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 153, number8, (java.lang.Number) 153L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) (short) -1, "Dec");
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MonthDay monthDay9 = monthDay6.withChronologyRetainFields((org.joda.time.Chronology) julianChronology8);
        java.lang.Class<?> wildcardClass10 = monthDay6.getClass();
        int[] intArray12 = julianChronology1.get((org.joda.time.ReadablePartial) monthDay6, 1L);
        org.joda.time.DurationField durationField13 = julianChronology1.minutes();
        try {
            long long21 = julianChronology1.getDateTimeMillis((int) (byte) 1, 34, 422, 36000000, 1, 20, 1910473);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 36000000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("0");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"0/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay(0);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) 10, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) 10, (int) (byte) 10);
        org.joda.time.Chronology chronology11 = iSOChronology5.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        long long13 = fixedDateTimeZone10.nextTransition((-187199990L));
        java.util.TimeZone timeZone14 = fixedDateTimeZone10.toTimeZone();
        org.joda.time.LocalDateTime localDateTime15 = null;
        boolean boolean16 = fixedDateTimeZone10.isLocalDateTimeGap(localDateTime15);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-187199990L) + "'", long13 == (-187199990L));
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(21, 'a', 2054, 2000, 57653339, false, (int) (byte) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder0.addRecurringSavings("", 61200, 61200, 4, '#', 134, 0, 2004, true, 0);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder19);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusHours((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone16);
        org.joda.time.MonthDay monthDay18 = monthDay15.withChronologyRetainFields((org.joda.time.Chronology) julianChronology17);
        java.lang.String str19 = julianChronology17.toString();
        org.joda.time.DateTime dateTime20 = dateTime7.toDateTime((org.joda.time.Chronology) julianChronology17);
        org.joda.time.DateTime.Property property21 = dateTime20.millisOfSecond();
        org.joda.time.Interval interval22 = property21.toInterval();
        org.joda.time.ReadableInterval readableInterval23 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval22);
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval22);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str19.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(interval22);
        org.junit.Assert.assertNotNull(readableInterval23);
        org.junit.Assert.assertNotNull(chronology24);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("-28798030", (java.lang.Number) 18000000L, (java.lang.Number) (-18000000L), (java.lang.Number) (-1L));
        illegalFieldValueException4.prependMessage("");
        java.lang.String str7 = illegalFieldValueException4.getIllegalValueAsString();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (-28800000));
        java.util.Locale locale12 = null;
        int int13 = offsetDateTimeField11.getMaximumShortTextLength(locale12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField11.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) (-18000000L), "10");
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException17);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "18000000" + "'", str7.equals("18000000"));
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, 0);
        int int7 = skipUndoDateTimeField5.getMinimumValue((long) 10);
        int int9 = skipUndoDateTimeField5.getLeapAmount(10L);
        int int11 = skipUndoDateTimeField5.getLeapAmount(0L);
        int int13 = skipUndoDateTimeField5.getLeapAmount((long) 216);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DateTime dateTime15 = dateTime13.minus((long) 31);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 54L, (java.lang.Number) 54, (java.lang.Number) 10);
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        int int9 = cachedDateTimeZone7.getOffset((long) 1);
        long long11 = cachedDateTimeZone7.convertUTCToLocal(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-28800000) + "'", int9 == (-28800000));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-28800000L) + "'", long11 == (-28800000L));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.weekOfWeekyear();
        boolean boolean19 = property12.equals((java.lang.Object) dateTimeField18);
        int int20 = property12.getMaximumValueOverall();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone22);
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology23);
        org.joda.time.MonthDay monthDay25 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology23);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology27 = julianChronology23.withZone(dateTimeZone26);
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now(chronology27);
        org.joda.time.DateTime dateTime30 = dateTime28.minusWeeks(0);
        org.joda.time.DateTime dateTime32 = dateTime28.plusSeconds(0);
        org.joda.time.DateTime.Property property33 = dateTime32.yearOfCentury();
        org.joda.time.DateTime dateTime34 = property33.withMaximumValue();
        long long35 = property12.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime34);
        boolean boolean36 = property12.isLeap();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-31L) + "'", long35 == (-31L));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.weekOfWeekyear();
        boolean boolean19 = property12.equals((java.lang.Object) dateTimeField18);
        int int20 = property12.getMaximumValueOverall();
        java.util.Locale locale21 = null;
        int int22 = property12.getMaximumTextLength(locale21);
        java.util.Locale locale23 = null;
        java.lang.String str24 = property12.getAsShortText(locale23);
        org.joda.time.DurationField durationField25 = property12.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "69" + "'", str24.equals("69"));
        org.junit.Assert.assertNull(durationField25);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusHours((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone16);
        org.joda.time.MonthDay monthDay18 = monthDay15.withChronologyRetainFields((org.joda.time.Chronology) julianChronology17);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone20);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology21);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        org.joda.time.MonthDay monthDay25 = monthDay22.withChronologyRetainFields((org.joda.time.Chronology) julianChronology24);
        java.lang.Class<?> wildcardClass26 = monthDay22.getClass();
        long long28 = julianChronology17.set((org.joda.time.ReadablePartial) monthDay22, 10L);
        org.joda.time.DateTime dateTime29 = dateTime7.toDateTime((org.joda.time.Chronology) julianChronology17);
        org.joda.time.DurationField durationField30 = julianChronology17.weeks();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10L + "'", long28 == 10L);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(durationField30);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (-28800000));
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumShortTextLength(locale4);
        org.joda.time.DateTimeField dateTimeField6 = offsetDateTimeField3.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (-28800000));
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField10.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField10.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField15 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType13, 153);
        int int17 = dividedDateTimeField15.get((long) '#');
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (-28800000));
        java.util.Locale locale22 = null;
        int int23 = offsetDateTimeField21.getMaximumShortTextLength(locale22);
        org.joda.time.DateTimeField dateTimeField24 = offsetDateTimeField21.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (-28800000));
        java.util.Locale locale29 = null;
        int int30 = offsetDateTimeField28.getMaximumShortTextLength(locale29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField24, dateTimeFieldType31, 153);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField34 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField15, dateTimeFieldType31);
        try {
            long long37 = remainderDateTimeField34.set(69L, "-321075054");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -321075054 for year must be in the range [0,152]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusHours((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone16);
        org.joda.time.MonthDay monthDay18 = monthDay15.withChronologyRetainFields((org.joda.time.Chronology) julianChronology17);
        java.lang.String str19 = julianChronology17.toString();
        org.joda.time.DateTime dateTime20 = dateTime7.toDateTime((org.joda.time.Chronology) julianChronology17);
        org.joda.time.DateTime.Property property21 = dateTime20.millisOfSecond();
        org.joda.time.Interval interval22 = property21.toInterval();
        org.joda.time.ReadableInterval readableInterval23 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval22);
        org.joda.time.ReadableInterval readableInterval24 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval23);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str19.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(interval22);
        org.junit.Assert.assertNotNull(readableInterval23);
        org.junit.Assert.assertNotNull(readableInterval24);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 100, (org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.weekOfWeekyear();
        boolean boolean19 = property12.equals((java.lang.Object) dateTimeField18);
        int int20 = property12.getMaximumValueOverall();
        org.joda.time.DateTime dateTime22 = property12.setCopy((int) (byte) 10);
        org.joda.time.DateTime dateTime24 = dateTime22.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property25 = dateTime22.year();
        org.joda.time.DateTime dateTime27 = dateTime22.minusWeeks((int) (byte) 0);
        boolean boolean28 = dateTime27.isAfterNow();
        java.lang.String str29 = dateTime27.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1910-12-18T16:00:00.100-08:00" + "'", str29.equals("1910-12-18T16:00:00.100-08:00"));
    }
}

