import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test001");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560628908182L + "'", long1 == 1560628908182L);
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, number1, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (short) 1, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDay();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField3 = new org.joda.time.field.RemainderDateTimeField(dateTimeField0, dateTimeFieldType1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.weeks();
        java.lang.String str1 = periodType0.getName();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Weeks" + "'", str1.equals("Weeks"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.DurationField durationField2 = null;
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField3 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField1, durationField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(10L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        try {
            long long9 = iSOChronology0.getDateTimeMillis((int) ' ', (int) (byte) 100, 10, (int) (short) 10, (int) (short) 0, (int) ' ', 52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (short) 0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.millisOfSecond();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 100, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = null;
        try {
            org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType2 = periodType0.getFieldType((int) (short) 0);
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType5 = periodType3.getFieldType((int) (short) 0);
        org.joda.time.Period period6 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval8);
        org.joda.time.Period period10 = new org.joda.time.Period((long) '4', chronology9);
        org.joda.time.Period period12 = period10.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType13 = period12.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType15 = periodType13.getFieldType((int) (short) 0);
        org.joda.time.Period period17 = period6.withField(durationFieldType15, (int) (short) 0);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType20 = periodType18.getFieldType((int) (short) 0);
        org.joda.time.ReadableInterval readableInterval22 = null;
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval22);
        org.joda.time.Period period24 = new org.joda.time.Period((long) '4', chronology23);
        org.joda.time.Period period26 = period24.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType27 = period26.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType29 = periodType27.getFieldType((int) (short) 0);
        org.joda.time.ReadableInterval readableInterval31 = null;
        org.joda.time.Chronology chronology32 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval31);
        org.joda.time.Period period33 = new org.joda.time.Period((long) '4', chronology32);
        org.joda.time.Period period35 = period33.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType36 = period35.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType38 = periodType36.getFieldType((int) (short) 0);
        org.joda.time.DurationFieldType[] durationFieldTypeArray39 = new org.joda.time.DurationFieldType[] { durationFieldType2, durationFieldType5, durationFieldType15, durationFieldType20, durationFieldType29, durationFieldType38 };
        try {
            org.joda.time.PeriodType periodType40 = org.joda.time.PeriodType.forFields(durationFieldTypeArray39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: PeriodType does not support fields: [days, days, years, years]");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(durationFieldType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(durationFieldType5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(durationFieldType29);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertNotNull(durationFieldType38);
        org.junit.Assert.assertNotNull(durationFieldTypeArray39);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (short) 1, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "PT0.052S");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType6 = period5.getPeriodType();
        try {
            org.joda.time.Seconds seconds7 = period5.toStandardSeconds();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Seconds as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        try {
            long long12 = iSOChronology2.getDateTimeMillis((long) (byte) -1, (int) (byte) 100, (-1), (int) '#', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(2440588L, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2440578L + "'", long2 == 2440578L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 1, periodType1, (org.joda.time.Chronology) iSOChronology4);
        try {
            long long15 = iSOChronology4.getDateTimeMillis((int) (short) 0, (int) (short) 1, 0, 0, 1, (int) (short) -1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            int[] intArray6 = iSOChronology0.get(readablePartial4, (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "Weeks", "Weeks");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "Weeks", "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) -1, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2) + "'", int2 == (-2));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = new org.joda.time.Period(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) '4', chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        int int7 = period5.getMillis();
        org.joda.time.Period period9 = period5.minusYears((int) ' ');
        int[] intArray11 = iSOChronology0.get((org.joda.time.ReadablePeriod) period9, (long) (short) 0);
        org.joda.time.DurationField durationField12 = iSOChronology0.years();
        long long15 = durationField12.subtract((long) (short) -1, 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period6 = period4.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType7 = period6.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (short) 0);
        org.joda.time.Period period11 = period0.withField(durationFieldType9, (int) (short) 0);
        org.joda.time.Period period13 = period0.withWeeks((-1));
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.clockhourOfDay();
        org.joda.time.Period period20 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology18);
        org.joda.time.Period period21 = new org.joda.time.Period((long) (byte) 1, periodType15, (org.joda.time.Chronology) iSOChronology18);
        org.joda.time.Period period22 = period0.withPeriodType(periodType15);
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType25 = periodType23.getFieldType((int) (short) 0);
        boolean boolean26 = period0.isSupported(durationFieldType25);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadablePartial readablePartial9 = null;
        try {
            int[] intArray11 = zonedChronology5.get(readablePartial9, (long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 1, periodType1, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DurationField durationField8 = iSOChronology4.seconds();
        long long11 = durationField8.subtract((long) (short) 1, (int) (short) 100);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-99999L) + "'", long11 == (-99999L));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        boolean boolean0 = org.joda.time.tz.ZoneInfoCompiler.verbose();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5d + "'", double1 == 2440587.5d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.months();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.years();
        try {
            org.joda.time.Period period9 = new org.joda.time.Period(52, 10, (int) (byte) 1, (-1), (int) (short) 10, (int) '#', (int) (byte) -1, (int) (byte) 1, periodType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'months'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType8);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        try {
            long long31 = zonedChronology5.getDateTimeMillis(1, 52, (int) 'a', (int) (short) 100, (int) (byte) 1, (int) (short) -1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, readableInstant5);
        try {
            org.joda.time.Period period7 = new org.joda.time.Period((java.lang.Object) dateTimeField2, periodType3, chronology6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.field.RemainderDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (byte) 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 10);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(0L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType10 = periodType9.withSecondsRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.clockhourOfDay();
        boolean boolean14 = iSOChronology11.equals((java.lang.Object) (-1.0f));
        org.joda.time.DateTimeZone dateTimeZone15 = iSOChronology11.getZone();
        org.joda.time.Period period16 = new org.joda.time.Period((long) (byte) -1, periodType10, (org.joda.time.Chronology) iSOChronology11);
        try {
            org.joda.time.Period period17 = new org.joda.time.Period((int) (byte) 1, (int) (byte) 0, (int) 'a', 3, (int) (short) 100, (int) '4', (int) (byte) 100, 0, periodType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'seconds'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeZone15);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 100.0d, "ZonedChronology[ISOChronology[UTC], UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType1 = periodType0.withSecondsRemoved();
        try {
            org.joda.time.DurationFieldType durationFieldType3 = periodType0.getFieldType((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        int int5 = period3.getMillis();
        org.joda.time.Period period7 = period3.minusYears((int) ' ');
        org.joda.time.Period period9 = period7.minusHours((int) (byte) -1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.clockhourOfDay();
        org.joda.time.Period period15 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology13);
        org.joda.time.DurationField durationField16 = iSOChronology13.millis();
        try {
            org.joda.time.Period period17 = new org.joda.time.Period((java.lang.Object) period9, periodType10, (org.joda.time.Chronology) iSOChronology13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'hours'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        int int5 = period3.getMillis();
        org.joda.time.Period period7 = period3.minusYears((int) ' ');
        org.joda.time.Period period9 = period7.plusDays((int) 'a');
        org.joda.time.Period period11 = period9.multipliedBy(0);
        try {
            org.joda.time.Seconds seconds12 = period9.toStandardSeconds();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Seconds as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 1, periodType1, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.PeriodType periodType8 = periodType1.withYearsRemoved();
        boolean boolean10 = periodType8.equals((java.lang.Object) (-2));
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        boolean boolean3 = iSOChronology0.equals((java.lang.Object) (-1.0f));
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.weekyear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (byte) 100, "PT0.052S");
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) '4', chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        int int7 = period5.getMillis();
        org.joda.time.Period period9 = period5.minusYears((int) ' ');
        int[] intArray11 = iSOChronology0.get((org.joda.time.ReadablePeriod) period9, (long) (short) 0);
        org.joda.time.DurationField durationField12 = iSOChronology0.weekyears();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.years();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.Period period9 = new org.joda.time.Period((long) '4', chronology8);
        org.joda.time.Period period11 = period9.plusMillis(1);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType14 = periodType12.getFieldType((int) (short) 0);
        int int15 = period9.indexOf(durationFieldType14);
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(durationFieldType14, "UTC");
        int int18 = periodType5.indexOf(durationFieldType14);
        org.joda.time.PeriodType periodType19 = periodType5.withMonthsRemoved();
        org.joda.time.Period period20 = period3.normalizedStandard(periodType5);
        int int21 = period20.getMonths();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        try {
            long long28 = zonedChronology5.getDateTimeMillis((long) (byte) 1, 0, (int) (byte) -1, (int) '4', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 0, (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.DurationFieldType[] durationFieldTypeArray0 = null;
        try {
            org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.forFields(durationFieldTypeArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "years");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(1);
        org.joda.time.Period period2 = period1.normalizedStandard();
        int int3 = period1.getYears();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) -1, 52, (int) (short) 0, (-1));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) '4', chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        int int7 = period5.getMillis();
        org.joda.time.Period period9 = period5.minusYears((int) ' ');
        int[] intArray11 = iSOChronology0.get((org.joda.time.ReadablePeriod) period9, (long) (short) 0);
        org.joda.time.Period period12 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval14);
        org.joda.time.Period period16 = new org.joda.time.Period((long) '4', chronology15);
        org.joda.time.Period period18 = period16.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType19 = period18.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType((int) (short) 0);
        org.joda.time.Period period23 = period12.withField(durationFieldType21, (int) (short) 0);
        org.joda.time.Period period25 = period12.withWeeks((-1));
        org.joda.time.Period period26 = period9.minus((org.joda.time.ReadablePeriod) period12);
        try {
            org.joda.time.Duration duration27 = period9.toStandardDuration();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Duration as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period26);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Period period5 = period4.normalizedStandard();
        org.joda.time.Period period7 = period4.withYears(10);
        org.joda.time.Period period9 = period4.plusHours(0);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.years();
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period16 = period14.plusMillis(1);
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType19 = periodType17.getFieldType((int) (short) 0);
        int int20 = period14.indexOf(durationFieldType19);
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(durationFieldType19, "UTC");
        int int23 = periodType10.indexOf(durationFieldType19);
        org.joda.time.PeriodType periodType24 = periodType10.withMonthsRemoved();
        try {
            org.joda.time.Period period25 = period9.withPeriodType(periodType24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'millis'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(periodType24);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        int int5 = period3.getMillis();
        org.joda.time.Period period7 = period3.minusYears((int) ' ');
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType9 = periodType8.withWeeksRemoved();
        org.joda.time.PeriodType periodType10 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
        org.joda.time.PeriodType periodType11 = periodType8.withDaysRemoved();
        try {
            org.joda.time.Period period12 = period7.withPeriodType(periodType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField7 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField5, dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period6 = period4.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType7 = period6.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (short) 0);
        org.joda.time.Period period11 = period0.withField(durationFieldType9, (int) (short) 0);
        org.joda.time.Period period13 = period0.withWeeks((-1));
        org.joda.time.Period period15 = period13.withYears(52);
        org.joda.time.Days days16 = period13.toStandardDays();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(days16);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Coordinated Universal Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType2, (int) (byte) 100, 1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        java.lang.String str6 = period3.toString();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.clockhourOfDay();
        boolean boolean10 = iSOChronology7.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period11 = new org.joda.time.Period((java.lang.Object) period3, (org.joda.time.Chronology) iSOChronology7);
        int int12 = period11.getDays();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PT0.052S" + "'", str6.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDayTime();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.Period period1 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) '4', chronology4);
        org.joda.time.Period period7 = period5.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType8 = period7.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType10 = periodType8.getFieldType((int) (short) 0);
        org.joda.time.Period period12 = period1.withField(durationFieldType10, (int) (short) 0);
        org.joda.time.Period period14 = period1.withWeeks((-1));
        org.joda.time.ReadableInterval readableInterval16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval16);
        org.joda.time.Period period18 = new org.joda.time.Period((long) '4', chronology17);
        org.joda.time.Period period20 = period18.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType21 = period20.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType((int) (short) 0);
        org.joda.time.Period period25 = period14.withField(durationFieldType23, (int) (short) -1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(durationFieldType23, "Weeks");
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField28 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertNotNull(period25);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.4999999884d + "'", double1 == 2440587.4999999884d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) '4', chronology5);
        org.joda.time.Period period8 = period6.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType9 = period8.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType11 = periodType9.getFieldType((int) (short) 0);
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant1, readableDuration2, periodType9);
        org.joda.time.Period period13 = new org.joda.time.Period((long) 10, periodType9);
        org.joda.time.Minutes minutes14 = period13.toStandardMinutes();
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(durationFieldType11);
        org.junit.Assert.assertNotNull(minutes14);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis(3, (int) (byte) 10, 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.Period period1 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) '4', chronology4);
        org.joda.time.Period period7 = period5.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType8 = period7.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType10 = periodType8.getFieldType((int) (short) 0);
        org.joda.time.Period period12 = period1.withField(durationFieldType10, (int) (short) 0);
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField14 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType10, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        int int5 = period3.getMillis();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.years();
        org.joda.time.ReadableInterval readableInterval8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval8);
        org.joda.time.Period period10 = new org.joda.time.Period((long) '4', chronology9);
        org.joda.time.Period period12 = period10.plusMillis(1);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType15 = periodType13.getFieldType((int) (short) 0);
        int int16 = period10.indexOf(durationFieldType15);
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(durationFieldType15, "UTC");
        int int19 = periodType6.indexOf(durationFieldType15);
        boolean boolean20 = period3.isSupported(durationFieldType15);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("DayTime", 100, 8, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for DayTime must be in the range [8,10]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period6 = period4.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType7 = period6.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (short) 0);
        org.joda.time.Period period11 = period0.withField(durationFieldType9, (int) (short) 0);
        org.joda.time.Period period13 = period11.withYears((int) (byte) 0);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period6 = period4.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType7 = period6.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (short) 0);
        org.joda.time.Period period11 = period0.withField(durationFieldType9, (int) (short) 0);
        int int12 = period0.getDays();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) '4', chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        int int7 = period5.getMillis();
        org.joda.time.Period period9 = period5.minusYears((int) ' ');
        int[] intArray11 = iSOChronology0.get((org.joda.time.ReadablePeriod) period9, (long) (short) 0);
        org.joda.time.DurationField durationField12 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology0.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType15, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 10, (int) (short) -1, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType6 = period5.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField10 = new org.joda.time.field.PreciseDurationField(durationFieldType8, (long) (byte) 100);
        int int13 = preciseDurationField10.getDifference((long) (byte) -1, (long) 'a');
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType4 = periodType3.withSecondsRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.clockhourOfDay();
        boolean boolean8 = iSOChronology5.equals((java.lang.Object) (-1.0f));
        org.joda.time.DateTimeZone dateTimeZone9 = iSOChronology5.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) (byte) -1, periodType4, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology5.clockhourOfDay();
        org.joda.time.Period period12 = new org.joda.time.Period(0L, periodType1, (org.joda.time.Chronology) iSOChronology5);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 3, (java.lang.Number) 1560628908182L, (java.lang.Number) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("", 1, (int) 'a', (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for  must be in the range [97,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.ReadablePartial readablePartial23 = null;
        try {
            int[] intArray25 = zonedChronology5.get(readablePartial23, (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("years");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"years\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("PeriodType[Weeks]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"PeriodType[Weeks]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.millis();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 0, (int) (byte) 100, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType2 = periodType0.getFieldType((int) (short) 0);
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) '4', chronology5);
        org.joda.time.Period period8 = period6.plusMillis(1);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType11 = periodType9.getFieldType((int) (short) 0);
        int int12 = period6.indexOf(durationFieldType11);
        boolean boolean13 = periodType0.isSupported(durationFieldType11);
        org.joda.time.field.PreciseDurationField preciseDurationField15 = new org.joda.time.field.PreciseDurationField(durationFieldType11, 0L);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(durationFieldType2);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(durationFieldType11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = zonedChronology3.getZone();
        java.lang.String str5 = zonedChronology3.toString();
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology3);
        try {
            long long14 = zonedChronology3.getDateTimeMillis((int) (short) 100, (int) '#', 100, (int) (byte) 10, (int) (byte) -1, (int) (byte) 100, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(lenientChronology6);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (short) -1, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        int int10 = period3.getSeconds();
        org.joda.time.Period period12 = period3.minusDays(0);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.clockhourOfDay();
        org.joda.time.ReadableInterval readableInterval16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval16);
        org.joda.time.Period period18 = new org.joda.time.Period((long) '4', chronology17);
        org.joda.time.Period period19 = period18.toPeriod();
        int int20 = period18.getMillis();
        org.joda.time.Period period22 = period18.minusYears((int) ' ');
        int[] intArray24 = iSOChronology13.get((org.joda.time.ReadablePeriod) period22, (long) (short) 0);
        org.joda.time.Period period25 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval27 = null;
        org.joda.time.Chronology chronology28 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval27);
        org.joda.time.Period period29 = new org.joda.time.Period((long) '4', chronology28);
        org.joda.time.Period period31 = period29.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType32 = period31.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType34 = periodType32.getFieldType((int) (short) 0);
        org.joda.time.Period period36 = period25.withField(durationFieldType34, (int) (short) 0);
        org.joda.time.Period period38 = period25.withWeeks((-1));
        org.joda.time.Period period39 = period22.minus((org.joda.time.ReadablePeriod) period25);
        org.joda.time.ReadableInterval readableInterval41 = null;
        org.joda.time.Chronology chronology42 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval41);
        org.joda.time.Period period43 = new org.joda.time.Period((long) '4', chronology42);
        org.joda.time.Period period44 = period43.toPeriod();
        org.joda.time.ReadableInterval readableInterval46 = null;
        org.joda.time.Chronology chronology47 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval46);
        org.joda.time.Period period48 = new org.joda.time.Period((long) '4', chronology47);
        org.joda.time.Period period50 = period48.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType51 = period50.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType53 = periodType51.getFieldType((int) (short) 0);
        boolean boolean54 = period43.isSupported(durationFieldType53);
        int int55 = period39.get(durationFieldType53);
        boolean boolean56 = period12.isSupported(durationFieldType53);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 52 + "'", int20 == 52);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertNotNull(chronology47);
        org.junit.Assert.assertNotNull(period50);
        org.junit.Assert.assertNotNull(periodType51);
        org.junit.Assert.assertNotNull(durationFieldType53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-32) + "'", int55 == (-32));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "PeriodType[Weeks]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((-2), (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 'a');
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType9, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.junit.Assert.assertNotNull(period0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) '4', chronology4);
        org.joda.time.Period period7 = period5.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType8 = period7.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType10 = periodType8.getFieldType((int) (short) 0);
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType8);
        org.joda.time.PeriodType periodType12 = periodType8.withWeeksRemoved();
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(periodType12);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 1, periodType1, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DurationField durationField8 = iSOChronology4.seconds();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology4.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField11 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.years();
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period6 = period4.plusMillis(1);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (short) 0);
        int int10 = period4.indexOf(durationFieldType9);
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(durationFieldType9, "UTC");
        int int13 = periodType0.indexOf(durationFieldType9);
        java.lang.String str14 = periodType0.toString();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PeriodType[Years]" + "'", str14.equals("PeriodType[Years]"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 1, periodType1, (org.joda.time.Chronology) iSOChronology4);
        int int8 = period7.getSeconds();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType2 = periodType1.withWeeksRemoved();
        org.joda.time.PeriodType periodType3 = periodType2.withMillisRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.clockhourOfDay();
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology9);
        org.joda.time.Period period12 = new org.joda.time.Period((long) (byte) 1, periodType6, (org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DurationField durationField13 = iSOChronology9.seconds();
        org.joda.time.chrono.LenientChronology lenientChronology14 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology9);
        try {
            org.joda.time.Period period15 = new org.joda.time.Period((java.lang.Object) 3, periodType3, (org.joda.time.Chronology) lenientChronology14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(lenientChronology14);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866846400000L) + "'", long1 == (-210866846400000L));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.BufferedReader bufferedReader1 = null;
        try {
            zoneInfoCompiler0.parseDataFile(bufferedReader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((-3491999), (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-3491999) + "'", int2 == (-3491999));
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test118");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) (-1.0f));
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology0.getZone();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getShortName((long) 'a', locale6);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone4);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period6 = period4.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType7 = period6.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (short) 0);
        org.joda.time.Period period11 = period0.withField(durationFieldType9, (int) (short) 0);
        org.joda.time.Period period13 = period0.withWeeks((-1));
        org.joda.time.Period period15 = period13.withYears(52);
        org.joda.time.Period period16 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval18 = null;
        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval18);
        org.joda.time.Period period20 = new org.joda.time.Period((long) '4', chronology19);
        org.joda.time.Period period22 = period20.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType23 = period22.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType25 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period27 = period16.withField(durationFieldType25, (int) (short) 0);
        boolean boolean28 = period13.isSupported(durationFieldType25);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.DurationField durationField4 = iSOChronology0.hours();
        org.joda.time.DurationField durationField5 = iSOChronology0.weeks();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 2440587.5d, (java.lang.Number) (-1.0f), (java.lang.Number) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 100, periodType4, chronology6);
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) 100);
        org.joda.time.IllegalInstantException illegalInstantException10 = new org.joda.time.IllegalInstantException("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        boolean boolean11 = gregorianChronology0.equals((java.lang.Object) illegalInstantException10);
        try {
            long long19 = gregorianChronology0.getDateTimeMillis((int) (byte) 100, (int) (short) -1, (-2), (int) ' ', (int) (byte) 1, (-1), 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(durationFieldType8, "UTC");
        java.lang.String str12 = illegalFieldValueException11.getFieldName();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "days" + "'", str12.equals("days"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        int int5 = period3.getMillis();
        org.joda.time.Period period7 = period3.withWeeks((-1));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000000116d + "'", double1 == 2440587.5000000116d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) -1, 1, (int) ' ', (-3491999));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.Period period4 = new org.joda.time.Period(1, 1, (int) (short) -1, 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("DayTime");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"DayTime/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (short) -1, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-100) + "'", int2 == (-100));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.DurationFieldType durationFieldType1 = null;
        boolean boolean2 = periodType0.isSupported(durationFieldType1);
        java.lang.String str3 = periodType0.getName();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "YearDayTime" + "'", str3.equals("YearDayTime"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "DayTime");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(1);
        org.joda.time.Period period2 = period1.normalizedStandard();
        org.joda.time.Seconds seconds3 = period1.toStandardSeconds();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(seconds3);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        int int5 = period3.getMillis();
        org.joda.time.Period period7 = period3.minusYears((int) ' ');
        org.joda.time.Period period9 = period7.plusDays((int) 'a');
        org.joda.time.Period period10 = period7.negated();
        org.joda.time.Period period12 = period10.withSeconds(10);
        int[] intArray13 = period10.getValues();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("Weeks", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.days();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period6 = period4.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType7 = period6.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (short) 0);
        org.joda.time.Period period11 = period0.withField(durationFieldType9, (int) (short) 0);
        org.joda.time.Period period13 = period0.withWeeks((-1));
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.clockhourOfDay();
        org.joda.time.Period period20 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology18);
        org.joda.time.Period period21 = new org.joda.time.Period((long) (byte) 1, periodType15, (org.joda.time.Chronology) iSOChronology18);
        org.joda.time.Period period22 = period0.withPeriodType(periodType15);
        int int23 = period0.getHours();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "Weeks", "Weeks");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "Weeks", "org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getShortName(locale9, "ZonedChronology[ISOChronology[UTC], UTC]", "hi!");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (short) 100, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1000L + "'", long2 == 1000L);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        java.lang.String str9 = periodType1.getName();
        org.joda.time.PeriodType periodType10 = periodType1.withDaysRemoved();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "DayTime" + "'", str9.equals("DayTime"));
        org.junit.Assert.assertNotNull(periodType10);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str6 = dateTimeZone5.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone8 = zonedChronology7.getZone();
        java.lang.String str9 = zonedChronology7.toString();
        org.joda.time.Period period10 = new org.joda.time.Period((long) 3, periodType3, (org.joda.time.Chronology) zonedChronology7);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period16 = period14.plusMillis(1);
        java.lang.String str17 = period14.toString();
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.clockhourOfDay();
        boolean boolean21 = iSOChronology18.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period22 = new org.joda.time.Period((java.lang.Object) period14, (org.joda.time.Chronology) iSOChronology18);
        int[] intArray24 = zonedChronology7.get((org.joda.time.ReadablePeriod) period22, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology25 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.Period period26 = new org.joda.time.Period((long) 'a', (long) 0, (org.joda.time.Chronology) lenientChronology25);
        org.joda.time.PeriodType periodType27 = period26.getPeriodType();
        org.joda.time.DurationFieldType[] durationFieldTypeArray28 = period26.getFieldTypes();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str9.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PT0.052S" + "'", str17.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(lenientChronology25);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(durationFieldTypeArray28);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.Period period1 = new org.joda.time.Period((long) 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', chronology7);
        org.joda.time.Period period10 = period8.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType((int) (short) 0);
        boolean boolean14 = period3.isSupported(durationFieldType13);
        org.joda.time.field.PreciseDurationField preciseDurationField16 = new org.joda.time.field.PreciseDurationField(durationFieldType13, (long) '4');
        long long18 = preciseDurationField16.getMillis(156062890818200L);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 8115270322546400L + "'", long18 == 8115270322546400L);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) -1);
        java.io.DataOutput dataOutput4 = null;
        try {
            dateTimeZoneBuilder2.writeTo("Weeks", dataOutput4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Period period5 = period4.normalizedStandard();
        org.joda.time.Period period7 = period4.withYears(10);
        org.joda.time.Period period9 = period4.withWeeks((int) (byte) 0);
        org.joda.time.Period period11 = period9.minusDays((int) (short) 10);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        long long26 = zonedChronology5.add(2440588L, 0L, 0);
        org.joda.time.DateTimeField dateTimeField27 = zonedChronology5.yearOfCentury();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2440588L + "'", long26 == 2440588L);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period6 = period4.withYears((int) (short) 10);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period4.toDurationFrom(readableInstant7);
        org.joda.time.Period period10 = org.joda.time.Period.months(100);
        int int11 = period10.getMonths();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        org.joda.time.Period period18 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.Period period19 = new org.joda.time.Period((long) (byte) 1, periodType13, (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.PeriodType periodType20 = periodType13.withYearsRemoved();
        boolean boolean21 = period10.equals((java.lang.Object) periodType13);
        org.joda.time.Period period22 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration8, periodType13);
        org.joda.time.Period period27 = new org.joda.time.Period((int) (byte) 1, (int) (short) -1, 0, (int) (short) -1);
        org.joda.time.Period period28 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval30 = null;
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) '4', chronology31);
        org.joda.time.Period period34 = period32.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType35 = period34.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType37 = periodType35.getFieldType((int) (short) 0);
        org.joda.time.Period period39 = period28.withField(durationFieldType37, (int) (short) 0);
        org.joda.time.Period period41 = period28.withWeeks((-1));
        org.joda.time.ReadableInterval readableInterval43 = null;
        org.joda.time.Chronology chronology44 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval43);
        org.joda.time.Period period45 = new org.joda.time.Period((long) '4', chronology44);
        org.joda.time.Period period47 = period45.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType48 = period47.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType50 = periodType48.getFieldType((int) (short) 0);
        org.joda.time.Period period52 = period41.withField(durationFieldType50, (int) (short) -1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException54 = new org.joda.time.IllegalFieldValueException(durationFieldType50, "Weeks");
        boolean boolean55 = period27.isSupported(durationFieldType50);
        boolean boolean56 = periodType13.isSupported(durationFieldType50);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(durationFieldType37);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(chronology44);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(periodType48);
        org.junit.Assert.assertNotNull(durationFieldType50);
        org.junit.Assert.assertNotNull(period52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        java.lang.String str4 = dateTimeZone1.getID();
        java.lang.String str5 = dateTimeZone1.toString();
        long long9 = dateTimeZone1.convertLocalToUTC((long) (short) -1, false, (long) '#');
        long long11 = dateTimeZone1.convertUTCToLocal((long) 100);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("DayTime", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"DayTime/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.time();
        org.joda.time.Period period3 = new org.joda.time.Period((long) 10, 0L, periodType2);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 1, (java.lang.Number) 100, (java.lang.Number) 10.0d);
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        java.lang.String str6 = illegalFieldValueException4.getFieldName();
        org.joda.time.IllegalInstantException illegalInstantException9 = new org.joda.time.IllegalInstantException(2440588L, "org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalInstantException9);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 1, (java.lang.Number) 100, (java.lang.Number) 10.0d);
        java.lang.String str16 = illegalFieldValueException15.getIllegalStringValue();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException15);
        java.lang.String str18 = illegalFieldValueException15.getFieldName();
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.time();
        java.lang.String str1 = periodType0.getName();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Time" + "'", str1.equals("Time"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 100, periodType4, chronology6);
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) 100);
        org.joda.time.IllegalInstantException illegalInstantException10 = new org.joda.time.IllegalInstantException("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        boolean boolean11 = gregorianChronology0.equals((java.lang.Object) illegalInstantException10);
        org.joda.time.Chronology chronology12 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str14 = dateTimeZone13.getID();
        java.lang.String str15 = dateTimeZone13.getID();
        org.joda.time.Chronology chronology16 = gregorianChronology0.withZone(dateTimeZone13);
        try {
            long long21 = gregorianChronology0.getDateTimeMillis((int) (short) 1, 0, (-3491999), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.clockhourOfDay();
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period13 = period12.toPeriod();
        int int14 = period12.getMillis();
        org.joda.time.Period period16 = period12.minusYears((int) ' ');
        int[] intArray18 = iSOChronology7.get((org.joda.time.ReadablePeriod) period16, (long) (short) 0);
        try {
            iSOChronology2.validate(readablePartial6, intArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = zonedChronology3.getZone();
        java.lang.String str5 = zonedChronology3.toString();
        try {
            long long13 = zonedChronology3.getDateTimeMillis((int) (short) 1, (int) (short) 1, 0, (int) (byte) 100, (int) (short) 0, (-1), (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (short) 10, (-3491999));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-34919990L) + "'", long2 == (-34919990L));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Period period5 = period4.normalizedStandard();
        org.joda.time.Period period7 = period4.withYears(10);
        org.joda.time.Period period9 = period4.withWeeks((int) (byte) 0);
        org.joda.time.Period period11 = period9.withSeconds((int) (short) -1);
        org.joda.time.Period period13 = period11.withWeeks(100);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period6 = period4.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType7 = period6.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (short) 0);
        org.joda.time.Period period11 = period0.withField(durationFieldType9, (int) (short) 0);
        org.joda.time.Period period13 = period0.withWeeks((-1));
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period0.toString(periodFormatter14);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0S" + "'", str15.equals("PT0S"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (byte) 1, 156062890818200L);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.junit.Assert.assertNotNull(strMap0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType6, 100, (int) (short) 10, (-3491999));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) '4');
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.fieldDifference(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Period period5 = period4.normalizedStandard();
        org.joda.time.Period period7 = period4.withYears(10);
        boolean boolean9 = period4.equals((java.lang.Object) 2440587.5d);
        org.joda.time.Period period11 = period4.minusYears((-2));
        org.joda.time.DurationFieldType[] durationFieldTypeArray12 = period11.getFieldTypes();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(durationFieldTypeArray12);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Period period5 = period4.normalizedStandard();
        org.joda.time.Period period6 = period4.normalizedStandard();
        org.joda.time.Period period8 = period4.minusSeconds(4);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period6 = period4.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType7 = period6.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (short) 0);
        org.joda.time.Period period11 = period0.withField(durationFieldType9, (int) (short) 0);
        org.joda.time.Period period13 = period11.plusMillis((int) (short) -1);
        org.joda.time.Period period14 = period13.normalizedStandard();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) (byte) -1, ' ', (int) (byte) 100, (int) ' ', 0, false, (-32));
        java.io.DataOutput dataOutput10 = null;
        try {
            dateTimeZoneBuilder0.writeTo("hi!", dataOutput10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File file2 = null;
        java.io.File[] fileArray3 = new java.io.File[] { file2 };
        try {
            java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = zoneInfoCompiler0.compile(file1, fileArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fileArray3);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis(100, 8, (int) (short) 100, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        int int5 = period3.getMillis();
        org.joda.time.Period period7 = period3.minusYears((int) ' ');
        org.joda.time.Period period9 = period7.plusDays((int) 'a');
        org.joda.time.Period period11 = period7.withMillis(100);
        int int12 = period11.getMillis();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(2, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 70 + "'", int2 == 70);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) (byte) -1, ' ', (int) (byte) 100, (int) ' ', 0, false, (-32));
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder0.addCutover((-3491999), '4', (int) (short) 100, (int) (byte) 0, (-2), false, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = zonedChronology3.getZone();
        java.lang.String str5 = zonedChronology3.toString();
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology3);
        try {
            long long14 = zonedChronology3.getDateTimeMillis((int) '4', (int) (short) -1, (int) (byte) 0, 2, (-1), 4, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(lenientChronology6);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType2, (int) (short) -1, (int) (short) -1, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("ZonedChronology[ISOChronology[UTC], UTC]");
        org.joda.time.IllegalInstantException illegalInstantException3 = new org.joda.time.IllegalInstantException("ZonedChronology[ISOChronology[UTC], UTC]");
        org.joda.time.IllegalFieldValueException illegalFieldValueException8 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 1, (java.lang.Number) 100, (java.lang.Number) 10.0d);
        org.joda.time.DurationFieldType durationFieldType9 = illegalFieldValueException8.getDurationFieldType();
        java.lang.String str10 = illegalFieldValueException8.getFieldName();
        org.joda.time.IllegalInstantException illegalInstantException13 = new org.joda.time.IllegalInstantException(2440588L, "org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        illegalFieldValueException8.addSuppressed((java.lang.Throwable) illegalInstantException13);
        illegalInstantException3.addSuppressed((java.lang.Throwable) illegalInstantException13);
        illegalInstantException1.addSuppressed((java.lang.Throwable) illegalInstantException13);
        boolean boolean17 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalInstantException13);
        org.junit.Assert.assertNull(durationFieldType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.centuries();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        int int5 = period3.getMillis();
        org.joda.time.Period period7 = period3.minusYears((int) ' ');
        org.joda.time.Period period9 = period7.minusHours((int) (byte) -1);
        try {
            org.joda.time.Minutes minutes10 = period7.toStandardMinutes();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Minutes as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period6 = period4.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType7 = period6.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (short) 0);
        org.joda.time.Period period11 = period0.withField(durationFieldType9, (int) (short) 0);
        org.joda.time.Period period13 = period0.withWeeks((-1));
        org.joda.time.Period period15 = period13.withYears(52);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Duration duration17 = period13.toDurationFrom(readableInstant16);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(duration17);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', chronology7);
        org.joda.time.Period period10 = period8.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType((int) (short) 0);
        boolean boolean14 = period3.isSupported(durationFieldType13);
        org.joda.time.field.PreciseDurationField preciseDurationField16 = new org.joda.time.field.PreciseDurationField(durationFieldType13, (long) '4');
        java.lang.String str17 = preciseDurationField16.toString();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "DurationField[years]" + "'", str17.equals("DurationField[years]"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', chronology7);
        org.joda.time.Period period10 = period8.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType((int) (short) 0);
        boolean boolean14 = period3.isSupported(durationFieldType13);
        org.joda.time.field.PreciseDurationField preciseDurationField16 = new org.joda.time.field.PreciseDurationField(durationFieldType13, (long) '4');
        org.joda.time.Period period17 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval19 = null;
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval19);
        org.joda.time.Period period21 = new org.joda.time.Period((long) '4', chronology20);
        org.joda.time.Period period23 = period21.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType24 = period23.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType26 = periodType24.getFieldType((int) (short) 0);
        org.joda.time.Period period28 = period17.withField(durationFieldType26, (int) (short) 0);
        org.joda.time.Period period30 = period17.withWeeks((-1));
        org.joda.time.ReadableInterval readableInterval32 = null;
        org.joda.time.Chronology chronology33 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) '4', chronology33);
        org.joda.time.Period period36 = period34.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType37 = period36.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType39 = periodType37.getFieldType((int) (short) 0);
        org.joda.time.Period period41 = period30.withField(durationFieldType39, (int) (short) -1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(durationFieldType39, "Weeks");
        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) preciseDurationField16, durationFieldType39);
        long long47 = decoratedDurationField44.getDifferenceAsLong(97L, (long) 0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(durationFieldType39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1L + "'", long47 == 1L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType6 = period5.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField10 = new org.joda.time.field.PreciseDurationField(durationFieldType8, (long) (byte) 100);
        long long13 = preciseDurationField10.getMillis(0L, 10L);
        long long16 = preciseDurationField10.getMillis((long) 100, (long) (short) 0);
        long long19 = preciseDurationField10.getValueAsLong(97L, (long) 0);
        java.lang.String str20 = preciseDurationField10.getName();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10000L + "'", long16 == 10000L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "years" + "'", str20.equals("years"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Period period5 = period4.normalizedStandard();
        org.joda.time.Period period7 = period4.withYears(10);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Duration duration9 = period7.toDurationTo(readableInstant8);
        try {
            org.joda.time.Duration duration10 = period7.toStandardDuration();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Duration as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration9);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        java.lang.String str6 = period3.toString();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.clockhourOfDay();
        boolean boolean10 = iSOChronology7.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period11 = new org.joda.time.Period((java.lang.Object) period3, (org.joda.time.Chronology) iSOChronology7);
        java.lang.Class<?> wildcardClass12 = period11.getClass();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PT0.052S" + "'", str6.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-100) + "'", int1 == (-100));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.years();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.Period period9 = new org.joda.time.Period((long) '4', chronology8);
        org.joda.time.Period period11 = period9.plusMillis(1);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType14 = periodType12.getFieldType((int) (short) 0);
        int int15 = period9.indexOf(durationFieldType14);
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(durationFieldType14, "UTC");
        int int18 = periodType5.indexOf(durationFieldType14);
        org.joda.time.PeriodType periodType19 = periodType5.withMonthsRemoved();
        org.joda.time.Period period20 = period3.normalizedStandard(periodType5);
        org.joda.time.Period period22 = period3.plusMonths((int) 'a');
        int int23 = period3.getWeeks();
        org.joda.time.Period period25 = period3.withMinutes(0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(period25);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) -1);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder2.addCutover(0, '#', (int) (byte) 100, (-100), 4, false, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((-2), 70);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68 + "'", int2 == 68);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) '4', chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        int int7 = period5.getMillis();
        org.joda.time.Period period9 = period5.minusYears((int) ' ');
        int[] intArray11 = iSOChronology0.get((org.joda.time.ReadablePeriod) period9, (long) (short) 0);
        org.joda.time.Period period12 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval14);
        org.joda.time.Period period16 = new org.joda.time.Period((long) '4', chronology15);
        org.joda.time.Period period18 = period16.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType19 = period18.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType((int) (short) 0);
        org.joda.time.Period period23 = period12.withField(durationFieldType21, (int) (short) 0);
        org.joda.time.Period period25 = period12.withWeeks((-1));
        org.joda.time.Period period26 = period9.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.Period period28 = period9.minusMillis((int) (byte) 1);
        org.joda.time.Period period29 = period28.normalizedStandard();
        org.joda.time.Period period31 = period29.plusHours((int) 'a');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period31);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType2 = periodType1.withSecondsRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.clockhourOfDay();
        boolean boolean6 = iSOChronology3.equals((java.lang.Object) (-1.0f));
        org.joda.time.DateTimeZone dateTimeZone7 = iSOChronology3.getZone();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (byte) -1, periodType2, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, dateTimeFieldType10, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = org.joda.time.DateTimeUtils.getPeriodType(periodType4);
        try {
            org.joda.time.Period period6 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (short) -1);
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) '4', chronology4);
        org.joda.time.Period period7 = period5.plusMillis(1);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType10 = periodType8.getFieldType((int) (short) 0);
        int int11 = period5.indexOf(durationFieldType10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(durationFieldType10, "UTC");
        org.joda.time.Period period15 = period1.withFieldAdded(durationFieldType10, (int) '4');
        org.joda.time.Period period17 = period15.plusWeeks(0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.clockhourOfDay();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology6);
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 1, periodType3, (org.joda.time.Chronology) iSOChronology6);
        org.joda.time.PeriodType periodType10 = periodType3.withYearsRemoved();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (-210866846400000L), periodType10);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(periodType10);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File[] fileArray2 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = zoneInfoCompiler0.compile(file1, fileArray2);
        java.io.File file4 = null;
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler5 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file6 = null;
        java.io.File[] fileArray7 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = zoneInfoCompiler5.compile(file6, fileArray7);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap9 = zoneInfoCompiler0.compile(file4, fileArray7);
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap9);
        org.junit.Assert.assertNotNull(fileArray2);
        org.junit.Assert.assertNotNull(strMap3);
        org.junit.Assert.assertNotNull(fileArray7);
        org.junit.Assert.assertNotNull(strMap8);
        org.junit.Assert.assertNotNull(strMap9);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]", (java.lang.Number) (short) 0, (java.lang.Number) (short) 100, (java.lang.Number) 10.0d);
        illegalFieldValueException4.prependMessage("Coordinated Universal Time");
        java.lang.String str7 = illegalFieldValueException4.toString();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: Coordinated Universal Time: Value 0 for org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0] must be in the range [100,10.0]" + "'", str7.equals("org.joda.time.IllegalFieldValueException: Coordinated Universal Time: Value 0 for org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0] must be in the range [100,10.0]"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 2, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("Time");
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(8);
        java.lang.String str3 = dateTimeZone1.getShortName(1560628908182L);
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTimeZone1.getShortName(1560628908182L, locale5);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+08:00" + "'", str3.equals("+08:00"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+08:00" + "'", str6.equals("+08:00"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 100, periodType4, chronology6);
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) 100);
        org.joda.time.IllegalInstantException illegalInstantException10 = new org.joda.time.IllegalInstantException("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        boolean boolean11 = gregorianChronology0.equals((java.lang.Object) illegalInstantException10);
        org.joda.time.Chronology chronology12 = gregorianChronology0.withUTC();
        try {
            long long20 = gregorianChronology0.getDateTimeMillis(3, (int) (short) -1, 0, (int) '#', 4, 1, 8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        long long26 = zonedChronology5.add(2440588L, 0L, 0);
        org.joda.time.DateTimeField dateTimeField27 = zonedChronology5.halfdayOfDay();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2440588L + "'", long26 == 2440588L);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.clockhourOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.Period period6 = period5.normalizedStandard();
        org.joda.time.Period period8 = period5.withYears(10);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Duration duration10 = period8.toDurationTo(readableInstant9);
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration10);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(duration10);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 1, periodType1, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DurationField durationField8 = iSOChronology4.seconds();
        org.joda.time.chrono.LenientChronology lenientChronology9 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology4);
        long long13 = lenientChronology9.add(0L, 2440578L, 100);
        org.joda.time.DateTimeField dateTimeField14 = lenientChronology9.dayOfWeek();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(lenientChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 244057800L + "'", long13 == 244057800L);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 100, periodType4, chronology6);
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) 100);
        org.joda.time.IllegalInstantException illegalInstantException10 = new org.joda.time.IllegalInstantException("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        boolean boolean11 = gregorianChronology0.equals((java.lang.Object) illegalInstantException10);
        org.joda.time.Chronology chronology12 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str14 = dateTimeZone13.getID();
        java.lang.String str15 = dateTimeZone13.getID();
        org.joda.time.Chronology chronology16 = gregorianChronology0.withZone(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology0.monthOfYear();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField17, 1, (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for monthOfYear must be in the range [35,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("days", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"days/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.withYears((int) (short) 10);
        try {
            int int7 = period3.getValue((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = zonedChronology3.getZone();
        org.joda.time.DateTimeField dateTimeField5 = zonedChronology3.clockhourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Period period5 = period4.normalizedStandard();
        org.joda.time.Period period7 = period4.withYears(10);
        int int8 = period7.getWeeks();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        int int5 = period3.getMillis();
        org.joda.time.Period period7 = period3.minusYears((int) ' ');
        org.joda.time.Period period9 = period7.minusHours((int) (byte) -1);
        int int10 = period7.size();
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period16 = period14.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType17 = period16.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType19 = periodType17.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField21 = new org.joda.time.field.PreciseDurationField(durationFieldType19, (long) (byte) 100);
        java.lang.String str22 = preciseDurationField21.getName();
        long long23 = preciseDurationField21.getUnitMillis();
        int int26 = preciseDurationField21.getDifference((-349199900L), (long) 'a');
        org.joda.time.DurationFieldType durationFieldType27 = preciseDurationField21.getType();
        int int28 = period7.get(durationFieldType27);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 8 + "'", int10 == 8);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "years" + "'", str22.equals("years"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-3491999) + "'", int26 == (-3491999));
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-32) + "'", int28 == (-32));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.PeriodType periodType5 = periodType2.withDaysRemoved();
        try {
            org.joda.time.Period period6 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test215");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str1 = dateTimeZone0.getID();
//        java.lang.String str2 = dateTimeZone0.getID();
//        java.util.TimeZone timeZone3 = dateTimeZone0.toTimeZone();
//        java.lang.String str5 = dateTimeZone0.getName((long) 3);
//        java.lang.String str6 = dateTimeZone0.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTC" + "'", str1.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str1 = dateTimeZone0.getID();
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone0.getName((long) 8, locale4);
//        org.joda.time.LocalDateTime localDateTime6 = null;
//        boolean boolean7 = dateTimeZone0.isLocalDateTimeGap(localDateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTC" + "'", str1.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 1, periodType1, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.PeriodType periodType8 = periodType1.withYearsRemoved();
        java.lang.String str9 = periodType1.toString();
        org.joda.time.PeriodType periodType10 = periodType1.withYearsRemoved();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PeriodType[Weeks]" + "'", str9.equals("PeriodType[Weeks]"));
        org.junit.Assert.assertNotNull(periodType10);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 70, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 70L + "'", long2 == 70L);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) -1);
        java.io.OutputStream outputStream4 = null;
        try {
            dateTimeZoneBuilder2.writeTo("ZonedChronology[ISOChronology[UTC], UTC]", outputStream4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.Period period8 = new org.joda.time.Period(1, 10, (int) (short) -1, (-2), (int) (byte) 1, (int) (byte) 1, (int) ' ', (int) (byte) 10);
        org.joda.time.Period period10 = period8.minusSeconds((int) (short) 10);
        org.joda.time.Period period12 = period10.minusMinutes((int) (short) 10);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.yearDay();
        try {
            org.joda.time.Period period14 = new org.joda.time.Period((java.lang.Object) period10, periodType13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'months'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType13);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) 10, (long) 0, periodType4);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField4 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType2, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType6 = period5.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField10 = new org.joda.time.field.PreciseDurationField(durationFieldType8, (long) (byte) 100);
        long long13 = preciseDurationField10.getDifferenceAsLong((-2L), (long) 1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210865896000000L) + "'", long1 == (-210865896000000L));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.Period period1 = org.joda.time.Period.years(52);
        org.junit.Assert.assertNotNull(period1);
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test226");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        long long3 = dateTimeZone0.adjustOffset((long) 'a', false);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone0.getName((long) 3, locale5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone0.getName(2440578L, locale8);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordinated Universal Time" + "'", str9.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(2L, (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2L) + "'", long2 == (-2L));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(8);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(1);
        org.joda.time.Period period3 = period1.plusHours((-100));
        int int4 = period1.getHours();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.Period period8 = new org.joda.time.Period(1, 10, (int) (short) -1, (-2), (int) (byte) 1, (int) (byte) 1, (int) ' ', (int) (byte) 10);
        org.joda.time.Period period10 = period8.minusSeconds((int) (short) 10);
        org.joda.time.Period period12 = period8.minusWeeks(3);
        try {
            org.joda.time.Hours hours13 = period12.toStandardHours();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Hours as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) '4', chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        int int7 = period5.getMillis();
        org.joda.time.Period period9 = period5.minusYears((int) ' ');
        int[] intArray11 = iSOChronology0.get((org.joda.time.ReadablePeriod) period9, (long) (short) 0);
        org.joda.time.DurationField durationField12 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology0.hourOfHalfday();
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.clockhourOfDay();
        org.joda.time.Period period19 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DurationField durationField20 = iSOChronology17.millis();
        org.joda.time.DurationField durationField21 = iSOChronology17.weeks();
        try {
            org.joda.time.Period period22 = new org.joda.time.Period((java.lang.Object) iSOChronology0, (org.joda.time.Chronology) iSOChronology17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(durationField21);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 0, 0, (-100));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("+08:00", (java.lang.Number) 244057800L, number2, (java.lang.Number) (short) 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withWeeksRemoved();
        org.joda.time.PeriodType periodType2 = periodType1.withMillisRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        java.lang.String str4 = periodType3.toString();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PeriodType[DayTimeNoMillis]" + "'", str4.equals("PeriodType[DayTimeNoMillis]"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period6 = period4.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType7 = period6.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (short) 0);
        org.joda.time.Period period11 = period0.withField(durationFieldType9, (int) (short) 0);
        org.joda.time.Period period13 = period0.withWeeks((-1));
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.clockhourOfDay();
        org.joda.time.Period period20 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology18);
        org.joda.time.Period period21 = new org.joda.time.Period((long) (byte) 1, periodType15, (org.joda.time.Chronology) iSOChronology18);
        org.joda.time.Period period22 = period0.withPeriodType(periodType15);
        org.joda.time.PeriodType periodType23 = periodType15.withDaysRemoved();
        org.joda.time.PeriodType periodType24 = org.joda.time.PeriodType.years();
        boolean boolean25 = periodType23.equals((java.lang.Object) periodType24);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 8, (int) ' ', 52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.Period period8 = new org.joda.time.Period(1, 10, (int) (short) -1, (-2), (int) (byte) 1, (int) (byte) 1, (int) ' ', (int) (byte) 10);
        org.joda.time.Period period10 = period8.minusSeconds((int) (short) 10);
        org.joda.time.PeriodType periodType11 = period8.getPeriodType();
        org.joda.time.Period period13 = period8.minusYears(52);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 100.0d, (java.lang.Number) (-99999L), number3);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-99999L) + "'", number5.equals((-99999L)));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType9 = periodType8.withWeeksRemoved();
        org.joda.time.Period period10 = new org.joda.time.Period(0, (int) (byte) 0, 0, 68, 2, 52, (int) (short) 10, 0, periodType8);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period15 = period14.toPeriod();
        int int16 = period14.getMillis();
        org.joda.time.Period period18 = period14.minusYears((int) ' ');
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Duration duration20 = period14.toDurationFrom(readableInstant19);
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration20, readableInstant21);
        org.joda.time.Period period23 = period10.plus((org.joda.time.ReadablePeriod) period22);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 52 + "'", int16 == 52);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(duration20);
        org.junit.Assert.assertNotNull(period23);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType2 = periodType1.withSecondsRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.clockhourOfDay();
        boolean boolean6 = iSOChronology3.equals((java.lang.Object) (-1.0f));
        org.joda.time.DateTimeZone dateTimeZone7 = iSOChronology3.getZone();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (byte) -1, periodType2, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.yearOfEra();
        long long14 = iSOChronology3.add((long) 70, 1560628909182L, (int) (byte) 0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 70L + "'", long14 == 70L);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(durationFieldType8, "UTC");
        java.lang.String str12 = illegalFieldValueException11.getIllegalStringValue();
        java.lang.Throwable[] throwableArray13 = illegalFieldValueException11.getSuppressed();
        java.lang.Number number14 = illegalFieldValueException11.getUpperBound();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UTC" + "'", str12.equals("UTC"));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNull(number14);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType2 = periodType1.withSecondsRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str7 = dateTimeZone6.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology5, dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone9 = zonedChronology8.getZone();
        java.lang.String str10 = zonedChronology8.toString();
        org.joda.time.Period period11 = new org.joda.time.Period((long) 3, periodType4, (org.joda.time.Chronology) zonedChronology8);
        org.joda.time.ReadableInterval readableInterval13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) '4', chronology14);
        org.joda.time.Period period17 = period15.plusMillis(1);
        java.lang.String str18 = period15.toString();
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.clockhourOfDay();
        boolean boolean22 = iSOChronology19.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period23 = new org.joda.time.Period((java.lang.Object) period15, (org.joda.time.Chronology) iSOChronology19);
        int[] intArray25 = zonedChronology8.get((org.joda.time.ReadablePeriod) period23, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology26 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology8);
        long long31 = zonedChronology8.getDateTimeMillis(100, (int) (short) 10, 10, (int) 'a');
        org.joda.time.Period period32 = new org.joda.time.Period(0L, periodType2, (org.joda.time.Chronology) zonedChronology8);
        org.joda.time.Minutes minutes33 = period32.toStandardMinutes();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str10.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PT0.052S" + "'", str18.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(lenientChronology26);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-58987094399903L) + "'", long31 == (-58987094399903L));
        org.junit.Assert.assertNotNull(minutes33);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', chronology7);
        org.joda.time.Period period10 = period8.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType((int) (short) 0);
        boolean boolean14 = period3.isSupported(durationFieldType13);
        org.joda.time.field.PreciseDurationField preciseDurationField16 = new org.joda.time.field.PreciseDurationField(durationFieldType13, (long) '4');
        org.joda.time.Period period17 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval19 = null;
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval19);
        org.joda.time.Period period21 = new org.joda.time.Period((long) '4', chronology20);
        org.joda.time.Period period23 = period21.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType24 = period23.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType26 = periodType24.getFieldType((int) (short) 0);
        org.joda.time.Period period28 = period17.withField(durationFieldType26, (int) (short) 0);
        org.joda.time.Period period30 = period17.withWeeks((-1));
        org.joda.time.ReadableInterval readableInterval32 = null;
        org.joda.time.Chronology chronology33 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) '4', chronology33);
        org.joda.time.Period period36 = period34.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType37 = period36.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType39 = periodType37.getFieldType((int) (short) 0);
        org.joda.time.Period period41 = period30.withField(durationFieldType39, (int) (short) -1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(durationFieldType39, "Weeks");
        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) preciseDurationField16, durationFieldType39);
        long long47 = preciseDurationField16.subtract(0L, (int) 'a');
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(durationFieldType39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-5044L) + "'", long47 == (-5044L));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str6 = dateTimeZone5.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone8 = zonedChronology7.getZone();
        java.lang.String str9 = zonedChronology7.toString();
        org.joda.time.Period period10 = new org.joda.time.Period((long) 3, periodType3, (org.joda.time.Chronology) zonedChronology7);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period16 = period14.plusMillis(1);
        java.lang.String str17 = period14.toString();
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.clockhourOfDay();
        boolean boolean21 = iSOChronology18.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period22 = new org.joda.time.Period((java.lang.Object) period14, (org.joda.time.Chronology) iSOChronology18);
        int[] intArray24 = zonedChronology7.get((org.joda.time.ReadablePeriod) period22, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology25 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.Period period26 = new org.joda.time.Period((long) 'a', (long) 0, (org.joda.time.Chronology) lenientChronology25);
        org.joda.time.PeriodType periodType27 = period26.getPeriodType();
        org.joda.time.PeriodType periodType28 = periodType27.withSecondsRemoved();
        org.joda.time.PeriodType periodType29 = periodType27.withYearsRemoved();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str9.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PT0.052S" + "'", str17.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(lenientChronology25);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(periodType29);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.years();
        org.joda.time.DurationFieldType durationFieldType1 = null;
        int int2 = periodType0.indexOf(durationFieldType1);
        org.joda.time.PeriodType periodType3 = periodType0.withDaysRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType2, 100, 1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType2 = periodType1.withSecondsRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str7 = dateTimeZone6.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology5, dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone9 = zonedChronology8.getZone();
        java.lang.String str10 = zonedChronology8.toString();
        org.joda.time.Period period11 = new org.joda.time.Period((long) 3, periodType4, (org.joda.time.Chronology) zonedChronology8);
        org.joda.time.ReadableInterval readableInterval13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) '4', chronology14);
        org.joda.time.Period period17 = period15.plusMillis(1);
        java.lang.String str18 = period15.toString();
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.clockhourOfDay();
        boolean boolean22 = iSOChronology19.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period23 = new org.joda.time.Period((java.lang.Object) period15, (org.joda.time.Chronology) iSOChronology19);
        int[] intArray25 = zonedChronology8.get((org.joda.time.ReadablePeriod) period23, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology26 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology8);
        long long31 = zonedChronology8.getDateTimeMillis(100, (int) (short) 10, 10, (int) 'a');
        org.joda.time.Period period32 = new org.joda.time.Period(0L, periodType2, (org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTimeField dateTimeField33 = zonedChronology8.weekOfWeekyear();
        long long39 = zonedChronology8.getDateTimeMillis(52L, 3, 0, 0, 2);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str10.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PT0.052S" + "'", str18.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(lenientChronology26);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-58987094399903L) + "'", long31 == (-58987094399903L));
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 10800002L + "'", long39 == 10800002L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Period period5 = period4.normalizedStandard();
        org.joda.time.Period period7 = period4.withYears(10);
        boolean boolean9 = period4.equals((java.lang.Object) 2440587.5d);
        org.joda.time.Period period11 = period4.minusYears((-2));
        int int12 = period11.getYears();
        org.joda.time.Period period14 = period11.withWeeks((int) (byte) -1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.DurationField durationField4 = iSOChronology0.weeks();
        org.joda.time.DurationField durationField5 = iSOChronology0.months();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "PeriodType[Years]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 1, (java.lang.Number) 100, (java.lang.Number) 10.0d);
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        java.lang.String str6 = illegalFieldValueException4.toString();
        java.lang.Class<?> wildcardClass7 = illegalFieldValueException4.getClass();
        java.lang.Number number8 = illegalFieldValueException4.getIllegalNumberValue();
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]" + "'", str6.equals("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]"));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1 + "'", number8.equals(1));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 1, periodType1, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DurationField durationField8 = iSOChronology4.seconds();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology4.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = iSOChronology4.getZone();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone1.isLocalDateTimeGap(localDateTime4);
        long long7 = dateTimeZone1.convertUTCToLocal(8115270322546400L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 8115270322546400L + "'", long7 == 8115270322546400L);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 1, (int) (short) -1, 0, (int) (short) -1);
        org.joda.time.Period period5 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.Period period9 = new org.joda.time.Period((long) '4', chronology8);
        org.joda.time.Period period11 = period9.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType12 = period11.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType14 = periodType12.getFieldType((int) (short) 0);
        org.joda.time.Period period16 = period5.withField(durationFieldType14, (int) (short) 0);
        org.joda.time.Period period18 = period5.withWeeks((-1));
        org.joda.time.ReadableInterval readableInterval20 = null;
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval20);
        org.joda.time.Period period22 = new org.joda.time.Period((long) '4', chronology21);
        org.joda.time.Period period24 = period22.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType25 = period24.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType27 = periodType25.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withField(durationFieldType27, (int) (short) -1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(durationFieldType27, "Weeks");
        boolean boolean32 = period4.isSupported(durationFieldType27);
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(durationFieldType27, (java.lang.Number) 10L, (java.lang.Number) 3, (java.lang.Number) (-100));
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "years");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        java.security.Permission permission3 = null;
        boolean boolean4 = jodaTimePermission1.implies(permission3);
        java.lang.Object obj5 = null;
        jodaTimePermission1.checkGuard(obj5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        java.lang.String str6 = period3.toString();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.clockhourOfDay();
        boolean boolean10 = iSOChronology7.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period11 = new org.joda.time.Period((java.lang.Object) period3, (org.joda.time.Chronology) iSOChronology7);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology7.halfdayOfDay();
        try {
            long long20 = iSOChronology7.getDateTimeMillis(8, 0, (int) (byte) 10, 3, (int) (short) -1, (int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PT0.052S" + "'", str6.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test259");
//        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.dayTime();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str6 = dateTimeZone5.getID();
//        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone8 = zonedChronology7.getZone();
//        java.lang.String str9 = zonedChronology7.toString();
//        org.joda.time.Period period10 = new org.joda.time.Period((long) 3, periodType3, (org.joda.time.Chronology) zonedChronology7);
//        org.joda.time.ReadableInterval readableInterval12 = null;
//        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
//        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
//        org.joda.time.Period period16 = period14.plusMillis(1);
//        java.lang.String str17 = period14.toString();
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.clockhourOfDay();
//        boolean boolean21 = iSOChronology18.equals((java.lang.Object) (-1.0f));
//        org.joda.time.Period period22 = new org.joda.time.Period((java.lang.Object) period14, (org.joda.time.Chronology) iSOChronology18);
//        int[] intArray24 = zonedChronology7.get((org.joda.time.ReadablePeriod) period22, (-1L));
//        org.joda.time.chrono.LenientChronology lenientChronology25 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology7);
//        org.joda.time.Period period26 = new org.joda.time.Period((long) 'a', (long) 0, (org.joda.time.Chronology) lenientChronology25);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str28 = dateTimeZone27.getID();
//        java.lang.String str29 = dateTimeZone27.getID();
//        java.util.TimeZone timeZone30 = dateTimeZone27.toTimeZone();
//        java.lang.String str32 = dateTimeZone27.getName((long) 3);
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
//        long long36 = dateTimeZone27.getMillisKeepLocal(dateTimeZone34, (long) (byte) 100);
//        org.joda.time.Chronology chronology37 = lenientChronology25.withZone(dateTimeZone27);
//        org.joda.time.DateTimeField dateTimeField38 = lenientChronology25.monthOfYear();
//        org.joda.time.Period period40 = org.joda.time.Period.seconds(1);
//        org.joda.time.Period period42 = period40.plusHours((-100));
//        boolean boolean43 = lenientChronology25.equals((java.lang.Object) period42);
//        org.joda.time.DateTimeField dateTimeField44 = lenientChronology25.minuteOfHour();
//        org.junit.Assert.assertNotNull(periodType3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//        org.junit.Assert.assertNotNull(zonedChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str9.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PT0.052S" + "'", str17.equals("PT0.052S"));
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(intArray24);
//        org.junit.Assert.assertNotNull(lenientChronology25);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UTC" + "'", str29.equals("UTC"));
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Coordinated Universal Time" + "'", str32.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-349199900L) + "'", long36 == (-349199900L));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(period40);
//        org.junit.Assert.assertNotNull(period42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.Period period8 = new org.joda.time.Period(1, 10, (int) (short) -1, (-2), (int) (byte) 1, (int) (byte) 1, (int) ' ', (int) (byte) 10);
        org.joda.time.Period period10 = period8.minusSeconds((int) (short) 10);
        org.joda.time.Period period12 = period8.minusWeeks(3);
        try {
            org.joda.time.Seconds seconds13 = period12.toStandardSeconds();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Seconds as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str26 = dateTimeZone25.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology27 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology24, dateTimeZone25);
        java.lang.String str28 = dateTimeZone25.getID();
        java.lang.String str29 = dateTimeZone25.toString();
        long long32 = dateTimeZone25.convertLocalToUTC((long) '4', false);
        org.joda.time.Chronology chronology33 = zonedChronology5.withZone(dateTimeZone25);
        org.joda.time.DateTimeField dateTimeField34 = zonedChronology5.weekyearOfCentury();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UTC" + "'", str26.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UTC" + "'", str29.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 52L + "'", long32 == 52L);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        int int5 = period3.getMillis();
        org.joda.time.Period period7 = period3.minusYears((int) ' ');
        org.joda.time.Period period9 = period7.plusDays((int) 'a');
        org.joda.time.Period period10 = period7.negated();
        org.joda.time.Period period12 = org.joda.time.Period.seconds((int) (short) -1);
        org.joda.time.ReadableInterval readableInterval14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval14);
        org.joda.time.Period period16 = new org.joda.time.Period((long) '4', chronology15);
        org.joda.time.Period period18 = period16.plusMillis(1);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType((int) (short) 0);
        int int22 = period16.indexOf(durationFieldType21);
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(durationFieldType21, "UTC");
        org.joda.time.Period period26 = period12.withFieldAdded(durationFieldType21, (int) '4');
        int int27 = period10.get(durationFieldType21);
        org.joda.time.format.PeriodFormatter periodFormatter28 = null;
        java.lang.String str29 = period10.toString(periodFormatter28);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "P32YT-0.052S" + "'", str29.equals("P32YT-0.052S"));
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.joda.time.ReadableInterval readableInterval1 = null;
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
//        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
//        org.joda.time.Period period5 = period3.withYears((int) (short) 10);
//        org.joda.time.Period period6 = period3.normalizedStandard();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str8 = dateTimeZone7.getID();
//        java.lang.String str9 = dateTimeZone7.getID();
//        java.util.TimeZone timeZone10 = dateTimeZone7.toTimeZone();
//        java.lang.String str12 = dateTimeZone7.getName((long) 3);
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
//        long long16 = dateTimeZone7.getMillisKeepLocal(dateTimeZone14, (long) (byte) 100);
//        boolean boolean17 = period3.equals((java.lang.Object) long16);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(period6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Coordinated Universal Time" + "'", str12.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-349199900L) + "'", long16 == (-349199900L));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.withYears((int) (short) 10);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period3.toDurationFrom(readableInstant6);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType10 = periodType9.withWeeksRemoved();
        org.joda.time.PeriodType periodType11 = periodType10.withMillisRemoved();
        org.joda.time.PeriodType periodType12 = org.joda.time.DateTimeUtils.getPeriodType(periodType11);
        org.joda.time.Period period13 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration7, readableInstant8, periodType12);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        try {
            long long12 = unsupportedDurationField10.getMillis(10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: days field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 1, (java.lang.Number) 100, (java.lang.Number) 10.0d);
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        java.lang.String str6 = illegalFieldValueException4.toString();
        java.lang.Class<?> wildcardClass7 = illegalFieldValueException4.getClass();
        java.lang.String str8 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]" + "'", str6.equals("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]"));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        long long10 = durationField7.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period15 = period14.toPeriod();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) '4', chronology18);
        org.joda.time.Period period21 = period19.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType24 = periodType22.getFieldType((int) (short) 0);
        boolean boolean25 = period14.isSupported(durationFieldType24);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType24, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField29 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType24, (int) (short) 100);
        org.joda.time.ReadableInterval readableInterval31 = null;
        org.joda.time.Chronology chronology32 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval31);
        org.joda.time.Period period33 = new org.joda.time.Period((long) '4', chronology32);
        org.joda.time.Period period34 = period33.toPeriod();
        org.joda.time.PeriodType periodType35 = org.joda.time.PeriodType.years();
        org.joda.time.ReadableInterval readableInterval37 = null;
        org.joda.time.Chronology chronology38 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval37);
        org.joda.time.Period period39 = new org.joda.time.Period((long) '4', chronology38);
        org.joda.time.Period period41 = period39.plusMillis(1);
        org.joda.time.PeriodType periodType42 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType44 = periodType42.getFieldType((int) (short) 0);
        int int45 = period39.indexOf(durationFieldType44);
        org.joda.time.IllegalFieldValueException illegalFieldValueException47 = new org.joda.time.IllegalFieldValueException(durationFieldType44, "UTC");
        int int48 = periodType35.indexOf(durationFieldType44);
        org.joda.time.PeriodType periodType49 = periodType35.withMonthsRemoved();
        org.joda.time.Period period50 = period33.normalizedStandard(periodType35);
        org.joda.time.Period period52 = period33.plusMonths((int) 'a');
        boolean boolean53 = scaledDurationField29.equals((java.lang.Object) period33);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(periodType42);
        org.junit.Assert.assertNotNull(durationFieldType44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 3 + "'", int45 == 3);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(periodType49);
        org.junit.Assert.assertNotNull(period50);
        org.junit.Assert.assertNotNull(period52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, number1, "ZonedChronology[ISOChronology[UTC], UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.Period period3 = org.joda.time.Period.seconds((int) (short) -1);
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) '4', chronology6);
        org.joda.time.Period period9 = period7.plusMillis(1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType12 = periodType10.getFieldType((int) (short) 0);
        int int13 = period7.indexOf(durationFieldType12);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(durationFieldType12, "UTC");
        org.joda.time.Period period17 = period3.withFieldAdded(durationFieldType12, (int) '4');
        int[] intArray18 = period3.getValues();
        try {
            iSOChronology0.validate(readablePartial1, intArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        boolean boolean11 = unsupportedDurationField10.isSupported();
        try {
            long long14 = unsupportedDurationField10.add((long) 0, 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: days field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.Period period1 = new org.joda.time.Period(0L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        try {
            int int12 = unsupportedDurationField10.getValue((long) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: days field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        boolean boolean11 = unsupportedDurationField10.isSupported();
        try {
            int int14 = unsupportedDurationField10.getValue((long) 2, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: days field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 1, periodType1, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DurationField durationField8 = iSOChronology4.seconds();
        org.joda.time.chrono.LenientChronology lenientChronology9 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DurationField durationField10 = lenientChronology9.millis();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(lenientChronology9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology2.dayOfMonth();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.Period period2 = new org.joda.time.Period(2440578L, (long) 52);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', chronology7);
        org.joda.time.Period period10 = period8.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType((int) (short) 0);
        boolean boolean14 = period3.isSupported(durationFieldType13);
        org.joda.time.field.PreciseDurationField preciseDurationField16 = new org.joda.time.field.PreciseDurationField(durationFieldType13, (long) '4');
        org.joda.time.Period period17 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval19 = null;
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval19);
        org.joda.time.Period period21 = new org.joda.time.Period((long) '4', chronology20);
        org.joda.time.Period period23 = period21.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType24 = period23.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType26 = periodType24.getFieldType((int) (short) 0);
        org.joda.time.Period period28 = period17.withField(durationFieldType26, (int) (short) 0);
        org.joda.time.Period period30 = period17.withWeeks((-1));
        org.joda.time.ReadableInterval readableInterval32 = null;
        org.joda.time.Chronology chronology33 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) '4', chronology33);
        org.joda.time.Period period36 = period34.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType37 = period36.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType39 = periodType37.getFieldType((int) (short) 0);
        org.joda.time.Period period41 = period30.withField(durationFieldType39, (int) (short) -1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(durationFieldType39, "Weeks");
        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) preciseDurationField16, durationFieldType39);
        long long47 = decoratedDurationField44.add((long) 100, (int) (byte) 100);
        java.lang.String str48 = decoratedDurationField44.getName();
        long long50 = decoratedDurationField44.getMillis((int) (short) 1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(durationFieldType39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 5300L + "'", long47 == 5300L);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "years" + "'", str48.equals("years"));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 52L + "'", long50 == 52L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str1 = dateTimeZone0.getID();
        java.util.TimeZone timeZone2 = dateTimeZone0.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTC" + "'", str1.equals("UTC"));
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.DurationField durationField4 = iSOChronology0.weeks();
        org.joda.time.Period period9 = new org.joda.time.Period((int) (byte) 1, (int) (short) -1, 0, (int) (short) -1);
        org.joda.time.Period period10 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period16 = period14.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType17 = period16.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType19 = periodType17.getFieldType((int) (short) 0);
        org.joda.time.Period period21 = period10.withField(durationFieldType19, (int) (short) 0);
        org.joda.time.Period period23 = period10.withWeeks((-1));
        org.joda.time.ReadableInterval readableInterval25 = null;
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval25);
        org.joda.time.Period period27 = new org.joda.time.Period((long) '4', chronology26);
        org.joda.time.Period period29 = period27.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType30 = period29.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.Period period34 = period23.withField(durationFieldType32, (int) (short) -1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(durationFieldType32, "Weeks");
        boolean boolean37 = period9.isSupported(durationFieldType32);
        long long40 = iSOChronology0.add((org.joda.time.ReadablePeriod) period9, 1L, 4);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 14159997L + "'", long40 == 14159997L);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        java.lang.String str6 = period3.toString();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.clockhourOfDay();
        boolean boolean10 = iSOChronology7.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period11 = new org.joda.time.Period((java.lang.Object) period3, (org.joda.time.Chronology) iSOChronology7);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology7.halfdayOfDay();
        org.joda.time.DurationField durationField13 = iSOChronology7.weeks();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PT0.052S" + "'", str6.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((-2));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period1 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) '4', chronology4);
        org.joda.time.Period period7 = period5.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType8 = period7.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType10 = periodType8.getFieldType((int) (short) 0);
        org.joda.time.Period period12 = period1.withField(durationFieldType10, (int) (short) 0);
        org.joda.time.Period period14 = period1.withWeeks((-1));
        org.joda.time.Period period16 = period14.withYears(52);
        int[] intArray18 = iSOChronology0.get((org.joda.time.ReadablePeriod) period16, (long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial19 = null;
        try {
            int[] intArray21 = iSOChronology0.get(readablePartial19, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        long long27 = zonedChronology5.add(1000L, 1560628908182L, (int) (short) 1);
        org.joda.time.Chronology chronology28 = zonedChronology5.withUTC();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560628909182L + "'", long27 == 1560628909182L);
        org.junit.Assert.assertNotNull(chronology28);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.Period period1 = org.joda.time.Period.days(3);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.Period period4 = period2.minusMinutes(52);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period2.toDurationTo(readableInstant5);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration6, readableInstant7, periodType8);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration6);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "DayTime", 0, 10);
        int int6 = fixedDateTimeZone4.getStandardOffset((-210865896000000L));
        long long8 = fixedDateTimeZone4.nextTransition((long) (short) 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        long long27 = zonedChronology5.add(1000L, 1560628908182L, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField28 = zonedChronology5.minuteOfDay();
        java.lang.String str29 = zonedChronology5.toString();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560628909182L + "'", long27 == 1560628909182L);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str29.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("UTC", "UTC");
        illegalFieldValueException2.prependMessage("PeriodType[Weeks]");
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Period period5 = period4.normalizedStandard();
        org.joda.time.Period period7 = period4.withYears(10);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Duration duration9 = period7.toDurationTo(readableInstant8);
        long long10 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration9);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 315619199935L + "'", long10 == 315619199935L);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 1, periodType1, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DurationField durationField8 = iSOChronology4.seconds();
        org.joda.time.chrono.LenientChronology lenientChronology9 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology4);
        long long13 = lenientChronology9.add(0L, 2440578L, 100);
        org.joda.time.Chronology chronology14 = lenientChronology9.withUTC();
        org.joda.time.Chronology chronology15 = lenientChronology9.withUTC();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(lenientChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 244057800L + "'", long13 == 244057800L);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(chronology15);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (byte) 100, 1, (int) (short) 100);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.DateTimeField dateTimeField24 = zonedChronology5.millisOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField27 = new org.joda.time.field.DividedDateTimeField(dateTimeField24, dateTimeFieldType25, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        boolean boolean11 = unsupportedDurationField10.isSupported();
        org.joda.time.DurationFieldType durationFieldType12 = unsupportedDurationField10.getType();
        boolean boolean13 = unsupportedDurationField10.isSupported();
        try {
            long long16 = unsupportedDurationField10.add((long) 0, (long) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: days field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(97L, (long) (byte) 100, periodType2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.years();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', chronology7);
        org.joda.time.Period period10 = period8.plusMillis(1);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType((int) (short) 0);
        int int14 = period8.indexOf(durationFieldType13);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(durationFieldType13, "UTC");
        int int17 = periodType4.indexOf(durationFieldType13);
        org.joda.time.Period period18 = period3.normalizedStandard(periodType4);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(period18);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("1", (-2), 4, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2 for 1 must be in the range [4,10]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        boolean boolean11 = unsupportedDurationField10.isSupported();
        java.lang.String str12 = unsupportedDurationField10.getName();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "days" + "'", str12.equals("days"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str26 = dateTimeZone25.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology27 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology24, dateTimeZone25);
        java.lang.String str28 = dateTimeZone25.getID();
        java.lang.String str29 = dateTimeZone25.toString();
        long long32 = dateTimeZone25.convertLocalToUTC((long) '4', false);
        org.joda.time.Chronology chronology33 = zonedChronology5.withZone(dateTimeZone25);
        org.joda.time.ReadableInstant readableInstant34 = null;
        int int35 = dateTimeZone25.getOffset(readableInstant34);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UTC" + "'", str26.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UTC" + "'", str29.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 52L + "'", long32 == 52L);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period6 = period4.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType7 = period6.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (short) 0);
        org.joda.time.Period period11 = period0.withField(durationFieldType9, (int) (short) 0);
        org.joda.time.Period period13 = period0.withWeeks((-1));
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.clockhourOfDay();
        org.joda.time.Period period20 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology18);
        org.joda.time.Period period21 = new org.joda.time.Period((long) (byte) 1, periodType15, (org.joda.time.Chronology) iSOChronology18);
        org.joda.time.Period period22 = period0.withPeriodType(periodType15);
        org.joda.time.PeriodType periodType23 = periodType15.withDaysRemoved();
        org.joda.time.Period period25 = org.joda.time.Period.seconds((int) (short) -1);
        org.joda.time.ReadableInterval readableInterval27 = null;
        org.joda.time.Chronology chronology28 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval27);
        org.joda.time.Period period29 = new org.joda.time.Period((long) '4', chronology28);
        org.joda.time.Period period31 = period29.plusMillis(1);
        org.joda.time.PeriodType periodType32 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType34 = periodType32.getFieldType((int) (short) 0);
        int int35 = period29.indexOf(durationFieldType34);
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(durationFieldType34, "UTC");
        org.joda.time.Period period39 = period25.withFieldAdded(durationFieldType34, (int) '4');
        org.joda.time.field.PreciseDurationField preciseDurationField41 = new org.joda.time.field.PreciseDurationField(durationFieldType34, (long) (-100));
        int int42 = periodType23.indexOf(durationFieldType34);
        org.joda.time.PeriodType periodType43 = org.joda.time.DateTimeUtils.getPeriodType(periodType23);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 3 + "'", int35 == 3);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(periodType43);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', chronology7);
        org.joda.time.Period period10 = period8.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType((int) (short) 0);
        boolean boolean14 = period3.isSupported(durationFieldType13);
        org.joda.time.field.PreciseDurationField preciseDurationField16 = new org.joda.time.field.PreciseDurationField(durationFieldType13, (long) '4');
        long long19 = preciseDurationField16.add((long) (-2), (int) (byte) 0);
        long long21 = preciseDurationField16.getMillis(52);
        long long24 = preciseDurationField16.add((long) 2, 0L);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-2L) + "'", long19 == (-2L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2704L + "'", long21 == 2704L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2L + "'", long24 == 2L);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType6 = period5.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField10 = new org.joda.time.field.PreciseDurationField(durationFieldType8, (long) (byte) 100);
        long long13 = preciseDurationField10.getValueAsLong(0L, (long) 10);
        long long16 = preciseDurationField10.subtract((long) 100, (long) (short) 0);
        org.joda.time.DurationFieldType durationFieldType17 = preciseDurationField10.getType();
        boolean boolean18 = preciseDurationField10.isSupported();
        long long21 = preciseDurationField10.getMillis(8, 32L);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 800L + "'", long21 == 800L);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(0, 0, 68, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 1, (java.lang.Number) 100, (java.lang.Number) 10.0d);
        java.lang.String str5 = illegalFieldValueException4.getIllegalValueAsString();
        illegalFieldValueException4.prependMessage("Time");
        java.lang.String str8 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1" + "'", str5.equals("1"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (short) 10);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("PeriodType[DayTimeNoMillis]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"PeriodType[DayTimeNoMillis]\" is malformed at \"eriodType[DayTimeNoMillis]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) -1);
        java.io.DataOutput dataOutput4 = null;
        try {
            dateTimeZoneBuilder0.writeTo("Coordinated Universal Time", dataOutput4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 1, periodType1, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DurationField durationField8 = iSOChronology4.seconds();
        org.joda.time.chrono.LenientChronology lenientChronology9 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology4);
        long long13 = lenientChronology9.add(0L, 2440578L, 100);
        java.lang.String str14 = lenientChronology9.toString();
        org.joda.time.ReadablePartial readablePartial15 = null;
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.clockhourOfDay();
        org.joda.time.Period period22 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology20);
        org.joda.time.Period period23 = new org.joda.time.Period((long) (byte) 1, periodType17, (org.joda.time.Chronology) iSOChronology20);
        org.joda.time.DurationField durationField24 = iSOChronology20.halfdays();
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.Period period27 = new org.joda.time.Period(readableInstant25, readableInstant26);
        org.joda.time.Period period29 = period27.minusMinutes(52);
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.Duration duration31 = period27.toDurationTo(readableInstant30);
        int[] intArray33 = iSOChronology20.get((org.joda.time.ReadablePeriod) period27, 2440588L);
        try {
            lenientChronology9.validate(readablePartial15, intArray33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(lenientChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 244057800L + "'", long13 == 244057800L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str14.equals("LenientChronology[ISOChronology[UTC]]"));
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(duration31);
        org.junit.Assert.assertNotNull(intArray33);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "P32YT-0.052S");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType6 = period5.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField10 = new org.joda.time.field.PreciseDurationField(durationFieldType8, (long) (byte) 100);
        long long13 = preciseDurationField10.getMillis(0L, 10L);
        long long15 = preciseDurationField10.getMillis(1560628908182L);
        long long18 = preciseDurationField10.subtract((long) (-2), (int) '4');
        java.lang.String str19 = preciseDurationField10.toString();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 156062890818200L + "'", long15 == 156062890818200L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-5202L) + "'", long18 == (-5202L));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "DurationField[years]" + "'", str19.equals("DurationField[years]"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType9 = periodType8.withWeeksRemoved();
        org.joda.time.PeriodType periodType10 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
        java.lang.Class<?> wildcardClass11 = periodType10.getClass();
        try {
            org.joda.time.Period period12 = new org.joda.time.Period((int) (byte) -1, 0, (int) (short) 10, 0, 8, (int) (byte) 1, (int) (byte) 0, 2, periodType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone1.isLocalDateTimeGap(localDateTime4);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440587L + "'", long1 == 2440587L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.time();
        try {
            org.joda.time.Period period3 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (byte) 10, (java.lang.Number) (short) 10, (java.lang.Number) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.Chronology chronology24 = zonedChronology5.withUTC();
        try {
            long long29 = zonedChronology5.getDateTimeMillis((-100), 0, (int) (byte) -1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (short) -1, "PT-0.065S");
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) (-100));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440587L + "'", long1 == 2440587L);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(449280000000L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2445788L + "'", long1 == 2445788L);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = zonedChronology3.getZone();
        java.lang.String str5 = zonedChronology3.toString();
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology3);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.weekyear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        boolean boolean11 = unsupportedDurationField10.isSupported();
        try {
            long long14 = unsupportedDurationField10.add((long) (short) 0, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: days field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        java.lang.String str11 = unsupportedDurationField10.getName();
        boolean boolean12 = unsupportedDurationField10.isPrecise();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "days" + "'", str11.equals("days"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("", 100, 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for  must be in the range [0,10]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        boolean boolean11 = unsupportedDurationField10.isSupported();
        org.joda.time.DurationFieldType durationFieldType12 = unsupportedDurationField10.getType();
        try {
            long long15 = unsupportedDurationField10.add(244057800L, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: days field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationFieldType12);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Period period5 = period4.normalizedStandard();
        org.joda.time.Period period7 = period4.withYears(10);
        org.joda.time.Period period9 = period7.withWeeks((-1));
        org.joda.time.MutablePeriod mutablePeriod10 = period9.toMutablePeriod();
        org.joda.time.Period period12 = period9.withMillis(52);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(mutablePeriod10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "PT0S");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.Period period4 = period2.minusMinutes(52);
        org.joda.time.Period period6 = period2.withDays((int) 'a');
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        int int5 = period3.getMillis();
        org.joda.time.Period period7 = period3.minusYears((int) ' ');
        org.joda.time.Period period9 = period7.plusDays((int) 'a');
        try {
            org.joda.time.Weeks weeks10 = period7.toStandardWeeks();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Weeks as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 1, (java.lang.Number) 100, (java.lang.Number) 10.0d);
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        java.lang.String str6 = illegalFieldValueException4.getFieldName();
        org.joda.time.IllegalInstantException illegalInstantException9 = new org.joda.time.IllegalInstantException(2440588L, "org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalInstantException9);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 1, (java.lang.Number) 100, (java.lang.Number) 10.0d);
        java.lang.String str16 = illegalFieldValueException15.getIllegalStringValue();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException15);
        java.lang.Throwable[] throwableArray18 = illegalFieldValueException15.getSuppressed();
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.weekyearOfCentury();
        org.joda.time.DurationField durationField21 = iSOChronology19.days();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology19.year();
        try {
            org.joda.time.Period period23 = new org.joda.time.Period((java.lang.Object) throwableArray18, (org.joda.time.Chronology) iSOChronology19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: [Ljava.lang.Throwable;");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', chronology7);
        org.joda.time.Period period10 = period8.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType((int) (short) 0);
        boolean boolean14 = period3.isSupported(durationFieldType13);
        org.joda.time.field.PreciseDurationField preciseDurationField16 = new org.joda.time.field.PreciseDurationField(durationFieldType13, (long) '4');
        long long19 = preciseDurationField16.add((-2L), (long) 'a');
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.ReadableInterval readableInterval23 = null;
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval23);
        org.joda.time.Period period25 = new org.joda.time.Period((long) '4', chronology24);
        org.joda.time.Period period27 = period25.withYears((int) (short) 10);
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Duration duration29 = period25.toDurationFrom(readableInstant28);
        org.joda.time.Period period31 = org.joda.time.Period.months(100);
        int int32 = period31.getMonths();
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField38 = iSOChronology37.clockhourOfDay();
        org.joda.time.Period period39 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology37);
        org.joda.time.Period period40 = new org.joda.time.Period((long) (byte) 1, periodType34, (org.joda.time.Chronology) iSOChronology37);
        org.joda.time.PeriodType periodType41 = periodType34.withYearsRemoved();
        boolean boolean42 = period31.equals((java.lang.Object) periodType34);
        org.joda.time.Period period43 = new org.joda.time.Period(readableInstant21, (org.joda.time.ReadableDuration) duration29, periodType34);
        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType45 = periodType44.withWeeksRemoved();
        org.joda.time.PeriodType periodType46 = periodType45.withMillisRemoved();
        org.joda.time.Period period47 = new org.joda.time.Period(readableInstant20, (org.joda.time.ReadableDuration) duration29, periodType46);
        boolean boolean48 = preciseDurationField16.equals((java.lang.Object) readableInstant20);
        long long51 = preciseDurationField16.getMillis(0, (long) (byte) 1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 5042L + "'", long19 == 5042L);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(duration29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(periodType46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', chronology7);
        org.joda.time.Period period10 = period8.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType((int) (short) 0);
        boolean boolean14 = period3.isSupported(durationFieldType13);
        org.joda.time.field.PreciseDurationField preciseDurationField16 = new org.joda.time.field.PreciseDurationField(durationFieldType13, (long) '4');
        org.joda.time.Period period17 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval19 = null;
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval19);
        org.joda.time.Period period21 = new org.joda.time.Period((long) '4', chronology20);
        org.joda.time.Period period23 = period21.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType24 = period23.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType26 = periodType24.getFieldType((int) (short) 0);
        org.joda.time.Period period28 = period17.withField(durationFieldType26, (int) (short) 0);
        org.joda.time.Period period30 = period17.withWeeks((-1));
        org.joda.time.ReadableInterval readableInterval32 = null;
        org.joda.time.Chronology chronology33 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) '4', chronology33);
        org.joda.time.Period period36 = period34.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType37 = period36.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType39 = periodType37.getFieldType((int) (short) 0);
        org.joda.time.Period period41 = period30.withField(durationFieldType39, (int) (short) -1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(durationFieldType39, "Weeks");
        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) preciseDurationField16, durationFieldType39);
        boolean boolean45 = preciseDurationField16.isSupported();
        boolean boolean47 = preciseDurationField16.equals((java.lang.Object) 1.0d);
        org.joda.time.ReadableInterval readableInterval49 = null;
        org.joda.time.Chronology chronology50 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval49);
        org.joda.time.Period period51 = new org.joda.time.Period((long) '4', chronology50);
        org.joda.time.Period period53 = period51.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType54 = period53.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType56 = periodType54.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField58 = new org.joda.time.field.PreciseDurationField(durationFieldType56, (long) (byte) 100);
        long long61 = preciseDurationField58.getMillis(0L, 10L);
        int int62 = preciseDurationField16.compareTo((org.joda.time.DurationField) preciseDurationField58);
        long long65 = preciseDurationField16.add((long) (-32), (-1));
        java.lang.String str66 = preciseDurationField16.toString();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(durationFieldType39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(chronology50);
        org.junit.Assert.assertNotNull(period53);
        org.junit.Assert.assertNotNull(periodType54);
        org.junit.Assert.assertNotNull(durationFieldType56);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + (-84L) + "'", long65 == (-84L));
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "DurationField[years]" + "'", str66.equals("DurationField[years]"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        boolean boolean11 = unsupportedDurationField10.isSupported();
        org.joda.time.DurationFieldType durationFieldType12 = unsupportedDurationField10.getType();
        try {
            long long15 = unsupportedDurationField10.getValueAsLong(0L, 800L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: days field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationFieldType12);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) '4', chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        int int7 = period5.getMillis();
        org.joda.time.Period period9 = period5.minusYears((int) ' ');
        int[] intArray11 = iSOChronology0.get((org.joda.time.ReadablePeriod) period9, (long) (short) 0);
        org.joda.time.DurationField durationField12 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology0.era();
        org.joda.time.DurationField durationField15 = iSOChronology0.halfdays();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str8 = dateTimeZone7.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology6, dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone10 = zonedChronology9.getZone();
        java.lang.String str11 = zonedChronology9.toString();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 3, periodType5, (org.joda.time.Chronology) zonedChronology9);
        org.joda.time.ReadableInterval readableInterval14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval14);
        org.joda.time.Period period16 = new org.joda.time.Period((long) '4', chronology15);
        org.joda.time.Period period18 = period16.plusMillis(1);
        java.lang.String str19 = period16.toString();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.clockhourOfDay();
        boolean boolean23 = iSOChronology20.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) period16, (org.joda.time.Chronology) iSOChronology20);
        int[] intArray26 = zonedChronology9.get((org.joda.time.ReadablePeriod) period24, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology27 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology9);
        long long32 = zonedChronology9.getDateTimeMillis(100, (int) (short) 10, 10, (int) 'a');
        org.joda.time.Period period33 = new org.joda.time.Period(0L, periodType3, (org.joda.time.Chronology) zonedChronology9);
        org.joda.time.Period period34 = new org.joda.time.Period(2440578L, periodType3);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str11.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PT0.052S" + "'", str19.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(lenientChronology27);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-58987094399903L) + "'", long32 == (-58987094399903L));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "DayTime");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str1 = dateTimeZone0.getID();
        java.util.TimeZone timeZone2 = dateTimeZone0.toTimeZone();
        java.util.TimeZone timeZone3 = dateTimeZone0.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTC" + "'", str1.equals("UTC"));
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(52, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period6 = period4.plusMillis(1);
        java.lang.String str7 = period4.toString();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.clockhourOfDay();
        boolean boolean11 = iSOChronology8.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) period4, (org.joda.time.Chronology) iSOChronology8);
        org.joda.time.Period period13 = new org.joda.time.Period(10L, (org.joda.time.Chronology) iSOChronology8);
        org.joda.time.ReadablePartial readablePartial14 = null;
        try {
            int[] intArray16 = iSOChronology8.get(readablePartial14, 52L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PT0.052S" + "'", str7.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(1);
        org.joda.time.Period period3 = period1.plusHours((-100));
        org.joda.time.Period period5 = period3.withMonths((int) (short) 100);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.Period period4 = period2.minusMinutes(52);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period2.toDurationTo(readableInstant5);
        org.joda.time.DurationFieldType[] durationFieldTypeArray7 = period2.getFieldTypes();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(durationFieldTypeArray7);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period6 = period4.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType7 = period6.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField11 = new org.joda.time.field.PreciseDurationField(durationFieldType9, (long) (byte) 100);
        long long14 = preciseDurationField11.getMillis(0L, 10L);
        long long17 = preciseDurationField11.getMillis((long) 100, (long) (short) 0);
        long long20 = preciseDurationField11.getValueAsLong(97L, (long) 0);
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str25 = dateTimeZone24.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology26 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology23, dateTimeZone24);
        org.joda.time.DateTimeZone dateTimeZone27 = zonedChronology26.getZone();
        java.lang.String str28 = zonedChronology26.toString();
        org.joda.time.Period period29 = new org.joda.time.Period((long) 3, periodType22, (org.joda.time.Chronology) zonedChronology26);
        org.joda.time.ReadableInterval readableInterval31 = null;
        org.joda.time.Chronology chronology32 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval31);
        org.joda.time.Period period33 = new org.joda.time.Period((long) '4', chronology32);
        org.joda.time.Period period35 = period33.plusMillis(1);
        java.lang.String str36 = period33.toString();
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField38 = iSOChronology37.clockhourOfDay();
        boolean boolean40 = iSOChronology37.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period41 = new org.joda.time.Period((java.lang.Object) period33, (org.joda.time.Chronology) iSOChronology37);
        int[] intArray43 = zonedChronology26.get((org.joda.time.ReadablePeriod) period41, (-1L));
        org.joda.time.DurationField durationField44 = zonedChronology26.weeks();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, (org.joda.time.DurationField) preciseDurationField11, durationField44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10000L + "'", long17 == 10000L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "UTC" + "'", str25.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str28.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "PT0.052S" + "'", str36.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(durationField44);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.clockhourOfDay();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology6);
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 1, periodType3, (org.joda.time.Chronology) iSOChronology6);
        org.joda.time.Period period10 = new org.joda.time.Period(1560628908182L, (long) (-1), (org.joda.time.Chronology) iSOChronology6);
        try {
            int int12 = period10.getValue((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.Period period1 = org.joda.time.Period.months(100);
        int int2 = period1.getMonths();
        org.joda.time.DurationFieldType[] durationFieldTypeArray3 = period1.getFieldTypes();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
        org.junit.Assert.assertNotNull(durationFieldTypeArray3);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) ' ');
        org.joda.time.Period period3 = period1.multipliedBy(2);
        org.joda.time.Period period5 = period3.withYears((int) (short) -1);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        java.security.PermissionCollection permissionCollection3 = jodaTimePermission1.newPermissionCollection();
        java.security.PermissionCollection permissionCollection4 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str5 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertNotNull(permissionCollection3);
        org.junit.Assert.assertNotNull(permissionCollection4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str1 = dateTimeZone0.getID();
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone0.getName((long) 8, locale4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone0.getShortName(3536L, locale7);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTC" + "'", str1.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        long long10 = durationField7.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period15 = period14.toPeriod();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) '4', chronology18);
        org.joda.time.Period period21 = period19.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType24 = periodType22.getFieldType((int) (short) 0);
        boolean boolean25 = period14.isSupported(durationFieldType24);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType24, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField29 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType24, (int) (short) 100);
        long long31 = scaledDurationField29.getValueAsLong((long) 68);
        long long33 = scaledDurationField29.getMillis(52);
        long long36 = scaledDurationField29.getDifferenceAsLong((-84L), (-34919990L));
        long long39 = scaledDurationField29.getDifferenceAsLong(5042L, 5042L);
        int int42 = scaledDurationField29.getDifference((long) ' ', 1560628909182L);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 449280000000L + "'", long33 == 449280000000L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-180) + "'", int42 == (-180));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = zonedChronology3.getZone();
        long long7 = dateTimeZone4.adjustOffset(1560628908182L, true);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560628908182L + "'", long7 == 1560628908182L);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1", "org.joda.time.IllegalFieldValueException: Coordinated Universal Time: Value 0 for org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0] must be in the range [100,10.0]");
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test351");
//        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.dayTime();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str6 = dateTimeZone5.getID();
//        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone8 = zonedChronology7.getZone();
//        java.lang.String str9 = zonedChronology7.toString();
//        org.joda.time.Period period10 = new org.joda.time.Period((long) 3, periodType3, (org.joda.time.Chronology) zonedChronology7);
//        org.joda.time.ReadableInterval readableInterval12 = null;
//        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
//        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
//        org.joda.time.Period period16 = period14.plusMillis(1);
//        java.lang.String str17 = period14.toString();
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.clockhourOfDay();
//        boolean boolean21 = iSOChronology18.equals((java.lang.Object) (-1.0f));
//        org.joda.time.Period period22 = new org.joda.time.Period((java.lang.Object) period14, (org.joda.time.Chronology) iSOChronology18);
//        int[] intArray24 = zonedChronology7.get((org.joda.time.ReadablePeriod) period22, (-1L));
//        org.joda.time.chrono.LenientChronology lenientChronology25 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology7);
//        org.joda.time.Period period26 = new org.joda.time.Period((long) 'a', (long) 0, (org.joda.time.Chronology) lenientChronology25);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str28 = dateTimeZone27.getID();
//        java.lang.String str29 = dateTimeZone27.getID();
//        java.util.TimeZone timeZone30 = dateTimeZone27.toTimeZone();
//        java.lang.String str32 = dateTimeZone27.getName((long) 3);
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
//        long long36 = dateTimeZone27.getMillisKeepLocal(dateTimeZone34, (long) (byte) 100);
//        org.joda.time.Chronology chronology37 = lenientChronology25.withZone(dateTimeZone27);
//        org.joda.time.DateTimeField dateTimeField38 = lenientChronology25.minuteOfHour();
//        org.junit.Assert.assertNotNull(periodType3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//        org.junit.Assert.assertNotNull(zonedChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str9.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PT0.052S" + "'", str17.equals("PT0.052S"));
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(intArray24);
//        org.junit.Assert.assertNotNull(lenientChronology25);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UTC" + "'", str29.equals("UTC"));
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Coordinated Universal Time" + "'", str32.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-349199900L) + "'", long36 == (-349199900L));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType2 = periodType1.withSecondsRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.clockhourOfDay();
        boolean boolean6 = iSOChronology3.equals((java.lang.Object) (-1.0f));
        org.joda.time.DateTimeZone dateTimeZone7 = iSOChronology3.getZone();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (byte) -1, periodType2, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology3.hourOfHalfday();
        try {
            long long17 = iSOChronology3.getDateTimeMillis((-58987094399903L), 100, 0, (int) (short) 1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfSecond();
        org.joda.time.DurationField durationField4 = iSOChronology0.hours();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) '4', chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        int int7 = period5.getMillis();
        org.joda.time.Period period9 = period5.minusYears((int) ' ');
        int[] intArray11 = iSOChronology0.get((org.joda.time.ReadablePeriod) period9, (long) (short) 0);
        org.joda.time.Period period12 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval14);
        org.joda.time.Period period16 = new org.joda.time.Period((long) '4', chronology15);
        org.joda.time.Period period18 = period16.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType19 = period18.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType((int) (short) 0);
        org.joda.time.Period period23 = period12.withField(durationFieldType21, (int) (short) 0);
        org.joda.time.Period period25 = period12.withWeeks((-1));
        org.joda.time.Period period26 = period9.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.Period period28 = period9.minusMillis((int) (byte) 1);
        org.joda.time.Period period29 = period28.normalizedStandard();
        org.joda.time.Period period31 = period29.minusMillis(2);
        org.joda.time.Period period33 = period31.withWeeks((int) ' ');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(period33);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("Time", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "DayTime", 0, 10);
        int int6 = fixedDateTimeZone4.getStandardOffset((-210865896000000L));
        int int8 = fixedDateTimeZone4.getStandardOffset(156062890818200L);
        int int10 = fixedDateTimeZone4.getOffsetFromLocal((long) 52);
        java.lang.String str12 = fixedDateTimeZone4.getNameKey(0L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DayTime" + "'", str12.equals("DayTime"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("PT0.052S", (-180), (int) (short) 10, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -180 for PT0.052S must be in the range [10,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.ReadablePartial readablePartial6 = null;
        try {
            long long8 = iSOChronology2.set(readablePartial6, 156062890818200L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        try {
            int int13 = unsupportedDurationField10.getValue((-61851686400000L), 3536L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: days field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 1, (java.lang.Number) 100, (java.lang.Number) 10.0d);
        java.lang.String str5 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.Number number7 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1" + "'", str5.equals("1"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1 + "'", number6.equals(1));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10.0d + "'", number7.equals(10.0d));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        java.lang.String str5 = iSOChronology0.toString();
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period8 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType15 = period14.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType17 = periodType15.getFieldType((int) (short) 0);
        org.joda.time.Period period19 = period8.withField(durationFieldType17, (int) (short) 0);
        org.joda.time.Period period21 = period8.withWeeks((-1));
        org.joda.time.Period period23 = period21.withYears(52);
        int[] intArray25 = iSOChronology7.get((org.joda.time.ReadablePeriod) period23, (long) (byte) 1);
        try {
            iSOChronology0.validate(readablePartial6, intArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[UTC]" + "'", str5.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(intArray25);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        long long10 = durationField7.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period15 = period14.toPeriod();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) '4', chronology18);
        org.joda.time.Period period21 = period19.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType24 = periodType22.getFieldType((int) (short) 0);
        boolean boolean25 = period14.isSupported(durationFieldType24);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType24, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField29 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType24, (int) (short) 100);
        long long31 = scaledDurationField29.getValueAsLong((long) 68);
        long long33 = scaledDurationField29.getMillis(52);
        long long36 = scaledDurationField29.getDifferenceAsLong((-84L), (-34919990L));
        long long39 = scaledDurationField29.getValueAsLong((long) 10, 0L);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 449280000000L + "'", long33 == 449280000000L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone1.getID();
//        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
//        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
//        java.lang.String str5 = lenientChronology4.toString();
//        org.joda.time.DateTimeField dateTimeField6 = lenientChronology4.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str8 = dateTimeZone7.getID();
//        java.lang.String str9 = dateTimeZone7.getID();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone7.getName((long) 0, locale11);
//        int int14 = dateTimeZone7.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime15 = null;
//        boolean boolean16 = dateTimeZone7.isLocalDateTimeGap(localDateTime15);
//        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) lenientChronology4, dateTimeZone7);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
//        org.junit.Assert.assertNotNull(zonedChronology3);
//        org.junit.Assert.assertNotNull(lenientChronology4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str5.equals("LenientChronology[ISOChronology[UTC]]"));
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Coordinated Universal Time" + "'", str12.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(zonedChronology17);
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        try {
            long long10 = iSOChronology0.getDateTimeMillis(68, (-1), 1, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period6 = period4.withYears((int) (short) 10);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period4.toDurationFrom(readableInstant7);
        org.joda.time.Period period10 = org.joda.time.Period.months(100);
        int int11 = period10.getMonths();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        org.joda.time.Period period18 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.Period period19 = new org.joda.time.Period((long) (byte) 1, periodType13, (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.PeriodType periodType20 = periodType13.withYearsRemoved();
        boolean boolean21 = period10.equals((java.lang.Object) periodType13);
        org.joda.time.Period period22 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration8, periodType13);
        java.lang.String str23 = periodType13.toString();
        org.joda.time.PeriodType periodType24 = periodType13.withDaysRemoved();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "PeriodType[Weeks]" + "'", str23.equals("PeriodType[Weeks]"));
        org.junit.Assert.assertNotNull(periodType24);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) '4', chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        int int7 = period5.getMillis();
        org.joda.time.Period period9 = period5.minusYears((int) ' ');
        int[] intArray11 = iSOChronology0.get((org.joda.time.ReadablePeriod) period9, (long) (short) 0);
        org.joda.time.Period period12 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval14);
        org.joda.time.Period period16 = new org.joda.time.Period((long) '4', chronology15);
        org.joda.time.Period period18 = period16.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType19 = period18.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType((int) (short) 0);
        org.joda.time.Period period23 = period12.withField(durationFieldType21, (int) (short) 0);
        org.joda.time.Period period25 = period12.withWeeks((-1));
        org.joda.time.Period period26 = period9.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.ReadableInterval readableInterval28 = null;
        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval28);
        org.joda.time.Period period30 = new org.joda.time.Period((long) '4', chronology29);
        org.joda.time.Period period31 = period30.toPeriod();
        org.joda.time.ReadableInterval readableInterval33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval33);
        org.joda.time.Period period35 = new org.joda.time.Period((long) '4', chronology34);
        org.joda.time.Period period37 = period35.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType38 = period37.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType40 = periodType38.getFieldType((int) (short) 0);
        boolean boolean41 = period30.isSupported(durationFieldType40);
        int int42 = period26.get(durationFieldType40);
        org.joda.time.Period period44 = period26.withHours((int) (short) 10);
        org.joda.time.Period period46 = period44.minusDays(8);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-32) + "'", int42 == (-32));
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertNotNull(period46);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.DurationFieldType durationFieldType1 = null;
        boolean boolean2 = periodType0.isSupported(durationFieldType1);
        boolean boolean4 = periodType0.equals((java.lang.Object) 100);
        org.joda.time.Period period9 = new org.joda.time.Period((-1), 70, (int) (short) 100, (int) (byte) 1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType12 = periodType10.getFieldType((int) (short) 0);
        org.joda.time.ReadableInterval readableInterval14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval14);
        org.joda.time.Period period16 = new org.joda.time.Period((long) '4', chronology15);
        org.joda.time.Period period18 = period16.plusMillis(1);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType((int) (short) 0);
        int int22 = period16.indexOf(durationFieldType21);
        boolean boolean23 = periodType10.isSupported(durationFieldType21);
        int int24 = period9.indexOf(durationFieldType21);
        boolean boolean25 = periodType0.isSupported(durationFieldType21);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType6 = period5.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField10 = new org.joda.time.field.PreciseDurationField(durationFieldType8, (long) (byte) 100);
        long long13 = preciseDurationField10.getMillis(0L, 10L);
        long long16 = preciseDurationField10.getMillis((long) 100, (long) (short) 0);
        long long19 = preciseDurationField10.getValueAsLong(97L, (long) 0);
        long long22 = preciseDurationField10.add((-46934L), 0L);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10000L + "'", long16 == 10000L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-46934L) + "'", long22 == (-46934L));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Period period5 = period4.normalizedStandard();
        org.joda.time.Period period7 = period4.withYears(10);
        org.joda.time.Period period9 = period4.plusHours(0);
        org.joda.time.Seconds seconds10 = period4.toStandardSeconds();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(seconds10);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (-99999L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-219506673600000L) + "'", long1 == (-219506673600000L));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str1 = dateTimeZone0.getID();
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        int int4 = dateTimeZone0.getOffsetFromLocal(100L);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone0.getOffset(readableInstant5);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTC" + "'", str1.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Period period5 = period4.normalizedStandard();
        org.joda.time.Period period6 = new org.joda.time.Period((java.lang.Object) period5);
        org.joda.time.Period period8 = period5.plusMillis((int) 'a');
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        long long10 = durationField7.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period15 = period14.toPeriod();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) '4', chronology18);
        org.joda.time.Period period21 = period19.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType24 = periodType22.getFieldType((int) (short) 0);
        boolean boolean25 = period14.isSupported(durationFieldType24);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType24, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField29 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType24, (int) (short) 100);
        long long31 = scaledDurationField29.getValueAsLong((long) 68);
        int int34 = scaledDurationField29.getValue((-210866846400000L), (long) (byte) 100);
        long long37 = scaledDurationField29.add((-2L), 0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-24405) + "'", int34 == (-24405));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-2L) + "'", long37 == (-2L));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.yearOfEra();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.halfdayOfDay();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) '4', chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        int int7 = period5.getMillis();
        org.joda.time.Period period9 = period5.minusYears((int) ' ');
        int[] intArray11 = iSOChronology0.get((org.joda.time.ReadablePeriod) period9, (long) (short) 0);
        org.joda.time.Period period13 = period9.minusHours(0);
        try {
            org.joda.time.Weeks weeks14 = period13.toStandardWeeks();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Weeks as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.Period period4 = period2.minusMinutes(52);
        org.joda.time.DurationFieldType[] durationFieldTypeArray5 = period4.getFieldTypes();
        int int6 = period4.getSeconds();
        org.joda.time.Weeks weeks7 = period4.toStandardWeeks();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(durationFieldTypeArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(weeks7);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        long long10 = durationField7.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period15 = period14.toPeriod();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) '4', chronology18);
        org.joda.time.Period period21 = period19.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType24 = periodType22.getFieldType((int) (short) 0);
        boolean boolean25 = period14.isSupported(durationFieldType24);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType24, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField29 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType24, (int) (short) 100);
        long long31 = scaledDurationField29.getValueAsLong((long) 68);
        long long33 = scaledDurationField29.getMillis(52);
        int int35 = scaledDurationField29.getValue((long) (short) 0);
        int int37 = scaledDurationField29.getValue((-210865896000000L));
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 449280000000L + "'", long33 == 449280000000L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-24405) + "'", int37 == (-24405));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "DayTime");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        java.lang.String str11 = unsupportedDurationField10.getName();
        org.joda.time.ReadableInterval readableInterval13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) '4', chronology14);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.ReadableInterval readableInterval18 = null;
        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval18);
        org.joda.time.Period period20 = new org.joda.time.Period((long) '4', chronology19);
        org.joda.time.Period period22 = period20.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType23 = period22.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType25 = periodType23.getFieldType((int) (short) 0);
        boolean boolean26 = period15.isSupported(durationFieldType25);
        org.joda.time.field.PreciseDurationField preciseDurationField28 = new org.joda.time.field.PreciseDurationField(durationFieldType25, (long) '4');
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.Period period31 = new org.joda.time.Period(readableInstant29, readableInstant30);
        org.joda.time.Period period33 = period31.minusMinutes(52);
        org.joda.time.DurationFieldType[] durationFieldTypeArray34 = period33.getFieldTypes();
        boolean boolean35 = preciseDurationField28.equals((java.lang.Object) durationFieldTypeArray34);
        long long38 = preciseDurationField28.subtract((long) 68, 68);
        int int39 = unsupportedDurationField10.compareTo((org.joda.time.DurationField) preciseDurationField28);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "days" + "'", str11.equals("days"));
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(durationFieldTypeArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-3468L) + "'", long38 == (-3468L));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("PT-0.065S", (int) (byte) 100, (int) '4', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for PT-0.065S must be in the range [52,10]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Period period5 = period4.normalizedStandard();
        int int6 = period4.getDays();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        boolean boolean11 = unsupportedDurationField10.isSupported();
        try {
            long long14 = unsupportedDurationField10.getDifferenceAsLong((-1L), (-2L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: days field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(0);
        org.joda.time.Period period3 = period1.withMinutes(8);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.Period period9 = new org.joda.time.Period((long) '4', chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getMillis();
        org.joda.time.Period period13 = period9.minusYears((int) ' ');
        int[] intArray15 = iSOChronology4.get((org.joda.time.ReadablePeriod) period13, (long) (short) 0);
        org.joda.time.Period period16 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval18 = null;
        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval18);
        org.joda.time.Period period20 = new org.joda.time.Period((long) '4', chronology19);
        org.joda.time.Period period22 = period20.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType23 = period22.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType25 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period27 = period16.withField(durationFieldType25, (int) (short) 0);
        org.joda.time.Period period29 = period16.withWeeks((-1));
        org.joda.time.Period period30 = period13.minus((org.joda.time.ReadablePeriod) period16);
        org.joda.time.Period period32 = period13.minusMillis((int) (byte) 1);
        org.joda.time.Period period33 = period32.normalizedStandard();
        org.joda.time.Period period34 = period3.withFields((org.joda.time.ReadablePeriod) period33);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 52 + "'", int11 == 52);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(period34);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "years", "days");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("DurationField[years]");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"DurationField[years]/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.Period period7 = period5.plusSeconds((int) (byte) -1);
        int int8 = period5.getHours();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (short) 100, (int) (byte) 100, (int) (short) 10, 4);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        boolean boolean11 = unsupportedDurationField10.isSupported();
        org.joda.time.DurationFieldType durationFieldType12 = unsupportedDurationField10.getType();
        boolean boolean13 = unsupportedDurationField10.isSupported();
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.clockhourOfDay();
        org.joda.time.Period period20 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology18);
        org.joda.time.Period period21 = new org.joda.time.Period((long) (byte) 1, periodType15, (org.joda.time.Chronology) iSOChronology18);
        org.joda.time.DurationField durationField22 = iSOChronology18.halfdays();
        int int23 = unsupportedDurationField10.compareTo(durationField22);
        try {
            long long25 = unsupportedDurationField10.getValueAsLong((-349199900L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: days field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 100, periodType4, chronology6);
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) 100);
        org.joda.time.IllegalInstantException illegalInstantException10 = new org.joda.time.IllegalInstantException("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        boolean boolean11 = gregorianChronology0.equals((java.lang.Object) illegalInstantException10);
        org.joda.time.Chronology chronology12 = gregorianChronology0.withUTC();
        try {
            long long17 = gregorianChronology0.getDateTimeMillis((int) (short) 10, 0, 3, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType2 = periodType1.withSecondsRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.clockhourOfDay();
        boolean boolean6 = iSOChronology3.equals((java.lang.Object) (-1.0f));
        org.joda.time.DateTimeZone dateTimeZone7 = iSOChronology3.getZone();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (byte) -1, periodType2, (org.joda.time.Chronology) iSOChronology3);
        try {
            org.joda.time.Period period10 = period8.withSeconds((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "Weeks", "Weeks");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "Weeks", "org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getName(locale9, "1", "PT0S");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period6 = period4.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType7 = period6.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (short) 0);
        org.joda.time.Period period11 = period0.withField(durationFieldType9, (int) (short) 0);
        org.joda.time.Period period13 = period0.withWeeks((-1));
        org.joda.time.Period period15 = period13.withYears(52);
        org.joda.time.MutablePeriod mutablePeriod16 = period13.toMutablePeriod();
        int int17 = period13.getSeconds();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(mutablePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str6 = dateTimeZone5.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone8 = zonedChronology7.getZone();
        java.lang.String str9 = zonedChronology7.toString();
        org.joda.time.Period period10 = new org.joda.time.Period((long) 3, periodType3, (org.joda.time.Chronology) zonedChronology7);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period16 = period14.plusMillis(1);
        java.lang.String str17 = period14.toString();
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.clockhourOfDay();
        boolean boolean21 = iSOChronology18.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period22 = new org.joda.time.Period((java.lang.Object) period14, (org.joda.time.Chronology) iSOChronology18);
        int[] intArray24 = zonedChronology7.get((org.joda.time.ReadablePeriod) period22, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology25 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.Period period26 = new org.joda.time.Period((long) 'a', (long) 0, (org.joda.time.Chronology) lenientChronology25);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        long long30 = lenientChronology25.add(readablePeriod27, 10000L, (-100));
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str9.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PT0.052S" + "'", str17.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(lenientChronology25);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10000L + "'", long30 == 10000L);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 1, (int) (short) -1, 0, (int) (short) -1);
        org.joda.time.Period period6 = period4.withHours(0);
        java.lang.String str7 = period6.toString();
        org.joda.time.Period period9 = period6.plusHours((-100));
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PT-1M-0.001S" + "'", str7.equals("PT-1M-0.001S"));
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        boolean boolean11 = unsupportedDurationField10.isSupported();
        java.lang.String str12 = unsupportedDurationField10.toString();
        try {
            long long14 = unsupportedDurationField10.getMillis((long) 68);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: days field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDurationField[days]" + "'", str12.equals("UnsupportedDurationField[days]"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType6 = period5.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField10 = new org.joda.time.field.PreciseDurationField(durationFieldType8, (long) (byte) 100);
        java.lang.String str11 = preciseDurationField10.getName();
        org.joda.time.Period period12 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval14);
        org.joda.time.Period period16 = new org.joda.time.Period((long) '4', chronology15);
        org.joda.time.Period period18 = period16.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType19 = period18.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType((int) (short) 0);
        org.joda.time.Period period23 = period12.withField(durationFieldType21, (int) (short) 0);
        org.joda.time.Period period25 = period12.withWeeks((-1));
        org.joda.time.ReadableInterval readableInterval27 = null;
        org.joda.time.Chronology chronology28 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval27);
        org.joda.time.Period period29 = new org.joda.time.Period((long) '4', chronology28);
        org.joda.time.Period period31 = period29.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType32 = period31.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType34 = periodType32.getFieldType((int) (short) 0);
        org.joda.time.Period period36 = period25.withField(durationFieldType34, (int) (short) -1);
        boolean boolean37 = preciseDurationField10.equals((java.lang.Object) period25);
        try {
            org.joda.time.DurationFieldType durationFieldType39 = period25.getFieldType((-2));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "years" + "'", str11.equals("years"));
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.dayTime();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str6 = dateTimeZone5.getID();
//        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone8 = zonedChronology7.getZone();
//        java.lang.String str9 = zonedChronology7.toString();
//        org.joda.time.Period period10 = new org.joda.time.Period((long) 3, periodType3, (org.joda.time.Chronology) zonedChronology7);
//        org.joda.time.ReadableInterval readableInterval12 = null;
//        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
//        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
//        org.joda.time.Period period16 = period14.plusMillis(1);
//        java.lang.String str17 = period14.toString();
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.clockhourOfDay();
//        boolean boolean21 = iSOChronology18.equals((java.lang.Object) (-1.0f));
//        org.joda.time.Period period22 = new org.joda.time.Period((java.lang.Object) period14, (org.joda.time.Chronology) iSOChronology18);
//        int[] intArray24 = zonedChronology7.get((org.joda.time.ReadablePeriod) period22, (-1L));
//        org.joda.time.chrono.LenientChronology lenientChronology25 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology7);
//        org.joda.time.Period period26 = new org.joda.time.Period((long) 'a', (long) 0, (org.joda.time.Chronology) lenientChronology25);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str28 = dateTimeZone27.getID();
//        java.lang.String str29 = dateTimeZone27.getID();
//        java.util.TimeZone timeZone30 = dateTimeZone27.toTimeZone();
//        java.lang.String str32 = dateTimeZone27.getName((long) 3);
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
//        long long36 = dateTimeZone27.getMillisKeepLocal(dateTimeZone34, (long) (byte) 100);
//        org.joda.time.Chronology chronology37 = lenientChronology25.withZone(dateTimeZone27);
//        org.joda.time.DateTimeField dateTimeField38 = lenientChronology25.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField39 = lenientChronology25.weekyear();
//        org.junit.Assert.assertNotNull(periodType3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//        org.junit.Assert.assertNotNull(zonedChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str9.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PT0.052S" + "'", str17.equals("PT0.052S"));
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(intArray24);
//        org.junit.Assert.assertNotNull(lenientChronology25);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UTC" + "'", str29.equals("UTC"));
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Coordinated Universal Time" + "'", str32.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-349199900L) + "'", long36 == (-349199900L));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.withYears((int) (short) 10);
        org.joda.time.Period period6 = period3.normalizedStandard();
        org.joda.time.Period period8 = period6.multipliedBy(4);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', chronology7);
        org.joda.time.Period period10 = period8.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType((int) (short) 0);
        boolean boolean14 = period3.isSupported(durationFieldType13);
        org.joda.time.field.PreciseDurationField preciseDurationField16 = new org.joda.time.field.PreciseDurationField(durationFieldType13, (long) '4');
        org.joda.time.Period period17 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval19 = null;
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval19);
        org.joda.time.Period period21 = new org.joda.time.Period((long) '4', chronology20);
        org.joda.time.Period period23 = period21.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType24 = period23.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType26 = periodType24.getFieldType((int) (short) 0);
        org.joda.time.Period period28 = period17.withField(durationFieldType26, (int) (short) 0);
        org.joda.time.Period period30 = period17.withWeeks((-1));
        org.joda.time.ReadableInterval readableInterval32 = null;
        org.joda.time.Chronology chronology33 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) '4', chronology33);
        org.joda.time.Period period36 = period34.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType37 = period36.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType39 = periodType37.getFieldType((int) (short) 0);
        org.joda.time.Period period41 = period30.withField(durationFieldType39, (int) (short) -1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(durationFieldType39, "Weeks");
        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) preciseDurationField16, durationFieldType39);
        long long47 = decoratedDurationField44.add((long) 100, (int) (byte) 100);
        boolean boolean48 = decoratedDurationField44.isPrecise();
        int int51 = decoratedDurationField44.getValue((long) (short) 100, 0L);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(durationFieldType39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 5300L + "'", long47 == 5300L);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "DayTime", 0, 10);
        java.lang.String str6 = fixedDateTimeZone4.getShortName(32314377595232L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00" + "'", str6.equals("+00:00"));
    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test408");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        long long3 = dateTimeZone0.adjustOffset((long) 'a', false);
//        java.lang.String str5 = dateTimeZone0.getName(10000L);
//        org.joda.time.LocalDateTime localDateTime6 = null;
//        boolean boolean7 = dateTimeZone0.isLocalDateTimeGap(localDateTime6);
//        java.lang.String str8 = dateTimeZone0.getID();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
//    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "DayTime", 0, 10);
        int int6 = fixedDateTimeZone4.getStandardOffset((-210865896000000L));
        long long8 = fixedDateTimeZone4.nextTransition((long) ' ');
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-3491999), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = zonedChronology3.getZone();
        boolean boolean6 = dateTimeZone4.isStandardOffset(1000L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 100, periodType4, chronology6);
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) 100);
        org.joda.time.IllegalInstantException illegalInstantException10 = new org.joda.time.IllegalInstantException("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        boolean boolean11 = gregorianChronology0.equals((java.lang.Object) illegalInstantException10);
        org.joda.time.Chronology chronology12 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str14 = dateTimeZone13.getID();
        java.lang.String str15 = dateTimeZone13.getID();
        org.joda.time.Chronology chronology16 = gregorianChronology0.withZone(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str18 = dateTimeZone17.getID();
        org.joda.time.Chronology chronology19 = gregorianChronology0.withZone(dateTimeZone17);
        java.lang.String str20 = dateTimeZone17.toString();
        java.util.TimeZone timeZone21 = dateTimeZone17.toTimeZone();
        try {
            org.joda.time.Period period22 = new org.joda.time.Period((java.lang.Object) dateTimeZone17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.tz.FixedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "UTC" + "'", str18.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
        org.junit.Assert.assertNotNull(timeZone21);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType6 = period5.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField10 = new org.joda.time.field.PreciseDurationField(durationFieldType8, (long) (byte) 100);
        java.lang.String str11 = preciseDurationField10.getName();
        long long12 = preciseDurationField10.getUnitMillis();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType14 = periodType13.withWeeksRemoved();
        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
        org.joda.time.PeriodType periodType16 = periodType15.withSecondsRemoved();
        boolean boolean17 = preciseDurationField10.equals((java.lang.Object) periodType15);
        long long20 = preciseDurationField10.add((long) 70, (int) 'a');
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "years" + "'", str11.equals("years"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9770L + "'", long20 == 9770L);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        long long27 = zonedChronology5.add(1000L, 1560628908182L, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField28 = zonedChronology5.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.PeriodType periodType31 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType32 = periodType31.withWeeksRemoved();
        org.joda.time.PeriodType periodType33 = org.joda.time.DateTimeUtils.getPeriodType(periodType31);
        org.joda.time.ReadableInterval readableInterval34 = null;
        org.joda.time.Chronology chronology35 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval34);
        org.joda.time.Period period36 = new org.joda.time.Period((long) 100, periodType33, chronology35);
        boolean boolean37 = gregorianChronology29.equals((java.lang.Object) 100);
        org.joda.time.IllegalInstantException illegalInstantException39 = new org.joda.time.IllegalInstantException("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        boolean boolean40 = gregorianChronology29.equals((java.lang.Object) illegalInstantException39);
        org.joda.time.Chronology chronology41 = gregorianChronology29.withUTC();
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str43 = dateTimeZone42.getID();
        java.lang.String str44 = dateTimeZone42.getID();
        org.joda.time.Chronology chronology45 = gregorianChronology29.withZone(dateTimeZone42);
        org.joda.time.Chronology chronology46 = zonedChronology5.withZone(dateTimeZone42);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560628909182L + "'", long27 == 1560628909182L);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "UTC" + "'", str43.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "UTC" + "'", str44.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology45);
        org.junit.Assert.assertNotNull(chronology46);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', chronology7);
        org.joda.time.Period period10 = period8.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType((int) (short) 0);
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant3, readableDuration4, periodType11);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 10, periodType11);
        org.joda.time.Period period16 = new org.joda.time.Period(2440587L, 0L, periodType11);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.Period period1 = org.joda.time.Period.parse("PT0.052S");
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', chronology7);
        org.joda.time.Period period10 = period8.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType((int) (short) 0);
        boolean boolean14 = period3.isSupported(durationFieldType13);
        org.joda.time.field.PreciseDurationField preciseDurationField16 = new org.joda.time.field.PreciseDurationField(durationFieldType13, (long) '4');
        org.joda.time.Period period17 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval19 = null;
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval19);
        org.joda.time.Period period21 = new org.joda.time.Period((long) '4', chronology20);
        org.joda.time.Period period23 = period21.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType24 = period23.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType26 = periodType24.getFieldType((int) (short) 0);
        org.joda.time.Period period28 = period17.withField(durationFieldType26, (int) (short) 0);
        org.joda.time.Period period30 = period17.withWeeks((-1));
        org.joda.time.ReadableInterval readableInterval32 = null;
        org.joda.time.Chronology chronology33 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) '4', chronology33);
        org.joda.time.Period period36 = period34.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType37 = period36.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType39 = periodType37.getFieldType((int) (short) 0);
        org.joda.time.Period period41 = period30.withField(durationFieldType39, (int) (short) -1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(durationFieldType39, "Weeks");
        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) preciseDurationField16, durationFieldType39);
        boolean boolean45 = preciseDurationField16.isSupported();
        boolean boolean47 = preciseDurationField16.equals((java.lang.Object) 1.0d);
        org.joda.time.ReadableInterval readableInterval49 = null;
        org.joda.time.Chronology chronology50 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval49);
        org.joda.time.Period period51 = new org.joda.time.Period((long) '4', chronology50);
        org.joda.time.Period period53 = period51.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType54 = period53.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType56 = periodType54.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField58 = new org.joda.time.field.PreciseDurationField(durationFieldType56, (long) (byte) 100);
        long long61 = preciseDurationField58.getMillis(0L, 10L);
        int int62 = preciseDurationField16.compareTo((org.joda.time.DurationField) preciseDurationField58);
        long long64 = preciseDurationField16.getMillis(68);
        boolean boolean66 = preciseDurationField16.equals((java.lang.Object) (-3174845943151792L));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(durationFieldType39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(chronology50);
        org.junit.Assert.assertNotNull(period53);
        org.junit.Assert.assertNotNull(periodType54);
        org.junit.Assert.assertNotNull(durationFieldType56);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 3536L + "'", long64 == 3536L);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) ' ');
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 8, 32314377595232L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 258515020761856L + "'", long2 == 258515020761856L);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 100, periodType4, chronology6);
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) 100);
        org.joda.time.IllegalInstantException illegalInstantException10 = new org.joda.time.IllegalInstantException("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        boolean boolean11 = gregorianChronology0.equals((java.lang.Object) illegalInstantException10);
        org.joda.time.Chronology chronology12 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str14 = dateTimeZone13.getID();
        java.lang.String str15 = dateTimeZone13.getID();
        org.joda.time.Chronology chronology16 = gregorianChronology0.withZone(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str18 = dateTimeZone17.getID();
        org.joda.time.Chronology chronology19 = gregorianChronology0.withZone(dateTimeZone17);
        org.joda.time.DurationField durationField20 = gregorianChronology0.years();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "UTC" + "'", str18.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(durationField20);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = zonedChronology3.getZone();
        java.lang.String str5 = zonedChronology3.toString();
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology3);
        org.joda.time.ReadableInterval readableInterval8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval8);
        org.joda.time.Period period10 = new org.joda.time.Period((long) '4', chronology9);
        org.joda.time.Period period12 = period10.plusMillis(1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray13 = period12.getFieldTypes();
        boolean boolean14 = zonedChronology3.equals((java.lang.Object) durationFieldTypeArray13);
        org.joda.time.ReadablePartial readablePartial15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.clockhourOfDay();
        org.joda.time.Period period20 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology18);
        org.joda.time.ReadableInterval readableInterval22 = null;
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval22);
        org.joda.time.Period period24 = new org.joda.time.Period((long) '4', chronology23);
        org.joda.time.Period period26 = period24.withYears((int) (short) 10);
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.Duration duration28 = period24.toDurationFrom(readableInstant27);
        org.joda.time.Period period29 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval31 = null;
        org.joda.time.Chronology chronology32 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval31);
        org.joda.time.Period period33 = new org.joda.time.Period((long) '4', chronology32);
        org.joda.time.Period period35 = period33.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType36 = period35.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType38 = periodType36.getFieldType((int) (short) 0);
        org.joda.time.Period period40 = period29.withField(durationFieldType38, (int) (short) 0);
        org.joda.time.Period period42 = period29.withWeeks((-1));
        org.joda.time.ReadableInterval readableInterval44 = null;
        org.joda.time.Chronology chronology45 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval44);
        org.joda.time.Period period46 = new org.joda.time.Period((long) '4', chronology45);
        org.joda.time.Period period48 = period46.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType49 = period48.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType51 = periodType49.getFieldType((int) (short) 0);
        org.joda.time.Period period53 = period42.withField(durationFieldType51, (int) (short) -1);
        org.joda.time.Period period55 = period24.withField(durationFieldType51, 0);
        int[] intArray57 = iSOChronology18.get((org.joda.time.ReadablePeriod) period55, (long) (short) 1);
        try {
            zonedChronology3.validate(readablePartial15, intArray57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldTypeArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(duration28);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertNotNull(durationFieldType38);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(chronology45);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertNotNull(periodType49);
        org.junit.Assert.assertNotNull(durationFieldType51);
        org.junit.Assert.assertNotNull(period53);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertNotNull(intArray57);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        boolean boolean11 = unsupportedDurationField10.isSupported();
        org.joda.time.DurationFieldType durationFieldType12 = unsupportedDurationField10.getType();
        boolean boolean13 = unsupportedDurationField10.isSupported();
        try {
            long long16 = unsupportedDurationField10.getDifferenceAsLong((-61851686400000L), (long) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: days field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) '4', chronology4);
        org.joda.time.Period period7 = period5.withYears((int) (short) 10);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Duration duration9 = period5.toDurationFrom(readableInstant8);
        org.joda.time.Period period11 = org.joda.time.Period.months(100);
        int int12 = period11.getMonths();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.clockhourOfDay();
        org.joda.time.Period period19 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology17);
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) 1, periodType14, (org.joda.time.Chronology) iSOChronology17);
        org.joda.time.PeriodType periodType21 = periodType14.withYearsRemoved();
        boolean boolean22 = period11.equals((java.lang.Object) periodType14);
        org.joda.time.Period period23 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration9, periodType14);
        org.joda.time.PeriodType periodType24 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType25 = periodType24.withWeeksRemoved();
        org.joda.time.PeriodType periodType26 = periodType25.withMillisRemoved();
        org.joda.time.Period period27 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration9, periodType26);
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.PeriodType periodType29 = org.joda.time.PeriodType.standard();
        int int30 = periodType29.size();
        org.joda.time.Period period31 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration9, readableInstant28, periodType29);
        int int32 = period31.getWeeks();
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 8 + "'", int30 == 8);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) '4', chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        int int7 = period5.getMillis();
        org.joda.time.Period period9 = period5.minusYears((int) ' ');
        int[] intArray11 = iSOChronology0.get((org.joda.time.ReadablePeriod) period9, (long) (short) 0);
        org.joda.time.Period period12 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval14);
        org.joda.time.Period period16 = new org.joda.time.Period((long) '4', chronology15);
        org.joda.time.Period period18 = period16.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType19 = period18.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType((int) (short) 0);
        org.joda.time.Period period23 = period12.withField(durationFieldType21, (int) (short) 0);
        org.joda.time.Period period25 = period12.withWeeks((-1));
        org.joda.time.Period period26 = period9.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.ReadableInterval readableInterval28 = null;
        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval28);
        org.joda.time.Period period30 = new org.joda.time.Period((long) '4', chronology29);
        org.joda.time.Period period31 = period30.toPeriod();
        org.joda.time.ReadableInterval readableInterval33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval33);
        org.joda.time.Period period35 = new org.joda.time.Period((long) '4', chronology34);
        org.joda.time.Period period37 = period35.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType38 = period37.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType40 = periodType38.getFieldType((int) (short) 0);
        boolean boolean41 = period30.isSupported(durationFieldType40);
        int int42 = period26.get(durationFieldType40);
        org.joda.time.Period period44 = period26.withHours((int) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.PeriodType periodType47 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType48 = periodType47.withWeeksRemoved();
        org.joda.time.PeriodType periodType49 = org.joda.time.DateTimeUtils.getPeriodType(periodType47);
        org.joda.time.ReadableInterval readableInterval50 = null;
        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval50);
        org.joda.time.Period period52 = new org.joda.time.Period((long) 100, periodType49, chronology51);
        boolean boolean53 = gregorianChronology45.equals((java.lang.Object) 100);
        org.joda.time.IllegalInstantException illegalInstantException55 = new org.joda.time.IllegalInstantException("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        boolean boolean56 = gregorianChronology45.equals((java.lang.Object) illegalInstantException55);
        org.joda.time.Chronology chronology57 = gregorianChronology45.withUTC();
        org.joda.time.Period period58 = new org.joda.time.Period((java.lang.Object) period44, chronology57);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-32) + "'", int42 == (-32));
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(periodType47);
        org.junit.Assert.assertNotNull(periodType48);
        org.junit.Assert.assertNotNull(periodType49);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(chronology57);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        boolean boolean11 = unsupportedDurationField10.isSupported();
        org.joda.time.DurationFieldType durationFieldType12 = unsupportedDurationField10.getType();
        boolean boolean13 = unsupportedDurationField10.isSupported();
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.clockhourOfDay();
        org.joda.time.Period period20 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology18);
        org.joda.time.Period period21 = new org.joda.time.Period((long) (byte) 1, periodType15, (org.joda.time.Chronology) iSOChronology18);
        org.joda.time.DurationField durationField22 = iSOChronology18.halfdays();
        int int23 = unsupportedDurationField10.compareTo(durationField22);
        try {
            long long25 = unsupportedDurationField10.getMillis(0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: days field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.PeriodType periodType5 = periodType2.withDaysRemoved();
        org.joda.time.PeriodType periodType6 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(0L, 156062890818200L, periodType6, chronology7);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        try {
            long long13 = unsupportedDurationField10.getMillis((long) 70, (long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: days field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str26 = dateTimeZone25.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology27 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology24, dateTimeZone25);
        java.lang.String str28 = dateTimeZone25.getID();
        java.lang.String str29 = dateTimeZone25.toString();
        long long32 = dateTimeZone25.convertLocalToUTC((long) '4', false);
        org.joda.time.Chronology chronology33 = zonedChronology5.withZone(dateTimeZone25);
        org.joda.time.LocalDateTime localDateTime34 = null;
        boolean boolean35 = dateTimeZone25.isLocalDateTimeGap(localDateTime34);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UTC" + "'", str26.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UTC" + "'", str29.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 52L + "'", long32 == 52L);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.clockhourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 1, (java.lang.Number) 100, (java.lang.Number) 10.0d);
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        java.lang.String str6 = illegalFieldValueException4.getFieldName();
        org.joda.time.IllegalInstantException illegalInstantException9 = new org.joda.time.IllegalInstantException(2440588L, "org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalInstantException9);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 1, (java.lang.Number) 100, (java.lang.Number) 10.0d);
        java.lang.String str16 = illegalFieldValueException15.getIllegalStringValue();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException15);
        java.lang.Throwable[] throwableArray18 = illegalFieldValueException15.getSuppressed();
        java.lang.Number number19 = illegalFieldValueException15.getUpperBound();
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 10.0d + "'", number19.equals(10.0d));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "DayTime", 0, 10);
        int int6 = fixedDateTimeZone4.getStandardOffset((-210865896000000L));
        int int8 = fixedDateTimeZone4.getStandardOffset(156062890818200L);
        long long10 = fixedDateTimeZone4.nextTransition((-99999L));
        int int12 = fixedDateTimeZone4.getOffsetFromLocal(449280000000L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-99999L) + "'", long10 == (-99999L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(70, 349200000, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.weekyear();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 100, periodType4, chronology6);
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) 100);
        org.joda.time.IllegalInstantException illegalInstantException10 = new org.joda.time.IllegalInstantException("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        boolean boolean11 = gregorianChronology0.equals((java.lang.Object) illegalInstantException10);
        org.joda.time.Chronology chronology12 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str14 = dateTimeZone13.getID();
        java.lang.String str15 = dateTimeZone13.getID();
        org.joda.time.Chronology chronology16 = gregorianChronology0.withZone(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str18 = dateTimeZone17.getID();
        org.joda.time.Chronology chronology19 = gregorianChronology0.withZone(dateTimeZone17);
        long long21 = dateTimeZone17.convertUTCToLocal((-58987094399903L));
        org.joda.time.DateTimeZone.setDefault(dateTimeZone17);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "UTC" + "'", str18.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-58987094399903L) + "'", long21 == (-58987094399903L));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        long long10 = durationField7.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period15 = period14.toPeriod();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) '4', chronology18);
        org.joda.time.Period period21 = period19.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType24 = periodType22.getFieldType((int) (short) 0);
        boolean boolean25 = period14.isSupported(durationFieldType24);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType24, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField29 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType24, (int) (short) 100);
        long long31 = scaledDurationField29.getValueAsLong((long) 68);
        long long34 = scaledDurationField29.getValueAsLong(2440587L, 10800002L);
        org.joda.time.DurationFieldType durationFieldType35 = scaledDurationField29.getType();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(durationFieldType35);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', chronology7);
        org.joda.time.Period period10 = period8.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType((int) (short) 0);
        boolean boolean14 = period3.isSupported(durationFieldType13);
        org.joda.time.field.PreciseDurationField preciseDurationField16 = new org.joda.time.field.PreciseDurationField(durationFieldType13, (long) '4');
        long long19 = preciseDurationField16.add((long) (-2), (int) (byte) 0);
        long long21 = preciseDurationField16.getMillis(52);
        long long24 = preciseDurationField16.subtract((-5202L), (long) 'a');
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-2L) + "'", long19 == (-2L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2704L + "'", long21 == 2704L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-10246L) + "'", long24 == (-10246L));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) '4', chronology5);
        org.joda.time.Period period8 = period6.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType9 = period8.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType11 = periodType9.getFieldType((int) (short) 0);
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant1, readableDuration2, periodType9);
        org.joda.time.Period period13 = new org.joda.time.Period((long) 10, periodType9);
        org.joda.time.PeriodType periodType14 = periodType9.withWeeksRemoved();
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(durationFieldType11);
        org.junit.Assert.assertNotNull(periodType14);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str3 = dateTimeZone2.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone2);
        java.lang.String str5 = dateTimeZone2.getID();
        java.lang.String str6 = dateTimeZone2.toString();
        long long9 = dateTimeZone2.adjustOffset(1560628909182L, false);
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, dateTimeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560628909182L + "'", long9 == 1560628909182L);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.Period period1 = org.joda.time.Period.years((-100));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(1);
        org.joda.time.Period period3 = period1.plusHours((-100));
        org.joda.time.Period period5 = period3.minusDays((int) (byte) 10);
        int int6 = period3.getHours();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-100) + "'", int6 == (-100));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str6 = dateTimeZone5.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone8 = zonedChronology7.getZone();
        java.lang.String str9 = zonedChronology7.toString();
        org.joda.time.Period period10 = new org.joda.time.Period((long) 3, periodType3, (org.joda.time.Chronology) zonedChronology7);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period16 = period14.plusMillis(1);
        java.lang.String str17 = period14.toString();
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.clockhourOfDay();
        boolean boolean21 = iSOChronology18.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period22 = new org.joda.time.Period((java.lang.Object) period14, (org.joda.time.Chronology) iSOChronology18);
        int[] intArray24 = zonedChronology7.get((org.joda.time.ReadablePeriod) period22, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology25 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.Period period26 = new org.joda.time.Period((long) 'a', (long) 0, (org.joda.time.Chronology) lenientChronology25);
        org.joda.time.DurationField durationField27 = lenientChronology25.days();
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.clockhourOfDay();
        org.joda.time.ReadableInterval readableInterval32 = null;
        org.joda.time.Chronology chronology33 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) '4', chronology33);
        org.joda.time.Period period35 = period34.toPeriod();
        int int36 = period34.getMillis();
        org.joda.time.Period period38 = period34.minusYears((int) ' ');
        int[] intArray40 = iSOChronology29.get((org.joda.time.ReadablePeriod) period38, (long) (short) 0);
        org.joda.time.DurationField durationField41 = iSOChronology29.years();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology29.minuteOfHour();
        org.joda.time.Period period43 = new org.joda.time.Period((long) (byte) 10, (org.joda.time.Chronology) iSOChronology29);
        org.joda.time.ReadablePeriod readablePeriod44 = null;
        long long47 = iSOChronology29.add(readablePeriod44, 99916L, (-32));
        org.joda.time.DurationField durationField48 = iSOChronology29.halfdays();
        boolean boolean49 = lenientChronology25.equals((java.lang.Object) iSOChronology29);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str9.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PT0.052S" + "'", str17.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(lenientChronology25);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 52 + "'", int36 == 52);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 99916L + "'", long47 == 99916L);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(2440578L, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 1, periodType1, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DurationField durationField8 = iSOChronology4.seconds();
        org.joda.time.chrono.LenientChronology lenientChronology9 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology4);
        long long13 = lenientChronology9.add(0L, 2440578L, 100);
        java.lang.String str14 = lenientChronology9.toString();
        long long18 = lenientChronology9.add((long) ' ', (-1L), 0);
        org.joda.time.DurationField durationField19 = lenientChronology9.millis();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(lenientChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 244057800L + "'", long13 == 244057800L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str14.equals("LenientChronology[ISOChronology[UTC]]"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 32L + "'", long18 == 32L);
        org.junit.Assert.assertNotNull(durationField19);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        long long10 = durationField7.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period15 = period14.toPeriod();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) '4', chronology18);
        org.joda.time.Period period21 = period19.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType24 = periodType22.getFieldType((int) (short) 0);
        boolean boolean25 = period14.isSupported(durationFieldType24);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType24, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField29 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType24, (int) (short) 100);
        long long31 = scaledDurationField29.getValueAsLong((long) 68);
        long long33 = scaledDurationField29.getMillis(52);
        long long36 = scaledDurationField29.getDifferenceAsLong((-84L), (-34919990L));
        long long39 = scaledDurationField29.getDifferenceAsLong(5042L, 5042L);
        int int42 = scaledDurationField29.getValue(0L, (long) (-2));
        int int45 = scaledDurationField29.getValue(0L, (-99999L));
        int int48 = scaledDurationField29.getValue((long) 52, 1560628908182L);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 449280000000L + "'", long33 == 449280000000L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str6 = dateTimeZone5.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone8 = zonedChronology7.getZone();
        java.lang.String str9 = zonedChronology7.toString();
        org.joda.time.Period period10 = new org.joda.time.Period((long) 3, periodType3, (org.joda.time.Chronology) zonedChronology7);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period16 = period14.plusMillis(1);
        java.lang.String str17 = period14.toString();
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.clockhourOfDay();
        boolean boolean21 = iSOChronology18.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period22 = new org.joda.time.Period((java.lang.Object) period14, (org.joda.time.Chronology) iSOChronology18);
        int[] intArray24 = zonedChronology7.get((org.joda.time.ReadablePeriod) period22, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology25 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.Period period26 = new org.joda.time.Period((long) 'a', (long) 0, (org.joda.time.Chronology) lenientChronology25);
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.Duration duration28 = period26.toDurationFrom(readableInstant27);
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.PeriodType periodType30 = null;
        org.joda.time.Period period31 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration28, readableInstant29, periodType30);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str9.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PT0.052S" + "'", str17.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(lenientChronology25);
        org.junit.Assert.assertNotNull(duration28);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        java.lang.String str6 = period3.toString();
        org.joda.time.Period period8 = period3.plusMonths(4);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PT0.052S" + "'", str6.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) '4', chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        int int7 = period5.getMillis();
        org.joda.time.Period period9 = period5.minusYears((int) ' ');
        int[] intArray11 = iSOChronology0.get((org.joda.time.ReadablePeriod) period9, (long) (short) 0);
        org.joda.time.Period period13 = period9.minusHours(0);
        org.joda.time.Period period15 = period13.minusWeeks((-3491999));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.Period period1 = org.joda.time.Period.months((-3491999));
        org.joda.time.Period period3 = period1.minusMillis(68);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(520L);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        long long27 = zonedChronology5.add(1000L, 1560628908182L, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField28 = zonedChronology5.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField29 = zonedChronology5.secondOfMinute();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560628909182L + "'", long27 == 1560628909182L);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        long long10 = durationField7.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period15 = period14.toPeriod();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) '4', chronology18);
        org.joda.time.Period period21 = period19.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType24 = periodType22.getFieldType((int) (short) 0);
        boolean boolean25 = period14.isSupported(durationFieldType24);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType24, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField29 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType24, (int) (short) 100);
        long long31 = scaledDurationField29.getValueAsLong((long) 68);
        long long34 = scaledDurationField29.getDifferenceAsLong(220L, (long) 'a');
        long long37 = scaledDurationField29.getValueAsLong(3536L, (long) 68);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(0);
        int int2 = period1.getSeconds();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        long long10 = durationField7.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period15 = period14.toPeriod();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) '4', chronology18);
        org.joda.time.Period period21 = period19.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType24 = periodType22.getFieldType((int) (short) 0);
        boolean boolean25 = period14.isSupported(durationFieldType24);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType24, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField29 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType24, (int) (short) 100);
        long long31 = scaledDurationField29.getValueAsLong((long) 68);
        long long34 = scaledDurationField29.getValueAsLong(2440587L, 10800002L);
        long long37 = scaledDurationField29.add((-3468L), 0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-3468L) + "'", long37 == (-3468L));
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone1.getID();
//        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
//        java.lang.String str5 = dateTimeZone1.getShortName(2L);
//        boolean boolean7 = dateTimeZone1.isStandardOffset((long) (short) 10);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
//        org.junit.Assert.assertNotNull(zonedChronology3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 100, periodType4, chronology6);
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) 100);
        org.joda.time.IllegalInstantException illegalInstantException10 = new org.joda.time.IllegalInstantException("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        boolean boolean11 = gregorianChronology0.equals((java.lang.Object) illegalInstantException10);
        org.joda.time.DurationField durationField12 = gregorianChronology0.centuries();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        long long10 = durationField7.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period15 = period14.toPeriod();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) '4', chronology18);
        org.joda.time.Period period21 = period19.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType24 = periodType22.getFieldType((int) (short) 0);
        boolean boolean25 = period14.isSupported(durationFieldType24);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType24, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField29 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType24, (int) (short) 100);
        long long31 = scaledDurationField29.getValueAsLong((long) 68);
        long long33 = scaledDurationField29.getMillis(52);
        long long36 = scaledDurationField29.getDifferenceAsLong((-84L), (-34919990L));
        long long39 = scaledDurationField29.getDifferenceAsLong(5042L, 5042L);
        int int42 = scaledDurationField29.getValue(0L, (long) (-2));
        int int45 = scaledDurationField29.getValue(0L, (-99999L));
        int int47 = scaledDurationField29.getValue((long) 8);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 449280000000L + "'", long33 == 449280000000L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.weekyearOfCentury();
        boolean boolean5 = jodaTimePermission1.equals((java.lang.Object) dateTimeField4);
        jodaTimePermission1.checkGuard((java.lang.Object) "Weeks");
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType4 = periodType3.withSecondsRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.clockhourOfDay();
        boolean boolean8 = iSOChronology5.equals((java.lang.Object) (-1.0f));
        org.joda.time.DateTimeZone dateTimeZone9 = iSOChronology5.getZone();
        org.joda.time.Period period10 = new org.joda.time.Period((long) (byte) -1, periodType4, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology5.minuteOfDay();
        org.joda.time.Period period12 = new org.joda.time.Period(9770L, 2440578L, (org.joda.time.Chronology) iSOChronology5);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) '4', chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        int int7 = period5.getMillis();
        org.joda.time.Period period9 = period5.minusYears((int) ' ');
        int[] intArray11 = iSOChronology0.get((org.joda.time.ReadablePeriod) period9, (long) (short) 0);
        org.joda.time.Period period12 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval14);
        org.joda.time.Period period16 = new org.joda.time.Period((long) '4', chronology15);
        org.joda.time.Period period18 = period16.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType19 = period18.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType((int) (short) 0);
        org.joda.time.Period period23 = period12.withField(durationFieldType21, (int) (short) 0);
        org.joda.time.Period period25 = period12.withWeeks((-1));
        org.joda.time.Period period26 = period9.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.Period period28 = period9.minusMillis((int) (byte) 1);
        org.joda.time.Period period30 = period9.withDays((-100));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.Period period1 = org.joda.time.Period.months(100);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        int int4 = period3.getYears();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.Period period1 = new org.joda.time.Period((long) 3);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.Period period1 = org.joda.time.Period.days((-32));
        org.junit.Assert.assertNotNull(period1);
    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        long long3 = dateTimeZone0.adjustOffset((long) 'a', false);
//        java.lang.String str5 = dateTimeZone0.getName(10000L);
//        org.joda.time.LocalDateTime localDateTime6 = null;
//        boolean boolean7 = dateTimeZone0.isLocalDateTimeGap(localDateTime6);
//        long long9 = dateTimeZone0.convertUTCToLocal(0L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period6 = period4.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType7 = period6.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField11 = new org.joda.time.field.PreciseDurationField(durationFieldType9, (long) (byte) 100);
        long long14 = preciseDurationField11.getMillis(0L, 10L);
        long long17 = preciseDurationField11.getMillis((long) 100, (long) (short) 0);
        org.joda.time.DurationField durationField18 = null;
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField19 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, (org.joda.time.DurationField) preciseDurationField11, durationField18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10000L + "'", long17 == 10000L);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfHalfday();
        java.lang.String str3 = iSOChronology0.toString();
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        long long10 = durationField7.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period15 = period14.toPeriod();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) '4', chronology18);
        org.joda.time.Period period21 = period19.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType24 = periodType22.getFieldType((int) (short) 0);
        boolean boolean25 = period14.isSupported(durationFieldType24);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType24, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField29 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType24, (int) (short) 100);
        long long31 = scaledDurationField29.getValueAsLong((long) 68);
        long long33 = scaledDurationField29.getMillis(52);
        long long36 = scaledDurationField29.getDifferenceAsLong((-84L), (-34919990L));
        long long39 = scaledDurationField29.getValueAsLong((long) (byte) -1, (long) (-180));
        org.joda.time.PeriodType periodType40 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.DurationFieldType durationFieldType41 = null;
        boolean boolean42 = periodType40.isSupported(durationFieldType41);
        try {
            org.joda.time.Period period43 = new org.joda.time.Period((java.lang.Object) (-180), periodType40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 449280000000L + "'", long33 == 449280000000L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNotNull(periodType40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = zonedChronology3.getZone();
        java.lang.String str5 = zonedChronology3.toString();
        java.lang.Object obj6 = null;
        boolean boolean7 = zonedChronology3.equals(obj6);
        org.joda.time.DurationField durationField8 = zonedChronology3.eras();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = zonedChronology3.getZone();
        java.lang.String str5 = zonedChronology3.toString();
        org.joda.time.DateTimeField dateTimeField6 = zonedChronology3.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology3.halfdayOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str1 = dateTimeZone0.getID();
//        java.lang.String str2 = dateTimeZone0.getID();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone0.getName((long) 0, locale4);
//        java.lang.String str7 = dateTimeZone0.getName((-349199900L));
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTC" + "'", str1.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//    }

//    @Test
//    public void test476() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test476");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone1.getID();
//        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
//        java.lang.String str5 = dateTimeZone1.getShortName(2L);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
//        org.junit.Assert.assertNotNull(zonedChronology3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
//        org.junit.Assert.assertNotNull(iSOChronology6);
//    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType9 = periodType8.withWeeksRemoved();
        org.joda.time.Period period10 = new org.joda.time.Period(0, (int) (byte) 0, 0, 68, 2, 52, (int) (short) 10, 0, periodType8);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        boolean boolean12 = periodType8.isSupported(durationFieldType11);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("DayTime", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "org.joda.time.IllegalFieldValueException: Coordinated Universal Time: Value 0 for org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0] must be in the range [100,10.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 100, periodType4, chronology6);
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) 100);
        org.joda.time.IllegalInstantException illegalInstantException10 = new org.joda.time.IllegalInstantException("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        boolean boolean11 = gregorianChronology0.equals((java.lang.Object) illegalInstantException10);
        org.joda.time.Chronology chronology12 = gregorianChronology0.withUTC();
        int int13 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField14 = gregorianChronology0.months();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) ' ', 0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        int int5 = period3.getMillis();
        org.joda.time.Period period7 = period3.minusYears((int) ' ');
        org.joda.time.Period period9 = period7.plusDays((int) 'a');
        org.joda.time.Period period10 = period7.negated();
        org.joda.time.Period period12 = period10.withSeconds(10);
        org.joda.time.Period period13 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) '4', chronology16);
        org.joda.time.Period period19 = period17.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType20 = period19.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType22 = periodType20.getFieldType((int) (short) 0);
        org.joda.time.Period period24 = period13.withField(durationFieldType22, (int) (short) 0);
        org.joda.time.Period period26 = period10.withField(durationFieldType22, (int) (byte) -1);
        try {
            org.joda.time.Minutes minutes27 = period10.toStandardMinutes();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Minutes as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', chronology7);
        org.joda.time.Period period10 = period8.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType((int) (short) 0);
        boolean boolean14 = period3.isSupported(durationFieldType13);
        org.joda.time.field.PreciseDurationField preciseDurationField16 = new org.joda.time.field.PreciseDurationField(durationFieldType13, (long) '4');
        org.joda.time.ReadableInterval readableInterval18 = null;
        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval18);
        org.joda.time.Period period20 = new org.joda.time.Period((long) '4', chronology19);
        org.joda.time.Period period22 = period20.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType23 = period22.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType25 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType25, (long) (byte) 100);
        long long30 = preciseDurationField27.getMillis(0L, 10L);
        long long32 = preciseDurationField27.getMillis(1560628908182L);
        int int33 = preciseDurationField16.compareTo((org.joda.time.DurationField) preciseDurationField27);
        long long36 = preciseDurationField16.getDifferenceAsLong((long) (byte) 0, 2440587L);
        long long39 = preciseDurationField16.getMillis(0, (-46934L));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 156062890818200L + "'", long32 == 156062890818200L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-46934L) + "'", long36 == (-46934L));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 100, periodType4, chronology6);
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) 100);
        org.joda.time.IllegalInstantException illegalInstantException10 = new org.joda.time.IllegalInstantException("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        boolean boolean11 = gregorianChronology0.equals((java.lang.Object) illegalInstantException10);
        org.joda.time.Chronology chronology12 = gregorianChronology0.withUTC();
        java.lang.String str13 = gregorianChronology0.toString();
        org.joda.time.Chronology chronology14 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "GregorianChronology[UTC]" + "'", str13.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', chronology7);
        org.joda.time.Period period10 = period8.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType((int) (short) 0);
        boolean boolean14 = period3.isSupported(durationFieldType13);
        org.joda.time.field.PreciseDurationField preciseDurationField16 = new org.joda.time.field.PreciseDurationField(durationFieldType13, (long) '4');
        org.joda.time.Period period17 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval19 = null;
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval19);
        org.joda.time.Period period21 = new org.joda.time.Period((long) '4', chronology20);
        org.joda.time.Period period23 = period21.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType24 = period23.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType26 = periodType24.getFieldType((int) (short) 0);
        org.joda.time.Period period28 = period17.withField(durationFieldType26, (int) (short) 0);
        org.joda.time.Period period30 = period17.withWeeks((-1));
        org.joda.time.ReadableInterval readableInterval32 = null;
        org.joda.time.Chronology chronology33 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) '4', chronology33);
        org.joda.time.Period period36 = period34.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType37 = period36.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType39 = periodType37.getFieldType((int) (short) 0);
        org.joda.time.Period period41 = period30.withField(durationFieldType39, (int) (short) -1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(durationFieldType39, "Weeks");
        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) preciseDurationField16, durationFieldType39);
        boolean boolean45 = preciseDurationField16.isSupported();
        long long48 = preciseDurationField16.add((long) (byte) 1, (-3491999));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(durationFieldType39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-181583947L) + "'", long48 == (-181583947L));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.withYears((int) (short) 10);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period3.toDurationFrom(readableInstant6);
        org.joda.time.Period period9 = period3.withMillis((int) (byte) 10);
        org.joda.time.ReadableInterval readableInterval11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval11);
        org.joda.time.Period period13 = new org.joda.time.Period((long) '4', chronology12);
        org.joda.time.Period period15 = period13.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType16 = period15.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType18 = periodType16.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField20 = new org.joda.time.field.PreciseDurationField(durationFieldType18, (long) (byte) 100);
        long long23 = preciseDurationField20.getValueAsLong(0L, (long) 10);
        long long26 = preciseDurationField20.subtract((long) 100, (long) (short) 0);
        org.joda.time.DurationFieldType durationFieldType27 = preciseDurationField20.getType();
        boolean boolean28 = period3.isSupported(durationFieldType27);
        org.joda.time.Hours hours29 = period3.toStandardHours();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(hours29);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        boolean boolean11 = unsupportedDurationField10.isSupported();
        org.joda.time.DurationFieldType durationFieldType12 = unsupportedDurationField10.getType();
        boolean boolean13 = unsupportedDurationField10.isSupported();
        long long14 = unsupportedDurationField10.getUnitMillis();
        try {
            long long17 = unsupportedDurationField10.getValueAsLong((long) '#', (-300L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: days field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        boolean boolean11 = unsupportedDurationField10.isSupported();
        org.joda.time.DurationFieldType durationFieldType12 = unsupportedDurationField10.getType();
        boolean boolean13 = unsupportedDurationField10.isSupported();
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.clockhourOfDay();
        org.joda.time.Period period20 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology18);
        org.joda.time.Period period21 = new org.joda.time.Period((long) (byte) 1, periodType15, (org.joda.time.Chronology) iSOChronology18);
        org.joda.time.DurationField durationField22 = iSOChronology18.halfdays();
        int int23 = unsupportedDurationField10.compareTo(durationField22);
        try {
            long long26 = unsupportedDurationField10.getDifferenceAsLong((long) (short) -1, (long) 68);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: days field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str26 = dateTimeZone25.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology27 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology24, dateTimeZone25);
        java.lang.String str28 = dateTimeZone25.getID();
        java.lang.String str29 = dateTimeZone25.toString();
        long long32 = dateTimeZone25.convertLocalToUTC((long) '4', false);
        org.joda.time.Chronology chronology33 = zonedChronology5.withZone(dateTimeZone25);
        org.joda.time.ReadablePartial readablePartial34 = null;
        try {
            long long36 = zonedChronology5.set(readablePartial34, (-32L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UTC" + "'", str26.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UTC" + "'", str29.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 52L + "'", long32 == 52L);
        org.junit.Assert.assertNotNull(chronology33);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) (byte) -1, ' ', (int) (byte) 100, (int) ' ', 0, false, (-32));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder0.setStandardOffset((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((-1.0d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866846400000L) + "'", long1 == (-210866846400000L));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("ZonedChronology[ISOChronology[UTC], UTC]");
        org.joda.time.IllegalFieldValueException illegalFieldValueException6 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 1, (java.lang.Number) 100, (java.lang.Number) 10.0d);
        org.joda.time.DurationFieldType durationFieldType7 = illegalFieldValueException6.getDurationFieldType();
        java.lang.String str8 = illegalFieldValueException6.getFieldName();
        org.joda.time.IllegalInstantException illegalInstantException11 = new org.joda.time.IllegalInstantException(2440588L, "org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        illegalFieldValueException6.addSuppressed((java.lang.Throwable) illegalInstantException11);
        illegalInstantException1.addSuppressed((java.lang.Throwable) illegalInstantException11);
        java.lang.Throwable[] throwableArray14 = illegalInstantException1.getSuppressed();
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]", (java.lang.Number) (short) 0, (java.lang.Number) (short) 100, (java.lang.Number) 10.0d);
        illegalInstantException1.addSuppressed((java.lang.Throwable) illegalFieldValueException19);
        boolean boolean21 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalInstantException1);
        org.junit.Assert.assertNull(durationFieldType7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', chronology7);
        org.joda.time.Period period10 = period8.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType((int) (short) 0);
        boolean boolean14 = period3.isSupported(durationFieldType13);
        org.joda.time.field.PreciseDurationField preciseDurationField16 = new org.joda.time.field.PreciseDurationField(durationFieldType13, (long) '4');
        long long19 = preciseDurationField16.add((long) (-2), (int) (byte) 0);
        long long22 = preciseDurationField16.getMillis(9770L, (-61851686400000L));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-2L) + "'", long19 == (-2L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 508040L + "'", long22 == 508040L);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "DayTime", 0, 10);
        int int6 = fixedDateTimeZone4.getStandardOffset((-210865896000000L));
        int int8 = fixedDateTimeZone4.getStandardOffset(156062890818200L);
        long long10 = fixedDateTimeZone4.nextTransition((-99999L));
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler11 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file12 = null;
        java.io.File[] fileArray13 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap14 = zoneInfoCompiler11.compile(file12, fileArray13);
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap14);
        boolean boolean16 = fixedDateTimeZone4.equals((java.lang.Object) strMap14);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-99999L) + "'", long10 == (-99999L));
        org.junit.Assert.assertNotNull(fileArray13);
        org.junit.Assert.assertNotNull(strMap14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withWeeksRemoved();
        org.joda.time.PeriodType periodType2 = periodType1.withMillisRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) '4', chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        int int7 = period5.getMillis();
        org.joda.time.Period period9 = period5.minusYears((int) ' ');
        int[] intArray11 = iSOChronology0.get((org.joda.time.ReadablePeriod) period9, (long) (short) 0);
        org.joda.time.Period period12 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval14);
        org.joda.time.Period period16 = new org.joda.time.Period((long) '4', chronology15);
        org.joda.time.Period period18 = period16.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType19 = period18.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType((int) (short) 0);
        org.joda.time.Period period23 = period12.withField(durationFieldType21, (int) (short) 0);
        org.joda.time.Period period25 = period12.withWeeks((-1));
        org.joda.time.Period period26 = period9.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.ReadableInterval readableInterval28 = null;
        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval28);
        org.joda.time.Period period30 = new org.joda.time.Period((long) '4', chronology29);
        org.joda.time.Period period31 = period30.toPeriod();
        org.joda.time.ReadableInterval readableInterval33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval33);
        org.joda.time.Period period35 = new org.joda.time.Period((long) '4', chronology34);
        org.joda.time.Period period37 = period35.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType38 = period37.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType40 = periodType38.getFieldType((int) (short) 0);
        boolean boolean41 = period30.isSupported(durationFieldType40);
        int int42 = period26.get(durationFieldType40);
        org.joda.time.Period period44 = period26.withHours((int) (short) 10);
        org.joda.time.Period period46 = period44.minusSeconds(3);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-32) + "'", int42 == (-32));
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertNotNull(period46);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        long long10 = durationField7.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period15 = period14.toPeriod();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) '4', chronology18);
        org.joda.time.Period period21 = period19.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType24 = periodType22.getFieldType((int) (short) 0);
        boolean boolean25 = period14.isSupported(durationFieldType24);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType24, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField29 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType24, (int) (short) 100);
        long long31 = scaledDurationField29.getValueAsLong((long) 68);
        long long33 = scaledDurationField29.getMillis(52);
        long long36 = scaledDurationField29.getDifferenceAsLong((-84L), (-34919990L));
        long long39 = scaledDurationField29.getMillis(8, 0L);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 449280000000L + "'", long33 == 449280000000L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 69120000000L + "'", long39 == 69120000000L);
    }
}

