import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.years();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.Period period9 = new org.joda.time.Period((long) '4', chronology8);
        org.joda.time.Period period11 = period9.plusMillis(1);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType14 = periodType12.getFieldType((int) (short) 0);
        int int15 = period9.indexOf(durationFieldType14);
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(durationFieldType14, "UTC");
        int int18 = periodType5.indexOf(durationFieldType14);
        org.joda.time.PeriodType periodType19 = periodType5.withMonthsRemoved();
        org.joda.time.Period period20 = period3.normalizedStandard(periodType5);
        org.joda.time.Period period29 = new org.joda.time.Period(1, 10, (int) (short) -1, (-2), (int) (byte) 1, (int) (byte) 1, (int) ' ', (int) (byte) 10);
        org.joda.time.Period period31 = period29.minusSeconds((int) (short) 10);
        org.joda.time.Period period32 = period29.negated();
        try {
            org.joda.time.Period period33 = period20.withFields((org.joda.time.ReadablePeriod) period32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'months'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(period32);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) (short) 0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (-1248000));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period4 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', chronology7);
        org.joda.time.Period period10 = period8.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType((int) (short) 0);
        org.joda.time.Period period15 = period4.withField(durationFieldType13, (int) (short) 0);
        org.joda.time.Period period17 = period4.withWeeks((-1));
        org.joda.time.Period period19 = period17.withYears(52);
        int[] intArray21 = iSOChronology3.get((org.joda.time.ReadablePeriod) period19, (long) (byte) 1);
        org.joda.time.DurationField durationField22 = iSOChronology3.centuries();
        org.joda.time.Period period23 = new org.joda.time.Period(32314377595232L, (long) 70, periodType2, (org.joda.time.Chronology) iSOChronology3);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(durationField22);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        boolean boolean11 = unsupportedDurationField10.isSupported();
        org.joda.time.DurationFieldType durationFieldType12 = unsupportedDurationField10.getType();
        boolean boolean13 = unsupportedDurationField10.isSupported();
        org.joda.time.DurationFieldType durationFieldType14 = unsupportedDurationField10.getType();
        try {
            long long17 = unsupportedDurationField10.getMillis((long) 'a', 99916L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: days field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(durationFieldType14);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        long long9 = offsetDateTimeField7.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial10 = null;
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField7.getAsText(readablePartial10, 0, locale12);
        int int16 = offsetDateTimeField7.getDifference(0L, 4492800000070L);
        try {
            long long19 = offsetDateTimeField7.set(520L, "org.joda.time.IllegalFieldValueException: Coordinated Universal Time: Value 0 for org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0] must be in the range [100,10.0]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"org.joda.time.IllegalFieldValueException: Coordinated Universal Time: Value 0 for org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0] must be in the range [100,10.0]\" for clockhourOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1248000) + "'", int16 == (-1248000));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        boolean boolean11 = unsupportedDurationField10.isSupported();
        org.joda.time.DurationFieldType durationFieldType12 = unsupportedDurationField10.getType();
        try {
            long long15 = unsupportedDurationField10.add(0L, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: days field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationFieldType12);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        long long10 = durationField7.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period15 = period14.toPeriod();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) '4', chronology18);
        org.joda.time.Period period21 = period19.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType24 = periodType22.getFieldType((int) (short) 0);
        boolean boolean25 = period14.isSupported(durationFieldType24);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType24, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField29 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType24, (int) (short) 100);
        long long31 = scaledDurationField29.getValueAsLong((long) 68);
        long long34 = scaledDurationField29.getDifferenceAsLong(220L, (long) 'a');
        long long37 = scaledDurationField29.getValueAsLong((long) 52, 0L);
        long long39 = scaledDurationField29.getMillis(9770L);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 84412800000000L + "'", long39 == 84412800000000L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        long long9 = offsetDateTimeField7.roundHalfFloor(2704L);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField7.getType();
        org.joda.time.ReadablePartial readablePartial11 = null;
        java.util.Locale locale12 = null;
        try {
            java.lang.String str13 = offsetDateTimeField7.getAsShortText(readablePartial11, locale12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str26 = dateTimeZone25.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology27 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology24, dateTimeZone25);
        java.lang.String str28 = dateTimeZone25.getID();
        java.lang.String str29 = dateTimeZone25.toString();
        long long32 = dateTimeZone25.convertLocalToUTC((long) '4', false);
        org.joda.time.Chronology chronology33 = zonedChronology5.withZone(dateTimeZone25);
        org.joda.time.Period period35 = org.joda.time.Period.months(100);
        org.joda.time.Period period37 = period35.withMillis((int) 'a');
        org.joda.time.ReadableInterval readableInterval39 = null;
        org.joda.time.Chronology chronology40 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval39);
        org.joda.time.Period period41 = new org.joda.time.Period((long) '4', chronology40);
        org.joda.time.Period period42 = period41.toPeriod();
        org.joda.time.ReadableInterval readableInterval44 = null;
        org.joda.time.Chronology chronology45 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval44);
        org.joda.time.Period period46 = new org.joda.time.Period((long) '4', chronology45);
        org.joda.time.Period period48 = period46.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType49 = period48.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType51 = periodType49.getFieldType((int) (short) 0);
        boolean boolean52 = period41.isSupported(durationFieldType51);
        org.joda.time.Period period54 = period35.withField(durationFieldType51, 4);
        boolean boolean55 = zonedChronology5.equals((java.lang.Object) 4);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UTC" + "'", str26.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UTC" + "'", str29.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 52L + "'", long32 == 52L);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(chronology45);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertNotNull(periodType49);
        org.junit.Assert.assertNotNull(durationFieldType51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(period54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.Period period8 = new org.joda.time.Period(1, 10, (int) (short) -1, (-2), (int) (byte) 1, (int) (byte) 1, (int) ' ', (int) (byte) 10);
        org.joda.time.Period period10 = period8.minusSeconds((int) (short) 10);
        org.joda.time.Period period12 = period8.minusWeeks(3);
        org.joda.time.Period period14 = period8.withSeconds((-32));
        org.joda.time.DurationFieldType durationFieldType15 = null;
        try {
            org.joda.time.Period period17 = period14.withFieldAdded(durationFieldType15, (-180));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.Period period7 = period5.plusSeconds((int) (byte) -1);
        org.joda.time.Period period9 = period5.withMinutes(100);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        java.security.PermissionCollection permissionCollection3 = jodaTimePermission1.newPermissionCollection();
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str8 = dateTimeZone7.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology6, dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone10 = zonedChronology9.getZone();
        java.lang.String str11 = zonedChronology9.toString();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 3, periodType5, (org.joda.time.Chronology) zonedChronology9);
        org.joda.time.ReadableInterval readableInterval14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval14);
        org.joda.time.Period period16 = new org.joda.time.Period((long) '4', chronology15);
        org.joda.time.Period period18 = period16.plusMillis(1);
        java.lang.String str19 = period16.toString();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.clockhourOfDay();
        boolean boolean23 = iSOChronology20.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) period16, (org.joda.time.Chronology) iSOChronology20);
        int[] intArray26 = zonedChronology9.get((org.joda.time.ReadablePeriod) period24, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology27 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology9);
        long long31 = zonedChronology9.add(1000L, 1560628908182L, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField32 = zonedChronology9.minuteOfDay();
        jodaTimePermission1.checkGuard((java.lang.Object) zonedChronology9);
        org.joda.time.JodaTimePermission jodaTimePermission35 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str36 = jodaTimePermission35.getName();
        java.security.PermissionCollection permissionCollection37 = jodaTimePermission35.newPermissionCollection();
        org.joda.time.Period period46 = new org.joda.time.Period(1, 10, (int) (short) -1, (-2), (int) (byte) 1, (int) (byte) 1, (int) ' ', (int) (byte) 10);
        org.joda.time.Period period48 = period46.minusSeconds((int) (short) 10);
        org.joda.time.Period period50 = period48.minusMinutes((int) (short) 10);
        jodaTimePermission35.checkGuard((java.lang.Object) period48);
        boolean boolean52 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertNotNull(permissionCollection3);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str11.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PT0.052S" + "'", str19.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(lenientChronology27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560628909182L + "'", long31 == 1560628909182L);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertNotNull(permissionCollection37);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertNotNull(period50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        boolean boolean11 = unsupportedDurationField10.isSupported();
        org.joda.time.DurationFieldType durationFieldType12 = unsupportedDurationField10.getType();
        boolean boolean13 = unsupportedDurationField10.isSupported();
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.clockhourOfDay();
        org.joda.time.Period period20 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology18);
        org.joda.time.Period period21 = new org.joda.time.Period((long) (byte) 1, periodType15, (org.joda.time.Chronology) iSOChronology18);
        org.joda.time.DurationField durationField22 = iSOChronology18.halfdays();
        int int23 = unsupportedDurationField10.compareTo(durationField22);
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType26 = periodType25.withSecondsRemoved();
        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str31 = dateTimeZone30.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology32 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology29, dateTimeZone30);
        org.joda.time.DateTimeZone dateTimeZone33 = zonedChronology32.getZone();
        java.lang.String str34 = zonedChronology32.toString();
        org.joda.time.Period period35 = new org.joda.time.Period((long) 3, periodType28, (org.joda.time.Chronology) zonedChronology32);
        org.joda.time.ReadableInterval readableInterval37 = null;
        org.joda.time.Chronology chronology38 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval37);
        org.joda.time.Period period39 = new org.joda.time.Period((long) '4', chronology38);
        org.joda.time.Period period41 = period39.plusMillis(1);
        java.lang.String str42 = period39.toString();
        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology43.clockhourOfDay();
        boolean boolean46 = iSOChronology43.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period47 = new org.joda.time.Period((java.lang.Object) period39, (org.joda.time.Chronology) iSOChronology43);
        int[] intArray49 = zonedChronology32.get((org.joda.time.ReadablePeriod) period47, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology50 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology32);
        long long55 = zonedChronology32.getDateTimeMillis(100, (int) (short) 10, 10, (int) 'a');
        org.joda.time.Period period56 = new org.joda.time.Period(0L, periodType26, (org.joda.time.Chronology) zonedChronology32);
        boolean boolean57 = unsupportedDurationField10.equals((java.lang.Object) zonedChronology32);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "UTC" + "'", str31.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str34.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "PT0.052S" + "'", str42.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(lenientChronology50);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-58987094399903L) + "'", long55 == (-58987094399903L));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        long long10 = durationField7.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period15 = period14.toPeriod();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) '4', chronology18);
        org.joda.time.Period period21 = period19.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType24 = periodType22.getFieldType((int) (short) 0);
        boolean boolean25 = period14.isSupported(durationFieldType24);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType24, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField29 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType24, (int) (short) 100);
        long long31 = scaledDurationField29.getValueAsLong((long) 68);
        long long33 = scaledDurationField29.getMillis(52);
        long long36 = scaledDurationField29.getDifferenceAsLong((-84L), (-34919990L));
        long long39 = scaledDurationField29.getDifferenceAsLong(5042L, 5042L);
        int int42 = scaledDurationField29.getValue(0L, (long) (-2));
        long long45 = scaledDurationField29.add(84412800000000L, (-34919990L));
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 449280000000L + "'", long33 == 449280000000L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-301624300800000000L) + "'", long45 == (-301624300800000000L));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 1, periodType1, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DurationField durationField8 = iSOChronology4.seconds();
        org.joda.time.chrono.LenientChronology lenientChronology9 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology4);
        long long13 = lenientChronology9.add(0L, 2440578L, 100);
        org.joda.time.ReadableInterval readableInterval15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) '4', chronology16);
        org.joda.time.Period period18 = period17.toPeriod();
        org.joda.time.ReadableInterval readableInterval20 = null;
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval20);
        org.joda.time.Period period22 = new org.joda.time.Period((long) '4', chronology21);
        org.joda.time.Period period24 = period22.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType25 = period24.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType27 = periodType25.getFieldType((int) (short) 0);
        boolean boolean28 = period17.isSupported(durationFieldType27);
        org.joda.time.field.PreciseDurationField preciseDurationField30 = new org.joda.time.field.PreciseDurationField(durationFieldType27, (long) '4');
        org.joda.time.ReadableInterval readableInterval32 = null;
        org.joda.time.Chronology chronology33 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) '4', chronology33);
        org.joda.time.Period period36 = period34.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType37 = period36.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType39 = periodType37.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField41 = new org.joda.time.field.PreciseDurationField(durationFieldType39, (long) (byte) 100);
        long long44 = preciseDurationField41.getMillis(0L, 10L);
        long long46 = preciseDurationField41.getMillis(1560628908182L);
        int int47 = preciseDurationField30.compareTo((org.joda.time.DurationField) preciseDurationField41);
        boolean boolean48 = lenientChronology9.equals((java.lang.Object) preciseDurationField30);
        long long51 = preciseDurationField30.add((long) (byte) 1, (long) (-3491999));
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(lenientChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 244057800L + "'", long13 == 244057800L);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(durationFieldType39);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 156062890818200L + "'", long46 == 156062890818200L);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-181583947L) + "'", long51 == (-181583947L));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Weeks", "Coordinated Universal Time", (int) ' ', 8);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((-1134367200000L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2427458.25d + "'", double1 == 2427458.25d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField4 = zonedChronology3.weekyearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Period period5 = period4.normalizedStandard();
        org.joda.time.Period period6 = period4.toPeriod();
        org.joda.time.Period period8 = period6.plusHours(2);
        int int9 = period6.getMonths();
        org.joda.time.Seconds seconds10 = period6.toStandardSeconds();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(seconds10);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType6 = period5.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField10 = new org.joda.time.field.PreciseDurationField(durationFieldType8, (long) (byte) 100);
        java.lang.String str11 = preciseDurationField10.getName();
        long long12 = preciseDurationField10.getUnitMillis();
        long long15 = preciseDurationField10.getMillis((-46934L), 0L);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "years" + "'", str11.equals("years"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-4693400L) + "'", long15 == (-4693400L));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((-181583947L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440585.3983339467d + "'", double1 == 2440585.3983339467d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 1, (java.lang.Number) 100, (java.lang.Number) 10.0d);
        java.lang.String str5 = illegalFieldValueException4.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.String str7 = illegalFieldValueException4.getIllegalStringValue();
        boolean boolean8 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]" + "'", str5.equals("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]"));
        org.junit.Assert.assertNull(dateTimeFieldType6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        java.lang.String str4 = dateTimeZone1.getID();
        java.lang.String str5 = dateTimeZone1.toString();
        long long9 = dateTimeZone1.convertLocalToUTC((long) (short) -1, false, (long) '#');
        java.util.TimeZone timeZone10 = dateTimeZone1.toTimeZone();
        java.lang.String str11 = dateTimeZone1.getID();
        org.joda.time.ReadableInstant readableInstant12 = null;
        int int13 = dateTimeZone1.getOffset(readableInstant12);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', chronology7);
        org.joda.time.Period period10 = period8.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType((int) (short) 0);
        boolean boolean14 = period3.isSupported(durationFieldType13);
        org.joda.time.field.PreciseDurationField preciseDurationField16 = new org.joda.time.field.PreciseDurationField(durationFieldType13, (long) '4');
        org.joda.time.Period period17 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval19 = null;
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval19);
        org.joda.time.Period period21 = new org.joda.time.Period((long) '4', chronology20);
        org.joda.time.Period period23 = period21.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType24 = period23.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType26 = periodType24.getFieldType((int) (short) 0);
        org.joda.time.Period period28 = period17.withField(durationFieldType26, (int) (short) 0);
        org.joda.time.Period period30 = period17.withWeeks((-1));
        org.joda.time.ReadableInterval readableInterval32 = null;
        org.joda.time.Chronology chronology33 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) '4', chronology33);
        org.joda.time.Period period36 = period34.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType37 = period36.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType39 = periodType37.getFieldType((int) (short) 0);
        org.joda.time.Period period41 = period30.withField(durationFieldType39, (int) (short) -1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(durationFieldType39, "Weeks");
        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) preciseDurationField16, durationFieldType39);
        long long47 = decoratedDurationField44.add((long) 100, (int) (byte) 100);
        long long48 = decoratedDurationField44.getUnitMillis();
        int int51 = decoratedDurationField44.getValue((long) (byte) -1, (-10246L));
        long long54 = decoratedDurationField44.getValueAsLong((-1134367200000L), 2440578L);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(durationFieldType39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 5300L + "'", long47 == 5300L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 52L + "'", long48 == 52L);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-21814753846L) + "'", long54 == (-21814753846L));
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        long long3 = dateTimeZone0.adjustOffset((long) 'a', false);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone0.getName((long) 3, locale5);
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(iSOChronology7);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        long long9 = offsetDateTimeField7.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial10 = null;
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField7.getAsText(readablePartial10, 0, locale12);
        int int14 = offsetDateTimeField7.getMaximumValue();
        long long17 = offsetDateTimeField7.getDifferenceAsLong(2440588L, 14159997L);
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.clockhourOfDay();
        org.joda.time.Period period24 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology22);
        org.joda.time.ReadableInterval readableInterval26 = null;
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval26);
        org.joda.time.Period period28 = new org.joda.time.Period((long) '4', chronology27);
        org.joda.time.Period period30 = period28.withYears((int) (short) 10);
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Duration duration32 = period28.toDurationFrom(readableInstant31);
        org.joda.time.Period period33 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval35 = null;
        org.joda.time.Chronology chronology36 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval35);
        org.joda.time.Period period37 = new org.joda.time.Period((long) '4', chronology36);
        org.joda.time.Period period39 = period37.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType40 = period39.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType42 = periodType40.getFieldType((int) (short) 0);
        org.joda.time.Period period44 = period33.withField(durationFieldType42, (int) (short) 0);
        org.joda.time.Period period46 = period33.withWeeks((-1));
        org.joda.time.ReadableInterval readableInterval48 = null;
        org.joda.time.Chronology chronology49 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval48);
        org.joda.time.Period period50 = new org.joda.time.Period((long) '4', chronology49);
        org.joda.time.Period period52 = period50.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType53 = period52.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType55 = periodType53.getFieldType((int) (short) 0);
        org.joda.time.Period period57 = period46.withField(durationFieldType55, (int) (short) -1);
        org.joda.time.Period period59 = period28.withField(durationFieldType55, 0);
        int[] intArray61 = iSOChronology22.get((org.joda.time.ReadablePeriod) period59, (long) (short) 1);
        try {
            int[] intArray63 = offsetDateTimeField7.set(readablePartial18, (int) (short) 0, intArray61, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 23 + "'", int14 == 23);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-3L) + "'", long17 == (-3L));
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(duration32);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(periodType40);
        org.junit.Assert.assertNotNull(durationFieldType42);
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertNotNull(period46);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(period52);
        org.junit.Assert.assertNotNull(periodType53);
        org.junit.Assert.assertNotNull(durationFieldType55);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertNotNull(period59);
        org.junit.Assert.assertNotNull(intArray61);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.Period period8 = new org.joda.time.Period(1, 10, (int) (short) -1, (-2), (int) (byte) 1, (int) (byte) 1, (int) ' ', (int) (byte) 10);
        org.joda.time.Period period10 = period8.minusSeconds((int) (short) 10);
        org.joda.time.Period period12 = period8.minusWeeks(3);
        org.joda.time.Period period13 = period8.normalizedStandard();
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        org.joda.time.DurationField durationField8 = offsetDateTimeField7.getLeapDurationField();
        long long11 = offsetDateTimeField7.add(10L, 1);
        int int13 = offsetDateTimeField7.getLeapAmount(14159997L);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField7.getType();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3600010L + "'", long11 == 3600010L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        org.joda.time.DurationField durationField8 = offsetDateTimeField7.getLeapDurationField();
        long long11 = offsetDateTimeField7.add(10L, 1);
        int int13 = offsetDateTimeField7.getLeapAmount(14159997L);
        org.joda.time.ReadablePartial readablePartial14 = null;
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) '4', chronology18);
        int[] intArray20 = period19.getValues();
        java.util.Locale locale22 = null;
        try {
            int[] intArray23 = offsetDateTimeField7.set(readablePartial14, (int) (byte) -1, intArray20, "", locale22);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for clockhourOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3600010L + "'", long11 == 3600010L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(intArray20);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Period period5 = period4.normalizedStandard();
        org.joda.time.Period period7 = period4.withYears(10);
        org.joda.time.Period period9 = period4.plusMillis((int) (byte) 10);
        org.joda.time.Seconds seconds10 = period9.toStandardSeconds();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(seconds10);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        int int5 = period3.getMillis();
        org.joda.time.Period period7 = period3.plusMonths((-100));
        org.joda.time.Period period9 = period7.withHours((-1248000));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        boolean boolean11 = unsupportedDurationField10.isSupported();
        org.joda.time.DurationFieldType durationFieldType12 = unsupportedDurationField10.getType();
        boolean boolean13 = unsupportedDurationField10.isSupported();
        long long14 = unsupportedDurationField10.getUnitMillis();
        org.joda.time.DurationFieldType durationFieldType15 = unsupportedDurationField10.getType();
        try {
            long long18 = unsupportedDurationField10.getMillis(2, 2L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: days field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(durationFieldType15);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "DayTime", 0, 10);
        int int6 = fixedDateTimeZone4.getStandardOffset((-210865896000000L));
        int int8 = fixedDateTimeZone4.getStandardOffset(156062890818200L);
        long long10 = fixedDateTimeZone4.nextTransition((-99999L));
        int int12 = fixedDateTimeZone4.getOffsetFromLocal(156062890818200L);
        int int14 = fixedDateTimeZone4.getOffset(3536L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-99999L) + "'", long10 == (-99999L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(100L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "DayTime", 0, 10);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(70L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        org.joda.time.DurationField durationField8 = offsetDateTimeField7.getLeapDurationField();
        long long11 = offsetDateTimeField7.add(10L, 1);
        int int13 = offsetDateTimeField7.getLeapAmount(14159997L);
        long long15 = offsetDateTimeField7.remainder((long) (short) -1);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3600010L + "'", long11 == 3600010L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3599999L + "'", long15 == 3599999L);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 0, periodType1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType7 = periodType6.withWeeksRemoved();
        org.joda.time.PeriodType periodType8 = org.joda.time.DateTimeUtils.getPeriodType(periodType6);
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) 100, periodType8, chronology10);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.clockhourOfDay();
        org.joda.time.Period period16 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology14);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, (long) '#', periodType8, (org.joda.time.Chronology) iSOChronology14);
        org.joda.time.Period period19 = period17.plusMillis((int) (short) 0);
        org.joda.time.Period period20 = period2.withFields((org.joda.time.ReadablePeriod) period17);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.Period period4 = new org.joda.time.Period((-1), 70, (int) (short) 100, (int) (byte) 1);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType7 = periodType5.getFieldType((int) (short) 0);
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) '4', chronology10);
        org.joda.time.Period period13 = period11.plusMillis(1);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType16 = periodType14.getFieldType((int) (short) 0);
        int int17 = period11.indexOf(durationFieldType16);
        boolean boolean18 = periodType5.isSupported(durationFieldType16);
        int int19 = period4.indexOf(durationFieldType16);
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(durationFieldType16, "LenientChronology[ISOChronology[UTC]]");
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(durationFieldType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) '#');
        org.joda.time.DurationFieldType[] durationFieldTypeArray2 = period1.getFieldTypes();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(durationFieldTypeArray2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.DateTimeZone dateTimeZone23 = zonedChronology5.getZone();
        org.joda.time.DateTimeField dateTimeField24 = zonedChronology5.hourOfDay();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeField24);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        java.security.Permission permission3 = null;
        boolean boolean4 = jodaTimePermission1.implies(permission3);
        java.security.PermissionCollection permissionCollection5 = jodaTimePermission1.newPermissionCollection();
        org.joda.time.JodaTimePermission jodaTimePermission7 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean8 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission7);
        java.lang.String str9 = jodaTimePermission1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(permissionCollection5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str9.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.Period period1 = org.joda.time.Period.months(100);
        int int2 = period1.getMonths();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.clockhourOfDay();
        org.joda.time.Period period9 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology7);
        org.joda.time.Period period10 = new org.joda.time.Period((long) (byte) 1, periodType4, (org.joda.time.Chronology) iSOChronology7);
        org.joda.time.PeriodType periodType11 = periodType4.withYearsRemoved();
        boolean boolean12 = period1.equals((java.lang.Object) periodType4);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period1.toDurationTo(readableInstant13);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(duration14);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        java.security.PermissionCollection permissionCollection3 = jodaTimePermission1.newPermissionCollection();
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str8 = dateTimeZone7.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology6, dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone10 = zonedChronology9.getZone();
        java.lang.String str11 = zonedChronology9.toString();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 3, periodType5, (org.joda.time.Chronology) zonedChronology9);
        org.joda.time.ReadableInterval readableInterval14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval14);
        org.joda.time.Period period16 = new org.joda.time.Period((long) '4', chronology15);
        org.joda.time.Period period18 = period16.plusMillis(1);
        java.lang.String str19 = period16.toString();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.clockhourOfDay();
        boolean boolean23 = iSOChronology20.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) period16, (org.joda.time.Chronology) iSOChronology20);
        int[] intArray26 = zonedChronology9.get((org.joda.time.ReadablePeriod) period24, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology27 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology9);
        long long31 = zonedChronology9.add(1000L, 1560628908182L, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField32 = zonedChronology9.minuteOfDay();
        jodaTimePermission1.checkGuard((java.lang.Object) zonedChronology9);
        try {
            long long41 = zonedChronology9.getDateTimeMillis(349200000, (-1248000), 23, 4, (int) (short) 1, (int) (byte) 10, (-100));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -100 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertNotNull(permissionCollection3);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str11.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PT0.052S" + "'", str19.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(lenientChronology27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560628909182L + "'", long31 == 1560628909182L);
        org.junit.Assert.assertNotNull(dateTimeField32);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        long long9 = offsetDateTimeField7.roundHalfFloor(2704L);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField7.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType10, "ZonedChronology[ISOChronology[UTC], UTC]");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType10, (int) '4', 68, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for clockhourOfDay must be in the range [68,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((-100));
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Duration duration3 = period1.toDurationTo(readableInstant2);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(duration3);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType6 = period5.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField10 = new org.joda.time.field.PreciseDurationField(durationFieldType8, (long) (byte) 100);
        long long13 = preciseDurationField10.getValueAsLong(0L, (long) 10);
        long long16 = preciseDurationField10.subtract((long) 100, (long) (short) 0);
        org.joda.time.DurationFieldType durationFieldType17 = preciseDurationField10.getType();
        int int20 = preciseDurationField10.getValue((long) (byte) 100, (-61054729675996L));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.Period period8 = new org.joda.time.Period(1, 8, (int) (short) 0, (-180), (int) 'a', (int) (short) 0, 8, 4);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        long long26 = zonedChronology5.add(2440588L, 0L, 0);
        try {
            long long31 = zonedChronology5.getDateTimeMillis((int) '#', 100, 52, (-1248000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1248000 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2440588L + "'", long26 == 2440588L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        long long9 = offsetDateTimeField7.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial10 = null;
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField7.getAsText(readablePartial10, 0, locale12);
        int int14 = offsetDateTimeField7.getMaximumValue();
        org.joda.time.ReadablePartial readablePartial15 = null;
        org.joda.time.ReadableInterval readableInterval18 = null;
        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval18);
        org.joda.time.Period period20 = new org.joda.time.Period((long) '4', chronology19);
        org.joda.time.Period period21 = period20.toPeriod();
        int[] intArray22 = period20.getValues();
        try {
            int[] intArray24 = offsetDateTimeField7.addWrapField(readablePartial15, 70, intArray22, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 70");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 23 + "'", int14 == 23);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(intArray22);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        org.joda.time.DurationField durationField8 = iSOChronology2.weeks();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology2.hourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType2 = periodType1.withSecondsRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str7 = dateTimeZone6.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology5, dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone9 = zonedChronology8.getZone();
        java.lang.String str10 = zonedChronology8.toString();
        org.joda.time.Period period11 = new org.joda.time.Period((long) 3, periodType4, (org.joda.time.Chronology) zonedChronology8);
        org.joda.time.ReadableInterval readableInterval13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) '4', chronology14);
        org.joda.time.Period period17 = period15.plusMillis(1);
        java.lang.String str18 = period15.toString();
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.clockhourOfDay();
        boolean boolean22 = iSOChronology19.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period23 = new org.joda.time.Period((java.lang.Object) period15, (org.joda.time.Chronology) iSOChronology19);
        int[] intArray25 = zonedChronology8.get((org.joda.time.ReadablePeriod) period23, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology26 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology8);
        long long31 = zonedChronology8.getDateTimeMillis(100, (int) (short) 10, 10, (int) 'a');
        org.joda.time.Period period32 = new org.joda.time.Period(0L, periodType2, (org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTimeField dateTimeField33 = zonedChronology8.weekOfWeekyear();
        org.joda.time.DurationField durationField34 = zonedChronology8.halfdays();
        org.joda.time.DateTimeField dateTimeField35 = zonedChronology8.weekyearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        try {
            int[] intArray39 = zonedChronology8.get(readablePeriod36, (-52L), 244800220L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str10.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PT0.052S" + "'", str18.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(lenientChronology26);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-58987094399903L) + "'", long31 == (-58987094399903L));
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File[] fileArray2 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = zoneInfoCompiler0.compile(file1, fileArray2);
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap3);
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap3);
        org.junit.Assert.assertNotNull(fileArray2);
        org.junit.Assert.assertNotNull(strMap3);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) ' ');
        org.joda.time.Period period3 = period1.multipliedBy(2);
        org.joda.time.Period period5 = org.joda.time.Period.days((int) (short) 0);
        org.joda.time.Period period6 = period3.plus((org.joda.time.ReadablePeriod) period5);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 1, periodType1, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.PeriodType periodType8 = periodType1.withYearsRemoved();
        int int9 = periodType8.size();
        org.joda.time.PeriodType periodType10 = periodType8.withWeeksRemoved();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(periodType10);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 1, (int) (short) -1, 0, (int) (short) -1);
        org.joda.time.PeriodType periodType5 = null;
        org.joda.time.Period period6 = period4.normalizedStandard(periodType5);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 1, (int) (short) -1, 0, (int) (short) -1);
        org.joda.time.Period period6 = period4.withHours(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType10 = periodType9.withWeeksRemoved();
        org.joda.time.PeriodType periodType11 = org.joda.time.DateTimeUtils.getPeriodType(periodType9);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) 100, periodType11, chronology13);
        boolean boolean15 = gregorianChronology7.equals((java.lang.Object) 100);
        org.joda.time.IllegalInstantException illegalInstantException17 = new org.joda.time.IllegalInstantException("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        boolean boolean18 = gregorianChronology7.equals((java.lang.Object) illegalInstantException17);
        org.joda.time.Chronology chronology19 = gregorianChronology7.withUTC();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str21 = dateTimeZone20.getID();
        java.lang.String str22 = dateTimeZone20.getID();
        org.joda.time.Chronology chronology23 = gregorianChronology7.withZone(dateTimeZone20);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str25 = dateTimeZone24.getID();
        org.joda.time.Chronology chronology26 = gregorianChronology7.withZone(dateTimeZone24);
        boolean boolean27 = period6.equals((java.lang.Object) chronology26);
        org.joda.time.Period period29 = period6.withDays(52);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "UTC" + "'", str21.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UTC" + "'", str22.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "UTC" + "'", str25.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(period29);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        int int5 = period3.getMillis();
        org.joda.time.Period period7 = period3.minusYears((int) ' ');
        org.joda.time.Period period9 = period7.plusDays((int) 'a');
        org.joda.time.Period period10 = period7.negated();
        org.joda.time.MutablePeriod mutablePeriod11 = period10.toMutablePeriod();
        org.joda.time.Period period13 = period10.withMinutes(100);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(mutablePeriod11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 1, (java.lang.Number) 100, (java.lang.Number) 10.0d);
        illegalFieldValueException4.prependMessage("");
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = illegalFieldValueException4.getDateTimeFieldType();
        org.joda.time.DurationFieldType durationFieldType8 = illegalFieldValueException4.getDurationFieldType();
        java.lang.Number number9 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertNull(dateTimeFieldType7);
        org.junit.Assert.assertNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 10.0d + "'", number9.equals(10.0d));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) (byte) -1, ' ', (int) (byte) 100, (int) ' ', 0, false, (-32));
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeZoneBuilder0.toDateTimeZone("+00:00", false);
        java.lang.String str12 = dateTimeZone11.toString();
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(3599999L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) -1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 1, (int) (short) -1, 0, (int) (short) -1);
        org.joda.time.Period period6 = period4.minusMillis((int) (byte) 100);
        org.joda.time.ReadableInterval readableInterval8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval8);
        org.joda.time.Period period10 = new org.joda.time.Period((long) '4', chronology9);
        org.joda.time.Period period12 = period10.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType13 = period12.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType15 = periodType13.getFieldType((int) (short) 0);
        int int16 = period4.get(durationFieldType15);
        org.joda.time.Period period18 = period4.plusHours(68);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(period18);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("ISOChronology[UTC]");
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', chronology7);
        org.joda.time.Period period10 = period8.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType((int) (short) 0);
        boolean boolean14 = period3.isSupported(durationFieldType13);
        org.joda.time.field.PreciseDurationField preciseDurationField16 = new org.joda.time.field.PreciseDurationField(durationFieldType13, (long) '4');
        org.joda.time.ReadableInterval readableInterval18 = null;
        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval18);
        org.joda.time.Period period20 = new org.joda.time.Period((long) '4', chronology19);
        org.joda.time.Period period22 = period20.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType23 = period22.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType25 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType25, (long) (byte) 100);
        long long30 = preciseDurationField27.getMillis(0L, 10L);
        long long32 = preciseDurationField27.getMillis(1560628908182L);
        int int33 = preciseDurationField16.compareTo((org.joda.time.DurationField) preciseDurationField27);
        org.joda.time.DurationFieldType durationFieldType34 = preciseDurationField27.getType();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 156062890818200L + "'", long32 == 156062890818200L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType34);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = zonedChronology3.getZone();
        java.lang.String str5 = zonedChronology3.toString();
        org.joda.time.DateTimeField dateTimeField6 = zonedChronology3.clockhourOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str9 = dateTimeZone8.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, dateTimeZone8);
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology7.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (-1));
        long long16 = offsetDateTimeField14.roundHalfFloor(2704L);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField14.getType();
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField19 = new org.joda.time.field.RemainderDateTimeField(dateTimeField6, dateTimeFieldType17, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period6 = period4.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType7 = period6.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (short) 0);
        org.joda.time.Period period11 = period0.withField(durationFieldType9, (int) (short) 0);
        org.joda.time.Period period13 = period0.withWeeks((-1));
        org.joda.time.ReadableInterval readableInterval15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) '4', chronology16);
        org.joda.time.Period period19 = period17.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType20 = period19.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType22 = periodType20.getFieldType((int) (short) 0);
        org.joda.time.Period period24 = period13.withField(durationFieldType22, (int) (short) -1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(durationFieldType22, "Weeks");
        org.joda.time.IllegalInstantException illegalInstantException28 = new org.joda.time.IllegalInstantException("hi!");
        illegalFieldValueException26.addSuppressed((java.lang.Throwable) illegalInstantException28);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(period24);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) '4', chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        int int7 = period5.getMillis();
        org.joda.time.Period period9 = period5.minusYears((int) ' ');
        int[] intArray11 = iSOChronology0.get((org.joda.time.ReadablePeriod) period9, (long) (short) 0);
        org.joda.time.Period period12 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval14);
        org.joda.time.Period period16 = new org.joda.time.Period((long) '4', chronology15);
        org.joda.time.Period period18 = period16.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType19 = period18.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType((int) (short) 0);
        org.joda.time.Period period23 = period12.withField(durationFieldType21, (int) (short) 0);
        org.joda.time.Period period25 = period12.withWeeks((-1));
        org.joda.time.Period period26 = period9.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.ReadableInterval readableInterval28 = null;
        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval28);
        org.joda.time.Period period30 = new org.joda.time.Period((long) '4', chronology29);
        org.joda.time.Period period31 = period30.toPeriod();
        org.joda.time.ReadableInterval readableInterval33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval33);
        org.joda.time.Period period35 = new org.joda.time.Period((long) '4', chronology34);
        org.joda.time.Period period37 = period35.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType38 = period37.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType40 = periodType38.getFieldType((int) (short) 0);
        boolean boolean41 = period30.isSupported(durationFieldType40);
        int int42 = period26.get(durationFieldType40);
        org.joda.time.Period period44 = period26.minusMinutes((-3491999));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-32) + "'", int42 == (-32));
        org.junit.Assert.assertNotNull(period44);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 100, periodType4, chronology6);
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) 100);
        org.joda.time.IllegalInstantException illegalInstantException10 = new org.joda.time.IllegalInstantException("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        boolean boolean11 = gregorianChronology0.equals((java.lang.Object) illegalInstantException10);
        org.joda.time.Chronology chronology12 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str14 = dateTimeZone13.getID();
        java.lang.String str15 = dateTimeZone13.getID();
        org.joda.time.Chronology chronology16 = gregorianChronology0.withZone(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str18 = dateTimeZone17.getID();
        org.joda.time.Chronology chronology19 = gregorianChronology0.withZone(dateTimeZone17);
        long long21 = dateTimeZone17.convertUTCToLocal((-58987094399903L));
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone17);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "UTC" + "'", str18.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-58987094399903L) + "'", long21 == (-58987094399903L));
        org.junit.Assert.assertNotNull(iSOChronology22);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType4 = periodType3.withWeeksRemoved();
        org.joda.time.PeriodType periodType5 = org.joda.time.DateTimeUtils.getPeriodType(periodType3);
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) 100, periodType5, chronology7);
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType5);
        org.joda.time.PeriodType periodType10 = periodType5.withHoursRemoved();
        org.joda.time.PeriodType periodType11 = periodType10.withMonthsRemoved();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDay();
        try {
            org.joda.time.DurationFieldType durationFieldType2 = periodType0.getFieldType(349200000);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        org.joda.time.DurationField durationField8 = offsetDateTimeField7.getLeapDurationField();
        long long11 = offsetDateTimeField7.add(10L, 1);
        int int13 = offsetDateTimeField7.getLeapAmount(14159997L);
        org.joda.time.ReadablePartial readablePartial14 = null;
        int int15 = offsetDateTimeField7.getMaximumValue(readablePartial14);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3600010L + "'", long11 == 3600010L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 23 + "'", int15 == 23);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withWeeksRemoved();
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType3 = periodType0.withDaysRemoved();
        org.joda.time.DurationFieldType durationFieldType5 = periodType3.getFieldType((int) (byte) 0);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(durationFieldType5);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.Period period1 = org.joda.time.Period.years(23);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) (byte) -1, ' ', (int) (byte) 100, (int) ' ', 0, false, (-32));
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeZoneBuilder0.toDateTimeZone("+00:00", false);
        java.io.OutputStream outputStream13 = null;
        try {
            dateTimeZoneBuilder0.writeTo("ISOChronology[UTC]", outputStream13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "org.joda.time.IllegalFieldValueException: Value 0 for org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0] must be in the range [100,10.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        long long10 = durationField7.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period15 = period14.toPeriod();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) '4', chronology18);
        org.joda.time.Period period21 = period19.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType24 = periodType22.getFieldType((int) (short) 0);
        boolean boolean25 = period14.isSupported(durationFieldType24);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType24, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField29 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType24, (int) (short) 100);
        long long31 = scaledDurationField29.getMillis((int) '4');
        int int32 = scaledDurationField29.getScalar();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 449280000000L + "'", long31 == 449280000000L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File[] fileArray2 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = zoneInfoCompiler0.compile(file1, fileArray2);
        java.io.BufferedReader bufferedReader4 = null;
        try {
            zoneInfoCompiler0.parseDataFile(bufferedReader4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fileArray2);
        org.junit.Assert.assertNotNull(strMap3);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', chronology7);
        org.joda.time.Period period10 = period8.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType((int) (short) 0);
        boolean boolean14 = period3.isSupported(durationFieldType13);
        org.joda.time.field.PreciseDurationField preciseDurationField16 = new org.joda.time.field.PreciseDurationField(durationFieldType13, (long) '4');
        org.joda.time.Period period17 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval19 = null;
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval19);
        org.joda.time.Period period21 = new org.joda.time.Period((long) '4', chronology20);
        org.joda.time.Period period23 = period21.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType24 = period23.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType26 = periodType24.getFieldType((int) (short) 0);
        org.joda.time.Period period28 = period17.withField(durationFieldType26, (int) (short) 0);
        org.joda.time.Period period30 = period17.withWeeks((-1));
        org.joda.time.ReadableInterval readableInterval32 = null;
        org.joda.time.Chronology chronology33 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) '4', chronology33);
        org.joda.time.Period period36 = period34.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType37 = period36.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType39 = periodType37.getFieldType((int) (short) 0);
        org.joda.time.Period period41 = period30.withField(durationFieldType39, (int) (short) -1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(durationFieldType39, "Weeks");
        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) preciseDurationField16, durationFieldType39);
        long long47 = decoratedDurationField44.add((long) 100, (int) (byte) 100);
        int int50 = decoratedDurationField44.getValue(1L, 0L);
        long long53 = decoratedDurationField44.getMillis((long) 52, (long) (short) -1);
        long long56 = decoratedDurationField44.add((long) 100, (-1));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(durationFieldType39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 5300L + "'", long47 == 5300L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 2704L + "'", long53 == 2704L);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 48L + "'", long56 == 48L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType6 = period5.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField10 = new org.joda.time.field.PreciseDurationField(durationFieldType8, (long) (byte) 100);
        long long13 = preciseDurationField10.getValueAsLong(0L, (long) 10);
        long long16 = preciseDurationField10.subtract((long) 100, (long) (short) 0);
        org.joda.time.DurationFieldType durationFieldType17 = preciseDurationField10.getType();
        long long20 = preciseDurationField10.getMillis((int) ' ', 244057800L);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 3200L + "'", long20 == 3200L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(durationFieldType8, "UTC");
        illegalFieldValueException11.prependMessage("PT-1M-0.001S");
        org.joda.time.DurationFieldType durationFieldType14 = illegalFieldValueException11.getDurationFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(durationFieldType14, "PeriodType[Years]");
        java.lang.Class<?> wildcardClass17 = durationFieldType14.getClass();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        org.joda.time.DurationField durationField8 = offsetDateTimeField7.getLeapDurationField();
        long long11 = offsetDateTimeField7.add(0L, (long) (short) 100);
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale13 = null;
        try {
            java.lang.String str14 = offsetDateTimeField7.getAsText(readablePartial12, locale13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 360000000L + "'", long11 == 360000000L);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str1 = dateTimeZone0.getID();
//        java.util.TimeZone timeZone2 = dateTimeZone0.toTimeZone();
//        java.util.TimeZone timeZone3 = dateTimeZone0.toTimeZone();
//        long long6 = dateTimeZone0.adjustOffset(1L, true);
//        java.lang.String str8 = dateTimeZone0.getShortName(360000000L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTC" + "'", str1.equals("UTC"));
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.millisOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str8 = dateTimeZone7.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology6, dateTimeZone7);
        org.joda.time.chrono.LenientChronology lenientChronology10 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology6.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (-1));
        long long15 = offsetDateTimeField13.roundHalfFloor(2704L);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField13.getType();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType16, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(lenientChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
//        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
//        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
//        org.joda.time.ReadableInterval readableInterval5 = null;
//        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
//        org.joda.time.Period period7 = new org.joda.time.Period((long) 100, periodType4, chronology6);
//        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) 100);
//        org.joda.time.IllegalInstantException illegalInstantException10 = new org.joda.time.IllegalInstantException("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
//        boolean boolean11 = gregorianChronology0.equals((java.lang.Object) illegalInstantException10);
//        org.joda.time.Chronology chronology12 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str14 = dateTimeZone13.getID();
//        java.lang.String str15 = dateTimeZone13.getID();
//        org.joda.time.Chronology chronology16 = gregorianChronology0.withZone(dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str18 = dateTimeZone17.getID();
//        org.joda.time.Chronology chronology19 = gregorianChronology0.withZone(dateTimeZone17);
//        java.lang.String str20 = dateTimeZone17.toString();
//        java.util.TimeZone timeZone21 = dateTimeZone17.toTimeZone();
//        boolean boolean23 = dateTimeZone17.isStandardOffset((long) (-3491999));
//        int int25 = dateTimeZone17.getOffsetFromLocal((-1L));
//        java.lang.String str27 = dateTimeZone17.getName((long) (byte) 10);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(periodType3);
//        org.junit.Assert.assertNotNull(periodType4);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "UTC" + "'", str18.equals("UTC"));
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Coordinated Universal Time" + "'", str27.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withWeeksRemoved();
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        java.lang.String str3 = periodType0.toString();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PeriodType[DayTime]" + "'", str3.equals("PeriodType[DayTime]"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfDay();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        java.security.PermissionCollection permissionCollection3 = jodaTimePermission1.newPermissionCollection();
        org.joda.time.Period period12 = new org.joda.time.Period(1, 10, (int) (short) -1, (-2), (int) (byte) 1, (int) (byte) 1, (int) ' ', (int) (byte) 10);
        org.joda.time.Period period14 = period12.minusSeconds((int) (short) 10);
        org.joda.time.Period period16 = period14.minusMinutes((int) (short) 10);
        jodaTimePermission1.checkGuard((java.lang.Object) period14);
        java.security.PermissionCollection permissionCollection18 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertNotNull(permissionCollection3);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(permissionCollection18);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(10L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("YearDayTime");
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        long long10 = durationField7.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period15 = period14.toPeriod();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) '4', chronology18);
        org.joda.time.Period period21 = period19.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType24 = periodType22.getFieldType((int) (short) 0);
        boolean boolean25 = period14.isSupported(durationFieldType24);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType24, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField29 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType24, (int) (short) 100);
        long long31 = scaledDurationField29.getValueAsLong((long) 68);
        long long33 = scaledDurationField29.getMillis(52);
        int int35 = scaledDurationField29.getValue((long) (short) 0);
        long long38 = scaledDurationField29.add((long) 4, 100);
        long long41 = scaledDurationField29.getValueAsLong(0L, 5300L);
        int int42 = scaledDurationField29.getScalar();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 449280000000L + "'", long33 == 449280000000L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 864000000004L + "'", long38 == 864000000004L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 100 + "'", int42 == 100);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(1);
        org.joda.time.Period period3 = period1.minusMillis((-100));
        org.joda.time.Period period5 = period3.plusDays((-131));
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', chronology7);
        org.joda.time.Period period10 = period8.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType((int) (short) 0);
        boolean boolean14 = period3.isSupported(durationFieldType13);
        org.joda.time.field.PreciseDurationField preciseDurationField16 = new org.joda.time.field.PreciseDurationField(durationFieldType13, (long) '4');
        long long19 = preciseDurationField16.add((long) (-2), (int) (byte) 0);
        long long22 = preciseDurationField16.subtract((long) 0, (int) (short) 1);
        boolean boolean23 = preciseDurationField16.isPrecise();
        boolean boolean24 = preciseDurationField16.isPrecise();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-2L) + "'", long19 == (-2L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-52L) + "'", long22 == (-52L));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.era();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 10L + "'", long0 == 10L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) '4', chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        int int7 = period5.getMillis();
        org.joda.time.Period period9 = period5.minusYears((int) ' ');
        int[] intArray11 = iSOChronology0.get((org.joda.time.ReadablePeriod) period9, (long) (short) 0);
        org.joda.time.DurationField durationField12 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(349200000);
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
//        boolean boolean5 = iSOChronology2.equals((java.lang.Object) (-1.0f));
//        org.joda.time.DateTimeZone dateTimeZone6 = iSOChronology2.getZone();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getShortName((long) 'a', locale8);
//        java.lang.String str11 = dateTimeZone6.getShortName((-349199900L));
//        long long13 = dateTimeZone1.getMillisKeepLocal(dateTimeZone6, (-32L));
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 349199968L + "'", long13 == 349199968L);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        boolean boolean11 = unsupportedDurationField10.isSupported();
        java.lang.String str12 = unsupportedDurationField10.toString();
        try {
            long long14 = unsupportedDurationField10.getValueAsLong((long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: days field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDurationField[days]" + "'", str12.equals("UnsupportedDurationField[days]"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 100, periodType4, chronology6);
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) 100);
        org.joda.time.IllegalInstantException illegalInstantException10 = new org.joda.time.IllegalInstantException("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        boolean boolean11 = gregorianChronology0.equals((java.lang.Object) illegalInstantException10);
        org.joda.time.Chronology chronology12 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str14 = dateTimeZone13.getID();
        java.lang.String str15 = dateTimeZone13.getID();
        org.joda.time.Chronology chronology16 = gregorianChronology0.withZone(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str18 = dateTimeZone17.getID();
        org.joda.time.Chronology chronology19 = gregorianChronology0.withZone(dateTimeZone17);
        long long21 = dateTimeZone17.convertUTCToLocal((-58987094399903L));
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.dayOfWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "UTC" + "'", str18.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-58987094399903L) + "'", long21 == (-58987094399903L));
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 1, (java.lang.Number) 100, (java.lang.Number) 10.0d);
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        java.lang.String str6 = illegalFieldValueException4.toString();
        illegalFieldValueException4.prependMessage("");
        java.lang.String str9 = illegalFieldValueException4.getIllegalStringValue();
        org.joda.time.DurationFieldType durationFieldType10 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]" + "'", str6.equals("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]"));
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(durationFieldType10);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("LenientChronology[ISOChronology[UTC]]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'LenientChronology[ISOChronology[UTC]]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        long long9 = offsetDateTimeField7.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial10 = null;
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField7.getAsText(readablePartial10, 0, locale12);
        int int14 = offsetDateTimeField7.getMaximumValue();
        long long17 = offsetDateTimeField7.getDifferenceAsLong(2440588L, 14159997L);
        long long20 = offsetDateTimeField7.set(3536L, 0);
        long long22 = offsetDateTimeField7.remainder(10000L);
        java.util.Locale locale25 = null;
        try {
            long long26 = offsetDateTimeField7.set((-52L), "Coordinated Universal Time", locale25);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Coordinated Universal Time\" for clockhourOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 23 + "'", int14 == 23);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-3L) + "'", long17 == (-3L));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 3603536L + "'", long20 == 3603536L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10000L + "'", long22 == 10000L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        java.lang.String str5 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance(chronology2, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology6.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology6.dayOfMonth();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.clockhourOfDay();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology6);
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 1, periodType3, (org.joda.time.Chronology) iSOChronology6);
        org.joda.time.Period period10 = new org.joda.time.Period(1560628908182L, (long) (-1), (org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology6.yearOfEra();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 100, periodType4, chronology6);
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) 100);
        org.joda.time.IllegalInstantException illegalInstantException10 = new org.joda.time.IllegalInstantException("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        boolean boolean11 = gregorianChronology0.equals((java.lang.Object) illegalInstantException10);
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType17 = periodType16.withWeeksRemoved();
        org.joda.time.PeriodType periodType18 = org.joda.time.DateTimeUtils.getPeriodType(periodType16);
        org.joda.time.ReadableInterval readableInterval19 = null;
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval19);
        org.joda.time.Period period21 = new org.joda.time.Period((long) 100, periodType18, chronology20);
        boolean boolean22 = gregorianChronology14.equals((java.lang.Object) 100);
        org.joda.time.IllegalInstantException illegalInstantException24 = new org.joda.time.IllegalInstantException("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        boolean boolean25 = gregorianChronology14.equals((java.lang.Object) illegalInstantException24);
        org.joda.time.DateTimeZone dateTimeZone26 = gregorianChronology14.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone26);
        org.joda.time.Chronology chronology28 = gregorianChronology13.withZone(dateTimeZone26);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(chronology28);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        long long9 = offsetDateTimeField7.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial10 = null;
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField7.getAsText(readablePartial10, 0, locale12);
        int int14 = offsetDateTimeField7.getMaximumValue();
        int int16 = offsetDateTimeField7.getMinimumValue((long) (-3491999));
        long long19 = offsetDateTimeField7.add(3600010L, (long) (-2));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 23 + "'", int14 == 23);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-3599990L) + "'", long19 == (-3599990L));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(349200000);
        org.joda.time.ReadableInstant readableInstant2 = null;
        int int3 = dateTimeZone1.getOffset(readableInstant2);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 349200000 + "'", int3 == 349200000);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', chronology7);
        org.joda.time.Period period10 = period8.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType((int) (short) 0);
        boolean boolean14 = period3.isSupported(durationFieldType13);
        org.joda.time.field.PreciseDurationField preciseDurationField16 = new org.joda.time.field.PreciseDurationField(durationFieldType13, (long) '4');
        org.joda.time.Period period17 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval19 = null;
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval19);
        org.joda.time.Period period21 = new org.joda.time.Period((long) '4', chronology20);
        org.joda.time.Period period23 = period21.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType24 = period23.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType26 = periodType24.getFieldType((int) (short) 0);
        org.joda.time.Period period28 = period17.withField(durationFieldType26, (int) (short) 0);
        org.joda.time.Period period30 = period17.withWeeks((-1));
        org.joda.time.ReadableInterval readableInterval32 = null;
        org.joda.time.Chronology chronology33 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) '4', chronology33);
        org.joda.time.Period period36 = period34.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType37 = period36.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType39 = periodType37.getFieldType((int) (short) 0);
        org.joda.time.Period period41 = period30.withField(durationFieldType39, (int) (short) -1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(durationFieldType39, "Weeks");
        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) preciseDurationField16, durationFieldType39);
        long long47 = decoratedDurationField44.add((long) 100, (int) (byte) 100);
        int int50 = decoratedDurationField44.getValue(1L, 0L);
        long long53 = decoratedDurationField44.getMillis((-1L), (-10246L));
        long long55 = decoratedDurationField44.getMillis((long) 0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(durationFieldType39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 5300L + "'", long47 == 5300L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-52L) + "'", long53 == (-52L));
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) -1);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder0.addRecurringSavings("Coordinated Universal Time", (-24405), 8, 23, 'a', (-24405), (int) (byte) 0, (-180), true, (-24405));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.clockhourOfDay();
        org.joda.time.Period period9 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology7);
        org.joda.time.Period period10 = new org.joda.time.Period((long) (byte) 1, periodType4, (org.joda.time.Chronology) iSOChronology7);
        org.joda.time.PeriodType periodType11 = periodType4.withYearsRemoved();
        int int12 = periodType11.size();
        boolean boolean13 = gregorianChronology0.equals((java.lang.Object) int12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        org.joda.time.DurationField durationField8 = offsetDateTimeField7.getLeapDurationField();
        long long11 = offsetDateTimeField7.add(10L, 1);
        int int13 = offsetDateTimeField7.getLeapAmount(14159997L);
        java.util.Locale locale14 = null;
        int int15 = offsetDateTimeField7.getMaximumTextLength(locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        int int17 = offsetDateTimeField7.getMinimumValue(readablePartial16);
        org.joda.time.ReadablePartial readablePartial18 = null;
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField7.getAsText(readablePartial18, 0, locale20);
        java.util.Locale locale22 = null;
        int int23 = offsetDateTimeField7.getMaximumShortTextLength(locale22);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3600010L + "'", long11 == 3600010L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("LenientChronology[ISOChronology[UTC]]", "ZonedChronology[ISOChronology[UTC], UTC]", (int) '4', (-100));
        java.lang.String str6 = fixedDateTimeZone4.getNameKey(3200L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str6.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.Period period1 = org.joda.time.Period.years(0);
        org.joda.time.Period period3 = period1.multipliedBy(2);
        org.joda.time.Period period5 = period1.minusSeconds((int) (short) 1);
        org.joda.time.MutablePeriod mutablePeriod6 = period5.toMutablePeriod();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(mutablePeriod6);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        java.security.PermissionCollection permissionCollection3 = jodaTimePermission1.newPermissionCollection();
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str8 = dateTimeZone7.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology6, dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone10 = zonedChronology9.getZone();
        java.lang.String str11 = zonedChronology9.toString();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 3, periodType5, (org.joda.time.Chronology) zonedChronology9);
        org.joda.time.ReadableInterval readableInterval14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval14);
        org.joda.time.Period period16 = new org.joda.time.Period((long) '4', chronology15);
        org.joda.time.Period period18 = period16.plusMillis(1);
        java.lang.String str19 = period16.toString();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.clockhourOfDay();
        boolean boolean23 = iSOChronology20.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) period16, (org.joda.time.Chronology) iSOChronology20);
        int[] intArray26 = zonedChronology9.get((org.joda.time.ReadablePeriod) period24, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology27 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology9);
        long long31 = zonedChronology9.add(1000L, 1560628908182L, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField32 = zonedChronology9.minuteOfDay();
        jodaTimePermission1.checkGuard((java.lang.Object) zonedChronology9);
        java.lang.String str34 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertNotNull(permissionCollection3);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str11.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PT0.052S" + "'", str19.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(lenientChronology27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560628909182L + "'", long31 == 1560628909182L);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) '4', chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        int int7 = period5.getMillis();
        org.joda.time.Period period9 = period5.minusYears((int) ' ');
        int[] intArray11 = iSOChronology0.get((org.joda.time.ReadablePeriod) period9, (long) (short) 0);
        org.joda.time.DurationField durationField12 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology0.hourOfHalfday();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str17 = dateTimeZone16.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone16);
        org.joda.time.chrono.LenientChronology lenientChronology19 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology15);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology15.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (-1));
        long long24 = offsetDateTimeField22.roundHalfFloor(2704L);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField22.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField27 = new org.joda.time.field.DividedDateTimeField(dateTimeField14, dateTimeFieldType25, (int) '4');
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, (java.lang.Number) 68, (java.lang.Number) (byte) -1, (java.lang.Number) 2440585.3983339467d);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "UTC" + "'", str17.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(lenientChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', chronology7);
        org.joda.time.Period period10 = period8.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType((int) (short) 0);
        boolean boolean14 = period3.isSupported(durationFieldType13);
        org.joda.time.field.PreciseDurationField preciseDurationField16 = new org.joda.time.field.PreciseDurationField(durationFieldType13, (long) '4');
        org.joda.time.Period period17 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval19 = null;
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval19);
        org.joda.time.Period period21 = new org.joda.time.Period((long) '4', chronology20);
        org.joda.time.Period period23 = period21.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType24 = period23.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType26 = periodType24.getFieldType((int) (short) 0);
        org.joda.time.Period period28 = period17.withField(durationFieldType26, (int) (short) 0);
        org.joda.time.Period period30 = period17.withWeeks((-1));
        org.joda.time.ReadableInterval readableInterval32 = null;
        org.joda.time.Chronology chronology33 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) '4', chronology33);
        org.joda.time.Period period36 = period34.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType37 = period36.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType39 = periodType37.getFieldType((int) (short) 0);
        org.joda.time.Period period41 = period30.withField(durationFieldType39, (int) (short) -1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(durationFieldType39, "Weeks");
        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) preciseDurationField16, durationFieldType39);
        int int46 = decoratedDurationField44.getValue((long) (short) 1);
        long long47 = decoratedDurationField44.getUnitMillis();
        java.lang.String str48 = decoratedDurationField44.toString();
        org.joda.time.DurationField durationField49 = decoratedDurationField44.getWrappedField();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(durationFieldType39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 52L + "'", long47 == 52L);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "DurationField[years]" + "'", str48.equals("DurationField[years]"));
        org.junit.Assert.assertNotNull(durationField49);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        boolean boolean11 = unsupportedDurationField10.isSupported();
        org.joda.time.DurationFieldType durationFieldType12 = unsupportedDurationField10.getType();
        boolean boolean13 = unsupportedDurationField10.isSupported();
        java.lang.String str14 = unsupportedDurationField10.toString();
        long long15 = unsupportedDurationField10.getUnitMillis();
        boolean boolean16 = unsupportedDurationField10.isPrecise();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UnsupportedDurationField[days]" + "'", str14.equals("UnsupportedDurationField[days]"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("PeriodType[Years]");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(permissionCollection2);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        long long10 = durationField7.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period15 = period14.toPeriod();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) '4', chronology18);
        org.joda.time.Period period21 = period19.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType24 = periodType22.getFieldType((int) (short) 0);
        boolean boolean25 = period14.isSupported(durationFieldType24);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType24, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField29 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType24, (int) (short) 100);
        long long31 = scaledDurationField29.getValueAsLong((long) 68);
        long long34 = scaledDurationField29.getDifferenceAsLong(220L, (long) 'a');
        long long36 = scaledDurationField29.getMillis((long) (-3491999));
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-30170871360000000L) + "'", long36 == (-30170871360000000L));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.Period period1 = org.joda.time.Period.months(100);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) '4', chronology6);
        org.joda.time.Period period8 = period7.toPeriod();
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType15 = period14.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType17 = periodType15.getFieldType((int) (short) 0);
        boolean boolean18 = period7.isSupported(durationFieldType17);
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(durationFieldType17, (java.lang.Number) 4, (java.lang.Number) 1L, (java.lang.Number) 2L);
        boolean boolean23 = period1.isSupported(durationFieldType17);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField24 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        try {
            long long27 = unsupportedDurationField24.getMillis(4, (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField24);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        boolean boolean11 = unsupportedDurationField10.isSupported();
        org.joda.time.DurationFieldType durationFieldType12 = unsupportedDurationField10.getType();
        boolean boolean13 = unsupportedDurationField10.isSupported();
        try {
            long long16 = unsupportedDurationField10.add((-5044L), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: days field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(durationFieldType8, "UTC");
        illegalFieldValueException11.prependMessage("PT-1M-0.001S");
        illegalFieldValueException11.prependMessage("LenientChronology[ISOChronology[UTC]]");
        java.lang.Number number16 = illegalFieldValueException11.getIllegalNumberValue();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNull(number16);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', chronology7);
        org.joda.time.Period period10 = period8.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType((int) (short) 0);
        boolean boolean14 = period3.isSupported(durationFieldType13);
        org.joda.time.field.PreciseDurationField preciseDurationField16 = new org.joda.time.field.PreciseDurationField(durationFieldType13, (long) '4');
        org.joda.time.Period period17 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval19 = null;
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval19);
        org.joda.time.Period period21 = new org.joda.time.Period((long) '4', chronology20);
        org.joda.time.Period period23 = period21.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType24 = period23.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType26 = periodType24.getFieldType((int) (short) 0);
        org.joda.time.Period period28 = period17.withField(durationFieldType26, (int) (short) 0);
        org.joda.time.Period period30 = period17.withWeeks((-1));
        org.joda.time.ReadableInterval readableInterval32 = null;
        org.joda.time.Chronology chronology33 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) '4', chronology33);
        org.joda.time.Period period36 = period34.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType37 = period36.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType39 = periodType37.getFieldType((int) (short) 0);
        org.joda.time.Period period41 = period30.withField(durationFieldType39, (int) (short) -1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(durationFieldType39, "Weeks");
        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) preciseDurationField16, durationFieldType39);
        long long47 = decoratedDurationField44.add((long) 100, (int) (byte) 100);
        boolean boolean48 = decoratedDurationField44.isPrecise();
        long long51 = decoratedDurationField44.getMillis((int) (short) 10, 5042L);
        long long54 = decoratedDurationField44.getMillis((-84L), (long) 70);
        long long56 = decoratedDurationField44.getMillis((int) (short) 100);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(durationFieldType39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 5300L + "'", long47 == 5300L);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 520L + "'", long51 == 520L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-4368L) + "'", long54 == (-4368L));
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 5200L + "'", long56 == 5200L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        long long10 = durationField7.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period15 = period14.toPeriod();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) '4', chronology18);
        org.joda.time.Period period21 = period19.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType24 = periodType22.getFieldType((int) (short) 0);
        boolean boolean25 = period14.isSupported(durationFieldType24);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType24, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField29 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType24, (int) (short) 100);
        long long31 = scaledDurationField29.getValueAsLong((long) 68);
        long long34 = scaledDurationField29.getDifferenceAsLong(220L, (long) 'a');
        long long36 = scaledDurationField29.getMillis(0);
        try {
            long long39 = scaledDurationField29.getMillis(84412800000000L, (long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 8441280000000000 * 86400000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Period period5 = period4.normalizedStandard();
        org.joda.time.Period period7 = period4.withYears(10);
        org.joda.time.Period period9 = period7.withWeeks((-1));
        org.joda.time.MutablePeriod mutablePeriod10 = period9.toMutablePeriod();
        int int11 = period9.size();
        try {
            org.joda.time.DurationFieldType durationFieldType13 = period9.getFieldType(23);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(mutablePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.DurationFieldType durationFieldType2 = null;
        boolean boolean3 = periodType1.isSupported(durationFieldType2);
        boolean boolean5 = periodType1.equals((java.lang.Object) 100);
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.Period period9 = new org.joda.time.Period((long) '4', chronology8);
        org.joda.time.Period period10 = new org.joda.time.Period(0L, periodType1, chronology8);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period15 = period14.toPeriod();
        int int16 = period14.getMillis();
        org.joda.time.Period period18 = period14.minusYears((int) ' ');
        org.joda.time.Period period20 = period18.plusDays((int) 'a');
        org.joda.time.Period period22 = period18.withMillis(100);
        boolean boolean23 = org.joda.time.field.FieldUtils.equals((java.lang.Object) periodType1, (java.lang.Object) period18);
        org.joda.time.ReadableInterval readableInterval25 = null;
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval25);
        org.joda.time.Period period27 = new org.joda.time.Period((long) '4', chronology26);
        org.joda.time.Period period29 = period27.plusMillis(1);
        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        int int33 = period27.indexOf(durationFieldType32);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField34 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType32);
        boolean boolean35 = period18.isSupported(durationFieldType32);
        org.joda.time.PeriodType periodType36 = null;
        org.joda.time.Period period37 = period18.withPeriodType(periodType36);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 52 + "'", int16 == 52);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 3 + "'", int33 == 3);
        org.junit.Assert.assertNotNull(unsupportedDurationField34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(period37);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.clockhourOfDay();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology6);
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 1, periodType3, (org.joda.time.Chronology) iSOChronology6);
        org.joda.time.Period period10 = new org.joda.time.Period(1560628908182L, (long) (-1), (org.joda.time.Chronology) iSOChronology6);
        java.lang.String str11 = iSOChronology6.toString();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[UTC]" + "'", str11.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period6 = period4.withYears((int) (short) 10);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period4.toDurationFrom(readableInstant7);
        org.joda.time.Period period10 = org.joda.time.Period.months(100);
        int int11 = period10.getMonths();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        org.joda.time.Period period18 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.Period period19 = new org.joda.time.Period((long) (byte) 1, periodType13, (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.PeriodType periodType20 = periodType13.withYearsRemoved();
        boolean boolean21 = period10.equals((java.lang.Object) periodType13);
        org.joda.time.Period period22 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration8, periodType13);
        long long23 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration8);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 52L + "'", long23 == 52L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((-61054729675996L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1733936L + "'", long1 == 1733936L);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (short) -1);
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) '4', chronology4);
        org.joda.time.Period period7 = period5.plusMillis(1);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType10 = periodType8.getFieldType((int) (short) 0);
        int int11 = period5.indexOf(durationFieldType10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(durationFieldType10, "UTC");
        org.joda.time.Period period15 = period1.withFieldAdded(durationFieldType10, (int) '4');
        org.joda.time.field.PreciseDurationField preciseDurationField17 = new org.joda.time.field.PreciseDurationField(durationFieldType10, (long) (-100));
        long long19 = preciseDurationField17.getMillis((long) 3);
        long long21 = preciseDurationField17.getValueAsLong(52L);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-300L) + "'", long19 == (-300L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 1, periodType1, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DurationField durationField8 = iSOChronology4.seconds();
        org.joda.time.chrono.LenientChronology lenientChronology9 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology4);
        long long13 = lenientChronology9.add(0L, 2440578L, 100);
        java.lang.String str14 = lenientChronology9.toString();
        org.joda.time.DurationField durationField15 = lenientChronology9.hours();
        org.joda.time.DateTimeField dateTimeField16 = lenientChronology9.dayOfMonth();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(lenientChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 244057800L + "'", long13 == 244057800L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str14.equals("LenientChronology[ISOChronology[UTC]]"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withWeeksRemoved();
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType3 = periodType0.withDaysRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        java.lang.String str5 = periodType4.getName();
        java.lang.String str6 = periodType4.toString();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DayTime" + "'", str5.equals("DayTime"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PeriodType[DayTime]" + "'", str6.equals("PeriodType[DayTime]"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        java.lang.String str5 = lenientChronology4.toString();
        org.joda.time.DateTimeField dateTimeField6 = lenientChronology4.millisOfSecond();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str5.equals("LenientChronology[ISOChronology[UTC]]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.Period period2 = new org.joda.time.Period((-4368L), (long) 1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType6 = period5.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField10 = new org.joda.time.field.PreciseDurationField(durationFieldType8, (long) (byte) 100);
        long long13 = preciseDurationField10.getValueAsLong(0L, (long) 10);
        long long16 = preciseDurationField10.subtract((long) 100, (long) (short) 0);
        long long19 = preciseDurationField10.getDifferenceAsLong((-4368L), (long) (-3491999));
        long long22 = preciseDurationField10.getValueAsLong((-52L), (-359999000L));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 34876L + "'", long19 == 34876L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(3);
        int int2 = period1.getWeeks();
        java.lang.String str3 = period1.toString();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PT3S" + "'", str3.equals("PT3S"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) (byte) -1, ' ', (int) (byte) 100, (int) ' ', 0, false, (-32));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.setFixedSavings("Coordinated Universal Time", (int) (short) 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder0.setFixedSavings("LenientChronology[ZonedChronology[ISOChronology[UTC], UTC]]", (-1248000));
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType6 = period5.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField10 = new org.joda.time.field.PreciseDurationField(durationFieldType8, (long) (byte) 100);
        java.lang.String str11 = preciseDurationField10.getName();
        long long12 = preciseDurationField10.getUnitMillis();
        long long15 = preciseDurationField10.add((-301624300800000000L), (long) 349200000);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "years" + "'", str11.equals("years"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-301624265880000000L) + "'", long15 == (-301624265880000000L));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        long long10 = durationField7.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period15 = period14.toPeriod();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) '4', chronology18);
        org.joda.time.Period period21 = period19.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType24 = periodType22.getFieldType((int) (short) 0);
        boolean boolean25 = period14.isSupported(durationFieldType24);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType24, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField29 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType24, (int) (short) 100);
        long long31 = scaledDurationField29.getValueAsLong((long) 68);
        long long34 = scaledDurationField29.getDifferenceAsLong(220L, (long) 'a');
        long long37 = scaledDurationField29.getValueAsLong((long) 52, 0L);
        long long39 = scaledDurationField29.getMillis((int) (byte) -1);
        long long42 = scaledDurationField29.getMillis((long) (short) 100, 0L);
        long long44 = scaledDurationField29.getMillis(0);
        org.joda.time.DurationField durationField45 = scaledDurationField29.getWrappedField();
        int int48 = scaledDurationField29.getDifference(1L, (-5044L));
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-8640000000L) + "'", long39 == (-8640000000L));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 864000000000L + "'", long42 == 864000000000L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) '4', chronology5);
        org.joda.time.Period period7 = period6.toPeriod();
        int int8 = period6.getMillis();
        org.joda.time.Period period10 = period6.minusYears((int) ' ');
        int[] intArray12 = iSOChronology1.get((org.joda.time.ReadablePeriod) period10, (long) (short) 0);
        org.joda.time.DurationField durationField13 = iSOChronology1.years();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology1.hourOfHalfday();
        org.joda.time.Period period16 = new org.joda.time.Period(800L, (org.joda.time.Chronology) iSOChronology1);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', chronology7);
        org.joda.time.Period period10 = period8.withYears((int) (short) 10);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period8.toDurationFrom(readableInstant11);
        org.joda.time.Period period13 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) '4', chronology16);
        org.joda.time.Period period19 = period17.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType20 = period19.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType22 = periodType20.getFieldType((int) (short) 0);
        org.joda.time.Period period24 = period13.withField(durationFieldType22, (int) (short) 0);
        org.joda.time.Period period26 = period13.withWeeks((-1));
        org.joda.time.ReadableInterval readableInterval28 = null;
        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval28);
        org.joda.time.Period period30 = new org.joda.time.Period((long) '4', chronology29);
        org.joda.time.Period period32 = period30.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType33 = period32.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType35 = periodType33.getFieldType((int) (short) 0);
        org.joda.time.Period period37 = period26.withField(durationFieldType35, (int) (short) -1);
        org.joda.time.Period period39 = period8.withField(durationFieldType35, 0);
        int[] intArray41 = iSOChronology2.get((org.joda.time.ReadablePeriod) period39, (long) (short) 1);
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology2.weekOfWeekyear();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(durationFieldType35);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(dateTimeField42);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        int int5 = period3.getMillis();
        org.joda.time.Period period7 = period3.minusYears((int) ' ');
        org.joda.time.Period period9 = period7.plusDays((int) 'a');
        org.joda.time.Period period11 = period7.withMillis(100);
        org.joda.time.Period period13 = period7.withYears((-100));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Period period5 = period4.normalizedStandard();
        org.joda.time.Period period7 = period4.withYears(10);
        org.joda.time.format.PeriodFormatter periodFormatter8 = null;
        java.lang.String str9 = period4.toString(periodFormatter8);
        org.joda.time.Seconds seconds10 = period4.toStandardSeconds();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PT-0.065S" + "'", str9.equals("PT-0.065S"));
        org.junit.Assert.assertNotNull(seconds10);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.weekyearOfCentury();
        boolean boolean5 = jodaTimePermission1.equals((java.lang.Object) dateTimeField4);
        java.lang.String str6 = jodaTimePermission1.getActions();
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType9 = periodType8.withSecondsRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.clockhourOfDay();
        boolean boolean13 = iSOChronology10.equals((java.lang.Object) (-1.0f));
        org.joda.time.DateTimeZone dateTimeZone14 = iSOChronology10.getZone();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (byte) -1, periodType9, (org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology10.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology10.hourOfHalfday();
        boolean boolean18 = jodaTimePermission1.equals((java.lang.Object) iSOChronology10);
        try {
            long long24 = iSOChronology10.getDateTimeMillis(2440578L, (int) (short) 100, 70, 68, 8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        long long9 = offsetDateTimeField7.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial10 = null;
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField7.getAsText(readablePartial10, 0, locale12);
        int int14 = offsetDateTimeField7.getMaximumValue();
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField7.getAsShortText(100, locale16);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 23 + "'", int14 == 23);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100" + "'", str17.equals("100"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 100, periodType4, chronology6);
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) 100);
        org.joda.time.IllegalInstantException illegalInstantException10 = new org.joda.time.IllegalInstantException("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        boolean boolean11 = gregorianChronology0.equals((java.lang.Object) illegalInstantException10);
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology0.year();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        int int5 = period3.getMillis();
        org.joda.time.Period period7 = period3.minusYears((int) ' ');
        org.joda.time.Period period9 = period7.plusDays((int) 'a');
        org.joda.time.Period period10 = period7.negated();
        org.joda.time.Period period12 = period10.withSeconds(10);
        org.joda.time.Period period14 = period10.plusWeeks(0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(70);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("org.joda.time.IllegalFieldValueException: Coordinated Universal Time: Value 0 for org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0] must be in the range [100,10.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"org.joda.time.IllegalFieldValueE...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        org.joda.time.DurationField durationField8 = offsetDateTimeField7.getLeapDurationField();
        long long11 = offsetDateTimeField7.add(10L, 1);
        int int13 = offsetDateTimeField7.getLeapAmount(14159997L);
        java.util.Locale locale14 = null;
        int int15 = offsetDateTimeField7.getMaximumTextLength(locale14);
        org.joda.time.DurationField durationField16 = offsetDateTimeField7.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial17 = null;
        org.joda.time.Period period19 = org.joda.time.Period.seconds((int) (short) -1);
        org.joda.time.ReadableInterval readableInterval21 = null;
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval21);
        org.joda.time.Period period23 = new org.joda.time.Period((long) '4', chronology22);
        org.joda.time.Period period25 = period23.plusMillis(1);
        org.joda.time.PeriodType periodType26 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType28 = periodType26.getFieldType((int) (short) 0);
        int int29 = period23.indexOf(durationFieldType28);
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(durationFieldType28, "UTC");
        org.joda.time.Period period33 = period19.withFieldAdded(durationFieldType28, (int) '4');
        int[] intArray34 = period19.getValues();
        int int35 = offsetDateTimeField7.getMinimumValue(readablePartial17, intArray34);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3600010L + "'", long11 == 3600010L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertNull(durationField16);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 3 + "'", int29 == 3);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        boolean boolean11 = unsupportedDurationField10.isSupported();
        org.joda.time.DurationFieldType durationFieldType12 = unsupportedDurationField10.getType();
        boolean boolean13 = unsupportedDurationField10.isSupported();
        long long14 = unsupportedDurationField10.getUnitMillis();
        org.joda.time.DurationFieldType durationFieldType15 = unsupportedDurationField10.getType();
        try {
            long long18 = unsupportedDurationField10.getDifferenceAsLong(2440578L, (long) (-131));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: days field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(durationFieldType15);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        long long26 = zonedChronology5.add(2440588L, 0L, 0);
        org.joda.time.DateTimeField dateTimeField27 = zonedChronology5.minuteOfDay();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2440588L + "'", long26 == 2440588L);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (-21814753846L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1885005599054400000L) + "'", long1 == (-1885005599054400000L));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]", (java.lang.Number) (short) 0, (java.lang.Number) (short) 100, (java.lang.Number) 10.0d);
        illegalFieldValueException4.prependMessage("Coordinated Universal Time");
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 1, (java.lang.Number) 100, (java.lang.Number) 10.0d);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]", (java.lang.Number) (short) 0, (java.lang.Number) (short) 100, (java.lang.Number) 10.0d);
        illegalFieldValueException11.addSuppressed((java.lang.Throwable) illegalFieldValueException16);
        java.lang.String str18 = illegalFieldValueException16.toString();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 0 for org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0] must be in the range [100,10.0]" + "'", str18.equals("org.joda.time.IllegalFieldValueException: Value 0 for org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0] must be in the range [100,10.0]"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        org.joda.time.DurationField durationField8 = offsetDateTimeField7.getLeapDurationField();
        long long11 = offsetDateTimeField7.add(10L, 1);
        int int13 = offsetDateTimeField7.getLeapAmount(14159997L);
        java.util.Locale locale14 = null;
        int int15 = offsetDateTimeField7.getMaximumTextLength(locale14);
        java.lang.String str16 = offsetDateTimeField7.toString();
        long long18 = offsetDateTimeField7.roundHalfEven((-3468L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3600010L + "'", long11 == 3600010L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DateTimeField[clockhourOfDay]" + "'", str16.equals("DateTimeField[clockhourOfDay]"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("PeriodType[Weeks]");
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (short) 1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.clockhourOfDay();
        org.joda.time.Period period9 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology7);
        org.joda.time.Period period10 = new org.joda.time.Period((long) (byte) 1, periodType4, (org.joda.time.Chronology) iSOChronology7);
        org.joda.time.PeriodType periodType11 = periodType4.withYearsRemoved();
        int int12 = periodType11.size();
        boolean boolean13 = gregorianChronology0.equals((java.lang.Object) int12);
        org.joda.time.ReadableInterval readableInterval15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) '4', chronology16);
        org.joda.time.Period period18 = period17.toPeriod();
        int int19 = period17.getMillis();
        org.joda.time.Period period21 = period17.minusYears((int) ' ');
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.Duration duration23 = period17.toDurationFrom(readableInstant22);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration23, readableInstant24);
        boolean boolean26 = gregorianChronology0.equals((java.lang.Object) period25);
        org.joda.time.DateTimeZone dateTimeZone27 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 52 + "'", int19 == 52);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTimeZone27);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) '4', chronology5);
        org.joda.time.Period period7 = period6.toPeriod();
        int int8 = period6.getMillis();
        org.joda.time.Period period10 = period6.minusYears((int) ' ');
        int[] intArray12 = iSOChronology1.get((org.joda.time.ReadablePeriod) period10, (long) (short) 0);
        org.joda.time.Period period13 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) '4', chronology16);
        org.joda.time.Period period19 = period17.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType20 = period19.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType22 = periodType20.getFieldType((int) (short) 0);
        org.joda.time.Period period24 = period13.withField(durationFieldType22, (int) (short) 0);
        org.joda.time.Period period26 = period13.withWeeks((-1));
        org.joda.time.Period period27 = period10.minus((org.joda.time.ReadablePeriod) period13);
        org.joda.time.Period period29 = period27.minusMinutes(8);
        int[] intArray31 = iSOChronology0.get((org.joda.time.ReadablePeriod) period29, 70L);
        org.joda.time.chrono.LenientChronology lenientChronology32 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology33.clockhourOfDay();
        org.joda.time.ReadableInterval readableInterval36 = null;
        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
        org.joda.time.Period period38 = new org.joda.time.Period((long) '4', chronology37);
        org.joda.time.Period period39 = period38.toPeriod();
        int int40 = period38.getMillis();
        org.joda.time.Period period42 = period38.minusYears((int) ' ');
        int[] intArray44 = iSOChronology33.get((org.joda.time.ReadablePeriod) period42, (long) (short) 0);
        org.joda.time.Period period45 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval47 = null;
        org.joda.time.Chronology chronology48 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval47);
        org.joda.time.Period period49 = new org.joda.time.Period((long) '4', chronology48);
        org.joda.time.Period period51 = period49.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType52 = period51.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType54 = periodType52.getFieldType((int) (short) 0);
        org.joda.time.Period period56 = period45.withField(durationFieldType54, (int) (short) 0);
        org.joda.time.Period period58 = period45.withWeeks((-1));
        org.joda.time.Period period59 = period42.minus((org.joda.time.ReadablePeriod) period45);
        org.joda.time.Period period61 = period59.minusMinutes(8);
        boolean boolean62 = lenientChronology32.equals((java.lang.Object) 8);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(lenientChronology32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 52 + "'", int40 == 52);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertNotNull(periodType52);
        org.junit.Assert.assertNotNull(durationFieldType54);
        org.junit.Assert.assertNotNull(period56);
        org.junit.Assert.assertNotNull(period58);
        org.junit.Assert.assertNotNull(period59);
        org.junit.Assert.assertNotNull(period61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 0, (-359999000L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 100, periodType4, chronology6);
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) 100);
        org.joda.time.IllegalInstantException illegalInstantException10 = new org.joda.time.IllegalInstantException("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        boolean boolean11 = gregorianChronology0.equals((java.lang.Object) illegalInstantException10);
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        int int14 = gregorianChronology13.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.clockhourOfDay();
        org.joda.time.Period period9 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology7);
        org.joda.time.Period period10 = new org.joda.time.Period((long) (byte) 1, periodType4, (org.joda.time.Chronology) iSOChronology7);
        org.joda.time.PeriodType periodType11 = periodType4.withYearsRemoved();
        int int12 = periodType11.size();
        boolean boolean13 = gregorianChronology0.equals((java.lang.Object) int12);
        org.joda.time.ReadableInterval readableInterval15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) '4', chronology16);
        org.joda.time.Period period18 = period17.toPeriod();
        int int19 = period17.getMillis();
        org.joda.time.Period period21 = period17.minusYears((int) ' ');
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.Duration duration23 = period17.toDurationFrom(readableInstant22);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration23, readableInstant24);
        boolean boolean26 = gregorianChronology0.equals((java.lang.Object) period25);
        java.lang.Object obj27 = null;
        boolean boolean28 = gregorianChronology0.equals(obj27);
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology0.era();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 52 + "'", int19 == 52);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTimeField29);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.Chronology chronology24 = zonedChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology5.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str28 = dateTimeZone27.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology26, dateTimeZone27);
        org.joda.time.chrono.LenientChronology lenientChronology30 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (-1));
        long long35 = offsetDateTimeField33.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField33.getAsText(readablePartial36, 0, locale38);
        long long42 = offsetDateTimeField33.add(220L, 68);
        int int44 = offsetDateTimeField33.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField33.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType45);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology49.clockhourOfDay();
        org.joda.time.Period period51 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.DurationField durationField52 = iSOChronology49.millis();
        org.joda.time.DurationField durationField53 = iSOChronology49.weeks();
        org.joda.time.DurationField durationField54 = iSOChronology49.days();
        long long57 = durationField54.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval59 = null;
        org.joda.time.Chronology chronology60 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval59);
        org.joda.time.Period period61 = new org.joda.time.Period((long) '4', chronology60);
        org.joda.time.Period period62 = period61.toPeriod();
        org.joda.time.ReadableInterval readableInterval64 = null;
        org.joda.time.Chronology chronology65 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval64);
        org.joda.time.Period period66 = new org.joda.time.Period((long) '4', chronology65);
        org.joda.time.Period period68 = period66.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType69 = period68.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType71 = periodType69.getFieldType((int) (short) 0);
        boolean boolean72 = period61.isSupported(durationFieldType71);
        org.joda.time.field.PreciseDurationField preciseDurationField74 = new org.joda.time.field.PreciseDurationField(durationFieldType71, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField76 = new org.joda.time.field.ScaledDurationField(durationField54, durationFieldType71, (int) (short) 100);
        long long78 = scaledDurationField76.getValueAsLong((long) 68);
        long long80 = scaledDurationField76.getMillis(52);
        int int81 = scaledDurationField76.getScalar();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField82 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType45, (org.joda.time.DurationField) scaledDurationField76);
        try {
            long long84 = unsupportedDateTimeField82.remainder(520L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(lenientChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 244800220L + "'", long42 == 244800220L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(durationField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 10L + "'", long57 == 10L);
        org.junit.Assert.assertNotNull(chronology60);
        org.junit.Assert.assertNotNull(period62);
        org.junit.Assert.assertNotNull(chronology65);
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertNotNull(periodType69);
        org.junit.Assert.assertNotNull(durationFieldType71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 449280000000L + "'", long80 == 449280000000L);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 100 + "'", int81 == 100);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField82);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((-58987094399903L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1757866.5000011227d + "'", double1 == 1757866.5000011227d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 1, (java.lang.Number) 100, (java.lang.Number) 10.0d);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100 + "'", number5.equals(100));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) '4', chronology4);
        org.joda.time.Period period7 = period5.withYears((int) (short) 10);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Duration duration9 = period5.toDurationFrom(readableInstant8);
        org.joda.time.Period period11 = org.joda.time.Period.months(100);
        int int12 = period11.getMonths();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.clockhourOfDay();
        org.joda.time.Period period19 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology17);
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) 1, periodType14, (org.joda.time.Chronology) iSOChronology17);
        org.joda.time.PeriodType periodType21 = periodType14.withYearsRemoved();
        boolean boolean22 = period11.equals((java.lang.Object) periodType14);
        org.joda.time.Period period23 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration9, periodType14);
        org.joda.time.PeriodType periodType24 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType25 = periodType24.withWeeksRemoved();
        org.joda.time.PeriodType periodType26 = periodType25.withMillisRemoved();
        org.joda.time.Period period27 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration9, periodType26);
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.PeriodType periodType29 = org.joda.time.PeriodType.standard();
        int int30 = periodType29.size();
        org.joda.time.Period period31 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration9, readableInstant28, periodType29);
        org.joda.time.PeriodType periodType32 = periodType29.withHoursRemoved();
        org.joda.time.PeriodType periodType33 = periodType32.withYearsRemoved();
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 8 + "'", int30 == 8);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(periodType33);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test174");
//        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.dayTime();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str6 = dateTimeZone5.getID();
//        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone8 = zonedChronology7.getZone();
//        java.lang.String str9 = zonedChronology7.toString();
//        org.joda.time.Period period10 = new org.joda.time.Period((long) 3, periodType3, (org.joda.time.Chronology) zonedChronology7);
//        org.joda.time.ReadableInterval readableInterval12 = null;
//        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
//        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
//        org.joda.time.Period period16 = period14.plusMillis(1);
//        java.lang.String str17 = period14.toString();
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.clockhourOfDay();
//        boolean boolean21 = iSOChronology18.equals((java.lang.Object) (-1.0f));
//        org.joda.time.Period period22 = new org.joda.time.Period((java.lang.Object) period14, (org.joda.time.Chronology) iSOChronology18);
//        int[] intArray24 = zonedChronology7.get((org.joda.time.ReadablePeriod) period22, (-1L));
//        org.joda.time.chrono.LenientChronology lenientChronology25 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology7);
//        org.joda.time.Period period26 = new org.joda.time.Period((long) 'a', (long) 0, (org.joda.time.Chronology) lenientChronology25);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str28 = dateTimeZone27.getID();
//        java.lang.String str29 = dateTimeZone27.getID();
//        java.util.TimeZone timeZone30 = dateTimeZone27.toTimeZone();
//        java.lang.String str32 = dateTimeZone27.getName((long) 3);
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
//        long long36 = dateTimeZone27.getMillisKeepLocal(dateTimeZone34, (long) (byte) 100);
//        org.joda.time.Chronology chronology37 = lenientChronology25.withZone(dateTimeZone27);
//        org.joda.time.DateTimeField dateTimeField38 = lenientChronology25.monthOfYear();
//        org.joda.time.Period period40 = org.joda.time.Period.seconds(1);
//        org.joda.time.Period period42 = period40.plusHours((-100));
//        boolean boolean43 = lenientChronology25.equals((java.lang.Object) period42);
//        long long51 = lenientChronology25.getDateTimeMillis((int) '#', 4, 3, 0, 52, 4, 4);
//        org.joda.time.DateTimeField dateTimeField52 = lenientChronology25.dayOfYear();
//        org.joda.time.DurationField durationField53 = lenientChronology25.eras();
//        org.junit.Assert.assertNotNull(periodType3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//        org.junit.Assert.assertNotNull(zonedChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str9.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PT0.052S" + "'", str17.equals("PT0.052S"));
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(intArray24);
//        org.junit.Assert.assertNotNull(lenientChronology25);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UTC" + "'", str29.equals("UTC"));
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Coordinated Universal Time" + "'", str32.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-349199900L) + "'", long36 == (-349199900L));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(period40);
//        org.junit.Assert.assertNotNull(period42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-61054729675996L) + "'", long51 == (-61054729675996L));
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(durationField53);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        int int5 = period3.getMillis();
        org.joda.time.Period period7 = period3.minusYears((int) ' ');
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Duration duration9 = period3.toDurationFrom(readableInstant8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration9, readableInstant10);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType14 = periodType13.withWeeksRemoved();
        org.joda.time.PeriodType periodType15 = periodType14.withMillisRemoved();
        org.joda.time.PeriodType periodType16 = org.joda.time.DateTimeUtils.getPeriodType(periodType15);
        org.joda.time.Period period17 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration9, readableInstant12, periodType16);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, (int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("1", false);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.Chronology chronology24 = zonedChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology5.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str28 = dateTimeZone27.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology26, dateTimeZone27);
        org.joda.time.chrono.LenientChronology lenientChronology30 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (-1));
        long long35 = offsetDateTimeField33.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField33.getAsText(readablePartial36, 0, locale38);
        long long42 = offsetDateTimeField33.add(220L, 68);
        int int44 = offsetDateTimeField33.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField33.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType45);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology49.clockhourOfDay();
        org.joda.time.Period period51 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.DurationField durationField52 = iSOChronology49.millis();
        org.joda.time.DurationField durationField53 = iSOChronology49.weeks();
        org.joda.time.DurationField durationField54 = iSOChronology49.days();
        long long57 = durationField54.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval59 = null;
        org.joda.time.Chronology chronology60 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval59);
        org.joda.time.Period period61 = new org.joda.time.Period((long) '4', chronology60);
        org.joda.time.Period period62 = period61.toPeriod();
        org.joda.time.ReadableInterval readableInterval64 = null;
        org.joda.time.Chronology chronology65 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval64);
        org.joda.time.Period period66 = new org.joda.time.Period((long) '4', chronology65);
        org.joda.time.Period period68 = period66.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType69 = period68.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType71 = periodType69.getFieldType((int) (short) 0);
        boolean boolean72 = period61.isSupported(durationFieldType71);
        org.joda.time.field.PreciseDurationField preciseDurationField74 = new org.joda.time.field.PreciseDurationField(durationFieldType71, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField76 = new org.joda.time.field.ScaledDurationField(durationField54, durationFieldType71, (int) (short) 100);
        long long78 = scaledDurationField76.getValueAsLong((long) 68);
        long long80 = scaledDurationField76.getMillis(52);
        int int81 = scaledDurationField76.getScalar();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField82 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType45, (org.joda.time.DurationField) scaledDurationField76);
        try {
            java.lang.String str84 = unsupportedDateTimeField82.getAsShortText(1560628908182L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(lenientChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 244800220L + "'", long42 == 244800220L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(durationField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 10L + "'", long57 == 10L);
        org.junit.Assert.assertNotNull(chronology60);
        org.junit.Assert.assertNotNull(period62);
        org.junit.Assert.assertNotNull(chronology65);
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertNotNull(periodType69);
        org.junit.Assert.assertNotNull(durationFieldType71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 449280000000L + "'", long80 == 449280000000L);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 100 + "'", int81 == 100);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField82);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long4 = cachedDateTimeZone2.nextTransition((long) (-32));
        int int6 = cachedDateTimeZone2.getStandardOffset((long) 68);
        boolean boolean7 = cachedDateTimeZone2.isFixed();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-32L) + "'", long4 == (-32L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 349200000 + "'", int6 == 349200000);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        int int5 = period3.getMillis();
        org.joda.time.Period period7 = period3.minusYears((int) ' ');
        org.joda.time.Period period9 = period7.plusDays((int) 'a');
        org.joda.time.Period period10 = period7.negated();
        org.joda.time.Period period12 = period10.withSeconds(10);
        org.joda.time.Period period13 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) '4', chronology16);
        org.joda.time.Period period19 = period17.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType20 = period19.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType22 = periodType20.getFieldType((int) (short) 0);
        org.joda.time.Period period24 = period13.withField(durationFieldType22, (int) (short) 0);
        org.joda.time.Period period26 = period10.withField(durationFieldType22, (int) (byte) -1);
        org.joda.time.Period period27 = period26.toPeriod();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period27);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        long long10 = durationField7.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period15 = period14.toPeriod();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) '4', chronology18);
        org.joda.time.Period period21 = period19.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType24 = periodType22.getFieldType((int) (short) 0);
        boolean boolean25 = period14.isSupported(durationFieldType24);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType24, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField29 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType24, (int) (short) 100);
        long long31 = scaledDurationField29.getValueAsLong((long) 68);
        long long34 = scaledDurationField29.getDifferenceAsLong(220L, (long) 'a');
        long long37 = scaledDurationField29.getValueAsLong((long) 52, 0L);
        long long39 = scaledDurationField29.getMillis((int) (byte) -1);
        int int41 = scaledDurationField29.getValue((-1134367200000L));
        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField45 = iSOChronology44.clockhourOfDay();
        org.joda.time.Period period46 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology44);
        org.joda.time.DurationField durationField47 = iSOChronology44.millis();
        org.joda.time.DurationField durationField48 = iSOChronology44.weeks();
        org.joda.time.DurationField durationField49 = iSOChronology44.days();
        long long52 = durationField49.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval54 = null;
        org.joda.time.Chronology chronology55 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval54);
        org.joda.time.Period period56 = new org.joda.time.Period((long) '4', chronology55);
        org.joda.time.Period period57 = period56.toPeriod();
        org.joda.time.ReadableInterval readableInterval59 = null;
        org.joda.time.Chronology chronology60 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval59);
        org.joda.time.Period period61 = new org.joda.time.Period((long) '4', chronology60);
        org.joda.time.Period period63 = period61.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType64 = period63.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType66 = periodType64.getFieldType((int) (short) 0);
        boolean boolean67 = period56.isSupported(durationFieldType66);
        org.joda.time.field.PreciseDurationField preciseDurationField69 = new org.joda.time.field.PreciseDurationField(durationFieldType66, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField71 = new org.joda.time.field.ScaledDurationField(durationField49, durationFieldType66, (int) (short) 100);
        long long73 = scaledDurationField71.getValueAsLong((long) 68);
        long long75 = scaledDurationField71.getMillis(52);
        long long78 = scaledDurationField71.getDifferenceAsLong((-84L), (-34919990L));
        long long81 = scaledDurationField71.getValueAsLong((long) (byte) -1, (long) (-180));
        int int82 = scaledDurationField29.compareTo((org.joda.time.DurationField) scaledDurationField71);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-8640000000L) + "'", long39 == (-8640000000L));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-131) + "'", int41 == (-131));
        org.junit.Assert.assertNotNull(iSOChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 10L + "'", long52 == 10L);
        org.junit.Assert.assertNotNull(chronology55);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertNotNull(chronology60);
        org.junit.Assert.assertNotNull(period63);
        org.junit.Assert.assertNotNull(periodType64);
        org.junit.Assert.assertNotNull(durationFieldType66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 0L + "'", long73 == 0L);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 449280000000L + "'", long75 == 449280000000L);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 0L + "'", long81 == 0L);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.clockhourOfDay();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology10);
        org.joda.time.Period period13 = new org.joda.time.Period((long) (byte) 1, periodType7, (org.joda.time.Chronology) iSOChronology10);
        org.joda.time.PeriodType periodType14 = periodType7.withYearsRemoved();
        int int15 = periodType7.size();
        java.lang.String str16 = periodType7.getName();
        try {
            org.joda.time.Period period17 = period3.withPeriodType(periodType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'millis'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Weeks" + "'", str16.equals("Weeks"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.withYears((int) (short) 10);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period3.toDurationFrom(readableInstant6);
        org.joda.time.Period period8 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType15 = period14.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType17 = periodType15.getFieldType((int) (short) 0);
        org.joda.time.Period period19 = period8.withField(durationFieldType17, (int) (short) 0);
        org.joda.time.Period period21 = period8.withWeeks((-1));
        org.joda.time.ReadableInterval readableInterval23 = null;
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval23);
        org.joda.time.Period period25 = new org.joda.time.Period((long) '4', chronology24);
        org.joda.time.Period period27 = period25.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType28 = period27.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType30 = periodType28.getFieldType((int) (short) 0);
        org.joda.time.Period period32 = period21.withField(durationFieldType30, (int) (short) -1);
        org.joda.time.Period period34 = period3.withField(durationFieldType30, 0);
        org.joda.time.field.PreciseDurationField preciseDurationField36 = new org.joda.time.field.PreciseDurationField(durationFieldType30, 508040L);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(period34);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = zonedChronology3.getZone();
        boolean boolean6 = dateTimeZone4.isStandardOffset(34876L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 1, periodType1, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DurationField durationField8 = iSOChronology4.seconds();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology4.year();
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.clockhourOfDay();
        org.joda.time.Period period14 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology12);
        org.joda.time.Period period15 = period14.normalizedStandard();
        org.joda.time.Period period16 = period14.toPeriod();
        int[] intArray19 = iSOChronology4.get((org.joda.time.ReadablePeriod) period16, 2440588L, 864000000004L);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(intArray19);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.Chronology chronology24 = zonedChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology5.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str28 = dateTimeZone27.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology26, dateTimeZone27);
        org.joda.time.chrono.LenientChronology lenientChronology30 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (-1));
        long long35 = offsetDateTimeField33.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField33.getAsText(readablePartial36, 0, locale38);
        long long42 = offsetDateTimeField33.add(220L, 68);
        int int44 = offsetDateTimeField33.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField33.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType45);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology49.clockhourOfDay();
        org.joda.time.Period period51 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.DurationField durationField52 = iSOChronology49.millis();
        org.joda.time.DurationField durationField53 = iSOChronology49.weeks();
        org.joda.time.DurationField durationField54 = iSOChronology49.days();
        long long57 = durationField54.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval59 = null;
        org.joda.time.Chronology chronology60 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval59);
        org.joda.time.Period period61 = new org.joda.time.Period((long) '4', chronology60);
        org.joda.time.Period period62 = period61.toPeriod();
        org.joda.time.ReadableInterval readableInterval64 = null;
        org.joda.time.Chronology chronology65 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval64);
        org.joda.time.Period period66 = new org.joda.time.Period((long) '4', chronology65);
        org.joda.time.Period period68 = period66.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType69 = period68.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType71 = periodType69.getFieldType((int) (short) 0);
        boolean boolean72 = period61.isSupported(durationFieldType71);
        org.joda.time.field.PreciseDurationField preciseDurationField74 = new org.joda.time.field.PreciseDurationField(durationFieldType71, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField76 = new org.joda.time.field.ScaledDurationField(durationField54, durationFieldType71, (int) (short) 100);
        long long78 = scaledDurationField76.getValueAsLong((long) 68);
        long long80 = scaledDurationField76.getMillis(52);
        int int81 = scaledDurationField76.getScalar();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField82 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType45, (org.joda.time.DurationField) scaledDurationField76);
        java.util.Locale locale84 = null;
        try {
            java.lang.String str85 = unsupportedDateTimeField82.getAsShortText(99916L, locale84);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(lenientChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 244800220L + "'", long42 == 244800220L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(durationField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 10L + "'", long57 == 10L);
        org.junit.Assert.assertNotNull(chronology60);
        org.junit.Assert.assertNotNull(period62);
        org.junit.Assert.assertNotNull(chronology65);
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertNotNull(periodType69);
        org.junit.Assert.assertNotNull(durationFieldType71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 449280000000L + "'", long80 == 449280000000L);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 100 + "'", int81 == 100);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField82);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(0L, 48L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-48L) + "'", long2 == (-48L));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        long long10 = durationField7.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period15 = period14.toPeriod();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) '4', chronology18);
        org.joda.time.Period period21 = period19.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType24 = periodType22.getFieldType((int) (short) 0);
        boolean boolean25 = period14.isSupported(durationFieldType24);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType24, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField29 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType24, (int) (short) 100);
        long long31 = scaledDurationField29.getValueAsLong((long) 68);
        long long34 = scaledDurationField29.getDifferenceAsLong(220L, (long) 'a');
        long long37 = scaledDurationField29.getValueAsLong((long) 52, 0L);
        long long39 = scaledDurationField29.getMillis((int) (byte) -1);
        long long42 = scaledDurationField29.getMillis((long) (short) 100, 0L);
        long long44 = scaledDurationField29.getMillis(0);
        boolean boolean45 = scaledDurationField29.isPrecise();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-8640000000L) + "'", long39 == (-8640000000L));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 864000000000L + "'", long42 == 864000000000L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', chronology7);
        org.joda.time.Period period10 = period8.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType((int) (short) 0);
        boolean boolean14 = period3.isSupported(durationFieldType13);
        org.joda.time.field.PreciseDurationField preciseDurationField16 = new org.joda.time.field.PreciseDurationField(durationFieldType13, (long) '4');
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant17, readableInstant18);
        org.joda.time.Period period21 = period19.minusMinutes(52);
        org.joda.time.DurationFieldType[] durationFieldTypeArray22 = period21.getFieldTypes();
        boolean boolean23 = preciseDurationField16.equals((java.lang.Object) durationFieldTypeArray22);
        java.lang.String str24 = preciseDurationField16.getName();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(durationFieldTypeArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "years" + "'", str24.equals("years"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.Chronology chronology24 = zonedChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology5.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str28 = dateTimeZone27.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology26, dateTimeZone27);
        org.joda.time.chrono.LenientChronology lenientChronology30 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (-1));
        long long35 = offsetDateTimeField33.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField33.getAsText(readablePartial36, 0, locale38);
        long long42 = offsetDateTimeField33.add(220L, 68);
        int int44 = offsetDateTimeField33.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField33.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType45);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology49.clockhourOfDay();
        org.joda.time.Period period51 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.DurationField durationField52 = iSOChronology49.millis();
        org.joda.time.DurationField durationField53 = iSOChronology49.weeks();
        org.joda.time.DurationField durationField54 = iSOChronology49.days();
        long long57 = durationField54.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval59 = null;
        org.joda.time.Chronology chronology60 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval59);
        org.joda.time.Period period61 = new org.joda.time.Period((long) '4', chronology60);
        org.joda.time.Period period62 = period61.toPeriod();
        org.joda.time.ReadableInterval readableInterval64 = null;
        org.joda.time.Chronology chronology65 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval64);
        org.joda.time.Period period66 = new org.joda.time.Period((long) '4', chronology65);
        org.joda.time.Period period68 = period66.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType69 = period68.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType71 = periodType69.getFieldType((int) (short) 0);
        boolean boolean72 = period61.isSupported(durationFieldType71);
        org.joda.time.field.PreciseDurationField preciseDurationField74 = new org.joda.time.field.PreciseDurationField(durationFieldType71, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField76 = new org.joda.time.field.ScaledDurationField(durationField54, durationFieldType71, (int) (short) 100);
        long long78 = scaledDurationField76.getValueAsLong((long) 68);
        long long80 = scaledDurationField76.getMillis(52);
        int int81 = scaledDurationField76.getScalar();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField82 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType45, (org.joda.time.DurationField) scaledDurationField76);
        java.util.Locale locale83 = null;
        try {
            int int84 = unsupportedDateTimeField82.getMaximumTextLength(locale83);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(lenientChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 244800220L + "'", long42 == 244800220L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(durationField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 10L + "'", long57 == 10L);
        org.junit.Assert.assertNotNull(chronology60);
        org.junit.Assert.assertNotNull(period62);
        org.junit.Assert.assertNotNull(chronology65);
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertNotNull(periodType69);
        org.junit.Assert.assertNotNull(durationFieldType71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 449280000000L + "'", long80 == 449280000000L);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 100 + "'", int81 == 100);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField82);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = zonedChronology3.getZone();
        java.lang.String str5 = zonedChronology3.toString();
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology3);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) zonedChronology3);
        long long13 = zonedChronology3.getDateTimeMillis(2L, 0, (int) '4', (int) (short) 1, 4);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3121004L + "'", long13 == 3121004L);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        int int6 = period4.getMillis();
        org.joda.time.Minutes minutes7 = period4.toStandardMinutes();
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) period4);
        java.lang.String str9 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
        org.junit.Assert.assertNotNull(minutes7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GregorianChronology[UTC]" + "'", str9.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.clockhourOfDay();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology6);
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 1, periodType3, (org.joda.time.Chronology) iSOChronology6);
        org.joda.time.Period period10 = new org.joda.time.Period(1560628908182L, (long) (-1), (org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology6.monthOfYear();
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology6);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        long long10 = durationField7.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period15 = period14.toPeriod();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) '4', chronology18);
        org.joda.time.Period period21 = period19.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType24 = periodType22.getFieldType((int) (short) 0);
        boolean boolean25 = period14.isSupported(durationFieldType24);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType24, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField29 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType24, (int) (short) 100);
        long long31 = scaledDurationField29.getValueAsLong((long) 68);
        long long34 = scaledDurationField29.getDifferenceAsLong(220L, (long) 'a');
        long long37 = scaledDurationField29.getValueAsLong((long) 52, 0L);
        long long39 = scaledDurationField29.getMillis((long) (-100));
        long long42 = scaledDurationField29.add(2440587L, (long) 23);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-864000000000L) + "'", long39 == (-864000000000L));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 198722440587L + "'", long42 == 198722440587L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "DayTime", 0, 10);
        int int6 = fixedDateTimeZone4.getStandardOffset((-210865896000000L));
        int int8 = fixedDateTimeZone4.getStandardOffset(156062890818200L);
        long long10 = fixedDateTimeZone4.nextTransition((-99999L));
        int int12 = fixedDateTimeZone4.getOffsetFromLocal(156062890818200L);
        long long14 = fixedDateTimeZone4.nextTransition((long) 'a');
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-99999L) + "'", long10 == (-99999L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        long long9 = offsetDateTimeField7.roundHalfFloor(2704L);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField7.getType();
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumTextLength(locale11);
        long long14 = offsetDateTimeField7.roundHalfEven(1560628908182L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560628800000L + "'", long14 == 1560628800000L);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 100, periodType4, chronology6);
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) 100);
        int int9 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.clockhourOfDay();
        org.joda.time.ReadableInterval readableInterval13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) '4', chronology14);
        org.joda.time.Period period16 = period15.toPeriod();
        int int17 = period15.getMillis();
        org.joda.time.Period period19 = period15.minusYears((int) ' ');
        int[] intArray21 = iSOChronology10.get((org.joda.time.ReadablePeriod) period19, (long) (short) 0);
        org.joda.time.Period period22 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval24 = null;
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval24);
        org.joda.time.Period period26 = new org.joda.time.Period((long) '4', chronology25);
        org.joda.time.Period period28 = period26.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType29 = period28.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType31 = periodType29.getFieldType((int) (short) 0);
        org.joda.time.Period period33 = period22.withField(durationFieldType31, (int) (short) 0);
        org.joda.time.Period period35 = period22.withWeeks((-1));
        org.joda.time.Period period36 = period19.minus((org.joda.time.ReadablePeriod) period22);
        org.joda.time.Period period38 = period36.minusMinutes(8);
        org.joda.time.Period period40 = period36.plusMillis((int) 'a');
        long long43 = gregorianChronology0.add((org.joda.time.ReadablePeriod) period40, 0L, (-32));
        org.joda.time.Period period45 = period40.withSeconds(10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 32314377595232L + "'", long43 == 32314377595232L);
        org.junit.Assert.assertNotNull(period45);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        java.lang.String str24 = lenientChronology23.toString();
        org.joda.time.DateTimeField dateTimeField25 = lenientChronology23.halfdayOfDay();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "LenientChronology[ZonedChronology[ISOChronology[UTC], UTC]]" + "'", str24.equals("LenientChronology[ZonedChronology[ISOChronology[UTC], UTC]]"));
        org.junit.Assert.assertNotNull(dateTimeField25);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period6 = period4.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType7 = period6.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (short) 0);
        org.joda.time.Period period11 = period0.withField(durationFieldType9, (int) (short) 0);
        org.joda.time.Period period13 = period0.withWeeks((-1));
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.clockhourOfDay();
        org.joda.time.Period period20 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology18);
        org.joda.time.Period period21 = new org.joda.time.Period((long) (byte) 1, periodType15, (org.joda.time.Chronology) iSOChronology18);
        org.joda.time.Period period22 = period0.withPeriodType(periodType15);
        org.joda.time.PeriodType periodType23 = period0.getPeriodType();
        org.joda.time.Period period25 = period0.withSeconds(10);
        org.joda.time.Period period27 = period0.withMinutes(68);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File[] fileArray2 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = zoneInfoCompiler0.compile(file1, fileArray2);
        java.io.File file4 = null;
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler5 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file6 = null;
        java.io.File[] fileArray7 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = zoneInfoCompiler5.compile(file6, fileArray7);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap9 = zoneInfoCompiler0.compile(file4, fileArray7);
        java.io.File file10 = null;
        java.io.File[] fileArray11 = null;
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap12 = zoneInfoCompiler0.compile(file10, fileArray11);
        org.junit.Assert.assertNotNull(fileArray2);
        org.junit.Assert.assertNotNull(strMap3);
        org.junit.Assert.assertNotNull(fileArray7);
        org.junit.Assert.assertNotNull(strMap8);
        org.junit.Assert.assertNotNull(strMap9);
        org.junit.Assert.assertNotNull(strMap12);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "Weeks", "Weeks");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "Weeks", "org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getName(locale9, "", "PT0S");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str3 = dateTimeZone2.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone2);
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        java.lang.String str6 = lenientChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology5.weekyearOfCentury();
        org.joda.time.Period period8 = new org.joda.time.Period(360000000L, (org.joda.time.Chronology) lenientChronology5);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str6.equals("LenientChronology[ISOChronology[UTC]]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant2, readableInstant3);
        org.joda.time.Period period6 = period4.minusMinutes(52);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period4.toDurationTo(readableInstant7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant9);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType((int) (short) 0);
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration8, periodType11);
        org.joda.time.PeriodType periodType15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration8, periodType15);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        org.joda.time.DurationField durationField8 = offsetDateTimeField7.getLeapDurationField();
        long long11 = offsetDateTimeField7.add(10L, 1);
        int int13 = offsetDateTimeField7.getLeapAmount(14159997L);
        java.util.Locale locale14 = null;
        int int15 = offsetDateTimeField7.getMaximumTextLength(locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        int int17 = offsetDateTimeField7.getMinimumValue(readablePartial16);
        org.joda.time.ReadablePartial readablePartial18 = null;
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField7.getAsText(readablePartial18, 0, locale20);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField7.getType();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3600010L + "'", long11 == 3600010L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Weeks", (java.lang.Number) (-30170871360000000L), (java.lang.Number) 32314377595232L, (java.lang.Number) 2445788L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 1, periodType1, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DurationField durationField8 = iSOChronology4.seconds();
        org.joda.time.DurationField durationField9 = iSOChronology4.hours();
        org.joda.time.DurationField durationField10 = iSOChronology4.minutes();
        org.joda.time.Period period12 = org.joda.time.Period.seconds(1);
        org.joda.time.Period period13 = period12.normalizedStandard();
        long long16 = iSOChronology4.add((org.joda.time.ReadablePeriod) period12, (-84L), (int) (short) 100);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology4.yearOfCentury();
        org.joda.time.ReadablePartial readablePartial18 = null;
        try {
            long long20 = iSOChronology4.set(readablePartial18, (-301624265880000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 99916L + "'", long16 == 99916L);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.Chronology chronology24 = zonedChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology5.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str28 = dateTimeZone27.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology26, dateTimeZone27);
        org.joda.time.chrono.LenientChronology lenientChronology30 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (-1));
        long long35 = offsetDateTimeField33.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField33.getAsText(readablePartial36, 0, locale38);
        long long42 = offsetDateTimeField33.add(220L, 68);
        int int44 = offsetDateTimeField33.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField33.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType45);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology49.clockhourOfDay();
        org.joda.time.Period period51 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.DurationField durationField52 = iSOChronology49.millis();
        org.joda.time.DurationField durationField53 = iSOChronology49.weeks();
        org.joda.time.DurationField durationField54 = iSOChronology49.days();
        long long57 = durationField54.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval59 = null;
        org.joda.time.Chronology chronology60 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval59);
        org.joda.time.Period period61 = new org.joda.time.Period((long) '4', chronology60);
        org.joda.time.Period period62 = period61.toPeriod();
        org.joda.time.ReadableInterval readableInterval64 = null;
        org.joda.time.Chronology chronology65 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval64);
        org.joda.time.Period period66 = new org.joda.time.Period((long) '4', chronology65);
        org.joda.time.Period period68 = period66.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType69 = period68.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType71 = periodType69.getFieldType((int) (short) 0);
        boolean boolean72 = period61.isSupported(durationFieldType71);
        org.joda.time.field.PreciseDurationField preciseDurationField74 = new org.joda.time.field.PreciseDurationField(durationFieldType71, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField76 = new org.joda.time.field.ScaledDurationField(durationField54, durationFieldType71, (int) (short) 100);
        long long78 = scaledDurationField76.getValueAsLong((long) 68);
        long long80 = scaledDurationField76.getMillis(52);
        int int81 = scaledDurationField76.getScalar();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField82 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType45, (org.joda.time.DurationField) scaledDurationField76);
        org.joda.time.ReadablePartial readablePartial83 = null;
        int[] intArray85 = null;
        try {
            int[] intArray87 = unsupportedDateTimeField82.set(readablePartial83, 1, intArray85, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(lenientChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 244800220L + "'", long42 == 244800220L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(durationField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 10L + "'", long57 == 10L);
        org.junit.Assert.assertNotNull(chronology60);
        org.junit.Assert.assertNotNull(period62);
        org.junit.Assert.assertNotNull(chronology65);
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertNotNull(periodType69);
        org.junit.Assert.assertNotNull(durationFieldType71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 449280000000L + "'", long80 == 449280000000L);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 100 + "'", int81 == 100);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField82);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.Chronology chronology24 = zonedChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology5.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str28 = dateTimeZone27.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology26, dateTimeZone27);
        org.joda.time.chrono.LenientChronology lenientChronology30 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (-1));
        long long35 = offsetDateTimeField33.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField33.getAsText(readablePartial36, 0, locale38);
        long long42 = offsetDateTimeField33.add(220L, 68);
        int int44 = offsetDateTimeField33.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField33.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType45);
        org.joda.time.DurationField durationField47 = zeroIsMaxDateTimeField46.getLeapDurationField();
        boolean boolean49 = zeroIsMaxDateTimeField46.isLeap((long) (-100));
        long long51 = zeroIsMaxDateTimeField46.roundHalfEven(3200L);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(lenientChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 244800220L + "'", long42 == 244800220L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNull(durationField47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.Chronology chronology4 = zonedChronology3.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(3599999L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.541666655d + "'", double1 == 2440587.541666655d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(2, (int) '#', 4, (int) '4');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 37 + "'", int4 == 37);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.Period period1 = org.joda.time.Period.millis((-32));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        java.lang.String str5 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance(chronology2, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology6.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology6.secondOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        int int5 = period3.getMillis();
        org.joda.time.DurationFieldType[] durationFieldTypeArray6 = period3.getFieldTypes();
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.forFields(durationFieldTypeArray6);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertNotNull(durationFieldTypeArray6);
        org.junit.Assert.assertNotNull(periodType7);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        org.joda.time.DurationField durationField8 = offsetDateTimeField7.getLeapDurationField();
        long long11 = offsetDateTimeField7.add(0L, (long) (short) 100);
        long long13 = offsetDateTimeField7.roundHalfCeiling(2L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 360000000L + "'", long11 == 360000000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.Chronology chronology24 = zonedChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology5.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str28 = dateTimeZone27.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology26, dateTimeZone27);
        org.joda.time.chrono.LenientChronology lenientChronology30 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (-1));
        long long35 = offsetDateTimeField33.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField33.getAsText(readablePartial36, 0, locale38);
        long long42 = offsetDateTimeField33.add(220L, 68);
        int int44 = offsetDateTimeField33.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField33.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType45);
        int int48 = zeroIsMaxDateTimeField46.getLeapAmount((-3468L));
        long long50 = zeroIsMaxDateTimeField46.roundHalfCeiling((-3L));
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(lenientChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 244800220L + "'", long42 == 244800220L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.era();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 1, periodType1, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DurationField durationField8 = iSOChronology4.seconds();
        org.joda.time.chrono.LenientChronology lenientChronology9 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology4);
        long long13 = lenientChronology9.add(0L, 2440578L, 100);
        org.joda.time.DurationField durationField14 = lenientChronology9.halfdays();
        org.joda.time.DurationField durationField15 = lenientChronology9.months();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(lenientChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 244057800L + "'", long13 == 244057800L);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withWeeksRemoved();
        java.lang.String str2 = periodType1.toString();
        org.joda.time.PeriodType periodType3 = periodType1.withYearsRemoved();
        boolean boolean5 = periodType1.equals((java.lang.Object) "ISOChronology[UTC]");
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PeriodType[DayTime]" + "'", str2.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone9 = iSOChronology2.getZone();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        try {
            int int7 = period3.getValue((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        long long9 = offsetDateTimeField7.roundHalfFloor(2704L);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField7.getType();
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField7.getAsText(10, locale12);
        long long15 = offsetDateTimeField7.roundHalfCeiling(520L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10" + "'", str13.equals("10"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.years();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.Period period9 = new org.joda.time.Period((long) '4', chronology8);
        org.joda.time.Period period11 = period9.plusMillis(1);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType14 = periodType12.getFieldType((int) (short) 0);
        int int15 = period9.indexOf(durationFieldType14);
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(durationFieldType14, "UTC");
        int int18 = periodType5.indexOf(durationFieldType14);
        org.joda.time.PeriodType periodType19 = periodType5.withMonthsRemoved();
        org.joda.time.Period period20 = period3.normalizedStandard(periodType5);
        org.joda.time.PeriodType periodType21 = org.joda.time.DateTimeUtils.getPeriodType(periodType5);
        org.joda.time.PeriodType periodType22 = periodType21.withMinutesRemoved();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "DayTime", 0, 10);
        int int6 = fixedDateTimeZone4.getStandardOffset((-210865896000000L));
        int int8 = fixedDateTimeZone4.getStandardOffset(156062890818200L);
        long long10 = fixedDateTimeZone4.nextTransition((-99999L));
        long long12 = fixedDateTimeZone4.nextTransition(0L);
        boolean boolean13 = fixedDateTimeZone4.isFixed();
        java.util.TimeZone timeZone14 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-99999L) + "'", long10 == (-99999L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(timeZone14);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', chronology7);
        org.joda.time.Period period10 = period8.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType((int) (short) 0);
        boolean boolean14 = period3.isSupported(durationFieldType13);
        org.joda.time.field.PreciseDurationField preciseDurationField16 = new org.joda.time.field.PreciseDurationField(durationFieldType13, (long) '4');
        long long19 = preciseDurationField16.add((-2L), (long) 'a');
        boolean boolean21 = preciseDurationField16.equals((java.lang.Object) (-1L));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 5042L + "'", long19 == 5042L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test226");
//        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.dayTime();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str6 = dateTimeZone5.getID();
//        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone8 = zonedChronology7.getZone();
//        java.lang.String str9 = zonedChronology7.toString();
//        org.joda.time.Period period10 = new org.joda.time.Period((long) 3, periodType3, (org.joda.time.Chronology) zonedChronology7);
//        org.joda.time.ReadableInterval readableInterval12 = null;
//        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
//        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
//        org.joda.time.Period period16 = period14.plusMillis(1);
//        java.lang.String str17 = period14.toString();
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.clockhourOfDay();
//        boolean boolean21 = iSOChronology18.equals((java.lang.Object) (-1.0f));
//        org.joda.time.Period period22 = new org.joda.time.Period((java.lang.Object) period14, (org.joda.time.Chronology) iSOChronology18);
//        int[] intArray24 = zonedChronology7.get((org.joda.time.ReadablePeriod) period22, (-1L));
//        org.joda.time.chrono.LenientChronology lenientChronology25 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology7);
//        org.joda.time.Period period26 = new org.joda.time.Period((long) 'a', (long) 0, (org.joda.time.Chronology) lenientChronology25);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str28 = dateTimeZone27.getID();
//        java.lang.String str29 = dateTimeZone27.getID();
//        java.util.TimeZone timeZone30 = dateTimeZone27.toTimeZone();
//        java.lang.String str32 = dateTimeZone27.getName((long) 3);
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
//        long long36 = dateTimeZone27.getMillisKeepLocal(dateTimeZone34, (long) (byte) 100);
//        org.joda.time.Chronology chronology37 = lenientChronology25.withZone(dateTimeZone27);
//        org.joda.time.DateTimeField dateTimeField38 = lenientChronology25.monthOfYear();
//        org.joda.time.Period period40 = org.joda.time.Period.seconds(1);
//        org.joda.time.Period period42 = period40.plusHours((-100));
//        boolean boolean43 = lenientChronology25.equals((java.lang.Object) period42);
//        long long51 = lenientChronology25.getDateTimeMillis((int) '#', 4, 3, 0, 52, 4, 4);
//        org.joda.time.DateTimeField dateTimeField52 = lenientChronology25.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField53 = lenientChronology25.dayOfMonth();
//        org.joda.time.chrono.ISOChronology iSOChronology54 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField55 = iSOChronology54.clockhourOfDay();
//        org.joda.time.ReadableInterval readableInterval57 = null;
//        org.joda.time.Chronology chronology58 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval57);
//        org.joda.time.Period period59 = new org.joda.time.Period((long) '4', chronology58);
//        org.joda.time.Period period60 = period59.toPeriod();
//        int int61 = period59.getMillis();
//        org.joda.time.Period period63 = period59.minusYears((int) ' ');
//        int[] intArray65 = iSOChronology54.get((org.joda.time.ReadablePeriod) period63, (long) (short) 0);
//        org.joda.time.Period period66 = new org.joda.time.Period();
//        org.joda.time.ReadableInterval readableInterval68 = null;
//        org.joda.time.Chronology chronology69 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval68);
//        org.joda.time.Period period70 = new org.joda.time.Period((long) '4', chronology69);
//        org.joda.time.Period period72 = period70.withYears((int) (short) 10);
//        org.joda.time.PeriodType periodType73 = period72.getPeriodType();
//        org.joda.time.DurationFieldType durationFieldType75 = periodType73.getFieldType((int) (short) 0);
//        org.joda.time.Period period77 = period66.withField(durationFieldType75, (int) (short) 0);
//        org.joda.time.Period period79 = period66.withWeeks((-1));
//        org.joda.time.Period period80 = period63.minus((org.joda.time.ReadablePeriod) period66);
//        org.joda.time.Period period82 = period63.minusMillis((int) (byte) 1);
//        int int83 = period82.getMinutes();
//        int[] intArray86 = lenientChronology25.get((org.joda.time.ReadablePeriod) period82, 10800002L, (-3174845943151792L));
//        org.junit.Assert.assertNotNull(periodType3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//        org.junit.Assert.assertNotNull(zonedChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str9.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PT0.052S" + "'", str17.equals("PT0.052S"));
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(intArray24);
//        org.junit.Assert.assertNotNull(lenientChronology25);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UTC" + "'", str29.equals("UTC"));
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Coordinated Universal Time" + "'", str32.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-349199900L) + "'", long36 == (-349199900L));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(period40);
//        org.junit.Assert.assertNotNull(period42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-61054729675996L) + "'", long51 == (-61054729675996L));
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(iSOChronology54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertNotNull(chronology58);
//        org.junit.Assert.assertNotNull(period60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 52 + "'", int61 == 52);
//        org.junit.Assert.assertNotNull(period63);
//        org.junit.Assert.assertNotNull(intArray65);
//        org.junit.Assert.assertNotNull(chronology69);
//        org.junit.Assert.assertNotNull(period72);
//        org.junit.Assert.assertNotNull(periodType73);
//        org.junit.Assert.assertNotNull(durationFieldType75);
//        org.junit.Assert.assertNotNull(period77);
//        org.junit.Assert.assertNotNull(period79);
//        org.junit.Assert.assertNotNull(period80);
//        org.junit.Assert.assertNotNull(period82);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
//        org.junit.Assert.assertNotNull(intArray86);
//    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str4 = dateTimeZone3.getID();
//        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
//        java.lang.String str7 = zonedChronology5.toString();
//        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
//        org.joda.time.ReadableInterval readableInterval10 = null;
//        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
//        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
//        org.joda.time.Period period14 = period12.plusMillis(1);
//        java.lang.String str15 = period12.toString();
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
//        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
//        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
//        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
//        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
//        org.joda.time.DateTimeField dateTimeField24 = zonedChronology5.millisOfDay();
//        org.joda.time.DateTimeZone dateTimeZone25 = zonedChronology5.getZone();
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = dateTimeZone25.getShortName((long) (-3491999), locale27);
//        org.junit.Assert.assertNotNull(periodType1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertNotNull(zonedChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(intArray22);
//        org.junit.Assert.assertNotNull(lenientChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', chronology7);
        org.joda.time.Period period10 = period8.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType((int) (short) 0);
        boolean boolean14 = period3.isSupported(durationFieldType13);
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(durationFieldType13, (java.lang.Number) 4, (java.lang.Number) 1L, (java.lang.Number) 2L);
        illegalFieldValueException18.prependMessage("LenientChronology[ISOChronology[UTC]]");
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) -1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = dateTimeZoneBuilder2.setStandardOffset(0);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder4);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.Chronology chronology24 = zonedChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology5.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str28 = dateTimeZone27.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology26, dateTimeZone27);
        org.joda.time.chrono.LenientChronology lenientChronology30 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (-1));
        long long35 = offsetDateTimeField33.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField33.getAsText(readablePartial36, 0, locale38);
        long long42 = offsetDateTimeField33.add(220L, 68);
        int int44 = offsetDateTimeField33.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField33.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType45);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology49.clockhourOfDay();
        org.joda.time.Period period51 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.DurationField durationField52 = iSOChronology49.millis();
        org.joda.time.DurationField durationField53 = iSOChronology49.weeks();
        org.joda.time.DurationField durationField54 = iSOChronology49.days();
        long long57 = durationField54.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval59 = null;
        org.joda.time.Chronology chronology60 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval59);
        org.joda.time.Period period61 = new org.joda.time.Period((long) '4', chronology60);
        org.joda.time.Period period62 = period61.toPeriod();
        org.joda.time.ReadableInterval readableInterval64 = null;
        org.joda.time.Chronology chronology65 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval64);
        org.joda.time.Period period66 = new org.joda.time.Period((long) '4', chronology65);
        org.joda.time.Period period68 = period66.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType69 = period68.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType71 = periodType69.getFieldType((int) (short) 0);
        boolean boolean72 = period61.isSupported(durationFieldType71);
        org.joda.time.field.PreciseDurationField preciseDurationField74 = new org.joda.time.field.PreciseDurationField(durationFieldType71, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField76 = new org.joda.time.field.ScaledDurationField(durationField54, durationFieldType71, (int) (short) 100);
        long long78 = scaledDurationField76.getValueAsLong((long) 68);
        long long80 = scaledDurationField76.getMillis(52);
        int int81 = scaledDurationField76.getScalar();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField82 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType45, (org.joda.time.DurationField) scaledDurationField76);
        org.joda.time.ReadablePartial readablePartial83 = null;
        java.util.Locale locale85 = null;
        try {
            java.lang.String str86 = unsupportedDateTimeField82.getAsShortText(readablePartial83, 0, locale85);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(lenientChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 244800220L + "'", long42 == 244800220L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(durationField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 10L + "'", long57 == 10L);
        org.junit.Assert.assertNotNull(chronology60);
        org.junit.Assert.assertNotNull(period62);
        org.junit.Assert.assertNotNull(chronology65);
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertNotNull(periodType69);
        org.junit.Assert.assertNotNull(durationFieldType71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 449280000000L + "'", long80 == 449280000000L);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 100 + "'", int81 == 100);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField82);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 100, periodType4, chronology6);
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) 100);
        org.joda.time.IllegalInstantException illegalInstantException10 = new org.joda.time.IllegalInstantException("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        boolean boolean11 = gregorianChronology0.equals((java.lang.Object) illegalInstantException10);
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        org.joda.time.DurationField durationField8 = offsetDateTimeField7.getLeapDurationField();
        long long11 = offsetDateTimeField7.add(10L, 1);
        int int13 = offsetDateTimeField7.getLeapAmount(14159997L);
        java.util.Locale locale14 = null;
        int int15 = offsetDateTimeField7.getMaximumTextLength(locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        int int17 = offsetDateTimeField7.getMinimumValue(readablePartial16);
        org.joda.time.ReadablePartial readablePartial18 = null;
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField7.getAsText(readablePartial18, 0, locale20);
        org.joda.time.ReadablePartial readablePartial22 = null;
        java.util.Locale locale23 = null;
        try {
            java.lang.String str24 = offsetDateTimeField7.getAsText(readablePartial22, locale23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3600010L + "'", long11 == 3600010L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        java.lang.String str5 = lenientChronology4.toString();
        org.joda.time.DateTimeField dateTimeField6 = lenientChronology4.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str9 = dateTimeZone8.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, dateTimeZone8);
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology7.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (-1));
        long long16 = offsetDateTimeField14.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField14.getAsText(readablePartial17, 0, locale19);
        long long23 = offsetDateTimeField14.add(220L, 68);
        int int25 = offsetDateTimeField14.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType26, 70);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField30 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField28, dateTimeFieldType29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str5.equals("LenientChronology[ISOChronology[UTC]]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 244800220L + "'", long23 == 244800220L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        org.joda.time.DurationField durationField8 = offsetDateTimeField7.getLeapDurationField();
        long long11 = offsetDateTimeField7.add(10L, 1);
        int int13 = offsetDateTimeField7.getLeapAmount(14159997L);
        java.util.Locale locale14 = null;
        int int15 = offsetDateTimeField7.getMaximumTextLength(locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        int int17 = offsetDateTimeField7.getMinimumValue(readablePartial16);
        long long19 = offsetDateTimeField7.roundHalfCeiling(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3600010L + "'", long11 == 3600010L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test235");
//        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
//        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology4);
//        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 1, periodType1, (org.joda.time.Chronology) iSOChronology4);
//        org.joda.time.DurationField durationField8 = iSOChronology4.seconds();
//        org.joda.time.chrono.LenientChronology lenientChronology9 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology4);
//        long long13 = lenientChronology9.add(0L, 2440578L, 100);
//        java.lang.String str14 = lenientChronology9.toString();
//        org.joda.time.DurationField durationField15 = lenientChronology9.hours();
//        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.dayTime();
//        org.joda.time.PeriodType periodType20 = periodType19.withWeeksRemoved();
//        org.joda.time.PeriodType periodType21 = org.joda.time.DateTimeUtils.getPeriodType(periodType19);
//        org.joda.time.ReadableInterval readableInterval22 = null;
//        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval22);
//        org.joda.time.Period period24 = new org.joda.time.Period((long) 100, periodType21, chronology23);
//        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.clockhourOfDay();
//        org.joda.time.Period period29 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology27);
//        org.joda.time.Period period30 = new org.joda.time.Period((long) (short) -1, (long) '#', periodType21, (org.joda.time.Chronology) iSOChronology27);
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.Chronology chronology32 = iSOChronology27.withZone(dateTimeZone31);
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str34 = dateTimeZone33.getID();
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone33);
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = dateTimeZone33.getName((long) 8, locale37);
//        org.joda.time.Chronology chronology39 = iSOChronology27.withZone(dateTimeZone33);
//        java.lang.String str40 = iSOChronology27.toString();
//        boolean boolean41 = org.joda.time.field.FieldUtils.equals((java.lang.Object) lenientChronology9, (java.lang.Object) str40);
//        org.junit.Assert.assertNotNull(periodType1);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(lenientChronology9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 244057800L + "'", long13 == 244057800L);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str14.equals("LenientChronology[ISOChronology[UTC]]"));
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(periodType19);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(iSOChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(chronology32);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "UTC" + "'", str34.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Coordinated Universal Time" + "'", str38.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "ISOChronology[UTC]" + "'", str40.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.Chronology chronology24 = zonedChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology5.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str28 = dateTimeZone27.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology26, dateTimeZone27);
        org.joda.time.chrono.LenientChronology lenientChronology30 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (-1));
        long long35 = offsetDateTimeField33.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField33.getAsText(readablePartial36, 0, locale38);
        long long42 = offsetDateTimeField33.add(220L, 68);
        int int44 = offsetDateTimeField33.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField33.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType45);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology49.clockhourOfDay();
        org.joda.time.Period period51 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.DurationField durationField52 = iSOChronology49.millis();
        org.joda.time.DurationField durationField53 = iSOChronology49.weeks();
        org.joda.time.DurationField durationField54 = iSOChronology49.days();
        long long57 = durationField54.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval59 = null;
        org.joda.time.Chronology chronology60 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval59);
        org.joda.time.Period period61 = new org.joda.time.Period((long) '4', chronology60);
        org.joda.time.Period period62 = period61.toPeriod();
        org.joda.time.ReadableInterval readableInterval64 = null;
        org.joda.time.Chronology chronology65 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval64);
        org.joda.time.Period period66 = new org.joda.time.Period((long) '4', chronology65);
        org.joda.time.Period period68 = period66.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType69 = period68.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType71 = periodType69.getFieldType((int) (short) 0);
        boolean boolean72 = period61.isSupported(durationFieldType71);
        org.joda.time.field.PreciseDurationField preciseDurationField74 = new org.joda.time.field.PreciseDurationField(durationFieldType71, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField76 = new org.joda.time.field.ScaledDurationField(durationField54, durationFieldType71, (int) (short) 100);
        long long78 = scaledDurationField76.getValueAsLong((long) 68);
        long long80 = scaledDurationField76.getMillis(52);
        int int81 = scaledDurationField76.getScalar();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField82 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType45, (org.joda.time.DurationField) scaledDurationField76);
        org.joda.time.ReadablePartial readablePartial83 = null;
        java.util.Locale locale85 = null;
        try {
            java.lang.String str86 = unsupportedDateTimeField82.getAsShortText(readablePartial83, (int) (byte) 1, locale85);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(lenientChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 244800220L + "'", long42 == 244800220L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(durationField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 10L + "'", long57 == 10L);
        org.junit.Assert.assertNotNull(chronology60);
        org.junit.Assert.assertNotNull(period62);
        org.junit.Assert.assertNotNull(chronology65);
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertNotNull(periodType69);
        org.junit.Assert.assertNotNull(durationFieldType71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 449280000000L + "'", long80 == 449280000000L);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 100 + "'", int81 == 100);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField82);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str6 = dateTimeZone5.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone8 = zonedChronology7.getZone();
        java.lang.String str9 = zonedChronology7.toString();
        org.joda.time.Period period10 = new org.joda.time.Period((long) 3, periodType3, (org.joda.time.Chronology) zonedChronology7);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period16 = period14.plusMillis(1);
        java.lang.String str17 = period14.toString();
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.clockhourOfDay();
        boolean boolean21 = iSOChronology18.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period22 = new org.joda.time.Period((java.lang.Object) period14, (org.joda.time.Chronology) iSOChronology18);
        int[] intArray24 = zonedChronology7.get((org.joda.time.ReadablePeriod) period22, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology25 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.Period period26 = new org.joda.time.Period((long) 'a', (long) 0, (org.joda.time.Chronology) lenientChronology25);
        org.joda.time.PeriodType periodType27 = period26.getPeriodType();
        org.joda.time.Period period28 = period26.toPeriod();
        org.joda.time.Weeks weeks29 = period26.toStandardWeeks();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str9.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PT0.052S" + "'", str17.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(lenientChronology25);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(weeks29);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((-3L), (-84L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 81L + "'", long2 == 81L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "DayTime", 0, 10);
        int int6 = fixedDateTimeZone4.getStandardOffset((-210865896000000L));
        int int8 = fixedDateTimeZone4.getStandardOffset(156062890818200L);
        int int10 = fixedDateTimeZone4.getOffsetFromLocal((long) 52);
        java.lang.String str12 = fixedDateTimeZone4.getNameKey(3599999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DayTime" + "'", str12.equals("DayTime"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        long long27 = zonedChronology5.add(1000L, 1560628908182L, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField28 = zonedChronology5.minuteOfDay();
        org.joda.time.tz.DefaultNameProvider defaultNameProvider29 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale30 = null;
        java.lang.String str33 = defaultNameProvider29.getShortName(locale30, "Weeks", "Weeks");
        java.util.Locale locale34 = null;
        java.lang.String str37 = defaultNameProvider29.getShortName(locale34, "Weeks", "org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        boolean boolean38 = zonedChronology5.equals((java.lang.Object) locale34);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560628909182L + "'", long27 == 1560628909182L);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(1);
        org.joda.time.Period period2 = period1.normalizedStandard();
        org.joda.time.Period period4 = period1.plusHours((int) (byte) 10);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.clockhourOfDay();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology6);
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 1, periodType3, (org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DurationField durationField10 = iSOChronology6.seconds();
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology6);
        long long15 = lenientChronology11.add(0L, 2440578L, 100);
        java.lang.String str16 = lenientChronology11.toString();
        long long21 = lenientChronology11.getDateTimeMillis((int) (byte) 10, (int) (short) 1, 0, 0);
        org.joda.time.Period period22 = new org.joda.time.Period(obj0, periodType1, (org.joda.time.Chronology) lenientChronology11);
        org.joda.time.PeriodType periodType23 = periodType1.withSecondsRemoved();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 244057800L + "'", long15 == 244057800L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str16.equals("LenientChronology[ISOChronology[UTC]]"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61851686400000L) + "'", long21 == (-61851686400000L));
        org.junit.Assert.assertNotNull(periodType23);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 1, (int) (short) -1, 0, (int) (short) -1);
        org.joda.time.Period period6 = period4.minusMillis((int) (byte) 100);
        org.joda.time.Period period8 = period6.plusMinutes(349200000);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str13 = dateTimeZone12.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology11, dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone15 = zonedChronology14.getZone();
        java.lang.String str16 = zonedChronology14.toString();
        org.joda.time.Period period17 = new org.joda.time.Period((long) 3, periodType10, (org.joda.time.Chronology) zonedChronology14);
        org.joda.time.ReadableInterval readableInterval19 = null;
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval19);
        org.joda.time.Period period21 = new org.joda.time.Period((long) '4', chronology20);
        org.joda.time.Period period23 = period21.plusMillis(1);
        java.lang.String str24 = period21.toString();
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.clockhourOfDay();
        boolean boolean28 = iSOChronology25.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period29 = new org.joda.time.Period((java.lang.Object) period21, (org.joda.time.Chronology) iSOChronology25);
        int[] intArray31 = zonedChronology14.get((org.joda.time.ReadablePeriod) period29, (-1L));
        org.joda.time.Period period32 = period6.withFields((org.joda.time.ReadablePeriod) period29);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UTC" + "'", str13.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str16.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "PT0.052S" + "'", str24.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(period32);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType6 = period5.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField10 = new org.joda.time.field.PreciseDurationField(durationFieldType8, (long) (byte) 100);
        java.lang.String str11 = preciseDurationField10.getName();
        long long12 = preciseDurationField10.getUnitMillis();
        int int15 = preciseDurationField10.getDifference((-349199900L), (long) 'a');
        org.joda.time.DurationFieldType durationFieldType16 = preciseDurationField10.getType();
        long long19 = preciseDurationField10.getValueAsLong(244057800L, (long) 2);
        boolean boolean20 = preciseDurationField10.isSupported();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "years" + "'", str11.equals("years"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-3491999) + "'", int15 == (-3491999));
        org.junit.Assert.assertNotNull(durationFieldType16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2440578L + "'", long19 == 2440578L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test245");
//        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.dayTime();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str6 = dateTimeZone5.getID();
//        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone8 = zonedChronology7.getZone();
//        java.lang.String str9 = zonedChronology7.toString();
//        org.joda.time.Period period10 = new org.joda.time.Period((long) 3, periodType3, (org.joda.time.Chronology) zonedChronology7);
//        org.joda.time.ReadableInterval readableInterval12 = null;
//        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
//        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
//        org.joda.time.Period period16 = period14.plusMillis(1);
//        java.lang.String str17 = period14.toString();
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.clockhourOfDay();
//        boolean boolean21 = iSOChronology18.equals((java.lang.Object) (-1.0f));
//        org.joda.time.Period period22 = new org.joda.time.Period((java.lang.Object) period14, (org.joda.time.Chronology) iSOChronology18);
//        int[] intArray24 = zonedChronology7.get((org.joda.time.ReadablePeriod) period22, (-1L));
//        org.joda.time.chrono.LenientChronology lenientChronology25 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology7);
//        org.joda.time.Period period26 = new org.joda.time.Period((long) 'a', (long) 0, (org.joda.time.Chronology) lenientChronology25);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str28 = dateTimeZone27.getID();
//        java.lang.String str29 = dateTimeZone27.getID();
//        java.util.TimeZone timeZone30 = dateTimeZone27.toTimeZone();
//        java.lang.String str32 = dateTimeZone27.getName((long) 3);
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
//        long long36 = dateTimeZone27.getMillisKeepLocal(dateTimeZone34, (long) (byte) 100);
//        org.joda.time.Chronology chronology37 = lenientChronology25.withZone(dateTimeZone27);
//        org.joda.time.DateTimeField dateTimeField38 = lenientChronology25.monthOfYear();
//        org.joda.time.Period period40 = org.joda.time.Period.seconds(1);
//        org.joda.time.Period period42 = period40.plusHours((-100));
//        boolean boolean43 = lenientChronology25.equals((java.lang.Object) period42);
//        org.joda.time.Period period45 = period42.plusHours((-100));
//        org.junit.Assert.assertNotNull(periodType3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//        org.junit.Assert.assertNotNull(zonedChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str9.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PT0.052S" + "'", str17.equals("PT0.052S"));
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(intArray24);
//        org.junit.Assert.assertNotNull(lenientChronology25);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UTC" + "'", str29.equals("UTC"));
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Coordinated Universal Time" + "'", str32.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-349199900L) + "'", long36 == (-349199900L));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(period40);
//        org.junit.Assert.assertNotNull(period42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(period45);
//    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        long long27 = zonedChronology5.add(1000L, 1560628908182L, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField28 = zonedChronology5.minuteOfDay();
        org.joda.time.Chronology chronology29 = zonedChronology5.withUTC();
        java.lang.String str30 = zonedChronology5.toString();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560628909182L + "'", long27 == 1560628909182L);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str30.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        org.joda.time.DurationField durationField8 = offsetDateTimeField7.getLeapDurationField();
        long long11 = offsetDateTimeField7.add(10L, 1);
        int int13 = offsetDateTimeField7.getLeapAmount(14159997L);
        java.util.Locale locale14 = null;
        int int15 = offsetDateTimeField7.getMaximumTextLength(locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        int int17 = offsetDateTimeField7.getMinimumValue(readablePartial16);
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.clockhourOfDay();
        org.joda.time.Period period25 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology23);
        org.joda.time.Period period26 = new org.joda.time.Period((long) (byte) 1, periodType20, (org.joda.time.Chronology) iSOChronology23);
        org.joda.time.DurationField durationField27 = iSOChronology23.halfdays();
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant28, readableInstant29);
        org.joda.time.Period period32 = period30.minusMinutes(52);
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Duration duration34 = period30.toDurationTo(readableInstant33);
        int[] intArray36 = iSOChronology23.get((org.joda.time.ReadablePeriod) period30, 2440588L);
        int int37 = offsetDateTimeField7.getMaximumValue(readablePartial18, intArray36);
        org.joda.time.DurationField durationField38 = offsetDateTimeField7.getLeapDurationField();
        long long41 = offsetDateTimeField7.add(508040L, (long) 23);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3600010L + "'", long11 == 3600010L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(duration34);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 23 + "'", int37 == 23);
        org.junit.Assert.assertNull(durationField38);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 83308040L + "'", long41 == 83308040L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 1, periodType1, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DurationField durationField8 = iSOChronology4.seconds();
        org.joda.time.chrono.LenientChronology lenientChronology9 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology4);
        long long13 = lenientChronology9.add(0L, 2440578L, 100);
        java.lang.String str14 = lenientChronology9.toString();
        org.joda.time.DateTimeField dateTimeField15 = lenientChronology9.hourOfDay();
        org.joda.time.DateTimeField dateTimeField16 = lenientChronology9.dayOfWeek();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(lenientChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 244057800L + "'", long13 == 244057800L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str14.equals("LenientChronology[ISOChronology[UTC]]"));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period6 = period4.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType7 = period6.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (short) 0);
        org.joda.time.Period period11 = period0.withField(durationFieldType9, (int) (short) 0);
        org.joda.time.Period period13 = period11.plusMillis((int) (short) -1);
        org.joda.time.ReadableInterval readableInterval15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) '4', chronology16);
        org.joda.time.Period period18 = period17.toPeriod();
        int int19 = period17.getMillis();
        org.joda.time.Period period21 = period17.minusYears((int) ' ');
        org.joda.time.Period period22 = period11.plus((org.joda.time.ReadablePeriod) period17);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 52 + "'", int19 == 52);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period22);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.Chronology chronology24 = zonedChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology5.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str28 = dateTimeZone27.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology26, dateTimeZone27);
        org.joda.time.chrono.LenientChronology lenientChronology30 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (-1));
        long long35 = offsetDateTimeField33.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField33.getAsText(readablePartial36, 0, locale38);
        long long42 = offsetDateTimeField33.add(220L, 68);
        int int44 = offsetDateTimeField33.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField33.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType45);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology49.clockhourOfDay();
        org.joda.time.Period period51 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.DurationField durationField52 = iSOChronology49.millis();
        org.joda.time.DurationField durationField53 = iSOChronology49.weeks();
        org.joda.time.DurationField durationField54 = iSOChronology49.days();
        long long57 = durationField54.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval59 = null;
        org.joda.time.Chronology chronology60 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval59);
        org.joda.time.Period period61 = new org.joda.time.Period((long) '4', chronology60);
        org.joda.time.Period period62 = period61.toPeriod();
        org.joda.time.ReadableInterval readableInterval64 = null;
        org.joda.time.Chronology chronology65 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval64);
        org.joda.time.Period period66 = new org.joda.time.Period((long) '4', chronology65);
        org.joda.time.Period period68 = period66.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType69 = period68.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType71 = periodType69.getFieldType((int) (short) 0);
        boolean boolean72 = period61.isSupported(durationFieldType71);
        org.joda.time.field.PreciseDurationField preciseDurationField74 = new org.joda.time.field.PreciseDurationField(durationFieldType71, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField76 = new org.joda.time.field.ScaledDurationField(durationField54, durationFieldType71, (int) (short) 100);
        long long78 = scaledDurationField76.getValueAsLong((long) 68);
        long long80 = scaledDurationField76.getMillis(52);
        int int81 = scaledDurationField76.getScalar();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField82 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType45, (org.joda.time.DurationField) scaledDurationField76);
        try {
            long long85 = unsupportedDateTimeField82.addWrapField(3536L, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(lenientChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 244800220L + "'", long42 == 244800220L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(durationField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 10L + "'", long57 == 10L);
        org.junit.Assert.assertNotNull(chronology60);
        org.junit.Assert.assertNotNull(period62);
        org.junit.Assert.assertNotNull(chronology65);
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertNotNull(periodType69);
        org.junit.Assert.assertNotNull(durationFieldType71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 449280000000L + "'", long80 == 449280000000L);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 100 + "'", int81 == 100);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField82);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period2 = org.joda.time.Period.seconds(1);
        org.joda.time.Period period4 = period2.plusHours((-100));
        org.joda.time.Duration duration5 = period2.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration5, readableInstant6);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration5, readableInstant8);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.weeks();
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType10);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) '4', chronology16);
        org.joda.time.Period period19 = period17.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType20 = period19.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType22 = periodType20.getFieldType((int) (short) 0);
        org.joda.time.Period period24 = period13.withField(durationFieldType22, (int) (short) 0);
        org.joda.time.Period period26 = period13.withWeeks((-1));
        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.clockhourOfDay();
        org.joda.time.Period period33 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.Period period34 = new org.joda.time.Period((long) (byte) 1, periodType28, (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.Period period35 = period13.withPeriodType(periodType28);
        org.joda.time.Period period36 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration5, readableInstant12, periodType28);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(period35);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        long long10 = durationField7.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period15 = period14.toPeriod();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) '4', chronology18);
        org.joda.time.Period period21 = period19.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType24 = periodType22.getFieldType((int) (short) 0);
        boolean boolean25 = period14.isSupported(durationFieldType24);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType24, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField29 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType24, (int) (short) 100);
        long long32 = scaledDurationField29.add((long) 70, 520L);
        try {
            long long35 = scaledDurationField29.add(3121004L, 4492800000070L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 449280000007000 * 86400000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 4492800000070L + "'", long32 == 4492800000070L);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.Chronology chronology24 = zonedChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology5.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str28 = dateTimeZone27.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology26, dateTimeZone27);
        org.joda.time.chrono.LenientChronology lenientChronology30 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (-1));
        long long35 = offsetDateTimeField33.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField33.getAsText(readablePartial36, 0, locale38);
        long long42 = offsetDateTimeField33.add(220L, 68);
        int int44 = offsetDateTimeField33.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField33.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType45);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology49.clockhourOfDay();
        org.joda.time.Period period51 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.DurationField durationField52 = iSOChronology49.millis();
        org.joda.time.DurationField durationField53 = iSOChronology49.weeks();
        org.joda.time.DurationField durationField54 = iSOChronology49.days();
        long long57 = durationField54.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval59 = null;
        org.joda.time.Chronology chronology60 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval59);
        org.joda.time.Period period61 = new org.joda.time.Period((long) '4', chronology60);
        org.joda.time.Period period62 = period61.toPeriod();
        org.joda.time.ReadableInterval readableInterval64 = null;
        org.joda.time.Chronology chronology65 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval64);
        org.joda.time.Period period66 = new org.joda.time.Period((long) '4', chronology65);
        org.joda.time.Period period68 = period66.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType69 = period68.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType71 = periodType69.getFieldType((int) (short) 0);
        boolean boolean72 = period61.isSupported(durationFieldType71);
        org.joda.time.field.PreciseDurationField preciseDurationField74 = new org.joda.time.field.PreciseDurationField(durationFieldType71, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField76 = new org.joda.time.field.ScaledDurationField(durationField54, durationFieldType71, (int) (short) 100);
        long long78 = scaledDurationField76.getValueAsLong((long) 68);
        long long80 = scaledDurationField76.getMillis(52);
        int int81 = scaledDurationField76.getScalar();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField82 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType45, (org.joda.time.DurationField) scaledDurationField76);
        org.joda.time.ReadablePartial readablePartial83 = null;
        java.util.Locale locale85 = null;
        try {
            java.lang.String str86 = unsupportedDateTimeField82.getAsText(readablePartial83, 100, locale85);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(lenientChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 244800220L + "'", long42 == 244800220L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(durationField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 10L + "'", long57 == 10L);
        org.junit.Assert.assertNotNull(chronology60);
        org.junit.Assert.assertNotNull(period62);
        org.junit.Assert.assertNotNull(chronology65);
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertNotNull(periodType69);
        org.junit.Assert.assertNotNull(durationFieldType71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 449280000000L + "'", long80 == 449280000000L);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 100 + "'", int81 == 100);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField82);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        int[] intArray5 = period3.getValues();
        try {
            int int7 = period3.getValue((-32));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str3 = dateTimeZone2.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone2);
        org.joda.time.DurationField durationField5 = iSOChronology1.hours();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.clockhourOfDay();
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology9);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.clockhourOfDay();
        org.joda.time.Period period16 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology14);
        org.joda.time.Period period17 = period16.normalizedStandard();
        org.joda.time.Period period19 = period16.withYears(10);
        org.joda.time.Period period21 = period16.withWeeks((int) (byte) 0);
        org.joda.time.Period period23 = period21.withSeconds((int) (short) -1);
        org.joda.time.Period period24 = period11.minus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Weeks weeks25 = period11.toStandardWeeks();
        int[] intArray28 = iSOChronology1.get((org.joda.time.ReadablePeriod) weeks25, (-99999L), 10800002L);
        try {
            org.joda.time.Period period29 = new org.joda.time.Period((java.lang.Object) (-131), (org.joda.time.Chronology) iSOChronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(weeks25);
        org.junit.Assert.assertNotNull(intArray28);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.Chronology chronology24 = zonedChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology5.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str28 = dateTimeZone27.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology26, dateTimeZone27);
        org.joda.time.chrono.LenientChronology lenientChronology30 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (-1));
        long long35 = offsetDateTimeField33.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField33.getAsText(readablePartial36, 0, locale38);
        long long42 = offsetDateTimeField33.add(220L, 68);
        int int44 = offsetDateTimeField33.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField33.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType45);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology49.clockhourOfDay();
        org.joda.time.Period period51 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.DurationField durationField52 = iSOChronology49.millis();
        org.joda.time.DurationField durationField53 = iSOChronology49.weeks();
        org.joda.time.DurationField durationField54 = iSOChronology49.days();
        long long57 = durationField54.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval59 = null;
        org.joda.time.Chronology chronology60 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval59);
        org.joda.time.Period period61 = new org.joda.time.Period((long) '4', chronology60);
        org.joda.time.Period period62 = period61.toPeriod();
        org.joda.time.ReadableInterval readableInterval64 = null;
        org.joda.time.Chronology chronology65 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval64);
        org.joda.time.Period period66 = new org.joda.time.Period((long) '4', chronology65);
        org.joda.time.Period period68 = period66.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType69 = period68.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType71 = periodType69.getFieldType((int) (short) 0);
        boolean boolean72 = period61.isSupported(durationFieldType71);
        org.joda.time.field.PreciseDurationField preciseDurationField74 = new org.joda.time.field.PreciseDurationField(durationFieldType71, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField76 = new org.joda.time.field.ScaledDurationField(durationField54, durationFieldType71, (int) (short) 100);
        long long78 = scaledDurationField76.getValueAsLong((long) 68);
        long long80 = scaledDurationField76.getMillis(52);
        int int81 = scaledDurationField76.getScalar();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField82 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType45, (org.joda.time.DurationField) scaledDurationField76);
        org.joda.time.ReadablePartial readablePartial83 = null;
        java.util.Locale locale85 = null;
        try {
            java.lang.String str86 = unsupportedDateTimeField82.getAsText(readablePartial83, 37, locale85);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(lenientChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 244800220L + "'", long42 == 244800220L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(durationField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 10L + "'", long57 == 10L);
        org.junit.Assert.assertNotNull(chronology60);
        org.junit.Assert.assertNotNull(period62);
        org.junit.Assert.assertNotNull(chronology65);
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertNotNull(periodType69);
        org.junit.Assert.assertNotNull(durationFieldType71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 449280000000L + "'", long80 == 449280000000L);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 100 + "'", int81 == 100);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField82);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 100, periodType4, chronology6);
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) 100);
        org.joda.time.IllegalInstantException illegalInstantException10 = new org.joda.time.IllegalInstantException("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        boolean boolean11 = gregorianChronology0.equals((java.lang.Object) illegalInstantException10);
        org.joda.time.Chronology chronology12 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str14 = dateTimeZone13.getID();
        java.lang.String str15 = dateTimeZone13.getID();
        org.joda.time.Chronology chronology16 = gregorianChronology0.withZone(dateTimeZone13);
        java.lang.String str17 = dateTimeZone13.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "UTC" + "'", str17.equals("UTC"));
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test258");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str1 = dateTimeZone0.getID();
//        java.lang.String str2 = dateTimeZone0.getID();
//        java.util.TimeZone timeZone3 = dateTimeZone0.toTimeZone();
//        java.lang.String str5 = dateTimeZone0.getName((long) 3);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
//        long long9 = dateTimeZone0.getMillisKeepLocal(dateTimeZone7, (long) (byte) 100);
//        org.joda.time.LocalDateTime localDateTime10 = null;
//        boolean boolean11 = dateTimeZone0.isLocalDateTimeGap(localDateTime10);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        long long15 = dateTimeZone0.adjustOffset((long) 100, false);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTC" + "'", str1.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-349199900L) + "'", long9 == (-349199900L));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone28 = new org.joda.time.tz.FixedDateTimeZone("", "DayTime", 0, 10);
        int int30 = fixedDateTimeZone28.getStandardOffset((-210865896000000L));
        int int32 = fixedDateTimeZone28.getStandardOffset(156062890818200L);
        org.joda.time.Chronology chronology33 = zonedChronology5.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone28);
        org.joda.time.Chronology chronology34 = zonedChronology5.withUTC();
        org.joda.time.DateTimeZone dateTimeZone35 = zonedChronology5.getZone();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 10 + "'", int32 == 10);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTimeZone35);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        java.security.PermissionCollection permissionCollection3 = jodaTimePermission1.newPermissionCollection();
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str8 = dateTimeZone7.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology6, dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone10 = zonedChronology9.getZone();
        java.lang.String str11 = zonedChronology9.toString();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 3, periodType5, (org.joda.time.Chronology) zonedChronology9);
        org.joda.time.ReadableInterval readableInterval14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval14);
        org.joda.time.Period period16 = new org.joda.time.Period((long) '4', chronology15);
        org.joda.time.Period period18 = period16.plusMillis(1);
        java.lang.String str19 = period16.toString();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.clockhourOfDay();
        boolean boolean23 = iSOChronology20.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) period16, (org.joda.time.Chronology) iSOChronology20);
        int[] intArray26 = zonedChronology9.get((org.joda.time.ReadablePeriod) period24, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology27 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology9);
        long long31 = zonedChronology9.add(1000L, 1560628908182L, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField32 = zonedChronology9.minuteOfDay();
        jodaTimePermission1.checkGuard((java.lang.Object) zonedChronology9);
        java.security.PermissionCollection permissionCollection34 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertNotNull(permissionCollection3);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str11.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PT0.052S" + "'", str19.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(lenientChronology27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560628909182L + "'", long31 == 1560628909182L);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(permissionCollection34);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(3);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Period period7 = period6.normalizedStandard();
        org.joda.time.Period period9 = period6.withYears(10);
        boolean boolean11 = period6.equals((java.lang.Object) 2440587.5d);
        org.joda.time.Period period13 = period6.minusWeeks((int) (byte) 10);
        org.joda.time.Period period14 = period1.withFields((org.joda.time.ReadablePeriod) period13);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("hi!");
        try {
            org.joda.time.Period period2 = new org.joda.time.Period((java.lang.Object) "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.clockhourOfDay();
        org.joda.time.Period period9 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology7);
        org.joda.time.Period period10 = new org.joda.time.Period((long) (byte) 1, periodType4, (org.joda.time.Chronology) iSOChronology7);
        org.joda.time.PeriodType periodType11 = periodType4.withYearsRemoved();
        int int12 = periodType11.size();
        boolean boolean13 = gregorianChronology0.equals((java.lang.Object) int12);
        org.joda.time.DurationField durationField14 = gregorianChronology0.weekyears();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        int int5 = period3.getMillis();
        org.joda.time.Period period7 = period3.minusYears((int) ' ');
        org.joda.time.Period period9 = period7.plusDays((int) 'a');
        org.joda.time.Period period11 = period7.withMinutes((-100));
        org.joda.time.Period period13 = period11.minusYears(23);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1248000));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.Period period4 = period2.minusMinutes(52);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period2.toDurationTo(readableInstant5);
        org.joda.time.Period period8 = period2.minusMillis((int) (byte) 1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        long long10 = durationField7.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period15 = period14.toPeriod();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) '4', chronology18);
        org.joda.time.Period period21 = period19.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType24 = periodType22.getFieldType((int) (short) 0);
        boolean boolean25 = period14.isSupported(durationFieldType24);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType24, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField29 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType24, (int) (short) 100);
        long long31 = scaledDurationField29.getValueAsLong((long) 68);
        long long33 = scaledDurationField29.getMillis(52);
        long long36 = scaledDurationField29.getDifferenceAsLong((-84L), (-34919990L));
        long long39 = scaledDurationField29.getDifferenceAsLong(5042L, 5042L);
        long long41 = scaledDurationField29.getMillis(52);
        long long44 = scaledDurationField29.getMillis((-46934L), (-34919990L));
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 449280000000L + "'", long33 == 449280000000L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 449280000000L + "'", long41 == 449280000000L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-405509760000000L) + "'", long44 == (-405509760000000L));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "Weeks", "Weeks");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "Weeks", "org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getName(locale9, "", "PT0S");
        java.util.Locale locale13 = null;
        java.lang.String str16 = defaultNameProvider0.getName(locale13, "LenientChronology[ZonedChronology[ISOChronology[UTC], UTC]]", "GregorianChronology[UTC]");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        long long9 = offsetDateTimeField7.roundHalfFloor(2704L);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField7.getType();
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumTextLength(locale11);
        long long14 = offsetDateTimeField7.roundHalfCeiling(3603536L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3600000L + "'", long14 == 3600000L);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.Chronology chronology24 = zonedChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology5.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str28 = dateTimeZone27.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology26, dateTimeZone27);
        org.joda.time.chrono.LenientChronology lenientChronology30 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (-1));
        long long35 = offsetDateTimeField33.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField33.getAsText(readablePartial36, 0, locale38);
        long long42 = offsetDateTimeField33.add(220L, 68);
        int int44 = offsetDateTimeField33.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField33.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType45);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology49.clockhourOfDay();
        org.joda.time.Period period51 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.DurationField durationField52 = iSOChronology49.millis();
        org.joda.time.DurationField durationField53 = iSOChronology49.weeks();
        org.joda.time.DurationField durationField54 = iSOChronology49.days();
        long long57 = durationField54.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval59 = null;
        org.joda.time.Chronology chronology60 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval59);
        org.joda.time.Period period61 = new org.joda.time.Period((long) '4', chronology60);
        org.joda.time.Period period62 = period61.toPeriod();
        org.joda.time.ReadableInterval readableInterval64 = null;
        org.joda.time.Chronology chronology65 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval64);
        org.joda.time.Period period66 = new org.joda.time.Period((long) '4', chronology65);
        org.joda.time.Period period68 = period66.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType69 = period68.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType71 = periodType69.getFieldType((int) (short) 0);
        boolean boolean72 = period61.isSupported(durationFieldType71);
        org.joda.time.field.PreciseDurationField preciseDurationField74 = new org.joda.time.field.PreciseDurationField(durationFieldType71, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField76 = new org.joda.time.field.ScaledDurationField(durationField54, durationFieldType71, (int) (short) 100);
        long long78 = scaledDurationField76.getValueAsLong((long) 68);
        long long80 = scaledDurationField76.getMillis(52);
        int int81 = scaledDurationField76.getScalar();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField82 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType45, (org.joda.time.DurationField) scaledDurationField76);
        try {
            boolean boolean84 = unsupportedDateTimeField82.isLeap(2L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(lenientChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 244800220L + "'", long42 == 244800220L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(durationField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 10L + "'", long57 == 10L);
        org.junit.Assert.assertNotNull(chronology60);
        org.junit.Assert.assertNotNull(period62);
        org.junit.Assert.assertNotNull(chronology65);
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertNotNull(periodType69);
        org.junit.Assert.assertNotNull(durationFieldType71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 449280000000L + "'", long80 == 449280000000L);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 100 + "'", int81 == 100);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField82);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        long long10 = durationField7.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period15 = period14.toPeriod();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) '4', chronology18);
        org.joda.time.Period period21 = period19.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType24 = periodType22.getFieldType((int) (short) 0);
        boolean boolean25 = period14.isSupported(durationFieldType24);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType24, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField29 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType24, (int) (short) 100);
        long long31 = scaledDurationField29.getValueAsLong((long) 68);
        long long34 = scaledDurationField29.getValueAsLong(2440587L, 10800002L);
        int int37 = scaledDurationField29.getValue(0L, (long) 70);
        org.joda.time.DurationFieldType durationFieldType38 = scaledDurationField29.getType();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(durationFieldType38);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Period period5 = period4.normalizedStandard();
        org.joda.time.Period period7 = period4.withYears(10);
        org.joda.time.Period period9 = period4.withWeeks((int) (byte) 0);
        org.joda.time.Period period11 = period9.withSeconds((int) (short) -1);
        org.joda.time.Period period13 = period11.withYears((-24405));
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.Chronology chronology24 = zonedChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology5.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str28 = dateTimeZone27.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology26, dateTimeZone27);
        org.joda.time.chrono.LenientChronology lenientChronology30 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (-1));
        long long35 = offsetDateTimeField33.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField33.getAsText(readablePartial36, 0, locale38);
        long long42 = offsetDateTimeField33.add(220L, 68);
        int int44 = offsetDateTimeField33.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField33.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType45);
        org.joda.time.DurationField durationField47 = zeroIsMaxDateTimeField46.getLeapDurationField();
        boolean boolean49 = zeroIsMaxDateTimeField46.isLeap((long) (-100));
        boolean boolean51 = zeroIsMaxDateTimeField46.isLeap(5200L);
        int int53 = zeroIsMaxDateTimeField46.getLeapAmount(2440588L);
        long long55 = zeroIsMaxDateTimeField46.roundHalfCeiling((-3599990L));
        long long58 = zeroIsMaxDateTimeField46.add(0L, 0L);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(lenientChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 244800220L + "'", long42 == 244800220L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNull(durationField47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 0L + "'", long58 == 0L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "DayTime", 0, 10);
        int int6 = fixedDateTimeZone4.getStandardOffset((-210865896000000L));
        int int8 = fixedDateTimeZone4.getStandardOffset(156062890818200L);
        long long10 = fixedDateTimeZone4.convertUTCToLocal(3121004L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3121004L + "'", long10 == 3121004L);
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test275");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str1 = dateTimeZone0.getID();
//        java.lang.String str2 = dateTimeZone0.getID();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone0.getName((long) 0, locale4);
//        int int7 = dateTimeZone0.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.LocalDateTime localDateTime8 = null;
//        boolean boolean9 = dateTimeZone0.isLocalDateTimeGap(localDateTime8);
//        long long11 = dateTimeZone0.convertUTCToLocal(864000000004L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTC" + "'", str1.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 864000000004L + "'", long11 == 864000000004L);
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 1, periodType1, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.PeriodType periodType8 = periodType1.withYearsRemoved();
        int int9 = periodType1.size();
        org.joda.time.PeriodType periodType10 = periodType1.withMillisRemoved();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(periodType10);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (short) -1);
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) '4', chronology4);
        org.joda.time.Period period7 = period5.plusMillis(1);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType10 = periodType8.getFieldType((int) (short) 0);
        int int11 = period5.indexOf(durationFieldType10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(durationFieldType10, "UTC");
        org.joda.time.Period period15 = period1.withFieldAdded(durationFieldType10, (int) '4');
        org.joda.time.field.PreciseDurationField preciseDurationField17 = new org.joda.time.field.PreciseDurationField(durationFieldType10, (long) (-100));
        long long20 = preciseDurationField17.getValueAsLong((-3599990L), (-3L));
        org.joda.time.ReadableInterval readableInterval22 = null;
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval22);
        org.joda.time.Period period24 = new org.joda.time.Period((long) '4', chronology23);
        org.joda.time.Period period26 = period24.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType27 = period26.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType29 = periodType27.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField31 = new org.joda.time.field.PreciseDurationField(durationFieldType29, (long) (byte) 100);
        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(durationFieldType29, "PT0.052S");
        org.joda.time.field.DecoratedDurationField decoratedDurationField34 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) preciseDurationField17, durationFieldType29);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 35999L + "'", long20 == 35999L);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(durationFieldType29);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.Chronology chronology24 = zonedChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology5.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str28 = dateTimeZone27.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology26, dateTimeZone27);
        org.joda.time.chrono.LenientChronology lenientChronology30 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (-1));
        long long35 = offsetDateTimeField33.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField33.getAsText(readablePartial36, 0, locale38);
        long long42 = offsetDateTimeField33.add(220L, 68);
        int int44 = offsetDateTimeField33.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField33.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType45);
        org.joda.time.ReadablePartial readablePartial47 = null;
        int int48 = zeroIsMaxDateTimeField46.getMinimumValue(readablePartial47);
        org.joda.time.ReadablePartial readablePartial49 = null;
        int[] intArray50 = null;
        int int51 = zeroIsMaxDateTimeField46.getMaximumValue(readablePartial49, intArray50);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(lenientChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 244800220L + "'", long42 == 244800220L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 100 + "'", int51 == 100);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        java.lang.String str4 = dateTimeZone1.getID();
        java.lang.String str5 = dateTimeZone1.toString();
        long long8 = dateTimeZone1.convertLocalToUTC((long) '4', false);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 52L + "'", long8 == 52L);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period6 = period4.withYears((int) (short) 10);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period4.toDurationFrom(readableInstant7);
        org.joda.time.Period period10 = org.joda.time.Period.months(100);
        int int11 = period10.getMonths();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        org.joda.time.Period period18 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.Period period19 = new org.joda.time.Period((long) (byte) 1, periodType13, (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.PeriodType periodType20 = periodType13.withYearsRemoved();
        boolean boolean21 = period10.equals((java.lang.Object) periodType13);
        org.joda.time.Period period22 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration8, periodType13);
        org.joda.time.Period period24 = period22.minusSeconds(0);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(period24);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        org.joda.time.DurationField durationField8 = offsetDateTimeField7.getLeapDurationField();
        long long11 = offsetDateTimeField7.add(10L, 1);
        int int13 = offsetDateTimeField7.getLeapAmount(14159997L);
        java.util.Locale locale14 = null;
        int int15 = offsetDateTimeField7.getMaximumTextLength(locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        int int17 = offsetDateTimeField7.getMinimumValue(readablePartial16);
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.clockhourOfDay();
        org.joda.time.Period period25 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology23);
        org.joda.time.Period period26 = new org.joda.time.Period((long) (byte) 1, periodType20, (org.joda.time.Chronology) iSOChronology23);
        org.joda.time.DurationField durationField27 = iSOChronology23.halfdays();
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant28, readableInstant29);
        org.joda.time.Period period32 = period30.minusMinutes(52);
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Duration duration34 = period30.toDurationTo(readableInstant33);
        int[] intArray36 = iSOChronology23.get((org.joda.time.ReadablePeriod) period30, 2440588L);
        int int37 = offsetDateTimeField7.getMaximumValue(readablePartial18, intArray36);
        java.lang.String str39 = offsetDateTimeField7.getAsShortText((long) 10);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int int41 = offsetDateTimeField7.getMaximumValue(readablePartial40);
        long long43 = offsetDateTimeField7.roundHalfCeiling(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3600010L + "'", long11 == 3600010L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(duration34);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 23 + "'", int37 == 23);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "23" + "'", str39.equals("23"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 23 + "'", int41 == 23);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 100, periodType4, chronology6);
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) 100);
        org.joda.time.IllegalInstantException illegalInstantException10 = new org.joda.time.IllegalInstantException("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        boolean boolean11 = gregorianChronology0.equals((java.lang.Object) illegalInstantException10);
        org.joda.time.Chronology chronology12 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str14 = dateTimeZone13.getID();
        java.lang.String str15 = dateTimeZone13.getID();
        org.joda.time.Chronology chronology16 = gregorianChronology0.withZone(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str18 = dateTimeZone17.getID();
        org.joda.time.Chronology chronology19 = gregorianChronology0.withZone(dateTimeZone17);
        long long21 = dateTimeZone17.convertUTCToLocal((-58987094399903L));
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.era();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "UTC" + "'", str18.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-58987094399903L) + "'", long21 == (-58987094399903L));
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(3599999L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3599999 + "'", int1 == 3599999);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.Chronology chronology24 = zonedChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology5.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str28 = dateTimeZone27.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology26, dateTimeZone27);
        org.joda.time.chrono.LenientChronology lenientChronology30 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (-1));
        long long35 = offsetDateTimeField33.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField33.getAsText(readablePartial36, 0, locale38);
        long long42 = offsetDateTimeField33.add(220L, 68);
        int int44 = offsetDateTimeField33.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField33.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType45);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology49.clockhourOfDay();
        org.joda.time.Period period51 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.DurationField durationField52 = iSOChronology49.millis();
        org.joda.time.DurationField durationField53 = iSOChronology49.weeks();
        org.joda.time.DurationField durationField54 = iSOChronology49.days();
        long long57 = durationField54.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval59 = null;
        org.joda.time.Chronology chronology60 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval59);
        org.joda.time.Period period61 = new org.joda.time.Period((long) '4', chronology60);
        org.joda.time.Period period62 = period61.toPeriod();
        org.joda.time.ReadableInterval readableInterval64 = null;
        org.joda.time.Chronology chronology65 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval64);
        org.joda.time.Period period66 = new org.joda.time.Period((long) '4', chronology65);
        org.joda.time.Period period68 = period66.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType69 = period68.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType71 = periodType69.getFieldType((int) (short) 0);
        boolean boolean72 = period61.isSupported(durationFieldType71);
        org.joda.time.field.PreciseDurationField preciseDurationField74 = new org.joda.time.field.PreciseDurationField(durationFieldType71, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField76 = new org.joda.time.field.ScaledDurationField(durationField54, durationFieldType71, (int) (short) 100);
        long long78 = scaledDurationField76.getValueAsLong((long) 68);
        long long80 = scaledDurationField76.getMillis(52);
        int int81 = scaledDurationField76.getScalar();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField82 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType45, (org.joda.time.DurationField) scaledDurationField76);
        org.joda.time.DurationField durationField83 = unsupportedDateTimeField82.getDurationField();
        org.joda.time.ReadablePartial readablePartial84 = null;
        java.util.Locale locale85 = null;
        try {
            java.lang.String str86 = unsupportedDateTimeField82.getAsText(readablePartial84, locale85);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(lenientChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 244800220L + "'", long42 == 244800220L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(durationField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 10L + "'", long57 == 10L);
        org.junit.Assert.assertNotNull(chronology60);
        org.junit.Assert.assertNotNull(period62);
        org.junit.Assert.assertNotNull(chronology65);
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertNotNull(periodType69);
        org.junit.Assert.assertNotNull(durationFieldType71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 449280000000L + "'", long80 == 449280000000L);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 100 + "'", int81 == 100);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField82);
        org.junit.Assert.assertNotNull(durationField83);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        org.joda.time.DurationField durationField8 = offsetDateTimeField7.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField7.getMaximumValue(readablePartial9);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 23 + "'", int10 == 23);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withWeeksRemoved();
        java.lang.Class<?> wildcardClass2 = periodType0.getClass();
        org.joda.time.PeriodType periodType3 = periodType0.withDaysRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("PT3S");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"PT3S/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 1, periodType1, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DurationField durationField8 = iSOChronology4.seconds();
        org.joda.time.chrono.LenientChronology lenientChronology9 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology4);
        long long13 = lenientChronology9.add(0L, 2440578L, 100);
        org.joda.time.Chronology chronology14 = lenientChronology9.withUTC();
        long long20 = lenientChronology9.getDateTimeMillis(2440578L, 68, (-180), 0, (int) (short) 0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(lenientChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 244057800L + "'", long13 == 244057800L);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 234000000L + "'", long20 == 234000000L);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 1, periodType1, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DurationField durationField8 = iSOChronology4.seconds();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology4.secondOfDay();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology4.weekOfWeekyear();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType6 = period5.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField10 = new org.joda.time.field.PreciseDurationField(durationFieldType8, (long) (byte) 100);
        long long13 = preciseDurationField10.getValueAsLong(0L, (long) 10);
        long long16 = preciseDurationField10.subtract((long) 100, (long) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.clockhourOfDay();
        org.joda.time.ReadableInterval readableInterval20 = null;
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval20);
        org.joda.time.Period period22 = new org.joda.time.Period((long) '4', chronology21);
        org.joda.time.Period period23 = period22.toPeriod();
        int int24 = period22.getMillis();
        org.joda.time.Period period26 = period22.minusYears((int) ' ');
        int[] intArray28 = iSOChronology17.get((org.joda.time.ReadablePeriod) period26, (long) (short) 0);
        org.joda.time.Period period29 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval31 = null;
        org.joda.time.Chronology chronology32 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval31);
        org.joda.time.Period period33 = new org.joda.time.Period((long) '4', chronology32);
        org.joda.time.Period period35 = period33.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType36 = period35.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType38 = periodType36.getFieldType((int) (short) 0);
        org.joda.time.Period period40 = period29.withField(durationFieldType38, (int) (short) 0);
        org.joda.time.Period period42 = period29.withWeeks((-1));
        org.joda.time.Period period43 = period26.minus((org.joda.time.ReadablePeriod) period29);
        org.joda.time.ReadableInterval readableInterval45 = null;
        org.joda.time.Chronology chronology46 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval45);
        org.joda.time.Period period47 = new org.joda.time.Period((long) '4', chronology46);
        org.joda.time.Period period48 = period47.toPeriod();
        org.joda.time.ReadableInterval readableInterval50 = null;
        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval50);
        org.joda.time.Period period52 = new org.joda.time.Period((long) '4', chronology51);
        org.joda.time.Period period54 = period52.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType55 = period54.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType57 = periodType55.getFieldType((int) (short) 0);
        boolean boolean58 = period47.isSupported(durationFieldType57);
        int int59 = period43.get(durationFieldType57);
        org.joda.time.field.DecoratedDurationField decoratedDurationField60 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) preciseDurationField10, durationFieldType57);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 52 + "'", int24 == 52);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertNotNull(durationFieldType38);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertNotNull(chronology46);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(period54);
        org.junit.Assert.assertNotNull(periodType55);
        org.junit.Assert.assertNotNull(durationFieldType57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-32) + "'", int59 == (-32));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.Chronology chronology24 = zonedChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology5.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str28 = dateTimeZone27.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology26, dateTimeZone27);
        org.joda.time.chrono.LenientChronology lenientChronology30 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (-1));
        long long35 = offsetDateTimeField33.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField33.getAsText(readablePartial36, 0, locale38);
        long long42 = offsetDateTimeField33.add(220L, 68);
        int int44 = offsetDateTimeField33.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField33.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType45);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology49.clockhourOfDay();
        org.joda.time.Period period51 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.DurationField durationField52 = iSOChronology49.millis();
        org.joda.time.DurationField durationField53 = iSOChronology49.weeks();
        org.joda.time.DurationField durationField54 = iSOChronology49.days();
        long long57 = durationField54.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval59 = null;
        org.joda.time.Chronology chronology60 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval59);
        org.joda.time.Period period61 = new org.joda.time.Period((long) '4', chronology60);
        org.joda.time.Period period62 = period61.toPeriod();
        org.joda.time.ReadableInterval readableInterval64 = null;
        org.joda.time.Chronology chronology65 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval64);
        org.joda.time.Period period66 = new org.joda.time.Period((long) '4', chronology65);
        org.joda.time.Period period68 = period66.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType69 = period68.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType71 = periodType69.getFieldType((int) (short) 0);
        boolean boolean72 = period61.isSupported(durationFieldType71);
        org.joda.time.field.PreciseDurationField preciseDurationField74 = new org.joda.time.field.PreciseDurationField(durationFieldType71, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField76 = new org.joda.time.field.ScaledDurationField(durationField54, durationFieldType71, (int) (short) 100);
        long long78 = scaledDurationField76.getValueAsLong((long) 68);
        long long80 = scaledDurationField76.getMillis(52);
        int int81 = scaledDurationField76.getScalar();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField82 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType45, (org.joda.time.DurationField) scaledDurationField76);
        try {
            int int84 = unsupportedDateTimeField82.getLeapAmount(10800002L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(lenientChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 244800220L + "'", long42 == 244800220L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(durationField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 10L + "'", long57 == 10L);
        org.junit.Assert.assertNotNull(chronology60);
        org.junit.Assert.assertNotNull(period62);
        org.junit.Assert.assertNotNull(chronology65);
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertNotNull(periodType69);
        org.junit.Assert.assertNotNull(durationFieldType71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 449280000000L + "'", long80 == 449280000000L);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 100 + "'", int81 == 100);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField82);
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test292");
//        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.dayTime();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str8 = dateTimeZone7.getID();
//        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology6, dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone10 = zonedChronology9.getZone();
//        java.lang.String str11 = zonedChronology9.toString();
//        org.joda.time.Period period12 = new org.joda.time.Period((long) 3, periodType5, (org.joda.time.Chronology) zonedChronology9);
//        org.joda.time.ReadableInterval readableInterval14 = null;
//        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval14);
//        org.joda.time.Period period16 = new org.joda.time.Period((long) '4', chronology15);
//        org.joda.time.Period period18 = period16.plusMillis(1);
//        java.lang.String str19 = period16.toString();
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.clockhourOfDay();
//        boolean boolean23 = iSOChronology20.equals((java.lang.Object) (-1.0f));
//        org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) period16, (org.joda.time.Chronology) iSOChronology20);
//        int[] intArray26 = zonedChronology9.get((org.joda.time.ReadablePeriod) period24, (-1L));
//        org.joda.time.chrono.LenientChronology lenientChronology27 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology9);
//        org.joda.time.Period period28 = new org.joda.time.Period((long) 'a', (long) 0, (org.joda.time.Chronology) lenientChronology27);
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str30 = dateTimeZone29.getID();
//        java.lang.String str31 = dateTimeZone29.getID();
//        java.util.TimeZone timeZone32 = dateTimeZone29.toTimeZone();
//        java.lang.String str34 = dateTimeZone29.getName((long) 3);
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
//        long long38 = dateTimeZone29.getMillisKeepLocal(dateTimeZone36, (long) (byte) 100);
//        org.joda.time.Chronology chronology39 = lenientChronology27.withZone(dateTimeZone29);
//        org.joda.time.DateTimeField dateTimeField40 = lenientChronology27.monthOfYear();
//        org.joda.time.Period period42 = org.joda.time.Period.seconds(1);
//        org.joda.time.Period period44 = period42.plusHours((-100));
//        boolean boolean45 = lenientChronology27.equals((java.lang.Object) period44);
//        long long53 = lenientChronology27.getDateTimeMillis((int) '#', 4, 3, 0, 52, 4, 4);
//        long long57 = lenientChronology27.add((-300L), (long) '4', (int) (short) 10);
//        org.joda.time.Period period58 = new org.joda.time.Period((-30170871360000000L), (-3174845943151792L), (org.joda.time.Chronology) lenientChronology27);
//        org.junit.Assert.assertNotNull(periodType5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
//        org.junit.Assert.assertNotNull(zonedChronology9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str11.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PT0.052S" + "'", str19.equals("PT0.052S"));
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(intArray26);
//        org.junit.Assert.assertNotNull(lenientChronology27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "UTC" + "'", str30.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "UTC" + "'", str31.equals("UTC"));
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Coordinated Universal Time" + "'", str34.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-349199900L) + "'", long38 == (-349199900L));
//        org.junit.Assert.assertNotNull(chronology39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(period42);
//        org.junit.Assert.assertNotNull(period44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-61054729675996L) + "'", long53 == (-61054729675996L));
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 220L + "'", long57 == 220L);
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) '4', chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        int int7 = period5.getMillis();
        org.joda.time.Period period9 = period5.minusYears((int) ' ');
        int[] intArray11 = iSOChronology0.get((org.joda.time.ReadablePeriod) period9, (long) (short) 0);
        org.joda.time.DurationField durationField12 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology0.hourOfHalfday();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str17 = dateTimeZone16.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone16);
        org.joda.time.chrono.LenientChronology lenientChronology19 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology15);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology15.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (-1));
        long long24 = offsetDateTimeField22.roundHalfFloor(2704L);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField22.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField27 = new org.joda.time.field.DividedDateTimeField(dateTimeField14, dateTimeFieldType25, (int) '4');
        org.joda.time.DurationField durationField28 = dividedDateTimeField27.getDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "UTC" + "'", str17.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(lenientChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(durationField28);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 1, (java.lang.Number) 100, (java.lang.Number) 10.0d);
        illegalFieldValueException4.prependMessage("");
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = illegalFieldValueException4.getDateTimeFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = illegalFieldValueException4.getDateTimeFieldType();
        org.junit.Assert.assertNull(dateTimeFieldType7);
        org.junit.Assert.assertNull(dateTimeFieldType8);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', chronology7);
        org.joda.time.Period period10 = period8.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType((int) (short) 0);
        boolean boolean14 = period3.isSupported(durationFieldType13);
        org.joda.time.field.PreciseDurationField preciseDurationField16 = new org.joda.time.field.PreciseDurationField(durationFieldType13, (long) '4');
        org.joda.time.Period period17 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval19 = null;
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval19);
        org.joda.time.Period period21 = new org.joda.time.Period((long) '4', chronology20);
        org.joda.time.Period period23 = period21.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType24 = period23.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType26 = periodType24.getFieldType((int) (short) 0);
        org.joda.time.Period period28 = period17.withField(durationFieldType26, (int) (short) 0);
        org.joda.time.Period period30 = period17.withWeeks((-1));
        org.joda.time.ReadableInterval readableInterval32 = null;
        org.joda.time.Chronology chronology33 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) '4', chronology33);
        org.joda.time.Period period36 = period34.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType37 = period36.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType39 = periodType37.getFieldType((int) (short) 0);
        org.joda.time.Period period41 = period30.withField(durationFieldType39, (int) (short) -1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(durationFieldType39, "Weeks");
        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) preciseDurationField16, durationFieldType39);
        long long47 = decoratedDurationField44.add((long) 100, (int) (byte) 100);
        org.joda.time.DurationFieldType durationFieldType48 = decoratedDurationField44.getType();
        long long49 = decoratedDurationField44.getUnitMillis();
        long long51 = decoratedDurationField44.getMillis((-61054729675996L));
        try {
            org.joda.time.Period period52 = new org.joda.time.Period((java.lang.Object) (-61054729675996L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Long");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(durationFieldType39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 5300L + "'", long47 == 5300L);
        org.junit.Assert.assertNotNull(durationFieldType48);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 52L + "'", long49 == 52L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-3174845943151792L) + "'", long51 == (-3174845943151792L));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.Chronology chronology24 = zonedChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology5.weekyearOfCentury();
        try {
            long long31 = zonedChronology5.getDateTimeMillis((long) 100, 0, (int) (byte) 10, 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(2440588L);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "DayTime", 0, 10);
        int int6 = fixedDateTimeZone4.getStandardOffset((-210865896000000L));
        int int8 = fixedDateTimeZone4.getStandardOffset((-34919990L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str6 = dateTimeZone5.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone8 = zonedChronology7.getZone();
        java.lang.String str9 = zonedChronology7.toString();
        org.joda.time.Period period10 = new org.joda.time.Period((long) 3, periodType3, (org.joda.time.Chronology) zonedChronology7);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period16 = period14.plusMillis(1);
        java.lang.String str17 = period14.toString();
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.clockhourOfDay();
        boolean boolean21 = iSOChronology18.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period22 = new org.joda.time.Period((java.lang.Object) period14, (org.joda.time.Chronology) iSOChronology18);
        int[] intArray24 = zonedChronology7.get((org.joda.time.ReadablePeriod) period22, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology25 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.Period period26 = new org.joda.time.Period((long) 'a', (long) 0, (org.joda.time.Chronology) lenientChronology25);
        org.joda.time.PeriodType periodType27 = period26.getPeriodType();
        org.joda.time.PeriodType periodType28 = periodType27.withHoursRemoved();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str9.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PT0.052S" + "'", str17.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(lenientChronology25);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        long long9 = offsetDateTimeField7.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial10 = null;
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField7.getAsText(readablePartial10, 0, locale12);
        long long16 = offsetDateTimeField7.add(220L, 68);
        int int18 = offsetDateTimeField7.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField7.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, "org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 244800220L + "'", long16 == 244800220L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.Chronology chronology24 = zonedChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology5.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str28 = dateTimeZone27.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology26, dateTimeZone27);
        org.joda.time.chrono.LenientChronology lenientChronology30 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (-1));
        long long35 = offsetDateTimeField33.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField33.getAsText(readablePartial36, 0, locale38);
        long long42 = offsetDateTimeField33.add(220L, 68);
        int int44 = offsetDateTimeField33.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField33.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType45);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology49.clockhourOfDay();
        org.joda.time.Period period51 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.DurationField durationField52 = iSOChronology49.millis();
        org.joda.time.DurationField durationField53 = iSOChronology49.weeks();
        org.joda.time.DurationField durationField54 = iSOChronology49.days();
        long long57 = durationField54.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval59 = null;
        org.joda.time.Chronology chronology60 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval59);
        org.joda.time.Period period61 = new org.joda.time.Period((long) '4', chronology60);
        org.joda.time.Period period62 = period61.toPeriod();
        org.joda.time.ReadableInterval readableInterval64 = null;
        org.joda.time.Chronology chronology65 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval64);
        org.joda.time.Period period66 = new org.joda.time.Period((long) '4', chronology65);
        org.joda.time.Period period68 = period66.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType69 = period68.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType71 = periodType69.getFieldType((int) (short) 0);
        boolean boolean72 = period61.isSupported(durationFieldType71);
        org.joda.time.field.PreciseDurationField preciseDurationField74 = new org.joda.time.field.PreciseDurationField(durationFieldType71, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField76 = new org.joda.time.field.ScaledDurationField(durationField54, durationFieldType71, (int) (short) 100);
        long long78 = scaledDurationField76.getValueAsLong((long) 68);
        long long80 = scaledDurationField76.getMillis(52);
        int int81 = scaledDurationField76.getScalar();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField82 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType45, (org.joda.time.DurationField) scaledDurationField76);
        java.util.Locale locale85 = null;
        try {
            long long86 = unsupportedDateTimeField82.set((-32L), "PT-0.065S", locale85);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(lenientChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 244800220L + "'", long42 == 244800220L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(durationField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 10L + "'", long57 == 10L);
        org.junit.Assert.assertNotNull(chronology60);
        org.junit.Assert.assertNotNull(period62);
        org.junit.Assert.assertNotNull(chronology65);
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertNotNull(periodType69);
        org.junit.Assert.assertNotNull(durationFieldType71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 449280000000L + "'", long80 == 449280000000L);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 100 + "'", int81 == 100);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField82);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 1, periodType1, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DurationField durationField8 = iSOChronology4.seconds();
        org.joda.time.chrono.LenientChronology lenientChronology9 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology4);
        long long13 = lenientChronology9.add(0L, 2440578L, 100);
        org.joda.time.ReadableInterval readableInterval15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) '4', chronology16);
        org.joda.time.Period period18 = period17.toPeriod();
        org.joda.time.ReadableInterval readableInterval20 = null;
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval20);
        org.joda.time.Period period22 = new org.joda.time.Period((long) '4', chronology21);
        org.joda.time.Period period24 = period22.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType25 = period24.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType27 = periodType25.getFieldType((int) (short) 0);
        boolean boolean28 = period17.isSupported(durationFieldType27);
        org.joda.time.field.PreciseDurationField preciseDurationField30 = new org.joda.time.field.PreciseDurationField(durationFieldType27, (long) '4');
        org.joda.time.ReadableInterval readableInterval32 = null;
        org.joda.time.Chronology chronology33 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) '4', chronology33);
        org.joda.time.Period period36 = period34.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType37 = period36.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType39 = periodType37.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField41 = new org.joda.time.field.PreciseDurationField(durationFieldType39, (long) (byte) 100);
        long long44 = preciseDurationField41.getMillis(0L, 10L);
        long long46 = preciseDurationField41.getMillis(1560628908182L);
        int int47 = preciseDurationField30.compareTo((org.joda.time.DurationField) preciseDurationField41);
        boolean boolean48 = lenientChronology9.equals((java.lang.Object) preciseDurationField30);
        org.joda.time.DurationField durationField49 = lenientChronology9.weekyears();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(lenientChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 244057800L + "'", long13 == 244057800L);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(durationFieldType39);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 156062890818200L + "'", long46 == 156062890818200L);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(durationField49);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', chronology7);
        org.joda.time.Period period10 = period8.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType((int) (short) 0);
        boolean boolean14 = period3.isSupported(durationFieldType13);
        org.joda.time.field.PreciseDurationField preciseDurationField16 = new org.joda.time.field.PreciseDurationField(durationFieldType13, (long) '4');
        org.joda.time.Period period17 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval19 = null;
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval19);
        org.joda.time.Period period21 = new org.joda.time.Period((long) '4', chronology20);
        org.joda.time.Period period23 = period21.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType24 = period23.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType26 = periodType24.getFieldType((int) (short) 0);
        org.joda.time.Period period28 = period17.withField(durationFieldType26, (int) (short) 0);
        org.joda.time.Period period30 = period17.withWeeks((-1));
        org.joda.time.ReadableInterval readableInterval32 = null;
        org.joda.time.Chronology chronology33 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) '4', chronology33);
        org.joda.time.Period period36 = period34.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType37 = period36.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType39 = periodType37.getFieldType((int) (short) 0);
        org.joda.time.Period period41 = period30.withField(durationFieldType39, (int) (short) -1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(durationFieldType39, "Weeks");
        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) preciseDurationField16, durationFieldType39);
        int int46 = decoratedDurationField44.getValue((long) (short) 1);
        long long47 = decoratedDurationField44.getUnitMillis();
        java.lang.String str48 = decoratedDurationField44.toString();
        long long51 = decoratedDurationField44.subtract(3600000L, (long) 37);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(durationFieldType39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 52L + "'", long47 == 52L);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "DurationField[years]" + "'", str48.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 3598076L + "'", long51 == 3598076L);
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test304");
//        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.dayTime();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str8 = dateTimeZone7.getID();
//        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology6, dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone10 = zonedChronology9.getZone();
//        java.lang.String str11 = zonedChronology9.toString();
//        org.joda.time.Period period12 = new org.joda.time.Period((long) 3, periodType5, (org.joda.time.Chronology) zonedChronology9);
//        org.joda.time.ReadableInterval readableInterval14 = null;
//        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval14);
//        org.joda.time.Period period16 = new org.joda.time.Period((long) '4', chronology15);
//        org.joda.time.Period period18 = period16.plusMillis(1);
//        java.lang.String str19 = period16.toString();
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.clockhourOfDay();
//        boolean boolean23 = iSOChronology20.equals((java.lang.Object) (-1.0f));
//        org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) period16, (org.joda.time.Chronology) iSOChronology20);
//        int[] intArray26 = zonedChronology9.get((org.joda.time.ReadablePeriod) period24, (-1L));
//        org.joda.time.chrono.LenientChronology lenientChronology27 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology9);
//        org.joda.time.Period period28 = new org.joda.time.Period((long) 'a', (long) 0, (org.joda.time.Chronology) lenientChronology27);
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str30 = dateTimeZone29.getID();
//        java.lang.String str31 = dateTimeZone29.getID();
//        java.util.TimeZone timeZone32 = dateTimeZone29.toTimeZone();
//        java.lang.String str34 = dateTimeZone29.getName((long) 3);
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
//        long long38 = dateTimeZone29.getMillisKeepLocal(dateTimeZone36, (long) (byte) 100);
//        org.joda.time.Chronology chronology39 = lenientChronology27.withZone(dateTimeZone29);
//        org.joda.time.DateTimeField dateTimeField40 = lenientChronology27.monthOfYear();
//        org.joda.time.Period period41 = new org.joda.time.Period(864000000000L, 1L, (org.joda.time.Chronology) lenientChronology27);
//        org.joda.time.DurationField durationField42 = lenientChronology27.hours();
//        org.junit.Assert.assertNotNull(periodType5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
//        org.junit.Assert.assertNotNull(zonedChronology9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str11.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PT0.052S" + "'", str19.equals("PT0.052S"));
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(intArray26);
//        org.junit.Assert.assertNotNull(lenientChronology27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "UTC" + "'", str30.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "UTC" + "'", str31.equals("UTC"));
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Coordinated Universal Time" + "'", str34.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-349199900L) + "'", long38 == (-349199900L));
//        org.junit.Assert.assertNotNull(chronology39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(durationField42);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.Chronology chronology24 = zonedChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology5.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str28 = dateTimeZone27.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology26, dateTimeZone27);
        org.joda.time.chrono.LenientChronology lenientChronology30 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (-1));
        long long35 = offsetDateTimeField33.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField33.getAsText(readablePartial36, 0, locale38);
        long long42 = offsetDateTimeField33.add(220L, 68);
        int int44 = offsetDateTimeField33.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField33.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType45);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology49.clockhourOfDay();
        org.joda.time.Period period51 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.DurationField durationField52 = iSOChronology49.millis();
        org.joda.time.DurationField durationField53 = iSOChronology49.weeks();
        org.joda.time.DurationField durationField54 = iSOChronology49.days();
        long long57 = durationField54.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval59 = null;
        org.joda.time.Chronology chronology60 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval59);
        org.joda.time.Period period61 = new org.joda.time.Period((long) '4', chronology60);
        org.joda.time.Period period62 = period61.toPeriod();
        org.joda.time.ReadableInterval readableInterval64 = null;
        org.joda.time.Chronology chronology65 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval64);
        org.joda.time.Period period66 = new org.joda.time.Period((long) '4', chronology65);
        org.joda.time.Period period68 = period66.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType69 = period68.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType71 = periodType69.getFieldType((int) (short) 0);
        boolean boolean72 = period61.isSupported(durationFieldType71);
        org.joda.time.field.PreciseDurationField preciseDurationField74 = new org.joda.time.field.PreciseDurationField(durationFieldType71, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField76 = new org.joda.time.field.ScaledDurationField(durationField54, durationFieldType71, (int) (short) 100);
        long long78 = scaledDurationField76.getValueAsLong((long) 68);
        long long80 = scaledDurationField76.getMillis(52);
        int int81 = scaledDurationField76.getScalar();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField82 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType45, (org.joda.time.DurationField) scaledDurationField76);
        org.joda.time.ReadablePartial readablePartial83 = null;
        java.util.Locale locale84 = null;
        try {
            java.lang.String str85 = unsupportedDateTimeField82.getAsShortText(readablePartial83, locale84);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(lenientChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 244800220L + "'", long42 == 244800220L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(durationField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 10L + "'", long57 == 10L);
        org.junit.Assert.assertNotNull(chronology60);
        org.junit.Assert.assertNotNull(period62);
        org.junit.Assert.assertNotNull(chronology65);
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertNotNull(periodType69);
        org.junit.Assert.assertNotNull(durationFieldType71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 449280000000L + "'", long80 == 449280000000L);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 100 + "'", int81 == 100);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField82);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType2 = periodType1.withSecondsRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.clockhourOfDay();
        boolean boolean6 = iSOChronology3.equals((java.lang.Object) (-1.0f));
        org.joda.time.DateTimeZone dateTimeZone7 = iSOChronology3.getZone();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (byte) -1, periodType2, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology3.monthOfYear();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str7 = dateTimeZone6.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology5, dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone9 = zonedChronology8.getZone();
        java.lang.String str10 = zonedChronology8.toString();
        org.joda.time.Period period11 = new org.joda.time.Period((long) 3, periodType4, (org.joda.time.Chronology) zonedChronology8);
        org.joda.time.ReadableInterval readableInterval13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) '4', chronology14);
        org.joda.time.Period period17 = period15.plusMillis(1);
        java.lang.String str18 = period15.toString();
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.clockhourOfDay();
        boolean boolean22 = iSOChronology19.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period23 = new org.joda.time.Period((java.lang.Object) period15, (org.joda.time.Chronology) iSOChronology19);
        int[] intArray25 = zonedChronology8.get((org.joda.time.ReadablePeriod) period23, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology26 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTimeField dateTimeField27 = zonedChronology8.millisOfDay();
        org.joda.time.Chronology chronology28 = zonedChronology8.withUTC();
        org.joda.time.Period period29 = new org.joda.time.Period(3200L, 3598076L, periodType2, (org.joda.time.Chronology) zonedChronology8);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str10.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PT0.052S" + "'", str18.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(lenientChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(chronology28);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        long long9 = offsetDateTimeField7.roundHalfFloor(2704L);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField7.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType10, "days");
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType10, (java.lang.Number) (short) 10, "(\"org.joda.time.JodaTimePermission\" \"hi!\")");
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) '4', chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        int int7 = period5.getMillis();
        org.joda.time.Period period9 = period5.minusYears((int) ' ');
        int[] intArray11 = iSOChronology0.get((org.joda.time.ReadablePeriod) period9, (long) (short) 0);
        org.joda.time.DurationField durationField12 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology0.hourOfHalfday();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str17 = dateTimeZone16.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone16);
        org.joda.time.chrono.LenientChronology lenientChronology19 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology15);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology15.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (-1));
        long long24 = offsetDateTimeField22.roundHalfFloor(2704L);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField22.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField27 = new org.joda.time.field.DividedDateTimeField(dateTimeField14, dateTimeFieldType25, (int) '4');
        int int28 = dividedDateTimeField27.getMinimumValue();
        try {
            long long31 = dividedDateTimeField27.addWrapField(0L, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "UTC" + "'", str17.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(lenientChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        long long10 = durationField7.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period15 = period14.toPeriod();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) '4', chronology18);
        org.joda.time.Period period21 = period19.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType24 = periodType22.getFieldType((int) (short) 0);
        boolean boolean25 = period14.isSupported(durationFieldType24);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType24, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField29 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType24, (int) (short) 100);
        long long31 = scaledDurationField29.getValueAsLong((long) 68);
        long long33 = scaledDurationField29.getMillis(52);
        long long36 = scaledDurationField29.getDifferenceAsLong((-84L), (-34919990L));
        long long39 = scaledDurationField29.getValueAsLong((long) (byte) -1, (long) (-180));
        long long42 = scaledDurationField29.add((long) (-32), (int) (short) -1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 449280000000L + "'", long33 == 449280000000L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-8640000032L) + "'", long42 == (-8640000032L));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) ' ');
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        java.lang.String str5 = lenientChronology4.toString();
        org.joda.time.DateTimeField dateTimeField6 = lenientChronology4.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str9 = dateTimeZone8.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, dateTimeZone8);
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology7.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (-1));
        long long16 = offsetDateTimeField14.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField14.getAsText(readablePartial17, 0, locale19);
        long long23 = offsetDateTimeField14.add(220L, 68);
        int int25 = offsetDateTimeField14.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType26, 70);
        java.lang.String str30 = dividedDateTimeField28.getAsShortText((-301624300800000000L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str5.equals("LenientChronology[ISOChronology[UTC]]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 244800220L + "'", long23 == 244800220L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "0" + "'", str30.equals("0"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period6 = period4.withYears((int) (short) 10);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period4.toDurationFrom(readableInstant7);
        org.joda.time.Period period10 = org.joda.time.Period.months(100);
        int int11 = period10.getMonths();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        org.joda.time.Period period18 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.Period period19 = new org.joda.time.Period((long) (byte) 1, periodType13, (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.PeriodType periodType20 = periodType13.withYearsRemoved();
        boolean boolean21 = period10.equals((java.lang.Object) periodType13);
        org.joda.time.Period period22 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration8, periodType13);
        java.lang.String str23 = periodType13.toString();
        org.joda.time.PeriodType periodType24 = periodType13.withMinutesRemoved();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "PeriodType[Weeks]" + "'", str23.equals("PeriodType[Weeks]"));
        org.junit.Assert.assertNotNull(periodType24);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long4 = cachedDateTimeZone2.nextTransition((long) (-32));
        int int6 = cachedDateTimeZone2.getStandardOffset((long) 68);
        int int8 = cachedDateTimeZone2.getOffset(1872000000L);
        boolean boolean9 = cachedDateTimeZone2.isFixed();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-32L) + "'", long4 == (-32L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 349200000 + "'", int6 == 349200000);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 349200000 + "'", int8 == 349200000);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        org.joda.time.DurationField durationField8 = offsetDateTimeField7.getLeapDurationField();
        long long11 = offsetDateTimeField7.add(10L, 1);
        int int13 = offsetDateTimeField7.getLeapAmount(14159997L);
        java.util.Locale locale14 = null;
        int int15 = offsetDateTimeField7.getMaximumTextLength(locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        int int17 = offsetDateTimeField7.getMinimumValue(readablePartial16);
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.clockhourOfDay();
        org.joda.time.Period period25 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology23);
        org.joda.time.Period period26 = new org.joda.time.Period((long) (byte) 1, periodType20, (org.joda.time.Chronology) iSOChronology23);
        org.joda.time.DurationField durationField27 = iSOChronology23.halfdays();
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant28, readableInstant29);
        org.joda.time.Period period32 = period30.minusMinutes(52);
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Duration duration34 = period30.toDurationTo(readableInstant33);
        int[] intArray36 = iSOChronology23.get((org.joda.time.ReadablePeriod) period30, 2440588L);
        int int37 = offsetDateTimeField7.getMaximumValue(readablePartial18, intArray36);
        java.lang.String str39 = offsetDateTimeField7.getAsShortText((long) 10);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int int41 = offsetDateTimeField7.getMaximumValue(readablePartial40);
        long long44 = offsetDateTimeField7.add(0L, 520L);
        java.util.Locale locale46 = null;
        java.lang.String str47 = offsetDateTimeField7.getAsText((long) 52, locale46);
        long long49 = offsetDateTimeField7.roundHalfCeiling(84412800000000L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3600010L + "'", long11 == 3600010L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(duration34);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 23 + "'", int37 == 23);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "23" + "'", str39.equals("23"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 23 + "'", int41 == 23);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1872000000L + "'", long44 == 1872000000L);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "23" + "'", str47.equals("23"));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 84412800000000L + "'", long49 == 84412800000000L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        long long9 = offsetDateTimeField7.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial10 = null;
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField7.getAsText(readablePartial10, 0, locale12);
        int int16 = offsetDateTimeField7.getDifference(0L, 4492800000070L);
        java.lang.String str17 = offsetDateTimeField7.getName();
        long long19 = offsetDateTimeField7.roundHalfFloor(244800220L);
        long long21 = offsetDateTimeField7.roundHalfCeiling((-46934L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1248000) + "'", int16 == (-1248000));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "clockhourOfDay" + "'", str17.equals("clockhourOfDay"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 244800000L + "'", long19 == 244800000L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType4 = periodType3.withWeeksRemoved();
        org.joda.time.PeriodType periodType5 = org.joda.time.DateTimeUtils.getPeriodType(periodType3);
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) 100, periodType5, chronology7);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.clockhourOfDay();
        org.joda.time.Period period13 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology11);
        org.joda.time.Period period14 = new org.joda.time.Period((long) (short) -1, (long) '#', periodType5, (org.joda.time.Chronology) iSOChronology11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = iSOChronology11.withZone(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology11.clockhourOfDay();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long4 = cachedDateTimeZone2.nextTransition((long) (-32));
        int int6 = cachedDateTimeZone2.getStandardOffset((long) 68);
        org.joda.time.DateTimeZone dateTimeZone7 = cachedDateTimeZone2.getUncachedZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-32L) + "'", long4 == (-32L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 349200000 + "'", int6 == 349200000);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.Chronology chronology24 = zonedChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology5.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str28 = dateTimeZone27.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology26, dateTimeZone27);
        org.joda.time.chrono.LenientChronology lenientChronology30 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (-1));
        long long35 = offsetDateTimeField33.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField33.getAsText(readablePartial36, 0, locale38);
        long long42 = offsetDateTimeField33.add(220L, 68);
        int int44 = offsetDateTimeField33.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField33.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType45);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology49.clockhourOfDay();
        org.joda.time.Period period51 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.DurationField durationField52 = iSOChronology49.millis();
        org.joda.time.DurationField durationField53 = iSOChronology49.weeks();
        org.joda.time.DurationField durationField54 = iSOChronology49.days();
        long long57 = durationField54.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval59 = null;
        org.joda.time.Chronology chronology60 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval59);
        org.joda.time.Period period61 = new org.joda.time.Period((long) '4', chronology60);
        org.joda.time.Period period62 = period61.toPeriod();
        org.joda.time.ReadableInterval readableInterval64 = null;
        org.joda.time.Chronology chronology65 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval64);
        org.joda.time.Period period66 = new org.joda.time.Period((long) '4', chronology65);
        org.joda.time.Period period68 = period66.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType69 = period68.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType71 = periodType69.getFieldType((int) (short) 0);
        boolean boolean72 = period61.isSupported(durationFieldType71);
        org.joda.time.field.PreciseDurationField preciseDurationField74 = new org.joda.time.field.PreciseDurationField(durationFieldType71, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField76 = new org.joda.time.field.ScaledDurationField(durationField54, durationFieldType71, (int) (short) 100);
        long long78 = scaledDurationField76.getValueAsLong((long) 68);
        long long80 = scaledDurationField76.getMillis(52);
        int int81 = scaledDurationField76.getScalar();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField82 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType45, (org.joda.time.DurationField) scaledDurationField76);
        long long84 = scaledDurationField76.getMillis(0L);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(lenientChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 244800220L + "'", long42 == 244800220L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(durationField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 10L + "'", long57 == 10L);
        org.junit.Assert.assertNotNull(chronology60);
        org.junit.Assert.assertNotNull(period62);
        org.junit.Assert.assertNotNull(chronology65);
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertNotNull(periodType69);
        org.junit.Assert.assertNotNull(durationFieldType71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 449280000000L + "'", long80 == 449280000000L);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 100 + "'", int81 == 100);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField82);
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 0L + "'", long84 == 0L);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', chronology7);
        org.joda.time.Period period10 = period8.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType((int) (short) 0);
        boolean boolean14 = period3.isSupported(durationFieldType13);
        org.joda.time.field.PreciseDurationField preciseDurationField16 = new org.joda.time.field.PreciseDurationField(durationFieldType13, (long) '4');
        org.joda.time.Period period17 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval19 = null;
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval19);
        org.joda.time.Period period21 = new org.joda.time.Period((long) '4', chronology20);
        org.joda.time.Period period23 = period21.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType24 = period23.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType26 = periodType24.getFieldType((int) (short) 0);
        org.joda.time.Period period28 = period17.withField(durationFieldType26, (int) (short) 0);
        org.joda.time.Period period30 = period17.withWeeks((-1));
        org.joda.time.ReadableInterval readableInterval32 = null;
        org.joda.time.Chronology chronology33 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) '4', chronology33);
        org.joda.time.Period period36 = period34.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType37 = period36.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType39 = periodType37.getFieldType((int) (short) 0);
        org.joda.time.Period period41 = period30.withField(durationFieldType39, (int) (short) -1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(durationFieldType39, "Weeks");
        org.joda.time.field.DecoratedDurationField decoratedDurationField44 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) preciseDurationField16, durationFieldType39);
        int int46 = decoratedDurationField44.getValue((long) (short) 1);
        long long49 = decoratedDurationField44.getDifferenceAsLong((-58987094399903L), (long) (byte) 100);
        java.lang.String str50 = decoratedDurationField44.toString();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(durationFieldType39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-1134367200000L) + "'", long49 == (-1134367200000L));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "DurationField[years]" + "'", str50.equals("DurationField[years]"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        java.lang.String str5 = lenientChronology4.toString();
        org.joda.time.DateTimeField dateTimeField6 = lenientChronology4.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str9 = dateTimeZone8.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, dateTimeZone8);
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology7.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (-1));
        long long16 = offsetDateTimeField14.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField14.getAsText(readablePartial17, 0, locale19);
        long long23 = offsetDateTimeField14.add(220L, 68);
        int int25 = offsetDateTimeField14.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType26, 70);
        long long30 = dividedDateTimeField28.roundFloor((long) 2);
        int int32 = dividedDateTimeField28.get((-52L));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField33 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField28);
        org.joda.time.DurationField durationField34 = remainderDateTimeField33.getRangeDurationField();
        int int36 = remainderDateTimeField33.get((-181583947L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str5.equals("LenientChronology[ISOChronology[UTC]]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 244800220L + "'", long23 == 244800220L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 69 + "'", int36 == 69);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        long long9 = offsetDateTimeField7.roundCeiling(244057800L);
        org.joda.time.DurationField durationField10 = offsetDateTimeField7.getLeapDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 244800000L + "'", long9 == 244800000L);
        org.junit.Assert.assertNull(durationField10);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.joda.time.Period period1 = org.joda.time.Period.days((-180));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        org.joda.time.DurationField durationField8 = offsetDateTimeField7.getLeapDurationField();
        long long11 = offsetDateTimeField7.add(10L, 1);
        int int13 = offsetDateTimeField7.getLeapAmount(14159997L);
        int int15 = offsetDateTimeField7.getLeapAmount(32L);
        int int18 = offsetDateTimeField7.getDifference(52L, (long) 100);
        org.joda.time.ReadablePartial readablePartial19 = null;
        java.util.Locale locale21 = null;
        java.lang.String str22 = offsetDateTimeField7.getAsShortText(readablePartial19, (-2), locale21);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3600010L + "'", long11 == 3600010L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-2" + "'", str22.equals("-2"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler2 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file3 = null;
        java.io.File[] fileArray4 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = zoneInfoCompiler2.compile(file3, fileArray4);
        java.io.File file6 = null;
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler7 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file8 = null;
        java.io.File[] fileArray9 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap10 = zoneInfoCompiler7.compile(file8, fileArray9);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap11 = zoneInfoCompiler2.compile(file6, fileArray9);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap12 = zoneInfoCompiler0.compile(file1, fileArray9);
        org.junit.Assert.assertNotNull(fileArray4);
        org.junit.Assert.assertNotNull(strMap5);
        org.junit.Assert.assertNotNull(fileArray9);
        org.junit.Assert.assertNotNull(strMap10);
        org.junit.Assert.assertNotNull(strMap11);
        org.junit.Assert.assertNotNull(strMap12);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period2 = org.joda.time.Period.seconds(1);
        org.joda.time.Period period4 = period2.plusHours((-100));
        org.joda.time.Duration duration5 = period2.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration5, readableInstant6);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration5, readableInstant8);
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(durationFieldType8, "UTC");
        java.lang.String str12 = illegalFieldValueException11.getIllegalStringValue();
        java.lang.Number number13 = illegalFieldValueException11.getUpperBound();
        java.lang.String str14 = illegalFieldValueException11.getIllegalValueAsString();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UTC" + "'", str12.equals("UTC"));
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("LenientChronology[ZonedChronology[ISOChronology[UTC], UTC]]", (java.lang.Number) (-1885005599054400000L), (java.lang.Number) 8115270322546400L, number3);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        long long9 = offsetDateTimeField7.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial10 = null;
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField7.getAsText(readablePartial10, 0, locale12);
        int int14 = offsetDateTimeField7.getMaximumValue();
        int int16 = offsetDateTimeField7.getMinimumValue((long) (-3491999));
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField7, 3, 3599999, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3 for clockhourOfDay must be in the range [3599999,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 23 + "'", int14 == 23);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.joda.time.Period period1 = org.joda.time.Period.hours(10);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Period period5 = period4.normalizedStandard();
        org.joda.time.Period period7 = period4.withYears(10);
        org.joda.time.Period period9 = period7.withWeeks((-1));
        org.joda.time.MutablePeriod mutablePeriod10 = period9.toMutablePeriod();
        int int11 = period9.size();
        try {
            int int13 = period9.getValue(37);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(mutablePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "Weeks", "Weeks");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "Weeks", "org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getName(locale9, "+08:00", "PT-1M-0.001S");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 1, periodType1, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DurationField durationField8 = iSOChronology4.halfdays();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology4.clockhourOfHalfday();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str12 = dateTimeZone11.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology10, dateTimeZone11);
        org.joda.time.chrono.LenientChronology lenientChronology14 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology10.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (-1));
        long long19 = offsetDateTimeField17.roundHalfFloor(2704L);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField17.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, dateTimeFieldType20, (int) (byte) 100);
        org.joda.time.ReadableInterval readableInterval24 = null;
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval24);
        org.joda.time.Period period26 = new org.joda.time.Period((long) '4', chronology25);
        org.joda.time.Period period28 = period26.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType29 = period28.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType31 = periodType29.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField33 = new org.joda.time.field.PreciseDurationField(durationFieldType31, (long) (byte) 100);
        java.lang.String str34 = preciseDurationField33.getName();
        long long35 = preciseDurationField33.getUnitMillis();
        int int38 = preciseDurationField33.getDifference((-349199900L), (long) 'a');
        org.joda.time.DurationFieldType durationFieldType39 = preciseDurationField33.getType();
        long long42 = preciseDurationField33.getValueAsLong(244057800L, (long) 2);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, (org.joda.time.DurationField) preciseDurationField33);
        boolean boolean44 = unsupportedDateTimeField43.isLenient();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UTC" + "'", str12.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(lenientChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "years" + "'", str34.equals("years"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 100L + "'", long35 == 100L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-3491999) + "'", int38 == (-3491999));
        org.junit.Assert.assertNotNull(durationFieldType39);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 2440578L + "'", long42 == 2440578L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        java.lang.String str5 = lenientChronology4.toString();
        org.joda.time.DateTimeField dateTimeField6 = lenientChronology4.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str9 = dateTimeZone8.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, dateTimeZone8);
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology7.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (-1));
        long long16 = offsetDateTimeField14.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField14.getAsText(readablePartial17, 0, locale19);
        long long23 = offsetDateTimeField14.add(220L, 68);
        int int25 = offsetDateTimeField14.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType26, 70);
        long long30 = dividedDateTimeField28.roundFloor((long) 2);
        int int32 = dividedDateTimeField28.get((-52L));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField33 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField28);
        long long35 = remainderDateTimeField33.roundHalfEven(3598076L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str5.equals("LenientChronology[ISOChronology[UTC]]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 244800220L + "'", long23 == 244800220L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        long long9 = offsetDateTimeField7.roundHalfFloor(2704L);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField7.getType();
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField7.getAsText(10, locale12);
        int int14 = offsetDateTimeField7.getMaximumValue();
        java.lang.String str15 = offsetDateTimeField7.getName();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10" + "'", str13.equals("10"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 23 + "'", int14 == 23);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "clockhourOfDay" + "'", str15.equals("clockhourOfDay"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "DayTime", 0, 10);
        int int6 = fixedDateTimeZone4.getStandardOffset((-210865896000000L));
        int int8 = fixedDateTimeZone4.getStandardOffset(156062890818200L);
        int int10 = fixedDateTimeZone4.getOffsetFromLocal((long) 52);
        long long12 = fixedDateTimeZone4.nextTransition((long) '4');
        int int14 = fixedDateTimeZone4.getOffset(16409692800010L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 52L + "'", long12 == 52L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        org.joda.time.DurationField durationField8 = offsetDateTimeField7.getLeapDurationField();
        long long11 = offsetDateTimeField7.add(0L, (long) (short) 100);
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField7.getAsText((long) 52, locale13);
        long long16 = offsetDateTimeField7.roundHalfEven(2440588L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 360000000L + "'", long11 == 360000000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "23" + "'", str14.equals("23"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3600000L + "'", long16 == 3600000L);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(1);
        int int2 = period1.getMillis();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) '4', chronology5);
        org.joda.time.Period period7 = period6.toPeriod();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) '4', chronology10);
        org.joda.time.Period period13 = period11.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType14 = period13.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType16 = periodType14.getFieldType((int) (short) 0);
        boolean boolean17 = period6.isSupported(durationFieldType16);
        org.joda.time.field.PreciseDurationField preciseDurationField19 = new org.joda.time.field.PreciseDurationField(durationFieldType16, (long) '4');
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period(readableInstant20, readableInstant21);
        org.joda.time.Period period24 = period22.minusMinutes(52);
        org.joda.time.DurationFieldType[] durationFieldTypeArray25 = period24.getFieldTypes();
        boolean boolean26 = preciseDurationField19.equals((java.lang.Object) durationFieldTypeArray25);
        org.joda.time.PeriodType periodType27 = org.joda.time.PeriodType.forFields(durationFieldTypeArray25);
        org.joda.time.Period period28 = new org.joda.time.Period((java.lang.Object) period1, periodType27);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(durationFieldType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(durationFieldTypeArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(periodType27);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        long long9 = offsetDateTimeField7.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial10 = null;
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField7.getAsText(readablePartial10, 0, locale12);
        int int16 = offsetDateTimeField7.getDifference(0L, 4492800000070L);
        java.lang.String str17 = offsetDateTimeField7.getName();
        boolean boolean19 = offsetDateTimeField7.isLeap((-61054729675996L));
        int int21 = offsetDateTimeField7.getMaximumValue(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1248000) + "'", int16 == (-1248000));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "clockhourOfDay" + "'", str17.equals("clockhourOfDay"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 23 + "'", int21 == 23);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.Chronology chronology24 = zonedChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology5.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str28 = dateTimeZone27.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology26, dateTimeZone27);
        org.joda.time.chrono.LenientChronology lenientChronology30 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (-1));
        long long35 = offsetDateTimeField33.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField33.getAsText(readablePartial36, 0, locale38);
        long long42 = offsetDateTimeField33.add(220L, 68);
        int int44 = offsetDateTimeField33.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField33.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType45);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology49.clockhourOfDay();
        org.joda.time.Period period51 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.DurationField durationField52 = iSOChronology49.millis();
        org.joda.time.DurationField durationField53 = iSOChronology49.weeks();
        org.joda.time.DurationField durationField54 = iSOChronology49.days();
        long long57 = durationField54.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval59 = null;
        org.joda.time.Chronology chronology60 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval59);
        org.joda.time.Period period61 = new org.joda.time.Period((long) '4', chronology60);
        org.joda.time.Period period62 = period61.toPeriod();
        org.joda.time.ReadableInterval readableInterval64 = null;
        org.joda.time.Chronology chronology65 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval64);
        org.joda.time.Period period66 = new org.joda.time.Period((long) '4', chronology65);
        org.joda.time.Period period68 = period66.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType69 = period68.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType71 = periodType69.getFieldType((int) (short) 0);
        boolean boolean72 = period61.isSupported(durationFieldType71);
        org.joda.time.field.PreciseDurationField preciseDurationField74 = new org.joda.time.field.PreciseDurationField(durationFieldType71, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField76 = new org.joda.time.field.ScaledDurationField(durationField54, durationFieldType71, (int) (short) 100);
        long long78 = scaledDurationField76.getValueAsLong((long) 68);
        long long80 = scaledDurationField76.getMillis(52);
        int int81 = scaledDurationField76.getScalar();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField82 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType45, (org.joda.time.DurationField) scaledDurationField76);
        try {
            java.lang.String str84 = unsupportedDateTimeField82.getAsText((-10246L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(lenientChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 244800220L + "'", long42 == 244800220L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(durationField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 10L + "'", long57 == 10L);
        org.junit.Assert.assertNotNull(chronology60);
        org.junit.Assert.assertNotNull(period62);
        org.junit.Assert.assertNotNull(chronology65);
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertNotNull(periodType69);
        org.junit.Assert.assertNotNull(durationFieldType71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 449280000000L + "'", long80 == 449280000000L);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 100 + "'", int81 == 100);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField82);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) '4', chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        int int7 = period5.getMillis();
        org.joda.time.Period period9 = period5.minusYears((int) ' ');
        int[] intArray11 = iSOChronology0.get((org.joda.time.ReadablePeriod) period9, (long) (short) 0);
        org.joda.time.Period period12 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval14);
        org.joda.time.Period period16 = new org.joda.time.Period((long) '4', chronology15);
        org.joda.time.Period period18 = period16.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType19 = period18.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType((int) (short) 0);
        org.joda.time.Period period23 = period12.withField(durationFieldType21, (int) (short) 0);
        org.joda.time.Period period25 = period12.withWeeks((-1));
        org.joda.time.Period period26 = period9.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.Period period28 = period26.minusMinutes(8);
        org.joda.time.Period period30 = period26.plusMillis((int) 'a');
        int int31 = period30.getSeconds();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType6 = period5.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField10 = new org.joda.time.field.PreciseDurationField(durationFieldType8, (long) (byte) 100);
        long long13 = preciseDurationField10.getMillis(0L, 10L);
        long long16 = preciseDurationField10.getMillis((long) 100, (long) (short) 0);
        long long18 = preciseDurationField10.getMillis((-3599990L));
        boolean boolean19 = preciseDurationField10.isPrecise();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10000L + "'", long16 == 10000L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-359999000L) + "'", long18 == (-359999000L));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.Chronology chronology24 = zonedChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology5.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str28 = dateTimeZone27.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology26, dateTimeZone27);
        org.joda.time.chrono.LenientChronology lenientChronology30 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (-1));
        long long35 = offsetDateTimeField33.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField33.getAsText(readablePartial36, 0, locale38);
        long long42 = offsetDateTimeField33.add(220L, 68);
        int int44 = offsetDateTimeField33.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField33.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType45);
        org.joda.time.DurationField durationField47 = zeroIsMaxDateTimeField46.getLeapDurationField();
        boolean boolean49 = zeroIsMaxDateTimeField46.isLeap((long) (-100));
        boolean boolean51 = zeroIsMaxDateTimeField46.isLeap(5200L);
        org.joda.time.ReadablePartial readablePartial52 = null;
        int int53 = zeroIsMaxDateTimeField46.getMaximumValue(readablePartial52);
        long long56 = zeroIsMaxDateTimeField46.add(0L, 2);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(lenientChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 244800220L + "'", long42 == 244800220L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNull(durationField47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 100 + "'", int53 == 100);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 63072000000L + "'", long56 == 63072000000L);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Weeks", (java.lang.Number) (-99999L), (java.lang.Number) 1560628908182L, (java.lang.Number) (byte) -1);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) -1 + "'", number5.equals((byte) -1));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        long long10 = durationField7.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period15 = period14.toPeriod();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) '4', chronology18);
        org.joda.time.Period period21 = period19.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType24 = periodType22.getFieldType((int) (short) 0);
        boolean boolean25 = period14.isSupported(durationFieldType24);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType24, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField29 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType24, (int) (short) 100);
        long long31 = scaledDurationField29.getValueAsLong((long) 68);
        long long34 = scaledDurationField29.getDifferenceAsLong(220L, (long) 'a');
        long long37 = scaledDurationField29.getValueAsLong((long) 52, 0L);
        long long39 = scaledDurationField29.getMillis((int) (byte) -1);
        long long42 = scaledDurationField29.getMillis((long) (short) 100, 0L);
        long long44 = scaledDurationField29.getMillis(0);
        long long46 = scaledDurationField29.getMillis((int) '4');
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-8640000000L) + "'", long39 == (-8640000000L));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 864000000000L + "'", long42 == 864000000000L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 449280000000L + "'", long46 == 449280000000L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.Chronology chronology24 = zonedChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology5.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str28 = dateTimeZone27.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology26, dateTimeZone27);
        org.joda.time.chrono.LenientChronology lenientChronology30 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (-1));
        long long35 = offsetDateTimeField33.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField33.getAsText(readablePartial36, 0, locale38);
        long long42 = offsetDateTimeField33.add(220L, 68);
        int int44 = offsetDateTimeField33.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField33.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType45);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology49.clockhourOfDay();
        org.joda.time.Period period51 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.DurationField durationField52 = iSOChronology49.millis();
        org.joda.time.DurationField durationField53 = iSOChronology49.weeks();
        org.joda.time.DurationField durationField54 = iSOChronology49.days();
        long long57 = durationField54.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval59 = null;
        org.joda.time.Chronology chronology60 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval59);
        org.joda.time.Period period61 = new org.joda.time.Period((long) '4', chronology60);
        org.joda.time.Period period62 = period61.toPeriod();
        org.joda.time.ReadableInterval readableInterval64 = null;
        org.joda.time.Chronology chronology65 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval64);
        org.joda.time.Period period66 = new org.joda.time.Period((long) '4', chronology65);
        org.joda.time.Period period68 = period66.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType69 = period68.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType71 = periodType69.getFieldType((int) (short) 0);
        boolean boolean72 = period61.isSupported(durationFieldType71);
        org.joda.time.field.PreciseDurationField preciseDurationField74 = new org.joda.time.field.PreciseDurationField(durationFieldType71, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField76 = new org.joda.time.field.ScaledDurationField(durationField54, durationFieldType71, (int) (short) 100);
        long long78 = scaledDurationField76.getValueAsLong((long) 68);
        long long80 = scaledDurationField76.getMillis(52);
        int int81 = scaledDurationField76.getScalar();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField82 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType45, (org.joda.time.DurationField) scaledDurationField76);
        org.joda.time.DurationField durationField83 = unsupportedDateTimeField82.getDurationField();
        try {
            java.lang.String str85 = unsupportedDateTimeField82.getAsShortText((long) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(lenientChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 244800220L + "'", long42 == 244800220L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(durationField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 10L + "'", long57 == 10L);
        org.junit.Assert.assertNotNull(chronology60);
        org.junit.Assert.assertNotNull(period62);
        org.junit.Assert.assertNotNull(chronology65);
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertNotNull(periodType69);
        org.junit.Assert.assertNotNull(durationFieldType71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 449280000000L + "'", long80 == 449280000000L);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 100 + "'", int81 == 100);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField82);
        org.junit.Assert.assertNotNull(durationField83);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period5 = period3.plusMillis(1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        int int9 = period3.indexOf(durationFieldType8);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        boolean boolean11 = unsupportedDurationField10.isSupported();
        java.lang.String str12 = unsupportedDurationField10.toString();
        try {
            int int15 = unsupportedDurationField10.getValue(800L, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: days field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDurationField[days]" + "'", str12.equals("UnsupportedDurationField[days]"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.Chronology chronology24 = zonedChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology5.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str28 = dateTimeZone27.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology26, dateTimeZone27);
        org.joda.time.chrono.LenientChronology lenientChronology30 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (-1));
        long long35 = offsetDateTimeField33.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField33.getAsText(readablePartial36, 0, locale38);
        long long42 = offsetDateTimeField33.add(220L, 68);
        int int44 = offsetDateTimeField33.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField33.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType45);
        org.joda.time.DurationField durationField47 = zeroIsMaxDateTimeField46.getLeapDurationField();
        int int49 = zeroIsMaxDateTimeField46.getLeapAmount(1560628909182L);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(lenientChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 244800220L + "'", long42 == 244800220L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNull(durationField47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.clockhourOfDay();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Period period8 = new org.joda.time.Period((long) (byte) 1, periodType2, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DurationField durationField9 = iSOChronology5.halfdays();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.clockhourOfHalfday();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str13 = dateTimeZone12.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology11, dateTimeZone12);
        org.joda.time.chrono.LenientChronology lenientChronology15 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology11.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (-1));
        long long20 = offsetDateTimeField18.roundHalfFloor(2704L);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField18.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType21, (int) (byte) 100);
        org.joda.time.ReadableInterval readableInterval25 = null;
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval25);
        org.joda.time.Period period27 = new org.joda.time.Period((long) '4', chronology26);
        org.joda.time.Period period29 = period27.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType30 = period29.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType32 = periodType30.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField34 = new org.joda.time.field.PreciseDurationField(durationFieldType32, (long) (byte) 100);
        java.lang.String str35 = preciseDurationField34.getName();
        long long36 = preciseDurationField34.getUnitMillis();
        int int39 = preciseDurationField34.getDifference((-349199900L), (long) 'a');
        org.joda.time.DurationFieldType durationFieldType40 = preciseDurationField34.getType();
        long long43 = preciseDurationField34.getValueAsLong(244057800L, (long) 2);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, (org.joda.time.DurationField) preciseDurationField34);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, dateTimeFieldType21, 349200000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UTC" + "'", str13.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(lenientChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "years" + "'", str35.equals("years"));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 100L + "'", long36 == 100L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-3491999) + "'", int39 == (-3491999));
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 2440578L + "'", long43 == 2440578L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        java.lang.String str5 = lenientChronology4.toString();
        org.joda.time.DateTimeField dateTimeField6 = lenientChronology4.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str9 = dateTimeZone8.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, dateTimeZone8);
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology7.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (-1));
        long long16 = offsetDateTimeField14.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField14.getAsText(readablePartial17, 0, locale19);
        long long23 = offsetDateTimeField14.add(220L, 68);
        int int25 = offsetDateTimeField14.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType26, 70);
        long long30 = dividedDateTimeField28.roundFloor((long) 2);
        int int32 = dividedDateTimeField28.get((-52L));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField33 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField28);
        int int34 = remainderDateTimeField33.getMaximumValue();
        long long36 = remainderDateTimeField33.roundHalfFloor((-4693400L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str5.equals("LenientChronology[ISOChronology[UTC]]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 244800220L + "'", long23 == 244800220L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 69 + "'", int34 == 69);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.joda.time.Period period2 = new org.joda.time.Period((long) 100, (long) '#');
        int int3 = period2.getSeconds();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 100, periodType4, chronology6);
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) 100);
        org.joda.time.IllegalInstantException illegalInstantException10 = new org.joda.time.IllegalInstantException("org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0]");
        boolean boolean11 = gregorianChronology0.equals((java.lang.Object) illegalInstantException10);
        org.joda.time.Chronology chronology12 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str14 = dateTimeZone13.getID();
        java.lang.String str15 = dateTimeZone13.getID();
        org.joda.time.Chronology chronology16 = gregorianChronology0.withZone(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str18 = dateTimeZone17.getID();
        org.joda.time.Chronology chronology19 = gregorianChronology0.withZone(dateTimeZone17);
        java.lang.String str20 = dateTimeZone17.toString();
        java.util.TimeZone timeZone21 = dateTimeZone17.toTimeZone();
        boolean boolean23 = dateTimeZone17.isStandardOffset((long) (-3491999));
        long long25 = dateTimeZone17.convertUTCToLocal((long) 349200000);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "UTC" + "'", str18.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 349200000L + "'", long25 == 349200000L);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        java.lang.String str5 = lenientChronology4.toString();
        org.joda.time.DateTimeField dateTimeField6 = lenientChronology4.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str9 = dateTimeZone8.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, dateTimeZone8);
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology7.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (-1));
        long long16 = offsetDateTimeField14.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField14.getAsText(readablePartial17, 0, locale19);
        long long23 = offsetDateTimeField14.add(220L, 68);
        int int25 = offsetDateTimeField14.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType26, 70);
        long long30 = dividedDateTimeField28.roundFloor((long) 2);
        int int32 = dividedDateTimeField28.get((-52L));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField33 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField28);
        int int34 = remainderDateTimeField33.getMaximumValue();
        long long36 = remainderDateTimeField33.roundFloor((long) (short) 100);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str5.equals("LenientChronology[ISOChronology[UTC]]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 244800220L + "'", long23 == 244800220L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 69 + "'", int34 == 69);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.Chronology chronology24 = zonedChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology5.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str28 = dateTimeZone27.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology26, dateTimeZone27);
        org.joda.time.chrono.LenientChronology lenientChronology30 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (-1));
        long long35 = offsetDateTimeField33.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField33.getAsText(readablePartial36, 0, locale38);
        long long42 = offsetDateTimeField33.add(220L, 68);
        int int44 = offsetDateTimeField33.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField33.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType45);
        org.joda.time.DurationField durationField47 = zeroIsMaxDateTimeField46.getLeapDurationField();
        boolean boolean49 = zeroIsMaxDateTimeField46.isLeap((long) (-100));
        boolean boolean51 = zeroIsMaxDateTimeField46.isLeap(5200L);
        int int53 = zeroIsMaxDateTimeField46.getLeapAmount(2440588L);
        long long55 = zeroIsMaxDateTimeField46.roundHalfCeiling((-3599990L));
        org.joda.time.ReadablePartial readablePartial56 = null;
        int int57 = zeroIsMaxDateTimeField46.getMaximumValue(readablePartial56);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(lenientChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 244800220L + "'", long42 == 244800220L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNull(durationField47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 100 + "'", int57 == 100);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) (-32));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440587L + "'", long1 == 2440587L);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        org.joda.time.DurationField durationField8 = offsetDateTimeField7.getLeapDurationField();
        long long11 = offsetDateTimeField7.add(0L, (long) (short) 100);
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField7.getAsText((long) 52, locale13);
        try {
            long long17 = offsetDateTimeField7.set(1560628800000L, "");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for clockhourOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 360000000L + "'", long11 == 360000000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "23" + "'", str14.equals("23"));
    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test359");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
//        org.joda.time.Chronology chronology2 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str4 = dateTimeZone3.getID();
//        java.lang.String str5 = dateTimeZone3.getID();
//        java.util.TimeZone timeZone6 = dateTimeZone3.toTimeZone();
//        java.lang.String str8 = dateTimeZone3.getName((long) 3);
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
//        long long12 = dateTimeZone3.getMillisKeepLocal(dateTimeZone10, (long) (byte) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.weekOfWeekyear();
//        org.joda.time.Chronology chronology15 = iSOChronology13.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str17 = dateTimeZone16.getID();
//        java.lang.String str18 = dateTimeZone16.getID();
//        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance(chronology15, dateTimeZone16);
//        long long21 = dateTimeZone3.getMillisKeepLocal(dateTimeZone16, 10800002L);
//        org.joda.time.Chronology chronology22 = gregorianChronology0.withZone(dateTimeZone3);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-349199900L) + "'", long12 == (-349199900L));
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "UTC" + "'", str17.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "UTC" + "'", str18.equals("UTC"));
//        org.junit.Assert.assertNotNull(zonedChronology19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10800002L + "'", long21 == 10800002L);
//        org.junit.Assert.assertNotNull(chronology22);
//    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 1, periodType1, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DurationField durationField8 = iSOChronology4.seconds();
        org.joda.time.chrono.LenientChronology lenientChronology9 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology4);
        long long13 = lenientChronology9.add(0L, 2440578L, 100);
        java.lang.String str14 = lenientChronology9.toString();
        long long18 = lenientChronology9.add((long) ' ', (-1L), 0);
        long long22 = lenientChronology9.add((-48L), (-4368L), 8);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(lenientChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 244057800L + "'", long13 == 244057800L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str14.equals("LenientChronology[ISOChronology[UTC]]"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 32L + "'", long18 == 32L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-34992L) + "'", long22 == (-34992L));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.Chronology chronology24 = zonedChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology5.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str28 = dateTimeZone27.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology26, dateTimeZone27);
        org.joda.time.chrono.LenientChronology lenientChronology30 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (-1));
        long long35 = offsetDateTimeField33.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField33.getAsText(readablePartial36, 0, locale38);
        long long42 = offsetDateTimeField33.add(220L, 68);
        int int44 = offsetDateTimeField33.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField33.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType45);
        org.joda.time.DurationField durationField47 = zeroIsMaxDateTimeField46.getLeapDurationField();
        boolean boolean49 = zeroIsMaxDateTimeField46.isLeap((long) (-100));
        boolean boolean51 = zeroIsMaxDateTimeField46.isLeap(5200L);
        long long53 = zeroIsMaxDateTimeField46.roundHalfEven(315619199935L);
        long long56 = zeroIsMaxDateTimeField46.set((long) 100, (int) (byte) 10);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(lenientChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 244800220L + "'", long42 == 244800220L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNull(durationField47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 315532800000L + "'", long53 == 315532800000L);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-1893455999900L) + "'", long56 == (-1893455999900L));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Period period5 = period4.normalizedStandard();
        org.joda.time.Period period6 = period4.toPeriod();
        org.joda.time.Period period8 = period6.plusHours(2);
        int int9 = period6.getMonths();
        int int10 = period6.size();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 8 + "'", int10 == 8);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "DayTime", 0, 10);
        int int6 = fixedDateTimeZone4.getStandardOffset((-210865896000000L));
        int int8 = fixedDateTimeZone4.getStandardOffset(156062890818200L);
        long long10 = fixedDateTimeZone4.nextTransition((-99999L));
        long long12 = fixedDateTimeZone4.nextTransition(0L);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "DayTime", 0, 10);
        int int19 = fixedDateTimeZone17.getStandardOffset((-210865896000000L));
        int int21 = fixedDateTimeZone17.getStandardOffset(156062890818200L);
        long long23 = fixedDateTimeZone17.nextTransition((-99999L));
        long long25 = fixedDateTimeZone17.nextTransition(0L);
        boolean boolean26 = fixedDateTimeZone17.isFixed();
        long long28 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone17, (-99999L));
        long long30 = fixedDateTimeZone17.previousTransition((long) (short) 10);
        boolean boolean31 = fixedDateTimeZone17.isFixed();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-99999L) + "'", long10 == (-99999L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-99999L) + "'", long23 == (-99999L));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-99999L) + "'", long28 == (-99999L));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 1, periodType1, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DurationField durationField8 = iSOChronology4.seconds();
        org.joda.time.chrono.LenientChronology lenientChronology9 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology4.halfdayOfDay();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(lenientChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) '4', chronology5);
        org.joda.time.Period period7 = period6.toPeriod();
        int int8 = period6.getMillis();
        org.joda.time.Period period10 = period6.minusYears((int) ' ');
        int[] intArray12 = iSOChronology1.get((org.joda.time.ReadablePeriod) period10, (long) (short) 0);
        org.joda.time.Period period13 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) '4', chronology16);
        org.joda.time.Period period19 = period17.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType20 = period19.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType22 = periodType20.getFieldType((int) (short) 0);
        org.joda.time.Period period24 = period13.withField(durationFieldType22, (int) (short) 0);
        org.joda.time.Period period26 = period13.withWeeks((-1));
        org.joda.time.Period period27 = period10.minus((org.joda.time.ReadablePeriod) period13);
        org.joda.time.Period period29 = period27.minusMinutes(8);
        int[] intArray31 = iSOChronology0.get((org.joda.time.ReadablePeriod) period29, 70L);
        try {
            org.joda.time.Days days32 = period29.toStandardDays();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Days as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(intArray31);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone28 = new org.joda.time.tz.FixedDateTimeZone("", "DayTime", 0, 10);
        int int30 = fixedDateTimeZone28.getStandardOffset((-210865896000000L));
        int int32 = fixedDateTimeZone28.getStandardOffset(156062890818200L);
        org.joda.time.Chronology chronology33 = zonedChronology5.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone28);
        java.lang.String str35 = fixedDateTimeZone28.getShortName(520L);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 10 + "'", int32 == 10);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "+00:00" + "'", str35.equals("+00:00"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((-2L));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.joda.time.Period period1 = org.joda.time.Period.millis(0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-1));
        long long9 = offsetDateTimeField7.roundHalfFloor(2704L);
        long long11 = offsetDateTimeField7.roundFloor((long) 2);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) (byte) -1, ' ', (int) (byte) 100, (int) ' ', 0, false, (-32));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder0.addRecurringSavings("PT0.052S", 70, 4, 0, '4', 1, 52, (-1), false, (-1));
        java.io.DataOutput dataOutput21 = null;
        try {
            dateTimeZoneBuilder19.writeTo("100", dataOutput21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder19);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationField durationField6 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        long long10 = durationField7.subtract((long) (byte) 10, 0L);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period15 = period14.toPeriod();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) '4', chronology18);
        org.joda.time.Period period21 = period19.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType24 = periodType22.getFieldType((int) (short) 0);
        boolean boolean25 = period14.isSupported(durationFieldType24);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType24, (long) '4');
        org.joda.time.field.ScaledDurationField scaledDurationField29 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType24, (int) (short) 100);
        long long31 = scaledDurationField29.getValueAsLong((long) 68);
        long long33 = scaledDurationField29.getMillis(52);
        int int35 = scaledDurationField29.getValue((long) (short) 0);
        long long38 = scaledDurationField29.add((long) 4, 100);
        try {
            long long41 = scaledDurationField29.add((-61851686400000L), 1560628908182L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 156062890818200 * 86400000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 449280000000L + "'", long33 == 449280000000L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 864000000004L + "'", long38 == 864000000004L);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long4 = cachedDateTimeZone2.nextTransition((long) (-32));
        int int6 = cachedDateTimeZone2.getStandardOffset((long) 68);
        long long8 = cachedDateTimeZone2.previousTransition((long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        int int10 = cachedDateTimeZone2.getOffset(readableInstant9);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-32L) + "'", long4 == (-32L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 349200000 + "'", int6 == 349200000);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 349200000 + "'", int10 == 349200000);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("org.joda.time.IllegalFieldValueException: Value 0 for org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0] must be in the range [100,10.0]", 52, 4, (-3491999));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for org.joda.time.IllegalFieldValueException: Value 0 for org.joda.time.IllegalFieldValueException: Value 1 for  must be in the range [100,10.0] must be in the range [100,10.0] must be in the range [4,-3491999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = zonedChronology3.getZone();
        java.lang.String str5 = zonedChronology3.toString();
        java.lang.Object obj6 = null;
        boolean boolean7 = zonedChronology3.equals(obj6);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.clockhourOfDay();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DurationField durationField13 = iSOChronology10.millis();
        org.joda.time.DurationField durationField14 = iSOChronology10.weeks();
        org.joda.time.DurationField durationField15 = iSOChronology10.days();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology10.dayOfMonth();
        boolean boolean17 = zonedChronology3.equals((java.lang.Object) iSOChronology10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(1);
        org.joda.time.Period period2 = period1.normalizedStandard();
        org.joda.time.MutablePeriod mutablePeriod3 = period2.toMutablePeriod();
        org.joda.time.Duration duration4 = period2.toStandardDuration();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(mutablePeriod3);
        org.junit.Assert.assertNotNull(duration4);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(100);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 1, periodType1, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DurationField durationField8 = iSOChronology4.seconds();
        org.joda.time.chrono.LenientChronology lenientChronology9 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology4);
        long long13 = lenientChronology9.add(0L, 2440578L, 100);
        java.lang.String str14 = lenientChronology9.toString();
        org.joda.time.DurationField durationField15 = lenientChronology9.weeks();
        org.joda.time.Chronology chronology16 = lenientChronology9.withUTC();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(lenientChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 244057800L + "'", long13 == 244057800L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str14.equals("LenientChronology[ISOChronology[UTC]]"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 1, periodType1, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DurationField durationField8 = iSOChronology4.halfdays();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology4.clockhourOfHalfday();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str12 = dateTimeZone11.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology10, dateTimeZone11);
        org.joda.time.chrono.LenientChronology lenientChronology14 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology10.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (-1));
        long long19 = offsetDateTimeField17.roundHalfFloor(2704L);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField17.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, dateTimeFieldType20, (int) (byte) 100);
        org.joda.time.ReadableInterval readableInterval24 = null;
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval24);
        org.joda.time.Period period26 = new org.joda.time.Period((long) '4', chronology25);
        org.joda.time.Period period28 = period26.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType29 = period28.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType31 = periodType29.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField33 = new org.joda.time.field.PreciseDurationField(durationFieldType31, (long) (byte) 100);
        java.lang.String str34 = preciseDurationField33.getName();
        long long35 = preciseDurationField33.getUnitMillis();
        int int38 = preciseDurationField33.getDifference((-349199900L), (long) 'a');
        org.joda.time.DurationFieldType durationFieldType39 = preciseDurationField33.getType();
        long long42 = preciseDurationField33.getValueAsLong(244057800L, (long) 2);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, (org.joda.time.DurationField) preciseDurationField33);
        java.util.Locale locale44 = null;
        try {
            int int45 = unsupportedDateTimeField43.getMaximumShortTextLength(locale44);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UTC" + "'", str12.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(lenientChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "years" + "'", str34.equals("years"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 100L + "'", long35 == 100L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-3491999) + "'", int38 == (-3491999));
        org.junit.Assert.assertNotNull(durationFieldType39);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 2440578L + "'", long42 == 2440578L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period6 = period4.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType7 = period6.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField11 = new org.joda.time.field.PreciseDurationField(durationFieldType9, (long) (byte) 100);
        java.lang.String str12 = preciseDurationField11.getName();
        long long13 = preciseDurationField11.getUnitMillis();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType15 = periodType14.withWeeksRemoved();
        org.joda.time.PeriodType periodType16 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
        org.joda.time.PeriodType periodType17 = periodType16.withSecondsRemoved();
        boolean boolean18 = preciseDurationField11.equals((java.lang.Object) periodType16);
        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str23 = dateTimeZone22.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology24 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology21, dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone25 = zonedChronology24.getZone();
        java.lang.String str26 = zonedChronology24.toString();
        org.joda.time.Period period27 = new org.joda.time.Period((long) 3, periodType20, (org.joda.time.Chronology) zonedChronology24);
        org.joda.time.ReadableInterval readableInterval29 = null;
        org.joda.time.Chronology chronology30 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval29);
        org.joda.time.Period period31 = new org.joda.time.Period((long) '4', chronology30);
        org.joda.time.Period period33 = period31.plusMillis(1);
        java.lang.String str34 = period31.toString();
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology35.clockhourOfDay();
        boolean boolean38 = iSOChronology35.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period39 = new org.joda.time.Period((java.lang.Object) period31, (org.joda.time.Chronology) iSOChronology35);
        int[] intArray41 = zonedChronology24.get((org.joda.time.ReadablePeriod) period39, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology42 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology24);
        long long47 = zonedChronology24.getDateTimeMillis(100, (int) (short) 10, 10, (int) 'a');
        org.joda.time.Period period48 = new org.joda.time.Period((-34919990L), periodType16, (org.joda.time.Chronology) zonedChronology24);
        org.joda.time.DateTimeField dateTimeField49 = zonedChronology24.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "years" + "'", str12.equals("years"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "UTC" + "'", str23.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str26.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "PT0.052S" + "'", str34.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(lenientChronology42);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-58987094399903L) + "'", long47 == (-58987094399903L));
        org.junit.Assert.assertNotNull(dateTimeField49);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) ' ', (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 1, periodType1, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DurationField durationField8 = iSOChronology4.halfdays();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology4.clockhourOfHalfday();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str12 = dateTimeZone11.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology10, dateTimeZone11);
        org.joda.time.chrono.LenientChronology lenientChronology14 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology10.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (-1));
        long long19 = offsetDateTimeField17.roundHalfFloor(2704L);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField17.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, dateTimeFieldType20, (int) (byte) 100);
        org.joda.time.ReadableInterval readableInterval24 = null;
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval24);
        org.joda.time.Period period26 = new org.joda.time.Period((long) '4', chronology25);
        org.joda.time.Period period28 = period26.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType29 = period28.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType31 = periodType29.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField33 = new org.joda.time.field.PreciseDurationField(durationFieldType31, (long) (byte) 100);
        java.lang.String str34 = preciseDurationField33.getName();
        long long35 = preciseDurationField33.getUnitMillis();
        int int38 = preciseDurationField33.getDifference((-349199900L), (long) 'a');
        org.joda.time.DurationFieldType durationFieldType39 = preciseDurationField33.getType();
        long long42 = preciseDurationField33.getValueAsLong(244057800L, (long) 2);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, (org.joda.time.DurationField) preciseDurationField33);
        java.util.Locale locale45 = null;
        try {
            java.lang.String str46 = unsupportedDateTimeField43.getAsText(3, locale45);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UTC" + "'", str12.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(lenientChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "years" + "'", str34.equals("years"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 100L + "'", long35 == 100L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-3491999) + "'", int38 == (-3491999));
        org.junit.Assert.assertNotNull(durationFieldType39);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 2440578L + "'", long42 == 2440578L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', chronology2);
        org.joda.time.Period period4 = period3.toPeriod();
        int int5 = period3.getMillis();
        org.joda.time.Period period7 = period3.minusYears((int) ' ');
        org.joda.time.Period period9 = period7.plusDays((int) 'a');
        org.joda.time.Period period10 = period7.negated();
        org.joda.time.Period period12 = period10.withSeconds(10);
        org.joda.time.Period period13 = new org.joda.time.Period();
        org.joda.time.ReadableInterval readableInterval15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) '4', chronology16);
        org.joda.time.Period period19 = period17.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType20 = period19.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType22 = periodType20.getFieldType((int) (short) 0);
        org.joda.time.Period period24 = period13.withField(durationFieldType22, (int) (short) 0);
        org.joda.time.Period period26 = period10.withField(durationFieldType22, (int) (byte) -1);
        org.joda.time.ReadableInterval readableInterval28 = null;
        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval28);
        org.joda.time.Period period30 = new org.joda.time.Period((long) '4', chronology29);
        org.joda.time.Period period32 = period30.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType33 = period32.getPeriodType();
        org.joda.time.ReadableInterval readableInterval35 = null;
        org.joda.time.Chronology chronology36 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval35);
        org.joda.time.Period period37 = new org.joda.time.Period((long) '4', chronology36);
        org.joda.time.Period period39 = period37.withYears((int) (short) 10);
        org.joda.time.PeriodType periodType40 = period39.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType42 = periodType40.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField44 = new org.joda.time.field.PreciseDurationField(durationFieldType42, (long) (byte) 100);
        int int45 = periodType33.indexOf(durationFieldType42);
        int int46 = period10.indexOf(durationFieldType42);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(periodType40);
        org.junit.Assert.assertNotNull(durationFieldType42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.Chronology chronology24 = zonedChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology5.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str28 = dateTimeZone27.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology26, dateTimeZone27);
        org.joda.time.chrono.LenientChronology lenientChronology30 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (-1));
        long long35 = offsetDateTimeField33.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField33.getAsText(readablePartial36, 0, locale38);
        long long42 = offsetDateTimeField33.add(220L, 68);
        int int44 = offsetDateTimeField33.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField33.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType45);
        org.joda.time.DurationField durationField47 = zeroIsMaxDateTimeField46.getLeapDurationField();
        boolean boolean49 = zeroIsMaxDateTimeField46.isLeap((long) (-100));
        boolean boolean51 = zeroIsMaxDateTimeField46.isLeap(5200L);
        int int52 = zeroIsMaxDateTimeField46.getMaximumValue();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(lenientChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 244800220L + "'", long42 == 244800220L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNull(durationField47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 100 + "'", int52 == 100);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 100, periodType4, chronology6);
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) 100);
        int int9 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology10 = gregorianChronology0.withUTC();
        org.joda.time.Chronology chronology11 = gregorianChronology0.withUTC();
        int int12 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology13 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone1);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        java.lang.String str5 = lenientChronology4.toString();
        org.joda.time.DateTimeField dateTimeField6 = lenientChronology4.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str9 = dateTimeZone8.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, dateTimeZone8);
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology7.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (-1));
        long long16 = offsetDateTimeField14.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField14.getAsText(readablePartial17, 0, locale19);
        long long23 = offsetDateTimeField14.add(220L, 68);
        int int25 = offsetDateTimeField14.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType26, 70);
        long long30 = dividedDateTimeField28.roundFloor((long) 2);
        int int32 = dividedDateTimeField28.get((-52L));
        long long34 = dividedDateTimeField28.roundFloor(32L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str5.equals("LenientChronology[ISOChronology[UTC]]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 244800220L + "'", long23 == 244800220L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology5.getZone();
        java.lang.String str7 = zonedChronology5.toString();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 3, periodType1, (org.joda.time.Chronology) zonedChronology5);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) '4', chronology11);
        org.joda.time.Period period14 = period12.plusMillis(1);
        java.lang.String str15 = period12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) (-1.0f));
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period12, (org.joda.time.Chronology) iSOChronology16);
        int[] intArray22 = zonedChronology5.get((org.joda.time.ReadablePeriod) period20, (-1L));
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology5);
        org.joda.time.Chronology chronology24 = zonedChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology5.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str28 = dateTimeZone27.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology26, dateTimeZone27);
        org.joda.time.chrono.LenientChronology lenientChronology30 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (-1));
        long long35 = offsetDateTimeField33.roundHalfFloor(2704L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField33.getAsText(readablePartial36, 0, locale38);
        long long42 = offsetDateTimeField33.add(220L, 68);
        int int44 = offsetDateTimeField33.getLeapAmount((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField33.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType45);
        org.joda.time.ReadablePartial readablePartial47 = null;
        int int48 = zeroIsMaxDateTimeField46.getMinimumValue(readablePartial47);
        long long51 = zeroIsMaxDateTimeField46.add(10L, 520L);
        long long53 = zeroIsMaxDateTimeField46.roundHalfFloor(14159997L);
        long long56 = zeroIsMaxDateTimeField46.add(10000L, (-131));
        org.joda.time.ReadablePartial readablePartial57 = null;
        int int58 = zeroIsMaxDateTimeField46.getMinimumValue(readablePartial57);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0.052S" + "'", str15.equals("PT0.052S"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(lenientChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 244800220L + "'", long42 == 244800220L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 16409692800010L + "'", long51 == 16409692800010L);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-4133980790000L) + "'", long56 == (-4133980790000L));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
    }
}

