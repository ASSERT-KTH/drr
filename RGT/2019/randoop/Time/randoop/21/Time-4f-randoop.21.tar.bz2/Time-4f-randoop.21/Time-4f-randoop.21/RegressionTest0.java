import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (byte) 10, (java.lang.Number) 0.0d, (java.lang.Number) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) (short) -1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField3 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, durationField1, dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (short) -1);
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, dateTimeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, (int) '#', (int) (byte) 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        try {
            org.joda.time.DateTime dateTime5 = dateTime2.withYearOfEra((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) 'a', (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 132 + "'", int2 == 132);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField2 = copticChronology1.weeks();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField4 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, durationField2, dateTimeFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (byte) 10, 0, (int) (byte) -1, 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.junit.Assert.assertNotNull(dateTime0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (short) -1);
        org.joda.time.DateTime dateTime5 = instant1.toDateTime(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime6 = instant1.toMutableDateTime();
        try {
            java.lang.String str8 = mutableDateTime6.toString("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.weeks();
        long long4 = durationField1.subtract(0L, (-1));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 604800000L + "'", long4 == 604800000L);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneOffset("772", "72", false, (-1), 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        try {
            org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((java.lang.Object) "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneOffset("hi!", "658", false, (int) (short) -1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType4, 100, (int) (short) 1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(1, 0, (int) (short) -1, 4, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property3.getAsText(locale4);
        org.joda.time.Instant instant7 = new org.joda.time.Instant((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        int int10 = dateTimeZone8.getOffsetFromLocal((long) (short) -1);
        org.joda.time.DateTime dateTime11 = instant7.toDateTime(dateTimeZone8);
        long long12 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
        int int13 = dateTime11.getMonthOfYear();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1" + "'", str5.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-31L) + "'", long12 == (-31L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTimeZone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField2 = copticChronology1.weeks();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField4 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, durationField2, dateTimeFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        try {
            org.joda.time.DateTime dateTime9 = dateTime6.withHourOfDay((int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        int int1 = copticChronology0.getMinimumDaysInFirstWeek();
        try {
            long long6 = copticChronology0.getDateTimeMillis((int) (byte) 0, 4, 132, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 132 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((int) (byte) 10, 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology7.getZone();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) 'a', (int) (byte) 100, 0, (int) (byte) 10, (int) (byte) 10, 4, 0, (org.joda.time.Chronology) gJChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) ' ');
        try {
            long long4 = dateTimeFormatter2.parseMillis("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.weeks();
        try {
            long long6 = copticChronology0.getDateTimeMillis((int) (short) 10, (int) (byte) 0, 132, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount(604800000L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 9 + "'", int1 == 9);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("772");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '772' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        int int5 = delegatedDateTimeField3.getMinimumValue((long) (byte) 0);
        int int6 = delegatedDateTimeField3.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField8 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Chronology must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay(4);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendSignedDecimal(dateTimeFieldType5, 12, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        try {
            org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1, (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -28800000");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (short) 10, (int) 'a', (int) (short) -1, (int) (short) 0, 1969, 9, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((-28800000), 132, (int) (byte) 100, (int) (byte) 100, (int) '#', 132);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology1.getZone();
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((java.lang.Object) (-1), (org.joda.time.Chronology) gJChronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 52);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210862267200000L) + "'", long1 == (-210862267200000L));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(9, (int) ' ', 0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.field.FieldUtils.verifyValueBounds("", 0, 0, 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
        int[] intArray15 = new int[] { 69, 'a', 2000, 132 };
        java.util.Locale locale17 = null;
        try {
            int[] intArray18 = delegatedDateTimeField4.set((org.joda.time.ReadablePartial) localDate9, (int) (byte) 10, intArray15, "", locale17);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for weekyearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime6.plusMillis((-1));
        int int10 = dateTime9.getYearOfCentury();
        int int11 = dateTime9.getSecondOfMinute();
        try {
            org.joda.time.DateTime dateTime13 = dateTime9.withMillisOfSecond(2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 69 + "'", int10 == 69);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        int int5 = delegatedDateTimeField3.getMinimumValue((long) (byte) 0);
        boolean boolean7 = delegatedDateTimeField3.isLeap((long) 0);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField9 = copticChronology8.weeks();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField9, dateTimeFieldType10, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.secondOfDay();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology5);
        org.joda.time.DateTime.Property property7 = dateTime6.millisOfSecond();
        org.joda.time.DateTime dateTime8 = dateTime6.withEarlierOffsetAtOverlap();
        org.joda.time.ReadablePartial readablePartial9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.withFields(readablePartial9);
        boolean boolean11 = copticChronology0.equals((java.lang.Object) dateTime6);
        org.joda.time.DurationField durationField12 = copticChronology0.years();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfMinute((int) 'a');
        boolean boolean5 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendLiteral("000000");
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder7.appendTimeZoneOffset("", "658", true, 2000, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfMinute((int) 'a');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYear((int) (short) -1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfMinute((int) 'a');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMillisOfDay((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(69, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3588 + "'", int2 == 3588);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
        org.joda.time.DateTime dateTime6 = localDate3.toDateTimeAtCurrentTime(dateTimeZone5);
        int int7 = localDate3.getCenturyOfEra();
        org.joda.time.LocalDate localDate9 = localDate3.withEra(0);
        try {
            org.joda.time.LocalDate localDate11 = localDate3.withEra(10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
        org.joda.time.DateTime dateTime6 = localDate3.toDateTimeAtCurrentTime(dateTimeZone5);
        int int7 = localDate3.getCenturyOfEra();
        org.joda.time.LocalDate localDate9 = localDate3.withEra(0);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        int int13 = dateTimeZone11.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) 1970, dateTimeZone11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withPivotYear((java.lang.Integer) 0);
        java.lang.String str18 = localDate14.toString(dateTimeFormatter17);
        org.joda.time.ReadableInterval readableInterval19 = null;
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval19);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(chronology20);
        org.joda.time.DateTime.Property property22 = dateTime21.millisOfSecond();
        org.joda.time.DateTime dateTime23 = dateTime21.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime24 = localDate14.toDateTime((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.LocalDate.Property property25 = localDate14.dayOfMonth();
        int int26 = localDate9.compareTo((org.joda.time.ReadablePartial) localDate14);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-28800000) + "'", int13 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1969" + "'", str18.equals("1969"));
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(chronology3);
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfSecond();
        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
        org.joda.time.DateTime dateTime8 = dateTime4.withCenturyOfEra(0);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("hi!", 100, 100, 12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hi! must be in the range [100,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime5 = dateTime2.minusDays(0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(132);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-132) + "'", int1 == (-132));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 1970, dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withPivotYear((java.lang.Integer) 0);
        java.lang.String str8 = localDate4.toString(dateTimeFormatter7);
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(chronology10);
        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
        org.joda.time.DateTime dateTime13 = dateTime11.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = localDate4.toDateTime((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.LocalDate.Property property15 = localDate4.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
        try {
            int int17 = localDate4.get(dateTimeFieldType16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (byte) 0, 0, (int) (byte) 1, 0, 1970, 4, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfMinute((int) 'a');
        org.joda.time.format.DateTimeParser dateTimeParser5 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendOptional(dateTimeParser5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.util.Calendar calendar0 = null;
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.fromCalendarFields(calendar0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The calendar must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (short) -1);
        org.joda.time.DateTime dateTime5 = instant1.toDateTime(dateTimeZone2);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTime dateTime8 = dateTime5.withMillisOfSecond(132);
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = copticChronology9.hourOfHalfday();
        org.joda.time.DurationField durationField11 = copticChronology9.millis();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime((org.joda.time.Chronology) copticChronology9);
        try {
            org.joda.time.DateTime dateTime14 = dateTime12.withDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime4 = dateTime2.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime6 = dateTime2.minusMillis(1969);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(604800000L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        java.util.Locale locale5 = null;
        java.lang.String str6 = localDate3.toString("000000Z", locale5);
        org.joda.time.LocalTime localTime7 = null;
        try {
            org.joda.time.LocalDateTime localDateTime8 = localDate3.toLocalDateTime(localTime7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The time must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "000000" + "'", str6.equals("000000"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.util.Date date0 = null;
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.fromDateFields(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The date must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getMinimumValue((long) (byte) 0);
        boolean boolean8 = delegatedDateTimeField4.isLeap((long) 0);
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField4, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField13 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, dateTimeFieldType11, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(1, 1969, 1969, (int) (byte) 10, (int) '4', (int) (short) 10, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.field.FieldUtils.verifyValueBounds("658", 86, 0, 1970);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField9 = gJChronology8.weekyears();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology6, dateTimeField10, (int) (byte) -1);
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(1, (int) (short) 1, (-132), (int) (byte) -1, 10, chronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) (short) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (short) 0, (int) 'a', 19, (-28800000), 2000, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (short) -1);
        org.joda.time.DateTime dateTime5 = instant1.toDateTime(dateTimeZone2);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTime dateTime8 = dateTime5.withMillisOfSecond(132);
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(chronology10);
        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
        org.joda.time.DateTime.Property property13 = dateTime11.millisOfSecond();
        org.joda.time.DateTime dateTime15 = dateTime11.withCenturyOfEra(0);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime17 = dateTime15.withZone(dateTimeZone16);
        boolean boolean18 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfMinute((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMillisOfDay(36);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendFractionOfHour((int) (short) -1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
        org.joda.time.DateTime dateTime6 = localDate3.toDateTimeAtCurrentTime(dateTimeZone5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            int int8 = localDate3.get(dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.hourOfHalfday();
        org.joda.time.DurationField durationField2 = copticChronology0.millis();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone3);
        try {
            long long13 = zonedChronology5.getDateTimeMillis((int) (byte) 0, (int) (short) 1, 0, 19, 132, 2000, 36);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 132 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 0.0f, (java.lang.Number) 100L, (java.lang.Number) 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(315705600000L, (long) 7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 315705600007L + "'", long2 == 315705600007L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYearOfEra(12, 52);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendHourOfDay((-132));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfMinute((int) 'a');
        boolean boolean5 = dateTimeFormatterBuilder0.canBuildPrinter();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendTimeZoneOffset("", "hi!", true, (int) '4', 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 604800000L + "'", long0 == 604800000L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfMinute((int) 'a');
        boolean boolean5 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendLiteral("000000");
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendCenturyOfEra(0, (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 132, (long) (-28800000));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3801600000L) + "'", long2 == (-3801600000L));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray1 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType0 };
        int[] intArray2 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField5 = gJChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.centuryOfEra();
        org.joda.time.DurationField durationField7 = gJChronology4.days();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(0L, (org.joda.time.Chronology) gJChronology4);
        try {
            org.joda.time.Partial partial9 = new org.joda.time.Partial(dateTimeFieldTypeArray1, intArray2, (org.joda.time.Chronology) gJChronology4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray1);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology7.getZone();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) 'a', (int) 'a', 4, (int) '#', 12, 0, 10, (org.joda.time.Chronology) gJChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (byte) 10, (int) ' ', (int) ' ', 1970, 1970, (-28800000), dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfMinute((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMillisOfDay(36);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendTimeZoneOffset("1", true, 0, (-132));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("hi!");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hi!/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneShortName();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendWeekOfWeekyear((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField2 = copticChronology1.weeks();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField3 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(12, (int) (short) 100, (int) (short) -1, 0, (-132));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -132 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        java.util.Locale locale5 = null;
        java.lang.String str6 = localDate3.toString("000000Z", locale5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = localDate3.indexOf(dateTimeFieldType7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        boolean boolean10 = localDate3.isSupported(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "000000" + "'", str6.equals("000000"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime5 = property3.addWrapFieldToCopy(0);
        java.util.Locale locale7 = null;
        org.joda.time.DateTime dateTime8 = property3.setCopy("772", locale7);
        int int9 = dateTime8.getDayOfWeek();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.LocalDate localDate0 = org.joda.time.LocalDate.now();
        org.joda.time.LocalDate.Property property1 = localDate0.dayOfWeek();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.LocalDate localDate4 = localDate0.withField(dateTimeFieldType2, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate0);
        org.junit.Assert.assertNotNull(property1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        int int3 = cachedDateTimeZone1.getStandardOffset(0L);
        try {
            org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone1, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 9");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        long long4 = dateTimeZone1.adjustOffset(10L, true);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) 1969, dateTimeZone1);
        org.joda.time.DateMidnight dateMidnight6 = localDate5.toDateMidnight();
        org.joda.time.LocalDate.Property property7 = localDate5.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = property7.getField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) (byte) 100, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(0, (-132), 52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -132 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (short) -1);
        org.joda.time.DateTime dateTime5 = instant1.toDateTime(dateTimeZone2);
        boolean boolean7 = dateTime5.equals((java.lang.Object) 0.0d);
        org.joda.time.DateTime dateTime9 = dateTime5.withYear((int) (short) -1);
        try {
            org.joda.time.DateTime dateTime11 = dateTime9.withHourOfDay(365);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 0, 100, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate4 = org.joda.time.LocalDate.now(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = gJChronology5.getZone();
        org.joda.time.DateTime dateTime7 = localDate4.toDateTimeAtCurrentTime(dateTimeZone6);
        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate4);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-W02-3" + "'", str8.equals("1970-W02-3"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate5 = org.joda.time.LocalDate.now(dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology6.getZone();
        org.joda.time.DateTime dateTime8 = localDate5.toDateTimeAtCurrentTime(dateTimeZone7);
        int int9 = localDate5.getCenturyOfEra();
        org.joda.time.LocalDate localDate11 = localDate5.withEra(0);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localDate5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 19 + "'", int9 == 19);
        org.junit.Assert.assertNotNull(localDate11);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime5 = property3.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime7 = property3.addToCopy(132);
        org.joda.time.DateTime dateTime9 = property3.addWrapFieldToCopy((-1));
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        long long2 = org.joda.time.field.FieldUtils.safeDivide((long) (byte) -1, (long) 3588);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        int int5 = delegatedDateTimeField3.getMinimumValue((long) (byte) 0);
        boolean boolean6 = delegatedDateTimeField3.isSupported();
        java.lang.String str8 = delegatedDateTimeField3.getAsShortText((long) (-1));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "87" + "'", str8.equals("87"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfMinute();
        java.lang.String str3 = gJChronology0.toString();
        java.lang.String str4 = gJChronology0.toString();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str4.equals("GJChronology[America/Los_Angeles]"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        int int5 = delegatedDateTimeField3.getMinimumValue((long) (byte) 0);
        long long8 = delegatedDateTimeField3.getDifferenceAsLong(0L, (long) 4);
        int int10 = delegatedDateTimeField3.get(1560639843040L);
        long long13 = delegatedDateTimeField3.getDifferenceAsLong((long) '4', (long) 36);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 36 + "'", int10 == 36);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime6.plusMillis((-1));
        try {
            org.joda.time.DateTime dateTime11 = dateTime6.withEra(9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 9 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        int int5 = delegatedDateTimeField3.getMinimumValue((long) (byte) 0);
        int int6 = delegatedDateTimeField3.getMinimumValue();
        int int7 = delegatedDateTimeField3.getMinimumValue();
        long long9 = delegatedDateTimeField3.roundHalfCeiling(1560639843040L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1568012400000L + "'", long9 == 1568012400000L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 1970, dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withPivotYear((java.lang.Integer) 0);
        java.lang.String str8 = localDate4.toString(dateTimeFormatter7);
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(chronology10);
        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
        org.joda.time.DateTime dateTime13 = dateTime11.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = localDate4.toDateTime((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.LocalDate localDate16 = localDate4.plusMonths((-132));
        org.joda.time.LocalDate.Property property17 = localDate4.era();
        java.lang.String str18 = property17.getName();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "era" + "'", str18.equals("era"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.secondOfDay();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology5);
        org.joda.time.DateTime.Property property7 = dateTime6.millisOfSecond();
        org.joda.time.DateTime dateTime8 = dateTime6.withEarlierOffsetAtOverlap();
        org.joda.time.ReadablePartial readablePartial9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.withFields(readablePartial9);
        boolean boolean11 = copticChronology0.equals((java.lang.Object) dateTime6);
        org.joda.time.DateTime dateTime13 = dateTime6.withYear((int) (byte) 100);
        org.joda.time.TimeOfDay timeOfDay14 = dateTime13.toTimeOfDay();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(timeOfDay14);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, number1, (java.lang.Number) (short) 1, (java.lang.Number) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfMinute((int) 'a');
        boolean boolean5 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendLiteral("000000");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendMonthOfYear(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendText(dateTimeFieldType12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime6.plusMillis((-1));
        org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfSecond(100);
        int int12 = dateTime11.getDayOfYear();
        org.joda.time.Chronology chronology13 = dateTime11.getChronology();
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate(chronology13);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 7 + "'", int12 == 7);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 1970, dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withPivotYear((java.lang.Integer) 0);
        java.lang.String str8 = localDate4.toString(dateTimeFormatter7);
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(chronology10);
        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
        org.joda.time.DateTime dateTime13 = dateTime11.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = localDate4.toDateTime((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.LocalDate.Property property15 = localDate4.dayOfMonth();
        org.joda.time.LocalDate localDate17 = localDate4.withCenturyOfEra(2000);
        int int18 = localDate4.getDayOfWeek();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 1, (int) (byte) -1, (int) (short) -1, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime6.plusMillis((-1));
        try {
            org.joda.time.DateTime dateTime11 = dateTime9.withYearOfEra((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        java.lang.String str4 = dateTimeZone0.getID();
        java.util.TimeZone timeZone5 = dateTimeZone0.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "America/Los_Angeles" + "'", str4.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.centuryOfEra();
        org.joda.time.DurationField durationField3 = gJChronology0.days();
        long long6 = durationField3.subtract((long) 1969, 0L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1969L + "'", long6 == 1969L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime5 = property3.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime7 = property3.addToCopy(132);
        int int8 = property3.get();
        org.joda.time.Instant instant10 = new org.joda.time.Instant((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        int int13 = dateTimeZone11.getOffsetFromLocal((long) (short) -1);
        org.joda.time.DateTime dateTime14 = instant10.toDateTime(dateTimeZone11);
        int int15 = dateTime14.getWeekyear();
        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) int8, (java.lang.Object) dateTime14);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-28800000) + "'", int13 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1970 + "'", int15 == 1970);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("000000", (-1), (int) 'a', (-99136));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for 000000 must be in the range [97,-99136]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.centuryOfEra();
        org.joda.time.DurationField durationField3 = gJChronology0.days();
        try {
            long long11 = gJChronology0.getDateTimeMillis(3, 0, (int) (short) 100, 4, 0, 57600, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test150");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField1 = copticChronology0.weeks();
//        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getShortName((long) 1969, locale4);
//        try {
//            org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone2, 132);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 132");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 315705600007L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("100", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"100/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTime dateTime8 = property7.withMinimumValue();
        try {
            org.joda.time.DateTime dateTime10 = property7.setCopy(57600);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(0);
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(chronology4);
        org.joda.time.DateTime.Property property6 = dateTime5.millisOfSecond();
        org.joda.time.DateTime.Property property7 = dateTime5.millisOfSecond();
        org.joda.time.DateTime dateTime9 = dateTime5.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property10 = dateTime9.weekOfWeekyear();
        java.lang.String str11 = property10.getAsShortText();
        int int12 = property10.getMinimumValueOverall();
        int int13 = property10.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property10.getFieldType();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder2.appendFixedSignedDecimal(dateTimeFieldType14, (-99136));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal number of digits: -99136");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2" + "'", str11.equals("2"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.Instant instant2 = new org.joda.time.Instant((long) ' ');
        org.joda.time.MutableDateTime mutableDateTime3 = instant2.toMutableDateTimeISO();
        int int6 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "", 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        long long4 = durationField1.subtract((long) (byte) 100, 19);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-599356799900L) + "'", long4 == (-599356799900L));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        java.util.TimeZone timeZone3 = dateTimeZone1.toTimeZone();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant4, 3);
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 19);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        java.lang.String str2 = dateTimeFormatter0.print((long) ' ');
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969-12-31T16" + "'", str2.equals("1969-12-31T16"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
        long long8 = delegatedDateTimeField3.roundFloor((long) 52);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9910800000L) + "'", long8 == (-9910800000L));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        boolean boolean4 = delegatedDateTimeField3.isSupported();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
        org.joda.time.DurationField durationField14 = null;
        org.joda.time.ReadableInterval readableInterval15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
        java.lang.String str23 = property22.getAsShortText();
        int int24 = property22.getMinimumValueOverall();
        int int25 = property22.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
        try {
            long long31 = dividedDateTimeField28.set((long) (short) 100, 9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 9 for weekOfWeekyear must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2" + "'", str23.equals("2"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime6.plusMillis((-1));
        int int10 = dateTime6.getMillisOfSecond();
        org.joda.time.DateTime dateTime12 = dateTime6.withWeekOfWeekyear(4);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getMinimumValue((long) (byte) 0);
        boolean boolean8 = delegatedDateTimeField4.isLeap((long) 0);
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField4, 1969);
        boolean boolean12 = gJChronology0.equals((java.lang.Object) 32L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.centuryOfEra();
        org.joda.time.DurationField durationField3 = gJChronology0.days();
        long long6 = durationField3.subtract((-599356799900L), 36);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-602467199900L) + "'", long6 == (-602467199900L));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate9, locale10);
        boolean boolean13 = delegatedDateTimeField4.isLeap((long) (short) 1);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "69" + "'", str11.equals("69"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        long long4 = dateTimeZone1.adjustOffset(10L, true);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) 1969, dateTimeZone1);
        org.joda.time.DateMidnight dateMidnight6 = localDate5.toDateMidnight();
        org.joda.time.LocalDate.Property property7 = localDate5.monthOfYear();
        org.joda.time.LocalDate localDate8 = property7.roundHalfFloorCopy();
        org.joda.time.LocalDate localDate10 = localDate8.plusWeeks(7);
        try {
            org.joda.time.LocalDate localDate12 = localDate8.withDayOfMonth(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        boolean boolean4 = delegatedDateTimeField3.isSupported();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
        long long15 = delegatedDateTimeField3.roundHalfEven((long) 100);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-9910800000L) + "'", long15 == (-9910800000L));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 100, (org.joda.time.Chronology) gJChronology1);
        try {
            long long11 = gJChronology1.getDateTimeMillis((-132), 0, 36, 70, (int) 'a', 19, 86);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 70 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            long long6 = gregorianChronology0.getDateTimeMillis((long) ' ', (-28800000), 132, 86, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Instant instant2 = new org.joda.time.Instant((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        int int5 = dateTimeZone3.getOffsetFromLocal((long) (short) -1);
        org.joda.time.DateTime dateTime6 = instant2.toDateTime(dateTimeZone3);
        org.joda.time.MutableDateTime mutableDateTime7 = instant2.toMutableDateTime();
        org.joda.time.Instant instant9 = instant2.withMillis((long) 132);
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) instant2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (short) -1);
        org.joda.time.DateTime dateTime5 = instant1.toDateTime(dateTimeZone2);
        org.joda.time.Instant instant7 = instant1.withMillis((long) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(instant7);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        boolean boolean4 = delegatedDateTimeField3.isSupported();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
        org.joda.time.DurationField durationField14 = null;
        org.joda.time.ReadableInterval readableInterval15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
        java.lang.String str23 = property22.getAsShortText();
        int int24 = property22.getMinimumValueOverall();
        int int25 = property22.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
        int int29 = dividedDateTimeField28.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.getDefault();
        int int33 = dateTimeZone31.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate((long) 1970, dateTimeZone31);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter35.withPivotYear((java.lang.Integer) 0);
        java.lang.String str38 = localDate34.toString(dateTimeFormatter37);
        org.joda.time.ReadableInterval readableInterval39 = null;
        org.joda.time.Chronology chronology40 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval39);
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime(chronology40);
        org.joda.time.DateTime.Property property42 = dateTime41.millisOfSecond();
        org.joda.time.DateTime dateTime43 = dateTime41.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime44 = localDate34.toDateTime((org.joda.time.ReadableInstant) dateTime41);
        org.joda.time.LocalDate localDate46 = localDate34.plusMonths((-132));
        org.joda.time.LocalDate.Property property47 = localDate34.era();
        org.joda.time.chrono.GJChronology gJChronology49 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.CopticChronology copticChronology50 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField51 = copticChronology50.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField53 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField51, dateTimeFieldType52);
        int int55 = delegatedDateTimeField53.getMinimumValue((long) (byte) 0);
        boolean boolean57 = delegatedDateTimeField53.isLeap((long) 0);
        org.joda.time.field.SkipDateTimeField skipDateTimeField59 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology49, (org.joda.time.DateTimeField) delegatedDateTimeField53, 1969);
        int int60 = skipDateTimeField59.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial61 = null;
        int[] intArray65 = new int[] { 'a', 2000 };
        int[] intArray67 = skipDateTimeField59.add(readablePartial61, 0, intArray65, 0);
        try {
            int[] intArray69 = dividedDateTimeField28.add((org.joda.time.ReadablePartial) localDate34, 365, intArray67, 3588);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 365");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2" + "'", str23.equals("2"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-28800000) + "'", int33 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1969" + "'", str38.equals("1969"));
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(localDate46);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(gJChronology49);
        org.junit.Assert.assertNotNull(copticChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(intArray67);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField2 = copticChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology1.secondOfDay();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.DateTime dateTime9 = dateTime7.withEarlierOffsetAtOverlap();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.withFields(readablePartial10);
        boolean boolean12 = copticChronology1.equals((java.lang.Object) dateTime7);
        org.joda.time.DateTimeField dateTimeField13 = copticChronology1.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField13, (int) 'a');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        java.util.Locale locale5 = null;
        java.lang.String str6 = localDate3.toString("000000Z", locale5);
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField8 = copticChronology7.weeks();
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology7.getZone();
        org.joda.time.DateMidnight dateMidnight10 = localDate3.toDateMidnight(dateTimeZone9);
        int int11 = localDate3.getYear();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "000000" + "'", str6.equals("000000"));
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1970 + "'", int11 == 1970);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime6 = property4.addToCopy((long) (byte) 100);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfMinute();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray5 = gJChronology0.get(readablePeriod3, (-31449599999L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (short) -1);
        org.joda.time.DateTime dateTime5 = instant1.toDateTime(dateTimeZone2);
        int int6 = dateTime5.getWeekyear();
        int int7 = dateTime5.getMillisOfDay();
        org.joda.time.DateTime dateTime9 = dateTime5.minusYears((int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1970 + "'", int6 == 1970);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 57600032 + "'", int7 == 57600032);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(32L, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
        org.joda.time.DateTime dateTime6 = localDate3.toDateTimeAtCurrentTime(dateTimeZone5);
        int int7 = localDate3.getCenturyOfEra();
        org.joda.time.LocalDate localDate9 = localDate3.withEra(0);
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology11.hourOfHalfday();
        org.joda.time.DurationField durationField13 = copticChronology11.millis();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology11, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((java.lang.Object) 1560639843040L, dateTimeZone14);
        org.joda.time.DateTime dateTime18 = localDate3.toDateTimeAtStartOfDay(dateTimeZone14);
        long long21 = dateTimeZone14.adjustOffset(0L, false);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYearOfEra(12, 52);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfSecond(12, 52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.LocalDate localDate0 = org.joda.time.LocalDate.now();
        org.joda.time.LocalDate.Property property1 = localDate0.dayOfWeek();
        java.util.Locale locale3 = null;
        java.lang.String str4 = localDate0.toString("69", locale3);
        org.junit.Assert.assertNotNull(localDate0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "69" + "'", str4.equals("69"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, 70);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (short) 0);
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter2.printTo(appendable3, (long) (-99136));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 1970, dateTimeZone1);
        org.joda.time.LocalDate localDate6 = localDate4.withYear((int) (short) 1);
        boolean boolean7 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate6);
        int int8 = localDate6.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 1970, dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withPivotYear((java.lang.Integer) 0);
        java.lang.String str8 = localDate4.toString(dateTimeFormatter7);
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(chronology10);
        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
        org.joda.time.DateTime dateTime13 = dateTime11.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = localDate4.toDateTime((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.LocalDate localDate16 = localDate4.withWeekyear((-132));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDate16);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(0L, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField5 = gJChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.centuryOfEra();
        org.joda.time.DurationField durationField7 = gJChronology4.days();
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTime3, (java.lang.Object) gJChronology4);
        try {
            org.joda.time.DateTime dateTime10 = dateTime3.withEra((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (short) -1);
        org.joda.time.DateTime dateTime5 = instant1.toDateTime(dateTimeZone2);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTime dateTime8 = dateTime5.withMillisOfSecond(132);
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = copticChronology9.hourOfHalfday();
        org.joda.time.DurationField durationField11 = copticChronology9.millis();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime((org.joda.time.Chronology) copticChronology9);
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = copticChronology13.hourOfHalfday();
        org.joda.time.DurationField durationField15 = copticChronology13.millis();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology13, dateTimeZone16);
        try {
            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) copticChronology9, dateTimeZone16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.CopticChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
        org.junit.Assert.assertNotNull(zonedChronology18);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        int int5 = delegatedDateTimeField3.getMinimumValue((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate9 = org.joda.time.LocalDate.now(dateTimeZone6);
        java.util.Locale locale11 = null;
        java.lang.String str12 = localDate9.toString("000000Z", locale11);
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField14 = copticChronology13.weeks();
        org.joda.time.DateTimeZone dateTimeZone15 = copticChronology13.getZone();
        org.joda.time.DateMidnight dateMidnight16 = localDate9.toDateMidnight(dateTimeZone15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.LocalDate localDate18 = localDate9.minus(readablePeriod17);
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
        int int26 = delegatedDateTimeField24.getMinimumValue((long) (byte) 0);
        boolean boolean28 = delegatedDateTimeField24.isLeap((long) 0);
        org.joda.time.field.SkipDateTimeField skipDateTimeField30 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology20, (org.joda.time.DateTimeField) delegatedDateTimeField24, 1969);
        int int31 = skipDateTimeField30.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial32 = null;
        int[] intArray36 = new int[] { 'a', 2000 };
        int[] intArray38 = skipDateTimeField30.add(readablePartial32, 0, intArray36, 0);
        try {
            int[] intArray40 = delegatedDateTimeField3.set((org.joda.time.ReadablePartial) localDate9, (int) (short) -1, intArray38, 57600);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for weekyearOfCentury must be in the range [1,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "000000" + "'", str12.equals("000000"));
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(copticChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray38);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.junit.Assert.assertNotNull(strMap0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4', true);
        org.joda.time.format.DateTimeParser dateTimeParser6 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.append(dateTimeParser6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 1970, dateTimeZone1);
        org.joda.time.LocalDate localDate6 = localDate4.withYear((int) (short) 1);
        int int7 = localDate4.getWeekyear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (short) 0);
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter0.printTo(appendable3, (long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        int int7 = dateTimeZone5.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate8 = org.joda.time.LocalDate.now(dateTimeZone5);
        java.util.Locale locale10 = null;
        java.lang.String str11 = localDate8.toString("000000Z", locale10);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField13 = copticChronology12.weeks();
        org.joda.time.DateTimeZone dateTimeZone14 = copticChronology12.getZone();
        org.joda.time.DateMidnight dateMidnight15 = localDate8.toDateMidnight(dateTimeZone14);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.LocalDate localDate17 = localDate8.minus(readablePeriod16);
        org.joda.time.LocalTime localTime18 = null;
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone20 = gJChronology19.getZone();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = localDate17.toDateTime(localTime18, dateTimeZone20);
        try {
            org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(0, (int) ' ', 0, 3, (int) (byte) 100, dateTimeZone20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-28800000) + "'", int7 == (-28800000));
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "000000" + "'", str11.equals("000000"));
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateMidnight15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) ' ');
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.joda.time.Instant instant4 = instant1.withMillis(0L);
        org.joda.time.MutableDateTime mutableDateTime5 = instant1.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        int int5 = delegatedDateTimeField3.getMinimumValue((long) (byte) 0);
        int int6 = delegatedDateTimeField3.getMinimumValue();
        int int7 = delegatedDateTimeField3.getMinimumValue();
        long long9 = delegatedDateTimeField3.roundCeiling(315705600007L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 337244400000L + "'", long9 == 337244400000L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendMillisOfSecond(1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendHourOfHalfday(3588);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 1970, dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withPivotYear((java.lang.Integer) 0);
        java.lang.String str8 = localDate4.toString(dateTimeFormatter7);
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(chronology10);
        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
        org.joda.time.DateTime dateTime13 = dateTime11.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = localDate4.toDateTime((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.LocalDate.Property property15 = localDate4.dayOfMonth();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder16.appendClockhourOfDay(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder20.appendTimeZoneShortName();
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField23, dateTimeFieldType24);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField25);
        long long28 = delegatedDateTimeField25.roundHalfFloor((long) (short) 10);
        org.joda.time.ReadableInterval readableInterval29 = null;
        org.joda.time.Chronology chronology30 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval29);
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(chronology30);
        org.joda.time.DateTime.Property property32 = dateTime31.millisOfSecond();
        org.joda.time.DateTime.Property property33 = dateTime31.millisOfSecond();
        org.joda.time.DateTime dateTime35 = dateTime31.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property36 = dateTime35.weekOfWeekyear();
        java.lang.String str37 = property36.getAsShortText();
        int int38 = property36.getMinimumValueOverall();
        int int39 = property36.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property36.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField25, dateTimeFieldType40, 3588);
        org.joda.time.chrono.CopticChronology copticChronology43 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField44 = copticChronology43.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField46 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField44, dateTimeFieldType45);
        boolean boolean47 = delegatedDateTimeField46.isSupported();
        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.getDefault();
        int int51 = dateTimeZone49.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate52 = new org.joda.time.LocalDate((long) 1970, dateTimeZone49);
        org.joda.time.LocalDate localDate54 = localDate52.withYear((int) (short) 1);
        java.util.Locale locale55 = null;
        java.lang.String str56 = delegatedDateTimeField46.getAsText((org.joda.time.ReadablePartial) localDate54, locale55);
        org.joda.time.DurationField durationField57 = null;
        org.joda.time.ReadableInterval readableInterval58 = null;
        org.joda.time.Chronology chronology59 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval58);
        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime(chronology59);
        org.joda.time.DateTime.Property property61 = dateTime60.millisOfSecond();
        org.joda.time.DateTime.Property property62 = dateTime60.millisOfSecond();
        org.joda.time.DateTime dateTime64 = dateTime60.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property65 = dateTime64.weekOfWeekyear();
        java.lang.String str66 = property65.getAsShortText();
        int int67 = property65.getMinimumValueOverall();
        int int68 = property65.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType69 = property65.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField71 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField46, durationField57, dateTimeFieldType69, 52);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField75 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField25, dateTimeFieldType69, 69, 0, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder78 = dateTimeFormatterBuilder20.appendFraction(dateTimeFieldType69, (int) '#', 10);
        try {
            org.joda.time.LocalDate localDate80 = localDate4.withField(dateTimeFieldType69, (-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-9910800000L) + "'", long28 == (-9910800000L));
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "2" + "'", str37.equals("2"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 52 + "'", int39 == 52);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(copticChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-28800000) + "'", int51 == (-28800000));
        org.junit.Assert.assertNotNull(localDate54);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "1" + "'", str56.equals("1"));
        org.junit.Assert.assertNotNull(chronology59);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(property65);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "2" + "'", str66.equals("2"));
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 52 + "'", int68 == 52);
        org.junit.Assert.assertNotNull(dateTimeFieldType69);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder78);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfSecond();
        org.joda.time.DateTime.Property property5 = dateTime3.millisOfSecond();
        org.joda.time.DateTime dateTime7 = dateTime3.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        java.lang.String str9 = property8.getAsShortText();
        int int10 = property8.getMinimumValueOverall();
        org.joda.time.DateTime dateTime11 = property8.withMaximumValue();
        org.joda.time.DurationField durationField12 = property8.getRangeDurationField();
        org.joda.time.ReadableInterval readableInterval13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(chronology14);
        org.joda.time.DateTime.Property property16 = dateTime15.millisOfSecond();
        org.joda.time.DateTime.Property property17 = dateTime15.millisOfSecond();
        org.joda.time.DateTime dateTime19 = dateTime15.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property20 = dateTime19.weekOfWeekyear();
        java.lang.String str21 = property20.getAsShortText();
        int int22 = property20.getMinimumValueOverall();
        int int23 = property20.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property20.getFieldType();
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField26 = new org.joda.time.field.RemainderDateTimeField(dateTimeField0, durationField12, dateTimeFieldType24, (-99136));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2" + "'", str9.equals("2"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2" + "'", str21.equals("2"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 52 + "'", int23 == 52);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial(chronology1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField5 = gJChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.yearOfEra();
        org.joda.time.Partial partial8 = partial3.withChronologyRetainFields((org.joda.time.Chronology) gJChronology4);
        org.joda.time.ReadablePartial readablePartial9 = null;
        try {
            boolean boolean10 = partial8.isMatch(readablePartial9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(partial8);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        long long6 = delegatedDateTimeField3.addWrapField((long) 1, (int) (short) -1);
        long long8 = delegatedDateTimeField3.remainder((long) 19);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31449599999L) + "'", long6 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9907200019L + "'", long8 == 9907200019L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        java.lang.String str8 = property7.getAsShortText();
        int int9 = property7.getMinimumValueOverall();
        org.joda.time.DateTime dateTime10 = property7.withMaximumValue();
        java.util.Locale locale11 = null;
        int int12 = property7.getMaximumShortTextLength(locale11);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2" + "'", str8.equals("2"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("millisOfSecond");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"millisOfSecond\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime4 = null;
        try {
            boolean boolean5 = dateTimeZone1.isLocalDateTimeGap(localDateTime4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        boolean boolean4 = delegatedDateTimeField3.isSupported();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
        org.joda.time.DurationField durationField14 = null;
        org.joda.time.ReadableInterval readableInterval15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
        java.lang.String str23 = property22.getAsShortText();
        int int24 = property22.getMinimumValueOverall();
        int int25 = property22.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
        int int29 = dividedDateTimeField28.getMinimumValue();
        long long32 = dividedDateTimeField28.add(0L, 0);
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.getDefault();
        int int36 = dateTimeZone34.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate((long) 1970, dateTimeZone34);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = dateTimeFormatter38.withPivotYear((java.lang.Integer) 0);
        java.lang.String str41 = localDate37.toString(dateTimeFormatter40);
        org.joda.time.ReadableInterval readableInterval42 = null;
        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval42);
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(chronology43);
        org.joda.time.DateTime.Property property45 = dateTime44.millisOfSecond();
        org.joda.time.DateTime dateTime46 = dateTime44.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime47 = localDate37.toDateTime((org.joda.time.ReadableInstant) dateTime44);
        org.joda.time.LocalDate localDate49 = localDate37.plusMonths((-132));
        org.joda.time.LocalDate.Property property50 = localDate37.era();
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.CopticChronology copticChronology52 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField53 = copticChronology52.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField55 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField53, dateTimeFieldType54);
        int int57 = delegatedDateTimeField55.getMinimumValue((long) (byte) 0);
        boolean boolean59 = delegatedDateTimeField55.isLeap((long) 0);
        org.joda.time.field.SkipDateTimeField skipDateTimeField61 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology51, (org.joda.time.DateTimeField) delegatedDateTimeField55, 1969);
        int int62 = skipDateTimeField61.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial63 = null;
        int[] intArray67 = new int[] { 'a', 2000 };
        int[] intArray69 = skipDateTimeField61.add(readablePartial63, 0, intArray67, 0);
        int int70 = dividedDateTimeField28.getMaximumValue((org.joda.time.ReadablePartial) localDate37, intArray69);
        long long73 = dividedDateTimeField28.getDifferenceAsLong((long) (byte) 10, 28800132L);
        java.util.Locale locale76 = null;
        try {
            long long77 = dividedDateTimeField28.set(1560639843626L, "era", locale76);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"era\" for weekOfWeekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2" + "'", str23.equals("2"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-28800000) + "'", int36 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1969" + "'", str41.equals("1969"));
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(copticChronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 0L + "'", long73 == 0L);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.DataOutput dataOutput2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("69", dataOutput2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        int int5 = delegatedDateTimeField3.getMinimumValue((long) (byte) 0);
        long long8 = delegatedDateTimeField3.getDifferenceAsLong(0L, (long) 4);
        int int11 = delegatedDateTimeField3.getDifference((long) 3, (long) ' ');
        org.joda.time.DurationField durationField12 = delegatedDateTimeField3.getRangeDurationField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.hourOfHalfday();
        org.joda.time.DurationField durationField2 = copticChronology0.millis();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate9 = org.joda.time.LocalDate.now(dateTimeZone6);
        java.lang.String str10 = dateTimeZone6.getID();
        org.joda.time.Chronology chronology11 = copticChronology0.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField12 = copticChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "America/Los_Angeles" + "'", str10.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        java.lang.Appendable appendable1 = null;
        org.joda.time.Instant instant3 = new org.joda.time.Instant((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        int int6 = dateTimeZone4.getOffsetFromLocal((long) (short) -1);
        org.joda.time.DateTime dateTime7 = instant3.toDateTime(dateTimeZone4);
        boolean boolean9 = dateTime7.equals((java.lang.Object) 0.0d);
        org.joda.time.DateTime dateTime11 = dateTime7.withYear((int) (short) -1);
        org.joda.time.DateTime dateTime13 = dateTime7.plusMinutes(100);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-28800000) + "'", int6 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        int int1 = copticChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(chronology3);
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfSecond();
        org.joda.time.DateTime dateTime7 = property5.addWrapFieldToCopy(0);
        boolean boolean8 = copticChronology0.equals((java.lang.Object) dateTime7);
        try {
            long long13 = copticChronology0.getDateTimeMillis(70, 3, 69, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
        org.joda.time.DateTime dateTime6 = localDate3.toDateTimeAtCurrentTime(dateTimeZone5);
        boolean boolean7 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate3);
        org.joda.time.ReadableInterval readableInterval8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(chronology9);
        org.joda.time.DateTime.Property property11 = dateTime10.millisOfSecond();
        org.joda.time.DateTime.Property property12 = dateTime10.millisOfSecond();
        org.joda.time.DateTime dateTime14 = dateTime10.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property15 = dateTime14.weekOfWeekyear();
        java.lang.String str16 = property15.getAsShortText();
        int int17 = property15.getMinimumValueOverall();
        int int18 = property15.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property15.getFieldType();
        org.joda.time.LocalDate.Property property20 = localDate3.property(dateTimeFieldType19);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        int int23 = dateTimeZone21.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate24 = org.joda.time.LocalDate.now(dateTimeZone21);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = gJChronology25.getZone();
        org.joda.time.DateTime dateTime27 = localDate24.toDateTimeAtCurrentTime(dateTimeZone26);
        boolean boolean28 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate24);
        org.joda.time.ReadableInterval readableInterval29 = null;
        org.joda.time.Chronology chronology30 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval29);
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(chronology30);
        org.joda.time.DateTime.Property property32 = dateTime31.millisOfSecond();
        org.joda.time.DateTime.Property property33 = dateTime31.millisOfSecond();
        org.joda.time.DateTime dateTime35 = dateTime31.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property36 = dateTime35.weekOfWeekyear();
        java.lang.String str37 = property36.getAsShortText();
        int int38 = property36.getMinimumValueOverall();
        int int39 = property36.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property36.getFieldType();
        org.joda.time.LocalDate.Property property41 = localDate24.property(dateTimeFieldType40);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray42 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType19, dateTimeFieldType40 };
        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField45 = copticChronology44.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField47 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField45, dateTimeFieldType46);
        int int49 = delegatedDateTimeField47.getMinimumValue((long) (byte) 0);
        boolean boolean51 = delegatedDateTimeField47.isLeap((long) 0);
        org.joda.time.field.SkipDateTimeField skipDateTimeField53 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology43, (org.joda.time.DateTimeField) delegatedDateTimeField47, 1969);
        int int54 = skipDateTimeField53.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial55 = null;
        int[] intArray59 = new int[] { 'a', 2000 };
        int[] intArray61 = skipDateTimeField53.add(readablePartial55, 0, intArray59, 0);
        org.joda.time.chrono.CopticChronology copticChronology62 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField63 = copticChronology62.weeks();
        org.joda.time.DateTimeField dateTimeField64 = copticChronology62.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField65 = copticChronology62.secondOfDay();
        org.joda.time.ReadableInterval readableInterval66 = null;
        org.joda.time.Chronology chronology67 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval66);
        org.joda.time.DateTime dateTime68 = new org.joda.time.DateTime(chronology67);
        org.joda.time.DateTime.Property property69 = dateTime68.millisOfSecond();
        org.joda.time.DateTime dateTime70 = dateTime68.withEarlierOffsetAtOverlap();
        org.joda.time.ReadablePartial readablePartial71 = null;
        org.joda.time.DateTime dateTime72 = dateTime68.withFields(readablePartial71);
        boolean boolean73 = copticChronology62.equals((java.lang.Object) dateTime68);
        org.joda.time.DateTimeField dateTimeField74 = copticChronology62.weekOfWeekyear();
        int int75 = copticChronology62.getMinimumDaysInFirstWeek();
        try {
            org.joda.time.Partial partial76 = new org.joda.time.Partial(dateTimeFieldTypeArray42, intArray59, (org.joda.time.Chronology) copticChronology62);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not contain duplicate: weekOfWeekyear");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2" + "'", str16.equals("2"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 52 + "'", int18 == 52);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-28800000) + "'", int23 == (-28800000));
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "2" + "'", str37.equals("2"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 52 + "'", int39 == 52);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray42);
        org.junit.Assert.assertNotNull(gJChronology43);
        org.junit.Assert.assertNotNull(copticChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(copticChronology62);
        org.junit.Assert.assertNotNull(durationField63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(chronology67);
        org.junit.Assert.assertNotNull(property69);
        org.junit.Assert.assertNotNull(dateTime70);
        org.junit.Assert.assertNotNull(dateTime72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(dateTimeField74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 4 + "'", int75 == 4);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
        java.lang.String str15 = property14.getAsShortText();
        int int16 = property14.getMinimumValueOverall();
        int int17 = property14.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
        boolean boolean25 = delegatedDateTimeField24.isSupported();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
        int int29 = dateTimeZone27.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) 1970, dateTimeZone27);
        org.joda.time.LocalDate localDate32 = localDate30.withYear((int) (short) 1);
        java.util.Locale locale33 = null;
        java.lang.String str34 = delegatedDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDate32, locale33);
        org.joda.time.DurationField durationField35 = null;
        org.joda.time.ReadableInterval readableInterval36 = null;
        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
        org.joda.time.DateTime.Property property39 = dateTime38.millisOfSecond();
        org.joda.time.DateTime.Property property40 = dateTime38.millisOfSecond();
        org.joda.time.DateTime dateTime42 = dateTime38.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
        java.lang.String str44 = property43.getAsShortText();
        int int45 = property43.getMinimumValueOverall();
        int int46 = property43.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField24, durationField35, dateTimeFieldType47, 52);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType47, 69, 0, 0);
        try {
            long long56 = offsetDateTimeField53.add((long) (-28800000), (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 155 for weekOfWeekyear must be in the range [70,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2" + "'", str15.equals("2"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(copticChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "2" + "'", str44.equals("2"));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.weeks();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.Partial partial4 = new org.joda.time.Partial((org.joda.time.Chronology) copticChronology0);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        boolean boolean4 = delegatedDateTimeField3.isSupported();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
        org.joda.time.DurationField durationField14 = null;
        org.joda.time.ReadableInterval readableInterval15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
        java.lang.String str23 = property22.getAsShortText();
        int int24 = property22.getMinimumValueOverall();
        int int25 = property22.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
        int int29 = dividedDateTimeField28.getMinimumValue();
        long long32 = dividedDateTimeField28.add(0L, 0);
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.getDefault();
        int int36 = dateTimeZone34.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate((long) 1970, dateTimeZone34);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = dateTimeFormatter38.withPivotYear((java.lang.Integer) 0);
        java.lang.String str41 = localDate37.toString(dateTimeFormatter40);
        org.joda.time.ReadableInterval readableInterval42 = null;
        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval42);
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(chronology43);
        org.joda.time.DateTime.Property property45 = dateTime44.millisOfSecond();
        org.joda.time.DateTime dateTime46 = dateTime44.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime47 = localDate37.toDateTime((org.joda.time.ReadableInstant) dateTime44);
        org.joda.time.LocalDate localDate49 = localDate37.plusMonths((-132));
        org.joda.time.LocalDate.Property property50 = localDate37.era();
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.CopticChronology copticChronology52 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField53 = copticChronology52.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField55 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField53, dateTimeFieldType54);
        int int57 = delegatedDateTimeField55.getMinimumValue((long) (byte) 0);
        boolean boolean59 = delegatedDateTimeField55.isLeap((long) 0);
        org.joda.time.field.SkipDateTimeField skipDateTimeField61 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology51, (org.joda.time.DateTimeField) delegatedDateTimeField55, 1969);
        int int62 = skipDateTimeField61.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial63 = null;
        int[] intArray67 = new int[] { 'a', 2000 };
        int[] intArray69 = skipDateTimeField61.add(readablePartial63, 0, intArray67, 0);
        int int70 = dividedDateTimeField28.getMaximumValue((org.joda.time.ReadablePartial) localDate37, intArray69);
        org.joda.time.ReadableInterval readableInterval71 = null;
        org.joda.time.Chronology chronology72 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval71);
        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime(chronology72);
        org.joda.time.Partial partial74 = new org.joda.time.Partial(chronology72);
        org.joda.time.chrono.GJChronology gJChronology75 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField76 = gJChronology75.weekyears();
        org.joda.time.DateTimeField dateTimeField77 = gJChronology75.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField78 = gJChronology75.yearOfEra();
        org.joda.time.Partial partial79 = partial74.withChronologyRetainFields((org.joda.time.Chronology) gJChronology75);
        int[] intArray80 = partial79.getValues();
        java.util.Locale locale81 = null;
        try {
            java.lang.String str82 = dividedDateTimeField28.getAsText((org.joda.time.ReadablePartial) partial79, locale81);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekOfWeekyear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2" + "'", str23.equals("2"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-28800000) + "'", int36 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1969" + "'", str41.equals("1969"));
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(copticChronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
        org.junit.Assert.assertNotNull(chronology72);
        org.junit.Assert.assertNotNull(gJChronology75);
        org.junit.Assert.assertNotNull(durationField76);
        org.junit.Assert.assertNotNull(dateTimeField77);
        org.junit.Assert.assertNotNull(dateTimeField78);
        org.junit.Assert.assertNotNull(partial79);
        org.junit.Assert.assertNotNull(intArray80);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        boolean boolean4 = dateTime2.isEqual((long) (short) 1);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfMinute((int) 'a');
        boolean boolean5 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendLiteral("000000");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendMonthOfYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (short) -1);
        org.joda.time.DateTime dateTime5 = instant1.toDateTime(dateTimeZone2);
        boolean boolean7 = dateTime5.equals((java.lang.Object) 0.0d);
        org.joda.time.DateTime.Property property8 = dateTime5.secondOfDay();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime5.plus(readableDuration9);
        try {
            org.joda.time.DateTime dateTime12 = dateTime10.withEra(132);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 132 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 1970, dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withPivotYear((java.lang.Integer) 0);
        java.lang.String str8 = localDate4.toString(dateTimeFormatter7);
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(chronology10);
        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
        org.joda.time.DateTime dateTime13 = dateTime11.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = localDate4.toDateTime((org.joda.time.ReadableInstant) dateTime11);
        try {
            java.lang.String str16 = dateTime14.toString("weekOfWeekyear");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: O");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        boolean boolean4 = delegatedDateTimeField3.isSupported();
        java.lang.String str6 = delegatedDateTimeField3.getAsText((long) 1970);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "87" + "'", str6.equals("87"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 19, "");
        boolean boolean3 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalInstantException2);
        boolean boolean4 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalInstantException2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        java.lang.String str8 = property7.getAsShortText();
        int int9 = property7.getMinimumValueOverall();
        org.joda.time.DateTime dateTime10 = property7.withMaximumValue();
        org.joda.time.DurationField durationField11 = property7.getRangeDurationField();
        org.joda.time.DurationFieldType durationFieldType12 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField14 = new org.joda.time.field.ScaledDurationField(durationField11, durationFieldType12, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2" + "'", str8.equals("2"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.weeks();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial(chronology1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField5 = gJChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.yearOfEra();
        org.joda.time.Partial partial8 = partial3.withChronologyRetainFields((org.joda.time.Chronology) gJChronology4);
        try {
            org.joda.time.Instant instant9 = new org.joda.time.Instant((java.lang.Object) partial3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.Partial");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(partial8);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        int int5 = delegatedDateTimeField3.getMinimumValue((long) (byte) 0);
        int int6 = delegatedDateTimeField3.getMinimumValue();
        long long8 = delegatedDateTimeField3.roundHalfEven((long) 100);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9910800000L) + "'", long8 == (-9910800000L));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay(4);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = null;
        org.joda.time.format.DateTimeParser dateTimeParser6 = null;
        org.joda.time.format.DateTimeParser[] dateTimeParserArray7 = new org.joda.time.format.DateTimeParser[] { dateTimeParser6 };
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.append(dateTimePrinter5, dateTimeParserArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeParserArray7);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("100", number1, (java.lang.Number) 100, (java.lang.Number) (byte) 1);
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException4.getSuppressed();
        java.lang.String str6 = illegalFieldValueException4.getFieldName();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100" + "'", str6.equals("100"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (short) 0);
        boolean boolean3 = dateTimeFormatter2.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        int int5 = delegatedDateTimeField3.getMinimumValue((long) (byte) 0);
        int int6 = delegatedDateTimeField3.getMinimumValue();
        int int7 = delegatedDateTimeField3.getMinimumValue();
        long long9 = delegatedDateTimeField3.roundHalfCeiling((long) 19);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) delegatedDateTimeField3, 0, (int) (byte) 1, 1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekyearOfCentury must be in the range [1,1970]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9910800000L) + "'", long9 == (-9910800000L));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.centuryOfEra();
        org.joda.time.Chronology chronology3 = gJChronology0.withUTC();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.secondOfDay();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology5);
        org.joda.time.DateTime.Property property7 = dateTime6.millisOfSecond();
        org.joda.time.DateTime dateTime8 = dateTime6.withEarlierOffsetAtOverlap();
        org.joda.time.ReadablePartial readablePartial9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.withFields(readablePartial9);
        boolean boolean11 = copticChronology0.equals((java.lang.Object) dateTime6);
        org.joda.time.DateTime dateTime13 = dateTime6.minusHours((int) (short) 0);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime16 = dateTime6.withDurationAdded(readableDuration14, 10);
        org.joda.time.Instant instant17 = dateTime16.toInstant();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(instant17);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial(chronology1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField5 = gJChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.yearOfEra();
        org.joda.time.Partial partial8 = partial3.withChronologyRetainFields((org.joda.time.Chronology) gJChronology4);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType10 = partial8.getFieldType((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(partial8);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.secondOfDay();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology5);
        org.joda.time.DateTime.Property property7 = dateTime6.millisOfSecond();
        org.joda.time.DateTime dateTime8 = dateTime6.withEarlierOffsetAtOverlap();
        org.joda.time.ReadablePartial readablePartial9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.withFields(readablePartial9);
        boolean boolean11 = copticChronology0.equals((java.lang.Object) dateTime6);
        org.joda.time.DateTime dateTime13 = dateTime6.withYear((int) (byte) 100);
        org.joda.time.DateTime dateTime14 = dateTime6.toDateTimeISO();
        org.joda.time.DateTime dateTime16 = dateTime6.plusYears((int) '#');
        try {
            org.joda.time.DateTime dateTime18 = dateTime16.withMonthOfYear(365);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.hourOfHalfday();
        org.joda.time.DurationField durationField2 = copticChronology0.millis();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone3);
        try {
            long long11 = zonedChronology5.getDateTimeMillis((-2618784000000L), (int) ' ', (int) (short) 100, 12, (-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(chronology1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField4 = gJChronology3.weekyears();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, dateTimeField5, (int) (byte) -1);
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipUndoDateTimeField7.getAsText((int) (byte) 100, locale9);
        int int11 = skipUndoDateTimeField7.getMinimumValue();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100" + "'", str10.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) 1970, dateTimeZone2);
        org.joda.time.LocalDate localDate7 = localDate5.withYear((int) (short) 1);
        boolean boolean8 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate7);
        java.lang.String str9 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate7);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0001-12-31T��:��:��" + "'", str9.equals("0001-12-31T��:��:��"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 86, number2, (java.lang.Number) 10);
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException4.getSuppressed();
        java.lang.String str6 = illegalFieldValueException4.getIllegalStringValue();
        illegalFieldValueException4.prependMessage("658");
        java.lang.String str9 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Number number10 = illegalFieldValueException4.getIllegalNumberValue();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "86" + "'", str9.equals("86"));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 86 + "'", number10.equals(86));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) ' ');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
        java.lang.String str15 = property14.getAsShortText();
        int int16 = property14.getMinimumValueOverall();
        int int17 = property14.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
        long long23 = offsetDateTimeField20.add(1560639843040L, 0);
        java.lang.String str24 = offsetDateTimeField20.getName();
        boolean boolean25 = offsetDateTimeField20.isSupported();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2" + "'", str15.equals("2"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560639843040L + "'", long23 == 1560639843040L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "weekOfWeekyear" + "'", str24.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter2.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(dateTimeZone3);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) ' ');
        long long2 = instant1.getMillis();
        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime();
        org.joda.time.Chronology chronology4 = instant1.getChronology();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        java.util.Locale locale5 = null;
        java.lang.String str6 = localDate3.toString("000000Z", locale5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = localDate3.indexOf(dateTimeFieldType7);
        org.joda.time.DateTime dateTime9 = localDate3.toDateTimeAtMidnight();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        long long14 = dateTimeZone11.adjustOffset(10L, true);
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) 1969, dateTimeZone11);
        org.joda.time.DateMidnight dateMidnight16 = localDate15.toDateMidnight();
        org.joda.time.LocalDate.Property property17 = localDate15.monthOfYear();
        org.joda.time.LocalDate localDate18 = property17.roundHalfFloorCopy();
        org.joda.time.LocalDate localDate20 = localDate18.plusWeeks(7);
        boolean boolean21 = localDate3.equals((java.lang.Object) localDate18);
        int int22 = localDate18.getDayOfWeek();
        int int23 = localDate18.getCenturyOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "000000" + "'", str6.equals("000000"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 19 + "'", int23 == 19);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime6.plusMillis((-1));
        int int10 = dateTime9.getYearOfCentury();
        int int11 = dateTime9.getSecondOfMinute();
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime9.minus(readableDuration12);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 70 + "'", int10 == 70);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 59 + "'", int11 == 59);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
        java.lang.String str15 = property14.getAsShortText();
        int int16 = property14.getMinimumValueOverall();
        int int17 = property14.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
        boolean boolean25 = delegatedDateTimeField24.isSupported();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
        int int29 = dateTimeZone27.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) 1970, dateTimeZone27);
        org.joda.time.LocalDate localDate32 = localDate30.withYear((int) (short) 1);
        java.util.Locale locale33 = null;
        java.lang.String str34 = delegatedDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDate32, locale33);
        org.joda.time.DurationField durationField35 = null;
        org.joda.time.ReadableInterval readableInterval36 = null;
        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
        org.joda.time.DateTime.Property property39 = dateTime38.millisOfSecond();
        org.joda.time.DateTime.Property property40 = dateTime38.millisOfSecond();
        org.joda.time.DateTime dateTime42 = dateTime38.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
        java.lang.String str44 = property43.getAsShortText();
        int int45 = property43.getMinimumValueOverall();
        int int46 = property43.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField24, durationField35, dateTimeFieldType47, 52);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType47, 69, 0, 0);
        long long56 = delegatedDateTimeField3.add((long) 70, (long) 3675);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2" + "'", str15.equals("2"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(copticChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "2" + "'", str44.equals("2"));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 115974633600070L + "'", long56 == 115974633600070L);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 1970, dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withPivotYear((java.lang.Integer) 0);
        java.lang.String str8 = localDate4.toString(dateTimeFormatter7);
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(chronology10);
        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
        org.joda.time.DateTime dateTime13 = dateTime11.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = localDate4.toDateTime((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime.Property property15 = dateTime14.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 1970, dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withPivotYear((java.lang.Integer) 0);
        java.lang.String str8 = localDate4.toString(dateTimeFormatter7);
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(chronology10);
        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
        org.joda.time.DateTime dateTime13 = dateTime11.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = localDate4.toDateTime((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        org.joda.time.DateTime dateTime18 = localDate4.toDateTimeAtCurrentTime(dateTimeZone17);
        try {
            org.joda.time.DateTime dateTime20 = dateTime18.withDayOfWeek(59);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial(chronology1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField5 = gJChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.yearOfEra();
        org.joda.time.Partial partial8 = partial3.withChronologyRetainFields((org.joda.time.Chronology) gJChronology4);
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = copticChronology9.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10, dateTimeFieldType11);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField12);
        long long15 = delegatedDateTimeField12.roundHalfFloor((long) (short) 10);
        org.joda.time.ReadableInterval readableInterval16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(chronology17);
        org.joda.time.DateTime.Property property19 = dateTime18.millisOfSecond();
        org.joda.time.DateTime.Property property20 = dateTime18.millisOfSecond();
        org.joda.time.DateTime dateTime22 = dateTime18.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property23 = dateTime22.weekOfWeekyear();
        java.lang.String str24 = property23.getAsShortText();
        int int25 = property23.getMinimumValueOverall();
        int int26 = property23.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property23.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField12, dateTimeFieldType27, 3588);
        org.joda.time.chrono.CopticChronology copticChronology30 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField31 = copticChronology30.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField33 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField31, dateTimeFieldType32);
        boolean boolean34 = delegatedDateTimeField33.isSupported();
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.getDefault();
        int int38 = dateTimeZone36.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate39 = new org.joda.time.LocalDate((long) 1970, dateTimeZone36);
        org.joda.time.LocalDate localDate41 = localDate39.withYear((int) (short) 1);
        java.util.Locale locale42 = null;
        java.lang.String str43 = delegatedDateTimeField33.getAsText((org.joda.time.ReadablePartial) localDate41, locale42);
        org.joda.time.DurationField durationField44 = null;
        org.joda.time.ReadableInterval readableInterval45 = null;
        org.joda.time.Chronology chronology46 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval45);
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime(chronology46);
        org.joda.time.DateTime.Property property48 = dateTime47.millisOfSecond();
        org.joda.time.DateTime.Property property49 = dateTime47.millisOfSecond();
        org.joda.time.DateTime dateTime51 = dateTime47.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property52 = dateTime51.weekOfWeekyear();
        java.lang.String str53 = property52.getAsShortText();
        int int54 = property52.getMinimumValueOverall();
        int int55 = property52.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType56 = property52.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField58 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField33, durationField44, dateTimeFieldType56, 52);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField12, dateTimeFieldType56, 69, 0, 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException65 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType56, (java.lang.Number) 0, "69");
        try {
            org.joda.time.Partial.Property property66 = partial8.property(dateTimeFieldType56);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekOfWeekyear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(partial8);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-9910800000L) + "'", long15 == (-9910800000L));
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2" + "'", str24.equals("2"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(copticChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-28800000) + "'", int38 == (-28800000));
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "1" + "'", str43.equals("1"));
        org.junit.Assert.assertNotNull(chronology46);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "2" + "'", str53.equals("2"));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 52 + "'", int55 == 52);
        org.junit.Assert.assertNotNull(dateTimeFieldType56);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfMinute((int) 'a');
        boolean boolean5 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendLiteral("000000");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap8);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.appendTimeZoneOffset("Pacific Standard Time", true, (int) (short) 100, (-132));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (short) -1);
        org.joda.time.DateTime dateTime5 = instant1.toDateTime(dateTimeZone2);
        boolean boolean7 = dateTime5.equals((java.lang.Object) 0.0d);
        try {
            org.joda.time.DateTime dateTime9 = dateTime5.withYearOfEra((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
        org.joda.time.DateTime dateTime6 = localDate3.toDateTimeAtCurrentTime(dateTimeZone5);
        int int7 = localDate3.getCenturyOfEra();
        int int8 = localDate3.getCenturyOfEra();
        int int9 = localDate3.getDayOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 19 + "'", int8 == 19);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.DataOutput dataOutput2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("3592", dataOutput2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.parse("772");
        java.lang.String str2 = localDate1.toString();
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0772-01-01" + "'", str2.equals("0772-01-01"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime6.plusMillis((-1));
        org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfSecond(100);
        java.lang.String str12 = dateTime11.toString();
        org.joda.time.DateTime dateTime13 = dateTime11.toDateTimeISO();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0070-01-07T15:59:59.100-07:52:58" + "'", str12.equals("0070-01-07T15:59:59.100-07:52:58"));
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime4 = dateTime2.withEarlierOffsetAtOverlap();
        org.joda.time.ReadablePartial readablePartial5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.withFields(readablePartial5);
        int int7 = dateTime6.getYear();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        boolean boolean4 = delegatedDateTimeField3.isSupported();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
        org.joda.time.DurationField durationField14 = null;
        org.joda.time.ReadableInterval readableInterval15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
        java.lang.String str23 = property22.getAsShortText();
        int int24 = property22.getMinimumValueOverall();
        int int25 = property22.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
        int int29 = dividedDateTimeField28.getMinimumValue();
        long long32 = dividedDateTimeField28.add(0L, 0);
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.getDefault();
        int int36 = dateTimeZone34.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate((long) 1970, dateTimeZone34);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = dateTimeFormatter38.withPivotYear((java.lang.Integer) 0);
        java.lang.String str41 = localDate37.toString(dateTimeFormatter40);
        org.joda.time.ReadableInterval readableInterval42 = null;
        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval42);
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(chronology43);
        org.joda.time.DateTime.Property property45 = dateTime44.millisOfSecond();
        org.joda.time.DateTime dateTime46 = dateTime44.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime47 = localDate37.toDateTime((org.joda.time.ReadableInstant) dateTime44);
        org.joda.time.LocalDate localDate49 = localDate37.plusMonths((-132));
        org.joda.time.LocalDate.Property property50 = localDate37.era();
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.CopticChronology copticChronology52 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField53 = copticChronology52.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField55 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField53, dateTimeFieldType54);
        int int57 = delegatedDateTimeField55.getMinimumValue((long) (byte) 0);
        boolean boolean59 = delegatedDateTimeField55.isLeap((long) 0);
        org.joda.time.field.SkipDateTimeField skipDateTimeField61 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology51, (org.joda.time.DateTimeField) delegatedDateTimeField55, 1969);
        int int62 = skipDateTimeField61.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial63 = null;
        int[] intArray67 = new int[] { 'a', 2000 };
        int[] intArray69 = skipDateTimeField61.add(readablePartial63, 0, intArray67, 0);
        int int70 = dividedDateTimeField28.getMaximumValue((org.joda.time.ReadablePartial) localDate37, intArray69);
        long long73 = dividedDateTimeField28.getDifferenceAsLong((long) (byte) 10, 28800132L);
        org.joda.time.ReadablePartial readablePartial74 = null;
        int[] intArray80 = new int[] { 'a', (-132), 70, (-28800000) };
        try {
            int[] intArray82 = dividedDateTimeField28.addWrapPartial(readablePartial74, 70, intArray80, 70);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 70");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2" + "'", str23.equals("2"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-28800000) + "'", int36 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1969" + "'", str41.equals("1969"));
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(copticChronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 0L + "'", long73 == 0L);
        org.junit.Assert.assertNotNull(intArray80);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
        org.joda.time.DateTime dateTime6 = localDate3.toDateTimeAtCurrentTime(dateTimeZone5);
        int int7 = localDate3.getCenturyOfEra();
        org.joda.time.LocalDate localDate9 = localDate3.withEra(0);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.LocalDate localDate11 = localDate3.minus(readablePeriod10);
        java.util.Date date12 = localDate11.toDate();
        org.joda.time.LocalDate localDate13 = org.joda.time.LocalDate.fromDateFields(date12);
        org.joda.time.LocalDate localDate15 = localDate13.withYearOfEra((int) ' ');
        int int16 = localDate15.getMonthOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 1970, dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withPivotYear((java.lang.Integer) 0);
        java.lang.String str8 = localDate4.toString(dateTimeFormatter7);
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(chronology10);
        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
        org.joda.time.DateTime dateTime13 = dateTime11.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = localDate4.toDateTime((org.joda.time.ReadableInstant) dateTime11);
        int int15 = localDate4.getWeekyear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        try {
            java.lang.String str17 = localDate4.toString(dateTimeFormatter16);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1970 + "'", int15 == 1970);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
        java.lang.String str15 = property14.getAsShortText();
        int int16 = property14.getMinimumValueOverall();
        int int17 = property14.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
        long long23 = delegatedDateTimeField3.addWrapField(337244400000L, (int) ' ');
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2" + "'", str15.equals("2"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-1808582400000L) + "'", long23 == (-1808582400000L));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        java.lang.String str8 = property7.getAsShortText();
        int int9 = property7.getMinimumValueOverall();
        org.joda.time.DateTime dateTime10 = property7.withMaximumValue();
        int int11 = property7.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2" + "'", str8.equals("2"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 53 + "'", int11 == 53);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime5 = property3.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime7 = property3.addToCopy(132);
        int int8 = property3.get();
        java.util.Locale locale9 = null;
        int int10 = property3.getMaximumShortTextLength(locale9);
        java.lang.String str11 = property3.toString();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Property[millisOfSecond]" + "'", str11.equals("Property[millisOfSecond]"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 19, "");
        boolean boolean3 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalInstantException2);
        java.lang.String str4 = illegalInstantException2.toString();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.019 ()" + "'", str4.equals("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.019 ()"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.secondOfDay();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology5);
        org.joda.time.DateTime.Property property7 = dateTime6.millisOfSecond();
        org.joda.time.DateTime dateTime8 = dateTime6.withEarlierOffsetAtOverlap();
        org.joda.time.ReadablePartial readablePartial9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.withFields(readablePartial9);
        boolean boolean11 = copticChronology0.equals((java.lang.Object) dateTime6);
        try {
            org.joda.time.DateTime dateTime13 = dateTime6.withHourOfDay(49);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 49 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 86, number2, (java.lang.Number) 10);
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException4.getSuppressed();
        java.lang.String str6 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "86" + "'", str6.equals("86"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime6.plusMillis((-1));
        org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfSecond(100);
        org.joda.time.DateTime dateTime12 = dateTime9.toDateTime();
        org.joda.time.DateTime dateTime14 = dateTime12.minusMillis(7);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime4 = dateTime2.withEarlierOffsetAtOverlap();
        boolean boolean5 = dateTime4.isBeforeNow();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
        org.joda.time.Chronology chronology2 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.era();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        java.util.Locale locale5 = null;
        java.lang.String str6 = localDate3.toString("000000Z", locale5);
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField8 = copticChronology7.weeks();
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology7.getZone();
        org.joda.time.DateMidnight dateMidnight10 = localDate3.toDateMidnight(dateTimeZone9);
        try {
            org.joda.time.LocalDate localDate12 = localDate3.withWeekOfWeekyear((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "000000" + "'", str6.equals("000000"));
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateMidnight10);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
        org.joda.time.DateTime dateTime6 = localDate3.toDateTimeAtCurrentTime(dateTimeZone5);
        int int7 = localDate3.getCenturyOfEra();
        org.joda.time.LocalDate localDate9 = localDate3.withEra(0);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.LocalDate localDate11 = localDate3.minus(readablePeriod10);
        java.util.Date date12 = localDate11.toDate();
        org.joda.time.LocalDate localDate13 = org.joda.time.LocalDate.fromDateFields(date12);
        try {
            org.joda.time.LocalDate localDate15 = localDate13.withDayOfYear((-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(localDate13);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendClockhourOfDay(4);
        boolean boolean7 = cachedDateTimeZone1.equals((java.lang.Object) dateTimeFormatterBuilder6);
        int int9 = cachedDateTimeZone1.getStandardOffset(10L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-28800000) + "'", int9 == (-28800000));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        java.lang.Object obj8 = null;
        boolean boolean9 = gJChronology7.equals(obj8);
        org.joda.time.DateTimeField dateTimeField10 = gJChronology7.yearOfEra();
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(36, (int) '4', (-28800000), 15, 2, (int) ' ', (int) (byte) 10, (org.joda.time.Chronology) gJChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.hourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField4 = gJChronology3.weekyears();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 100, (org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTime dateTime7 = dateTime5.withYear((int) (byte) 1);
        boolean boolean9 = dateTime7.isEqual((-210862267200000L));
        org.joda.time.DateTime.Property property10 = dateTime7.minuteOfHour();
        org.joda.time.DurationField durationField11 = property10.getDurationField();
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(chronology13);
        org.joda.time.DateTime.Property property15 = dateTime14.millisOfSecond();
        org.joda.time.DateTime.Property property16 = dateTime14.millisOfSecond();
        org.joda.time.DateTime dateTime18 = dateTime14.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property19 = dateTime18.weekOfWeekyear();
        java.lang.String str20 = property19.getAsShortText();
        int int21 = property19.getMinimumValueOverall();
        int int22 = property19.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property19.getFieldType();
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, durationField11, dateTimeFieldType23, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2" + "'", str20.equals("2"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 1970, dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withPivotYear((java.lang.Integer) 0);
        java.lang.String str8 = localDate4.toString(dateTimeFormatter7);
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(chronology10);
        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
        org.joda.time.DateTime dateTime13 = dateTime11.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = localDate4.toDateTime((org.joda.time.ReadableInstant) dateTime11);
        boolean boolean16 = dateTime14.isBefore((long) 69);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.centuryOfEra();
        org.joda.time.DurationField durationField3 = gJChronology0.days();
        boolean boolean5 = gJChronology0.equals((java.lang.Object) (-28800000));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate9, locale10);
        org.joda.time.LocalDate.Property property12 = localDate9.dayOfMonth();
        org.joda.time.LocalDate localDate14 = property12.addToCopy((int) 'a');
        try {
            org.joda.time.LocalDate localDate16 = property12.setCopy("Property[millisOfSecond]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Property[millisOfSecond]\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "69" + "'", str11.equals("69"));
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate14);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
        java.lang.String str15 = property14.getAsShortText();
        int int16 = property14.getMinimumValueOverall();
        int int17 = property14.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
        org.joda.time.ReadablePartial readablePartial21 = null;
        int int22 = offsetDateTimeField20.getMaximumValue(readablePartial21);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2" + "'", str15.equals("2"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3688 + "'", int22 == 3688);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(59);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 1970, dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withPivotYear((java.lang.Integer) 0);
        java.lang.String str8 = localDate4.toString(dateTimeFormatter7);
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(chronology10);
        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
        org.joda.time.DateTime dateTime13 = dateTime11.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = localDate4.toDateTime((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
        int int18 = cachedDateTimeZone16.getStandardOffset(0L);
        org.joda.time.Interval interval19 = localDate4.toInterval((org.joda.time.DateTimeZone) cachedDateTimeZone16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder20.appendClockhourOfDay(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder24.appendTimeZoneShortName();
        org.joda.time.chrono.CopticChronology copticChronology26 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField27 = copticChronology26.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField27, dateTimeFieldType28);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField29);
        long long32 = delegatedDateTimeField29.roundHalfFloor((long) (short) 10);
        org.joda.time.ReadableInterval readableInterval33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(chronology34);
        org.joda.time.DateTime.Property property36 = dateTime35.millisOfSecond();
        org.joda.time.DateTime.Property property37 = dateTime35.millisOfSecond();
        org.joda.time.DateTime dateTime39 = dateTime35.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property40 = dateTime39.weekOfWeekyear();
        java.lang.String str41 = property40.getAsShortText();
        int int42 = property40.getMinimumValueOverall();
        int int43 = property40.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property40.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField29, dateTimeFieldType44, 3588);
        org.joda.time.chrono.CopticChronology copticChronology47 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField48 = copticChronology47.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField50 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField48, dateTimeFieldType49);
        boolean boolean51 = delegatedDateTimeField50.isSupported();
        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeZone.getDefault();
        int int55 = dateTimeZone53.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate56 = new org.joda.time.LocalDate((long) 1970, dateTimeZone53);
        org.joda.time.LocalDate localDate58 = localDate56.withYear((int) (short) 1);
        java.util.Locale locale59 = null;
        java.lang.String str60 = delegatedDateTimeField50.getAsText((org.joda.time.ReadablePartial) localDate58, locale59);
        org.joda.time.DurationField durationField61 = null;
        org.joda.time.ReadableInterval readableInterval62 = null;
        org.joda.time.Chronology chronology63 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval62);
        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime(chronology63);
        org.joda.time.DateTime.Property property65 = dateTime64.millisOfSecond();
        org.joda.time.DateTime.Property property66 = dateTime64.millisOfSecond();
        org.joda.time.DateTime dateTime68 = dateTime64.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property69 = dateTime68.weekOfWeekyear();
        java.lang.String str70 = property69.getAsShortText();
        int int71 = property69.getMinimumValueOverall();
        int int72 = property69.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType73 = property69.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField75 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField50, durationField61, dateTimeFieldType73, 52);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField79 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField29, dateTimeFieldType73, 69, 0, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder82 = dateTimeFormatterBuilder24.appendFraction(dateTimeFieldType73, (int) '#', 10);
        try {
            org.joda.time.LocalDate localDate84 = localDate4.withField(dateTimeFieldType73, (-99136));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -99136 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-28800000) + "'", int18 == (-28800000));
        org.junit.Assert.assertNotNull(interval19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(copticChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-9910800000L) + "'", long32 == (-9910800000L));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "2" + "'", str41.equals("2"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 52 + "'", int43 == 52);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(copticChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-28800000) + "'", int55 == (-28800000));
        org.junit.Assert.assertNotNull(localDate58);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "1" + "'", str60.equals("1"));
        org.junit.Assert.assertNotNull(chronology63);
        org.junit.Assert.assertNotNull(property65);
        org.junit.Assert.assertNotNull(property66);
        org.junit.Assert.assertNotNull(dateTime68);
        org.junit.Assert.assertNotNull(property69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "2" + "'", str70.equals("2"));
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 52 + "'", int72 == 52);
        org.junit.Assert.assertNotNull(dateTimeFieldType73);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder82);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        int int5 = delegatedDateTimeField3.getMinimumValue((long) (byte) 0);
        boolean boolean7 = delegatedDateTimeField3.isLeap((long) 0);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField3.getRangeDurationField();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField11 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType9, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) 4);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 115974633600070L, (java.lang.Number) 3688, (java.lang.Number) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        long long5 = dateTimeZone2.adjustOffset(10L, true);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) 1969, dateTimeZone2);
        org.joda.time.DateMidnight dateMidnight7 = localDate6.toDateMidnight();
        int[] intArray9 = new int[] { 3588 };
        try {
            copticChronology0.validate((org.joda.time.ReadablePartial) localDate6, intArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNotNull(dateMidnight7);
        org.junit.Assert.assertNotNull(intArray9);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        boolean boolean4 = delegatedDateTimeField3.isSupported();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
        org.joda.time.LocalDate localDate15 = localDate11.plusYears((-132));
        int int16 = localDate11.getWeekyear();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        long long4 = dateTimeZone1.adjustOffset(10L, true);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) 1969, dateTimeZone1);
        org.joda.time.DateMidnight dateMidnight6 = localDate5.toDateMidnight();
        int int7 = dateMidnight6.getMinuteOfHour();
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9, dateTimeFieldType10);
        int int13 = delegatedDateTimeField11.getMinimumValue((long) (byte) 0);
        int int14 = delegatedDateTimeField11.getMinimumValue();
        int int15 = delegatedDateTimeField11.getMinimumValue();
        org.joda.time.DurationField durationField16 = delegatedDateTimeField11.getRangeDurationField();
        java.lang.String str18 = delegatedDateTimeField11.getAsText((long) 10);
        long long21 = delegatedDateTimeField11.add((long) 2000, 0);
        boolean boolean22 = org.joda.time.field.FieldUtils.equals((java.lang.Object) int7, (java.lang.Object) delegatedDateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "87" + "'", str18.equals("87"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2000L + "'", long21 == 2000L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(100, 12, 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.hourOfHalfday();
        org.joda.time.DurationField durationField3 = copticChronology1.millis();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology1, dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        int int9 = dateTimeZone7.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate10 = org.joda.time.LocalDate.now(dateTimeZone7);
        java.lang.String str11 = dateTimeZone7.getID();
        org.joda.time.Chronology chronology12 = copticChronology1.withZone(dateTimeZone7);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(0L, chronology12);
        int int14 = localDate13.getYear();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-28800000) + "'", int9 == (-28800000));
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "America/Los_Angeles" + "'", str11.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1686 + "'", int14 == 1686);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-28800000));
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter2.printTo(appendable3, (long) (-70));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 1970, dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withPivotYear((java.lang.Integer) 0);
        java.lang.String str8 = localDate4.toString(dateTimeFormatter7);
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(chronology10);
        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
        org.joda.time.DateTime dateTime13 = dateTime11.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = localDate4.toDateTime((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        int int16 = localDate4.indexOf(dateTimeFieldType15);
        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = copticChronology17.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18, dateTimeFieldType19);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField20);
        long long23 = delegatedDateTimeField20.roundHalfFloor((long) (short) 10);
        org.joda.time.ReadableInterval readableInterval24 = null;
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval24);
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(chronology25);
        org.joda.time.DateTime.Property property27 = dateTime26.millisOfSecond();
        org.joda.time.DateTime.Property property28 = dateTime26.millisOfSecond();
        org.joda.time.DateTime dateTime30 = dateTime26.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property31 = dateTime30.weekOfWeekyear();
        java.lang.String str32 = property31.getAsShortText();
        int int33 = property31.getMinimumValueOverall();
        int int34 = property31.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property31.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField20, dateTimeFieldType35, 3588);
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.getDefault();
        int int40 = dateTimeZone38.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate41 = org.joda.time.LocalDate.now(dateTimeZone38);
        java.util.Locale locale43 = null;
        java.lang.String str44 = localDate41.toString("000000Z", locale43);
        org.joda.time.chrono.CopticChronology copticChronology45 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField46 = copticChronology45.weeks();
        org.joda.time.DateTimeZone dateTimeZone47 = copticChronology45.getZone();
        org.joda.time.DateMidnight dateMidnight48 = localDate41.toDateMidnight(dateTimeZone47);
        org.joda.time.ReadablePeriod readablePeriod49 = null;
        org.joda.time.LocalDate localDate50 = localDate41.minus(readablePeriod49);
        org.joda.time.LocalTime localTime51 = null;
        org.joda.time.chrono.GJChronology gJChronology52 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone53 = gJChronology52.getZone();
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeUtils.getZone(dateTimeZone53);
        org.joda.time.chrono.GregorianChronology gregorianChronology55 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone53);
        org.joda.time.DateTime dateTime56 = localDate50.toDateTime(localTime51, dateTimeZone53);
        int int57 = offsetDateTimeField37.getMaximumValue((org.joda.time.ReadablePartial) localDate50);
        boolean boolean58 = localDate4.isEqual((org.joda.time.ReadablePartial) localDate50);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(copticChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-9910800000L) + "'", long23 == (-9910800000L));
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2" + "'", str32.equals("2"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 52 + "'", int34 == 52);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-28800000) + "'", int40 == (-28800000));
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "000000" + "'", str44.equals("000000"));
        org.junit.Assert.assertNotNull(copticChronology45);
        org.junit.Assert.assertNotNull(durationField46);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(dateMidnight48);
        org.junit.Assert.assertNotNull(localDate50);
        org.junit.Assert.assertNotNull(gJChronology52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertNotNull(gregorianChronology55);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 3688 + "'", int57 == 3688);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getMinimumValue((long) (byte) 0);
        boolean boolean8 = delegatedDateTimeField4.isLeap((long) 0);
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField4, 1969);
        int int11 = skipDateTimeField10.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial12 = null;
        int[] intArray16 = new int[] { 'a', 2000 };
        int[] intArray18 = skipDateTimeField10.add(readablePartial12, 0, intArray16, 0);
        try {
            long long21 = skipDateTimeField10.set(0L, "");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for weekyearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-1));
        org.joda.time.Instant instant5 = org.joda.time.Instant.parse("24");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.MutableDateTime mutableDateTime9 = instant5.toMutableDateTime(dateTimeZone6);
        int int12 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime9, "1970-W02-3", 69);
        int int13 = mutableDateTime9.getYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-70) + "'", int12 == (-70));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 9);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        int int5 = delegatedDateTimeField3.getMinimumValue((long) (byte) 0);
        long long8 = delegatedDateTimeField3.add(0L, (long) 10);
        try {
            long long11 = delegatedDateTimeField3.set((long) 3688, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for weekyearOfCentury must be in the range [1,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 315705600000L + "'", long8 == 315705600000L);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 604800000L + "'", long7 == 604800000L);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
        org.joda.time.DateTime dateTime6 = localDate3.toDateTimeAtCurrentTime(dateTimeZone5);
        int int7 = localDate3.getCenturyOfEra();
        org.joda.time.LocalDate localDate9 = localDate3.withEra(0);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.LocalDate localDate11 = localDate3.minus(readablePeriod10);
        java.util.Date date12 = localDate11.toDate();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        int int15 = dateTimeZone13.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate16 = org.joda.time.LocalDate.now(dateTimeZone13);
        org.joda.time.Interval interval17 = localDate11.toInterval(dateTimeZone13);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType19 = localDate11.getFieldType(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-28800000) + "'", int15 == (-28800000));
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(interval17);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.minuteOfDay();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology0.era();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test311");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime4 = dateTime2.withEarlierOffsetAtOverlap();
//        org.joda.time.ReadablePartial readablePartial5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.withFields(readablePartial5);
//        int int7 = dateTime2.getYearOfEra();
//        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.hourOfHalfday();
//        org.joda.time.DurationField durationField10 = copticChronology8.millis();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
//        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology8, dateTimeZone11);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone11.getName((long) 1969, locale15);
//        org.joda.time.DateTime dateTime17 = dateTime2.toDateTime(dateTimeZone11);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        int int21 = dateTimeZone19.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) 1970, dateTimeZone19);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter23.withPivotYear((java.lang.Integer) 0);
//        java.lang.String str26 = localDate22.toString(dateTimeFormatter25);
//        org.joda.time.ReadableInterval readableInterval27 = null;
//        org.joda.time.Chronology chronology28 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval27);
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(chronology28);
//        org.joda.time.DateTime.Property property30 = dateTime29.millisOfSecond();
//        org.joda.time.DateTime dateTime31 = dateTime29.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime32 = localDate22.toDateTime((org.joda.time.ReadableInstant) dateTime29);
//        org.joda.time.LocalDate.Property property33 = localDate22.dayOfMonth();
//        org.joda.time.LocalDate localDate35 = localDate22.withCenturyOfEra(2000);
//        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.getDefault();
//        int int39 = dateTimeZone37.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate((long) 1970, dateTimeZone37);
//        org.joda.time.DateMidnight dateMidnight41 = localDate35.toDateMidnight(dateTimeZone37);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((java.lang.Object) dateTime17, dateTimeZone37);
//        java.lang.String str43 = dateTimeZone37.toString();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
//        org.junit.Assert.assertNotNull(copticChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
//        org.junit.Assert.assertNotNull(zonedChronology13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Pacific Standard Time" + "'", str16.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-28800000) + "'", int21 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1969" + "'", str26.equals("1969"));
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-28800000) + "'", int39 == (-28800000));
//        org.junit.Assert.assertNotNull(dateMidnight41);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "America/Los_Angeles" + "'", str43.equals("America/Los_Angeles"));
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
        java.lang.String str15 = property14.getAsShortText();
        int int16 = property14.getMinimumValueOverall();
        int int17 = property14.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
        boolean boolean25 = delegatedDateTimeField24.isSupported();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
        int int29 = dateTimeZone27.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) 1970, dateTimeZone27);
        org.joda.time.LocalDate localDate32 = localDate30.withYear((int) (short) 1);
        java.util.Locale locale33 = null;
        java.lang.String str34 = delegatedDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDate32, locale33);
        org.joda.time.DurationField durationField35 = null;
        org.joda.time.ReadableInterval readableInterval36 = null;
        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
        org.joda.time.DateTime.Property property39 = dateTime38.millisOfSecond();
        org.joda.time.DateTime.Property property40 = dateTime38.millisOfSecond();
        org.joda.time.DateTime dateTime42 = dateTime38.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
        java.lang.String str44 = property43.getAsShortText();
        int int45 = property43.getMinimumValueOverall();
        int int46 = property43.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField24, durationField35, dateTimeFieldType47, 52);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType47, 69, 0, 0);
        long long56 = delegatedDateTimeField3.set((long) (byte) 0, 4);
        org.joda.time.ReadablePartial readablePartial57 = null;
        java.util.Locale locale58 = null;
        try {
            java.lang.String str59 = delegatedDateTimeField3.getAsText(readablePartial57, locale58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2" + "'", str15.equals("2"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(copticChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "2" + "'", str44.equals("2"));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-2618784000000L) + "'", long56 == (-2618784000000L));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((int) '#', 132, 999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 132 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.minus(readablePeriod3);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 100, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime7 = dateTime5.plus(0L);
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfWeek();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("0070-01-07T15:59:59.100-07:52:58", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"0070-01-07T15:59:59.100-07:52:58/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        try {
            org.joda.time.DateTimeField dateTimeField5 = localDate3.getField(36);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 36");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime5 = property3.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime7 = property3.addToCopy(132);
        org.joda.time.YearMonthDay yearMonthDay8 = dateTime7.toYearMonthDay();
        int int9 = dateTime7.getYearOfCentury();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(yearMonthDay8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 70 + "'", int9 == 70);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number2 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 1.0f, number2, (java.lang.Number) (-99136));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        java.lang.String str8 = property7.getAsShortText();
        int int9 = property7.getMinimumValueOverall();
        int int10 = property7.getMaximumValue();
        org.joda.time.Instant instant12 = new org.joda.time.Instant((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        int int15 = dateTimeZone13.getOffsetFromLocal((long) (short) -1);
        org.joda.time.DateTime dateTime16 = instant12.toDateTime(dateTimeZone13);
        boolean boolean18 = dateTime16.equals((java.lang.Object) 0.0d);
        org.joda.time.DateTime dateTime20 = dateTime16.withYear((int) (short) -1);
        org.joda.time.DateTime dateTime22 = dateTime16.plusMinutes(100);
        int int23 = property7.getDifference((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime dateTime25 = dateTime16.withWeekyear((-1));
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
        java.util.TimeZone timeZone28 = dateTimeZone27.toTimeZone();
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) '#', dateTimeZone27);
        org.joda.time.DateTime dateTime30 = dateTime16.withZone(dateTimeZone27);
        try {
            org.joda.time.DateTime dateTime32 = dateTime16.withMinuteOfHour(3588);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3588 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2" + "'", str8.equals("2"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-28800000) + "'", int15 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-99136) + "'", int23 == (-99136));
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNotNull(dateTime30);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getMinimumValue((long) (byte) 0);
        boolean boolean8 = delegatedDateTimeField4.isLeap((long) 0);
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField4, 1969);
        int int11 = skipDateTimeField10.getMinimumValue();
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(chronology13);
        org.joda.time.Partial partial15 = new org.joda.time.Partial(chronology13);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField17 = gJChronology16.weekyears();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology16.yearOfEra();
        org.joda.time.Partial partial20 = partial15.withChronologyRetainFields((org.joda.time.Chronology) gJChronology16);
        int[] intArray21 = partial20.getValues();
        java.util.Locale locale23 = null;
        java.lang.String str24 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) partial20, 3588, locale23);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(partial20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "3588" + "'", str24.equals("3588"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
        java.lang.String str15 = property14.getAsShortText();
        int int16 = property14.getMinimumValueOverall();
        int int17 = property14.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
        long long23 = offsetDateTimeField20.add(1560639843040L, 0);
        org.joda.time.DurationField durationField24 = offsetDateTimeField20.getDurationField();
        long long27 = offsetDateTimeField20.add((long) 19, 36);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2" + "'", str15.equals("2"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560639843040L + "'", long23 == 1560639843040L);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1136419200019L + "'", long27 == 1136419200019L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 86, number2, (java.lang.Number) 10);
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException4.getSuppressed();
        java.lang.String str6 = illegalFieldValueException4.getIllegalStringValue();
        illegalFieldValueException4.prependMessage("658");
        java.lang.Number number9 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 10 + "'", number9.equals(10));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        boolean boolean4 = delegatedDateTimeField3.isSupported();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
        org.joda.time.DurationField durationField14 = null;
        org.joda.time.ReadableInterval readableInterval15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
        java.lang.String str23 = property22.getAsShortText();
        int int24 = property22.getMinimumValueOverall();
        int int25 = property22.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
        int int29 = dividedDateTimeField28.getMinimumValue();
        org.joda.time.DateTimeField dateTimeField30 = dividedDateTimeField28.getWrappedField();
        java.util.Locale locale32 = null;
        java.lang.String str33 = dividedDateTimeField28.getAsShortText(0, locale32);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2" + "'", str23.equals("2"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "0" + "'", str33.equals("0"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial(chronology1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField5 = gJChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.yearOfEra();
        org.joda.time.Partial partial8 = partial3.withChronologyRetainFields((org.joda.time.Chronology) gJChronology4);
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = copticChronology9.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10, dateTimeFieldType11);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField12);
        long long15 = delegatedDateTimeField12.roundHalfFloor((long) (short) 10);
        org.joda.time.ReadableInterval readableInterval16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(chronology17);
        org.joda.time.DateTime.Property property19 = dateTime18.millisOfSecond();
        org.joda.time.DateTime.Property property20 = dateTime18.millisOfSecond();
        org.joda.time.DateTime dateTime22 = dateTime18.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property23 = dateTime22.weekOfWeekyear();
        java.lang.String str24 = property23.getAsShortText();
        int int25 = property23.getMinimumValueOverall();
        int int26 = property23.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property23.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField12, dateTimeFieldType27, 3588);
        org.joda.time.chrono.CopticChronology copticChronology30 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField31 = copticChronology30.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField33 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField31, dateTimeFieldType32);
        boolean boolean34 = delegatedDateTimeField33.isSupported();
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.getDefault();
        int int38 = dateTimeZone36.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate39 = new org.joda.time.LocalDate((long) 1970, dateTimeZone36);
        org.joda.time.LocalDate localDate41 = localDate39.withYear((int) (short) 1);
        java.util.Locale locale42 = null;
        java.lang.String str43 = delegatedDateTimeField33.getAsText((org.joda.time.ReadablePartial) localDate41, locale42);
        org.joda.time.DurationField durationField44 = null;
        org.joda.time.ReadableInterval readableInterval45 = null;
        org.joda.time.Chronology chronology46 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval45);
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime(chronology46);
        org.joda.time.DateTime.Property property48 = dateTime47.millisOfSecond();
        org.joda.time.DateTime.Property property49 = dateTime47.millisOfSecond();
        org.joda.time.DateTime dateTime51 = dateTime47.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property52 = dateTime51.weekOfWeekyear();
        java.lang.String str53 = property52.getAsShortText();
        int int54 = property52.getMinimumValueOverall();
        int int55 = property52.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType56 = property52.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField58 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField33, durationField44, dateTimeFieldType56, 52);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField12, dateTimeFieldType56, 69, 0, 0);
        try {
            org.joda.time.Partial partial64 = partial8.with(dateTimeFieldType56, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(partial8);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-9910800000L) + "'", long15 == (-9910800000L));
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2" + "'", str24.equals("2"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(copticChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-28800000) + "'", int38 == (-28800000));
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "1" + "'", str43.equals("1"));
        org.junit.Assert.assertNotNull(chronology46);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "2" + "'", str53.equals("2"));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 52 + "'", int55 == 52);
        org.junit.Assert.assertNotNull(dateTimeFieldType56);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, 526546800000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = gJChronology5.getZone();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        boolean boolean8 = copticChronology0.equals((java.lang.Object) dateTimeZone7);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        int int9 = dateTimeZone7.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) 1970, dateTimeZone7);
        java.util.Locale locale11 = null;
        java.lang.String str12 = delegatedDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate10, locale11);
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = copticChronology13.hourOfHalfday();
        org.joda.time.DurationField durationField15 = copticChronology13.millis();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology13, dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        int int21 = dateTimeZone19.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate22 = org.joda.time.LocalDate.now(dateTimeZone19);
        java.lang.String str23 = dateTimeZone19.getID();
        org.joda.time.Chronology chronology24 = copticChronology13.withZone(dateTimeZone19);
        boolean boolean25 = localDate10.equals((java.lang.Object) copticChronology13);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
        int int28 = dateTimeZone26.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate29 = org.joda.time.LocalDate.now(dateTimeZone26);
        org.joda.time.Chronology chronology30 = copticChronology13.withZone(dateTimeZone26);
        org.joda.time.DateTimeField dateTimeField31 = copticChronology13.weekyearOfCentury();
        org.joda.time.field.SkipDateTimeField skipDateTimeField33 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField31, 1);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-28800000) + "'", int9 == (-28800000));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "69" + "'", str12.equals("69"));
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-28800000) + "'", int21 == (-28800000));
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "America/Los_Angeles" + "'", str23.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-28800000) + "'", int28 == (-28800000));
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime4 = dateTime2.withEarlierOffsetAtOverlap();
//        org.joda.time.ReadablePartial readablePartial5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.withFields(readablePartial5);
//        int int7 = dateTime2.getYearOfEra();
//        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.hourOfHalfday();
//        org.joda.time.DurationField durationField10 = copticChronology8.millis();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
//        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology8, dateTimeZone11);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone11.getName((long) 1969, locale15);
//        org.joda.time.DateTime dateTime17 = dateTime2.toDateTime(dateTimeZone11);
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField19 = gJChronology18.weekyears();
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.centuryOfEra();
//        org.joda.time.DurationField durationField21 = gJChronology18.days();
//        org.joda.time.DateTimeZone dateTimeZone22 = gJChronology18.getZone();
//        org.joda.time.DateTime dateTime23 = dateTime2.toDateTime(dateTimeZone22);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone22);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
//        org.junit.Assert.assertNotNull(copticChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
//        org.junit.Assert.assertNotNull(zonedChronology13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Pacific Standard Time" + "'", str16.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(dateTime23);
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        int int5 = delegatedDateTimeField3.getMinimumValue((long) (byte) 0);
        long long8 = delegatedDateTimeField3.add(0L, (long) 10);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        int int11 = dateTimeZone9.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone9);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone14 = gJChronology13.getZone();
        org.joda.time.DateTime dateTime15 = localDate12.toDateTimeAtCurrentTime(dateTimeZone14);
        int int16 = localDate12.getCenturyOfEra();
        org.joda.time.LocalDate localDate18 = localDate12.withEra(0);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.LocalDate localDate20 = localDate12.minus(readablePeriod19);
        java.util.Date date21 = localDate20.toDate();
        org.joda.time.LocalDate localDate22 = org.joda.time.LocalDate.fromDateFields(date21);
        int[] intArray24 = null;
        java.util.Locale locale26 = null;
        try {
            int[] intArray27 = delegatedDateTimeField3.set((org.joda.time.ReadablePartial) localDate22, 0, intArray24, "", locale26);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for weekyearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 315705600000L + "'", long8 == 315705600000L);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 19 + "'", int16 == 19);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(localDate22);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate9, locale10);
        java.util.Locale locale12 = null;
        int int13 = delegatedDateTimeField4.getMaximumShortTextLength(locale12);
        java.util.Locale locale15 = null;
        java.lang.String str16 = delegatedDateTimeField4.getAsText((long) 57600, locale15);
        boolean boolean17 = delegatedDateTimeField4.isSupported();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "69" + "'", str11.equals("69"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "87" + "'", str16.equals("87"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
        org.joda.time.DateTime dateTime16 = dateTime13.plusMillis((-1));
        int int17 = dateTime16.getYearOfCentury();
        int int18 = dateTime16.getSecondOfMinute();
        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField20 = copticChronology19.hourOfHalfday();
        org.joda.time.DurationField durationField21 = copticChronology19.millis();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone23 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone22);
        org.joda.time.chrono.ZonedChronology zonedChronology24 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology19, dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime16.withZone(dateTimeZone22);
        try {
            org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((int) (short) 0, 100, (int) ' ', 24, 0, 4, 7, dateTimeZone22);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 24 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 70 + "'", int17 == 70);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 59 + "'", int18 == 59);
        org.junit.Assert.assertNotNull(copticChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(cachedDateTimeZone23);
        org.junit.Assert.assertNotNull(zonedChronology24);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        java.util.Locale locale5 = null;
        java.lang.String str6 = localDate3.toString("000000Z", locale5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = localDate3.indexOf(dateTimeFieldType7);
        java.lang.String str10 = localDate3.toString("86");
        int int11 = localDate3.getYearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "000000" + "'", str6.equals("000000"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "86" + "'", str10.equals("86"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 70 + "'", int11 == 70);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.hourOfHalfday();
        org.joda.time.DurationField durationField3 = copticChronology1.millis();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology1, dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        int int9 = dateTimeZone7.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate10 = org.joda.time.LocalDate.now(dateTimeZone7);
        java.lang.String str11 = dateTimeZone7.getID();
        org.joda.time.Chronology chronology12 = copticChronology1.withZone(dateTimeZone7);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(0L, chronology12);
        try {
            org.joda.time.LocalDate localDate15 = localDate13.withDayOfYear(999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 999 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-28800000) + "'", int9 == (-28800000));
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "America/Los_Angeles" + "'", str11.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate9, locale10);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.hourOfHalfday();
        org.joda.time.DurationField durationField14 = copticChronology12.millis();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology12, dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        int int20 = dateTimeZone18.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now(dateTimeZone18);
        java.lang.String str22 = dateTimeZone18.getID();
        org.joda.time.Chronology chronology23 = copticChronology12.withZone(dateTimeZone18);
        boolean boolean24 = localDate9.equals((java.lang.Object) copticChronology12);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
        int int27 = dateTimeZone25.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate28 = org.joda.time.LocalDate.now(dateTimeZone25);
        org.joda.time.Chronology chronology29 = copticChronology12.withZone(dateTimeZone25);
        org.joda.time.DurationField durationField30 = copticChronology12.hours();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "69" + "'", str11.equals("69"));
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-28800000) + "'", int20 == (-28800000));
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "America/Los_Angeles" + "'", str22.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-28800000) + "'", int27 == (-28800000));
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(durationField30);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
        java.lang.String str15 = property14.getAsShortText();
        int int16 = property14.getMinimumValueOverall();
        int int17 = property14.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
        long long23 = offsetDateTimeField20.add(1560639843040L, 0);
        int int25 = offsetDateTimeField20.get((long) 2000);
        long long27 = offsetDateTimeField20.roundHalfEven((long) (byte) 0);
        org.joda.time.ReadablePartial readablePartial28 = null;
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.CopticChronology copticChronology31 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = copticChronology31.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField32, dateTimeFieldType33);
        int int36 = delegatedDateTimeField34.getMinimumValue((long) (byte) 0);
        boolean boolean38 = delegatedDateTimeField34.isLeap((long) 0);
        org.joda.time.field.SkipDateTimeField skipDateTimeField40 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology30, (org.joda.time.DateTimeField) delegatedDateTimeField34, 1969);
        int int41 = skipDateTimeField40.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial42 = null;
        int[] intArray46 = new int[] { 'a', 2000 };
        int[] intArray48 = skipDateTimeField40.add(readablePartial42, 0, intArray46, 0);
        try {
            int[] intArray50 = offsetDateTimeField20.addWrapPartial(readablePartial28, 3, intArray48, 365);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2" + "'", str15.equals("2"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560639843040L + "'", long23 == 1560639843040L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 3675 + "'", int25 == 3675);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-9910800000L) + "'", long27 == (-9910800000L));
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(copticChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray48);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (short) 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("000000Z");
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(3);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test345");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.plusMillis((-1));
//        org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfSecond(100);
//        int int12 = dateTime11.getDayOfYear();
//        org.joda.time.ReadableDuration readableDuration13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime11.plus(readableDuration13);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 166 + "'", int12 == 166);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.plusMillis((-1));
//        int int10 = dateTime9.getYearOfCentury();
//        int int11 = dateTime9.getSecondOfMinute();
//        org.joda.time.DateTime dateTime13 = dateTime9.plus((long) (-28800000));
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19 + "'", int10 == 19);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 47 + "'", int11 == 47);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
//        boolean boolean25 = delegatedDateTimeField24.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) 1970, dateTimeZone27);
//        org.joda.time.LocalDate localDate32 = localDate30.withYear((int) (short) 1);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = delegatedDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDate32, locale33);
//        org.joda.time.DurationField durationField35 = null;
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
//        org.joda.time.DateTime.Property property39 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime.Property property40 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime dateTime42 = dateTime38.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
//        java.lang.String str44 = property43.getAsShortText();
//        int int45 = property43.getMinimumValueOverall();
//        int int46 = property43.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField24, durationField35, dateTimeFieldType47, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType47, 69, 0, 0);
//        try {
//            long long56 = offsetDateTimeField53.set((long) 3588, (-70));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -70 for weekOfWeekyear must be in the range [70,0]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "24" + "'", str44.equals("24"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (short) -1);
        org.joda.time.DateTime dateTime5 = instant1.toDateTime(dateTimeZone2);
        int int6 = dateTime5.getWeekyear();
        org.joda.time.Chronology chronology7 = dateTime5.getChronology();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1970 + "'", int6 == 1970);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (short) -1);
        org.joda.time.DateTime dateTime5 = instant1.toDateTime(dateTimeZone2);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTime.Property property7 = dateTime5.era();
        java.util.Locale locale9 = null;
        try {
            java.lang.String str10 = dateTime5.toString("", locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 100, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime7 = dateTime5.plus(0L);
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.DateTime dateTime12 = dateTime9.withFieldAdded(durationFieldType10, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getMinimumValue((long) (byte) 0);
        boolean boolean8 = delegatedDateTimeField4.isLeap((long) 0);
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField4, 1969);
        int int11 = skipDateTimeField10.getMinimumValue();
        int int13 = skipDateTimeField10.get((long) (short) 1);
        int int15 = skipDateTimeField10.get((long) 10);
        int int17 = skipDateTimeField10.get((long) 3588);
        boolean boolean18 = skipDateTimeField10.isSupported();
        int int19 = skipDateTimeField10.getMaximumValue();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 86 + "'", int13 == 86);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86 + "'", int15 == 86);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 86 + "'", int17 == 86);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial(chronology1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField5 = gJChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.yearOfEra();
        org.joda.time.Partial partial8 = partial3.withChronologyRetainFields((org.joda.time.Chronology) gJChronology4);
        int[] intArray9 = partial8.getValues();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology10.getZone();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) partial8, dateTimeZone11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.Partial");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(partial8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial(chronology1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField5 = gJChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.yearOfEra();
        org.joda.time.Partial partial8 = partial3.withChronologyRetainFields((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = partial8.getFieldTypes();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.Partial partial12 = partial8.withPeriodAdded(readablePeriod10, 24);
        try {
            int int14 = partial8.getValue(24);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 24");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(partial8);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
        org.junit.Assert.assertNotNull(partial12);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("772", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("1");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("1");
        java.lang.String str4 = jodaTimePermission3.getActions();
        boolean boolean5 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) '4', (int) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatterBuilder0.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate9, locale10);
        org.joda.time.LocalDate.Property property12 = localDate9.dayOfMonth();
        org.joda.time.LocalDate localDate14 = property12.addToCopy((int) 'a');
        org.joda.time.LocalDate localDate15 = property12.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        int int19 = dateTimeZone17.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((long) 1970, dateTimeZone17);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter21.withPivotYear((java.lang.Integer) 0);
        java.lang.String str24 = localDate20.toString(dateTimeFormatter23);
        org.joda.time.ReadableInterval readableInterval25 = null;
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval25);
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(chronology26);
        org.joda.time.DateTime.Property property28 = dateTime27.millisOfSecond();
        org.joda.time.DateTime dateTime29 = dateTime27.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime30 = localDate20.toDateTime((org.joda.time.ReadableInstant) dateTime27);
        int int31 = localDate20.getYearOfCentury();
        org.joda.time.LocalDate localDate32 = localDate15.withFields((org.joda.time.ReadablePartial) localDate20);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "69" + "'", str11.equals("69"));
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-28800000) + "'", int19 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1969" + "'", str24.equals("1969"));
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 69 + "'", int31 == 69);
        org.junit.Assert.assertNotNull(localDate32);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) ' ');
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.joda.time.Instant instant4 = instant1.withMillis(0L);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant1.plus(readableDuration5);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        boolean boolean4 = delegatedDateTimeField3.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
//        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
//        org.joda.time.DurationField durationField14 = null;
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        java.lang.String str23 = property22.getAsShortText();
//        int int24 = property22.getMinimumValueOverall();
//        int int25 = property22.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
//        int int29 = dividedDateTimeField28.getMinimumValue();
//        int int32 = dividedDateTimeField28.getDifference((long) 1970, 32L);
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.getDefault();
//        int int36 = dateTimeZone34.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate((long) 1970, dateTimeZone34);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = org.joda.time.format.ISODateTimeFormat.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = dateTimeFormatter38.withPivotYear((java.lang.Integer) 0);
//        java.lang.String str41 = localDate37.toString(dateTimeFormatter40);
//        org.joda.time.ReadableInterval readableInterval42 = null;
//        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval42);
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(chronology43);
//        org.joda.time.DateTime.Property property45 = dateTime44.millisOfSecond();
//        org.joda.time.DateTime dateTime46 = dateTime44.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime47 = localDate37.toDateTime((org.joda.time.ReadableInstant) dateTime44);
//        org.joda.time.DateTimeFieldType dateTimeFieldType48 = null;
//        int int49 = localDate37.indexOf(dateTimeFieldType48);
//        java.util.Locale locale51 = null;
//        java.lang.String str52 = dividedDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate37, (int) (short) 1, locale51);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField53 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField28);
//        long long56 = remainderDateTimeField53.addWrapField(1L, 52);
//        try {
//            long long59 = remainderDateTimeField53.set((long) 36, 57600032);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600032 for weekOfWeekyear must be in the range [0,51]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "24" + "'", str23.equals("24"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-28800000) + "'", int36 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTimeFormatter38);
//        org.junit.Assert.assertNotNull(dateTimeFormatter40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1969" + "'", str41.equals("1969"));
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "1" + "'", str52.equals("1"));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1L + "'", long56 == 1L);
//    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getMinimumValue((long) (byte) 0);
        boolean boolean8 = delegatedDateTimeField4.isLeap((long) 0);
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField4, 1969);
        int int11 = skipDateTimeField10.getMinimumValue();
        int int13 = skipDateTimeField10.get((long) (short) 1);
        int int14 = skipDateTimeField10.getMinimumValue();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) skipDateTimeField10, 19, 1970, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19 for weekyearOfCentury must be in the range [1970,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 86 + "'", int13 == 86);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (short) 1, 24, (int) (short) 0, 365, 0, 57600, 19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 12, (-3801600000L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3801599988L) + "'", long2 == (-3801599988L));
    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test365");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        java.lang.String str8 = property7.getAsShortText();
//        int int9 = property7.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime10 = property7.withMaximumValue();
//        org.joda.time.DurationField durationField11 = property7.getDurationField();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "24" + "'", str8.equals("24"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(durationField11);
//    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime6.plusMillis((-1));
        org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfSecond(100);
        org.joda.time.DateTime dateTime12 = dateTime11.toDateTime();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        int int5 = delegatedDateTimeField3.getMinimumValue((long) (byte) 0);
        int int6 = delegatedDateTimeField3.getMinimumValue();
        int int7 = delegatedDateTimeField3.getMinimumValue();
        org.joda.time.DurationField durationField8 = delegatedDateTimeField3.getRangeDurationField();
        java.lang.String str10 = delegatedDateTimeField3.getAsText((long) 10);
        long long13 = delegatedDateTimeField3.add((long) 2000, 0);
        long long16 = delegatedDateTimeField3.add(0L, (-132));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "87" + "'", str10.equals("87"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2000L + "'", long13 == 2000L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-4165258022000L) + "'", long16 == (-4165258022000L));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("0");
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((-132), (int) (byte) -1, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 72 + "'", int3 == 72);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) ' ');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210863995200000L) + "'", long1 == (-210863995200000L));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.parse("3588");
        org.junit.Assert.assertNotNull(localDate1);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.ReadableInstant readableInstant1 = null;
        java.lang.String str2 = dateTimeFormatter0.print(readableInstant1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06" + "'", str2.equals("2019-06"));
    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test373");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        boolean boolean21 = offsetDateTimeField20.isLenient();
//        java.lang.String str22 = offsetDateTimeField20.toString();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str22.equals("DateTimeField[weekOfWeekyear]"));
//    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology3.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType5);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        int int11 = dateTimeZone9.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) 1970, dateTimeZone9);
        java.util.Locale locale13 = null;
        java.lang.String str14 = delegatedDateTimeField7.getAsShortText((org.joda.time.ReadablePartial) localDate12, locale13);
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = copticChronology15.hourOfHalfday();
        org.joda.time.DurationField durationField17 = copticChronology15.millis();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone19 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone18);
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology15, dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        int int23 = dateTimeZone21.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate24 = org.joda.time.LocalDate.now(dateTimeZone21);
        java.lang.String str25 = dateTimeZone21.getID();
        org.joda.time.Chronology chronology26 = copticChronology15.withZone(dateTimeZone21);
        boolean boolean27 = localDate12.equals((java.lang.Object) copticChronology15);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.getDefault();
        int int30 = dateTimeZone28.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate31 = org.joda.time.LocalDate.now(dateTimeZone28);
        org.joda.time.Chronology chronology32 = copticChronology15.withZone(dateTimeZone28);
        java.util.TimeZone timeZone33 = dateTimeZone28.toTimeZone();
        org.joda.time.Chronology chronology34 = gJChronology0.withZone(dateTimeZone28);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "69" + "'", str14.equals("69"));
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(cachedDateTimeZone19);
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-28800000) + "'", int23 == (-28800000));
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "America/Los_Angeles" + "'", str25.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-28800000) + "'", int30 == (-28800000));
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(chronology34);
    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test375");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        long long23 = offsetDateTimeField20.add(1560639843040L, 0);
//        java.lang.String str25 = offsetDateTimeField20.getAsText(526546800000L);
//        java.util.Locale locale28 = null;
//        try {
//            long long29 = offsetDateTimeField20.set((long) (short) 0, "772", locale28);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 772 for weekOfWeekyear must be in the range [3589,3688]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560639843040L + "'", long23 == 1560639843040L);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "3592" + "'", str25.equals("3592"));
//    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(chronology1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField4 = gJChronology3.weekyears();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, dateTimeField5, (int) (byte) -1);
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipUndoDateTimeField7.getAsText((int) (byte) 100, locale9);
        int int12 = skipUndoDateTimeField7.getLeapAmount((long) 15);
        int int14 = skipUndoDateTimeField7.get(9907200019L);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100" + "'", str10.equals("100"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfMinute((int) 'a');
        boolean boolean5 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendLiteral("000000");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendWeekOfWeekyear(1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        org.joda.time.LocalDate.Property property4 = localDate3.centuryOfEra();
        org.joda.time.LocalTime localTime5 = null;
        org.joda.time.DateTime dateTime6 = localDate3.toDateTime(localTime5);
        org.joda.time.DateTime dateTime8 = dateTime6.plusDays(2019);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfCentury(132, 53);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test380");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.plusMillis((-1));
//        org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfSecond(100);
//        java.lang.String str12 = dateTime11.toString();
//        boolean boolean13 = dateTime11.isAfterNow();
//        org.joda.time.DateTime.Property property14 = dateTime11.yearOfEra();
//        org.joda.time.YearMonthDay yearMonthDay15 = dateTime11.toYearMonthDay();
//        org.joda.time.DateTime.Property property16 = dateTime11.yearOfCentury();
//        java.lang.String str17 = property16.getAsShortText();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0019-06-15T16:04:51.100-07:52:58" + "'", str12.equals("0019-06-15T16:04:51.100-07:52:58"));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(yearMonthDay15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "19" + "'", str17.equals("19"));
//    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test381");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Partial partial3 = new org.joda.time.Partial(chronology1);
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField5 = gJChronology4.weekyears();
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.yearOfEra();
//        org.joda.time.Partial partial8 = partial3.withChronologyRetainFields((org.joda.time.Chronology) gJChronology4);
//        java.lang.String str9 = partial8.toString();
//        org.joda.time.ReadableInterval readableInterval10 = null;
//        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
//        int int13 = dateTime12.getDayOfYear();
//        org.joda.time.ReadableDuration readableDuration14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime12.plus(readableDuration14);
//        org.joda.time.DateTime dateTime17 = dateTime12.plusYears(1970);
//        org.joda.time.ReadableInterval readableInterval18 = null;
//        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval18);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(chronology19);
//        org.joda.time.DateTime.Property property21 = dateTime20.millisOfSecond();
//        org.joda.time.DateTime.Property property22 = dateTime20.millisOfSecond();
//        org.joda.time.DateTime dateTime24 = dateTime20.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property25 = dateTime24.weekOfWeekyear();
//        java.lang.String str26 = property25.getAsShortText();
//        int int27 = property25.getMinimumValueOverall();
//        int int28 = property25.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property25.getFieldType();
//        org.joda.time.DateTime.Property property30 = dateTime12.property(dateTimeFieldType29);
//        try {
//            org.joda.time.Partial partial32 = partial8.withField(dateTimeFieldType29, 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekOfWeekyear' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(partial8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[]" + "'", str9.equals("[]"));
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 166 + "'", int13 == 166);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "24" + "'", str26.equals("24"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 52 + "'", int28 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertNotNull(property30);
//    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        int int5 = delegatedDateTimeField3.getMinimumValue((long) (byte) 0);
        long long8 = delegatedDateTimeField3.getDifferenceAsLong(0L, (long) 4);
        int int11 = delegatedDateTimeField3.getDifference((long) 3, (long) ' ');
        boolean boolean12 = delegatedDateTimeField3.isSupported();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate9, locale10);
        org.joda.time.LocalDate.Property property12 = localDate9.dayOfMonth();
        java.lang.String str13 = property12.getAsText();
        org.joda.time.LocalDate localDate14 = property12.roundCeilingCopy();
        org.joda.time.LocalDate localDate16 = property12.setCopy(2);
        org.joda.time.LocalDate localDate18 = property12.setCopy((int) (short) 1);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "69" + "'", str11.equals("69"));
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31" + "'", str13.equals("31"));
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate18);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.year();
        try {
            long long8 = gJChronology0.getDateTimeMillis(72, 0, (-70), (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendMillisOfSecond(1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendHourOfDay(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        try {
            long long5 = gJChronology0.getDateTimeMillis(70, 47, 1686, 86);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 47 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate9, locale10);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.hourOfHalfday();
        org.joda.time.DurationField durationField14 = copticChronology12.millis();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology12, dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        int int20 = dateTimeZone18.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now(dateTimeZone18);
        java.lang.String str22 = dateTimeZone18.getID();
        org.joda.time.Chronology chronology23 = copticChronology12.withZone(dateTimeZone18);
        boolean boolean24 = localDate9.equals((java.lang.Object) copticChronology12);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
        int int27 = dateTimeZone25.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate28 = org.joda.time.LocalDate.now(dateTimeZone25);
        org.joda.time.Chronology chronology29 = copticChronology12.withZone(dateTimeZone25);
        long long31 = dateTimeZone25.convertUTCToLocal(315705600007L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "69" + "'", str11.equals("69"));
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-28800000) + "'", int20 == (-28800000));
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "America/Los_Angeles" + "'", str22.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-28800000) + "'", int27 == (-28800000));
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 315676800007L + "'", long31 == 315676800007L);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        long long3 = dateTimeZone0.adjustOffset(10L, true);
        long long7 = dateTimeZone0.convertLocalToUTC((long) '4', false, (long) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800052L + "'", long7 == 28800052L);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        int int0 = org.joda.time.chrono.CopticChronology.AM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial(chronology1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField5 = gJChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.yearOfEra();
        org.joda.time.Partial partial8 = partial3.withChronologyRetainFields((org.joda.time.Chronology) gJChronology4);
        int[] intArray9 = partial8.getValues();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.Partial partial12 = partial8.withFieldAdded(durationFieldType10, 3675);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(partial8);
        org.junit.Assert.assertNotNull(intArray9);
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test391");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.plusMillis((-1));
//        org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfSecond(100);
//        int int12 = dateTime11.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
//        int int15 = dateTimeZone13.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate16 = org.joda.time.LocalDate.now(dateTimeZone13);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = localDate16.toString("000000Z", locale18);
//        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField21 = copticChronology20.weeks();
//        org.joda.time.DateTimeZone dateTimeZone22 = copticChronology20.getZone();
//        org.joda.time.DateMidnight dateMidnight23 = localDate16.toDateMidnight(dateTimeZone22);
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.LocalDate localDate25 = localDate16.minus(readablePeriod24);
//        org.joda.time.LocalTime localTime26 = null;
//        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone28 = gJChronology27.getZone();
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone28);
//        org.joda.time.DateTime dateTime31 = localDate25.toDateTime(localTime26, dateTimeZone28);
//        org.joda.time.DateTime dateTime32 = dateTime11.withZone(dateTimeZone28);
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = null;
//        try {
//            int int34 = dateTime11.get(dateTimeFieldType33);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 166 + "'", int12 == 166);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-28800000) + "'", int15 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "000000" + "'", str19.equals("000000"));
//        org.junit.Assert.assertNotNull(copticChronology20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(dateMidnight23);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(gJChronology27);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime32);
//    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        java.util.Locale locale5 = null;
        java.lang.String str6 = localDate3.toString("000000Z", locale5);
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField8 = copticChronology7.weeks();
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology7.getZone();
        org.joda.time.DateMidnight dateMidnight10 = localDate3.toDateMidnight(dateTimeZone9);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology11.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "000000" + "'", str6.equals("000000"));
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        long long4 = dateTimeZone1.adjustOffset(10L, true);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) 1969, dateTimeZone1);
        org.joda.time.DateMidnight dateMidnight6 = localDate5.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        long long11 = dateTimeZone8.adjustOffset(10L, true);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) 1969, dateTimeZone8);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) dateMidnight6, dateTimeZone8);
        int int14 = dateTime13.getDayOfYear();
        org.joda.time.DateTime.Property property15 = dateTime13.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 365 + "'", int14 == 365);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
        org.joda.time.DateTime dateTime6 = localDate3.toDateTimeAtCurrentTime(dateTimeZone5);
        int int7 = localDate3.getCenturyOfEra();
        org.joda.time.LocalDate localDate9 = localDate3.withEra(0);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.LocalDate localDate11 = localDate3.minus(readablePeriod10);
        java.util.Date date12 = localDate11.toDate();
        org.joda.time.LocalDate localDate13 = org.joda.time.LocalDate.fromDateFields(date12);
        org.joda.time.LocalDate localDate15 = localDate13.withYearOfEra((int) ' ');
        org.joda.time.LocalDate.Property property16 = localDate13.weekyear();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20 + "'", int7 == 20);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.lang.Appendable appendable1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate9, locale10);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.hourOfHalfday();
        org.joda.time.DurationField durationField14 = copticChronology12.millis();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology12, dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        int int20 = dateTimeZone18.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now(dateTimeZone18);
        java.lang.String str22 = dateTimeZone18.getID();
        org.joda.time.Chronology chronology23 = copticChronology12.withZone(dateTimeZone18);
        boolean boolean24 = localDate9.equals((java.lang.Object) copticChronology12);
        try {
            org.joda.time.Instant instant25 = new org.joda.time.Instant((java.lang.Object) boolean24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Boolean");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "69" + "'", str11.equals("69"));
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-28800000) + "'", int20 == (-28800000));
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "America/Los_Angeles" + "'", str22.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test397");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.hourOfHalfday();
//        org.joda.time.DurationField durationField2 = copticChronology0.millis();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
//        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate9 = org.joda.time.LocalDate.now(dateTimeZone6);
//        java.lang.String str10 = dateTimeZone6.getID();
//        org.joda.time.Chronology chronology11 = copticChronology0.withZone(dateTimeZone6);
//        org.joda.time.DurationField durationField12 = copticChronology0.years();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
//        int int15 = dateTimeZone13.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate16 = org.joda.time.LocalDate.now(dateTimeZone13);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = localDate16.toString("000000Z", locale18);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
//        int int21 = localDate16.indexOf(dateTimeFieldType20);
//        org.joda.time.DateTime dateTime22 = localDate16.toDateTimeAtMidnight();
//        org.joda.time.ReadableInterval readableInterval23 = null;
//        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval23);
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(chronology24);
//        org.joda.time.DateTime.Property property26 = dateTime25.millisOfSecond();
//        org.joda.time.DateTime.Property property27 = dateTime25.millisOfSecond();
//        org.joda.time.DateTime dateTime29 = dateTime25.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property30 = dateTime29.weekOfWeekyear();
//        java.lang.String str31 = property30.getAsShortText();
//        int int32 = property30.getMinimumValueOverall();
//        int int33 = property30.getMaximumValue();
//        org.joda.time.Instant instant35 = new org.joda.time.Instant((long) ' ');
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.getDefault();
//        int int38 = dateTimeZone36.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.DateTime dateTime39 = instant35.toDateTime(dateTimeZone36);
//        boolean boolean41 = dateTime39.equals((java.lang.Object) 0.0d);
//        org.joda.time.DateTime dateTime43 = dateTime39.withYear((int) (short) -1);
//        org.joda.time.DateTime dateTime45 = dateTime39.plusMinutes(100);
//        int int46 = property30.getDifference((org.joda.time.ReadableInstant) dateTime39);
//        org.joda.time.DateTime dateTime48 = dateTime39.withWeekyear((-1));
//        try {
//            org.joda.time.chrono.LimitChronology limitChronology49 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, (org.joda.time.ReadableDateTime) dateTime22, (org.joda.time.ReadableDateTime) dateTime48);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertNotNull(zonedChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "America/Los_Angeles" + "'", str10.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-28800000) + "'", int15 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "000000" + "'", str19.equals("000000"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "24" + "'", str31.equals("24"));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 52 + "'", int33 == 52);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-28800000) + "'", int38 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-101774) + "'", int46 == (-101774));
//        org.junit.Assert.assertNotNull(dateTime48);
//    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("weekyearOfCentury");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"weekyearOfCentury\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.secondOfDay();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology5);
        org.joda.time.DateTime.Property property7 = dateTime6.millisOfSecond();
        org.joda.time.DateTime dateTime8 = dateTime6.withEarlierOffsetAtOverlap();
        org.joda.time.ReadablePartial readablePartial9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.withFields(readablePartial9);
        boolean boolean11 = copticChronology0.equals((java.lang.Object) dateTime6);
        org.joda.time.DateTimeField dateTimeField12 = copticChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField13 = copticChronology0.clockhourOfHalfday();
        try {
            long long18 = copticChronology0.getDateTimeMillis((int) (byte) 0, (int) (short) 100, (int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test400");
//        org.joda.time.ReadableInterval readableInterval5 = null;
//        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.DateTime dateTime9 = dateTime7.withEarlierOffsetAtOverlap();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime7.withFields(readablePartial10);
//        int int12 = dateTime7.getYearOfEra();
//        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = copticChronology13.hourOfHalfday();
//        org.joda.time.DurationField durationField15 = copticChronology13.millis();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
//        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology13, dateTimeZone16);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone16.getName((long) 1969, locale20);
//        org.joda.time.DateTime dateTime22 = dateTime7.toDateTime(dateTimeZone16);
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
//        int int26 = dateTimeZone24.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate((long) 1970, dateTimeZone24);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter28.withPivotYear((java.lang.Integer) 0);
//        java.lang.String str31 = localDate27.toString(dateTimeFormatter30);
//        org.joda.time.ReadableInterval readableInterval32 = null;
//        org.joda.time.Chronology chronology33 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval32);
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(chronology33);
//        org.joda.time.DateTime.Property property35 = dateTime34.millisOfSecond();
//        org.joda.time.DateTime dateTime36 = dateTime34.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime37 = localDate27.toDateTime((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.LocalDate.Property property38 = localDate27.dayOfMonth();
//        org.joda.time.LocalDate localDate40 = localDate27.withCenturyOfEra(2000);
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
//        int int44 = dateTimeZone42.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate45 = new org.joda.time.LocalDate((long) 1970, dateTimeZone42);
//        org.joda.time.DateMidnight dateMidnight46 = localDate40.toDateMidnight(dateTimeZone42);
//        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((java.lang.Object) dateTime22, dateTimeZone42);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone48 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone42);
//        int int50 = cachedDateTimeZone48.getStandardOffset((long) 132);
//        try {
//            org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((int) 'a', (-1), (int) (byte) 0, 52, 53, (org.joda.time.DateTimeZone) cachedDateTimeZone48);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertNotNull(copticChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
//        org.junit.Assert.assertNotNull(zonedChronology18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-28800000) + "'", int26 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTimeFormatter28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1969" + "'", str31.equals("1969"));
//        org.junit.Assert.assertNotNull(chronology33);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(localDate40);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-28800000) + "'", int44 == (-28800000));
//        org.junit.Assert.assertNotNull(dateMidnight46);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone48);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-28800000) + "'", int50 == (-28800000));
//    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.year();
        try {
            long long8 = gJChronology0.getDateTimeMillis(57600032, 3589, 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3589 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test402");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        java.lang.String str8 = property7.getAsShortText();
//        int int9 = property7.getMinimumValueOverall();
//        int int10 = property7.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property7.getFieldType();
//        org.joda.time.Instant instant13 = new org.joda.time.Instant((long) ' ');
//        org.joda.time.MutableDateTime mutableDateTime14 = instant13.toMutableDateTimeISO();
//        int int15 = mutableDateTime14.getDayOfWeek();
//        int int16 = property7.getDifference((org.joda.time.ReadableInstant) mutableDateTime14);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "24" + "'", str8.equals("24"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-101774) + "'", int16 == (-101774));
//    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        java.util.Locale locale5 = null;
        java.lang.String str6 = localDate3.toString("000000Z", locale5);
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField8 = copticChronology7.weeks();
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology7.getZone();
        org.joda.time.DateMidnight dateMidnight10 = localDate3.toDateMidnight(dateTimeZone9);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
        java.lang.String str12 = buddhistChronology11.toString();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        try {
            int[] intArray15 = buddhistChronology11.get(readablePeriod13, (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "000000" + "'", str6.equals("000000"));
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str12.equals("BuddhistChronology[America/Los_Angeles]"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 1970, dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withPivotYear((java.lang.Integer) 0);
        java.lang.String str8 = localDate4.toString(dateTimeFormatter7);
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(chronology10);
        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
        org.joda.time.DateTime dateTime13 = dateTime11.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = localDate4.toDateTime((org.joda.time.ReadableInstant) dateTime11);
        boolean boolean15 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate4);
        try {
            int int17 = localDate4.getValue(24);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 24");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(0, ' ', (int) (short) -1, (int) (short) 0, 0, true, (int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeZoneBuilder0.toDateTimeZone("weekyearOfCentury", true);
        java.io.DataOutput dataOutput13 = null;
        try {
            dateTimeZoneBuilder0.writeTo("millisOfSecond", dataOutput13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        long long4 = dateTimeZone1.adjustOffset(10L, true);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) 1969, dateTimeZone1);
//        org.joda.time.DateMidnight dateMidnight6 = localDate5.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        long long11 = dateTimeZone8.adjustOffset(10L, true);
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) 1969, dateTimeZone8);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) dateMidnight6, dateTimeZone8);
//        java.lang.String str15 = dateTimeZone8.getShortName(604800000L);
//        long long18 = dateTimeZone8.convertLocalToUTC((long) 2, true);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
//        org.junit.Assert.assertNotNull(dateMidnight6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PST" + "'", str15.equals("PST"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800002L + "'", long18 == 28800002L);
//    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test407");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        boolean boolean4 = delegatedDateTimeField3.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
//        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
//        org.joda.time.DurationField durationField14 = null;
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        java.lang.String str23 = property22.getAsShortText();
//        int int24 = property22.getMinimumValueOverall();
//        int int25 = property22.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
//        long long31 = dividedDateTimeField28.add((long) 2, 12);
//        int int32 = dividedDateTimeField28.getMinimumValue();
//        java.util.Locale locale35 = null;
//        try {
//            long long36 = dividedDateTimeField28.set(0L, "hi!", locale35);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for weekOfWeekyear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "24" + "'", str23.equals("24"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 19692288000002L + "'", long31 == 19692288000002L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test408");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        boolean boolean4 = delegatedDateTimeField3.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
//        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
//        org.joda.time.DurationField durationField14 = null;
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        java.lang.String str23 = property22.getAsShortText();
//        int int24 = property22.getMinimumValueOverall();
//        int int25 = property22.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
//        java.util.Locale locale29 = null;
//        int int30 = dividedDateTimeField28.getMaximumShortTextLength(locale29);
//        long long33 = dividedDateTimeField28.getDifferenceAsLong(28800035L, (long) 9);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "24" + "'", str23.equals("24"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
//    }

//    @Test
//    public void test409() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test409");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
//        org.joda.time.DateTime dateTime6 = localDate3.toDateTimeAtCurrentTime(dateTimeZone5);
//        boolean boolean7 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate3);
//        org.joda.time.ReadableInterval readableInterval8 = null;
//        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(chronology9);
//        org.joda.time.DateTime.Property property11 = dateTime10.millisOfSecond();
//        org.joda.time.DateTime.Property property12 = dateTime10.millisOfSecond();
//        org.joda.time.DateTime dateTime14 = dateTime10.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekOfWeekyear();
//        java.lang.String str16 = property15.getAsShortText();
//        int int17 = property15.getMinimumValueOverall();
//        int int18 = property15.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property15.getFieldType();
//        org.joda.time.LocalDate.Property property20 = localDate3.property(dateTimeFieldType19);
//        org.joda.time.LocalDate localDate22 = localDate3.withYearOfCentury(1);
//        int int23 = localDate3.getCenturyOfEra();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "24" + "'", str16.equals("24"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 52 + "'", int18 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 20 + "'", int23 == 20);
//    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (short) -1);
        org.joda.time.DateTime dateTime5 = instant1.toDateTime(dateTimeZone2);
        boolean boolean7 = dateTime5.equals((java.lang.Object) 0.0d);
        org.joda.time.DateTime dateTime9 = dateTime5.withYear((int) (short) -1);
        org.joda.time.DateTime dateTime11 = dateTime5.plusMinutes(100);
        try {
            org.joda.time.DateTime dateTime13 = dateTime5.withHourOfDay(72);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 72 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 1970, dateTimeZone1);
        org.joda.time.LocalDate localDate6 = localDate4.withYear((int) (short) 1);
        org.joda.time.DateTime dateTime7 = localDate4.toDateTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = dateTime6.withZone(dateTimeZone7);
        org.joda.time.Instant instant9 = dateTime6.toInstant();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Instant instant11 = instant9.minus(readableDuration10);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(instant11);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) ' ', (int) '#', 49, 2, 53);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test415() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test415");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
//        boolean boolean25 = delegatedDateTimeField24.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) 1970, dateTimeZone27);
//        org.joda.time.LocalDate localDate32 = localDate30.withYear((int) (short) 1);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = delegatedDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDate32, locale33);
//        org.joda.time.DurationField durationField35 = null;
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
//        org.joda.time.DateTime.Property property39 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime.Property property40 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime dateTime42 = dateTime38.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
//        java.lang.String str44 = property43.getAsShortText();
//        int int45 = property43.getMinimumValueOverall();
//        int int46 = property43.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField24, durationField35, dateTimeFieldType47, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType47, 69, 0, 0);
//        org.joda.time.ReadableInterval readableInterval54 = null;
//        org.joda.time.Chronology chronology55 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval54);
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(chronology55);
//        org.joda.time.DateTime.Property property57 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime.Property property58 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime dateTime60 = dateTime56.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property61 = dateTime60.weekOfWeekyear();
//        java.lang.String str62 = property61.getAsShortText();
//        int int63 = property61.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime64 = property61.withMaximumValue();
//        org.joda.time.DurationField durationField65 = property61.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField66 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType47, durationField65);
//        java.lang.String str67 = unsupportedDateTimeField66.toString();
//        try {
//            long long69 = unsupportedDateTimeField66.roundCeiling((long) 2);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "24" + "'", str44.equals("24"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(chronology55);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "24" + "'", str62.equals("24"));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(durationField65);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField66);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "UnsupportedDateTimeField" + "'", str67.equals("UnsupportedDateTimeField"));
//    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        java.util.Locale locale5 = null;
        java.lang.String str6 = localDate3.toString("000000Z", locale5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        int int9 = dateTimeZone7.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate10 = org.joda.time.LocalDate.now(dateTimeZone7);
        java.util.Locale locale12 = null;
        java.lang.String str13 = localDate10.toString("000000Z", locale12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        int int15 = localDate10.indexOf(dateTimeFieldType14);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        long long20 = dateTimeZone17.adjustOffset(10L, true);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) 1969, dateTimeZone17);
        org.joda.time.LocalDate localDate22 = localDate10.withFields((org.joda.time.ReadablePartial) localDate21);
        boolean boolean23 = localDate3.isBefore((org.joda.time.ReadablePartial) localDate10);
        int[] intArray24 = localDate3.getValues();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "000000" + "'", str6.equals("000000"));
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-28800000) + "'", int9 == (-28800000));
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "000000" + "'", str13.equals("000000"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        try {
            long long11 = gregorianChronology3.getDateTimeMillis(15, (-28800000), (-101774), (-70), (int) (byte) 100, (int) (byte) 0, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -70 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMinuteOfDay(86);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendTimeZoneOffset("millisOfSecond", "GJChronology[America/Los_Angeles]", true, 86, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendWeekyear(15, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendPattern("772");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        int int5 = delegatedDateTimeField3.getMinimumValue((long) (byte) 0);
        int int6 = delegatedDateTimeField3.getMinimumValue();
        int int7 = delegatedDateTimeField3.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        int int10 = dateTimeZone8.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now(dateTimeZone8);
        java.util.Locale locale13 = null;
        java.lang.String str14 = localDate11.toString("000000Z", locale13);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        int int16 = localDate11.indexOf(dateTimeFieldType15);
        java.util.Locale locale17 = null;
        java.lang.String str18 = delegatedDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate11, locale17);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "000000" + "'", str14.equals("000000"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "19" + "'", str18.equals("19"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        java.lang.String str2 = dateTimeZone1.toString();
        java.util.TimeZone timeZone3 = dateTimeZone1.toTimeZone();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(timeZone3);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(chronology1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField4 = gJChronology3.weekyears();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, dateTimeField5, (int) (byte) -1);
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipUndoDateTimeField7.getAsText((int) (byte) 100, locale9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        long long15 = dateTimeZone12.adjustOffset(10L, true);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) 1969, dateTimeZone12);
        org.joda.time.DateMidnight dateMidnight17 = localDate16.toDateMidnight();
        org.joda.time.LocalDate.Property property18 = localDate16.monthOfYear();
        org.joda.time.LocalDate localDate19 = property18.roundHalfFloorCopy();
        org.joda.time.LocalDate localDate21 = localDate19.plusWeeks(7);
        int int22 = localDate19.getMonthOfYear();
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = copticChronology25.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField26, dateTimeFieldType27);
        int int30 = delegatedDateTimeField28.getMinimumValue((long) (byte) 0);
        boolean boolean32 = delegatedDateTimeField28.isLeap((long) 0);
        org.joda.time.field.SkipDateTimeField skipDateTimeField34 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology24, (org.joda.time.DateTimeField) delegatedDateTimeField28, 1969);
        int int35 = skipDateTimeField34.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial36 = null;
        int[] intArray40 = new int[] { 'a', 2000 };
        int[] intArray42 = skipDateTimeField34.add(readablePartial36, 0, intArray40, 0);
        try {
            int[] intArray44 = skipUndoDateTimeField7.set((org.joda.time.ReadablePartial) localDate19, (-132), intArray40, 47);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100" + "'", str10.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray42);
    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
//        boolean boolean25 = delegatedDateTimeField24.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) 1970, dateTimeZone27);
//        org.joda.time.LocalDate localDate32 = localDate30.withYear((int) (short) 1);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = delegatedDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDate32, locale33);
//        org.joda.time.DurationField durationField35 = null;
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
//        org.joda.time.DateTime.Property property39 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime.Property property40 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime dateTime42 = dateTime38.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
//        java.lang.String str44 = property43.getAsShortText();
//        int int45 = property43.getMinimumValueOverall();
//        int int46 = property43.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField24, durationField35, dateTimeFieldType47, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType47, 69, 0, 0);
//        org.joda.time.ReadableInterval readableInterval54 = null;
//        org.joda.time.Chronology chronology55 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval54);
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(chronology55);
//        org.joda.time.DateTime.Property property57 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime.Property property58 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime dateTime60 = dateTime56.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property61 = dateTime60.weekOfWeekyear();
//        java.lang.String str62 = property61.getAsShortText();
//        int int63 = property61.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime64 = property61.withMaximumValue();
//        org.joda.time.DurationField durationField65 = property61.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField66 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType47, durationField65);
//        java.util.Locale locale68 = null;
//        try {
//            java.lang.String str69 = unsupportedDateTimeField66.getAsText((int) (byte) -1, locale68);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "24" + "'", str44.equals("24"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(chronology55);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "24" + "'", str62.equals("24"));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(durationField65);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField66);
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getMinimumValue((long) (byte) 0);
        boolean boolean8 = delegatedDateTimeField4.isLeap((long) 0);
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField4, 1969);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        long long15 = dateTimeZone12.adjustOffset(10L, true);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) 1969, dateTimeZone12);
        org.joda.time.DateMidnight dateMidnight17 = localDate16.toDateMidnight();
        java.util.Locale locale19 = null;
        java.lang.String str20 = delegatedDateTimeField4.getAsText((org.joda.time.ReadablePartial) localDate16, 100, locale19);
        int int21 = localDate16.getDayOfYear();
        java.lang.Object obj22 = null;
        boolean boolean23 = localDate16.equals(obj22);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 365 + "'", int21 == 365);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((java.lang.Integer) 0);
        try {
            org.joda.time.LocalDate localDate4 = org.joda.time.LocalDate.parse("millisOfSecond", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"millisOfSecond\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.weekyearOfCentury();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField2, 999);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getMinimumValue((long) (byte) 0);
        boolean boolean8 = delegatedDateTimeField4.isLeap((long) 0);
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField4, 1969);
        int int12 = skipDateTimeField10.getLeapAmount(0L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

//    @Test
//    public void test431() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test431");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
//        boolean boolean25 = delegatedDateTimeField24.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) 1970, dateTimeZone27);
//        org.joda.time.LocalDate localDate32 = localDate30.withYear((int) (short) 1);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = delegatedDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDate32, locale33);
//        org.joda.time.DurationField durationField35 = null;
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
//        org.joda.time.DateTime.Property property39 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime.Property property40 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime dateTime42 = dateTime38.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
//        java.lang.String str44 = property43.getAsShortText();
//        int int45 = property43.getMinimumValueOverall();
//        int int46 = property43.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField24, durationField35, dateTimeFieldType47, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType47, 69, 0, 0);
//        org.joda.time.ReadableInterval readableInterval54 = null;
//        org.joda.time.Chronology chronology55 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval54);
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(chronology55);
//        org.joda.time.DateTime.Property property57 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime.Property property58 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime dateTime60 = dateTime56.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property61 = dateTime60.weekOfWeekyear();
//        java.lang.String str62 = property61.getAsShortText();
//        int int63 = property61.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime64 = property61.withMaximumValue();
//        org.joda.time.DurationField durationField65 = property61.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField66 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType47, durationField65);
//        org.joda.time.DateTimeZone dateTimeZone68 = org.joda.time.DateTimeZone.getDefault();
//        int int70 = dateTimeZone68.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate71 = new org.joda.time.LocalDate((long) 1970, dateTimeZone68);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter72 = org.joda.time.format.ISODateTimeFormat.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter74 = dateTimeFormatter72.withPivotYear((java.lang.Integer) 0);
//        java.lang.String str75 = localDate71.toString(dateTimeFormatter74);
//        org.joda.time.DateTimeZone dateTimeZone77 = org.joda.time.DateTimeZone.getDefault();
//        int int79 = dateTimeZone77.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate80 = new org.joda.time.LocalDate((long) 1970, dateTimeZone77);
//        int int81 = localDate80.getYear();
//        java.lang.String str82 = dateTimeFormatter74.print((org.joda.time.ReadablePartial) localDate80);
//        int[] intArray89 = new int[] { (short) 100, 57600032, (-70), 3588, 10 };
//        java.util.Locale locale91 = null;
//        try {
//            int[] intArray92 = unsupportedDateTimeField66.set((org.joda.time.ReadablePartial) localDate80, (int) (byte) 1, intArray89, "Property[millisOfSecond]", locale91);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "24" + "'", str44.equals("24"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(chronology55);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "24" + "'", str62.equals("24"));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(durationField65);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField66);
//        org.junit.Assert.assertNotNull(dateTimeZone68);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-28800000) + "'", int70 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTimeFormatter72);
//        org.junit.Assert.assertNotNull(dateTimeFormatter74);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "1969" + "'", str75.equals("1969"));
//        org.junit.Assert.assertNotNull(dateTimeZone77);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-28800000) + "'", int79 == (-28800000));
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1969 + "'", int81 == 1969);
//        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "1969" + "'", str82.equals("1969"));
//        org.junit.Assert.assertNotNull(intArray89);
//    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate9, locale10);
        org.joda.time.LocalDate.Property property12 = localDate9.dayOfMonth();
        org.joda.time.LocalDate localDate14 = property12.addToCopy((int) 'a');
        org.joda.time.LocalDate localDate15 = property12.roundCeilingCopy();
        org.joda.time.LocalDate localDate16 = property12.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "69" + "'", str11.equals("69"));
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate16);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = property7.addToCopy((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = property7.withMinimumValue();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 1970, (-536457598000L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -1056821468060000");
        } catch (java.lang.ArithmeticException e) {
        }
    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        boolean boolean21 = offsetDateTimeField20.isLenient();
//        boolean boolean23 = offsetDateTimeField20.isLeap((long) 57600032);
//        int int24 = offsetDateTimeField20.getOffset();
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = offsetDateTimeField20.getAsShortText(1969L, locale26);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3588 + "'", int24 == 3588);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "3675" + "'", str27.equals("3675"));
//    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime5 = property3.addWrapFieldToCopy(0);
        java.util.Locale locale7 = null;
        org.joda.time.DateTime dateTime8 = property3.setCopy("772", locale7);
        int int9 = property3.getMaximumValueOverall();
        try {
            org.joda.time.DateTime dateTime11 = property3.setCopy("GJChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GJChronology[America/Los_Angeles]\" for millisOfSecond is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 999 + "'", int9 == 999);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4', true);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology6);
        java.lang.String str8 = iSOChronology6.toString();
        try {
            org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((java.lang.Object) '4', (org.joda.time.Chronology) iSOChronology6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: java.lang.Character");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str8.equals("ISOChronology[America/Los_Angeles]"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.String str1 = julianChronology0.toString();
        try {
            long long6 = julianChronology0.getDateTimeMillis((int) '#', 7, 0, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str1.equals("JulianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("772");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"772\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test442");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        long long4 = dateTimeZone1.adjustOffset(10L, true);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) 1969, dateTimeZone1);
//        org.joda.time.DateMidnight dateMidnight6 = localDate5.toDateMidnight();
//        org.joda.time.LocalDate.Property property7 = localDate5.monthOfYear();
//        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9, dateTimeFieldType10);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField11);
//        long long14 = delegatedDateTimeField11.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        java.lang.String str23 = property22.getAsShortText();
//        int int24 = property22.getMinimumValueOverall();
//        int int25 = property22.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField11, dateTimeFieldType26, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField30 = copticChronology29.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField30, dateTimeFieldType31);
//        boolean boolean33 = delegatedDateTimeField32.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.getDefault();
//        int int37 = dateTimeZone35.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate((long) 1970, dateTimeZone35);
//        org.joda.time.LocalDate localDate40 = localDate38.withYear((int) (short) 1);
//        java.util.Locale locale41 = null;
//        java.lang.String str42 = delegatedDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate40, locale41);
//        org.joda.time.DurationField durationField43 = null;
//        org.joda.time.ReadableInterval readableInterval44 = null;
//        org.joda.time.Chronology chronology45 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval44);
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime(chronology45);
//        org.joda.time.DateTime.Property property47 = dateTime46.millisOfSecond();
//        org.joda.time.DateTime.Property property48 = dateTime46.millisOfSecond();
//        org.joda.time.DateTime dateTime50 = dateTime46.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property51 = dateTime50.weekOfWeekyear();
//        java.lang.String str52 = property51.getAsShortText();
//        int int53 = property51.getMinimumValueOverall();
//        int int54 = property51.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType55 = property51.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField57 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField32, durationField43, dateTimeFieldType55, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField61 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField11, dateTimeFieldType55, 69, 0, 0);
//        boolean boolean62 = localDate5.isSupported(dateTimeFieldType55);
//        java.lang.String str64 = localDate5.toString("87");
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
//        org.junit.Assert.assertNotNull(dateMidnight6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(copticChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-9910800000L) + "'", long14 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "24" + "'", str23.equals("24"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertNotNull(copticChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-28800000) + "'", int37 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate40);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "1" + "'", str42.equals("1"));
//        org.junit.Assert.assertNotNull(chronology45);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "24" + "'", str52.equals("24"));
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 52 + "'", int54 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType55);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "87" + "'", str64.equals("87"));
//    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.secondOfDay();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology5);
        org.joda.time.DateTime.Property property7 = dateTime6.millisOfSecond();
        org.joda.time.DateTime dateTime8 = dateTime6.withEarlierOffsetAtOverlap();
        org.joda.time.ReadablePartial readablePartial9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.withFields(readablePartial9);
        boolean boolean11 = copticChronology0.equals((java.lang.Object) dateTime6);
        org.joda.time.DateTime dateTime13 = dateTime6.withYear((int) (byte) 100);
        org.joda.time.DateTime dateTime14 = dateTime6.toDateTimeISO();
        org.joda.time.DateTime dateTime16 = dateTime6.plusYears((int) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        try {
            java.lang.String str18 = dateTime6.toString(dateTimeFormatter17);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        java.util.Locale locale5 = null;
        java.lang.String str6 = localDate3.toString("000000Z", locale5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = localDate3.indexOf(dateTimeFieldType7);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        long long13 = dateTimeZone10.adjustOffset(10L, true);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) 1969, dateTimeZone10);
        org.joda.time.LocalDate localDate15 = localDate3.withFields((org.joda.time.ReadablePartial) localDate14);
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = copticChronology16.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType18);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        int int24 = dateTimeZone22.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) 1970, dateTimeZone22);
        java.util.Locale locale26 = null;
        java.lang.String str27 = delegatedDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) localDate25, locale26);
        org.joda.time.LocalDate.Property property28 = localDate25.dayOfMonth();
        org.joda.time.LocalDate localDate30 = property28.addToCopy((int) 'a');
        org.joda.time.chrono.CopticChronology copticChronology31 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = copticChronology31.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField32, dateTimeFieldType33);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField35 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField32);
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.getDefault();
        int int39 = dateTimeZone37.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate((long) 1970, dateTimeZone37);
        java.util.Locale locale41 = null;
        java.lang.String str42 = delegatedDateTimeField35.getAsShortText((org.joda.time.ReadablePartial) localDate40, locale41);
        org.joda.time.LocalDate.Property property43 = localDate40.dayOfMonth();
        org.joda.time.LocalDate localDate45 = property43.addToCopy((int) 'a');
        boolean boolean46 = localDate30.isBefore((org.joda.time.ReadablePartial) localDate45);
        java.util.Locale locale48 = null;
        java.lang.String str49 = localDate45.toString("[]", locale48);
        boolean boolean50 = localDate15.equals((java.lang.Object) locale48);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "000000" + "'", str6.equals("000000"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "69" + "'", str27.equals("69"));
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertNotNull(copticChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-28800000) + "'", int39 == (-28800000));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "69" + "'", str42.equals("69"));
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(localDate45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "[]" + "'", str49.equals("[]"));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (short) -1);
        org.joda.time.DateTime dateTime5 = instant1.toDateTime(dateTimeZone2);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTime.Property property7 = dateTime5.dayOfYear();
        org.joda.time.Instant instant8 = dateTime5.toInstant();
        boolean boolean10 = dateTime5.isEqual(1136419200019L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        java.util.Locale locale5 = null;
        java.lang.String str6 = localDate3.toString("000000Z", locale5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = localDate3.indexOf(dateTimeFieldType7);
        org.joda.time.DateTime dateTime9 = localDate3.toDateTimeAtMidnight();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        long long14 = dateTimeZone11.adjustOffset(10L, true);
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) 1969, dateTimeZone11);
        org.joda.time.DateMidnight dateMidnight16 = localDate15.toDateMidnight();
        org.joda.time.LocalDate.Property property17 = localDate15.monthOfYear();
        org.joda.time.LocalDate localDate18 = property17.roundHalfFloorCopy();
        org.joda.time.LocalDate localDate20 = localDate18.plusWeeks(7);
        boolean boolean21 = localDate3.equals((java.lang.Object) localDate18);
        org.joda.time.Chronology chronology22 = localDate18.getChronology();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "000000" + "'", str6.equals("000000"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(chronology22);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
        org.joda.time.DateTime dateTime6 = localDate3.toDateTimeAtCurrentTime(dateTimeZone5);
        int int7 = localDate3.getCenturyOfEra();
        org.joda.time.LocalDate localDate9 = localDate3.withEra(0);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.LocalDate localDate11 = localDate3.minus(readablePeriod10);
        java.util.Date date12 = localDate11.toDate();
        org.joda.time.LocalDate localDate13 = org.joda.time.LocalDate.fromDateFields(date12);
        org.joda.time.LocalDate localDate15 = localDate13.withYearOfEra((int) ' ');
        org.joda.time.DurationFieldType durationFieldType16 = null;
        boolean boolean17 = localDate15.isSupported(durationFieldType16);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20 + "'", int7 == 20);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, 69, 1, 7, (int) (short) 10, 49, 69);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        long long23 = offsetDateTimeField20.add(1560639843040L, 0);
//        int int24 = offsetDateTimeField20.getOffset();
//        long long26 = offsetDateTimeField20.roundHalfCeiling(1L);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560639843040L + "'", long23 == 1560639843040L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3588 + "'", int24 == 3588);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-9910800000L) + "'", long26 == (-9910800000L));
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        boolean boolean4 = delegatedDateTimeField3.isSupported();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
        long long15 = delegatedDateTimeField3.remainder(1L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9907200001L + "'", long15 == 9907200001L);
    }

//    @Test
//    public void test454() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test454");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.plusMillis((-1));
//        org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfSecond(100);
//        int int12 = dateTime11.getDayOfYear();
//        org.joda.time.Chronology chronology13 = dateTime11.getChronology();
//        org.joda.time.ReadableDuration readableDuration14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime11.plus(readableDuration14);
//        try {
//            org.joda.time.DateTime dateTime19 = dateTime15.withDate(24, 4, 72);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 72 for dayOfMonth must be in the range [1,30]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 166 + "'", int12 == 166);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate9, locale10);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.hourOfHalfday();
        org.joda.time.DurationField durationField14 = copticChronology12.millis();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology12, dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        int int20 = dateTimeZone18.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now(dateTimeZone18);
        java.lang.String str22 = dateTimeZone18.getID();
        org.joda.time.Chronology chronology23 = copticChronology12.withZone(dateTimeZone18);
        boolean boolean24 = localDate9.equals((java.lang.Object) copticChronology12);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
        int int27 = dateTimeZone25.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate28 = org.joda.time.LocalDate.now(dateTimeZone25);
        org.joda.time.Chronology chronology29 = copticChronology12.withZone(dateTimeZone25);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology12.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField31 = copticChronology12.millisOfDay();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "69" + "'", str11.equals("69"));
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-28800000) + "'", int20 == (-28800000));
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "America/Los_Angeles" + "'", str22.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-28800000) + "'", int27 == (-28800000));
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((-599356799900L));
        int int2 = localDate1.getWeekyear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1951 + "'", int2 == 1951);
    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test457");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
//        boolean boolean25 = delegatedDateTimeField24.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) 1970, dateTimeZone27);
//        org.joda.time.LocalDate localDate32 = localDate30.withYear((int) (short) 1);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = delegatedDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDate32, locale33);
//        org.joda.time.DurationField durationField35 = null;
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
//        org.joda.time.DateTime.Property property39 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime.Property property40 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime dateTime42 = dateTime38.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
//        java.lang.String str44 = property43.getAsShortText();
//        int int45 = property43.getMinimumValueOverall();
//        int int46 = property43.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField24, durationField35, dateTimeFieldType47, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType47, 69, 0, 0);
//        org.joda.time.ReadableInterval readableInterval54 = null;
//        org.joda.time.Chronology chronology55 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval54);
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(chronology55);
//        org.joda.time.DateTime.Property property57 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime.Property property58 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime dateTime60 = dateTime56.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property61 = dateTime60.weekOfWeekyear();
//        java.lang.String str62 = property61.getAsShortText();
//        int int63 = property61.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime64 = property61.withMaximumValue();
//        org.joda.time.DurationField durationField65 = property61.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField66 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType47, durationField65);
//        java.util.Locale locale67 = null;
//        try {
//            int int68 = unsupportedDateTimeField66.getMaximumShortTextLength(locale67);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "24" + "'", str44.equals("24"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(chronology55);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "24" + "'", str62.equals("24"));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(durationField65);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField66);
//    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        long long4 = dateTimeZone1.adjustOffset(10L, true);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) 1969, dateTimeZone1);
        org.joda.time.DateMidnight dateMidnight6 = localDate5.toDateMidnight();
        org.joda.time.LocalDate.Property property7 = localDate5.monthOfYear();
        org.joda.time.LocalDate localDate8 = property7.roundHalfFloorCopy();
        org.joda.time.LocalDate localDate10 = localDate8.plusWeeks(7);
        java.util.Locale locale12 = null;
        try {
            java.lang.String str13 = localDate10.toString("", locale12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test459");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime.Property property4 = dateTime2.millisOfDay();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property4.getAsShortText(locale5);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "57902006" + "'", str6.equals("57902006"));
//    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str1 = gJChronology0.toString();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GJChronology[UTC]" + "'", str1.equals("GJChronology[UTC]"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 1970, dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withPivotYear((java.lang.Integer) 0);
        java.lang.String str8 = localDate4.toString(dateTimeFormatter7);
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(chronology10);
        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
        org.joda.time.DateTime dateTime13 = dateTime11.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = localDate4.toDateTime((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.LocalDate.Property property15 = localDate4.dayOfMonth();
        org.joda.time.LocalDate localDate17 = localDate4.withCenturyOfEra(2000);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        int int21 = dateTimeZone19.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) 1970, dateTimeZone19);
        org.joda.time.DateMidnight dateMidnight23 = localDate17.toDateMidnight(dateTimeZone19);
        org.joda.time.DateTime dateTime24 = localDate17.toDateTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-28800000) + "'", int21 == (-28800000));
        org.junit.Assert.assertNotNull(dateMidnight23);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfSecond();
        org.joda.time.DateTime.Property property5 = dateTime3.millisOfSecond();
        org.joda.time.DateTime dateTime7 = dateTime3.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime10 = property8.addToCopy((int) (byte) 10);
        boolean boolean11 = julianChronology0.equals((java.lang.Object) dateTime10);
        org.joda.time.DateTime.Property property12 = dateTime10.yearOfCentury();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
//        boolean boolean25 = delegatedDateTimeField24.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) 1970, dateTimeZone27);
//        org.joda.time.LocalDate localDate32 = localDate30.withYear((int) (short) 1);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = delegatedDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDate32, locale33);
//        org.joda.time.DurationField durationField35 = null;
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
//        org.joda.time.DateTime.Property property39 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime.Property property40 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime dateTime42 = dateTime38.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
//        java.lang.String str44 = property43.getAsShortText();
//        int int45 = property43.getMinimumValueOverall();
//        int int46 = property43.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField24, durationField35, dateTimeFieldType47, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType47, 69, 0, 0);
//        org.joda.time.ReadableInterval readableInterval54 = null;
//        org.joda.time.Chronology chronology55 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval54);
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(chronology55);
//        org.joda.time.DateTime.Property property57 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime.Property property58 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime dateTime60 = dateTime56.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property61 = dateTime60.weekOfWeekyear();
//        java.lang.String str62 = property61.getAsShortText();
//        int int63 = property61.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime64 = property61.withMaximumValue();
//        org.joda.time.DurationField durationField65 = property61.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField66 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType47, durationField65);
//        org.joda.time.DurationField durationField67 = unsupportedDateTimeField66.getLeapDurationField();
//        java.util.Locale locale68 = null;
//        try {
//            int int69 = unsupportedDateTimeField66.getMaximumShortTextLength(locale68);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "24" + "'", str44.equals("24"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(chronology55);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "24" + "'", str62.equals("24"));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(durationField65);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField66);
//        org.junit.Assert.assertNull(durationField67);
//    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        boolean boolean4 = delegatedDateTimeField3.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
//        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
//        org.joda.time.DurationField durationField14 = null;
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        java.lang.String str23 = property22.getAsShortText();
//        int int24 = property22.getMinimumValueOverall();
//        int int25 = property22.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
//        int int29 = dividedDateTimeField28.getMinimumValue();
//        int int32 = dividedDateTimeField28.getDifference((long) 1970, 32L);
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.getDefault();
//        int int36 = dateTimeZone34.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate((long) 1970, dateTimeZone34);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = org.joda.time.format.ISODateTimeFormat.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = dateTimeFormatter38.withPivotYear((java.lang.Integer) 0);
//        java.lang.String str41 = localDate37.toString(dateTimeFormatter40);
//        org.joda.time.ReadableInterval readableInterval42 = null;
//        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval42);
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(chronology43);
//        org.joda.time.DateTime.Property property45 = dateTime44.millisOfSecond();
//        org.joda.time.DateTime dateTime46 = dateTime44.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime47 = localDate37.toDateTime((org.joda.time.ReadableInstant) dateTime44);
//        org.joda.time.DateTimeFieldType dateTimeFieldType48 = null;
//        int int49 = localDate37.indexOf(dateTimeFieldType48);
//        java.util.Locale locale51 = null;
//        java.lang.String str52 = dividedDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate37, (int) (short) 1, locale51);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField53 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField28);
//        long long56 = remainderDateTimeField53.addWrapField(1L, 52);
//        long long58 = remainderDateTimeField53.roundHalfEven(19692288000002L);
//        long long61 = remainderDateTimeField53.addWrapField((long) 2000, 3675);
//        long long64 = remainderDateTimeField53.addWrapField((long) 365, 999);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "24" + "'", str23.equals("24"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-28800000) + "'", int36 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTimeFormatter38);
//        org.junit.Assert.assertNotNull(dateTimeFormatter40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1969" + "'", str41.equals("1969"));
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "1" + "'", str52.equals("1"));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1L + "'", long56 == 1L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 19682377200000L + "'", long58 == 19682377200000L);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-536457598000L) + "'", long61 == (-536457598000L));
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 347155200365L + "'", long64 == 347155200365L);
//    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) 365);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 0, (int) (short) 100, 999, 3688);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2790 + "'", int4 == 2790);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        long long4 = dateTimeZone1.adjustOffset(10L, true);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) 1969, dateTimeZone1);
        org.joda.time.DateMidnight dateMidnight6 = localDate5.toDateMidnight();
        org.joda.time.LocalDate.Property property7 = localDate5.monthOfYear();
        org.joda.time.LocalDate localDate9 = localDate5.plusYears(57600);
        org.joda.time.LocalDate localDate11 = localDate9.minusWeeks((int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate11);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        long long4 = dateTimeZone1.adjustOffset(10L, true);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) 1969, dateTimeZone1);
        org.joda.time.DateMidnight dateMidnight6 = localDate5.toDateMidnight();
        org.joda.time.LocalDate.Property property7 = localDate5.monthOfYear();
        org.joda.time.LocalDate localDate8 = property7.roundHalfFloorCopy();
        org.joda.time.Chronology chronology9 = localDate8.getChronology();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        int int5 = delegatedDateTimeField3.getMinimumValue((long) (byte) 0);
        boolean boolean6 = delegatedDateTimeField3.isSupported();
        java.util.Locale locale8 = null;
        java.lang.String str9 = delegatedDateTimeField3.getAsText(20, locale8);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "20" + "'", str9.equals("20"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime2.plusSeconds(3675);
        int int7 = dateTime6.getMonthOfYear();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        boolean boolean4 = delegatedDateTimeField3.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
//        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
//        org.joda.time.DurationField durationField14 = null;
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        java.lang.String str23 = property22.getAsShortText();
//        int int24 = property22.getMinimumValueOverall();
//        int int25 = property22.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
//        long long31 = dividedDateTimeField28.add((long) 2, 12);
//        int int32 = dividedDateTimeField28.getMinimumValue();
//        long long34 = dividedDateTimeField28.roundHalfCeiling((-31L));
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "24" + "'", str23.equals("24"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 19692288000002L + "'", long31 == 19692288000002L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 526546800000L + "'", long34 == 526546800000L);
//    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        int int3 = dateTime2.getDayOfYear();
//        org.joda.time.DateTime dateTime4 = dateTime2.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfMonth();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 166 + "'", int3 == 166);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//    }

//    @Test
//    public void test474() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test474");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        long long23 = offsetDateTimeField20.add(1560639843040L, 0);
//        int int24 = offsetDateTimeField20.getOffset();
//        org.joda.time.ReadablePartial readablePartial25 = null;
//        int int26 = offsetDateTimeField20.getMaximumValue(readablePartial25);
//        long long28 = offsetDateTimeField20.roundHalfFloor(10L);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560639843040L + "'", long23 == 1560639843040L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3588 + "'", int24 == 3588);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 3688 + "'", int26 == 3688);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-9910800000L) + "'", long28 == (-9910800000L));
//    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(19);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withLocale(locale3);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate9, locale10);
        org.joda.time.LocalDate.Property property12 = localDate9.dayOfMonth();
        org.joda.time.LocalDate localDate14 = property12.addToCopy((int) 'a');
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = copticChronology15.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        int int23 = dateTimeZone21.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) 1970, dateTimeZone21);
        java.util.Locale locale25 = null;
        java.lang.String str26 = delegatedDateTimeField19.getAsShortText((org.joda.time.ReadablePartial) localDate24, locale25);
        org.joda.time.LocalDate.Property property27 = localDate24.dayOfMonth();
        org.joda.time.LocalDate localDate29 = property27.addToCopy((int) 'a');
        boolean boolean30 = localDate14.isBefore((org.joda.time.ReadablePartial) localDate29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = localDate29.toString("[]", locale32);
        org.joda.time.LocalDate localDate35 = localDate29.minusYears(57600);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "69" + "'", str11.equals("69"));
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-28800000) + "'", int23 == (-28800000));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "69" + "'", str26.equals("69"));
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "[]" + "'", str33.equals("[]"));
        org.junit.Assert.assertNotNull(localDate35);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.yearOfEra();
        org.joda.time.Chronology chronology4 = gJChronology0.withUTC();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
        java.lang.String str2 = buddhistChronology0.toString();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray6 = buddhistChronology0.get(readablePeriod3, (long) 2000, (long) 86);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        try {
            org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Double");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
        org.joda.time.DateTime dateTime6 = localDate3.toDateTimeAtCurrentTime(dateTimeZone5);
        int int7 = localDate3.getCenturyOfEra();
        org.joda.time.LocalDate localDate9 = localDate3.withEra(0);
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology11.hourOfHalfday();
        org.joda.time.DurationField durationField13 = copticChronology11.millis();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology11, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((java.lang.Object) 1560639843040L, dateTimeZone14);
        org.joda.time.DateTime dateTime18 = localDate3.toDateTimeAtStartOfDay(dateTimeZone14);
        boolean boolean20 = dateTime18.isAfter(9972000000L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20 + "'", int7 == 20);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

//    @Test
//    public void test481() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test481");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5);
//        long long8 = delegatedDateTimeField5.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval9 = null;
//        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(chronology10);
//        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
//        org.joda.time.DateTime.Property property13 = dateTime11.millisOfSecond();
//        org.joda.time.DateTime dateTime15 = dateTime11.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property16 = dateTime15.weekOfWeekyear();
//        java.lang.String str17 = property16.getAsShortText();
//        int int18 = property16.getMinimumValueOverall();
//        int int19 = property16.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, dateTimeFieldType20, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField24 = copticChronology23.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField24, dateTimeFieldType25);
//        boolean boolean27 = delegatedDateTimeField26.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
//        int int31 = dateTimeZone29.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) 1970, dateTimeZone29);
//        org.joda.time.LocalDate localDate34 = localDate32.withYear((int) (short) 1);
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = delegatedDateTimeField26.getAsText((org.joda.time.ReadablePartial) localDate34, locale35);
//        org.joda.time.DurationField durationField37 = null;
//        org.joda.time.ReadableInterval readableInterval38 = null;
//        org.joda.time.Chronology chronology39 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval38);
//        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime(chronology39);
//        org.joda.time.DateTime.Property property41 = dateTime40.millisOfSecond();
//        org.joda.time.DateTime.Property property42 = dateTime40.millisOfSecond();
//        org.joda.time.DateTime dateTime44 = dateTime40.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property45 = dateTime44.weekOfWeekyear();
//        java.lang.String str46 = property45.getAsShortText();
//        int int47 = property45.getMinimumValueOverall();
//        int int48 = property45.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = property45.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField51 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField26, durationField37, dateTimeFieldType49, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, dateTimeFieldType49, 69, 0, 0);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException58 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType49, (java.lang.Number) 0, "69");
//        boolean boolean59 = julianChronology0.equals((java.lang.Object) illegalFieldValueException58);
//        illegalFieldValueException58.prependMessage("772");
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9910800000L) + "'", long8 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "24" + "'", str17.equals("24"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 52 + "'", int19 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertNotNull(copticChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-28800000) + "'", int31 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate34);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1" + "'", str36.equals("1"));
//        org.junit.Assert.assertNotNull(chronology39);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "24" + "'", str46.equals("24"));
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 52 + "'", int48 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType49);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology5);
        org.joda.time.DateTime.Property property7 = dateTime6.millisOfSecond();
        org.joda.time.DateTime dateTime9 = property7.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime11 = property7.addToCopy(132);
        org.joda.time.YearMonthDay yearMonthDay12 = dateTime11.toYearMonthDay();
        org.joda.time.ReadableInterval readableInterval14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(chronology15);
        org.joda.time.Partial partial17 = new org.joda.time.Partial(chronology15);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField19 = gJChronology18.weekyears();
        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField21 = gJChronology18.yearOfEra();
        org.joda.time.Partial partial22 = partial17.withChronologyRetainFields((org.joda.time.Chronology) gJChronology18);
        int[] intArray23 = partial22.getValues();
        try {
            int[] intArray25 = delegatedDateTimeField3.set((org.joda.time.ReadablePartial) yearMonthDay12, 0, intArray23, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(yearMonthDay12);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(partial22);
        org.junit.Assert.assertNotNull(intArray23);
    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
//        boolean boolean25 = delegatedDateTimeField24.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) 1970, dateTimeZone27);
//        org.joda.time.LocalDate localDate32 = localDate30.withYear((int) (short) 1);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = delegatedDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDate32, locale33);
//        org.joda.time.DurationField durationField35 = null;
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
//        org.joda.time.DateTime.Property property39 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime.Property property40 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime dateTime42 = dateTime38.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
//        java.lang.String str44 = property43.getAsShortText();
//        int int45 = property43.getMinimumValueOverall();
//        int int46 = property43.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField24, durationField35, dateTimeFieldType47, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType47, 69, 0, 0);
//        org.joda.time.ReadableInterval readableInterval54 = null;
//        org.joda.time.Chronology chronology55 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval54);
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(chronology55);
//        org.joda.time.DateTime.Property property57 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime.Property property58 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime dateTime60 = dateTime56.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property61 = dateTime60.weekOfWeekyear();
//        java.lang.String str62 = property61.getAsShortText();
//        int int63 = property61.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime64 = property61.withMaximumValue();
//        org.joda.time.DurationField durationField65 = property61.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField66 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType47, durationField65);
//        java.lang.String str67 = unsupportedDateTimeField66.toString();
//        try {
//            int int69 = unsupportedDateTimeField66.getMinimumValue(0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "24" + "'", str44.equals("24"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(chronology55);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "24" + "'", str62.equals("24"));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(durationField65);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField66);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "UnsupportedDateTimeField" + "'", str67.equals("UnsupportedDateTimeField"));
//    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(chronology1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField4 = gJChronology3.weekyears();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, dateTimeField5, (int) (byte) -1);
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipUndoDateTimeField7.getAsText((int) (byte) 100, locale9);
        int int12 = skipUndoDateTimeField7.getLeapAmount((long) 15);
        long long15 = skipUndoDateTimeField7.set((long) (-28800000), 0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100" + "'", str10.equals("100"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-28800000L) + "'", long15 == (-28800000L));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField2 = null;
        try {
            org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(10, 1969, 69, 0, 49, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        long long4 = dateTimeZone1.adjustOffset(10L, true);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) 1969, dateTimeZone1);
        org.joda.time.DateMidnight dateMidnight6 = localDate5.toDateMidnight();
        org.joda.time.LocalDate.Property property7 = localDate5.monthOfYear();
        org.joda.time.LocalDate localDate8 = property7.roundHalfFloorCopy();
        try {
            org.joda.time.LocalDate localDate10 = property7.setCopy("Pacific Standard Time");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Pacific Standard Time\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate8);
    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test488");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
//        boolean boolean25 = delegatedDateTimeField24.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) 1970, dateTimeZone27);
//        org.joda.time.LocalDate localDate32 = localDate30.withYear((int) (short) 1);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = delegatedDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDate32, locale33);
//        org.joda.time.DurationField durationField35 = null;
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
//        org.joda.time.DateTime.Property property39 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime.Property property40 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime dateTime42 = dateTime38.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
//        java.lang.String str44 = property43.getAsShortText();
//        int int45 = property43.getMinimumValueOverall();
//        int int46 = property43.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField24, durationField35, dateTimeFieldType47, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType47, 69, 0, 0);
//        org.joda.time.ReadableInterval readableInterval54 = null;
//        org.joda.time.Chronology chronology55 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval54);
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(chronology55);
//        org.joda.time.DateTime.Property property57 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime.Property property58 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime dateTime60 = dateTime56.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property61 = dateTime60.weekOfWeekyear();
//        java.lang.String str62 = property61.getAsShortText();
//        int int63 = property61.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime64 = property61.withMaximumValue();
//        org.joda.time.DurationField durationField65 = property61.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField66 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType47, durationField65);
//        org.joda.time.DurationField durationField67 = unsupportedDateTimeField66.getLeapDurationField();
//        try {
//            int int69 = unsupportedDateTimeField66.getLeapAmount(0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "24" + "'", str44.equals("24"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(chronology55);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "24" + "'", str62.equals("24"));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(durationField65);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField66);
//        org.junit.Assert.assertNull(durationField67);
//    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        int int5 = delegatedDateTimeField3.getMinimumValue((long) (byte) 0);
        boolean boolean7 = delegatedDateTimeField3.isLeap((long) 0);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField3.getRangeDurationField();
        long long11 = delegatedDateTimeField3.getDifferenceAsLong((long) 57600032, (-3801600000L));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.secondOfDay();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology5);
        org.joda.time.DateTime.Property property7 = dateTime6.millisOfSecond();
        org.joda.time.DateTime dateTime8 = dateTime6.withEarlierOffsetAtOverlap();
        org.joda.time.ReadablePartial readablePartial9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.withFields(readablePartial9);
        boolean boolean11 = copticChronology0.equals((java.lang.Object) dateTime6);
        org.joda.time.DateTime dateTime13 = dateTime6.withYear((int) (byte) 100);
        org.joda.time.DateTime.Property property14 = dateTime13.dayOfMonth();
        org.joda.time.DateTime dateTime16 = dateTime13.plusMonths((int) (short) 10);
        try {
            org.joda.time.DateTime dateTime18 = dateTime13.withEra(7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 7 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        java.util.TimeZone timeZone3 = dateTimeZone1.toTimeZone();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant4, 3);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology6.getZone();
        org.joda.time.DurationField durationField8 = gJChronology6.hours();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMillisOfSecond(9);
        org.joda.time.DateTime.Property property4 = dateTime1.year();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
        org.joda.time.DateTime dateTime6 = localDate3.toDateTimeAtCurrentTime(dateTimeZone5);
        int int7 = localDate3.getCenturyOfEra();
        org.joda.time.LocalDate localDate9 = localDate3.withEra(0);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.LocalDate localDate11 = localDate3.minus(readablePeriod10);
        java.util.Date date12 = localDate11.toDate();
        org.joda.time.LocalDate localDate13 = org.joda.time.LocalDate.fromDateFields(date12);
        org.joda.time.LocalDate localDate14 = org.joda.time.LocalDate.fromDateFields(date12);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20 + "'", int7 == 20);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(localDate14);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.secondOfDay();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology5);
        org.joda.time.DateTime.Property property7 = dateTime6.millisOfSecond();
        org.joda.time.DateTime dateTime8 = dateTime6.withEarlierOffsetAtOverlap();
        org.joda.time.ReadablePartial readablePartial9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.withFields(readablePartial9);
        boolean boolean11 = copticChronology0.equals((java.lang.Object) dateTime6);
        org.joda.time.DateTimeField dateTimeField12 = copticChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField13 = copticChronology0.halfdays();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField8 = copticChronology7.weeks();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField10 = copticChronology7.secondOfDay();
        org.joda.time.ReadableInterval readableInterval11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(chronology12);
        org.joda.time.DateTime.Property property14 = dateTime13.millisOfSecond();
        org.joda.time.DateTime dateTime15 = dateTime13.withEarlierOffsetAtOverlap();
        org.joda.time.ReadablePartial readablePartial16 = null;
        org.joda.time.DateTime dateTime17 = dateTime13.withFields(readablePartial16);
        boolean boolean18 = copticChronology7.equals((java.lang.Object) dateTime13);
        org.joda.time.DateTime dateTime20 = dateTime13.withYear((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime24 = dateTime20.toMutableDateTime(dateTimeZone23);
        try {
            org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(1969, 47, 16, 49, (int) (byte) 10, (int) (byte) 1, 57600, dateTimeZone23);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 49 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(mutableDateTime24);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 1970, dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withPivotYear((java.lang.Integer) 0);
        java.lang.String str8 = localDate4.toString(dateTimeFormatter7);
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(chronology10);
        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
        org.joda.time.DateTime dateTime13 = dateTime11.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = localDate4.toDateTime((org.joda.time.ReadableInstant) dateTime11);
        int int15 = localDate4.getWeekyear();
        int int16 = localDate4.getYearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1970 + "'", int15 == 1970);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 69 + "'", int16 == 69);
    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        boolean boolean4 = delegatedDateTimeField3.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
//        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
//        org.joda.time.DurationField durationField14 = null;
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        java.lang.String str23 = property22.getAsShortText();
//        int int24 = property22.getMinimumValueOverall();
//        int int25 = property22.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
//        int int29 = dividedDateTimeField28.getMinimumValue();
//        int int32 = dividedDateTimeField28.getDifference((long) 1970, 32L);
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.getDefault();
//        int int36 = dateTimeZone34.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate((long) 1970, dateTimeZone34);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = org.joda.time.format.ISODateTimeFormat.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = dateTimeFormatter38.withPivotYear((java.lang.Integer) 0);
//        java.lang.String str41 = localDate37.toString(dateTimeFormatter40);
//        org.joda.time.ReadableInterval readableInterval42 = null;
//        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval42);
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(chronology43);
//        org.joda.time.DateTime.Property property45 = dateTime44.millisOfSecond();
//        org.joda.time.DateTime dateTime46 = dateTime44.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime47 = localDate37.toDateTime((org.joda.time.ReadableInstant) dateTime44);
//        org.joda.time.DateTimeFieldType dateTimeFieldType48 = null;
//        int int49 = localDate37.indexOf(dateTimeFieldType48);
//        java.util.Locale locale51 = null;
//        java.lang.String str52 = dividedDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate37, (int) (short) 1, locale51);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField53 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField28);
//        long long56 = remainderDateTimeField53.addWrapField(1L, 52);
//        long long58 = remainderDateTimeField53.roundCeiling((long) 53);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "24" + "'", str23.equals("24"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-28800000) + "'", int36 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTimeFormatter38);
//        org.junit.Assert.assertNotNull(dateTimeFormatter40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1969" + "'", str41.equals("1969"));
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "1" + "'", str52.equals("1"));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1L + "'", long56 == 1L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 22143600000L + "'", long58 == 22143600000L);
//    }

//    @Test
//    public void test498() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test498");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        boolean boolean4 = delegatedDateTimeField3.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
//        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
//        org.joda.time.DurationField durationField14 = null;
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        java.lang.String str23 = property22.getAsShortText();
//        int int24 = property22.getMinimumValueOverall();
//        int int25 = property22.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
//        long long31 = dividedDateTimeField28.add((long) 2, 12);
//        int int32 = dividedDateTimeField28.getDivisor();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = null;
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField34 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField28, dateTimeFieldType33);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "24" + "'", str23.equals("24"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 19692288000002L + "'", long31 == 19692288000002L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 52 + "'", int32 == 52);
//    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendClockhourOfHalfday((int) (byte) 10);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMillisOfSecond((-70));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }
}

