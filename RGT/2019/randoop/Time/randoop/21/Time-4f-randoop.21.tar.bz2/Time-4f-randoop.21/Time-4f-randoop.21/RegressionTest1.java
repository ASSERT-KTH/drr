import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (short) -1);
        org.joda.time.DateTime dateTime5 = instant1.toDateTime(dateTimeZone2);
        boolean boolean7 = dateTime5.equals((java.lang.Object) 0.0d);
        org.joda.time.DateTime dateTime9 = dateTime5.withYear((int) (short) -1);
        org.joda.time.DateTime dateTime11 = dateTime5.plusMinutes(100);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        boolean boolean13 = dateTime5.isSupported(dateTimeFieldType12);
        org.joda.time.DateTime dateTime15 = dateTime5.withHourOfDay(3);
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField17 = copticChronology16.weeks();
        org.joda.time.DateTimeField dateTimeField18 = copticChronology16.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField19 = copticChronology16.secondOfDay();
        org.joda.time.ReadableInterval readableInterval20 = null;
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval20);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(chronology21);
        org.joda.time.DateTime.Property property23 = dateTime22.millisOfSecond();
        org.joda.time.DateTime dateTime24 = dateTime22.withEarlierOffsetAtOverlap();
        org.joda.time.ReadablePartial readablePartial25 = null;
        org.joda.time.DateTime dateTime26 = dateTime22.withFields(readablePartial25);
        boolean boolean27 = copticChronology16.equals((java.lang.Object) dateTime22);
        org.joda.time.DateTime dateTime29 = dateTime22.withYear((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone31 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone30);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone30);
        org.joda.time.MutableDateTime mutableDateTime33 = dateTime29.toMutableDateTime(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = dateTime5.withZoneRetainFields(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(cachedDateTimeZone31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(mutableDateTime33);
        org.junit.Assert.assertNotNull(dateTime34);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("1");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.dateHour();
        boolean boolean3 = jodaTimePermission1.equals((java.lang.Object) dateTimeFormatter2);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.halfdayOfDay();
        org.joda.time.Chronology chronology6 = buddhistChronology4.withUTC();
        java.lang.String str7 = buddhistChronology4.toString();
        boolean boolean8 = jodaTimePermission1.equals((java.lang.Object) buddhistChronology4);
        java.lang.String str9 = jodaTimePermission1.getActions();
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str7.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        java.io.Writer writer1 = null;
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(chronology3);
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.ReadablePartial readablePartial7 = null;
        org.joda.time.DateTime dateTime8 = dateTime4.withFields(readablePartial7);
        int int9 = dateTime4.getYearOfEra();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
//        boolean boolean25 = delegatedDateTimeField24.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) 1970, dateTimeZone27);
//        org.joda.time.LocalDate localDate32 = localDate30.withYear((int) (short) 1);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = delegatedDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDate32, locale33);
//        org.joda.time.DurationField durationField35 = null;
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
//        org.joda.time.DateTime.Property property39 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime.Property property40 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime dateTime42 = dateTime38.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
//        java.lang.String str44 = property43.getAsShortText();
//        int int45 = property43.getMinimumValueOverall();
//        int int46 = property43.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField24, durationField35, dateTimeFieldType47, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType47, 69, 0, 0);
//        org.joda.time.ReadableInterval readableInterval54 = null;
//        org.joda.time.Chronology chronology55 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval54);
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(chronology55);
//        org.joda.time.DateTime.Property property57 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime.Property property58 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime dateTime60 = dateTime56.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property61 = dateTime60.weekOfWeekyear();
//        java.lang.String str62 = property61.getAsShortText();
//        int int63 = property61.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime64 = property61.withMaximumValue();
//        org.joda.time.DurationField durationField65 = property61.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField66 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType47, durationField65);
//        org.joda.time.DurationField durationField67 = unsupportedDateTimeField66.getLeapDurationField();
//        java.util.Locale locale69 = null;
//        try {
//            java.lang.String str70 = unsupportedDateTimeField66.getAsShortText((int) (byte) 10, locale69);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "24" + "'", str44.equals("24"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(chronology55);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "24" + "'", str62.equals("24"));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(durationField65);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField66);
//        org.junit.Assert.assertNull(durationField67);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Partial partial1 = new org.joda.time.Partial((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = partial1.getFieldTypes();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        boolean boolean4 = delegatedDateTimeField3.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
//        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
//        org.joda.time.DurationField durationField14 = null;
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        java.lang.String str23 = property22.getAsShortText();
//        int int24 = property22.getMinimumValueOverall();
//        int int25 = property22.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
//        int int29 = dividedDateTimeField28.getMinimumValue();
//        int int32 = dividedDateTimeField28.getDifference((long) 1970, 32L);
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.getDefault();
//        int int36 = dateTimeZone34.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate((long) 1970, dateTimeZone34);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = org.joda.time.format.ISODateTimeFormat.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = dateTimeFormatter38.withPivotYear((java.lang.Integer) 0);
//        java.lang.String str41 = localDate37.toString(dateTimeFormatter40);
//        org.joda.time.ReadableInterval readableInterval42 = null;
//        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval42);
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(chronology43);
//        org.joda.time.DateTime.Property property45 = dateTime44.millisOfSecond();
//        org.joda.time.DateTime dateTime46 = dateTime44.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime47 = localDate37.toDateTime((org.joda.time.ReadableInstant) dateTime44);
//        org.joda.time.DateTimeFieldType dateTimeFieldType48 = null;
//        int int49 = localDate37.indexOf(dateTimeFieldType48);
//        java.util.Locale locale51 = null;
//        java.lang.String str52 = dividedDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate37, (int) (short) 1, locale51);
//        long long54 = dividedDateTimeField28.roundFloor((long) 49);
//        org.joda.time.DurationField durationField55 = dividedDateTimeField28.getRangeDurationField();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "24" + "'", str23.equals("24"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-28800000) + "'", int36 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTimeFormatter38);
//        org.junit.Assert.assertNotNull(dateTimeFormatter40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1969" + "'", str41.equals("1969"));
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "1" + "'", str52.equals("1"));
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-1114272000000L) + "'", long54 == (-1114272000000L));
//        org.junit.Assert.assertNotNull(durationField55);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(0, ' ', (int) (short) -1, (int) (short) 0, 0, true, (int) (short) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.setFixedSavings("86", 70);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology0.monthOfYear();
        org.joda.time.DurationField durationField5 = copticChronology0.days();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 1970, dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withPivotYear((java.lang.Integer) 0);
        java.lang.String str8 = localDate4.toString(dateTimeFormatter7);
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(chronology10);
        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
        org.joda.time.DateTime dateTime13 = dateTime11.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = localDate4.toDateTime((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        org.joda.time.DateTime dateTime18 = localDate4.toDateTimeAtCurrentTime(dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime18.plusDays((int) '#');
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.plusMillis((-1));
//        int int10 = dateTime9.getYearOfCentury();
//        int int11 = dateTime9.getSecondOfMinute();
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime9.plus(readableDuration12);
//        try {
//            org.joda.time.DateTime dateTime18 = dateTime9.withTime((int) (short) -1, 52, (int) (byte) 10, (-101774));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19 + "'", int10 == 19);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        long long4 = dateTimeZone1.adjustOffset(10L, true);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) 1969, dateTimeZone1);
        org.joda.time.DateMidnight dateMidnight6 = localDate5.toDateMidnight();
        org.joda.time.LocalDate.Property property7 = localDate5.monthOfYear();
        org.joda.time.LocalDate localDate8 = property7.roundHalfFloorCopy();
        int int9 = property7.get();
        org.joda.time.LocalDate localDate10 = property7.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 12 + "'", int9 == 12);
        org.junit.Assert.assertNotNull(localDate10);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) ' ');
        boolean boolean2 = instant1.isBeforeNow();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.centuryOfEra();
        org.joda.time.DurationField durationField3 = gJChronology0.days();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        boolean boolean4 = delegatedDateTimeField3.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
//        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
//        org.joda.time.DurationField durationField14 = null;
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        java.lang.String str23 = property22.getAsShortText();
//        int int24 = property22.getMinimumValueOverall();
//        int int25 = property22.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
//        java.util.Locale locale29 = null;
//        int int30 = dividedDateTimeField28.getMaximumShortTextLength(locale29);
//        long long33 = dividedDateTimeField28.add((long) 20, (long) 49);
//        try {
//            long long36 = dividedDateTimeField28.add((long) 3588, 347155200365L);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 18052070418980");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "24" + "'", str23.equals("24"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 80408764800020L + "'", long33 == 80408764800020L);
//    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.plusMillis((-1));
//        org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfSecond(100);
//        java.lang.String str12 = dateTime11.toString();
//        boolean boolean13 = dateTime11.isAfterNow();
//        org.joda.time.DateTime.Property property14 = dateTime11.yearOfEra();
//        org.joda.time.YearMonthDay yearMonthDay15 = dateTime11.toYearMonthDay();
//        try {
//            org.joda.time.DateTime dateTime17 = dateTime11.withEra(72);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 72 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0019-06-15T16:05:09.100-07:52:58" + "'", str12.equals("0019-06-15T16:05:09.100-07:52:58"));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(yearMonthDay15);
//    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime5 = property3.addWrapFieldToCopy(0);
//        org.joda.time.DateTime dateTime7 = property3.addToCopy(132);
//        java.lang.String str8 = property3.getAsShortText();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "775" + "'", str8.equals("775"));
//    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        long long23 = offsetDateTimeField20.add(1560639843040L, 0);
//        java.lang.String str24 = offsetDateTimeField20.getName();
//        try {
//            long long27 = offsetDateTimeField20.set((long) 57904, (int) 'a');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for weekOfWeekyear must be in the range [3589,3688]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560639843040L + "'", long23 == 1560639843040L);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "weekOfWeekyear" + "'", str24.equals("weekOfWeekyear"));
//    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime4 = dateTime2.withEarlierOffsetAtOverlap();
//        org.joda.time.ReadablePartial readablePartial5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.withFields(readablePartial5);
//        int int7 = dateTime2.getYearOfEra();
//        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.hourOfHalfday();
//        org.joda.time.DurationField durationField10 = copticChronology8.millis();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
//        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology8, dateTimeZone11);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone11.getName((long) 1969, locale15);
//        org.joda.time.DateTime dateTime17 = dateTime2.toDateTime(dateTimeZone11);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        int int21 = dateTimeZone19.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) 1970, dateTimeZone19);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter23.withPivotYear((java.lang.Integer) 0);
//        java.lang.String str26 = localDate22.toString(dateTimeFormatter25);
//        org.joda.time.ReadableInterval readableInterval27 = null;
//        org.joda.time.Chronology chronology28 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval27);
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(chronology28);
//        org.joda.time.DateTime.Property property30 = dateTime29.millisOfSecond();
//        org.joda.time.DateTime dateTime31 = dateTime29.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime32 = localDate22.toDateTime((org.joda.time.ReadableInstant) dateTime29);
//        org.joda.time.LocalDate.Property property33 = localDate22.dayOfMonth();
//        org.joda.time.LocalDate localDate35 = localDate22.withCenturyOfEra(2000);
//        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.getDefault();
//        int int39 = dateTimeZone37.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate((long) 1970, dateTimeZone37);
//        org.joda.time.DateMidnight dateMidnight41 = localDate35.toDateMidnight(dateTimeZone37);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((java.lang.Object) dateTime17, dateTimeZone37);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone43 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone37);
//        int int45 = cachedDateTimeZone43.getStandardOffset((long) 132);
//        long long47 = cachedDateTimeZone43.nextTransition((long) 166);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(copticChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
//        org.junit.Assert.assertNotNull(zonedChronology13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Pacific Standard Time" + "'", str16.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-28800000) + "'", int21 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1969" + "'", str26.equals("1969"));
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-28800000) + "'", int39 == (-28800000));
//        org.junit.Assert.assertNotNull(dateMidnight41);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone43);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-28800000) + "'", int45 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 9972000000L + "'", long47 == 9972000000L);
//    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.plusMillis((-1));
//        int int10 = dateTime9.getYearOfCentury();
//        int int11 = dateTime9.getSecondOfMinute();
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime9.plus(readableDuration12);
//        org.joda.time.DateTime dateTime15 = dateTime13.withWeekOfWeekyear(1);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19 + "'", int10 == 19);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        java.lang.String str4 = dateTimeZone0.getID();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        int int6 = gregorianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology7 = gregorianChronology5.withUTC();
        java.lang.String str8 = gregorianChronology5.toString();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "America/Los_Angeles" + "'", str4.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str8.equals("GregorianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(0, ' ', (int) (short) -1, (int) (short) 0, 0, true, (int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeZoneBuilder0.toDateTimeZone("3588", true);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder22 = dateTimeZoneBuilder0.addRecurringSavings("weekOfWeekyear", 3675, (int) (byte) 10, 59, '4', 55, 0, 3589, false, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.plusMillis((-1));
//        int int10 = dateTime9.getYearOfCentury();
//        int int11 = dateTime9.getSecondOfMinute();
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.hourOfHalfday();
//        org.joda.time.DurationField durationField14 = copticChronology12.millis();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
//        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology12, dateTimeZone15);
//        org.joda.time.DateTime dateTime18 = dateTime9.withZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime20 = dateTime18.minusMonths(7);
//        org.joda.time.DateTime.Property property21 = dateTime20.monthOfYear();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19 + "'", int10 == 19);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
//        org.junit.Assert.assertNotNull(zonedChronology17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendPattern("GJChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: J");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial(chronology1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField5 = gJChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.yearOfEra();
        org.joda.time.Partial partial8 = partial3.withChronologyRetainFields((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = partial8.getFieldTypes();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.Partial partial12 = partial8.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        try {
            int[] intArray15 = iSOChronology10.get(readablePeriod13, 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(partial8);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(partial12);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        int int1 = dateTimeFormatter0.getDefaultYear();
//        org.joda.time.ReadableInterval readableInterval2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(chronology3);
//        org.joda.time.DateTime.Property property5 = dateTime4.millisOfSecond();
//        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
//        org.joda.time.DateTime dateTime8 = dateTime4.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property9 = dateTime8.weekOfWeekyear();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusMillis((-1));
//        org.joda.time.DateTime dateTime13 = dateTime11.withMillisOfSecond(100);
//        java.lang.String str14 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0019-06-15T16" + "'", str14.equals("0019-06-15T16"));
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) '4', 24);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1248L + "'", long2 == 1248L);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = localDate3.toString("000000Z", locale5);
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        int int8 = localDate3.indexOf(dateTimeFieldType7);
//        org.joda.time.DateTime dateTime9 = localDate3.toDateTimeAtMidnight();
//        org.joda.time.LocalDate localDate11 = localDate3.withYearOfEra(4);
//        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now();
//        org.joda.time.LocalDate.Property property13 = localDate12.dayOfWeek();
//        boolean boolean14 = localDate3.equals((java.lang.Object) property13);
//        int int15 = localDate3.getDayOfWeek();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "000000" + "'", str6.equals("000000"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
//        boolean boolean25 = delegatedDateTimeField24.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) 1970, dateTimeZone27);
//        org.joda.time.LocalDate localDate32 = localDate30.withYear((int) (short) 1);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = delegatedDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDate32, locale33);
//        org.joda.time.DurationField durationField35 = null;
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
//        org.joda.time.DateTime.Property property39 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime.Property property40 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime dateTime42 = dateTime38.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
//        java.lang.String str44 = property43.getAsShortText();
//        int int45 = property43.getMinimumValueOverall();
//        int int46 = property43.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField24, durationField35, dateTimeFieldType47, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType47, 69, 0, 0);
//        org.joda.time.ReadableInterval readableInterval54 = null;
//        org.joda.time.Chronology chronology55 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval54);
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(chronology55);
//        org.joda.time.DateTime.Property property57 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime.Property property58 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime dateTime60 = dateTime56.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property61 = dateTime60.weekOfWeekyear();
//        java.lang.String str62 = property61.getAsShortText();
//        int int63 = property61.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime64 = property61.withMaximumValue();
//        org.joda.time.DurationField durationField65 = property61.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField66 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType47, durationField65);
//        try {
//            int int68 = unsupportedDateTimeField66.getLeapAmount(100L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "24" + "'", str44.equals("24"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(chronology55);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "24" + "'", str62.equals("24"));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(durationField65);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField66);
//    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        boolean boolean4 = delegatedDateTimeField3.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
//        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
//        org.joda.time.DurationField durationField14 = null;
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        java.lang.String str23 = property22.getAsShortText();
//        int int24 = property22.getMinimumValueOverall();
//        int int25 = property22.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
//        int int29 = dividedDateTimeField28.getMinimumValue();
//        int int32 = dividedDateTimeField28.getDifference((long) 1970, 32L);
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.getDefault();
//        int int36 = dateTimeZone34.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate((long) 1970, dateTimeZone34);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = org.joda.time.format.ISODateTimeFormat.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = dateTimeFormatter38.withPivotYear((java.lang.Integer) 0);
//        java.lang.String str41 = localDate37.toString(dateTimeFormatter40);
//        org.joda.time.ReadableInterval readableInterval42 = null;
//        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval42);
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(chronology43);
//        org.joda.time.DateTime.Property property45 = dateTime44.millisOfSecond();
//        org.joda.time.DateTime dateTime46 = dateTime44.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime47 = localDate37.toDateTime((org.joda.time.ReadableInstant) dateTime44);
//        org.joda.time.DateTimeFieldType dateTimeFieldType48 = null;
//        int int49 = localDate37.indexOf(dateTimeFieldType48);
//        java.util.Locale locale51 = null;
//        java.lang.String str52 = dividedDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate37, (int) (short) 1, locale51);
//        long long54 = dividedDateTimeField28.roundFloor((long) 49);
//        int int57 = dividedDateTimeField28.getDifference((long) 12, 347155200365L);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "24" + "'", str23.equals("24"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-28800000) + "'", int36 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTimeFormatter38);
//        org.junit.Assert.assertNotNull(dateTimeFormatter40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1969" + "'", str41.equals("1969"));
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "1" + "'", str52.equals("1"));
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-1114272000000L) + "'", long54 == (-1114272000000L));
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getMinimumValue((long) (byte) 0);
        boolean boolean8 = delegatedDateTimeField4.isLeap((long) 0);
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField4, 1969);
        int int11 = skipDateTimeField10.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        int int15 = dateTimeZone13.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) 1970, dateTimeZone13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter17.withPivotYear((java.lang.Integer) 0);
        java.lang.String str20 = localDate16.toString(dateTimeFormatter19);
        org.joda.time.ReadableInterval readableInterval21 = null;
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(chronology22);
        org.joda.time.DateTime.Property property24 = dateTime23.millisOfSecond();
        org.joda.time.DateTime dateTime25 = dateTime23.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime26 = localDate16.toDateTime((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.LocalDate.Property property27 = localDate16.dayOfMonth();
        org.joda.time.LocalDate localDate29 = localDate16.withCenturyOfEra(2000);
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.getDefault();
        int int33 = dateTimeZone31.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate((long) 1970, dateTimeZone31);
        org.joda.time.DateMidnight dateMidnight35 = localDate29.toDateMidnight(dateTimeZone31);
        java.util.Locale locale37 = null;
        java.lang.String str38 = skipDateTimeField10.getAsText((org.joda.time.ReadablePartial) localDate29, 19, locale37);
        try {
            org.joda.time.LocalDate localDate40 = localDate29.withDayOfMonth((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-28800000) + "'", int15 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969" + "'", str20.equals("1969"));
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-28800000) + "'", int33 == (-28800000));
        org.junit.Assert.assertNotNull(dateMidnight35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "19" + "'", str38.equals("19"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendLiteral("0");
        boolean boolean10 = dateTimeFormatterBuilder9.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test034");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
//        boolean boolean25 = delegatedDateTimeField24.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) 1970, dateTimeZone27);
//        org.joda.time.LocalDate localDate32 = localDate30.withYear((int) (short) 1);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = delegatedDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDate32, locale33);
//        org.joda.time.DurationField durationField35 = null;
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
//        org.joda.time.DateTime.Property property39 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime.Property property40 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime dateTime42 = dateTime38.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
//        java.lang.String str44 = property43.getAsShortText();
//        int int45 = property43.getMinimumValueOverall();
//        int int46 = property43.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField24, durationField35, dateTimeFieldType47, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType47, 69, 0, 0);
//        org.joda.time.ReadableInterval readableInterval54 = null;
//        org.joda.time.Chronology chronology55 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval54);
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(chronology55);
//        org.joda.time.DateTime.Property property57 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime.Property property58 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime dateTime60 = dateTime56.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property61 = dateTime60.weekOfWeekyear();
//        java.lang.String str62 = property61.getAsShortText();
//        int int63 = property61.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime64 = property61.withMaximumValue();
//        org.joda.time.DurationField durationField65 = property61.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField66 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType47, durationField65);
//        org.joda.time.DurationField durationField67 = unsupportedDateTimeField66.getLeapDurationField();
//        org.joda.time.DateTimeZone dateTimeZone68 = org.joda.time.DateTimeZone.getDefault();
//        int int70 = dateTimeZone68.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate71 = org.joda.time.LocalDate.now(dateTimeZone68);
//        java.util.Locale locale73 = null;
//        java.lang.String str74 = localDate71.toString("000000Z", locale73);
//        org.joda.time.DateTimeFieldType dateTimeFieldType75 = null;
//        int int76 = localDate71.indexOf(dateTimeFieldType75);
//        org.joda.time.DateTimeZone dateTimeZone78 = org.joda.time.DateTimeZone.getDefault();
//        long long81 = dateTimeZone78.adjustOffset(10L, true);
//        org.joda.time.LocalDate localDate82 = new org.joda.time.LocalDate((long) 1969, dateTimeZone78);
//        org.joda.time.LocalDate localDate83 = localDate71.withFields((org.joda.time.ReadablePartial) localDate82);
//        org.joda.time.chrono.CopticChronology copticChronology84 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField85 = copticChronology84.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType86 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField87 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField85, dateTimeFieldType86);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField88 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField85);
//        org.joda.time.DateTimeZone dateTimeZone90 = org.joda.time.DateTimeZone.getDefault();
//        int int92 = dateTimeZone90.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate93 = new org.joda.time.LocalDate((long) 1970, dateTimeZone90);
//        java.util.Locale locale94 = null;
//        java.lang.String str95 = delegatedDateTimeField88.getAsShortText((org.joda.time.ReadablePartial) localDate93, locale94);
//        int int96 = localDate71.compareTo((org.joda.time.ReadablePartial) localDate93);
//        java.util.Locale locale97 = null;
//        try {
//            java.lang.String str98 = unsupportedDateTimeField66.getAsText((org.joda.time.ReadablePartial) localDate93, locale97);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "24" + "'", str44.equals("24"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(chronology55);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "24" + "'", str62.equals("24"));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(durationField65);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField66);
//        org.junit.Assert.assertNull(durationField67);
//        org.junit.Assert.assertNotNull(dateTimeZone68);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-28800000) + "'", int70 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate71);
//        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "000000" + "'", str74.equals("000000"));
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-1) + "'", int76 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeZone78);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 10L + "'", long81 == 10L);
//        org.junit.Assert.assertNotNull(localDate83);
//        org.junit.Assert.assertNotNull(copticChronology84);
//        org.junit.Assert.assertNotNull(dateTimeField85);
//        org.junit.Assert.assertNotNull(dateTimeZone90);
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + (-28800000) + "'", int92 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "69" + "'", str95.equals("69"));
//        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 1 + "'", int96 == 1);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(32L, (-630806399900L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-20185804796800L) + "'", long2 == (-20185804796800L));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(chronology2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(0L, chronology2);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 100, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.Chronology chronology4 = gJChronology1.withUTC();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 1970, dateTimeZone1);
        org.joda.time.LocalDate.Property property5 = localDate4.centuryOfEra();
        org.joda.time.LocalDate localDate6 = property5.roundCeilingCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(132, (-101774), (-70));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-101573) + "'", int3 == (-101573));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 1970, dateTimeZone1);
        org.joda.time.LocalDate localDate6 = localDate4.withYear((int) (short) 1);
        org.joda.time.LocalDate localDate8 = localDate6.withCenturyOfEra(1951);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        int int7 = dateTimeZone5.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate8 = org.joda.time.LocalDate.now(dateTimeZone5);
        org.joda.time.LocalDate.Property property9 = localDate8.centuryOfEra();
        org.joda.time.LocalDate.Property property10 = localDate8.weekOfWeekyear();
        org.joda.time.LocalDate localDate11 = property10.getLocalDate();
        org.joda.time.LocalDate localDate12 = property10.withMinimumValue();
        int[] intArray14 = null;
        try {
            int[] intArray16 = delegatedDateTimeField3.addWrapField((org.joda.time.ReadablePartial) localDate12, 166, intArray14, 20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-28800000) + "'", int7 == (-28800000));
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(localDate12);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime6.plusMillis((-1));
        int int10 = dateTime9.getYearOfCentury();
        org.joda.time.DateTime dateTime12 = dateTime9.minusYears(0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19 + "'", int10 == 19);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        long long4 = dateTimeZone1.adjustOffset(10L, true);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) 1969, dateTimeZone1);
        org.joda.time.DateMidnight dateMidnight6 = localDate5.toDateMidnight();
        int int7 = localDate5.getEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.secondOfDay();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology5);
        org.joda.time.DateTime.Property property7 = dateTime6.millisOfSecond();
        org.joda.time.DateTime dateTime8 = dateTime6.withEarlierOffsetAtOverlap();
        org.joda.time.ReadablePartial readablePartial9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.withFields(readablePartial9);
        boolean boolean11 = copticChronology0.equals((java.lang.Object) dateTime6);
        org.joda.time.DateTimeField dateTimeField12 = copticChronology0.weekOfWeekyear();
        org.joda.time.Partial partial13 = new org.joda.time.Partial((org.joda.time.Chronology) copticChronology0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = partial13.getFormatter();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNull(dateTimeFormatter14);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.junit.Assert.assertNotNull(instant0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendYearOfCentury(2, 12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, (-28800000), (int) 'a', 3, (int) (short) 10, 0, 999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        java.lang.String str4 = dateTimeZone0.getID();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "America/Los_Angeles" + "'", str4.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime6.plusMillis((-1));
        boolean boolean10 = dateTime9.isAfterNow();
        org.joda.time.DateTime dateTime12 = dateTime9.plusYears(86);
        org.joda.time.DateTime dateTime14 = dateTime9.plusSeconds(53);
        org.joda.time.DateTime dateTime16 = dateTime9.plusMinutes((int) '4');
        org.joda.time.DateTime dateTime18 = dateTime16.withMillis((long) 57904);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        java.util.Locale locale5 = null;
        java.lang.String str6 = localDate3.toString("000000Z", locale5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = localDate3.indexOf(dateTimeFieldType7);
        org.joda.time.DateTime dateTime9 = localDate3.toDateTimeAtMidnight();
        org.joda.time.DateTime dateTime11 = dateTime9.plusDays(10);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "000000" + "'", str6.equals("000000"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getMinimumValue((long) (byte) 0);
        boolean boolean8 = delegatedDateTimeField4.isLeap((long) 0);
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField4, 1969);
        int int11 = skipDateTimeField10.getMinimumValue();
        int int13 = skipDateTimeField10.get((long) (short) 1);
        int int15 = skipDateTimeField10.get((long) 10);
        java.lang.String str17 = skipDateTimeField10.getAsText((-31L));
        java.lang.String str18 = skipDateTimeField10.toString();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 86 + "'", int13 == 86);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86 + "'", int15 == 86);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "87" + "'", str17.equals("87"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "DateTimeField[weekyearOfCentury]" + "'", str18.equals("DateTimeField[weekyearOfCentury]"));
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        boolean boolean4 = delegatedDateTimeField3.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
//        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
//        org.joda.time.DurationField durationField14 = null;
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        java.lang.String str23 = property22.getAsShortText();
//        int int24 = property22.getMinimumValueOverall();
//        int int25 = property22.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
//        int int29 = dividedDateTimeField28.getMinimumValue();
//        int int32 = dividedDateTimeField28.getDifference((long) 1970, 32L);
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.getDefault();
//        int int36 = dateTimeZone34.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate((long) 1970, dateTimeZone34);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = org.joda.time.format.ISODateTimeFormat.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = dateTimeFormatter38.withPivotYear((java.lang.Integer) 0);
//        java.lang.String str41 = localDate37.toString(dateTimeFormatter40);
//        org.joda.time.ReadableInterval readableInterval42 = null;
//        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval42);
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(chronology43);
//        org.joda.time.DateTime.Property property45 = dateTime44.millisOfSecond();
//        org.joda.time.DateTime dateTime46 = dateTime44.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime47 = localDate37.toDateTime((org.joda.time.ReadableInstant) dateTime44);
//        org.joda.time.DateTimeFieldType dateTimeFieldType48 = null;
//        int int49 = localDate37.indexOf(dateTimeFieldType48);
//        java.util.Locale locale51 = null;
//        java.lang.String str52 = dividedDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate37, (int) (short) 1, locale51);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField53 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField28);
//        long long56 = remainderDateTimeField53.addWrapField(1L, 52);
//        long long58 = remainderDateTimeField53.roundHalfEven(19692288000002L);
//        int int59 = remainderDateTimeField53.getMaximumValue();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "24" + "'", str23.equals("24"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-28800000) + "'", int36 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTimeFormatter38);
//        org.junit.Assert.assertNotNull(dateTimeFormatter40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1969" + "'", str41.equals("1969"));
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "1" + "'", str52.equals("1"));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1L + "'", long56 == 1L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 19682377200000L + "'", long58 == 19682377200000L);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 51 + "'", int59 == 51);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfMinute((int) 'a');
        boolean boolean5 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendLiteral("000000");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendWeekOfWeekyear(9);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder9.appendTimeZoneOffset("-99136", "GJChronology[UTC]", false, 3675, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.plusMillis((-1));
//        int int10 = dateTime9.getYearOfCentury();
//        int int11 = dateTime9.getHourOfDay();
//        org.joda.time.DateTime.Property property12 = dateTime9.weekOfWeekyear();
//        int int13 = dateTime9.getSecondOfMinute();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19 + "'", int10 == 19);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 16 + "'", int11 == 16);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 13 + "'", int13 == 13);
//    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        long long23 = offsetDateTimeField20.add(1560639843040L, 0);
//        org.joda.time.DurationField durationField24 = offsetDateTimeField20.getDurationField();
//        org.joda.time.DurationField durationField25 = offsetDateTimeField20.getLeapDurationField();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560639843040L + "'", long23 == 1560639843040L);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNull(durationField25);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        try {
            long long9 = gregorianChronology1.getDateTimeMillis(0, 1969, (int) (short) 0, 2019, 70, 51, 2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        boolean boolean4 = delegatedDateTimeField3.isSupported();
        org.joda.time.DateTimeField dateTimeField5 = delegatedDateTimeField3.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate9 = org.joda.time.LocalDate.now(dateTimeZone6);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime12 = localDate9.toDateTimeAtCurrentTime(dateTimeZone11);
        int int13 = localDate9.getCenturyOfEra();
        org.joda.time.LocalDate localDate15 = localDate9.withEra(0);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.LocalDate localDate17 = localDate9.minus(readablePeriod16);
        java.util.Date date18 = localDate17.toDate();
        org.joda.time.LocalDate localDate19 = org.joda.time.LocalDate.fromDateFields(date18);
        org.joda.time.LocalDate localDate21 = localDate19.withYearOfEra((int) ' ');
        int int22 = delegatedDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) localDate21);
        boolean boolean24 = delegatedDateTimeField3.isLeap((long) (short) 10);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        boolean boolean4 = delegatedDateTimeField3.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
//        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
//        org.joda.time.DurationField durationField14 = null;
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        java.lang.String str23 = property22.getAsShortText();
//        int int24 = property22.getMinimumValueOverall();
//        int int25 = property22.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
//        int int31 = dateTimeZone29.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate32 = org.joda.time.LocalDate.now(dateTimeZone29);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = localDate32.toString("000000Z", locale34);
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = null;
//        int int37 = localDate32.indexOf(dateTimeFieldType36);
//        java.lang.String str39 = localDate32.toString("86");
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = dividedDateTimeField28.getAsShortText((org.joda.time.ReadablePartial) localDate32, locale40);
//        org.joda.time.DurationField durationField42 = dividedDateTimeField28.getRangeDurationField();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "24" + "'", str23.equals("24"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-28800000) + "'", int31 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "000000" + "'", str35.equals("000000"));
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "86" + "'", str39.equals("86"));
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "24" + "'", str41.equals("24"));
//        org.junit.Assert.assertNotNull(durationField42);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(chronology1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField4 = gJChronology3.weekyears();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, dateTimeField5, (int) (byte) -1);
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipUndoDateTimeField7.getAsText((int) (byte) 100, locale9);
        long long13 = skipUndoDateTimeField7.set(0L, 10);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100" + "'", str10.equals("100"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10000L + "'", long13 == 10000L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(57600, 51, (-101573), 0, 365, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getMinimumValue((long) (byte) 0);
        boolean boolean8 = delegatedDateTimeField4.isLeap((long) 0);
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField4, 1969);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        long long15 = dateTimeZone12.adjustOffset(10L, true);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) 1969, dateTimeZone12);
        org.joda.time.DateMidnight dateMidnight17 = localDate16.toDateMidnight();
        java.util.Locale locale19 = null;
        java.lang.String str20 = delegatedDateTimeField4.getAsText((org.joda.time.ReadablePartial) localDate16, 100, locale19);
        int int21 = localDate16.getDayOfYear();
        org.joda.time.LocalTime localTime22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone24 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone23);
        boolean boolean26 = cachedDateTimeZone24.isStandardOffset((long) 24);
        long long28 = cachedDateTimeZone24.previousTransition(315676800007L);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) cachedDateTimeZone24);
        org.joda.time.DateTime dateTime30 = localDate16.toDateTime(localTime22, (org.joda.time.DateTimeZone) cachedDateTimeZone24);
        try {
            org.joda.time.DateTime dateTime32 = dateTime30.withMillisOfSecond((-70));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -70 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 365 + "'", int21 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(cachedDateTimeZone24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 309949199999L + "'", long28 == 309949199999L);
        org.junit.Assert.assertNotNull(dateTime30);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.plusMillis((-1));
//        boolean boolean10 = dateTime9.isAfterNow();
//        org.joda.time.DateTime dateTime12 = dateTime9.plusYears(86);
//        org.joda.time.DateTime dateTime14 = dateTime9.plusSeconds(53);
//        org.joda.time.DateTime dateTime16 = dateTime9.plusMinutes((int) '4');
//        java.lang.String str17 = dateTime9.toString();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0019-06-15T16:05:15.359-07:52:58" + "'", str17.equals("0019-06-15T16:05:15.359-07:52:58"));
//    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        long long4 = dateTimeZone1.adjustOffset(10L, true);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) 1969, dateTimeZone1);
//        java.lang.String str7 = dateTimeZone1.getName(1560639843626L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Daylight Time" + "'", str7.equals("Pacific Daylight Time"));
//    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = property7.withMinimumValue();
//        long long9 = property7.remainder();
//        java.lang.String str10 = property7.toString();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 489915546L + "'", long9 == 489915546L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[weekOfWeekyear]" + "'", str10.equals("Property[weekOfWeekyear]"));
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendLiteral("0");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendYearOfCentury(3589, 86);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        long long23 = offsetDateTimeField20.add(1560639843040L, 0);
//        java.lang.String str24 = offsetDateTimeField20.getName();
//        int int26 = offsetDateTimeField20.getLeapAmount(28800132L);
//        long long28 = offsetDateTimeField20.roundHalfEven((long) 49);
//        int int31 = offsetDateTimeField20.getDifference((long) 365, (long) 19);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560639843040L + "'", long23 == 1560639843040L);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "weekOfWeekyear" + "'", str24.equals("weekOfWeekyear"));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-9910800000L) + "'", long28 == (-9910800000L));
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneName(strMap3);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.append(dateTimePrinter5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(strMap3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(55, 0, 70, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        java.util.Locale locale5 = null;
        java.lang.String str6 = localDate3.toString("000000Z", locale5);
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField8 = copticChronology7.weeks();
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology7.getZone();
        org.joda.time.DateMidnight dateMidnight10 = localDate3.toDateMidnight(dateTimeZone9);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(chronology13);
        org.joda.time.DateTime.Property property15 = dateTime14.millisOfSecond();
        org.joda.time.DateTime.Property property16 = dateTime14.millisOfSecond();
        org.joda.time.DateTime dateTime18 = dateTime14.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property19 = dateTime18.weekOfWeekyear();
        org.joda.time.DateTime dateTime21 = dateTime18.plusMillis((-1));
        org.joda.time.DateTime dateTime23 = dateTime21.withMillisOfSecond(100);
        org.joda.time.DateTime dateTime25 = dateTime21.withYear((-1));
        int int26 = dateTime21.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, (org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        try {
            int[] intArray30 = gJChronology27.get(readablePeriod28, 22143600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "000000" + "'", str6.equals("000000"));
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 19 + "'", int26 == 19);
        org.junit.Assert.assertNotNull(gJChronology27);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 53");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 1970, dateTimeZone1);
        org.joda.time.LocalDate localDate6 = localDate4.withYear((int) (short) 1);
        boolean boolean7 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.DateTime dateTime8 = localDate6.toDateTimeAtCurrentTime();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = localDate6.getFieldTypes();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        int int12 = dateTimeZone10.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate13 = org.joda.time.LocalDate.now(dateTimeZone10);
        org.joda.time.LocalDate.Property property14 = localDate13.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        int int17 = dateTimeZone15.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate18 = org.joda.time.LocalDate.now(dateTimeZone15);
        java.lang.String str19 = dateTimeZone15.getID();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTime dateTime21 = localDate13.toDateTimeAtMidnight(dateTimeZone15);
        boolean boolean22 = localDate6.isEqual((org.joda.time.ReadablePartial) localDate13);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-28800000) + "'", int12 == (-28800000));
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-28800000) + "'", int17 == (-28800000));
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "America/Los_Angeles" + "'", str19.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField2 = copticChronology1.weeks();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology1.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField4 = copticChronology1.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology1.era();
//        boolean boolean7 = copticChronology1.equals((java.lang.Object) 22143600000L);
//        org.joda.time.DurationField durationField8 = copticChronology1.eras();
//        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = copticChronology9.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10, dateTimeFieldType11);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        int int17 = dateTimeZone15.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((long) 1970, dateTimeZone15);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = delegatedDateTimeField13.getAsShortText((org.joda.time.ReadablePartial) localDate18, locale19);
//        org.joda.time.LocalDate.Property property21 = localDate18.dayOfMonth();
//        org.joda.time.LocalDate localDate23 = property21.addToCopy((int) 'a');
//        org.joda.time.chrono.CopticChronology copticChronology24 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField25 = copticChronology24.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25, dateTimeFieldType26);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25);
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
//        int int32 = dateTimeZone30.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate((long) 1970, dateTimeZone30);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = delegatedDateTimeField28.getAsShortText((org.joda.time.ReadablePartial) localDate33, locale34);
//        org.joda.time.LocalDate.Property property36 = localDate33.dayOfMonth();
//        org.joda.time.LocalDate localDate38 = property36.addToCopy((int) 'a');
//        boolean boolean39 = localDate23.isBefore((org.joda.time.ReadablePartial) localDate38);
//        org.joda.time.Chronology chronology40 = localDate23.getChronology();
//        org.joda.time.ReadableInterval readableInterval41 = null;
//        org.joda.time.Chronology chronology42 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval41);
//        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime(chronology42);
//        int int44 = dateTime43.getDayOfYear();
//        org.joda.time.ReadableDuration readableDuration45 = null;
//        org.joda.time.DateTime dateTime46 = dateTime43.plus(readableDuration45);
//        org.joda.time.DateTime dateTime48 = dateTime43.plusYears(1970);
//        org.joda.time.ReadableInterval readableInterval49 = null;
//        org.joda.time.Chronology chronology50 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval49);
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime(chronology50);
//        org.joda.time.DateTime.Property property52 = dateTime51.millisOfSecond();
//        org.joda.time.DateTime.Property property53 = dateTime51.millisOfSecond();
//        org.joda.time.DateTime dateTime55 = dateTime51.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property56 = dateTime55.weekOfWeekyear();
//        java.lang.String str57 = property56.getAsShortText();
//        int int58 = property56.getMinimumValueOverall();
//        int int59 = property56.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType60 = property56.getFieldType();
//        org.joda.time.DateTime.Property property61 = dateTime43.property(dateTimeFieldType60);
//        boolean boolean62 = localDate23.isSupported(dateTimeFieldType60);
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField63 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, durationField8, dateTimeFieldType60);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(copticChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-28800000) + "'", int17 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "69" + "'", str20.equals("69"));
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertNotNull(copticChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-28800000) + "'", int32 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "69" + "'", str35.equals("69"));
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(chronology40);
//        org.junit.Assert.assertNotNull(chronology42);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 166 + "'", int44 == 166);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(chronology50);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "24" + "'", str57.equals("24"));
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 52 + "'", int59 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        try {
            long long8 = julianChronology0.getDateTimeMillis(72, 166, 69, (int) ' ', 365, 86, 24);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = property7.addToCopy((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = property7.roundCeilingCopy();
        org.joda.time.DateTime dateTime11 = dateTime10.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.minutes();
        org.joda.time.DurationField durationField3 = iSOChronology0.centuries();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate9, locale10);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.hourOfHalfday();
        org.joda.time.DurationField durationField14 = copticChronology12.millis();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology12, dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        int int20 = dateTimeZone18.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now(dateTimeZone18);
        java.lang.String str22 = dateTimeZone18.getID();
        org.joda.time.Chronology chronology23 = copticChronology12.withZone(dateTimeZone18);
        boolean boolean24 = localDate9.equals((java.lang.Object) copticChronology12);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
        int int27 = dateTimeZone25.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate28 = org.joda.time.LocalDate.now(dateTimeZone25);
        org.joda.time.Chronology chronology29 = copticChronology12.withZone(dateTimeZone25);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology12.weekyearOfCentury();
        try {
            long long36 = copticChronology12.getDateTimeMillis((long) 59, 70, 3589, 2, 2790);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 70 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "69" + "'", str11.equals("69"));
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-28800000) + "'", int20 == (-28800000));
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "America/Los_Angeles" + "'", str22.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-28800000) + "'", int27 == (-28800000));
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfSecond(3589, 0);
        dateTimeFormatterBuilder10.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        boolean boolean4 = delegatedDateTimeField3.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
//        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
//        org.joda.time.DurationField durationField14 = null;
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        java.lang.String str23 = property22.getAsShortText();
//        int int24 = property22.getMinimumValueOverall();
//        int int25 = property22.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
//        long long31 = dividedDateTimeField28.add((long) 2, 12);
//        int int32 = dividedDateTimeField28.getDivisor();
//        long long34 = dividedDateTimeField28.roundFloor(0L);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "24" + "'", str23.equals("24"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 19692288000002L + "'", long31 == 19692288000002L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 52 + "'", int32 == 52);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-1114272000000L) + "'", long34 == (-1114272000000L));
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "1970-W02-3", "CopticChronology[America/Los_Angeles]");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "", "69");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getName(locale9, "86", "24");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfMinute((int) 'a');
        boolean boolean5 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "658", 0, 57600);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfMinute((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMonthOfYear(12);
        boolean boolean7 = dateTimeFormatterBuilder6.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendDayOfYear(12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.secondOfDay();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology5);
        org.joda.time.DateTime.Property property7 = dateTime6.millisOfSecond();
        org.joda.time.DateTime dateTime8 = dateTime6.withEarlierOffsetAtOverlap();
        org.joda.time.ReadablePartial readablePartial9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.withFields(readablePartial9);
        boolean boolean11 = copticChronology0.equals((java.lang.Object) dateTime6);
        org.joda.time.DateTime dateTime13 = dateTime6.withYear((int) (byte) 100);
        org.joda.time.DateTime dateTime14 = dateTime6.toDateTimeISO();
        int int15 = dateTime14.getEra();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        int int9 = dateTimeZone7.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) 1970, dateTimeZone7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter11.withPivotYear((java.lang.Integer) 0);
        java.lang.String str14 = localDate10.toString(dateTimeFormatter13);
        org.joda.time.ReadableInterval readableInterval15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
        org.joda.time.DateTime dateTime19 = dateTime17.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime20 = localDate10.toDateTime((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.LocalDate.Property property21 = localDate10.dayOfMonth();
        org.joda.time.LocalDate localDate23 = localDate10.withCenturyOfEra(2000);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
        int int27 = dateTimeZone25.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate((long) 1970, dateTimeZone25);
        org.joda.time.DateMidnight dateMidnight29 = localDate23.toDateMidnight(dateTimeZone25);
        try {
            org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((int) (short) -1, 6, 2, (-101573), (int) (short) 100, (-101573), dateTimeZone25);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -101573 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-28800000) + "'", int9 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1969" + "'", str14.equals("1969"));
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-28800000) + "'", int27 == (-28800000));
        org.junit.Assert.assertNotNull(dateMidnight29);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        java.util.Locale locale5 = null;
        java.lang.String str6 = localDate3.toString("000000Z", locale5);
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField8 = copticChronology7.weeks();
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology7.getZone();
        org.joda.time.DateMidnight dateMidnight10 = localDate3.toDateMidnight(dateTimeZone9);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
        java.lang.String str12 = buddhistChronology11.toString();
        java.lang.String str13 = buddhistChronology11.toString();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "000000" + "'", str6.equals("000000"));
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str12.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str13.equals("BuddhistChronology[America/Los_Angeles]"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "0070-01-07T15:59:59.100-07:52:58", (int) '4', 57600);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Partial partial1 = new org.joda.time.Partial((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        java.lang.String str8 = property7.getAsShortText();
//        int int9 = property7.getMinimumValueOverall();
//        int int10 = property7.getMaximumValue();
//        int int11 = property7.getLeapAmount();
//        org.joda.time.Instant instant13 = new org.joda.time.Instant((long) ' ');
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        int int16 = dateTimeZone14.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.DateTime dateTime17 = instant13.toDateTime(dateTimeZone14);
//        org.joda.time.MutableDateTime mutableDateTime18 = instant13.toMutableDateTime();
//        boolean boolean19 = property7.equals((java.lang.Object) instant13);
//        org.joda.time.Instant instant21 = instant13.plus((-31449599999L));
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "24" + "'", str8.equals("24"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-28800000) + "'", int16 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(instant21);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getMinimumValue((long) (byte) 0);
        boolean boolean8 = delegatedDateTimeField4.isLeap((long) 0);
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField4, 1969);
        int int11 = skipDateTimeField10.getMinimumValue();
        int int13 = skipDateTimeField10.get((long) (short) 1);
        int int15 = skipDateTimeField10.get((long) 10);
        int int17 = skipDateTimeField10.get((long) 3588);
        java.lang.String str18 = skipDateTimeField10.getName();
        try {
            long long21 = skipDateTimeField10.set((long) (-99136), 57904);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57904 for weekyearOfCentury must be in the range [0,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 86 + "'", int13 == 86);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86 + "'", int15 == 86);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 86 + "'", int17 == 86);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "weekyearOfCentury" + "'", str18.equals("weekyearOfCentury"));
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(0);
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = copticChronology3.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType5);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField6);
//        long long9 = delegatedDateTimeField6.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval10 = null;
//        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
//        org.joda.time.DateTime.Property property13 = dateTime12.millisOfSecond();
//        org.joda.time.DateTime.Property property14 = dateTime12.millisOfSecond();
//        org.joda.time.DateTime dateTime16 = dateTime12.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property17 = dateTime16.weekOfWeekyear();
//        java.lang.String str18 = property17.getAsShortText();
//        int int19 = property17.getMinimumValueOverall();
//        int int20 = property17.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property17.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField6, dateTimeFieldType21, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology24 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField25 = copticChronology24.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25, dateTimeFieldType26);
//        boolean boolean28 = delegatedDateTimeField27.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
//        int int32 = dateTimeZone30.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate((long) 1970, dateTimeZone30);
//        org.joda.time.LocalDate localDate35 = localDate33.withYear((int) (short) 1);
//        java.util.Locale locale36 = null;
//        java.lang.String str37 = delegatedDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate35, locale36);
//        org.joda.time.DurationField durationField38 = null;
//        org.joda.time.ReadableInterval readableInterval39 = null;
//        org.joda.time.Chronology chronology40 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval39);
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime(chronology40);
//        org.joda.time.DateTime.Property property42 = dateTime41.millisOfSecond();
//        org.joda.time.DateTime.Property property43 = dateTime41.millisOfSecond();
//        org.joda.time.DateTime dateTime45 = dateTime41.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property46 = dateTime45.weekOfWeekyear();
//        java.lang.String str47 = property46.getAsShortText();
//        int int48 = property46.getMinimumValueOverall();
//        int int49 = property46.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType50 = property46.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField52 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField27, durationField38, dateTimeFieldType50, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField6, dateTimeFieldType50, 69, 0, 0);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException59 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType50, (java.lang.Number) 0, "69");
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType50, 53, 36, 1970);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType50, 69, (-101573));
//        org.joda.time.IllegalFieldValueException illegalFieldValueException70 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType50, (java.lang.Number) (-1.0f), (java.lang.Number) 10.0f, (java.lang.Number) 315705600007L);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9910800000L) + "'", long9 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "24" + "'", str18.equals("24"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 52 + "'", int20 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(copticChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-28800000) + "'", int32 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1" + "'", str37.equals("1"));
//        org.junit.Assert.assertNotNull(chronology40);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "24" + "'", str47.equals("24"));
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 52 + "'", int49 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType50);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        java.util.Locale locale5 = null;
        java.lang.String str6 = localDate3.toString("000000Z", locale5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = localDate3.indexOf(dateTimeFieldType7);
        org.joda.time.DateTime dateTime9 = localDate3.toDateTimeAtMidnight();
        int int10 = dateTime9.getEra();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "000000" + "'", str6.equals("000000"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
//        boolean boolean25 = delegatedDateTimeField24.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) 1970, dateTimeZone27);
//        org.joda.time.LocalDate localDate32 = localDate30.withYear((int) (short) 1);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = delegatedDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDate32, locale33);
//        org.joda.time.DurationField durationField35 = null;
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
//        org.joda.time.DateTime.Property property39 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime.Property property40 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime dateTime42 = dateTime38.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
//        java.lang.String str44 = property43.getAsShortText();
//        int int45 = property43.getMinimumValueOverall();
//        int int46 = property43.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField24, durationField35, dateTimeFieldType47, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType47, 69, 0, 0);
//        org.joda.time.ReadableInterval readableInterval54 = null;
//        org.joda.time.Chronology chronology55 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval54);
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(chronology55);
//        org.joda.time.DateTime.Property property57 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime.Property property58 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime dateTime60 = dateTime56.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property61 = dateTime60.weekOfWeekyear();
//        java.lang.String str62 = property61.getAsShortText();
//        int int63 = property61.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime64 = property61.withMaximumValue();
//        org.joda.time.DurationField durationField65 = property61.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField66 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType47, durationField65);
//        java.lang.String str67 = unsupportedDateTimeField66.toString();
//        org.joda.time.chrono.GJChronology gJChronology69 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField70 = gJChronology69.weekyears();
//        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime((long) (short) 100, (org.joda.time.Chronology) gJChronology69);
//        org.joda.time.DateTime dateTime73 = dateTime71.withYear((int) (byte) 1);
//        boolean boolean75 = dateTime73.isEqual((-210862267200000L));
//        org.joda.time.DateTime.Property property76 = dateTime73.minuteOfHour();
//        org.joda.time.LocalDate localDate77 = dateTime73.toLocalDate();
//        int[] intArray79 = null;
//        java.util.Locale locale81 = null;
//        try {
//            int[] intArray82 = unsupportedDateTimeField66.set((org.joda.time.ReadablePartial) localDate77, (int) (byte) 100, intArray79, "87", locale81);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "24" + "'", str44.equals("24"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(chronology55);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "24" + "'", str62.equals("24"));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(durationField65);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField66);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "UnsupportedDateTimeField" + "'", str67.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertNotNull(gJChronology69);
//        org.junit.Assert.assertNotNull(durationField70);
//        org.junit.Assert.assertNotNull(dateTime73);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertNotNull(property76);
//        org.junit.Assert.assertNotNull(localDate77);
//    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
//        boolean boolean25 = delegatedDateTimeField24.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) 1970, dateTimeZone27);
//        org.joda.time.LocalDate localDate32 = localDate30.withYear((int) (short) 1);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = delegatedDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDate32, locale33);
//        org.joda.time.DurationField durationField35 = null;
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
//        org.joda.time.DateTime.Property property39 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime.Property property40 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime dateTime42 = dateTime38.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
//        java.lang.String str44 = property43.getAsShortText();
//        int int45 = property43.getMinimumValueOverall();
//        int int46 = property43.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField24, durationField35, dateTimeFieldType47, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType47, 69, 0, 0);
//        java.util.Locale locale55 = null;
//        java.lang.String str56 = offsetDateTimeField53.getAsText((long) 10, locale55);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "24" + "'", str44.equals("24"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "156" + "'", str56.equals("156"));
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        int int5 = delegatedDateTimeField3.getMinimumValue((long) (byte) 0);
        int int6 = delegatedDateTimeField3.getMinimumValue();
        int int8 = delegatedDateTimeField3.getLeapAmount(315705600000L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
//        int int23 = dateTimeZone21.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate24 = org.joda.time.LocalDate.now(dateTimeZone21);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = localDate24.toString("000000Z", locale26);
//        org.joda.time.chrono.CopticChronology copticChronology28 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField29 = copticChronology28.weeks();
//        org.joda.time.DateTimeZone dateTimeZone30 = copticChronology28.getZone();
//        org.joda.time.DateMidnight dateMidnight31 = localDate24.toDateMidnight(dateTimeZone30);
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.LocalDate localDate33 = localDate24.minus(readablePeriod32);
//        org.joda.time.LocalTime localTime34 = null;
//        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone36 = gJChronology35.getZone();
//        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeUtils.getZone(dateTimeZone36);
//        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone36);
//        org.joda.time.DateTime dateTime39 = localDate33.toDateTime(localTime34, dateTimeZone36);
//        int int40 = offsetDateTimeField20.getMaximumValue((org.joda.time.ReadablePartial) localDate33);
//        int int41 = offsetDateTimeField20.getMinimumValue();
//        long long44 = offsetDateTimeField20.add((-599356799900L), (-1L));
//        int int46 = offsetDateTimeField20.get((long) (-28800000));
//        long long48 = offsetDateTimeField20.roundHalfEven((long) 59);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-28800000) + "'", int23 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "000000" + "'", str27.equals("000000"));
//        org.junit.Assert.assertNotNull(copticChronology28);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(dateMidnight31);
//        org.junit.Assert.assertNotNull(localDate33);
//        org.junit.Assert.assertNotNull(gJChronology35);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertNotNull(gregorianChronology38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 3688 + "'", int40 == 3688);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 3589 + "'", int41 == 3589);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-630806399900L) + "'", long44 == (-630806399900L));
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 3675 + "'", int46 == 3675);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-9910800000L) + "'", long48 == (-9910800000L));
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(0, ' ', (int) (short) -1, (int) (short) 0, 0, true, (int) (short) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder0.setStandardOffset(69);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField1 = copticChronology0.weeks();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.secondOfDay();
//        org.joda.time.ReadableInterval readableInterval4 = null;
//        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology5);
//        org.joda.time.DateTime.Property property7 = dateTime6.millisOfSecond();
//        org.joda.time.DateTime dateTime8 = dateTime6.withEarlierOffsetAtOverlap();
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime6.withFields(readablePartial9);
//        boolean boolean11 = copticChronology0.equals((java.lang.Object) dateTime6);
//        org.joda.time.DateTime dateTime13 = dateTime6.withYear((int) (byte) 100);
//        org.joda.time.DateTime dateTime14 = dateTime6.toDateTimeISO();
//        int int15 = dateTime6.getWeekyear();
//        int int16 = dateTime6.getWeekOfWeekyear();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 24 + "'", int16 == 24);
//    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime5 = property3.addWrapFieldToCopy(0);
//        java.util.Locale locale7 = null;
//        org.joda.time.DateTime dateTime8 = property3.setCopy("772", locale7);
//        int int9 = property3.getMaximumValueOverall();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology10);
//        boolean boolean12 = dateTime11.isAfterNow();
//        long long13 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 999 + "'", int9 == 999);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-8L) + "'", long13 == (-8L));
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = gJChronology5.getZone();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        boolean boolean8 = copticChronology0.equals((java.lang.Object) dateTimeZone7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        long long12 = copticChronology0.add(readablePeriod9, (long) 2790, 19);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2790L + "'", long12 == 2790L);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
//        boolean boolean25 = delegatedDateTimeField24.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) 1970, dateTimeZone27);
//        org.joda.time.LocalDate localDate32 = localDate30.withYear((int) (short) 1);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = delegatedDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDate32, locale33);
//        org.joda.time.DurationField durationField35 = null;
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
//        org.joda.time.DateTime.Property property39 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime.Property property40 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime dateTime42 = dateTime38.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
//        java.lang.String str44 = property43.getAsShortText();
//        int int45 = property43.getMinimumValueOverall();
//        int int46 = property43.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField24, durationField35, dateTimeFieldType47, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType47, 69, 0, 0);
//        org.joda.time.ReadableInterval readableInterval54 = null;
//        org.joda.time.Chronology chronology55 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval54);
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(chronology55);
//        org.joda.time.DateTime.Property property57 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime.Property property58 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime dateTime60 = dateTime56.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property61 = dateTime60.weekOfWeekyear();
//        java.lang.String str62 = property61.getAsShortText();
//        int int63 = property61.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime64 = property61.withMaximumValue();
//        org.joda.time.DurationField durationField65 = property61.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField66 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType47, durationField65);
//        org.joda.time.ReadablePartial readablePartial67 = null;
//        java.util.Locale locale68 = null;
//        try {
//            java.lang.String str69 = unsupportedDateTimeField66.getAsShortText(readablePartial67, locale68);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "24" + "'", str44.equals("24"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(chronology55);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "24" + "'", str62.equals("24"));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(durationField65);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField66);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 86, number2, (java.lang.Number) 10);
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException4.getSuppressed();
        java.lang.Number number6 = illegalFieldValueException4.getLowerBound();
        illegalFieldValueException4.prependMessage("America/Los_Angeles");
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        long long6 = gJChronology0.add((long) 1951, (long) 72, 53);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 5767L + "'", long6 == 5767L);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
//        boolean boolean25 = delegatedDateTimeField24.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) 1970, dateTimeZone27);
//        org.joda.time.LocalDate localDate32 = localDate30.withYear((int) (short) 1);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = delegatedDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDate32, locale33);
//        org.joda.time.DurationField durationField35 = null;
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
//        org.joda.time.DateTime.Property property39 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime.Property property40 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime dateTime42 = dateTime38.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
//        java.lang.String str44 = property43.getAsShortText();
//        int int45 = property43.getMinimumValueOverall();
//        int int46 = property43.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField24, durationField35, dateTimeFieldType47, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType47, 69, 0, 0);
//        org.joda.time.ReadableInterval readableInterval54 = null;
//        org.joda.time.Chronology chronology55 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval54);
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(chronology55);
//        org.joda.time.DateTime.Property property57 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime.Property property58 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime dateTime60 = dateTime56.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property61 = dateTime60.weekOfWeekyear();
//        java.lang.String str62 = property61.getAsShortText();
//        int int63 = property61.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime64 = property61.withMaximumValue();
//        org.joda.time.DurationField durationField65 = property61.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField66 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType47, durationField65);
//        java.lang.String str67 = unsupportedDateTimeField66.toString();
//        long long70 = unsupportedDateTimeField66.getDifferenceAsLong(337244400000L, (-9910800000L));
//        try {
//            long long73 = unsupportedDateTimeField66.set(1560639843626L, "3");
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "24" + "'", str44.equals("24"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(chronology55);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "24" + "'", str62.equals("24"));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(durationField65);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField66);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "UnsupportedDateTimeField" + "'", str67.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 11L + "'", long70 == 11L);
//    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
//        boolean boolean25 = delegatedDateTimeField24.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) 1970, dateTimeZone27);
//        org.joda.time.LocalDate localDate32 = localDate30.withYear((int) (short) 1);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = delegatedDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDate32, locale33);
//        org.joda.time.DurationField durationField35 = null;
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
//        org.joda.time.DateTime.Property property39 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime.Property property40 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime dateTime42 = dateTime38.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
//        java.lang.String str44 = property43.getAsShortText();
//        int int45 = property43.getMinimumValueOverall();
//        int int46 = property43.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField24, durationField35, dateTimeFieldType47, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType47, 69, 0, 0);
//        org.joda.time.ReadableInterval readableInterval54 = null;
//        org.joda.time.Chronology chronology55 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval54);
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(chronology55);
//        org.joda.time.DateTime.Property property57 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime.Property property58 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime dateTime60 = dateTime56.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property61 = dateTime60.weekOfWeekyear();
//        java.lang.String str62 = property61.getAsShortText();
//        int int63 = property61.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime64 = property61.withMaximumValue();
//        org.joda.time.DurationField durationField65 = property61.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField66 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType47, durationField65);
//        java.lang.String str67 = unsupportedDateTimeField66.toString();
//        org.joda.time.chrono.CopticChronology copticChronology68 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField69 = copticChronology68.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType70 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField71 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField69, dateTimeFieldType70);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField72 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField69);
//        org.joda.time.DateTimeZone dateTimeZone74 = org.joda.time.DateTimeZone.getDefault();
//        int int76 = dateTimeZone74.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate77 = new org.joda.time.LocalDate((long) 1970, dateTimeZone74);
//        java.util.Locale locale78 = null;
//        java.lang.String str79 = delegatedDateTimeField72.getAsShortText((org.joda.time.ReadablePartial) localDate77, locale78);
//        org.joda.time.LocalDate.Property property80 = localDate77.dayOfMonth();
//        org.joda.time.LocalDate localDate82 = property80.addToCopy((int) 'a');
//        org.joda.time.LocalDate localDate83 = property80.roundCeilingCopy();
//        org.joda.time.ReadableInterval readableInterval84 = null;
//        org.joda.time.Chronology chronology85 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval84);
//        org.joda.time.DateTime dateTime86 = new org.joda.time.DateTime(chronology85);
//        org.joda.time.Partial partial87 = new org.joda.time.Partial(chronology85);
//        org.joda.time.chrono.GJChronology gJChronology88 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField89 = gJChronology88.weekyears();
//        org.joda.time.DateTimeField dateTimeField90 = gJChronology88.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField91 = gJChronology88.yearOfEra();
//        org.joda.time.Partial partial92 = partial87.withChronologyRetainFields((org.joda.time.Chronology) gJChronology88);
//        int[] intArray93 = partial92.getValues();
//        int[] intArray94 = partial92.getValues();
//        try {
//            int int95 = unsupportedDateTimeField66.getMinimumValue((org.joda.time.ReadablePartial) localDate83, intArray94);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "24" + "'", str44.equals("24"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(chronology55);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "24" + "'", str62.equals("24"));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(durationField65);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField66);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "UnsupportedDateTimeField" + "'", str67.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertNotNull(copticChronology68);
//        org.junit.Assert.assertNotNull(dateTimeField69);
//        org.junit.Assert.assertNotNull(dateTimeZone74);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-28800000) + "'", int76 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "69" + "'", str79.equals("69"));
//        org.junit.Assert.assertNotNull(property80);
//        org.junit.Assert.assertNotNull(localDate82);
//        org.junit.Assert.assertNotNull(localDate83);
//        org.junit.Assert.assertNotNull(chronology85);
//        org.junit.Assert.assertNotNull(gJChronology88);
//        org.junit.Assert.assertNotNull(durationField89);
//        org.junit.Assert.assertNotNull(dateTimeField90);
//        org.junit.Assert.assertNotNull(dateTimeField91);
//        org.junit.Assert.assertNotNull(partial92);
//        org.junit.Assert.assertNotNull(intArray93);
//        org.junit.Assert.assertNotNull(intArray94);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology0.era();
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType7);
        boolean boolean9 = delegatedDateTimeField8.isSupported();
        org.joda.time.DateTimeField dateTimeField10 = delegatedDateTimeField8.getWrappedField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField8, 132);
        org.joda.time.DateTimeField dateTimeField13 = copticChronology0.millisOfSecond();
        org.joda.time.Chronology chronology14 = copticChronology0.withUTC();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(chronology14);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfSecond();
        org.joda.time.DateTime.Property property5 = dateTime3.millisOfSecond();
        org.joda.time.DateTime dateTime7 = dateTime3.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime10 = property8.addToCopy((int) (byte) 10);
        boolean boolean11 = julianChronology0.equals((java.lang.Object) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.withSecondOfMinute(0);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime13);
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        long long23 = offsetDateTimeField20.add(1560639843040L, 0);
//        int int24 = offsetDateTimeField20.getOffset();
//        org.joda.time.ReadablePartial readablePartial25 = null;
//        int int26 = offsetDateTimeField20.getMaximumValue(readablePartial25);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate30 = org.joda.time.LocalDate.now(dateTimeZone27);
//        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone32 = gJChronology31.getZone();
//        org.joda.time.DateTime dateTime33 = localDate30.toDateTimeAtCurrentTime(dateTimeZone32);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = offsetDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) localDate30, locale34);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560639843040L + "'", long23 == 1560639843040L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3588 + "'", int24 == 3588);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 3688 + "'", int26 == 3688);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(gJChronology31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "24" + "'", str35.equals("24"));
//    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        boolean boolean4 = delegatedDateTimeField3.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
//        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
//        org.joda.time.DurationField durationField14 = null;
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        java.lang.String str23 = property22.getAsShortText();
//        int int24 = property22.getMinimumValueOverall();
//        int int25 = property22.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
//        int int29 = dividedDateTimeField28.getMinimumValue();
//        int int32 = dividedDateTimeField28.getDifference((long) 1970, 32L);
//        int int35 = dividedDateTimeField28.getDifference(1248L, 1L);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "24" + "'", str23.equals("24"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
//        boolean boolean25 = delegatedDateTimeField24.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) 1970, dateTimeZone27);
//        org.joda.time.LocalDate localDate32 = localDate30.withYear((int) (short) 1);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = delegatedDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDate32, locale33);
//        org.joda.time.DurationField durationField35 = null;
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
//        org.joda.time.DateTime.Property property39 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime.Property property40 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime dateTime42 = dateTime38.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
//        java.lang.String str44 = property43.getAsShortText();
//        int int45 = property43.getMinimumValueOverall();
//        int int46 = property43.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField24, durationField35, dateTimeFieldType47, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType47, 69, 0, 0);
//        org.joda.time.ReadableInterval readableInterval54 = null;
//        org.joda.time.Chronology chronology55 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval54);
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(chronology55);
//        org.joda.time.DateTime.Property property57 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime.Property property58 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime dateTime60 = dateTime56.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property61 = dateTime60.weekOfWeekyear();
//        java.lang.String str62 = property61.getAsShortText();
//        int int63 = property61.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime64 = property61.withMaximumValue();
//        org.joda.time.DurationField durationField65 = property61.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField66 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType47, durationField65);
//        java.lang.String str67 = unsupportedDateTimeField66.toString();
//        try {
//            int int69 = unsupportedDateTimeField66.getMaximumValue(28800052L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "24" + "'", str44.equals("24"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(chronology55);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "24" + "'", str62.equals("24"));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(durationField65);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField66);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "UnsupportedDateTimeField" + "'", str67.equals("UnsupportedDateTimeField"));
//    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        int int3 = dateTime2.getDayOfYear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) dateTime2);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 166 + "'", int3 == 166);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendMillisOfSecond(1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendClockhourOfDay(132);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.appendFractionOfMinute(132, 2019);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(0, ' ', (int) (short) -1, (int) (short) 0, 0, true, (int) (short) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.setFixedSavings("Property[millisOfSecond]", 47);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "72", "19");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = dateTime6.withZone(dateTimeZone7);
        org.joda.time.Instant instant9 = dateTime6.toInstant();
        org.joda.time.DateTime dateTime10 = instant9.toDateTimeISO();
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Instant instant12 = instant9.plus(readableDuration11);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(instant12);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial(chronology1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField5 = gJChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.yearOfEra();
        org.joda.time.Partial partial8 = partial3.withChronologyRetainFields((org.joda.time.Chronology) gJChronology4);
        java.lang.String str9 = partial8.toString();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.Partial partial12 = partial8.withFieldAdded(durationFieldType10, 3589);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(partial8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[]" + "'", str9.equals("[]"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime4 = dateTime2.withEarlierOffsetAtOverlap();
//        org.joda.time.ReadablePartial readablePartial5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.withFields(readablePartial5);
//        int int7 = dateTime2.getYearOfEra();
//        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.hourOfHalfday();
//        org.joda.time.DurationField durationField10 = copticChronology8.millis();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
//        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology8, dateTimeZone11);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone11.getName((long) 1969, locale15);
//        org.joda.time.DateTime dateTime17 = dateTime2.toDateTime(dateTimeZone11);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        int int21 = dateTimeZone19.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) 1970, dateTimeZone19);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter23.withPivotYear((java.lang.Integer) 0);
//        java.lang.String str26 = localDate22.toString(dateTimeFormatter25);
//        org.joda.time.ReadableInterval readableInterval27 = null;
//        org.joda.time.Chronology chronology28 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval27);
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(chronology28);
//        org.joda.time.DateTime.Property property30 = dateTime29.millisOfSecond();
//        org.joda.time.DateTime dateTime31 = dateTime29.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime32 = localDate22.toDateTime((org.joda.time.ReadableInstant) dateTime29);
//        org.joda.time.LocalDate.Property property33 = localDate22.dayOfMonth();
//        org.joda.time.LocalDate localDate35 = localDate22.withCenturyOfEra(2000);
//        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.getDefault();
//        int int39 = dateTimeZone37.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate((long) 1970, dateTimeZone37);
//        org.joda.time.DateMidnight dateMidnight41 = localDate35.toDateMidnight(dateTimeZone37);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((java.lang.Object) dateTime17, dateTimeZone37);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone43 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone37);
//        int int45 = cachedDateTimeZone43.getStandardOffset((long) 132);
//        int int47 = cachedDateTimeZone43.getStandardOffset((long) 3675);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(copticChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
//        org.junit.Assert.assertNotNull(zonedChronology13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Pacific Standard Time" + "'", str16.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-28800000) + "'", int21 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1969" + "'", str26.equals("1969"));
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-28800000) + "'", int39 == (-28800000));
//        org.junit.Assert.assertNotNull(dateMidnight41);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone43);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-28800000) + "'", int45 == (-28800000));
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-28800000) + "'", int47 == (-28800000));
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime4 = dateTime2.withEarlierOffsetAtOverlap();
        org.joda.time.ReadablePartial readablePartial5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.withFields(readablePartial5);
        int int7 = dateTime2.getYearOfEra();
        org.joda.time.DateTime dateTime8 = dateTime2.toDateTimeISO();
        org.joda.time.DateTime.Property property9 = dateTime2.dayOfWeek();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
//        boolean boolean25 = delegatedDateTimeField24.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) 1970, dateTimeZone27);
//        org.joda.time.LocalDate localDate32 = localDate30.withYear((int) (short) 1);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = delegatedDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDate32, locale33);
//        org.joda.time.DurationField durationField35 = null;
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
//        org.joda.time.DateTime.Property property39 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime.Property property40 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime dateTime42 = dateTime38.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
//        java.lang.String str44 = property43.getAsShortText();
//        int int45 = property43.getMinimumValueOverall();
//        int int46 = property43.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField24, durationField35, dateTimeFieldType47, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType47, 69, 0, 0);
//        long long55 = offsetDateTimeField53.roundCeiling((long) (byte) 10);
//        long long57 = offsetDateTimeField53.roundFloor((long) 7);
//        java.util.Locale locale58 = null;
//        int int59 = offsetDateTimeField53.getMaximumTextLength(locale58);
//        long long61 = offsetDateTimeField53.roundHalfFloor((long) (-132));
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "24" + "'", str44.equals("24"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 22143600000L + "'", long55 == 22143600000L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-9910800000L) + "'", long57 == (-9910800000L));
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-9910800000L) + "'", long61 == (-9910800000L));
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfMinute((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMillisOfDay(36);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTimeZoneShortName(strMap7);
        dateTimeFormatterBuilder8.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.hourOfHalfday();
        org.joda.time.DurationField durationField2 = copticChronology0.millis();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone3);
        org.joda.time.Chronology chronology6 = zonedChronology5.withUTC();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        long long6 = dateTimeZone2.getMillisKeepLocal(dateTimeZone3, 0L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-28800000L) + "'", long6 == (-28800000L));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 100, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime7 = dateTime5.plus(0L);
        int int8 = dateTime5.getDayOfMonth();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        boolean boolean4 = delegatedDateTimeField3.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
//        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
//        org.joda.time.DurationField durationField14 = null;
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        java.lang.String str23 = property22.getAsShortText();
//        int int24 = property22.getMinimumValueOverall();
//        int int25 = property22.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
//        int int29 = dividedDateTimeField28.getMinimumValue();
//        int int32 = dividedDateTimeField28.getDifference((long) 1970, 32L);
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.getDefault();
//        int int36 = dateTimeZone34.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate((long) 1970, dateTimeZone34);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = org.joda.time.format.ISODateTimeFormat.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = dateTimeFormatter38.withPivotYear((java.lang.Integer) 0);
//        java.lang.String str41 = localDate37.toString(dateTimeFormatter40);
//        org.joda.time.ReadableInterval readableInterval42 = null;
//        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval42);
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(chronology43);
//        org.joda.time.DateTime.Property property45 = dateTime44.millisOfSecond();
//        org.joda.time.DateTime dateTime46 = dateTime44.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime47 = localDate37.toDateTime((org.joda.time.ReadableInstant) dateTime44);
//        org.joda.time.DateTimeFieldType dateTimeFieldType48 = null;
//        int int49 = localDate37.indexOf(dateTimeFieldType48);
//        java.util.Locale locale51 = null;
//        java.lang.String str52 = dividedDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate37, (int) (short) 1, locale51);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField53 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField28);
//        java.lang.String str55 = remainderDateTimeField53.getAsShortText((-4165258022000L));
//        long long57 = remainderDateTimeField53.roundHalfEven(144000000L);
//        org.joda.time.DurationField durationField58 = remainderDateTimeField53.getDurationField();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "24" + "'", str23.equals("24"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-28800000) + "'", int36 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTimeFormatter38);
//        org.junit.Assert.assertNotNull(dateTimeFormatter40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1969" + "'", str41.equals("1969"));
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "1" + "'", str52.equals("1"));
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "3" + "'", str55.equals("3"));
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-9910800000L) + "'", long57 == (-9910800000L));
//        org.junit.Assert.assertNotNull(durationField58);
//    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        boolean boolean4 = delegatedDateTimeField3.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
//        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
//        org.joda.time.DurationField durationField14 = null;
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        java.lang.String str23 = property22.getAsShortText();
//        int int24 = property22.getMinimumValueOverall();
//        int int25 = property22.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
//        int int31 = dateTimeZone29.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate32 = org.joda.time.LocalDate.now(dateTimeZone29);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = localDate32.toString("000000Z", locale34);
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = null;
//        int int37 = localDate32.indexOf(dateTimeFieldType36);
//        java.lang.String str39 = localDate32.toString("86");
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = dividedDateTimeField28.getAsShortText((org.joda.time.ReadablePartial) localDate32, locale40);
//        org.joda.time.LocalDate localDate43 = localDate32.withYear(57600032);
//        int int44 = localDate32.getWeekyear();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "24" + "'", str23.equals("24"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-28800000) + "'", int31 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "000000" + "'", str35.equals("000000"));
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "86" + "'", str39.equals("86"));
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "24" + "'", str41.equals("24"));
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 86, number2, (java.lang.Number) 10);
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        illegalFieldValueException4.prependMessage("weekOfWeekyear");
        org.junit.Assert.assertNull(durationFieldType5);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        boolean boolean21 = offsetDateTimeField20.isLenient();
//        java.util.Locale locale22 = null;
//        int int23 = offsetDateTimeField20.getMaximumTextLength(locale22);
//        long long25 = offsetDateTimeField20.roundHalfFloor((long) 15);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-9910800000L) + "'", long25 == (-9910800000L));
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("1");
        java.lang.String str2 = jodaTimePermission1.toString();
        try {
            org.joda.time.Instant instant3 = new org.joda.time.Instant((java.lang.Object) str2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"(\"org.joda.time.JodaTimePermissi...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"1\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"1\")"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
        org.joda.time.Chronology chronology2 = buddhistChronology0.withUTC();
        java.lang.String str3 = buddhistChronology0.toString();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str3.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfMinute((int) 'a');
        boolean boolean5 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendLiteral("000000");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendWeekOfWeekyear(9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder9.appendFractionOfDay(20, 51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendClockhourOfDay(4);
        boolean boolean7 = cachedDateTimeZone1.equals((java.lang.Object) dateTimeFormatterBuilder6);
        long long9 = cachedDateTimeZone1.nextTransition((long) 3589);
        int int11 = cachedDateTimeZone1.getOffset((long) 16);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9972000000L + "'", long9 == 9972000000L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        org.joda.time.LocalDate.Property property4 = localDate3.centuryOfEra();
        org.joda.time.LocalTime localTime5 = null;
        org.joda.time.DateTime dateTime6 = localDate3.toDateTime(localTime5);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        java.util.Locale locale8 = null;
        int int9 = property7.getMaximumShortTextLength(locale8);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        boolean boolean4 = delegatedDateTimeField3.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
//        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
//        org.joda.time.DurationField durationField14 = null;
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        java.lang.String str23 = property22.getAsShortText();
//        int int24 = property22.getMinimumValueOverall();
//        int int25 = property22.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
//        long long31 = dividedDateTimeField28.add((long) 2, 12);
//        long long33 = dividedDateTimeField28.remainder(28800132L);
//        int int34 = dividedDateTimeField28.getMaximumValue();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "24" + "'", str23.equals("24"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 19692288000002L + "'", long31 == 19692288000002L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 28800132L + "'", long33 == 28800132L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.parse("156");
        org.junit.Assert.assertNotNull(localDate1);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        java.lang.String str1 = copticChronology0.toString();
        try {
            long long6 = copticChronology0.getDateTimeMillis((int) (short) 100, (-28800000), 20, 20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[UTC]" + "'", str1.equals("CopticChronology[UTC]"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.centuryOfEra();
        org.joda.time.DurationField durationField4 = gJChronology1.days();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(0L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.LocalDate.Property property6 = localDate5.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        int int10 = dateTimeZone8.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) 1970, dateTimeZone8);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter12.withPivotYear((java.lang.Integer) 0);
        java.lang.String str15 = localDate11.toString(dateTimeFormatter14);
        org.joda.time.ReadableInterval readableInterval16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(chronology17);
        org.joda.time.DateTime.Property property19 = dateTime18.millisOfSecond();
        org.joda.time.DateTime dateTime20 = dateTime18.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime21 = localDate11.toDateTime((org.joda.time.ReadableInstant) dateTime18);
        int int22 = localDate11.getYearOfCentury();
        boolean boolean23 = localDate5.isEqual((org.joda.time.ReadablePartial) localDate11);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969" + "'", str15.equals("1969"));
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 69 + "'", int22 == 69);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.parse("772");
        java.util.Date date2 = localDate1.toDate();
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial(chronology1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField5 = gJChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.yearOfEra();
        org.joda.time.Partial partial8 = partial3.withChronologyRetainFields((org.joda.time.Chronology) gJChronology4);
        java.lang.String str10 = partial8.toString("69");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = partial8.getFormatter();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(partial8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "69" + "'", str10.equals("69"));
        org.junit.Assert.assertNull(dateTimeFormatter11);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        java.lang.String str8 = property7.getAsShortText();
//        int int9 = property7.getMinimumValueOverall();
//        int int10 = property7.getMaximumValue();
//        int int11 = property7.getLeapAmount();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property7.getFieldType();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "24" + "'", str8.equals("24"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 57600);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        java.lang.String str5 = property4.getName();
        java.lang.Object obj6 = null;
        boolean boolean7 = property4.equals(obj6);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "millisOfSecond" + "'", str5.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        long long23 = offsetDateTimeField20.add(1560639843040L, 0);
//        java.lang.String str24 = offsetDateTimeField20.toString();
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
//        int int28 = dateTimeZone26.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate((long) 1970, dateTimeZone26);
//        org.joda.time.LocalDate localDate31 = localDate29.withYear((int) (short) 1);
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.LocalDate localDate34 = localDate29.withPeriodAdded(readablePeriod32, (int) '#');
//        java.util.Locale locale36 = null;
//        java.lang.String str37 = offsetDateTimeField20.getAsText((org.joda.time.ReadablePartial) localDate29, (int) (short) 1, locale36);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder38.appendMinuteOfHour((int) (byte) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder38.appendTwoDigitYear((int) '4', true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder43.appendTimeZoneShortName();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap45 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder43.appendTimeZoneShortName(strMap45);
//        org.joda.time.ReadableInterval readableInterval47 = null;
//        org.joda.time.Chronology chronology48 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval47);
//        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime(chronology48);
//        org.joda.time.DateTime.Property property50 = dateTime49.millisOfSecond();
//        org.joda.time.DateTime.Property property51 = dateTime49.millisOfSecond();
//        org.joda.time.DateTime dateTime53 = dateTime49.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property54 = dateTime53.weekOfWeekyear();
//        java.lang.String str55 = property54.getAsShortText();
//        int int56 = property54.getMinimumValueOverall();
//        int int57 = property54.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType58 = property54.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder43.appendFixedDecimal(dateTimeFieldType58, 10);
//        boolean boolean61 = localDate29.isSupported(dateTimeFieldType58);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560639843040L + "'", long23 == 1560639843040L);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str24.equals("DateTimeField[weekOfWeekyear]"));
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-28800000) + "'", int28 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertNotNull(localDate34);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1" + "'", str37.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
//        org.junit.Assert.assertNotNull(chronology48);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "24" + "'", str55.equals("24"));
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 52 + "'", int57 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType58);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime4 = dateTime2.withEarlierOffsetAtOverlap();
//        org.joda.time.ReadablePartial readablePartial5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.withFields(readablePartial5);
//        int int7 = dateTime2.getYearOfEra();
//        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.hourOfHalfday();
//        org.joda.time.DurationField durationField10 = copticChronology8.millis();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
//        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology8, dateTimeZone11);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone11.getName((long) 1969, locale15);
//        org.joda.time.DateTime dateTime17 = dateTime2.toDateTime(dateTimeZone11);
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField19 = gJChronology18.weekyears();
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.centuryOfEra();
//        org.joda.time.DurationField durationField21 = gJChronology18.days();
//        org.joda.time.DateTimeZone dateTimeZone22 = gJChronology18.getZone();
//        org.joda.time.DateTime dateTime23 = dateTime2.toDateTime(dateTimeZone22);
//        org.joda.time.DateTime dateTime25 = dateTime23.withSecondOfMinute((int) ' ');
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(copticChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
//        org.junit.Assert.assertNotNull(zonedChronology13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Pacific Standard Time" + "'", str16.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.minutes();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readableDuration4);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime5);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.hourOfHalfday();
//        org.joda.time.DurationField durationField2 = copticChronology0.millis();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
//        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone3);
//        org.joda.time.ReadableInterval readableInterval6 = null;
//        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(chronology7);
//        org.joda.time.DateTime.Property property9 = dateTime8.millisOfSecond();
//        org.joda.time.DateTime.Property property10 = dateTime8.millisOfSecond();
//        org.joda.time.DateTime dateTime12 = dateTime8.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property13 = dateTime12.weekOfWeekyear();
//        org.joda.time.DateTime dateTime15 = dateTime12.plusMillis((-1));
//        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfSecond(100);
//        java.lang.String str18 = dateTime17.toString();
//        boolean boolean19 = dateTime17.isAfterNow();
//        org.joda.time.DateTime.Property property20 = dateTime17.yearOfEra();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime17.toYearMonthDay();
//        int[] intArray23 = zonedChronology5.get((org.joda.time.ReadablePartial) yearMonthDay21, (long) 3);
//        try {
//            long long31 = zonedChronology5.getDateTimeMillis(12, 2019, 49, 52, 0, 13, (-99136));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertNotNull(zonedChronology5);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0019-06-15T16:05:23.100-07:52:58" + "'", str18.equals("0019-06-15T16:05:23.100-07:52:58"));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertNotNull(intArray23);
//    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        boolean boolean4 = delegatedDateTimeField3.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
//        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
//        org.joda.time.DurationField durationField14 = null;
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        java.lang.String str23 = property22.getAsShortText();
//        int int24 = property22.getMinimumValueOverall();
//        int int25 = property22.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
//        int int29 = dividedDateTimeField28.getMinimumValue();
//        int int32 = dividedDateTimeField28.getDifference((long) 1970, 32L);
//        java.lang.String str33 = dividedDateTimeField28.getName();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "24" + "'", str23.equals("24"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "weekOfWeekyear" + "'", str33.equals("weekOfWeekyear"));
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 115974633600070L, 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneName(strMap3);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendClockhourOfDay(4);
        boolean boolean12 = cachedDateTimeZone6.equals((java.lang.Object) dateTimeFormatterBuilder11);
        long long14 = cachedDateTimeZone6.nextTransition((long) 3589);
        try {
            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatterBuilder2, (org.joda.time.DateTimeZone) cachedDateTimeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatterBuilder");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(strMap3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9972000000L + "'", long14 == 9972000000L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate9, locale10);
        org.joda.time.LocalDate.Property property12 = localDate9.dayOfMonth();
        int int13 = localDate9.getMonthOfYear();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "69" + "'", str11.equals("69"));
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime6.plusMillis((-1));
        boolean boolean10 = dateTime9.isAfterNow();
        java.util.Locale locale11 = null;
        java.util.Calendar calendar12 = dateTime9.toCalendar(locale11);
        try {
            org.joda.time.DateTime dateTime14 = dateTime9.withDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(calendar12);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
        org.joda.time.Chronology chronology2 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.minuteOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("", "0070-01-07T15:59:59.100-07:52:58", (int) '4', 57600);
        org.joda.time.Chronology chronology9 = buddhistChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(gJChronology10);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Partial partial1 = new org.joda.time.Partial((org.joda.time.Chronology) copticChronology0);
        java.lang.String str2 = partial1.toStringList();
        int[] intArray3 = partial1.getValues();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[]" + "'", str2.equals("[]"));
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 1970, dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withPivotYear((java.lang.Integer) 0);
        java.lang.String str8 = localDate4.toString(dateTimeFormatter7);
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(chronology10);
        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
        org.joda.time.DateTime dateTime13 = dateTime11.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = localDate4.toDateTime((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.LocalDate localDate16 = localDate4.plusMonths((-132));
        try {
            org.joda.time.DateTimeField dateTimeField18 = localDate4.getField(166);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 166");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDate16);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (short) -1);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
//        boolean boolean25 = delegatedDateTimeField24.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) 1970, dateTimeZone27);
//        org.joda.time.LocalDate localDate32 = localDate30.withYear((int) (short) 1);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = delegatedDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDate32, locale33);
//        org.joda.time.DurationField durationField35 = null;
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
//        org.joda.time.DateTime.Property property39 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime.Property property40 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime dateTime42 = dateTime38.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
//        java.lang.String str44 = property43.getAsShortText();
//        int int45 = property43.getMinimumValueOverall();
//        int int46 = property43.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField24, durationField35, dateTimeFieldType47, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType47, 69, 0, 0);
//        org.joda.time.ReadableInterval readableInterval54 = null;
//        org.joda.time.Chronology chronology55 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval54);
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(chronology55);
//        org.joda.time.DateTime.Property property57 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime.Property property58 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime dateTime60 = dateTime56.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property61 = dateTime60.weekOfWeekyear();
//        java.lang.String str62 = property61.getAsShortText();
//        int int63 = property61.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime64 = property61.withMaximumValue();
//        org.joda.time.DurationField durationField65 = property61.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField66 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType47, durationField65);
//        org.joda.time.DurationField durationField67 = unsupportedDateTimeField66.getLeapDurationField();
//        org.joda.time.DateTimeZone dateTimeZone69 = org.joda.time.DateTimeZone.getDefault();
//        long long72 = dateTimeZone69.adjustOffset(10L, true);
//        org.joda.time.LocalDate localDate73 = new org.joda.time.LocalDate((long) 1969, dateTimeZone69);
//        org.joda.time.DateMidnight dateMidnight74 = localDate73.toDateMidnight();
//        org.joda.time.LocalDate.Property property75 = localDate73.monthOfYear();
//        org.joda.time.LocalDate localDate76 = property75.roundHalfFloorCopy();
//        java.util.Locale locale78 = null;
//        try {
//            java.lang.String str79 = unsupportedDateTimeField66.getAsText((org.joda.time.ReadablePartial) localDate76, 365, locale78);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "24" + "'", str44.equals("24"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(chronology55);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "24" + "'", str62.equals("24"));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(durationField65);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField66);
//        org.junit.Assert.assertNull(durationField67);
//        org.junit.Assert.assertNotNull(dateTimeZone69);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 10L + "'", long72 == 10L);
//        org.junit.Assert.assertNotNull(dateMidnight74);
//        org.junit.Assert.assertNotNull(property75);
//        org.junit.Assert.assertNotNull(localDate76);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(55);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 55");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime6.plusMillis((-1));
        boolean boolean10 = dateTime9.isAfterNow();
        org.joda.time.DateTime dateTime12 = dateTime9.plusYears(86);
        java.util.GregorianCalendar gregorianCalendar13 = dateTime12.toGregorianCalendar();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(gregorianCalendar13);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test171");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Partial partial3 = new org.joda.time.Partial(chronology1);
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField5 = gJChronology4.weekyears();
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.yearOfEra();
//        org.joda.time.Partial partial8 = partial3.withChronologyRetainFields((org.joda.time.Chronology) gJChronology4);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = partial8.getFieldTypes();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMinuteOfHour((int) (byte) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendClockhourOfDay(4);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendTimeZoneShortName();
//        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField17 = copticChronology16.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType18);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField19);
//        long long22 = delegatedDateTimeField19.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval23 = null;
//        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval23);
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(chronology24);
//        org.joda.time.DateTime.Property property26 = dateTime25.millisOfSecond();
//        org.joda.time.DateTime.Property property27 = dateTime25.millisOfSecond();
//        org.joda.time.DateTime dateTime29 = dateTime25.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property30 = dateTime29.weekOfWeekyear();
//        java.lang.String str31 = property30.getAsShortText();
//        int int32 = property30.getMinimumValueOverall();
//        int int33 = property30.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property30.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField19, dateTimeFieldType34, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology37 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField38 = copticChronology37.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField40 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField38, dateTimeFieldType39);
//        boolean boolean41 = delegatedDateTimeField40.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.getDefault();
//        int int45 = dateTimeZone43.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate46 = new org.joda.time.LocalDate((long) 1970, dateTimeZone43);
//        org.joda.time.LocalDate localDate48 = localDate46.withYear((int) (short) 1);
//        java.util.Locale locale49 = null;
//        java.lang.String str50 = delegatedDateTimeField40.getAsText((org.joda.time.ReadablePartial) localDate48, locale49);
//        org.joda.time.DurationField durationField51 = null;
//        org.joda.time.ReadableInterval readableInterval52 = null;
//        org.joda.time.Chronology chronology53 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval52);
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime(chronology53);
//        org.joda.time.DateTime.Property property55 = dateTime54.millisOfSecond();
//        org.joda.time.DateTime.Property property56 = dateTime54.millisOfSecond();
//        org.joda.time.DateTime dateTime58 = dateTime54.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property59 = dateTime58.weekOfWeekyear();
//        java.lang.String str60 = property59.getAsShortText();
//        int int61 = property59.getMinimumValueOverall();
//        int int62 = property59.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType63 = property59.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField65 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField40, durationField51, dateTimeFieldType63, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField69 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField19, dateTimeFieldType63, 69, 0, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder72 = dateTimeFormatterBuilder14.appendFraction(dateTimeFieldType63, (int) '#', 10);
//        try {
//            org.joda.time.Partial partial74 = partial8.with(dateTimeFieldType63, 132);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 132 for weekOfWeekyear must not be larger than 53");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(partial8);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(copticChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-9910800000L) + "'", long22 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "24" + "'", str31.equals("24"));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 52 + "'", int33 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertNotNull(copticChronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-28800000) + "'", int45 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate48);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "1" + "'", str50.equals("1"));
//        org.junit.Assert.assertNotNull(chronology53);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(property59);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "24" + "'", str60.equals("24"));
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 52 + "'", int62 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType63);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder72);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.LocalDate localDate0 = org.joda.time.LocalDate.now();
        org.joda.time.LocalDate.Property property1 = localDate0.dayOfWeek();
        org.joda.time.LocalDate localDate2 = property1.withMinimumValue();
        org.junit.Assert.assertNotNull(localDate0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(localDate2);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("0019-06-15T16:04:51.100-07:52:58");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"0019-06-15T16:04:51.100-07:52:58/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 57600);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.plus(readableDuration2);
        org.joda.time.Instant instant4 = instant3.toInstant();
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant4);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        boolean boolean4 = delegatedDateTimeField3.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
//        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
//        org.joda.time.DurationField durationField14 = null;
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        java.lang.String str23 = property22.getAsShortText();
//        int int24 = property22.getMinimumValueOverall();
//        int int25 = property22.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
//        int int29 = dividedDateTimeField28.getMinimumValue();
//        long long32 = dividedDateTimeField28.add(0L, 0);
//        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField34 = copticChronology33.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField34, dateTimeFieldType35);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField36);
//        long long39 = delegatedDateTimeField36.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval40 = null;
//        org.joda.time.Chronology chronology41 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval40);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(chronology41);
//        org.joda.time.DateTime.Property property43 = dateTime42.millisOfSecond();
//        org.joda.time.DateTime.Property property44 = dateTime42.millisOfSecond();
//        org.joda.time.DateTime dateTime46 = dateTime42.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property47 = dateTime46.weekOfWeekyear();
//        java.lang.String str48 = property47.getAsShortText();
//        int int49 = property47.getMinimumValueOverall();
//        int int50 = property47.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property47.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField36, dateTimeFieldType51, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology54 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField55 = copticChronology54.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField57 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField55, dateTimeFieldType56);
//        boolean boolean58 = delegatedDateTimeField57.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeZone.getDefault();
//        int int62 = dateTimeZone60.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate63 = new org.joda.time.LocalDate((long) 1970, dateTimeZone60);
//        org.joda.time.LocalDate localDate65 = localDate63.withYear((int) (short) 1);
//        java.util.Locale locale66 = null;
//        java.lang.String str67 = delegatedDateTimeField57.getAsText((org.joda.time.ReadablePartial) localDate65, locale66);
//        org.joda.time.DurationField durationField68 = null;
//        org.joda.time.ReadableInterval readableInterval69 = null;
//        org.joda.time.Chronology chronology70 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval69);
//        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime(chronology70);
//        org.joda.time.DateTime.Property property72 = dateTime71.millisOfSecond();
//        org.joda.time.DateTime.Property property73 = dateTime71.millisOfSecond();
//        org.joda.time.DateTime dateTime75 = dateTime71.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property76 = dateTime75.weekOfWeekyear();
//        java.lang.String str77 = property76.getAsShortText();
//        int int78 = property76.getMinimumValueOverall();
//        int int79 = property76.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType80 = property76.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField82 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField57, durationField68, dateTimeFieldType80, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField86 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField36, dateTimeFieldType80, 69, 0, 0);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException89 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType80, (java.lang.Number) 0, "69");
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField90 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField28, dateTimeFieldType80);
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType80, 1969, (int) (short) -1, 13);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for weekOfWeekyear must be in the range [-1,13]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "24" + "'", str23.equals("24"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//        org.junit.Assert.assertNotNull(copticChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-9910800000L) + "'", long39 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology41);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "24" + "'", str48.equals("24"));
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 52 + "'", int50 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType51);
//        org.junit.Assert.assertNotNull(copticChronology54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone60);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-28800000) + "'", int62 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate65);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "1" + "'", str67.equals("1"));
//        org.junit.Assert.assertNotNull(chronology70);
//        org.junit.Assert.assertNotNull(property72);
//        org.junit.Assert.assertNotNull(property73);
//        org.junit.Assert.assertNotNull(dateTime75);
//        org.junit.Assert.assertNotNull(property76);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "24" + "'", str77.equals("24"));
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 52 + "'", int79 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType80);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(0L, "0070-01-07T15:59:59.100-07:52:58");
        boolean boolean3 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalInstantException2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test177");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        java.lang.String str2 = iSOChronology0.toString();
//        org.joda.time.ReadableInterval readableInterval3 = null;
//        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(chronology4);
//        org.joda.time.DateTime.Property property6 = dateTime5.millisOfSecond();
//        org.joda.time.DateTime dateTime8 = property6.addWrapFieldToCopy(0);
//        org.joda.time.DateTime dateTime10 = property6.addToCopy(132);
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField12 = copticChronology11.weeks();
//        org.joda.time.DateTimeField dateTimeField13 = copticChronology11.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField14 = copticChronology11.secondOfDay();
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime19 = dateTime17.withEarlierOffsetAtOverlap();
//        org.joda.time.ReadablePartial readablePartial20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime17.withFields(readablePartial20);
//        boolean boolean22 = copticChronology11.equals((java.lang.Object) dateTime17);
//        org.joda.time.DateTime dateTime24 = dateTime17.withYear((int) (byte) 100);
//        org.joda.time.DateTime dateTime25 = dateTime17.toDateTimeISO();
//        int int26 = dateTime17.getSecondOfDay();
//        boolean boolean27 = dateTime10.isBefore((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean28 = iSOChronology0.equals((java.lang.Object) dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str2.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 57925 + "'", int26 == 57925);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendMillisOfSecond((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendMillisOfDay(999);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        try {
            long long7 = gJChronology0.getDateTimeMillis((int) ' ', 6, 0, 70);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 100, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((org.joda.time.Chronology) gJChronology1);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) ' ');
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime3 = instant1.toDateTimeISO();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        java.util.TimeZone timeZone3 = dateTimeZone1.toTimeZone();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant4, 3);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.weekyearOfCentury();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test184");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
//        boolean boolean25 = delegatedDateTimeField24.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) 1970, dateTimeZone27);
//        org.joda.time.LocalDate localDate32 = localDate30.withYear((int) (short) 1);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = delegatedDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDate32, locale33);
//        org.joda.time.DurationField durationField35 = null;
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
//        org.joda.time.DateTime.Property property39 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime.Property property40 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime dateTime42 = dateTime38.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
//        java.lang.String str44 = property43.getAsShortText();
//        int int45 = property43.getMinimumValueOverall();
//        int int46 = property43.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField24, durationField35, dateTimeFieldType47, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType47, 69, 0, 0);
//        org.joda.time.ReadableInterval readableInterval54 = null;
//        org.joda.time.Chronology chronology55 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval54);
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(chronology55);
//        org.joda.time.DateTime.Property property57 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime.Property property58 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime dateTime60 = dateTime56.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property61 = dateTime60.weekOfWeekyear();
//        java.lang.String str62 = property61.getAsShortText();
//        int int63 = property61.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime64 = property61.withMaximumValue();
//        org.joda.time.DurationField durationField65 = property61.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField66 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType47, durationField65);
//        org.joda.time.DurationField durationField67 = unsupportedDateTimeField66.getLeapDurationField();
//        org.joda.time.DateTimeZone dateTimeZone68 = org.joda.time.DateTimeZone.getDefault();
//        int int70 = dateTimeZone68.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate71 = org.joda.time.LocalDate.now(dateTimeZone68);
//        org.joda.time.chrono.GJChronology gJChronology72 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone73 = gJChronology72.getZone();
//        org.joda.time.DateTime dateTime74 = localDate71.toDateTimeAtCurrentTime(dateTimeZone73);
//        int int75 = localDate71.getCenturyOfEra();
//        org.joda.time.LocalDate localDate77 = localDate71.withEra(0);
//        org.joda.time.ReadablePeriod readablePeriod78 = null;
//        org.joda.time.LocalDate localDate79 = localDate71.minus(readablePeriod78);
//        java.util.Date date80 = localDate79.toDate();
//        org.joda.time.LocalDate localDate81 = org.joda.time.LocalDate.fromDateFields(date80);
//        org.joda.time.ReadableInterval readableInterval82 = null;
//        org.joda.time.Chronology chronology83 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval82);
//        org.joda.time.DateTime dateTime84 = new org.joda.time.DateTime(chronology83);
//        org.joda.time.Partial partial85 = new org.joda.time.Partial(chronology83);
//        org.joda.time.chrono.GJChronology gJChronology86 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField87 = gJChronology86.weekyears();
//        org.joda.time.DateTimeField dateTimeField88 = gJChronology86.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField89 = gJChronology86.yearOfEra();
//        org.joda.time.Partial partial90 = partial85.withChronologyRetainFields((org.joda.time.Chronology) gJChronology86);
//        int[] intArray91 = partial90.getValues();
//        int[] intArray92 = partial90.getValues();
//        try {
//            int int93 = unsupportedDateTimeField66.getMinimumValue((org.joda.time.ReadablePartial) localDate81, intArray92);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "24" + "'", str44.equals("24"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(chronology55);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "24" + "'", str62.equals("24"));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(durationField65);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField66);
//        org.junit.Assert.assertNull(durationField67);
//        org.junit.Assert.assertNotNull(dateTimeZone68);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-28800000) + "'", int70 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate71);
//        org.junit.Assert.assertNotNull(gJChronology72);
//        org.junit.Assert.assertNotNull(dateTimeZone73);
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 20 + "'", int75 == 20);
//        org.junit.Assert.assertNotNull(localDate77);
//        org.junit.Assert.assertNotNull(localDate79);
//        org.junit.Assert.assertNotNull(date80);
//        org.junit.Assert.assertNotNull(localDate81);
//        org.junit.Assert.assertNotNull(chronology83);
//        org.junit.Assert.assertNotNull(gJChronology86);
//        org.junit.Assert.assertNotNull(durationField87);
//        org.junit.Assert.assertNotNull(dateTimeField88);
//        org.junit.Assert.assertNotNull(dateTimeField89);
//        org.junit.Assert.assertNotNull(partial90);
//        org.junit.Assert.assertNotNull(intArray91);
//        org.junit.Assert.assertNotNull(intArray92);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        try {
            int[] intArray3 = julianChronology0.get(readablePeriod1, (long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test186");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = localDate3.toString("000000Z", locale5);
//        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField8 = copticChronology7.weeks();
//        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology7.getZone();
//        org.joda.time.DateMidnight dateMidnight10 = localDate3.toDateMidnight(dateTimeZone9);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.LocalDate localDate12 = localDate3.minus(readablePeriod11);
//        int int13 = localDate12.getWeekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
//        org.joda.time.DateTime dateTime17 = localDate12.toDateTimeAtStartOfDay(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "000000" + "'", str6.equals("000000"));
//        org.junit.Assert.assertNotNull(copticChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 86, number2, (java.lang.Number) 10);
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException4.getSuppressed();
        java.lang.String str6 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.String str7 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        org.joda.time.LocalDate.Property property4 = localDate3.centuryOfEra();
        org.joda.time.LocalTime localTime5 = null;
        org.joda.time.DateTime dateTime6 = localDate3.toDateTime(localTime5);
        org.joda.time.DateTime dateTime8 = dateTime6.plusDays((-132));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        boolean boolean3 = cachedDateTimeZone1.isStandardOffset((long) 24);
        long long5 = cachedDateTimeZone1.previousTransition(315676800007L);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) cachedDateTimeZone1);
        boolean boolean7 = cachedDateTimeZone1.isFixed();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 309949199999L + "'", long5 == 309949199999L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getMinimumValue((long) (byte) 0);
        boolean boolean8 = delegatedDateTimeField4.isLeap((long) 0);
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField4, 1969);
        int int11 = skipDateTimeField10.getMinimumValue();
        int int13 = skipDateTimeField10.get((long) (short) 1);
        int int15 = skipDateTimeField10.get((long) 86);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipDateTimeField10.getAsText(3675, locale17);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 86 + "'", int13 == 86);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86 + "'", int15 == 86);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "3675" + "'", str18.equals("3675"));
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.lang.String str4 = dateTimeZone2.getName(32L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.secondOfDay();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology5);
        org.joda.time.DateTime.Property property7 = dateTime6.millisOfSecond();
        org.joda.time.DateTime dateTime8 = dateTime6.withEarlierOffsetAtOverlap();
        org.joda.time.ReadablePartial readablePartial9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.withFields(readablePartial9);
        boolean boolean11 = copticChronology0.equals((java.lang.Object) dateTime6);
        org.joda.time.DateTimeField dateTimeField12 = copticChronology0.weekOfWeekyear();
        java.lang.String str13 = copticChronology0.toString();
        int int14 = copticChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = copticChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField16 = copticChronology0.minuteOfDay();
        java.lang.String str17 = copticChronology0.toString();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str13.equals("CopticChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str17.equals("CopticChronology[America/Los_Angeles]"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendWeekyear(15, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear((int) '#', false);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendText(dateTimeFieldType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendDayOfWeek(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 100, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime7 = dateTime5.plus(0L);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMinutes(4);
        long long10 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime5);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62104234021900L) + "'", long10 == (-62104234021900L));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate9, locale10);
        org.joda.time.LocalDate.Property property12 = localDate9.dayOfMonth();
        org.joda.time.LocalDate localDate14 = property12.addToCopy((int) 'a');
        int int15 = property12.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "69" + "'", str11.equals("69"));
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 31 + "'", int15 == 31);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        long long4 = dateTimeZone1.adjustOffset(10L, true);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) 1969, dateTimeZone1);
        org.joda.time.DateMidnight dateMidnight6 = localDate5.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        long long11 = dateTimeZone8.adjustOffset(10L, true);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) 1969, dateTimeZone8);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) dateMidnight6, dateTimeZone8);
        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(property14);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test199");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        boolean boolean4 = delegatedDateTimeField3.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
//        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
//        org.joda.time.DurationField durationField14 = null;
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        java.lang.String str23 = property22.getAsShortText();
//        int int24 = property22.getMinimumValueOverall();
//        int int25 = property22.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
//        long long31 = dividedDateTimeField28.add((long) 2, 12);
//        long long33 = dividedDateTimeField28.remainder(28800132L);
//        long long36 = dividedDateTimeField28.getDifferenceAsLong(315705600000L, 0L);
//        long long38 = dividedDateTimeField28.roundHalfEven(1969L);
//        long long40 = dividedDateTimeField28.remainder(0L);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "24" + "'", str23.equals("24"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 19692288000002L + "'", long31 == 19692288000002L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 28800132L + "'", long33 == 28800132L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 526546800000L + "'", long38 == 526546800000L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.weeks();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.DurationField durationField4 = copticChronology0.years();
        org.joda.time.DurationField durationField5 = copticChronology0.months();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("JulianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"JulianChronology[America/Los_Ang...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getMinimumValue((long) (byte) 0);
        boolean boolean8 = delegatedDateTimeField4.isLeap((long) 0);
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField4, 1969);
        int int11 = skipDateTimeField10.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        int int15 = dateTimeZone13.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) 1970, dateTimeZone13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter17.withPivotYear((java.lang.Integer) 0);
        java.lang.String str20 = localDate16.toString(dateTimeFormatter19);
        org.joda.time.ReadableInterval readableInterval21 = null;
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(chronology22);
        org.joda.time.DateTime.Property property24 = dateTime23.millisOfSecond();
        org.joda.time.DateTime dateTime25 = dateTime23.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime26 = localDate16.toDateTime((org.joda.time.ReadableInstant) dateTime23);
        boolean boolean27 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate16);
        java.util.Locale locale29 = null;
        java.lang.String str30 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate16, (-99136), locale29);
        int[] intArray31 = localDate16.getValues();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-28800000) + "'", int15 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969" + "'", str20.equals("1969"));
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "-99136" + "'", str30.equals("-99136"));
        org.junit.Assert.assertNotNull(intArray31);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneShortName();
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime5 = property3.addWrapFieldToCopy(0);
//        org.joda.time.DateTime dateTime7 = property3.addToCopy(132);
//        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField9 = copticChronology8.weeks();
//        org.joda.time.DateTimeField dateTimeField10 = copticChronology8.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology8.secondOfDay();
//        org.joda.time.ReadableInterval readableInterval12 = null;
//        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(chronology13);
//        org.joda.time.DateTime.Property property15 = dateTime14.millisOfSecond();
//        org.joda.time.DateTime dateTime16 = dateTime14.withEarlierOffsetAtOverlap();
//        org.joda.time.ReadablePartial readablePartial17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime14.withFields(readablePartial17);
//        boolean boolean19 = copticChronology8.equals((java.lang.Object) dateTime14);
//        org.joda.time.DateTime dateTime21 = dateTime14.withYear((int) (byte) 100);
//        org.joda.time.DateTime dateTime22 = dateTime14.toDateTimeISO();
//        int int23 = dateTime14.getSecondOfDay();
//        boolean boolean24 = dateTime7.isBefore((org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTime dateTime26 = dateTime7.withSecondOfMinute(0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(copticChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 57927 + "'", int23 == 57927);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(dateTime26);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        int int5 = delegatedDateTimeField3.getMinimumValue((long) (byte) 0);
        boolean boolean7 = delegatedDateTimeField3.isLeap((long) 0);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField3.getRangeDurationField();
        org.joda.time.ReadablePartial readablePartial9 = null;
        int[] intArray11 = null;
        try {
            int[] intArray13 = delegatedDateTimeField3.add(readablePartial9, (int) '#', intArray11, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) '4', (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendSecondOfDay(13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("100", number1, (java.lang.Number) 100, (java.lang.Number) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertNull(durationFieldType5);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 86, number2, (java.lang.Number) 10);
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test209");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        boolean boolean4 = delegatedDateTimeField3.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
//        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
//        org.joda.time.DurationField durationField14 = null;
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        java.lang.String str23 = property22.getAsShortText();
//        int int24 = property22.getMinimumValueOverall();
//        int int25 = property22.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
//        int int31 = dateTimeZone29.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate32 = org.joda.time.LocalDate.now(dateTimeZone29);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = localDate32.toString("000000Z", locale34);
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = null;
//        int int37 = localDate32.indexOf(dateTimeFieldType36);
//        java.lang.String str39 = localDate32.toString("86");
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = dividedDateTimeField28.getAsShortText((org.joda.time.ReadablePartial) localDate32, locale40);
//        java.util.Locale locale43 = null;
//        java.lang.String str44 = dividedDateTimeField28.getAsText((long) 1, locale43);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField45 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField28);
//        int int46 = dividedDateTimeField28.getMaximumValue();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "24" + "'", str23.equals("24"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-28800000) + "'", int31 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "000000" + "'", str35.equals("000000"));
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "86" + "'", str39.equals("86"));
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "24" + "'", str41.equals("24"));
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "1" + "'", str44.equals("1"));
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test211");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay(4);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneShortName();
//        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField7 = copticChronology6.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField9);
//        long long12 = delegatedDateTimeField9.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval13 = null;
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval13);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(chronology14);
//        org.joda.time.DateTime.Property property16 = dateTime15.millisOfSecond();
//        org.joda.time.DateTime.Property property17 = dateTime15.millisOfSecond();
//        org.joda.time.DateTime dateTime19 = dateTime15.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property20 = dateTime19.weekOfWeekyear();
//        java.lang.String str21 = property20.getAsShortText();
//        int int22 = property20.getMinimumValueOverall();
//        int int23 = property20.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property20.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField9, dateTimeFieldType24, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology27 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField28 = copticChronology27.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField28, dateTimeFieldType29);
//        boolean boolean31 = delegatedDateTimeField30.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.getDefault();
//        int int35 = dateTimeZone33.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) 1970, dateTimeZone33);
//        org.joda.time.LocalDate localDate38 = localDate36.withYear((int) (short) 1);
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = delegatedDateTimeField30.getAsText((org.joda.time.ReadablePartial) localDate38, locale39);
//        org.joda.time.DurationField durationField41 = null;
//        org.joda.time.ReadableInterval readableInterval42 = null;
//        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval42);
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(chronology43);
//        org.joda.time.DateTime.Property property45 = dateTime44.millisOfSecond();
//        org.joda.time.DateTime.Property property46 = dateTime44.millisOfSecond();
//        org.joda.time.DateTime dateTime48 = dateTime44.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property49 = dateTime48.weekOfWeekyear();
//        java.lang.String str50 = property49.getAsShortText();
//        int int51 = property49.getMinimumValueOverall();
//        int int52 = property49.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property49.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField55 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField30, durationField41, dateTimeFieldType53, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField9, dateTimeFieldType53, 69, 0, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder4.appendFraction(dateTimeFieldType53, (int) '#', 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder62.appendTimeZoneShortName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder64.appendMinuteOfHour((int) (byte) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder64.appendClockhourOfDay(4);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder68.appendTimeZoneShortName();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap70 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder71 = dateTimeFormatterBuilder68.appendTimeZoneShortName(strMap70);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder72 = dateTimeFormatterBuilder63.appendTimeZoneShortName(strMap70);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(copticChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-9910800000L) + "'", long12 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "24" + "'", str21.equals("24"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 52 + "'", int23 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertNotNull(copticChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-28800000) + "'", int35 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1" + "'", str40.equals("1"));
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "24" + "'", str50.equals("24"));
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 52 + "'", int52 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
//        org.junit.Assert.assertNotNull(strMap70);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder71);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder72);
//    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test212");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField1 = copticChronology0.weeks();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = copticChronology0.era();
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone6 = gJChronology5.getZone();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
//        boolean boolean8 = copticChronology0.equals((java.lang.Object) dateTimeZone7);
//        long long11 = dateTimeZone7.convertLocalToUTC((long) 132, false);
//        long long15 = dateTimeZone7.convertLocalToUTC((long) '#', false, (long) (-28800000));
//        org.joda.time.ReadableInterval readableInterval16 = null;
//        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval16);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(chronology17);
//        org.joda.time.DateTime.Property property19 = dateTime18.millisOfSecond();
//        org.joda.time.DateTime.Property property20 = dateTime18.millisOfSecond();
//        org.joda.time.DateTime dateTime22 = dateTime18.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property23 = dateTime22.weekOfWeekyear();
//        org.joda.time.DateTime dateTime25 = dateTime22.plusMillis((-1));
//        org.joda.time.DateTime dateTime27 = dateTime25.withMillisOfSecond(100);
//        int int28 = dateTime27.getDayOfYear();
//        org.joda.time.Chronology chronology29 = dateTime27.getChronology();
//        int int30 = dateTimeZone7.getOffset((org.joda.time.ReadableInstant) dateTime27);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800132L + "'", long11 == 28800132L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800035L + "'", long15 == 28800035L);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 166 + "'", int28 == 166);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-28378000) + "'", int30 == (-28378000));
//    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test213");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        java.lang.String str8 = property7.getAsShortText();
//        int int9 = property7.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime10 = property7.withMaximumValue();
//        org.joda.time.DateTime dateTime11 = property7.roundHalfCeilingCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property7.getFieldType();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "24" + "'", str8.equals("24"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMonths((int) (byte) 10);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Partial partial1 = new org.joda.time.Partial((org.joda.time.Chronology) copticChronology0);
        java.lang.String str2 = partial1.toStringList();
        int int3 = partial1.size();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[]" + "'", str2.equals("[]"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test216");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        java.lang.String str8 = property7.getAsShortText();
//        int int9 = property7.getMaximumValueOverall();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "24" + "'", str8.equals("24"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(57925, 47, 3688, 59, (int) (byte) 1, 53, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test218");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.plusMillis((-1));
//        boolean boolean10 = dateTime9.isAfterNow();
//        org.joda.time.DateTime dateTime12 = dateTime9.plusYears(86);
//        org.joda.time.DateTime dateTime14 = dateTime9.plusSeconds(53);
//        org.joda.time.DateTime dateTime16 = dateTime9.plusMinutes((int) '4');
//        long long17 = dateTime16.getMillis();
//        int int18 = dateTime16.getMinuteOfDay();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61553257773346L) + "'", long17 == (-61553257773346L));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1017 + "'", int18 == 1017);
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (short) -1);
        org.joda.time.DateTime dateTime5 = instant1.toDateTime(dateTimeZone2);
        boolean boolean7 = dateTime5.equals((java.lang.Object) 0.0d);
        long long8 = dateTime5.getMillis();
        org.joda.time.DateTime dateTime10 = dateTime5.plus((-599356799900L));
        org.joda.time.DateTime dateTime12 = dateTime5.withCenturyOfEra((int) '#');
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(489915546L, (long) (-101573));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -49762191753858");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (short) -1);
        org.joda.time.DateTime dateTime5 = instant1.toDateTime(dateTimeZone2);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTime.Property property7 = dateTime5.era();
        org.joda.time.DateTime.Property property8 = dateTime5.monthOfYear();
        org.joda.time.DateTime dateTime10 = dateTime5.plusSeconds(0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        int int5 = delegatedDateTimeField3.getMinimumValue((long) (byte) 0);
        boolean boolean6 = delegatedDateTimeField3.isSupported();
        int int7 = delegatedDateTimeField3.getMinimumValue();
        long long9 = delegatedDateTimeField3.roundHalfFloor((long) 86);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9910800000L) + "'", long9 == (-9910800000L));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test224");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        boolean boolean4 = delegatedDateTimeField3.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
//        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
//        org.joda.time.DurationField durationField14 = null;
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        java.lang.String str23 = property22.getAsShortText();
//        int int24 = property22.getMinimumValueOverall();
//        int int25 = property22.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
//        int int31 = dateTimeZone29.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate32 = org.joda.time.LocalDate.now(dateTimeZone29);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = localDate32.toString("000000Z", locale34);
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = null;
//        int int37 = localDate32.indexOf(dateTimeFieldType36);
//        java.lang.String str39 = localDate32.toString("86");
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = dividedDateTimeField28.getAsShortText((org.joda.time.ReadablePartial) localDate32, locale40);
//        java.util.Locale locale43 = null;
//        java.lang.String str44 = dividedDateTimeField28.getAsText((long) 1, locale43);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField45 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField28);
//        org.joda.time.DateTimeField dateTimeField46 = delegatedDateTimeField45.getWrappedField();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "24" + "'", str23.equals("24"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-28800000) + "'", int31 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "000000" + "'", str35.equals("000000"));
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "86" + "'", str39.equals("86"));
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "24" + "'", str41.equals("24"));
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "1" + "'", str44.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeField46);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "0070-01-07T15:59:59.100-07:52:58", (int) '4', 57600);
        long long6 = fixedDateTimeZone4.previousTransition(0L);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendWeekyear(15, (int) (short) 100);
        dateTimeFormatterBuilder6.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
//        int int23 = dateTimeZone21.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate24 = org.joda.time.LocalDate.now(dateTimeZone21);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = localDate24.toString("000000Z", locale26);
//        org.joda.time.chrono.CopticChronology copticChronology28 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField29 = copticChronology28.weeks();
//        org.joda.time.DateTimeZone dateTimeZone30 = copticChronology28.getZone();
//        org.joda.time.DateMidnight dateMidnight31 = localDate24.toDateMidnight(dateTimeZone30);
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.LocalDate localDate33 = localDate24.minus(readablePeriod32);
//        org.joda.time.LocalTime localTime34 = null;
//        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone36 = gJChronology35.getZone();
//        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeUtils.getZone(dateTimeZone36);
//        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone36);
//        org.joda.time.DateTime dateTime39 = localDate33.toDateTime(localTime34, dateTimeZone36);
//        int int40 = offsetDateTimeField20.getMaximumValue((org.joda.time.ReadablePartial) localDate33);
//        int int41 = offsetDateTimeField20.getMinimumValue();
//        try {
//            long long44 = offsetDateTimeField20.set((long) 4, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [3589,3688]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-28800000) + "'", int23 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "000000" + "'", str27.equals("000000"));
//        org.junit.Assert.assertNotNull(copticChronology28);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(dateMidnight31);
//        org.junit.Assert.assertNotNull(localDate33);
//        org.junit.Assert.assertNotNull(gJChronology35);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertNotNull(gregorianChronology38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 3688 + "'", int40 == 3688);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 3589 + "'", int41 == 3589);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "0070-01-07T15:59:59.100-07:52:58", (int) '4', 57600);
        long long6 = fixedDateTimeZone4.previousTransition(0L);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal(0L);
        int int10 = fixedDateTimeZone4.getOffsetFromLocal((-2618784000000L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.String str1 = julianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str1.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test230");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate9, locale10);
//        org.joda.time.LocalDate.Property property12 = localDate9.dayOfMonth();
//        java.lang.String str13 = property12.getAsText();
//        org.joda.time.ReadableInterval readableInterval14 = null;
//        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval14);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(chronology15);
//        org.joda.time.DateTime.Property property17 = dateTime16.millisOfSecond();
//        org.joda.time.DateTime.Property property18 = dateTime16.millisOfSecond();
//        org.joda.time.DateTime dateTime20 = dateTime16.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property21 = dateTime20.weekOfWeekyear();
//        org.joda.time.DateTime dateTime23 = property21.addToCopy((int) (byte) 10);
//        org.joda.time.DateTime dateTime24 = property21.roundCeilingCopy();
//        int int25 = property12.getDifference((org.joda.time.ReadableInstant) dateTime24);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "69" + "'", str11.equals("69"));
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31" + "'", str13.equals("31"));
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 712419 + "'", int25 == 712419);
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (short) -1);
        org.joda.time.DateTime dateTime5 = instant1.toDateTime(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime6 = instant1.toMutableDateTime();
        org.joda.time.Instant instant8 = instant1.withMillis((long) 132);
        org.joda.time.Chronology chronology9 = instant1.getChronology();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(chronology9);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test232");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        boolean boolean4 = delegatedDateTimeField3.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
//        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
//        org.joda.time.DurationField durationField14 = null;
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        java.lang.String str23 = property22.getAsShortText();
//        int int24 = property22.getMinimumValueOverall();
//        int int25 = property22.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
//        int int29 = dividedDateTimeField28.getMinimumValue();
//        long long32 = dividedDateTimeField28.add(0L, 0);
//        boolean boolean33 = dividedDateTimeField28.isSupported();
//        try {
//            long long36 = dividedDateTimeField28.add((long) ' ', 22143600000L);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 1151467200000");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "24" + "'", str23.equals("24"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        long long4 = dateTimeZone1.adjustOffset(10L, true);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) 1969, dateTimeZone1);
        org.joda.time.DateMidnight dateMidnight6 = localDate5.toDateMidnight();
        org.joda.time.LocalDate.Property property7 = localDate5.monthOfYear();
        org.joda.time.LocalDate localDate8 = property7.roundFloorCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate8);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        org.joda.time.LocalDate.Property property4 = localDate3.centuryOfEra();
        org.joda.time.LocalDate.Property property5 = localDate3.weekOfWeekyear();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfSecond();
        org.joda.time.DateTime.Property property10 = dateTime8.millisOfSecond();
        org.joda.time.DateTime dateTime12 = dateTime8.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property13 = dateTime12.weekOfWeekyear();
        org.joda.time.DateTime dateTime15 = dateTime12.plusMillis((-1));
        boolean boolean16 = dateTime15.isAfterNow();
        org.joda.time.DateTime dateTime18 = dateTime15.plusYears(86);
        org.joda.time.DateTime dateTime20 = dateTime15.plusSeconds(53);
        org.joda.time.DateTime dateTime22 = dateTime15.plusMinutes((int) '4');
        int int23 = property5.getDifference((org.joda.time.ReadableInstant) dateTime22);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 104354 + "'", int23 == 104354);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = dateTime6.withZone(dateTimeZone7);
        try {
            org.joda.time.DateTime dateTime10 = dateTime8.withMonthOfYear((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test237");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay(4);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMonthOfYear(1970);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendMinuteOfHour((int) (byte) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendClockhourOfDay(4);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendTimeZoneShortName();
//        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = copticChronology13.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType15);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField17 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField16);
//        long long19 = delegatedDateTimeField16.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval20 = null;
//        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval20);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(chronology21);
//        org.joda.time.DateTime.Property property23 = dateTime22.millisOfSecond();
//        org.joda.time.DateTime.Property property24 = dateTime22.millisOfSecond();
//        org.joda.time.DateTime dateTime26 = dateTime22.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property27 = dateTime26.weekOfWeekyear();
//        java.lang.String str28 = property27.getAsShortText();
//        int int29 = property27.getMinimumValueOverall();
//        int int30 = property27.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property27.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField16, dateTimeFieldType31, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology34 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField35 = copticChronology34.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField35, dateTimeFieldType36);
//        boolean boolean38 = delegatedDateTimeField37.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
//        int int42 = dateTimeZone40.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate((long) 1970, dateTimeZone40);
//        org.joda.time.LocalDate localDate45 = localDate43.withYear((int) (short) 1);
//        java.util.Locale locale46 = null;
//        java.lang.String str47 = delegatedDateTimeField37.getAsText((org.joda.time.ReadablePartial) localDate45, locale46);
//        org.joda.time.DurationField durationField48 = null;
//        org.joda.time.ReadableInterval readableInterval49 = null;
//        org.joda.time.Chronology chronology50 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval49);
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime(chronology50);
//        org.joda.time.DateTime.Property property52 = dateTime51.millisOfSecond();
//        org.joda.time.DateTime.Property property53 = dateTime51.millisOfSecond();
//        org.joda.time.DateTime dateTime55 = dateTime51.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property56 = dateTime55.weekOfWeekyear();
//        java.lang.String str57 = property56.getAsShortText();
//        int int58 = property56.getMinimumValueOverall();
//        int int59 = property56.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType60 = property56.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField62 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField37, durationField48, dateTimeFieldType60, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField16, dateTimeFieldType60, 69, 0, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder11.appendFraction(dateTimeFieldType60, (int) '#', 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter70 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder71 = dateTimeFormatterBuilder11.append(dateTimeFormatter70);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder72 = dateTimeFormatterBuilder71.appendTimeZoneId();
//        org.joda.time.format.DateTimePrinter dateTimePrinter73 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter74 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeParser dateTimeParser75 = dateTimeFormatter74.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter76 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter73, dateTimeParser75);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder77 = dateTimeFormatterBuilder71.append(dateTimeParser75);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder78 = dateTimeFormatterBuilder6.append(dateTimeParser75);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder80 = dateTimeFormatterBuilder6.appendSecondOfDay(3588);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(copticChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-9910800000L) + "'", long19 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "24" + "'", str28.equals("24"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 52 + "'", int30 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(copticChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-28800000) + "'", int42 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "1" + "'", str47.equals("1"));
//        org.junit.Assert.assertNotNull(chronology50);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "24" + "'", str57.equals("24"));
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 52 + "'", int59 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType60);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
//        org.junit.Assert.assertNotNull(dateTimeFormatter70);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder71);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder72);
//        org.junit.Assert.assertNotNull(dateTimeFormatter74);
//        org.junit.Assert.assertNotNull(dateTimeParser75);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder77);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder78);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder80);
//    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test238");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
//        long long6 = gJChronology0.add((long) 1951, (long) 72, 53);
//        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8, dateTimeFieldType9);
//        boolean boolean11 = delegatedDateTimeField10.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
//        int int15 = dateTimeZone13.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) 1970, dateTimeZone13);
//        org.joda.time.LocalDate localDate18 = localDate16.withYear((int) (short) 1);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = delegatedDateTimeField10.getAsText((org.joda.time.ReadablePartial) localDate18, locale19);
//        org.joda.time.DurationField durationField21 = null;
//        org.joda.time.ReadableInterval readableInterval22 = null;
//        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval22);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(chronology23);
//        org.joda.time.DateTime.Property property25 = dateTime24.millisOfSecond();
//        org.joda.time.DateTime.Property property26 = dateTime24.millisOfSecond();
//        org.joda.time.DateTime dateTime28 = dateTime24.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property29 = dateTime28.weekOfWeekyear();
//        java.lang.String str30 = property29.getAsShortText();
//        int int31 = property29.getMinimumValueOverall();
//        int int32 = property29.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property29.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField10, durationField21, dateTimeFieldType33, 52);
//        int int36 = dividedDateTimeField35.getMinimumValue();
//        int int39 = dividedDateTimeField35.getDifference((long) 1970, 32L);
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.getDefault();
//        int int43 = dateTimeZone41.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate((long) 1970, dateTimeZone41);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = org.joda.time.format.ISODateTimeFormat.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter47 = dateTimeFormatter45.withPivotYear((java.lang.Integer) 0);
//        java.lang.String str48 = localDate44.toString(dateTimeFormatter47);
//        org.joda.time.ReadableInterval readableInterval49 = null;
//        org.joda.time.Chronology chronology50 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval49);
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime(chronology50);
//        org.joda.time.DateTime.Property property52 = dateTime51.millisOfSecond();
//        org.joda.time.DateTime dateTime53 = dateTime51.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime54 = localDate44.toDateTime((org.joda.time.ReadableInstant) dateTime51);
//        org.joda.time.DateTimeFieldType dateTimeFieldType55 = null;
//        int int56 = localDate44.indexOf(dateTimeFieldType55);
//        java.util.Locale locale58 = null;
//        java.lang.String str59 = dividedDateTimeField35.getAsText((org.joda.time.ReadablePartial) localDate44, (int) (short) 1, locale58);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField60 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField35);
//        long long63 = remainderDateTimeField60.addWrapField(1L, 52);
//        long long65 = remainderDateTimeField60.roundHalfEven(19692288000002L);
//        org.joda.time.DurationField durationField66 = remainderDateTimeField60.getRangeDurationField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField67 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) remainderDateTimeField60);
//        long long69 = remainderDateTimeField60.roundCeiling((long) 7);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 5767L + "'", long6 == 5767L);
//        org.junit.Assert.assertNotNull(copticChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-28800000) + "'", int15 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1" + "'", str20.equals("1"));
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "24" + "'", str30.equals("24"));
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 52 + "'", int32 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-28800000) + "'", int43 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTimeFormatter45);
//        org.junit.Assert.assertNotNull(dateTimeFormatter47);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1969" + "'", str48.equals("1969"));
//        org.junit.Assert.assertNotNull(chronology50);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "1" + "'", str59.equals("1"));
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1L + "'", long63 == 1L);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 19682377200000L + "'", long65 == 19682377200000L);
//        org.junit.Assert.assertNotNull(durationField66);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 22143600000L + "'", long69 == 22143600000L);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.String str1 = julianChronology0.toString();
        org.joda.time.DurationField durationField2 = julianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str1.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.LocalDate localDate0 = org.joda.time.LocalDate.now();
        org.joda.time.LocalDate.Property property1 = localDate0.dayOfWeek();
        int int2 = localDate0.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        int int5 = dateTimeZone3.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now(dateTimeZone3);
        java.util.Locale locale8 = null;
        java.lang.String str9 = localDate6.toString("000000Z", locale8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        int int11 = localDate6.indexOf(dateTimeFieldType10);
        boolean boolean12 = localDate0.isEqual((org.joda.time.ReadablePartial) localDate6);
        org.junit.Assert.assertNotNull(localDate0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "000000" + "'", str9.equals("000000"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (short) 0);
        java.lang.Appendable appendable3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        int int6 = dateTimeZone4.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate7 = org.joda.time.LocalDate.now(dateTimeZone4);
        java.util.Locale locale9 = null;
        java.lang.String str10 = localDate7.toString("000000Z", locale9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        int int12 = localDate7.indexOf(dateTimeFieldType11);
        org.joda.time.DateTime dateTime13 = localDate7.toDateTimeAtMidnight();
        try {
            dateTimeFormatter0.printTo(appendable3, (org.joda.time.ReadableInstant) dateTime13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-28800000) + "'", int6 == (-28800000));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "000000" + "'", str10.equals("000000"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial(chronology1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField5 = gJChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.yearOfEra();
        org.joda.time.Partial partial8 = partial3.withChronologyRetainFields((org.joda.time.Chronology) gJChronology4);
        java.lang.String str10 = partial8.toString("69");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray11 = partial8.getFieldTypes();
        org.joda.time.DurationFieldType durationFieldType12 = null;
        try {
            org.joda.time.Partial partial14 = partial8.withFieldAdded(durationFieldType12, 57600);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(partial8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "69" + "'", str10.equals("69"));
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray11);
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test244");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
//        org.joda.time.Chronology chronology2 = buddhistChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.minuteOfDay();
//        org.joda.time.DurationField durationField4 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfDay(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendMonthOfYear(0);
//        org.joda.time.ReadableInterval readableInterval10 = null;
//        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
//        int int13 = dateTime12.getDayOfYear();
//        org.joda.time.ReadableDuration readableDuration14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime12.plus(readableDuration14);
//        org.joda.time.DateTime dateTime17 = dateTime12.plusYears(1970);
//        org.joda.time.ReadableInterval readableInterval18 = null;
//        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval18);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(chronology19);
//        org.joda.time.DateTime.Property property21 = dateTime20.millisOfSecond();
//        org.joda.time.DateTime.Property property22 = dateTime20.millisOfSecond();
//        org.joda.time.DateTime dateTime24 = dateTime20.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property25 = dateTime24.weekOfWeekyear();
//        java.lang.String str26 = property25.getAsShortText();
//        int int27 = property25.getMinimumValueOverall();
//        int int28 = property25.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property25.getFieldType();
//        org.joda.time.DateTime.Property property30 = dateTime12.property(dateTimeFieldType29);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder9.appendShortText(dateTimeFieldType29);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField33 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, durationField4, dateTimeFieldType29, 52);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 3588, (java.lang.Number) (-1808582400000L), (java.lang.Number) 32L);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 166 + "'", int13 == 166);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "24" + "'", str26.equals("24"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 52 + "'", int28 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime4 = dateTime2.withEarlierOffsetAtOverlap();
        org.joda.time.ReadablePartial readablePartial5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.withFields(readablePartial5);
        int int7 = dateTime2.getYearOfEra();
        org.joda.time.DateTime dateTime8 = dateTime2.toDateTimeISO();
        org.joda.time.DateTime dateTime9 = dateTime2.toDateTimeISO();
        org.joda.time.DateTime dateTime10 = dateTime2.withTimeAtStartOfDay();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = dateTime2.toDateTime(dateTimeZone11);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.minutes();
        org.joda.time.Instant instant4 = new org.joda.time.Instant((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        int int7 = dateTimeZone5.getOffsetFromLocal((long) (short) -1);
        org.joda.time.DateTime dateTime8 = instant4.toDateTime(dateTimeZone5);
        long long9 = instant4.getMillis();
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) instant4);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Instant instant12 = instant4.minus(readableDuration11);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-28800000) + "'", int7 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 32L + "'", long9 == 32L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(instant12);
    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test247");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
//        boolean boolean25 = delegatedDateTimeField24.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) 1970, dateTimeZone27);
//        org.joda.time.LocalDate localDate32 = localDate30.withYear((int) (short) 1);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = delegatedDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDate32, locale33);
//        org.joda.time.DurationField durationField35 = null;
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
//        org.joda.time.DateTime.Property property39 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime.Property property40 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime dateTime42 = dateTime38.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
//        java.lang.String str44 = property43.getAsShortText();
//        int int45 = property43.getMinimumValueOverall();
//        int int46 = property43.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField24, durationField35, dateTimeFieldType47, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType47, 69, 0, 0);
//        org.joda.time.ReadableInterval readableInterval54 = null;
//        org.joda.time.Chronology chronology55 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval54);
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(chronology55);
//        org.joda.time.DateTime.Property property57 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime.Property property58 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime dateTime60 = dateTime56.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property61 = dateTime60.weekOfWeekyear();
//        java.lang.String str62 = property61.getAsShortText();
//        int int63 = property61.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime64 = property61.withMaximumValue();
//        org.joda.time.DurationField durationField65 = property61.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField66 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType47, durationField65);
//        java.lang.String str67 = unsupportedDateTimeField66.toString();
//        long long70 = unsupportedDateTimeField66.add(0L, 5767L);
//        try {
//            int int71 = unsupportedDateTimeField66.getMinimumValue();
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "24" + "'", str44.equals("24"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(chronology55);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "24" + "'", str62.equals("24"));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(durationField65);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField66);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "UnsupportedDateTimeField" + "'", str67.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 181989158400000L + "'", long70 == 181989158400000L);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        java.lang.String str2 = iSOChronology0.toString();
        org.joda.time.DurationField durationField3 = iSOChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.weekyear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str2.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test249");
//        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) ' ');
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = gJChronology2.getZone();
//        long long8 = gJChronology2.add((long) 1951, (long) 72, 53);
//        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = copticChronology9.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10, dateTimeFieldType11);
//        boolean boolean13 = delegatedDateTimeField12.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        int int17 = dateTimeZone15.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((long) 1970, dateTimeZone15);
//        org.joda.time.LocalDate localDate20 = localDate18.withYear((int) (short) 1);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = delegatedDateTimeField12.getAsText((org.joda.time.ReadablePartial) localDate20, locale21);
//        org.joda.time.DurationField durationField23 = null;
//        org.joda.time.ReadableInterval readableInterval24 = null;
//        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval24);
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(chronology25);
//        org.joda.time.DateTime.Property property27 = dateTime26.millisOfSecond();
//        org.joda.time.DateTime.Property property28 = dateTime26.millisOfSecond();
//        org.joda.time.DateTime dateTime30 = dateTime26.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property31 = dateTime30.weekOfWeekyear();
//        java.lang.String str32 = property31.getAsShortText();
//        int int33 = property31.getMinimumValueOverall();
//        int int34 = property31.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property31.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField12, durationField23, dateTimeFieldType35, 52);
//        int int38 = dividedDateTimeField37.getMinimumValue();
//        int int41 = dividedDateTimeField37.getDifference((long) 1970, 32L);
//        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.getDefault();
//        int int45 = dateTimeZone43.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate46 = new org.joda.time.LocalDate((long) 1970, dateTimeZone43);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter47 = org.joda.time.format.ISODateTimeFormat.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = dateTimeFormatter47.withPivotYear((java.lang.Integer) 0);
//        java.lang.String str50 = localDate46.toString(dateTimeFormatter49);
//        org.joda.time.ReadableInterval readableInterval51 = null;
//        org.joda.time.Chronology chronology52 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval51);
//        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime(chronology52);
//        org.joda.time.DateTime.Property property54 = dateTime53.millisOfSecond();
//        org.joda.time.DateTime dateTime55 = dateTime53.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime56 = localDate46.toDateTime((org.joda.time.ReadableInstant) dateTime53);
//        org.joda.time.DateTimeFieldType dateTimeFieldType57 = null;
//        int int58 = localDate46.indexOf(dateTimeFieldType57);
//        java.util.Locale locale60 = null;
//        java.lang.String str61 = dividedDateTimeField37.getAsText((org.joda.time.ReadablePartial) localDate46, (int) (short) 1, locale60);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField62 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField37);
//        long long65 = remainderDateTimeField62.addWrapField(1L, 52);
//        long long67 = remainderDateTimeField62.roundHalfEven(19692288000002L);
//        org.joda.time.DurationField durationField68 = remainderDateTimeField62.getRangeDurationField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField69 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) remainderDateTimeField62);
//        long long72 = remainderDateTimeField62.addWrapField((long) 86, (-70));
//        int int73 = instant1.get((org.joda.time.DateTimeField) remainderDateTimeField62);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 5767L + "'", long8 == 5767L);
//        org.junit.Assert.assertNotNull(copticChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-28800000) + "'", int17 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1" + "'", str22.equals("1"));
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "24" + "'", str32.equals("24"));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 52 + "'", int34 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-28800000) + "'", int45 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTimeFormatter47);
//        org.junit.Assert.assertNotNull(dateTimeFormatter49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "1969" + "'", str50.equals("1969"));
//        org.junit.Assert.assertNotNull(chronology52);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "1" + "'", str61.equals("1"));
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1L + "'", long65 == 1L);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 19682377200000L + "'", long67 == 19682377200000L);
//        org.junit.Assert.assertNotNull(durationField68);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + (-567907199914L) + "'", long72 == (-567907199914L));
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 35 + "'", int73 == 35);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (short) -1);
        org.joda.time.DateTime dateTime5 = instant1.toDateTime(dateTimeZone2);
        boolean boolean7 = dateTime5.equals((java.lang.Object) 0.0d);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(0L, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField13 = gJChronology12.weekyears();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology12.centuryOfEra();
        org.joda.time.DurationField durationField15 = gJChronology12.days();
        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTime11, (java.lang.Object) gJChronology12);
        boolean boolean17 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(3, 2019, 20, (int) (short) 0, 1686);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1686 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        long long4 = dateTimeZone1.adjustOffset(10L, true);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) 1969, dateTimeZone1);
        try {
            org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test253");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
//        boolean boolean25 = delegatedDateTimeField24.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) 1970, dateTimeZone27);
//        org.joda.time.LocalDate localDate32 = localDate30.withYear((int) (short) 1);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = delegatedDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDate32, locale33);
//        org.joda.time.DurationField durationField35 = null;
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
//        org.joda.time.DateTime.Property property39 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime.Property property40 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime dateTime42 = dateTime38.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
//        java.lang.String str44 = property43.getAsShortText();
//        int int45 = property43.getMinimumValueOverall();
//        int int46 = property43.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField24, durationField35, dateTimeFieldType47, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType47, 69, 0, 0);
//        org.joda.time.ReadableInterval readableInterval54 = null;
//        org.joda.time.Chronology chronology55 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval54);
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(chronology55);
//        org.joda.time.DateTime.Property property57 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime.Property property58 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime dateTime60 = dateTime56.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property61 = dateTime60.weekOfWeekyear();
//        java.lang.String str62 = property61.getAsShortText();
//        int int63 = property61.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime64 = property61.withMaximumValue();
//        org.joda.time.DurationField durationField65 = property61.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField66 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType47, durationField65);
//        java.lang.String str67 = unsupportedDateTimeField66.toString();
//        java.util.Locale locale68 = null;
//        try {
//            int int69 = unsupportedDateTimeField66.getMaximumShortTextLength(locale68);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "24" + "'", str44.equals("24"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(chronology55);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "24" + "'", str62.equals("24"));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(durationField65);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField66);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "UnsupportedDateTimeField" + "'", str67.equals("UnsupportedDateTimeField"));
//    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test254");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.plusMillis((-1));
//        org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfSecond(100);
//        java.lang.String str12 = dateTime11.toString();
//        boolean boolean13 = dateTime11.isAfterNow();
//        org.joda.time.DateTime.Property property14 = dateTime11.yearOfEra();
//        org.joda.time.YearMonthDay yearMonthDay15 = dateTime11.toYearMonthDay();
//        org.joda.time.LocalDate localDate17 = org.joda.time.LocalDate.parse("772");
//        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = copticChronology18.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19, dateTimeFieldType20);
//        boolean boolean22 = delegatedDateTimeField21.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
//        int int26 = dateTimeZone24.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate((long) 1970, dateTimeZone24);
//        org.joda.time.LocalDate localDate29 = localDate27.withYear((int) (short) 1);
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = delegatedDateTimeField21.getAsText((org.joda.time.ReadablePartial) localDate29, locale30);
//        org.joda.time.DurationField durationField32 = null;
//        org.joda.time.ReadableInterval readableInterval33 = null;
//        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval33);
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(chronology34);
//        org.joda.time.DateTime.Property property36 = dateTime35.millisOfSecond();
//        org.joda.time.DateTime.Property property37 = dateTime35.millisOfSecond();
//        org.joda.time.DateTime dateTime39 = dateTime35.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property40 = dateTime39.weekOfWeekyear();
//        java.lang.String str41 = property40.getAsShortText();
//        int int42 = property40.getMinimumValueOverall();
//        int int43 = property40.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property40.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField21, durationField32, dateTimeFieldType44, 52);
//        int int47 = localDate17.get(dateTimeFieldType44);
//        int int48 = yearMonthDay15.indexOf(dateTimeFieldType44);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0019-06-15T16:05:32.100-07:52:58" + "'", str12.equals("0019-06-15T16:05:32.100-07:52:58"));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(yearMonthDay15);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(copticChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-28800000) + "'", int26 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1" + "'", str31.equals("1"));
//        org.junit.Assert.assertNotNull(chronology34);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "24" + "'", str41.equals("24"));
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 52 + "'", int43 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType44);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 52 + "'", int47 == 52);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime5 = property3.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime7 = property3.addToCopy(132);
        org.joda.time.DateTime dateTime8 = dateTime7.toDateTimeISO();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.weeks();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology0.yearOfCentury();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder5.addCutover(0, ' ', (int) (short) -1, (int) (short) 0, 0, true, (int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTimeZoneBuilder5.toDateTimeZone("weekyearOfCentury", true);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone18 = gJChronology17.getZone();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
        long long21 = dateTimeZone16.getMillisKeepLocal(dateTimeZone18, (long) 51);
        org.joda.time.Chronology chronology22 = copticChronology0.withZone(dateTimeZone16);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28800051L + "'", long21 == 28800051L);
        org.junit.Assert.assertNotNull(chronology22);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyear();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology4.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        int int12 = dateTimeZone10.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 1970, dateTimeZone10);
        java.util.Locale locale14 = null;
        java.lang.String str15 = delegatedDateTimeField8.getAsShortText((org.joda.time.ReadablePartial) localDate13, locale14);
        java.util.Locale locale16 = null;
        int int17 = delegatedDateTimeField8.getMaximumShortTextLength(locale16);
        int int20 = delegatedDateTimeField8.getDifference(1560639843626L, (long) (short) 0);
        org.joda.time.DateTimeField dateTimeField21 = delegatedDateTimeField8.getWrappedField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField8, (int) (short) 10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-28800000) + "'", int12 == (-28800000));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "69" + "'", str15.equals("69"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 49 + "'", int20 == 49);
        org.junit.Assert.assertNotNull(dateTimeField21);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
        java.io.Writer writer3 = null;
        try {
            dateTimeFormatter2.printTo(writer3, (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        int int5 = delegatedDateTimeField3.getMinimumValue((long) (byte) 0);
        int int6 = delegatedDateTimeField3.getMinimumValue();
        int int7 = delegatedDateTimeField3.getMinimumValue();
        long long9 = delegatedDateTimeField3.roundHalfCeiling((long) 19);
        java.lang.String str10 = delegatedDateTimeField3.getName();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9910800000L) + "'", long9 == (-9910800000L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "weekyearOfCentury" + "'", str10.equals("weekyearOfCentury"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial(chronology1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField5 = gJChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.yearOfEra();
        org.joda.time.Partial partial8 = partial3.withChronologyRetainFields((org.joda.time.Chronology) gJChronology4);
        java.lang.String str10 = partial8.toString("69");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray11 = partial8.getFieldTypes();
        int int12 = partial8.size();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(partial8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "69" + "'", str10.equals("69"));
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("0070-01-07T15:59:59.100-07:52:58");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '0070-01-07T15:59:59.100-07:52:58' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfMinute((int) 'a');
        boolean boolean5 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendLiteral("000000");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendWeekOfWeekyear(1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendMillisOfSecond(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test263");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.plusMillis((-1));
//        int int10 = dateTime9.getYearOfCentury();
//        int int11 = dateTime9.getSecondOfMinute();
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.hourOfHalfday();
//        org.joda.time.DurationField durationField14 = copticChronology12.millis();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
//        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology12, dateTimeZone15);
//        org.joda.time.DateTime dateTime18 = dateTime9.withZone(dateTimeZone15);
//        int int19 = dateTime18.getMillisOfSecond();
//        org.joda.time.DateTime.Property property20 = dateTime18.era();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19 + "'", int10 == 19);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 33 + "'", int11 == 33);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
//        org.junit.Assert.assertNotNull(zonedChronology17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 462 + "'", int19 == 462);
//        org.junit.Assert.assertNotNull(property20);
//    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test264");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
//        boolean boolean25 = delegatedDateTimeField24.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) 1970, dateTimeZone27);
//        org.joda.time.LocalDate localDate32 = localDate30.withYear((int) (short) 1);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = delegatedDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDate32, locale33);
//        org.joda.time.DurationField durationField35 = null;
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
//        org.joda.time.DateTime.Property property39 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime.Property property40 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime dateTime42 = dateTime38.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
//        java.lang.String str44 = property43.getAsShortText();
//        int int45 = property43.getMinimumValueOverall();
//        int int46 = property43.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField24, durationField35, dateTimeFieldType47, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType47, 69, 0, 0);
//        org.joda.time.ReadableInterval readableInterval54 = null;
//        org.joda.time.Chronology chronology55 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval54);
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(chronology55);
//        org.joda.time.DateTime.Property property57 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime.Property property58 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime dateTime60 = dateTime56.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property61 = dateTime60.weekOfWeekyear();
//        java.lang.String str62 = property61.getAsShortText();
//        int int63 = property61.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime64 = property61.withMaximumValue();
//        org.joda.time.DurationField durationField65 = property61.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField66 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType47, durationField65);
//        java.lang.String str67 = unsupportedDateTimeField66.toString();
//        long long70 = unsupportedDateTimeField66.add(0L, 5767L);
//        org.joda.time.DurationField durationField71 = unsupportedDateTimeField66.getDurationField();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "24" + "'", str44.equals("24"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(chronology55);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "24" + "'", str62.equals("24"));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(durationField65);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField66);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "UnsupportedDateTimeField" + "'", str67.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 181989158400000L + "'", long70 == 181989158400000L);
//        org.junit.Assert.assertNotNull(durationField71);
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate9, locale10);
        org.joda.time.LocalDate.Property property12 = localDate9.dayOfMonth();
        org.joda.time.LocalDate localDate14 = property12.addToCopy((int) 'a');
        org.joda.time.LocalDate localDate15 = property12.withMaximumValue();
        boolean boolean16 = property12.isLeap();
        org.joda.time.LocalDate localDate17 = property12.withMaximumValue();
        try {
            org.joda.time.LocalDate localDate19 = property12.setCopy(53);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 53 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "69" + "'", str11.equals("69"));
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(localDate17);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate9, locale10);
        org.joda.time.LocalDate.Property property12 = localDate9.dayOfMonth();
        try {
            org.joda.time.LocalDate localDate14 = property12.setCopy("");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "69" + "'", str11.equals("69"));
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(buddhistChronology0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        java.util.Locale locale5 = null;
        java.lang.String str6 = localDate3.toString("000000Z", locale5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = localDate3.indexOf(dateTimeFieldType7);
        org.joda.time.DateTime dateTime9 = localDate3.toDateTimeAtMidnight();
        org.joda.time.LocalDate localDate11 = localDate3.withYearOfEra(4);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now();
        org.joda.time.LocalDate.Property property13 = localDate12.dayOfWeek();
        boolean boolean14 = localDate3.equals((java.lang.Object) property13);
        org.joda.time.LocalDate localDate15 = property13.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "000000" + "'", str6.equals("000000"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(localDate15);
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test269");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        boolean boolean4 = delegatedDateTimeField3.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
//        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
//        org.joda.time.DurationField durationField14 = null;
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        java.lang.String str23 = property22.getAsShortText();
//        int int24 = property22.getMinimumValueOverall();
//        int int25 = property22.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
//        int int31 = dateTimeZone29.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate32 = org.joda.time.LocalDate.now(dateTimeZone29);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = localDate32.toString("000000Z", locale34);
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = null;
//        int int37 = localDate32.indexOf(dateTimeFieldType36);
//        java.lang.String str39 = localDate32.toString("86");
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = dividedDateTimeField28.getAsShortText((org.joda.time.ReadablePartial) localDate32, locale40);
//        org.joda.time.LocalDate localDate43 = localDate32.withYear(57600032);
//        int int44 = localDate32.size();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "24" + "'", str23.equals("24"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-28800000) + "'", int31 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "000000" + "'", str35.equals("000000"));
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "86" + "'", str39.equals("86"));
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "24" + "'", str41.equals("24"));
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 3 + "'", int44 == 3);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withPivotYear((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.append(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        int int5 = delegatedDateTimeField3.getMinimumValue((long) (byte) 0);
        boolean boolean6 = delegatedDateTimeField3.isSupported();
        org.joda.time.DurationField durationField7 = delegatedDateTimeField3.getDurationField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("-99136");
        org.junit.Assert.assertNotNull(instant1);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
        org.joda.time.Chronology chronology2 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.minuteOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("", "0070-01-07T15:59:59.100-07:52:58", (int) '4', 57600);
        org.joda.time.Chronology chronology9 = buddhistChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        long long11 = fixedDateTimeZone8.previousTransition((long) 16);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 16L + "'", long11 == 16L);
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test274");
//        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) ' ');
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        int int4 = dateTimeZone2.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.DateTime dateTime5 = instant1.toDateTime(dateTimeZone2);
//        boolean boolean7 = dateTime5.equals((java.lang.Object) 0.0d);
//        long long8 = dateTime5.getMillis();
//        org.joda.time.DateTime.Property property9 = dateTime5.era();
//        org.joda.time.ReadableInterval readableInterval10 = null;
//        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
//        org.joda.time.DateTime.Property property13 = dateTime12.millisOfSecond();
//        org.joda.time.DateTime.Property property14 = dateTime12.millisOfSecond();
//        org.joda.time.DateTime dateTime16 = dateTime12.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property17 = dateTime16.weekOfWeekyear();
//        java.lang.String str18 = property17.getAsShortText();
//        int int19 = property17.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime20 = property17.withMaximumValue();
//        org.joda.time.DateTime dateTime21 = property17.roundHalfCeilingCopy();
//        try {
//            int int22 = property9.getDifference((org.joda.time.ReadableInstant) dateTime21);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "24" + "'", str18.equals("24"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 3589);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test276");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        java.lang.String str8 = property7.getAsText();
//        org.joda.time.DurationField durationField9 = property7.getLeapDurationField();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "24" + "'", str8.equals("24"));
//        org.junit.Assert.assertNull(durationField9);
//    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test277");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime4 = dateTime2.withEarlierOffsetAtOverlap();
//        org.joda.time.ReadablePartial readablePartial5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.withFields(readablePartial5);
//        int int7 = dateTime2.getYearOfEra();
//        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.hourOfHalfday();
//        org.joda.time.DurationField durationField10 = copticChronology8.millis();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
//        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology8, dateTimeZone11);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone11.getName((long) 1969, locale15);
//        org.joda.time.DateTime dateTime17 = dateTime2.toDateTime(dateTimeZone11);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        int int21 = dateTimeZone19.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) 1970, dateTimeZone19);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter23.withPivotYear((java.lang.Integer) 0);
//        java.lang.String str26 = localDate22.toString(dateTimeFormatter25);
//        org.joda.time.ReadableInterval readableInterval27 = null;
//        org.joda.time.Chronology chronology28 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval27);
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(chronology28);
//        org.joda.time.DateTime.Property property30 = dateTime29.millisOfSecond();
//        org.joda.time.DateTime dateTime31 = dateTime29.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime32 = localDate22.toDateTime((org.joda.time.ReadableInstant) dateTime29);
//        org.joda.time.LocalDate.Property property33 = localDate22.dayOfMonth();
//        org.joda.time.LocalDate localDate35 = localDate22.withCenturyOfEra(2000);
//        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.getDefault();
//        int int39 = dateTimeZone37.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate((long) 1970, dateTimeZone37);
//        org.joda.time.DateMidnight dateMidnight41 = localDate35.toDateMidnight(dateTimeZone37);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((java.lang.Object) dateTime17, dateTimeZone37);
//        try {
//            org.joda.time.DateTime dateTime44 = dateTime42.withDayOfYear(2790);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2790 for dayOfYear must be in the range [1,365]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(copticChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
//        org.junit.Assert.assertNotNull(zonedChronology13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Pacific Standard Time" + "'", str16.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-28800000) + "'", int21 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1969" + "'", str26.equals("1969"));
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-28800000) + "'", int39 == (-28800000));
//        org.junit.Assert.assertNotNull(dateMidnight41);
//    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test278");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime6.plusMillis((-1));
//        int int10 = dateTime9.getYearOfCentury();
//        int int11 = dateTime9.getSecondOfMinute();
//        int int12 = dateTime9.getSecondOfDay();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19 + "'", int10 == 19);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 57935 + "'", int12 == 57935);
//    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("(\"org.joda.time.JodaTimePermission\" \"1\")", "era");
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 100, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime7 = dateTime5.plus(0L);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMinutes(4);
        org.joda.time.DateTime dateTime11 = dateTime9.plusSeconds(712419);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getMinimumValue((long) (byte) 0);
        boolean boolean8 = delegatedDateTimeField4.isLeap((long) 0);
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField4, 1969);
        int int12 = skipDateTimeField10.get((long) 49);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86 + "'", int12 == 86);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.hourOfHalfday();
        org.joda.time.DurationField durationField2 = copticChronology0.millis();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate9 = org.joda.time.LocalDate.now(dateTimeZone6);
        java.lang.String str10 = dateTimeZone6.getID();
        org.joda.time.Chronology chronology11 = copticChronology0.withZone(dateTimeZone6);
        org.joda.time.DurationField durationField12 = copticChronology0.years();
        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField14 = copticChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "America/Los_Angeles" + "'", str10.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType7);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        int int13 = dateTimeZone11.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) 1970, dateTimeZone11);
        java.util.Locale locale15 = null;
        java.lang.String str16 = delegatedDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
        org.joda.time.LocalDate.Property property17 = localDate14.dayOfMonth();
        java.lang.String str18 = property17.getAsText();
        org.joda.time.LocalDate localDate19 = property17.roundCeilingCopy();
        org.joda.time.LocalDate localDate21 = localDate19.withWeekyear(7);
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField4.getAsText((org.joda.time.ReadablePartial) localDate21, locale22);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-28800000) + "'", int13 == (-28800000));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "69" + "'", str16.equals("69"));
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "31" + "'", str18.equals("31"));
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "7" + "'", str23.equals("7"));
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test286");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
//        boolean boolean25 = delegatedDateTimeField24.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) 1970, dateTimeZone27);
//        org.joda.time.LocalDate localDate32 = localDate30.withYear((int) (short) 1);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = delegatedDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDate32, locale33);
//        org.joda.time.DurationField durationField35 = null;
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
//        org.joda.time.DateTime.Property property39 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime.Property property40 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime dateTime42 = dateTime38.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
//        java.lang.String str44 = property43.getAsShortText();
//        int int45 = property43.getMinimumValueOverall();
//        int int46 = property43.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField24, durationField35, dateTimeFieldType47, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType47, 69, 0, 0);
//        org.joda.time.ReadableInterval readableInterval54 = null;
//        org.joda.time.Chronology chronology55 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval54);
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(chronology55);
//        org.joda.time.DateTime.Property property57 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime.Property property58 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime dateTime60 = dateTime56.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property61 = dateTime60.weekOfWeekyear();
//        java.lang.String str62 = property61.getAsShortText();
//        int int63 = property61.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime64 = property61.withMaximumValue();
//        org.joda.time.DurationField durationField65 = property61.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField66 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType47, durationField65);
//        java.lang.String str67 = unsupportedDateTimeField66.toString();
//        long long70 = unsupportedDateTimeField66.getDifferenceAsLong(337244400000L, (-9910800000L));
//        boolean boolean71 = unsupportedDateTimeField66.isSupported();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "24" + "'", str44.equals("24"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(chronology55);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "24" + "'", str62.equals("24"));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(durationField65);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField66);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "UnsupportedDateTimeField" + "'", str67.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 11L + "'", long70 == 11L);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime5 = property3.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime7 = property3.addToCopy(132);
        org.joda.time.DurationField durationField8 = property3.getDurationField();
        long long11 = durationField8.subtract(0L, 15);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-15L) + "'", long11 == (-15L));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        java.util.Locale locale5 = null;
        java.lang.String str6 = localDate3.toString("000000Z", locale5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        int int9 = dateTimeZone7.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate10 = org.joda.time.LocalDate.now(dateTimeZone7);
        java.util.Locale locale12 = null;
        java.lang.String str13 = localDate10.toString("000000Z", locale12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        int int15 = localDate10.indexOf(dateTimeFieldType14);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        long long20 = dateTimeZone17.adjustOffset(10L, true);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) 1969, dateTimeZone17);
        org.joda.time.LocalDate localDate22 = localDate10.withFields((org.joda.time.ReadablePartial) localDate21);
        boolean boolean23 = localDate3.isBefore((org.joda.time.ReadablePartial) localDate10);
        try {
            int int25 = localDate3.getValue(1686);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 1686");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "000000" + "'", str6.equals("000000"));
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-28800000) + "'", int9 == (-28800000));
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "000000" + "'", str13.equals("000000"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getMinimumValue((long) (byte) 0);
        boolean boolean8 = delegatedDateTimeField4.isLeap((long) 0);
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField4, 1969);
        int int11 = skipDateTimeField10.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        int int15 = dateTimeZone13.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) 1970, dateTimeZone13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter17.withPivotYear((java.lang.Integer) 0);
        java.lang.String str20 = localDate16.toString(dateTimeFormatter19);
        org.joda.time.ReadableInterval readableInterval21 = null;
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(chronology22);
        org.joda.time.DateTime.Property property24 = dateTime23.millisOfSecond();
        org.joda.time.DateTime dateTime25 = dateTime23.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime26 = localDate16.toDateTime((org.joda.time.ReadableInstant) dateTime23);
        boolean boolean27 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate16);
        java.util.Locale locale29 = null;
        java.lang.String str30 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate16, (-99136), locale29);
        java.lang.String str32 = skipDateTimeField10.getAsText(144000000L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-28800000) + "'", int15 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969" + "'", str20.equals("1969"));
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "-99136" + "'", str30.equals("-99136"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "87" + "'", str32.equals("87"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test291");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
//        boolean boolean25 = delegatedDateTimeField24.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) 1970, dateTimeZone27);
//        org.joda.time.LocalDate localDate32 = localDate30.withYear((int) (short) 1);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = delegatedDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDate32, locale33);
//        org.joda.time.DurationField durationField35 = null;
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
//        org.joda.time.DateTime.Property property39 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime.Property property40 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime dateTime42 = dateTime38.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
//        java.lang.String str44 = property43.getAsShortText();
//        int int45 = property43.getMinimumValueOverall();
//        int int46 = property43.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField24, durationField35, dateTimeFieldType47, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType47, 69, 0, 0);
//        long long55 = offsetDateTimeField53.roundCeiling((long) (byte) 10);
//        long long57 = offsetDateTimeField53.roundFloor((long) 7);
//        org.joda.time.DurationField durationField58 = offsetDateTimeField53.getDurationField();
//        int int60 = offsetDateTimeField53.getLeapAmount((-630806399900L));
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "24" + "'", str44.equals("24"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 22143600000L + "'", long55 == 22143600000L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-9910800000L) + "'", long57 == (-9910800000L));
//        org.junit.Assert.assertNotNull(durationField58);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        java.util.TimeZone timeZone3 = dateTimeZone1.toTimeZone();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant4, 3);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology6.getZone();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (short) -1);
        org.joda.time.DateTime dateTime5 = instant1.toDateTime(dateTimeZone2);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTime.Property property7 = dateTime5.yearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate9, locale10);
        org.joda.time.LocalDate.Property property12 = localDate9.dayOfMonth();
        java.lang.String str13 = property12.getAsText();
        org.joda.time.LocalDate localDate14 = property12.roundCeilingCopy();
        org.joda.time.LocalDate localDate16 = property12.setCopy(2);
        java.lang.String str18 = localDate16.toString("3588");
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "69" + "'", str11.equals("69"));
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31" + "'", str13.equals("31"));
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "3588" + "'", str18.equals("3588"));
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test295");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        boolean boolean4 = delegatedDateTimeField3.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
//        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
//        org.joda.time.DurationField durationField14 = null;
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        java.lang.String str23 = property22.getAsShortText();
//        int int24 = property22.getMinimumValueOverall();
//        int int25 = property22.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
//        int int29 = dividedDateTimeField28.getMinimumValue();
//        long long32 = dividedDateTimeField28.add(0L, 0);
//        try {
//            long long35 = dividedDateTimeField28.getDifferenceAsLong((-210863995200000L), 0L);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The minuend instant is below the supported minimum of 0001-01-01T00:00:00.000Z (CopticChronology[UTC])");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "24" + "'", str23.equals("24"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test296");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        long long4 = dateTimeZone1.adjustOffset(10L, true);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) 1969, dateTimeZone1);
//        org.joda.time.DateMidnight dateMidnight6 = localDate5.toDateMidnight();
//        org.joda.time.LocalDate.Property property7 = localDate5.monthOfYear();
//        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9, dateTimeFieldType10);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField11);
//        long long14 = delegatedDateTimeField11.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        java.lang.String str23 = property22.getAsShortText();
//        int int24 = property22.getMinimumValueOverall();
//        int int25 = property22.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField11, dateTimeFieldType26, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField30 = copticChronology29.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField30, dateTimeFieldType31);
//        boolean boolean33 = delegatedDateTimeField32.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.getDefault();
//        int int37 = dateTimeZone35.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate((long) 1970, dateTimeZone35);
//        org.joda.time.LocalDate localDate40 = localDate38.withYear((int) (short) 1);
//        java.util.Locale locale41 = null;
//        java.lang.String str42 = delegatedDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate40, locale41);
//        org.joda.time.DurationField durationField43 = null;
//        org.joda.time.ReadableInterval readableInterval44 = null;
//        org.joda.time.Chronology chronology45 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval44);
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime(chronology45);
//        org.joda.time.DateTime.Property property47 = dateTime46.millisOfSecond();
//        org.joda.time.DateTime.Property property48 = dateTime46.millisOfSecond();
//        org.joda.time.DateTime dateTime50 = dateTime46.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property51 = dateTime50.weekOfWeekyear();
//        java.lang.String str52 = property51.getAsShortText();
//        int int53 = property51.getMinimumValueOverall();
//        int int54 = property51.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType55 = property51.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField57 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField32, durationField43, dateTimeFieldType55, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField61 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField11, dateTimeFieldType55, 69, 0, 0);
//        boolean boolean62 = localDate5.isSupported(dateTimeFieldType55);
//        org.joda.time.ReadablePeriod readablePeriod63 = null;
//        org.joda.time.LocalDate localDate64 = localDate5.minus(readablePeriod63);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
//        org.junit.Assert.assertNotNull(dateMidnight6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(copticChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-9910800000L) + "'", long14 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "24" + "'", str23.equals("24"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertNotNull(copticChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-28800000) + "'", int37 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate40);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "1" + "'", str42.equals("1"));
//        org.junit.Assert.assertNotNull(chronology45);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "24" + "'", str52.equals("24"));
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 52 + "'", int54 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType55);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertNotNull(localDate64);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial(chronology1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField5 = gJChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.yearOfEra();
        org.joda.time.Partial partial8 = partial3.withChronologyRetainFields((org.joda.time.Chronology) gJChronology4);
        int[] intArray9 = partial8.getValues();
        int[] intArray10 = partial8.getValues();
        java.util.Locale locale12 = null;
        java.lang.String str13 = partial8.toString("100", locale12);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(partial8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology0.era();
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType7);
        boolean boolean9 = delegatedDateTimeField8.isSupported();
        org.joda.time.DateTimeField dateTimeField10 = delegatedDateTimeField8.getWrappedField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField8, 132);
        int int14 = skipDateTimeField12.getMaximumValue((long) 1969);
        long long16 = skipDateTimeField12.roundHalfEven((long) 57600);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-9910800000L) + "'", long16 == (-9910800000L));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("CopticChronology[America/Los_Angeles]");
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        boolean boolean2 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendYearOfCentury(365, 1969);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendTimeZoneOffset("0019-06-15T16:04:51.100-07:52:58", "(\"org.joda.time.JodaTimePermission\" \"1\")", false, 0, 33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = gJChronology5.getZone();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        boolean boolean8 = copticChronology0.equals((java.lang.Object) dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = copticChronology0.year();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(57925, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 115850 + "'", int2 == 115850);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((-61553257773346L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1728166L + "'", long1 == 1728166L);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("1");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.dateHour();
        boolean boolean3 = jodaTimePermission1.equals((java.lang.Object) dateTimeFormatter2);
        org.joda.time.JodaTimePermission jodaTimePermission5 = new org.joda.time.JodaTimePermission("1");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.dateHour();
        boolean boolean7 = jodaTimePermission5.equals((java.lang.Object) dateTimeFormatter6);
        org.joda.time.JodaTimePermission jodaTimePermission9 = new org.joda.time.JodaTimePermission("1");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.dateHour();
        boolean boolean11 = jodaTimePermission9.equals((java.lang.Object) dateTimeFormatter10);
        boolean boolean12 = jodaTimePermission5.implies((java.security.Permission) jodaTimePermission9);
        boolean boolean13 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission9);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.secondOfDay();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology5);
        org.joda.time.DateTime.Property property7 = dateTime6.millisOfSecond();
        org.joda.time.DateTime dateTime8 = dateTime6.withEarlierOffsetAtOverlap();
        org.joda.time.ReadablePartial readablePartial9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.withFields(readablePartial9);
        boolean boolean11 = copticChronology0.equals((java.lang.Object) dateTime6);
        org.joda.time.DateTime dateTime12 = dateTime6.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getMinimumValue((long) (byte) 0);
        boolean boolean8 = delegatedDateTimeField4.isLeap((long) 0);
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField4, 1969);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField13 = gJChronology12.weekyears();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology12.centuryOfEra();
        org.joda.time.DurationField durationField15 = gJChronology12.days();
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(0L, (org.joda.time.Chronology) gJChronology12);
        int int17 = skipDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDate16);
        java.lang.String str19 = skipDateTimeField10.getAsText(9972000000L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "87" + "'", str19.equals("87"));
    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test308");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
//        boolean boolean25 = delegatedDateTimeField24.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) 1970, dateTimeZone27);
//        org.joda.time.LocalDate localDate32 = localDate30.withYear((int) (short) 1);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = delegatedDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDate32, locale33);
//        org.joda.time.DurationField durationField35 = null;
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
//        org.joda.time.DateTime.Property property39 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime.Property property40 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime dateTime42 = dateTime38.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
//        java.lang.String str44 = property43.getAsShortText();
//        int int45 = property43.getMinimumValueOverall();
//        int int46 = property43.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField24, durationField35, dateTimeFieldType47, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType47, 69, 0, 0);
//        org.joda.time.ReadableInterval readableInterval54 = null;
//        org.joda.time.Chronology chronology55 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval54);
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(chronology55);
//        org.joda.time.DateTime.Property property57 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime.Property property58 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime dateTime60 = dateTime56.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property61 = dateTime60.weekOfWeekyear();
//        java.lang.String str62 = property61.getAsShortText();
//        int int63 = property61.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime64 = property61.withMaximumValue();
//        org.joda.time.DurationField durationField65 = property61.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField66 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType47, durationField65);
//        java.lang.String str67 = unsupportedDateTimeField66.toString();
//        org.joda.time.ReadableInterval readableInterval68 = null;
//        org.joda.time.Chronology chronology69 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval68);
//        org.joda.time.DateTime dateTime70 = new org.joda.time.DateTime(chronology69);
//        org.joda.time.Partial partial71 = new org.joda.time.Partial(chronology69);
//        org.joda.time.chrono.GJChronology gJChronology72 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField73 = gJChronology72.weekyears();
//        org.joda.time.DateTimeField dateTimeField74 = gJChronology72.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField75 = gJChronology72.yearOfEra();
//        org.joda.time.Partial partial76 = partial71.withChronologyRetainFields((org.joda.time.Chronology) gJChronology72);
//        int[] intArray77 = partial76.getValues();
//        int[] intArray78 = partial76.getValues();
//        org.joda.time.chrono.JulianChronology julianChronology80 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone82 = org.joda.time.DateTimeZone.getDefault();
//        int int84 = dateTimeZone82.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate85 = new org.joda.time.LocalDate((long) 1970, dateTimeZone82);
//        int int86 = localDate85.getYear();
//        int int87 = localDate85.size();
//        org.joda.time.LocalDate localDate89 = localDate85.withYearOfCentury(20);
//        int[] intArray91 = julianChronology80.get((org.joda.time.ReadablePartial) localDate89, 0L);
//        try {
//            int[] intArray93 = unsupportedDateTimeField66.addWrapPartial((org.joda.time.ReadablePartial) partial76, 100, intArray91, 365);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "24" + "'", str44.equals("24"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(chronology55);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "24" + "'", str62.equals("24"));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(durationField65);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField66);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "UnsupportedDateTimeField" + "'", str67.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertNotNull(chronology69);
//        org.junit.Assert.assertNotNull(gJChronology72);
//        org.junit.Assert.assertNotNull(durationField73);
//        org.junit.Assert.assertNotNull(dateTimeField74);
//        org.junit.Assert.assertNotNull(dateTimeField75);
//        org.junit.Assert.assertNotNull(partial76);
//        org.junit.Assert.assertNotNull(intArray77);
//        org.junit.Assert.assertNotNull(intArray78);
//        org.junit.Assert.assertNotNull(julianChronology80);
//        org.junit.Assert.assertNotNull(dateTimeZone82);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-28800000) + "'", int84 == (-28800000));
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 1969 + "'", int86 == 1969);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 3 + "'", int87 == 3);
//        org.junit.Assert.assertNotNull(localDate89);
//        org.junit.Assert.assertNotNull(intArray91);
//    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime5 = property3.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime7 = property3.addToCopy(132);
        org.joda.time.DurationField durationField8 = property3.getDurationField();
        long long11 = durationField8.subtract(0L, 2019);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-2019L) + "'", long11 == (-2019L));
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test310");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay(4);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendCenturyOfEra((int) (byte) 100, 2000);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendMinuteOfHour((int) (byte) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendSecondOfMinute((int) 'a');
//        boolean boolean14 = dateTimeFormatterBuilder9.canBuildPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder9.appendLiteral("000000");
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap17 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder9.appendTimeZoneName(strMap17);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder9.appendYearOfEra(57600032, 19);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendMinuteOfDay(0);
//        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField26 = copticChronology25.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField26, dateTimeFieldType27);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField28);
//        long long31 = delegatedDateTimeField28.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval32 = null;
//        org.joda.time.Chronology chronology33 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval32);
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(chronology33);
//        org.joda.time.DateTime.Property property35 = dateTime34.millisOfSecond();
//        org.joda.time.DateTime.Property property36 = dateTime34.millisOfSecond();
//        org.joda.time.DateTime dateTime38 = dateTime34.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property39 = dateTime38.weekOfWeekyear();
//        java.lang.String str40 = property39.getAsShortText();
//        int int41 = property39.getMinimumValueOverall();
//        int int42 = property39.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property39.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField28, dateTimeFieldType43, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology46 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField47 = copticChronology46.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType48 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField49 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField47, dateTimeFieldType48);
//        boolean boolean50 = delegatedDateTimeField49.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.getDefault();
//        int int54 = dateTimeZone52.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate55 = new org.joda.time.LocalDate((long) 1970, dateTimeZone52);
//        org.joda.time.LocalDate localDate57 = localDate55.withYear((int) (short) 1);
//        java.util.Locale locale58 = null;
//        java.lang.String str59 = delegatedDateTimeField49.getAsText((org.joda.time.ReadablePartial) localDate57, locale58);
//        org.joda.time.DurationField durationField60 = null;
//        org.joda.time.ReadableInterval readableInterval61 = null;
//        org.joda.time.Chronology chronology62 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval61);
//        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime(chronology62);
//        org.joda.time.DateTime.Property property64 = dateTime63.millisOfSecond();
//        org.joda.time.DateTime.Property property65 = dateTime63.millisOfSecond();
//        org.joda.time.DateTime dateTime67 = dateTime63.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property68 = dateTime67.weekOfWeekyear();
//        java.lang.String str69 = property68.getAsShortText();
//        int int70 = property68.getMinimumValueOverall();
//        int int71 = property68.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType72 = property68.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField74 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField49, durationField60, dateTimeFieldType72, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField78 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField28, dateTimeFieldType72, 69, 0, 0);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException81 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType72, (java.lang.Number) 0, "69");
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType72, 53, 36, 1970);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder88 = dateTimeFormatterBuilder22.appendFraction(dateTimeFieldType72, 69, (-101573));
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder91 = dateTimeFormatterBuilder9.appendDecimal(dateTimeFieldType72, (int) (byte) 10, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder92 = dateTimeFormatterBuilder8.appendText(dateTimeFieldType72);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(copticChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-9910800000L) + "'", long31 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology33);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "24" + "'", str40.equals("24"));
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 52 + "'", int42 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(copticChronology46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone52);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-28800000) + "'", int54 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate57);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "1" + "'", str59.equals("1"));
//        org.junit.Assert.assertNotNull(chronology62);
//        org.junit.Assert.assertNotNull(property64);
//        org.junit.Assert.assertNotNull(property65);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(property68);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "24" + "'", str69.equals("24"));
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 52 + "'", int71 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType72);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder88);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder91);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder92);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 1970, dateTimeZone1);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 999");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test312");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("1");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        boolean boolean3 = jodaTimePermission1.equals((java.lang.Object) dateTimeFormatter2);
//        java.lang.String str4 = jodaTimePermission1.getActions();
//        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType7);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        int int13 = dateTimeZone11.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) 1970, dateTimeZone11);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = delegatedDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) localDate14, locale15);
//        org.joda.time.LocalDate.Property property17 = localDate14.dayOfMonth();
//        org.joda.time.LocalDate localDate19 = property17.addToCopy((int) 'a');
//        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField21 = copticChronology20.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21, dateTimeFieldType22);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21);
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
//        int int28 = dateTimeZone26.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate((long) 1970, dateTimeZone26);
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = delegatedDateTimeField24.getAsShortText((org.joda.time.ReadablePartial) localDate29, locale30);
//        org.joda.time.LocalDate.Property property32 = localDate29.dayOfMonth();
//        org.joda.time.LocalDate localDate34 = property32.addToCopy((int) 'a');
//        boolean boolean35 = localDate19.isBefore((org.joda.time.ReadablePartial) localDate34);
//        org.joda.time.Chronology chronology36 = localDate19.getChronology();
//        org.joda.time.ReadableInterval readableInterval37 = null;
//        org.joda.time.Chronology chronology38 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval37);
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime(chronology38);
//        int int40 = dateTime39.getDayOfYear();
//        org.joda.time.ReadableDuration readableDuration41 = null;
//        org.joda.time.DateTime dateTime42 = dateTime39.plus(readableDuration41);
//        org.joda.time.DateTime dateTime44 = dateTime39.plusYears(1970);
//        org.joda.time.ReadableInterval readableInterval45 = null;
//        org.joda.time.Chronology chronology46 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval45);
//        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime(chronology46);
//        org.joda.time.DateTime.Property property48 = dateTime47.millisOfSecond();
//        org.joda.time.DateTime.Property property49 = dateTime47.millisOfSecond();
//        org.joda.time.DateTime dateTime51 = dateTime47.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property52 = dateTime51.weekOfWeekyear();
//        java.lang.String str53 = property52.getAsShortText();
//        int int54 = property52.getMinimumValueOverall();
//        int int55 = property52.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = property52.getFieldType();
//        org.joda.time.DateTime.Property property57 = dateTime39.property(dateTimeFieldType56);
//        boolean boolean58 = localDate19.isSupported(dateTimeFieldType56);
//        boolean boolean59 = jodaTimePermission1.equals((java.lang.Object) localDate19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
//        org.junit.Assert.assertNotNull(copticChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-28800000) + "'", int13 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "69" + "'", str16.equals("69"));
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(copticChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-28800000) + "'", int28 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "69" + "'", str31.equals("69"));
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(localDate34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(chronology36);
//        org.junit.Assert.assertNotNull(chronology38);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 166 + "'", int40 == 166);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(chronology46);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "24" + "'", str53.equals("24"));
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 52 + "'", int55 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType56);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneShortName();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap6 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTimeZoneShortName(strMap6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendHourOfDay(1686);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(strMap6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test314");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        boolean boolean4 = delegatedDateTimeField3.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
//        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
//        org.joda.time.DurationField durationField14 = null;
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        java.lang.String str23 = property22.getAsShortText();
//        int int24 = property22.getMinimumValueOverall();
//        int int25 = property22.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
//        int int29 = dividedDateTimeField28.getMinimumValue();
//        long long32 = dividedDateTimeField28.add(0L, 0);
//        org.joda.time.DurationField durationField33 = dividedDateTimeField28.getDurationField();
//        int int36 = dividedDateTimeField28.getDifference((long) (-28800000), 32L);
//        long long39 = dividedDateTimeField28.add((long) 52, 0);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "24" + "'", str23.equals("24"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 52L + "'", long39 == 52L);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 86, number2, (java.lang.Number) 10);
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException4.getSuppressed();
        java.lang.String str6 = illegalFieldValueException4.getIllegalStringValue();
        illegalFieldValueException4.prependMessage("658");
        java.lang.String str9 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Number number10 = illegalFieldValueException4.getLowerBound();
        java.lang.Number number11 = illegalFieldValueException4.getUpperBound();
        java.lang.String str12 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "86" + "'", str9.equals("86"));
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 10 + "'", number11.equals(10));
        org.junit.Assert.assertNull(str12);
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test316");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        boolean boolean4 = delegatedDateTimeField3.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 1970, dateTimeZone6);
//        org.joda.time.LocalDate localDate11 = localDate9.withYear((int) (short) 1);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
//        org.joda.time.DurationField durationField14 = null;
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(chronology16);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime21 = dateTime17.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekOfWeekyear();
//        java.lang.String str23 = property22.getAsShortText();
//        int int24 = property22.getMinimumValueOverall();
//        int int25 = property22.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField14, dateTimeFieldType26, 52);
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
//        int int31 = dateTimeZone29.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate32 = org.joda.time.LocalDate.now(dateTimeZone29);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = localDate32.toString("000000Z", locale34);
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = null;
//        int int37 = localDate32.indexOf(dateTimeFieldType36);
//        java.lang.String str39 = localDate32.toString("86");
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = dividedDateTimeField28.getAsShortText((org.joda.time.ReadablePartial) localDate32, locale40);
//        org.joda.time.LocalDate localDate43 = localDate32.withYear(57600032);
//        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone45 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone44);
//        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeUtils.getZone(dateTimeZone44);
//        boolean boolean47 = localDate32.equals((java.lang.Object) dateTimeZone46);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "24" + "'", str23.equals("24"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-28800000) + "'", int31 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "000000" + "'", str35.equals("000000"));
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "86" + "'", str39.equals("86"));
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "24" + "'", str41.equals("24"));
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone45);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        boolean boolean2 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) ' ');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfMinute();
        org.joda.time.Instant instant3 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.clockhourOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology0.getZone();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial(chronology1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField5 = gJChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.yearOfEra();
        org.joda.time.Partial partial8 = partial3.withChronologyRetainFields((org.joda.time.Chronology) gJChronology4);
        try {
            long long13 = gJChronology4.getDateTimeMillis(59, (int) (byte) 0, 33, (-28378000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28378000 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(partial8);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        int int1 = copticChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(chronology3);
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfSecond();
        org.joda.time.DateTime dateTime7 = property5.addWrapFieldToCopy(0);
        boolean boolean8 = copticChronology0.equals((java.lang.Object) dateTime7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.plus(readablePeriod9);
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology11.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, dateTimeFieldType13);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        int int19 = dateTimeZone17.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((long) 1970, dateTimeZone17);
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate20, locale21);
        org.joda.time.LocalDate.Property property23 = localDate20.dayOfMonth();
        java.lang.String str24 = property23.getAsText();
        org.joda.time.LocalDate localDate25 = property23.roundCeilingCopy();
        org.joda.time.LocalDate localDate27 = localDate25.withWeekyear(7);
        org.joda.time.DateTime dateTime28 = dateTime10.withFields((org.joda.time.ReadablePartial) localDate27);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-28800000) + "'", int19 == (-28800000));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "69" + "'", str22.equals("69"));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31" + "'", str24.equals("31"));
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(dateTime28);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        java.io.Writer writer1 = null;
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(chronology3);
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfSecond();
        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
        org.joda.time.DateTime dateTime8 = dateTime4.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property9 = dateTime8.weekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime8.plusMillis((-1));
        boolean boolean12 = dateTime11.isAfterNow();
        org.joda.time.DateTime dateTime14 = dateTime11.plusYears(86);
        org.joda.time.DateTime dateTime16 = dateTime11.plusSeconds(53);
        org.joda.time.DateTime dateTime18 = dateTime11.plusMinutes((int) '4');
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test323");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
//        boolean boolean25 = delegatedDateTimeField24.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) 1970, dateTimeZone27);
//        org.joda.time.LocalDate localDate32 = localDate30.withYear((int) (short) 1);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = delegatedDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDate32, locale33);
//        org.joda.time.DurationField durationField35 = null;
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
//        org.joda.time.DateTime.Property property39 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime.Property property40 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime dateTime42 = dateTime38.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
//        java.lang.String str44 = property43.getAsShortText();
//        int int45 = property43.getMinimumValueOverall();
//        int int46 = property43.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField24, durationField35, dateTimeFieldType47, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType47, 69, 0, 0);
//        org.joda.time.ReadableInterval readableInterval54 = null;
//        org.joda.time.Chronology chronology55 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval54);
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(chronology55);
//        org.joda.time.DateTime.Property property57 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime.Property property58 = dateTime56.millisOfSecond();
//        org.joda.time.DateTime dateTime60 = dateTime56.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property61 = dateTime60.weekOfWeekyear();
//        java.lang.String str62 = property61.getAsShortText();
//        int int63 = property61.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime64 = property61.withMaximumValue();
//        org.joda.time.DurationField durationField65 = property61.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField66 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType47, durationField65);
//        org.joda.time.DurationField durationField67 = unsupportedDateTimeField66.getLeapDurationField();
//        org.joda.time.ReadablePartial readablePartial68 = null;
//        try {
//            int int69 = unsupportedDateTimeField66.getMinimumValue(readablePartial68);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "24" + "'", str44.equals("24"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(chronology55);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "24" + "'", str62.equals("24"));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(durationField65);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField66);
//        org.junit.Assert.assertNull(durationField67);
//    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test324");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3);
//        long long6 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
//        java.lang.String str15 = property14.getAsShortText();
//        int int16 = property14.getMinimumValueOverall();
//        int int17 = property14.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType18, 3588);
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.weekyearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
//        boolean boolean25 = delegatedDateTimeField24.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) 1970, dateTimeZone27);
//        org.joda.time.LocalDate localDate32 = localDate30.withYear((int) (short) 1);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = delegatedDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDate32, locale33);
//        org.joda.time.DurationField durationField35 = null;
//        org.joda.time.ReadableInterval readableInterval36 = null;
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
//        org.joda.time.DateTime.Property property39 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime.Property property40 = dateTime38.millisOfSecond();
//        org.joda.time.DateTime dateTime42 = dateTime38.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property43 = dateTime42.weekOfWeekyear();
//        java.lang.String str44 = property43.getAsShortText();
//        int int45 = property43.getMinimumValueOverall();
//        int int46 = property43.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField24, durationField35, dateTimeFieldType47, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType47, 69, 0, 0);
//        long long55 = offsetDateTimeField53.roundCeiling((long) (byte) 10);
//        long long57 = offsetDateTimeField53.roundFloor((long) 7);
//        org.joda.time.DurationField durationField58 = offsetDateTimeField53.getDurationField();
//        int int60 = offsetDateTimeField53.get((-1114272000000L));
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9910800000L) + "'", long6 == (-9910800000L));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "24" + "'", str44.equals("24"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 22143600000L + "'", long55 == 22143600000L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-9910800000L) + "'", long57 == (-9910800000L));
//        org.junit.Assert.assertNotNull(durationField58);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 121 + "'", int60 == 121);
//    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(0, ' ', (int) (short) -1, (int) (short) 0, 0, true, (int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeZoneBuilder0.toDateTimeZone("weekyearOfCentury", true);
        java.io.OutputStream outputStream13 = null;
        try {
            dateTimeZoneBuilder0.writeTo("[]", outputStream13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendYear(3, (int) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test327");
//        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.hourOfHalfday();
//        org.joda.time.DurationField durationField3 = copticChronology1.millis();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology1, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        int int9 = dateTimeZone7.getOffsetFromLocal((long) (short) -1);
//        org.joda.time.LocalDate localDate10 = org.joda.time.LocalDate.now(dateTimeZone7);
//        java.lang.String str11 = dateTimeZone7.getID();
//        org.joda.time.Chronology chronology12 = copticChronology1.withZone(dateTimeZone7);
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(0L, chronology12);
//        org.joda.time.ReadableInterval readableInterval14 = null;
//        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval14);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(chronology15);
//        org.joda.time.DateTime.Property property17 = dateTime16.millisOfSecond();
//        org.joda.time.DateTime.Property property18 = dateTime16.millisOfSecond();
//        org.joda.time.DateTime dateTime20 = dateTime16.withCenturyOfEra(0);
//        org.joda.time.DateTime.Property property21 = dateTime20.weekOfWeekyear();
//        java.lang.String str22 = property21.getAsShortText();
//        int int23 = property21.getMinimumValueOverall();
//        int int24 = property21.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property21.getFieldType();
//        org.joda.time.LocalDate localDate27 = localDate13.withField(dateTimeFieldType25, 49);
//        org.junit.Assert.assertNotNull(copticChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-28800000) + "'", int9 == (-28800000));
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "America/Los_Angeles" + "'", str11.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "24" + "'", str22.equals("24"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 52 + "'", int24 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertNotNull(localDate27);
//    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
        org.joda.time.DateTime dateTime6 = localDate3.toDateTimeAtCurrentTime(dateTimeZone5);
        int int7 = localDate3.getCenturyOfEra();
        org.joda.time.LocalDate localDate9 = localDate3.withEra(0);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.LocalDate localDate11 = localDate3.minus(readablePeriod10);
        java.util.Date date12 = localDate11.toDate();
        org.joda.time.LocalDate localDate13 = org.joda.time.LocalDate.fromDateFields(date12);
        org.joda.time.LocalDate localDate15 = localDate13.plusYears(36);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        int int18 = dateTimeZone16.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate19 = org.joda.time.LocalDate.now(dateTimeZone16);
        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
        org.joda.time.LocalDate.Property property21 = localDate19.weekOfWeekyear();
        org.joda.time.LocalDate localDate22 = property21.getLocalDate();
        org.joda.time.LocalDate localDate23 = property21.withMinimumValue();
        boolean boolean24 = localDate13.isEqual((org.joda.time.ReadablePartial) localDate23);
        try {
            org.joda.time.LocalDate localDate26 = localDate13.withYearOfCentury(999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 999 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20 + "'", int7 == 20);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-28800000) + "'", int18 == (-28800000));
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withOffsetParsed();
        try {
            org.joda.time.LocalDate localDate4 = dateTimeFormatter0.parseLocalDate("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
        org.joda.time.DateTime dateTime6 = localDate3.toDateTimeAtCurrentTime(dateTimeZone5);
        int int7 = localDate3.getCenturyOfEra();
        org.joda.time.LocalDate localDate9 = localDate3.withEra(0);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.LocalDate localDate11 = localDate3.minus(readablePeriod10);
        java.util.Date date12 = localDate11.toDate();
        org.joda.time.LocalDate localDate13 = org.joda.time.LocalDate.fromDateFields(date12);
        org.joda.time.LocalDate localDate15 = localDate13.withYearOfEra((int) ' ');
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = copticChronology16.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType18);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        int int24 = dateTimeZone22.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) 1970, dateTimeZone22);
        java.util.Locale locale26 = null;
        java.lang.String str27 = delegatedDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) localDate25, locale26);
        org.joda.time.LocalDate.Property property28 = localDate25.dayOfMonth();
        org.joda.time.LocalDate localDate30 = property28.addToCopy((int) 'a');
        org.joda.time.chrono.CopticChronology copticChronology31 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = copticChronology31.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField32, dateTimeFieldType33);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField35 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField32);
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.getDefault();
        int int39 = dateTimeZone37.getOffsetFromLocal((long) (short) -1);
        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate((long) 1970, dateTimeZone37);
        java.util.Locale locale41 = null;
        java.lang.String str42 = delegatedDateTimeField35.getAsShortText((org.joda.time.ReadablePartial) localDate40, locale41);
        org.joda.time.LocalDate.Property property43 = localDate40.dayOfMonth();
        org.joda.time.LocalDate localDate45 = property43.addToCopy((int) 'a');
        boolean boolean46 = localDate30.isBefore((org.joda.time.ReadablePartial) localDate45);
        java.util.Locale locale48 = null;
        java.lang.String str49 = localDate45.toString("[]", locale48);
        org.joda.time.LocalDate localDate50 = localDate13.withFields((org.joda.time.ReadablePartial) localDate45);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20 + "'", int7 == 20);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "69" + "'", str27.equals("69"));
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertNotNull(copticChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-28800000) + "'", int39 == (-28800000));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "69" + "'", str42.equals("69"));
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(localDate45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "[]" + "'", str49.equals("[]"));
        org.junit.Assert.assertNotNull(localDate50);
    }
}

